<?php use App\Core\{Rp, Cal}; require __DIR__ . '/../pj/_report_css.php'; echo Rp::css(); Rp::reset(); $sid = (int)$s['id']; $back = 'cal/' . $sid . '/report'; $per = 'c' . $sid;
$tone = fn($v, $a = 85, $b = 70) => $v === null ? 'na' : ($v >= $a ? 'ok' : ($v >= $b ? 'warn' : 'ko'));
echo Rp::bar($title, url('cal/' . $sid)); ?>
<?= Rp::open('Rapport de calibrage qualité', $s['ref'] . ' · ' . $s['title'] . ' · ' . d($s['held_on'])) ?>
<div class="kcs">
<?= Rp::kpi((string)$m['cases'], 'Cas calibrés', $m['ref_cases'] . ' avec référence') ?>
<?= Rp::kpi((string)$m['raters'], 'Évaluateurs') ?>
<?= Rp::kpi(Rp::pct($m['exact_pct'], 0), 'Accord exact sur les critères', 'à la cotation de référence', true) ?>
<?= Rp::kpi($m['gap_avg'] === null ? '—' : Rp::num($m['gap_avg'], 1) . ' pt', 'Écart moyen des scores', 'vs référence') ?>
<?= Rp::kpi(Rp::pct($m['sev_pct'], 0), 'Accord sur la gravité', $m['sev_div_major'] . ' divergence(s) majeure(s)') ?>
<?= Rp::kpi(Rp::pct($m['na_pct'], 0), 'Accord sur les « NA »') ?>
</div>
<div class="nb"><h4>Contexte</h4>Grille : <?= e($s['grid_name']) ?><?= $s['grid_version'] ? ' (v' . e($s['grid_version']) . ')' : '' ?> · Étape : <?= e(Cal::ST[$s['status']]) ?> · Périmètre : <?= e($s['scope'] ?: '—') ?> · Objectif : <?= e($s['objective'] ?: '—') ?></div>
<?= Rp::note('cal', $per, 'synth', 'Synthèse', $edit, $back, 'À rédiger par l\'arbitre.') ?>
<?= Rp::close() ?>
<?= Rp::open('Alignement par évaluateur et par périmètre', $s['ref']) ?>
<div class="ns"><div><?php $t = []; foreach ($m['by_rater'] as $r) $t[] = [$r['name'], $r['cases'], Rp::pct($r['exact_pct'], 0), $r['gap_avg'] === null ? '—' : Rp::num($r['gap_avg'], 1) . ' pt', ['h' => Rp::status($tone($r['exact_pct']))]]; echo Rp::table(['Évaluateur', 'Cas', 'Accord exact', 'Écart moyen', 'Statut'], $t, [1, 2, 3], 'Aucune cotation comparée.'); ?></div>
<div><?php $t = []; foreach ($m['by_scope'] as $k => $r) $t[] = [$k, $r['cases'], Rp::pct($r['exact_pct'], 0), $r['gap_avg'] === null ? '—' : Rp::num($r['gap_avg'], 1) . ' pt', $r['sev_div']]; echo Rp::table(['Périmètre', 'Cas', 'Accord exact', 'Écart moyen', 'Div. gravité'], $t, [1, 2, 3, 4]); ?></div></div>
<h4 style="margin:18px 0 0;color:#003A84">Critères les moins alignés</h4>
<?php $t = []; foreach (array_slice($m['by_crit'], 0, 6, true) as $r) if ($r['cmp']) $t[] = [$r['label'], Rp::pct($r['exact_pct'], 0), (int)$r['cmp'], implode(', ', array_keys($r['cases'])) ?: '—']; echo Rp::table(['Critère', 'Accord exact', 'Comparaisons', 'Cas en écart'], $t, [1, 2], 'Aucune donnée.'); ?>
<?= Rp::note('cal', $per, 'gaps', 'Analyse des écarts', $edit, $back) ?>
<?= Rp::close() ?>
<?= Rp::open('Décisions, plan d\'actions et validité', $s['ref']) ?>
<?php $t = []; foreach ($decisions as $d) $t[] = [$d['rule'], $d['case_ref'] ?: '—', $d['grid_effect'] ?: '—', $d['validator'] ?: '—', $d['effect_date'] ? d($d['effect_date']) : '—']; echo Rp::table(['Règle clarifiée', 'Cas', 'Effet sur la grille', 'Validé par', 'Effet le'], $t, [], 'Aucune décision.'); ?>
<?php $t = []; foreach ($plans as $p) $t[] = [$p['action'], $p['who'] ?: '—', $p['owner'] ?: '—', $p['due_on'] ? d($p['due_on']) : '—', Cal::PST[$p['status']] ?? $p['status']]; echo Rp::table(['Action', 'Concerné(s)', 'Porteur', 'Échéance', 'Statut'], $t, [], 'Aucune action.'); ?>
<div class="nb"><h4>Validité des évaluations précédentes</h4><?= $s['validity'] ? e(Cal::VAL[$s['validity']]) . ($s['validity_note'] ? ' — ' . e($s['validity_note']) : '') : 'À décider' ?><br>Diffusion : <?= e($s['diffusion'] ?: '—') ?> · Prochaine session : <?= $s['next_session'] ? d($s['next_session']) : '—' ?><?= $s['next_note'] ? ' (' . e($s['next_note']) . ')' : '' ?></div>
<?= Rp::close() ?>
