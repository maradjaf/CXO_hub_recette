<?php $v = fn($k, $d = '') => old($k, $s[$k] ?? $d); ?>
<div class="page-h"><h1><?= e($title) ?></h1><a class="btn btn-outline-secondary" href="<?= url('cal') ?>">Retour</a></div>
<form method="post" action="<?= url('cal') ?>" data-nomulti class="cardx row g-3"><?= csrf_field() ?>
<div class="col-md-8"><label class="form-label" for="k-title">Intitulé</label><input id="k-title" class="form-control" name="title" required maxlength="190" value="<?= e($v('title')) ?>" placeholder="Ex. Calibrage mensuel — appels réclamation"></div>
<div class="col-md-4"><label class="form-label" for="k-date">Date</label><input id="k-date" type="date" class="form-control" name="held_on" required value="<?= e($v('held_on')) ?>"></div>
<div class="col-md-6"><label class="form-label" for="k-grid">Grille d'évaluation</label><select id="k-grid" name="grid_id" class="form-select" required><option value="">— Choisir —</option><?php foreach ($grids as $g): ?><option value="<?= $g['id'] ?>"><?= e($g['name']) ?></option><?php endforeach; ?></select></div>
<div class="col-md-3"><label class="form-label" for="k-ver">Version de la grille</label><input id="k-ver" class="form-control" name="grid_version" maxlength="30" value="<?= e($v('grid_version')) ?>"></div>
<div class="col-md-3"><label class="form-label" for="k-arb">Arbitre</label><select id="k-arb" name="arbiter_user_id" class="form-select" required data-search><option value="">— Choisir —</option><?php foreach ($users as $u): ?><option value="<?= $u['id'] ?>"><?= e($u['name']) ?></option><?php endforeach; ?></select></div>
<div class="col-md-6"><label class="form-label" for="k-scope">Périmètre</label><input id="k-scope" class="form-control" name="scope" maxlength="300" value="<?= e($v('scope')) ?>"></div>
<div class="col-md-6"><label class="form-label" for="k-obj">Objectif</label><input id="k-obj" class="form-control" name="objective" maxlength="300" value="<?= e($v('objective')) ?>"></div>
<div class="col-12"><button class="btn btn-primary">Créer la session</button></div></form>
