<div class="logo"><i class="bi bi-headset"></i></div>
<h1 class="welcome">Bienvenue sur <?= e(setting('app.name', 'CXO Excellence Hub')) ?></h1>
<p class="text-muted">Connectez-vous avec votre adresse professionnelle.</p>
<form method="post" action="<?= url('login') ?>"><?= csrf_field() ?>
<div class="mb-3"><label class="form-label">Adresse email</label><input type="email" name="email" class="form-control form-control-lg" value="<?= e(old('email')) ?>" required autofocus autocomplete="username"></div>
<div class="mb-3"><label class="form-label">Mot de passe</label><input type="password" name="password" class="form-control form-control-lg" required autocomplete="current-password"></div>
<button class="btn btn-primary btn-lg w-100" type="submit">Se connecter</button></form>
<p class="mt-3 text-center"><a href="<?= url('forgot') ?>">Mot de passe oublié ?</a> · <a href="<?= url('verify') ?>">Vérifier un document</a></p>
<?php unset($_SESSION['_old']); ?>
