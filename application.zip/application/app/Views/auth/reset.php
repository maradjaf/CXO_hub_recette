<div class="logo"><i class="bi bi-shield-lock"></i></div>
<?php if (!$valid): ?>
<h1 class="welcome">Lien invalide ou expiré</h1>
<p class="text-muted">Ce lien a déjà été utilisé ou n'est plus valable. Faites une nouvelle demande de réinitialisation.</p>
<a class="btn btn-primary w-100" href="<?= url('forgot') ?>">Demander un nouveau lien</a>
<?php else: ?>
<h1 class="welcome">Nouveau mot de passe</h1>
<p class="text-muted">Compte : <strong><?= e($t['email']) ?></strong></p>
<form method="post" action="<?= url('reset/' . $token) ?>"><?= csrf_field() ?>
<div class="mb-3"><label class="form-label req" for="rs-n">Nouveau mot de passe</label><input id="rs-n" type="password" name="new" class="form-control form-control-lg" required minlength="10" autocomplete="new-password" autofocus><div class="form-text">10 caractères minimum, avec majuscule, minuscule et chiffre.</div></div>
<div class="mb-3"><label class="form-label req" for="rs-c">Confirmation</label><input id="rs-c" type="password" name="confirm" class="form-control form-control-lg" required autocomplete="new-password"></div>
<button class="btn btn-primary btn-lg w-100" type="submit">Enregistrer</button></form>
<?php endif; ?>
