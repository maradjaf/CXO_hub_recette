<div class="logo"><i class="bi bi-key"></i></div>
<h1 class="welcome">Mot de passe oublié</h1>
<p class="text-muted">Saisissez votre adresse professionnelle : la demande est transmise à l'administrateur, qui vous enverra un lien de réinitialisation.</p>
<form method="post" action="<?= url('forgot') ?>"><?= csrf_field() ?>
<div class="mb-3"><label class="form-label req" for="fg-e">Adresse email</label><input id="fg-e" type="email" name="email" class="form-control form-control-lg" required autofocus autocomplete="username"></div>
<div class="mb-3"><label class="form-label" for="fg-r">Précision (facultatif)</label><input id="fg-r" name="reason" maxlength="300" class="form-control" placeholder="Ex. mot de passe oublié, compte verrouillé"></div>
<button class="btn btn-primary btn-lg w-100" type="submit">Envoyer la demande</button></form>
<p class="mt-3 text-center"><a href="<?= url('login') ?>">Retour à la connexion</a></p>
