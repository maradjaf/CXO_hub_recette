<div class="page-h"><h1>Changer le mot de passe</h1></div>
<?php if (!empty(App\Core\Auth::user()['must_change_password'])): ?><div class="alert alert-warning">Votre mot de passe est provisoire. Choisissez-en un nouveau pour continuer.</div><?php endif; ?>
<form method="post" class="cardx" style="max-width:480px"><?= csrf_field() ?>
<div class="mb-3"><label class="form-label req">Mot de passe actuel</label><input type="password" name="current" class="form-control" required autocomplete="current-password"></div>
<div class="mb-3"><label class="form-label req">Nouveau mot de passe</label><input type="password" name="new" class="form-control" required minlength="10" autocomplete="new-password"><div class="form-text">10 caractères minimum, avec majuscule, minuscule et chiffre.</div></div>
<div class="mb-3"><label class="form-label req">Confirmation</label><input type="password" name="confirm" class="form-control" required autocomplete="new-password"></div>
<button class="btn btn-primary" type="submit">Enregistrer</button></form>
