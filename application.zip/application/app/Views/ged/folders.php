<?php use App\Core\Ged; ?>
<div class="page-h"><h1>Dossiers de la GED</h1><a class="btn btn-outline-secondary" href="<?= url('ged') ?>">Documents</a></div>
<div class="cardx mb-3"><h2>Nouveau dossier</h2><form method="post" action="<?= url('ged/folders') ?>" class="row g-2" data-nowizard><?= csrf_field() ?>
<div class="col-md-3"><input class="form-control" name="name" placeholder="Nom *" maxlength="150" required aria-label="Nom"></div>
<div class="col-md-3"><select class="form-select" name="parent_id" aria-label="Dossier parent"><option value="">Racine</option><?php foreach ($tree as $f): ?><option value="<?= $f['id'] ?>"><?= str_repeat('— ', $f['depth']) . e($f['name']) ?></option><?php endforeach; ?></select></div>
<div class="col-md-3"><select class="form-select" name="access" aria-label="Accès"><?php foreach (Ged::ACCESS as $k => $l): ?><option value="<?= $k ?>"><?= e($l) ?></option><?php endforeach; ?></select></div>
<div class="col-md-3"><button class="btn btn-primary w-100">Créer</button></div>
<div class="col-12"><input class="form-control" name="description" placeholder="Description (facultatif)" maxlength="400" aria-label="Description"></div></form>
<div class="form-text">Pour un accès « Rôles choisis », ouvrez le dossier ci-dessous et cochez les rôles autorisés (lecture ou écriture).</div></div>
<div class="tbl"><table class="table align-middle" id="gedFolders"><thead><tr><th>Dossier</th><th>Accès</th><th>Documents</th><th></th></tr></thead><tbody>
<?php foreach ($tree as $f): $a = $acl[$f['id']] ?? []; ?><tr><td style="padding-left:<?= .5 + $f['depth'] * 1.2 ?>rem"><i class="bi bi-folder me-1"></i><b><?= e($f['name']) ?></b><div class="small text-muted"><?= e($f['description']) ?></div></td><td class="small"><?= e(Ged::ACCESS[$f['access']]) ?><?= $f['access'] === 'roles' ? ' (' . count($a) . ')' : '' ?></td><td><?= (int)($n[$f['id']] ?? 0) ?></td>
<td class="text-end text-nowrap"><details class="d-inline-block text-start"><summary class="btn btn-sm btn-outline-primary">Modifier</summary>
<form method="post" action="<?= url('ged/folders/' . $f['id']) ?>" class="border rounded p-2 mt-1 bg-body" style="min-width:20rem" data-nowizard><?= csrf_field() ?>
<input class="form-control form-control-sm mb-1" name="name" value="<?= e($f['name']) ?>" maxlength="150" required aria-label="Nom">
<select class="form-select form-select-sm mb-1" name="parent_id" aria-label="Parent"><option value="">Racine</option><?php foreach ($tree as $g): if ((int)$g['id'] === (int)$f['id']) continue; ?><option value="<?= $g['id'] ?>" <?= (int)$g['id'] === (int)$f['parent_id'] ? 'selected' : '' ?>><?= str_repeat('— ', $g['depth']) . e($g['name']) ?></option><?php endforeach; ?></select>
<select class="form-select form-select-sm mb-1" name="access" aria-label="Accès"><?php foreach (Ged::ACCESS as $k => $l): ?><option value="<?= $k ?>" <?= $f['access'] === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select>
<input class="form-control form-control-sm mb-1" name="description" value="<?= e($f['description']) ?>" maxlength="400" aria-label="Description">
<div class="small mb-1" style="max-height:9rem;overflow:auto"><?php foreach ($roles as $r): ?><div class="d-flex justify-content-between"><span><?= e($r['name']) ?></span><select name="role[<?= $r['id'] ?>]" class="form-select form-select-sm w-auto" aria-label="Droit <?= e($r['name']) ?>"><option value="">—</option><option value="read" <?= ($a[$r['id']] ?? '') === 'read' ? 'selected' : '' ?>>Lecture</option><option value="write" <?= ($a[$r['id']] ?? '') === 'write' ? 'selected' : '' ?>>Écriture</option></select></div><?php endforeach; ?></div>
<button class="btn btn-sm btn-primary">Enregistrer</button></form></details>
<form method="post" action="<?= url('ged/folders/' . $f['id'] . '/delete') ?>" class="d-inline"><?= csrf_field() ?><button class="btn btn-sm btn-outline-danger" data-confirm="Supprimer ce dossier vide ?">Supprimer</button></form></td></tr>
<?php endforeach; if (!$tree): ?><tr><td colspan="4"><div class="empty"><i class="bi bi-folder"></i>Aucun dossier.</div></td></tr><?php endif; ?></tbody></table></div>
