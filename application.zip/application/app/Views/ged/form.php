<?php use App\Core\{Ged, Files}; ?>
<div class="page-h"><h1>Nouveau document</h1><a class="btn btn-outline-secondary" href="<?= url('ged' . ($fid ? '?folder=' . $fid : '')) ?>">Retour</a></div>
<?php if (!$folders): ?><div class="alert alert-warning">Vous n'avez le droit de déposer dans aucun dossier. Contactez un gestionnaire de la GED.</div><?php else: ?>
<form method="post" action="<?= url('ged/new') ?>" enctype="multipart/form-data" class="cardx row g-3" data-nowizard><?= csrf_field() ?>
<div class="col-md-8"><label class="form-label" for="g-t">Titre *</label><input id="g-t" class="form-control" name="title" maxlength="200" required value="<?= e(old('title')) ?>"></div>
<div class="col-md-4"><label class="form-label" for="g-f">Dossier *</label><select id="g-f" class="form-select" name="folder_id" required><?php foreach ($folders as $f): ?><option value="<?= $f['id'] ?>" <?= $fid === (int)$f['id'] ? 'selected' : '' ?>><?= str_repeat('— ', $f['depth']) . e($f['name']) ?></option><?php endforeach; ?></select></div>
<div class="col-md-4"><label class="form-label" for="g-c">Catégorie</label><input id="g-c" class="form-control" name="category" maxlength="60" list="g-cats" value="<?= e(old('category')) ?>"><datalist id="g-cats"><?php foreach ($cats as $c): ?><option value="<?= e($c['category']) ?>"><?php endforeach; ?></datalist></div>
<div class="col-md-5"><label class="form-label" for="g-k">Mots-clés (séparés par des virgules)</label><input id="g-k" class="form-control" name="tags" maxlength="300" value="<?= e(old('tags')) ?>"></div>
<div class="col-md-3"><label class="form-label" for="g-cf">Confidentialité</label><select id="g-cf" class="form-select" name="confidentiality"><?php foreach (Ged::CONF as $k => $l): ?><option value="<?= $k ?>" <?= $k === 'internal' ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
<div class="col-md-3"><label class="form-label" for="g-r">Prochaine revue</label><input id="g-r" type="date" class="form-control" name="review_date"></div>
<div class="col-md-3"><label class="form-label" for="g-x">Expiration</label><input id="g-x" type="date" class="form-control" name="expires_at"></div>
<div class="col-12"><label class="form-label" for="g-d">Description</label><textarea id="g-d" class="form-control" name="description" rows="3"></textarea></div>
<div class="col-12"><label class="form-label" for="g-file">Fichier *</label><input id="g-file" class="form-control" type="file" name="files[]" accept="<?= e(Files::accept()) ?>" required><div class="form-text"><?= e(Files::hint()) ?></div></div>
<div class="col-12"><button class="btn btn-primary">Déposer le document</button></div></form><?php endif; ?>
