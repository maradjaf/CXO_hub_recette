<div class="page-h"><h1><i class="bi bi-balloon-heart me-2"></i>Félicitations</h1><?php if ($manage): ?><a class="btn btn-outline-primary" href="<?= url('congrats/templates') ?>">Configurer les messages</a><?php endif; ?></div>
<?php foreach ($posts as $p): $ini = mb_strtoupper(mb_substr($p['first_name'], 0, 1) . mb_substr($p['last_name'], 0, 1)); ?>
<div class="cardx mb-3" id="p<?= $p['id'] ?>" style="<?= $p['active'] ? '' : 'opacity:.55' ?>"><div class="d-flex gap-3">
<?php if ($p['photo']): ?><img src="<?= url('congrats/photo/' . $p['employee_id']) ?>" alt="Photo de <?= e($p['first_name'] . ' ' . $p['last_name']) ?>" style="width:96px;height:96px;object-fit:cover;border-radius:50%;border:3px solid var(--yas-yellow)"><?php else: ?><div aria-hidden="true" class="d-flex align-items-center justify-content-center fw-bold" style="width:96px;height:96px;border-radius:50%;background:var(--yas-blue);color:#fff;font-size:30px;border:3px solid var(--yas-yellow)"><?= e($ini) ?></div><?php endif; ?>
<div class="flex-grow-1"><h2 class="h5 mb-1"><?= e($p['title']) ?></h2>
<div class="fw-semibold"><?= e($p['first_name'] . ' ' . $p['last_name']) ?></div>
<div class="small my-1"><span class="text-muted">Ancien poste :</span> <?= e($p['from_position']) ?> <i class="bi bi-arrow-right mx-1"></i> <span class="text-muted">Nouveau poste :</span> <b><?= e($p['to_position']) ?></b></div>
<p class="mb-2"><?= nl2br(e($p['message'])) ?></p>
<div class="small text-muted mb-2"><?= d($p['effective_date']) ?> · <?= (int)$p['n'] ?> félicitation(s)</div>
<?php if ($p['active'] && !$p['mine']): ?><form method="post" action="<?= url('congrats/' . $p['id'] . '/react') ?>" class="d-flex gap-2" data-nomulti><?= csrf_field() ?><input class="form-control form-control-sm" name="message" maxlength="300" placeholder="Un petit mot (facultatif)" aria-label="Un petit mot"><button class="btn btn-sm btn-warning text-nowrap"><i class="bi bi-hand-thumbs-up me-1"></i>Féliciter</button></form>
<?php elseif ($p['mine']): ?><span class="badge text-bg-success">Vous avez félicité</span><?php endif; ?>
<?php if ($p['reacts']): ?><ul class="list-unstyled small mt-2 mb-0"><?php foreach ($p['reacts'] as $r): ?><li><b><?= e($r['name']) ?></b><?= $r['message'] ? ' : ' . e($r['message']) : '' ?></li><?php endforeach; ?></ul><?php endif; ?>
<?php if ($manage): ?><form method="post" action="<?= url('congrats/' . $p['id'] . '/hide') ?>" class="mt-2"><?= csrf_field() ?><button class="btn btn-sm btn-outline-secondary"><?= $p['active'] ? 'Masquer' : 'Réafficher' ?></button></form><?php endif; ?>
</div></div></div><?php endforeach; ?>
<?php if (!$posts): ?><div class="empty"><i class="bi bi-balloon-heart"></i>Aucune mobilité à célébrer pour le moment.</div><?php endif; ?>
