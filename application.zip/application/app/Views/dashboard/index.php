<div class="page-h"><h1>Bonjour <?= e(explode(' ', App\Core\Auth::user()['name'])[0]) ?></h1></div>
<?php require __DIR__ . '/_mydocs.php'; ?>
<?php if (isset($adv)) require __DIR__ . '/_advisor.php'; ?>
<?php if (isset($employees) && $wd['kpi_staff']): ?><div class="row g-3 mb-3">
<div class="col-6 col-lg-3"><div class="kpi"><div class="v"><?= $employees ?></div><div class="l">Collaborateurs actifs</div></div></div>
<div class="col-6 col-lg-3"><div class="kpi"><div class="v"><?= $teams ?></div><div class="l">Équipes</div></div></div>
<div class="col-6 col-lg-3"><div class="kpi"><div class="v"><?= $stores ?></div><div class="l">Stores</div></div></div>
<?php if (isset($events24)): ?><div class="col-6 col-lg-3"><div class="kpi"><div class="v"><?= $users24 ?></div><div class="l">Utilisateurs actifs sur 24 h</div></div></div><?php endif; ?></div><?php endif; ?>
<?php if ($wd['kpi_flags'] && (isset($contractsSoon) || isset($toValidate) || isset($absRate))): ?><div class="row g-3 mb-3">
<?php if (isset($toValidate)): ?><div class="col-6 col-lg-3"><a class="kpi d-block text-decoration-none" href="<?= url('workflow/inbox') ?>"><div class="v"><?= $toValidate ?></div><div class="l">Demandes à valider</div></a></div><?php endif; ?>
<?php if (isset($absRate)): ?><div class="col-6 col-lg-3"><a class="kpi d-block text-decoration-none" href="<?= url('absences/stats') ?>"><div class="v"><?= $absRate ?> %</div><div class="l">Absentéisme du mois</div></a></div><?php endif; ?>
<?php if (isset($contractsSoon)): ?><div class="col-6 col-lg-3"><a class="kpi d-block text-decoration-none" href="<?= url('contracts?status=expiring') ?>"><div class="v"><?= $contractsSoon ?></div><div class="l">Contrats échus ou à échéance sous 30 jours</div></a></div><?php endif; ?></div><?php endif; ?>
<?php if ($wd['ag'] && (isset($ag) || isset($agTeam))): ?><div class="row g-3 mb-3">
<?php if (isset($ag)): ?><div class="col-lg-6"><div class="cardx h-100"><h2>Mon évaluation</h2>
<?php foreach ($ag['todo'] as $x): ?><div class="alert alert-warning py-2 mb-2">Auto-évaluation à remettre : <a class="fw-semibold" href="<?= url('ag/eval/' . $x['id']) ?>"><?= e($x['name']) ?></a> avant le <?= d($x['closes_on']) ?>.</div><?php endforeach; ?>
<?php foreach ($ag['results'] as $x): [$rl, $rk] = App\Core\Ag::rating((int)$x['final_score']); ?><div class="d-flex justify-content-between border-bottom py-1"><a class="text-decoration-none" href="<?= url('ag/eval/' . $x['id']) ?>"><?= e($x['name']) ?></a><span><b><?= (int)$x['final_score'] ?> %</b> <?= badge($rl, $rk) ?></span></div><?php endforeach; ?>
<?php if (!$ag['results'] && !$ag['todo']): ?><div class="text-muted">Aucun résultat d'évaluation pour le moment.</div><?php endif; ?>
<div class="small text-muted mt-2"><a href="<?= url('ag/my') ?>"><?= (int)$ag['obj'] ?> objectif(s) en cours</a><?= $ag['pending'] ? ' · ' . (int)$ag['pending'] . ' en attente de validation' : '' ?></div></div></div><?php endif; ?>
<?php if (isset($agTeam) && ($agTeam['validate'] || $agTeam['review'])): ?><div class="col-lg-6"><div class="cardx h-100"><h2>Mon équipe</h2>
<?php if ($agTeam['validate']): ?><div><a href="<?= url('ag/objectives?status=submitted') ?>"><?= (int)$agTeam['validate'] ?> objectif(s)</a> à valider</div><?php endif; ?>
<?php if ($agTeam['review']): ?><div><a href="<?= url('ag/review') ?>"><?= (int)$agTeam['review'] ?> auto-évaluation(s)</a> à examiner</div><?php endif; ?></div></div><?php endif; ?></div><?php endif; ?>
<?php if ($wd['shortcuts']): ?><div class="row g-3 mb-3"><?php foreach ($shortcuts as [$l, $u, $t]): ?><div class="col-sm-6 col-lg-3"><a class="tile" href="<?= url($u) ?>"><b><?= e($l) ?></b><span><?= e($t) ?></span></a></div><?php endforeach; ?></div><?php endif; ?>
<div class="row g-3">
<?php if (!empty($byTeam) && $wd['by_team']): ?><div class="col-lg-6"><div class="cardx"><h2>Effectif par équipe</h2><?= chart('hbar', array_column($byTeam, 'name'), array_map('intval', array_column($byTeam, 'n'))) ?></div></div><?php endif; ?>
<?php if ($wd['notifs']): ?><div class="col-lg-6"><div class="cardx"><h2>Notifications non lues</h2><?php foreach ($notifs as $n): ?><div class="mb-2"><a class="fw-semibold text-decoration-none" href="<?= url($n['url'] ?: 'notifications') ?>"><?= e($n['title']) ?></a><div class="small text-muted"><?= e($n['body']) ?> · <?= dt($n['created_at']) ?></div></div><?php endforeach; ?>
<?php if (!$notifs): ?><div class="text-muted">Rien de nouveau.</div><?php endif; ?></div></div><?php endif; ?>
<?php if (!empty($recent) && $wd['recent']): ?><div class="col-12"><div class="cardx"><h2>Activité récente</h2><div class="tbl border-0"><table class="table table-sm"><thead><tr><th>Date</th><th>Utilisateur</th><th>Événement</th><th>Page</th><th>Lieu</th></tr></thead><tbody><?php foreach ($recent as $r): ?><tr><td><?= dt($r['created_at']) ?></td><td><?= e($r['user_name']) ?></td><td><?= e($r['event_type']) ?></td><td class="mono text-truncate" style="max-width:260px"><?= e($r['url']) ?></td><td><?= e($r['city'] ?: $r['network']) ?></td></tr><?php endforeach; ?></tbody></table></div></div></div><?php endif; ?>
</div>
