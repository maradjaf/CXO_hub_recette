<?php include __DIR__ . '/_nav.php'; ?>
<div class="page-h"><h1>Importer une bibliothèque de scripts</h1></div>
<?php if ($report): ?><div class="alert alert-<?= $report['dry'] ? 'info' : 'success' ?>"><b><?= $report['dry'] ? 'Simulation (rien n\'a été enregistré)' : 'Import terminé' ?></b> : <?= (int)$report['total'] ?> script(s) lus — <?php $o = []; foreach ($report['n'] as $k => $v) $o[] = "$v $k"; echo e(implode(', ', $o)); ?>.
<?php if ($report['notes']): ?><ul class="mb-0 mt-2"><?php foreach ($report['notes'] as $n): ?><li><?= e($n) ?></li><?php endforeach; ?></ul><?php endif; ?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data" action="<?= url('cs/import') ?>" class="cardx" style="max-width:720px"><?= csrf_field() ?>
<p class="small text-muted">Chargez la bibliothèque exportée (fichier .html) ou un fichier .json. Chaque script est identifié par son numéro source (SC-001…) : un nouvel import <b>met à jour</b> les scripts existants (nouvelle version si le texte change) et <b>ajoute</b> les nouveaux. Rien n'est jamais supprimé. Les variables [Prénom], [date], [heure] et [numéro] deviennent des champs à remplir. Un script signalé « à vérifier » reste en brouillon.</p>
<p><a class="btn btn-sm btn-outline-primary" href="<?= url('cs/import/template') ?>"><i class="bi bi-file-earmark-arrow-down me-1"></i>Télécharger le modèle de fichier</a></p>
<div class="mb-3"><input type="file" name="file" accept=".html,.htm,.json,text/html,application/json" class="form-control" required></div>
<div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="publish" value="1" id="pb" checked><label class="form-check-label" for="pb">Publier directement les nouveaux scripts</label></div>
<div class="form-check mb-3"><input class="form-check-input" type="checkbox" name="dry" value="1" id="dr" checked><label class="form-check-label" for="dr">Simulation seulement</label></div>
<button class="btn btn-primary">Importer</button></form>
