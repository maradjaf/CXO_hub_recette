<div class="page-h"><h1>Enregistrer ce poste</h1><a class="btn btn-outline-primary" href="<?= url('att') ?>">Retour</a></div>
<div class="row g-3"><div class="col-lg-6"><div class="cardx"><h2>Code d'enrôlement</h2>
<?php if ($dev): ?><div class="alert alert-success small">Ce navigateur est déjà enregistré comme poste « <b><?= e($dev['label']) ?></b> ».</div><?php endif; ?>
<p class="small text-muted">L'assistance technique crée le poste dans « Postes de pointage » et vous remet un code à usage unique valable 24 heures. Saisissez-le ici, sur l'ordinateur professionnel concerné et depuis le réseau du site. Adresse vue par le serveur : <span class="mono"><?= e($ip) ?></span>.</p>
<form method="post" action="<?= url('att/enroll') ?>" class="d-flex gap-2"><?= csrf_field() ?><input class="form-control mono text-uppercase" name="code" maxlength="12" autocomplete="off" required placeholder="CODE"><button class="btn btn-primary">Enregistrer</button></form></div></div></div>
