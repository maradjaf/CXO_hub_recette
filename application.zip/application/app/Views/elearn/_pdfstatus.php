<?php $st = \App\Core\ImportDoc::pdfStatus(); $ini = fn($k) => (string)ini_get($k); ?>
<div class="cardx mt-3 small" style="max-width:760px"><b>Import PDF — état du serveur</b>
<?php if ($st['bin']): ?>
<div class="text-success mt-1">✔ <b>pdftotext</b> détecté (<?= e($st['version'] ?: $st['bin']) ?>) : extraction PDF complète, mise en page respectée.</div>
<?php else: ?>
<div class="text-warning mt-1">⚠ <b>pdftotext</b> n'est pas installé (ou non accessible par PHP). L'import fonctionne avec l'extracteur intégré, correct pour les PDF générés par Word/LibreOffice/PowerPoint, mais moins fiable (colonnes, tableaux, polices spéciales). Les PDF <b>scannés</b> (images) ne sont pas lisibles sans OCR.</div>
<details class="mt-2"><summary><b>Que faut-il installer ?</b></summary>
<ul class="mt-2 mb-1">
<li><b>Windows / Laragon</b> : téléchargez « poppler for Windows » (github.com/oschwartz10612/poppler-windows/releases), décompressez dans <code>C:\laragon\bin\poppler</code>, puis soit ajoutez le dossier <code>Library\bin</code> au PATH Windows, soit saisissez le chemin complet de <code>pdftotext.exe</code> dans <i>Admin › Visio, WhatsApp et chat › E-learning › Chemin de pdftotext</i>. Redémarrez Apache/Laragon.</li>
<li><b>Linux (Debian/Ubuntu)</b> : <code>sudo apt install poppler-utils</code> · <b>CentOS/RHEL</b> : <code>sudo dnf install poppler-utils</code> · <b>macOS</b> : <code>brew install poppler</code>.</li>
<li><b>Hébergement mutualisé</b> : demandez à l'hébergeur d'installer poppler-utils ; vérifiez aussi que <code>exec</code> n'est pas dans <code>disable_functions</code> (actuellement : <code><?= e($ini('disable_functions') ?: 'vide') ?></code>).</li>
</ul></details>
<?php endif; ?>
<div class="mt-2 text-muted">Extension PHP <code>zip</code> (Word/PowerPoint) : <?= $st['zip'] ? '✔ active' : '✘ absente — activez <code>extension=zip</code> dans php.ini' ?> · Limites php.ini : upload_max_filesize <code><?= e($ini('upload_max_filesize')) ?></code>, post_max_size <code><?= e($ini('post_max_size')) ?></code>.</div></div>
