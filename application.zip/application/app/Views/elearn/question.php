<div class="page-h"><h1>Question de <?= e($t['uname']) ?></h1><a class="btn btn-light" href="<?= url('elearn/questions') ?>">‹ Toutes les questions</a></div>
<p class="text-muted">Cours : <b><?= e($t['ctitle']) ?></b><?= $t['ltitle'] ? ' · partie : <b>' . e($t['ltitle']) . '</b>' : '' ?></p>
<?php $chatModule = 'el'; $chatId = (int)$t['id']; require __DIR__ . '/../chat/_block.php'; ?>
