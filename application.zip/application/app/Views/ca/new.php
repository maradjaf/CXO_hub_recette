<div class="page-h"><h1>Planifier ou lancer un contrôle N1</h1></div>
<form method="post" action="<?= url('ca/new') ?>" class="cardx" style="max-width:640px"><?= csrf_field() ?>
<label class="form-label">Référentiel</label><select class="form-select mb-2" name="checklist_id" required><option value="">—</option><?php foreach ($checklists as $k): ?><option value="<?= $k['id'] ?>"><?= e($k['name']) ?> (v<?= (int)$k['version'] ?>)</option><?php endforeach; ?></select>
<label class="form-label">Store contrôlé <small class="text-muted">(référentiel « store »)</small></label><select class="form-select mb-2" name="store_id"><option value="">—</option><?php foreach ($stores as $s): ?><option value="<?= $s['id'] ?>"><?= e($s['name']) ?></option><?php endforeach; ?></select>
<label class="form-label">Équipe contrôlée <small class="text-muted">(référentiel « équipe »)</small></label><select class="form-select mb-2" name="team_id"><option value="">—</option><?php foreach ($teams as $t): ?><option value="<?= $t['id'] ?>"><?= e($t['name']) ?></option><?php endforeach; ?></select>
<?php if (can('ca.manage')): ?><label class="form-label">Contrôleur</label><select class="form-select mb-2" name="controller_id"><?php foreach ($controllers as $u): ?><option value="<?= $u['id'] ?>"><?= e($u['name']) ?></option><?php endforeach; ?></select><?php endif; ?>
<label class="form-label">Date prévue</label><input type="date" class="form-control mb-3" name="planned_date" value="<?= date('Y-m-d') ?>">
<button class="btn btn-primary">Créer le contrôle</button></form>
