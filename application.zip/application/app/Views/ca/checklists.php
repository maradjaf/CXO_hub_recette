<?php use App\Core\Ca; ?>
<div class="page-h"><h1>Référentiels de contrôle N1</h1></div>
<div class="row g-3"><div class="col-lg-8"><div class="tbl"><table class="table table-hover"><thead><tr><th>Code</th><th>Nom</th><th>Version</th><th>Périmètre</th><th class="text-end">Points</th><th class="text-end">Contrôles</th><th>Statut</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?><tr><td><?= e($r['code']) ?></td><td><a href="<?= url('ca/checklists/' . $r['id']) ?>"><?= e($r['name']) ?></a></td><td>v<?= (int)$r['version'] ?></td><td><?= ['store' => 'Store', 'team' => 'Équipe', 'support' => 'Fonction support'][$r['subject']] ?? '' ?></td><td class="text-end"><?= (int)$r['ni'] ?></td><td class="text-end"><?= (int)$r['nc'] ?></td><td><?= badge(Ca::CHK[$r['status']] ?? $r['status'], ['draft' => 'secondary', 'active' => 'success', 'archived' => 'dark'][$r['status']] ?? 'secondary') ?></td></tr>
<?php endforeach; if (!$rows): ?><tr><td colspan="7"><div class="empty"><i class="bi bi-card-checklist"></i>Aucun référentiel.</div></td></tr><?php endif; ?></tbody></table></div></div>
<div class="col-lg-4"><form method="post" action="<?= url('ca/checklists') ?>" class="cardx"><?= csrf_field() ?><h2>Nouveau référentiel</h2>
<label class="form-label">Code</label><input class="form-control mb-2" name="code" maxlength="40" required placeholder="STORE-N1">
<label class="form-label">Nom</label><input class="form-control mb-2" name="name" maxlength="150" required>
<label class="form-label">Description</label><textarea class="form-control mb-2" name="description" rows="2" maxlength="500"></textarea>
<label class="form-label">Contrôle porté sur</label><select class="form-select mb-2" name="subject"><option value="store">Un store</option><option value="team">Une équipe</option><option value="support">Une fonction support</option></select>
<label class="form-label">Seuil de conformité (%)</label><input type="number" min="1" max="100" class="form-control mb-3" name="pass_pct" value="80">
<button class="btn btn-primary">Créer</button></form></div></div>
