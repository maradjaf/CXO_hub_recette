<?php use App\Core\Inc; $cur = 'compare'; require __DIR__ . '/_nav.php';
$COL = ['#003A84', '#D72D32', '#E8A400', '#2E9E6B', '#7A4DB3']; $n = count($res); $nf = fn($v, $d = 0) => Inc::nf($v, $d);
$sel = fn($k, $v) => ($shared[$k] ?? '') === (string)$v ? 'selected' : '';
$labels = array_map(fn($r) => $r['P']['label'], $res); $cnt = array_count_values($labels); foreach ($labels as $i => $l) if ($cnt[$l] > 1) $labels[$i] = $l . ' (' . chr(65 + $i) . ')'; $ref = $res[0]['K'];
// Métriques : [clé, libellé, décimales, unité, sens favorable (-1 : plus bas = mieux, 1 : plus haut = mieux, 0 : neutre), fonction de formatage spéciale]
$M = [['n', 'Incidents', 0, '', -1], ['per_day', 'Incidents par jour', 2, '', -1], ['p1p2', 'Incidents P1 / P2', 0, '', -1], ['major', 'Incidents majeurs', 0, '', -1], ['recur_pct', 'Récurrence', 0, ' %', -1],
      ['lost', 'Heures-agent perdues', 1, ' h', -1], ['lost_day', 'Heures-agent perdues par jour ouvré', 1, ' h', -1], ['fte', 'FTE perdus (moyenne)', 2, '', -1], ['loss_pct', 'Capacité perdue', 2, ' %', -1], ['cost', 'Coût de la productivité perdue (' . Inc::set('inc.currency') . ')', 0, '', -1],
      ['mtta', 'Délai moyen de prise en charge', 0, ' min', -1], ['mttr', 'Délai moyen de rétablissement (MTTR)', 0, ' min', -1], ['mttr_p90', 'MTTR – 90e centile', 0, ' min', -1],
      ['sla_ack', 'Prise en charge dans le délai SLA', 1, ' %', 1], ['sla_res', 'Rétablissement dans le délai SLA', 1, ' %', 1],
      ['customers', 'Clients impactés', 0, '', -1], ['calls', 'Appels perdus', 0, '', -1], ['tx', 'Transactions échouées', 0, '', -1], ['revenue', 'Perte de revenus (' . Inc::set('inc.currency') . ')', 0, '', -1]];
$qsShared = http_build_query(array_filter($shared, fn($v) => $v !== ''));
$P = function (array $a) use ($qsShared) { $q = []; foreach ($a as $i => $p) foreach ($p as $k => $v) $q["p[$i][$k]"] = $v; return url('incidents/compare') . '?' . http_build_query($q) . ($qsShared ? '&' . $qsShared : ''); };
$td = fn($o) => date('Y-m-d', strtotime($o)); $today = date('Y-m-d');
$mS = date('Y-m-01'); $mP = date('Y-m-01', strtotime('first day of last month')); $mPe = date('Y-m-t', strtotime($mP));
$wd = (int)date('N'); $wS = date('Y-m-d', strtotime('-' . ($wd - 1) . ' days')); $wP = date('Y-m-d', strtotime($wS . ' -7 days')); $wPe = date('Y-m-d', strtotime($wS . ' -1 day'));
$d30 = date('Y-m-d', strtotime('-29 days'));
$presets = [
  '30 j vs 30 j précédents' => [['label' => '30 derniers jours', 'from' => $d30, 'to' => $today], ['label' => '30 jours précédents', 'from' => date('Y-m-d', strtotime('-59 days')), 'to' => date('Y-m-d', strtotime('-30 days'))]],
  'Mois en cours vs mois précédent' => [['label' => 'Mois en cours', 'from' => $mS, 'to' => $today], ['label' => 'Mois précédent', 'from' => $mP, 'to' => $mPe]],
  'Semaine vs semaine précédente' => [['label' => 'Cette semaine', 'from' => $wS, 'to' => $today], ['label' => 'Semaine précédente', 'from' => $wP, 'to' => $wPe]],
  'Même période, année précédente' => [['label' => '30 derniers jours', 'from' => $d30, 'to' => $today], ['label' => 'Même période N-1', 'from' => date('Y-m-d', strtotime('-1 year', strtotime($d30))), 'to' => date('Y-m-d', strtotime('-1 year'))]],
  'Heures ouvrées vs nuit (30 j)' => [['label' => 'Journée 07h–20h', 'from' => $d30, 'to' => $today, 'h1' => 7, 'h2' => 20], ['label' => 'Nuit 20h–07h', 'from' => $d30, 'to' => $today, 'h1' => 20, 'h2' => 7]],
  'Semaine vs week-end (30 j)' => [['label' => 'Lundi–vendredi', 'from' => $d30, 'to' => $today, 'dow' => '1,2,3,4,5'], ['label' => 'Week-end', 'from' => $d30, 'to' => $today, 'dow' => '6,7']],
];
?>
<div class="page-h"><h1>Comparaison de périodes</h1><a class="btn btn-light" href="<?= url('incidents/dashboard') ?>"><i class="bi bi-arrow-left me-1"></i>Tableau de bord</a></div>
<?php if ($notice): ?><div class="alert alert-warning py-2"><?= e($notice) ?></div><?php endif; ?>
<form method="get" class="cardx mb-3">
 <div class="d-flex flex-wrap gap-1 align-items-center mb-2"><span class="small text-muted me-1">Comparaisons rapides :</span><?php foreach ($presets as $l => $pp): ?><a class="btn btn-sm btn-light" href="<?= $P($pp) ?>"><?= e($l) ?></a><?php endforeach; ?></div>
 <div class="table-responsive"><table class="table table-sm align-middle mb-2" data-nodt><thead><tr><th></th><th>Libellé</th><th>Du</th><th>Au</th><th>Créneau de (h)</th><th>à (h)</th><th>Jours</th></tr></thead><tbody>
 <?php for ($i = 0; $i < 5; $i++): $r = $res[$i]['P'] ?? null; ?>
 <tr><td><span class="badge" style="background:<?= $COL[$i] ?>"><?= chr(65 + $i) ?></span></td>
 <td><input class="form-control form-control-sm" name="p[<?= $i ?>][label]" maxlength="40" value="<?= e($r['label'] ?? '') ?>" placeholder="Période <?= chr(65 + $i) ?>"></td>
 <td><input type="date" class="form-control form-control-sm" name="p[<?= $i ?>][from]" value="<?= e($r['from'] ?? '') ?>"></td>
 <td><input type="date" class="form-control form-control-sm" name="p[<?= $i ?>][to]" value="<?= e($r['to'] ?? '') ?>"></td>
 <td><select class="form-select form-select-sm" name="p[<?= $i ?>][h1]"><option value="">—</option><?php for ($h = 0; $h < 24; $h++): ?><option value="<?= $h ?>" <?= ($r['h1'] ?? '') === (string)$h ? 'selected' : '' ?>><?= sprintf('%02d', $h) ?></option><?php endfor; ?></select></td>
 <td><select class="form-select form-select-sm" name="p[<?= $i ?>][h2]"><option value="">—</option><?php for ($h = 1; $h <= 24; $h++): ?><option value="<?= $h ?>" <?= ($r['h2'] ?? '') === (string)$h ? 'selected' : '' ?>><?= sprintf('%02d', $h) ?></option><?php endfor; ?></select></td>
 <td><select class="form-select form-select-sm" name="p[<?= $i ?>][dow]"><?php foreach ([['', 'Tous les jours'], ['1,2,3,4,5', 'Lundi – vendredi'], ['1,2,3,4,5,6', 'Lundi – samedi'], ['6,7', 'Week-end'], ['7', 'Dimanche']] as [$v, $l]): ?><option value="<?= $v ?>" <?= ($r['dow'] ?? '') === $v ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select></td></tr>
 <?php endfor; ?></tbody></table></div>
 <div class="row g-2 align-items-end">
 <div class="col-md-2"><label class="form-label small mb-0">Famille</label><select class="form-select form-select-sm" name="family"><option value="">Toutes</option><?php foreach (Inc::FAMILIES as $k => $l): ?><option value="<?= $k ?>" <?= $sel('family', $k) ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
 <div class="col-md-3"><label class="form-label small mb-0">Nature d'incident</label><select class="form-select form-select-sm" name="category_id"><option value="">Toutes</option><?php foreach ($cats as $c): ?><option value="<?= $c['id'] ?>" <?= $sel('category_id', $c['id']) ?>><?= e($c['label']) ?></option><?php endforeach; ?></select></div>
 <div class="col-md-2"><label class="form-label small mb-0">Service</label><select class="form-select form-select-sm" name="service"><option value="">Tous</option><?php foreach (Inc::SERVICES as $k => $l): ?><option value="<?= $k ?>" <?= $sel('service', $k) ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
 <div class="col-md-2"><label class="form-label small mb-0">Gravité</label><select class="form-select form-select-sm" name="severity"><option value="">Toutes</option><option value="P12" <?= $sel('severity', 'P12') ?>>P1 + P2</option><?php foreach (Inc::SEV as $k => $l): ?><option value="<?= $k ?>" <?= $sel('severity', $k) ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
 <div class="col-md-2"><label class="form-label small mb-0">Type de panne</label><select class="form-select form-select-sm" name="outage"><option value="">Toutes</option><option value="1" <?= $sel('outage', '1') ?>>Panne totale</option><option value="0" <?= $sel('outage', '0') ?>>Dégradation</option></select></div>
 <div class="col-md-1"><button class="btn btn-primary btn-sm w-100">Comparer</button></div></div>
 <p class="small text-muted mt-2 mb-0">Renseignez 2 à 5 périodes ; la première sert de référence pour les écarts. Le créneau (heure de début de l'incident, de 20 à 7 = nuit) et les jours peuvent être précisés pour chaque période afin, par exemple, de comparer les heures ouvrées à la nuit. Les durées différentes sont ramenées « par jour ».</p>
</form>

<div class="cardx mb-3"><h2>Indicateurs comparés</h2><div class="table-responsive"><table class="table table-sm align-middle mb-0" data-nodt><thead><tr><th>Indicateur</th>
<?php foreach ($res as $i => $r): ?><th class="text-end"><span class="badge" style="background:<?= $COL[$i] ?>"><?= chr(65 + $i) ?></span> <?= e($r['P']['label']) ?><div class="small fw-normal text-muted"><?= d($r['P']['from']) ?> → <?= d($r['P']['to']) ?><?= $r['slot'] !== '' ? '<br>' . e($r['slot']) : '' ?></div></th><?php endforeach; ?></tr></thead><tbody>
<?php foreach ($M as [$k, $l, $dec, $u, $good]): ?><tr><td><?= e($l) ?></td>
<?php foreach ($res as $i => $r): $v = $r['K'][$k] ?? null; $b = $ref[$k] ?? null; ?><td class="text-end"><b><?= $v === null ? '—' : $nf($v, $dec) . $u ?></b>
<?php if ($i > 0 && $v !== null && $b !== null && abs($v - $b) >= 0.0005): $dl = $v - $b; $cls = $good === 0 ? '' : ($dl * $good > 0 ? 'up-good' : 'up-bad'); ?><div class="kd <?= $cls ?>"><?= $dl > 0 ? '▲ +' : '▼ ' ?><?= $nf($dl, $dec) ?><?= $b != 0 ? ' (' . ($dl > 0 ? '+' : '') . $nf($dl / abs($b) * 100) . ' %)' : '' ?></div><?php endif; ?></td><?php endforeach; ?></tr><?php endforeach; ?>
</tbody></table></div><p class="small text-muted mb-0 mt-2">Écarts par rapport à la période A : vert = évolution favorable, rouge = défavorable.</p></div>

<div class="row g-3 mb-3">
<div class="col-md-6 col-xl-3"><div class="cardx h-100"><h2>Incidents par jour</h2><?= chart('bar', $labels, ['Incidents / jour' => array_map(fn($r) => $r['K']['per_day'], $res)], ['pcolors' => array_slice($COL, 0, $n), 'h' => 220]) ?></div></div>
<div class="col-md-6 col-xl-3"><div class="cardx h-100"><h2>Heures perdues par jour ouvré</h2><?= chart('bar', $labels, ['Heures-agent / jour' => array_map(fn($r) => $r['K']['lost_day'], $res)], ['pcolors' => array_slice($COL, 0, $n), 'h' => 220]) ?></div></div>
<div class="col-md-6 col-xl-3"><div class="cardx h-100"><h2>MTTR (heures)</h2><?= chart('bar', $labels, ['MTTR' => array_map(fn($r) => $r['K']['mttr'] === null ? null : $r['K']['mttr'] / 60, $res)], ['pcolors' => array_slice($COL, 0, $n), 'h' => 220]) ?></div></div>
<div class="col-md-6 col-xl-3"><div class="cardx h-100"><h2>Rétablissement dans le SLA (%)</h2><?= chart('bar', $labels, ['SLA' => array_map(fn($r) => $r['K']['sla_res'], $res)], ['pcolors' => array_slice($COL, 0, $n), 'max' => 100, 'h' => 220]) ?></div></div>
<div class="col-12"><div class="cardx"><h2>Profil horaire — incidents par jour selon l'heure de début</h2><?php $hs = []; foreach ($res as $i => $r) $hs[$labels[$i]] = array_map(fn($x) => $x / $r['K']['cal'], $r['hour']); echo chart('line', array_map(fn($h) => sprintf('%02dh', $h), range(0, 23)), $hs, ['colors' => $COL, 'h' => 280]); ?></div></div>
<div class="col-lg-6"><div class="cardx h-100"><h2>Par famille — incidents par jour</h2><?php $fk = []; foreach ($res as $r) foreach ($r['fam'] as $k => $_) $fk[$k] = 1; $fk = array_keys($fk); $fs = []; foreach ($res as $i => $r) $fs[$labels[$i]] = array_map(fn($k) => ($r['fam'][$k] ?? 0) / $r['K']['cal'], $fk);
 echo $fk ? chart('bar', array_map(fn($k) => Inc::FAMILIES[$k] ?? $k, $fk), $fs, ['colors' => $COL, 'h' => 280]) : '<p class="text-muted small">Aucune donnée.</p>'; ?></div></div>
<div class="col-lg-3"><div class="cardx h-100"><h2>Par gravité — par jour</h2><?php $ss = []; foreach ($res as $i => $r) $ss[$labels[$i]] = array_map(fn($x) => $x / $r['K']['cal'], array_values($r['sev'])); echo chart('bar', array_keys($res[0]['sev']), $ss, ['colors' => $COL, 'h' => 280]); ?></div></div>
<div class="col-lg-3"><div class="cardx h-100"><h2>Par jour de semaine</h2><?php $ws = []; foreach ($res as $i => $r) $ws[$labels[$i]] = array_values($r['wd']); echo chart('bar', ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'], $ws, ['colors' => $COL, 'h' => 280]); ?><p class="small text-muted mb-0">Nombre d'incidents sur la période.</p></div></div>
</div>
<div class="cardx"><h2>Causes racines confirmées</h2><div class="table-responsive"><table class="table table-sm mb-0" data-nodt><thead><tr><th>Cause</th><?php foreach ($res as $i => $r): ?><th class="text-end"><?= chr(65 + $i) ?> · <?= e($r['P']['label']) ?></th><?php endforeach; ?></tr></thead><tbody>
<?php $rk = []; foreach ($res as $r) foreach ($r['root'] as $k => $_) $rk[$k] = ($rk[$k] ?? 0) + $_; arsort($rk); foreach ($rk as $k => $_): ?><tr><td><?= e(Inc::ROOT[$k] ?? $k) ?></td><?php foreach ($res as $r): ?><td class="text-end"><?= (int)($r['root'][$k] ?? 0) ?></td><?php endforeach; ?></tr><?php endforeach; if (!$rk): ?><tr><td colspan="<?= $n + 1 ?>" class="text-muted">Aucun post-mortem finalisé sur ces périodes.</td></tr><?php endif; ?></tbody></table></div></div>
