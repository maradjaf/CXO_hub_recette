<?php use App\Core\Files; $canAdd = \App\Controllers\IncFilesController::canAdd($i); $isSup = !can('inc.declare');
$base = $isSup ? 'support/incidents/' . $i['id'] . '/files' : 'incidents/' . $i['id'] . '/files'; ?>
<div class="cardx mb-3" id="pj"><h2>Pièces jointes <span class="badge text-bg-light"><?= count($files) ?></span></h2>
<?php if ($files): ?><ul class="list-unstyled mb-2"><?php foreach ($files as $f): ?>
<li class="d-flex align-items-center gap-2 py-1 border-bottom"><i class="bi <?= e(Files::icon($f['original_name'])) ?> fs-5"></i>
<div class="flex-grow-1"><a href="<?= url('incfiles/' . $f['id']) ?>"><?= e($f['original_name']) ?></a><div class="small text-muted"><?= e(Files::size((int)$f['size'])) ?> · <?= e($f['user_name'] ?: '—') ?> · <?= dt($f['created_at']) ?></div></div>
<?php if (can('inc.manage') || (int)$f['user_id'] === (int)\App\Core\Auth::id()): ?><form method="post" action="<?= url('incfiles/' . $f['id'] . '/delete') ?>" onsubmit="return confirm('Supprimer cette pièce jointe ?')"><?= csrf_field() ?><button class="btn btn-sm btn-outline-danger" title="Supprimer"><i class="bi bi-trash"></i></button></form><?php endif; ?></li>
<?php endforeach; ?></ul><?php else: ?><p class="text-muted small mb-2">Aucune pièce jointe.</p><?php endif; ?>
<?php if ($canAdd): ?><form method="post" enctype="multipart/form-data" action="<?= url($base) ?>" class="row g-2"><?= csrf_field() ?>
<div class="col-md-9"><input type="file" class="form-control form-control-sm" name="files[]" multiple accept="<?= e(Files::accept()) ?>"><div class="form-text"><?= e(Files::hint()) ?></div></div>
<div class="col-md-3"><button class="btn btn-outline-primary btn-sm w-100"><i class="bi bi-paperclip me-1"></i>Joindre</button></div></form><?php endif; ?></div>
