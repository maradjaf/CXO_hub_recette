<?php /** Zone de dessin de la signature : remplit le champ caché « pad ». Variables : $pad (image existante ou null). */ $cid = 'sg' . bin2hex(random_bytes(3)); ?>
<div class="mb-2"><?php if (!empty($pad)): ?><div class="small text-muted mb-1">Votre signature enregistrée :</div><img src="<?= e($pad) ?>" alt="Signature" style="height:60px;border:1px dashed #bbb;border-radius:6px;background:#fff;padding:2px"><details class="mt-1"><summary class="small">Redessiner ma signature</summary><?php endif; ?>
<canvas id="<?= $cid ?>" width="420" height="130" style="border:1px dashed #888;border-radius:6px;background:#fff;touch-action:none;max-width:100%"></canvas><div><button type="button" class="btn btn-link btn-sm p-0" data-clear="<?= $cid ?>">Effacer</button> <span class="small text-muted">Signez dans le cadre (souris ou doigt).</span></div>
<?php if (!empty($pad)): ?></details><?php endif; ?><input type="hidden" name="pad" id="<?= $cid ?>v"></div>
<script>(function(){var c=document.getElementById('<?= $cid ?>'),v=document.getElementById('<?= $cid ?>v'),x=c.getContext('2d'),d=false,used=false;x.lineWidth=2.2;x.lineCap='round';x.strokeStyle='#0b2a6b';
function p(e){var r=c.getBoundingClientRect();return[(e.clientX-r.left)*c.width/r.width,(e.clientY-r.top)*c.height/r.height];}
c.addEventListener('pointerdown',function(e){d=true;var q=p(e);x.beginPath();x.moveTo(q[0],q[1]);c.setPointerCapture(e.pointerId);});
c.addEventListener('pointermove',function(e){if(!d)return;var q=p(e);x.lineTo(q[0],q[1]);x.stroke();used=true;});
function up(){if(d&&used)v.value=c.toDataURL('image/png');d=false;}c.addEventListener('pointerup',up);c.addEventListener('pointerleave',up);
document.querySelector('[data-clear="<?= $cid ?>"]').addEventListener('click',function(){x.clearRect(0,0,c.width,c.height);v.value='';used=false;});})();</script>
