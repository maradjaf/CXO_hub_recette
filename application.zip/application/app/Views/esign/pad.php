<div class="page-h"><h1>Ma signature</h1></div>
<div class="cardx" style="max-width:520px"><p class="small text-muted">Cette signature est apposée sur les notes de service et mémos que vous visez ou signez. Chaque signature reste confirmée par votre mot de passe.</p>
<form method="post" action="<?= url('esign/pad') ?>"><?= csrf_field() ?><?php require __DIR__ . '/_canvas.php'; ?><button class="btn btn-primary">Enregistrer ma signature</button></form></div>
