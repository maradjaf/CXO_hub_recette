<?php /** Formulaire de visa / signature. Variables : $action (URL), $mine (ligne esign), $pad, $needPad (bool), $okLabel. */ ?>
<div class="cardx mb-3 border border-primary"><h2><i class="bi bi-pen me-1"></i><?= e($okLabel) ?> · <?= e($mine['role']) ?></h2>
<form method="post" action="<?= $action ?>"><?= csrf_field() ?>
<?php $pad = $pad ?? null; require __DIR__ . '/_canvas.php'; ?>
<?php if ($needPad && !$pad): ?><div class="small text-muted mb-2">Votre signature dessinée est obligatoire pour signer ; elle sera conservée pour les prochaines fois.</div><?php endif; ?>
<label class="form-label small mb-0">Commentaire (obligatoire en cas de refus)</label><textarea class="form-control mb-2" name="comment" rows="2" maxlength="500"></textarea>
<label class="form-label small mb-0 req">Votre mot de passe (confirmation)</label><input type="password" class="form-control mb-2" name="password" required autocomplete="current-password">
<div class="d-flex gap-2"><button class="btn btn-success" name="decision" value="ok"><i class="bi bi-check2-circle me-1"></i><?= e($okLabel) ?></button><button class="btn btn-outline-danger" name="decision" value="no" data-confirm="Refuser ce document ? Il retournera à son rédacteur.">Refuser</button></div>
<div class="form-text">Signature électronique simple : votre identité est confirmée par votre mot de passe ; la date, l'empreinte du document et votre adresse IP sont enregistrées.</div></form></div>
