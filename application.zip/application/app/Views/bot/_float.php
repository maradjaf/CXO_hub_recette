<?php /* Assistant flottant (Lot 53) : bouton + fenêtre de discussion, réponses via POST /bot/send (ajax=1). */ ?>
<button type="button" id="cbFab" aria-label="Ouvrir l'assistant virtuel" title="Assistant virtuel"><i class="bi bi-chat-dots-fill"></i></button>
<div id="cbBox" role="dialog" aria-label="Assistant virtuel">
  <div class="cb-h"><i class="bi bi-robot"></i><span class="cb-t">Assistant virtuel</span><a href="<?= url('bot') ?>" title="Ouvrir en pleine page"><i class="bi bi-arrows-fullscreen"></i></a><button type="button" id="cbNew" title="Nouvelle conversation"><i class="bi bi-plus-circle"></i></button><button type="button" id="cbX" title="Fermer"><i class="bi bi-x-lg"></i></button></div>
  <div id="cbLog" aria-live="polite"></div>
  <form id="cbForm" autocomplete="off"><input name="q" maxlength="500" placeholder="Écrivez votre question…" required><button type="submit" aria-label="Envoyer"><i class="bi bi-send-fill"></i></button></form>
</div>
<script>
(function(){
  var W=<?= json_encode("Bonjour, je suis l'assistant virtuel. En quoi puis je vous aider aujourd'hui ?", JSON_UNESCAPED_UNICODE) ?>;
  var U=<?= json_encode(url('bot/send')) ?>,T=<?= json_encode(\App\Core\Csrf::token()) ?>,K='cxo_cb_'+<?= (int)\App\Core\Auth::id() ?>;
  var fab=document.getElementById('cbFab'),box=document.getElementById('cbBox'),log=document.getElementById('cbLog'),f=document.getElementById('cbForm'),inp=f.q,busy=false,cid=0,hist=[];
  function save(){try{sessionStorage.setItem(K,JSON.stringify({c:cid,h:hist.slice(-40),o:box.classList.contains('on')?1:0}));}catch(e){}}
  function add(role,text,extra){var d=document.createElement('div');d.className='m '+(role==='u'?'u':'b');d.appendChild(document.createTextNode(text));
    if(extra){if(extra.sources&&extra.sources.length){var s=document.createElement('div');s.className='src';s.appendChild(document.createTextNode('Sources : '));extra.sources.forEach(function(x,i){var a=document.createElement('a');a.href=x.url;a.textContent=x.title;if(i)s.appendChild(document.createTextNode(' · '));s.appendChild(a);});d.appendChild(s);}
      if(extra.ticket||extra.kb){var s2=document.createElement('div');s2.className='src';if(extra.ticket){var a=document.createElement('a');a.href=extra.ticket;a.textContent='Créer un ticket d’assistance';s2.appendChild(a);}if(extra.kb){if(extra.ticket)s2.appendChild(document.createTextNode(' · '));var b=document.createElement('a');b.href=extra.kb;b.textContent='Parcourir la base de connaissances';s2.appendChild(b);}d.appendChild(s2);}}
    log.appendChild(d);log.scrollTop=log.scrollHeight;return d;}
  function render(){log.innerHTML='';add('b',W);hist.forEach(function(h){add(h.r,h.t,h.x);});}
  function open(on){box.classList.toggle('on',on);fab.setAttribute('aria-expanded',on?'true':'false');if(on){log.scrollTop=log.scrollHeight;setTimeout(function(){inp.focus();},50);}save();}
  try{var st=JSON.parse(sessionStorage.getItem(K)||'null');if(st){cid=st.c||0;hist=st.h||[];}}catch(e){}
  render();
  try{if(st&&st.o)open(true);}catch(e){}
  fab.addEventListener('click',function(){open(!box.classList.contains('on'));});
  document.getElementById('cbX').addEventListener('click',function(){open(false);});
  document.getElementById('cbNew').addEventListener('click',function(){cid=0;hist=[];render();save();inp.focus();});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&box.classList.contains('on'))open(false);});
  f.addEventListener('submit',function(e){e.preventDefault();var q=inp.value.trim();if(!q||busy)return;busy=true;inp.value='';add('u',q);hist.push({r:'u',t:q});
    var w=add('b','');w.innerHTML='<span class="dots"><span></span><span></span><span></span></span>';
    var fd=new FormData();fd.append('_csrf',T);fd.append('ajax','1');fd.append('q',q);fd.append('c',cid);
    fetch(U,{method:'POST',body:fd,credentials:'same-origin',headers:{'X-Requested-With':'fetch','Accept':'application/json'}}).then(function(r){return r.json();}).then(function(j){
      w.remove();if(j.ok){cid=j.c;var x={sources:j.sources,ticket:j.ticket,kb:j.kb};add('b',j.text,x);hist.push({r:'b',t:j.text,x:x});}
      else{add('b',j.error||'Une erreur est survenue.');hist.pop();}
    }).catch(function(){w.remove();add('b','Le service est momentanément indisponible. Réessayez dans un instant.');}).then(function(){busy=false;save();inp.focus();});});
})();
</script>
