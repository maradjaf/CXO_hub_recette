<?php $err = $_SESSION['_err'] ?? []; ?>
<div class="page-h"><h1><?= e($title) ?> · <?= e($c['name']) ?></h1><a class="btn btn-outline-secondary" href="<?= url('forum/c/' . $c['id']) ?>">Retour</a></div>
<?php foreach ($err as $m): ?><div class="alert alert-danger py-2"><?= e($m) ?></div><?php endforeach; ?>
<form method="post" action="<?= url('forum/topics') ?>" class="cardx row g-3" style="max-width:900px"><?= csrf_field() ?><input type="hidden" name="category_id" value="<?= (int)$c['id'] ?>">
<div class="col-12"><label class="form-label req" for="t-t">Titre</label><input id="t-t" class="form-control" name="title" maxlength="190" required value="<?= e(old('title')) ?>"></div>
<div class="col-12"><label class="form-label req" for="t-b">Message</label><textarea id="t-b" class="form-control" name="body" rows="8" required data-wysiwyg><?= e(\App\Core\Html::forEditor(old('body'))) ?></textarea></div>
<div class="col-12"><button class="btn btn-primary">Publier</button></div></form>
<?php unset($_SESSION['_err'], $_SESSION['_old']); ?>
