<div class="page-h"><h1><?= e($title) ?></h1><a class="btn btn-outline-secondary" href="<?= url('forum') ?>">Forum</a></div>
<form class="filters row g-2" method="get"><div class="col-md-6"><input class="form-control" name="q" minlength="2" placeholder="Mot ou expression" value="<?= e($q) ?>"></div><div class="col-md-1"><button class="btn btn-primary w-100">OK</button></div></form>
<div class="tbl"><table class="table table-hover"><thead><tr><th>Sujet</th><th>Catégorie</th><th>Auteur</th><th>Dernier message</th></tr></thead><tbody>
<?php foreach ($p['rows'] as $t): ?><tr><td><a class="fw-semibold text-decoration-none" href="<?= url('forum/t/' . $t['id']) ?>"><?= e($t['title']) ?></a></td><td><?= e($t['cname']) ?></td><td><?= e($t['author']) ?></td><td><?= dt($t['last_post_at']) ?></td></tr><?php endforeach; ?>
<?php if (!$p['rows']): ?><tr><td colspan="4"><div class="empty"><?= mb_strlen($q) < 2 ? 'Saisissez au moins 2 caractères.' : 'Aucun résultat.' ?></div></td></tr><?php endif; ?></tbody></table></div>
<?php require __DIR__ . '/../layout/pager.php'; ?>
