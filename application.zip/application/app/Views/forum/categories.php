<?php $err = $_SESSION['_err'] ?? []; ?>
<div class="page-h"><h1><?= e($title) ?></h1><a class="btn btn-outline-secondary" href="<?= url('forum') ?>">Forum</a></div>
<?php foreach ($err as $m): ?><div class="alert alert-danger py-2"><?= e($m) ?></div><?php endforeach; ?>
<?php foreach (array_merge($cats, [['id' => 0, 'name' => '', 'description' => '', 'sort_order' => count($cats) + 1, 'staff_only' => 0, 'active' => 1, 'n' => 0]]) as $c): ?>
<form method="post" action="<?= url('forum/categories') ?>" class="cardx row g-2 mb-2 align-items-end"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
<div class="col-md-3"><label class="form-label small"><?= $c['id'] ? 'Nom' : 'Nouvelle catégorie' ?></label><input class="form-control form-control-sm" name="name" maxlength="120" required value="<?= e($c['name']) ?>"></div>
<div class="col-md-4"><label class="form-label small">Description</label><input class="form-control form-control-sm" name="description" maxlength="300" value="<?= e($c['description']) ?>"></div>
<div class="col-md-1"><label class="form-label small">Ordre</label><input type="number" class="form-control form-control-sm" name="sort_order" value="<?= (int)$c['sort_order'] ?>"></div>
<div class="col-md-2 small"><label class="form-check"><input type="checkbox" class="form-check-input" name="staff_only" value="1" <?= $c['staff_only'] ? 'checked' : '' ?>> Annonces (modérateurs)</label><?php if ($c['id']): ?><label class="form-check"><input type="checkbox" class="form-check-input" name="active" value="1" <?= $c['active'] ? 'checked' : '' ?>> Visible</label><?php endif; ?></div>
<div class="col-md-2"><button class="btn btn-sm btn-primary"><?= $c['id'] ? 'Enregistrer' : 'Ajouter' ?></button><?= $c['id'] ? ' <span class="small text-muted">' . (int)$c['n'] . ' sujet(s)</span>' : '' ?></div></form><?php endforeach; ?>
<?php unset($_SESSION['_err'], $_SESSION['_old']); ?>
