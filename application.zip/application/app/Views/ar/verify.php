<div class="container py-4" style="max-width:700px"><h1 class="h3">Vérification d'une attestation</h1>
<?php if (!$r): ?><div class="alert alert-danger">Aucune attestation délivrée ne correspond au code « <?= e($code) ?> ».</div>
<?php else: ?><div class="alert alert-success"><b>Attestation authentique.</b> <?= e($r['title']) ?> délivrée le <?= dt($r['issued_at']) ?> à <?= e($r['first_name'] . ' ' . mb_substr($r['last_name'], 0, 1) . '.') ?></div>
<table class="table table-sm"><tbody><tr><th>Signée par</th><td><?= e($r['signed_by']) ?> <?= $r['signed_title'] ? '(' . e($r['signed_title']) . ')' : '' ?></td></tr><tr><th>Empreinte</th><td class="mono small"><?= e(substr((string)$r['doc_hash'], 0, 32)) ?>…</td></tr></tbody></table><?php endif; ?></div>
