<?php use App\Core\Cs; $tab = 'list'; ?>
<div class="page-h"><h1><code><?= e($k['code']) ?></code> <?= e($k['label']) ?></h1><div class="d-flex gap-2"><?php if (can('eoc.manage')): ?><a class="btn btn-primary" href="<?= url('eoc/' . (int)$k['id'] . '/edit') ?>">Modifier</a>
<form method="post" action="<?= url('eoc/' . (int)$k['id'] . '/delete') ?>" onsubmit="return confirm('Supprimer ce code ?')"><?= csrf_field() ?><button class="btn btn-outline-danger">Supprimer</button></form><?php endif; ?></div></div>
<?php require __DIR__ . '/_nav.php'; ?>
<div class="row g-3"><div class="col-lg-7"><div class="cardx"><h2>Fiche</h2><dl class="row mb-0">
<dt class="col-sm-4">Catégorie</dt><dd class="col-sm-8"><?= e(Cs::CAT[$k['category']] ?? '') ?></dd>
<dt class="col-sm-4">État</dt><dd class="col-sm-8"><?= $k['active'] ? '<span class="badge text-bg-success">Actif</span>' : '<span class="badge text-bg-secondary">Inactif</span>' ?></dd>
<dt class="col-sm-4">Résolu au 1er contact</dt><dd class="col-sm-8"><?= $k['counts_fcr'] ? 'Oui' : 'Non' ?></dd>
<dt class="col-sm-4">Commentaire exigé</dt><dd class="col-sm-8"><?= $k['needs_note'] ? 'Oui' : 'Non' ?></dd>
<dt class="col-sm-4">Rappel à planifier</dt><dd class="col-sm-8"><?= $k['needs_callback'] ? 'Oui' : 'Non' ?></dd>
<dt class="col-sm-4">ACW cible</dt><dd class="col-sm-8"><?= $k['acw_target_sec'] ? (int)$k['acw_target_sec'] . ' s' : '—' ?></dd>
<dt class="col-sm-4">Script de clôture</dt><dd class="col-sm-8"><?= $k['script'] ? '<a href="' . url('cs/' . (int)$k['closing_script_id']) . '">' . e($k['sref'] . ' ' . $k['script']) . '</a>' : '—' ?></dd>
<dt class="col-sm-4">Quand l'utiliser</dt><dd class="col-sm-8"><?= nl2br(e($k['description'] ?: '—')) ?></dd></dl></div></div>
<div class="col-lg-5"><div class="row g-3 mb-3"><div class="col-6"><div class="kpi"><div class="v"><?= (int)$use['n'] ?></div><div class="l">Fois posé</div></div></div><div class="col-6"><div class="kpi"><div class="v"><?= $use['acw'] !== null ? round($use['acw']) . ' s' : '—' ?></div><div class="l">ACW moyen</div></div></div>
<div class="col-6"><div class="kpi"><div class="v"><?= (int)$use['wrong'] ?></div><div class="l">Posé à tort</div></div></div><div class="col-6"><div class="kpi"><div class="v"><?= (int)$missed ?></div><div class="l">Attendu mais non posé</div></div></div></div>
<?php if ($recent): ?><div class="cardx"><h2>Derniers contrôles</h2><?php foreach ($recent as $r): ?><div class="d-flex justify-content-between small py-1"><a href="<?= url('cs/checks/' . (int)$r['id']) ?>"><?= e($r['first_name'] . ' ' . $r['last_name']) ?></a><span class="text-muted"><?= e(substr($r['created_at'], 0, 10)) ?></span></div><?php endforeach; ?></div><?php endif; ?></div></div>
