<?php $tab = 'import'; ?>
<div class="page-h"><h1>Importer des codes de fin d'appel</h1></div>
<?php require __DIR__ . '/_nav.php'; ?>
<form method="post" action="<?= url('eoc/import') ?>" enctype="multipart/form-data" class="cardx"><?= csrf_field() ?>
<p>Fichier CSV (séparateur « ; » ou « , »). Colonnes : <code>code</code> et <code>libelle</code> obligatoires ; facultatives : <code>categorie</code>, <code>fcr</code>, <code>commentaire_exige</code>, <code>rappel</code>, <code>acw_cible_sec</code>, <code>couleur</code>, <code>ordre</code>, <code>actif</code>, <code>description</code>. Un code existant est mis à jour. Le plus simple : <a href="<?= url('eoc?export=csv') ?>">exporter</a> le fichier actuel, le modifier, puis le ré-importer.</p>
<p><a class="btn btn-sm btn-outline-primary" href="<?= url('eoc/import/template') ?>"><i class="bi bi-file-earmark-arrow-down me-1"></i>Télécharger le modèle de fichier</a></p>
<div class="mb-3"><input type="file" name="file" accept=".csv,text/csv" class="form-control" required></div>
<label class="form-check mb-3"><input class="form-check-input" type="checkbox" name="apply" value="1"> Appliquer réellement (sinon, simple simulation)</label>
<button class="btn btn-primary">Importer</button></form>
