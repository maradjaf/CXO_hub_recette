<?php use App\Core\Cs; $tab = 'new'; $v = fn($f, $d = '') => $_SESSION['_old'][$f] ?? ($k[$f] ?? $d); $ch = fn($f, $d = 0) => (isset($_SESSION['_old']) ? !empty($_SESSION['_old'][$f]) : (isset($k[$f]) ? !empty($k[$f]) : (bool)$d)); $isNew = empty($k['id']); ?>
<div class="page-h"><h1><?= e($title) ?></h1></div>
<?php require __DIR__ . '/_nav.php'; ?>
<form method="post" action="<?= url($isNew ? 'eoc' : 'eoc/' . (int)$k['id']) ?>" class="cardx row g-3"><?= csrf_field() ?>
<div class="col-md-3"><label class="form-label req">Code</label><input name="code" class="form-control" maxlength="40" required value="<?= e($v('code')) ?>"></div>
<div class="col-md-5"><label class="form-label req">Libellé</label><input name="label" class="form-control" maxlength="150" required value="<?= e($v('label')) ?>"></div>
<div class="col-md-4"><label class="form-label">Catégorie</label><select name="category" class="form-select"><?php foreach (Cs::CAT as $c => $l): ?><option value="<?= $c ?>" <?= $v('category', 'resolved') === $c ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select></div>
<div class="col-md-5"><label class="form-label">Script de clôture</label><select name="closing_script_id" class="form-select"><option value="">—</option><?php foreach ($scripts as $s): ?><option value="<?= (int)$s['id'] ?>" <?= (int)$v('closing_script_id', 0) === (int)$s['id'] ? 'selected' : '' ?>><?= e($s['ref'] . ' ' . mb_substr($s['title'], 0, 50)) ?></option><?php endforeach; ?></select></div>
<div class="col-md-2"><label class="form-label">ACW cible (s)</label><input name="acw_target_sec" class="form-control" value="<?= e($v('acw_target_sec')) ?>"></div>
<div class="col-md-3"><label class="form-label">Couleur</label><input name="color" class="form-control" maxlength="20" placeholder="#2E8B57" value="<?= e($v('color')) ?>"></div>
<div class="col-md-2"><label class="form-label">Ordre</label><input name="sort_order" class="form-control" value="<?= e($v('sort_order', 0)) ?>"></div>
<div class="col-12"><label class="form-label">Quand utiliser ce code</label><textarea name="description" rows="2" maxlength="300" class="form-control"><?= e($v('description')) ?></textarea></div>
<div class="col-12 d-flex flex-wrap gap-4">
<label class="form-check"><input class="form-check-input" type="checkbox" name="counts_fcr" value="1" <?= $ch('counts_fcr', 1) ? 'checked' : '' ?>> Compte comme résolu au 1er contact</label>
<label class="form-check"><input class="form-check-input" type="checkbox" name="needs_note" value="1" <?= $ch('needs_note') ? 'checked' : '' ?>> Commentaire exigé</label>
<label class="form-check"><input class="form-check-input" type="checkbox" name="needs_callback" value="1" <?= $ch('needs_callback') ? 'checked' : '' ?>> Rappel à planifier</label>
<?php if (!$isNew): ?><label class="form-check"><input class="form-check-input" type="checkbox" name="active" value="1" <?= $ch('active', 1) ? 'checked' : '' ?>> Actif</label><?php endif; ?></div>
<div class="col-12"><button class="btn btn-primary">Enregistrer</button> <a class="btn btn-light" href="<?= url('eoc') ?>">Annuler</a></div></form>
<?php unset($_SESSION['_old']); ?>
