<?php $err = $_SESSION['_err'] ?? []; $cp = (int)($_GET['copy'] ?? old('copy_from', 0)); ?>
<div class="page-h"><h1><?= e($title) ?></h1><a class="btn btn-outline-secondary" href="<?= url('admin/roles') ?>">Retour</a></div>
<?php foreach ($err as $m): ?><div class="alert alert-danger py-2"><?= e($m) ?></div><?php endforeach; ?>
<form method="post" action="<?= url('admin/roles') ?>" class="cardx row g-3" style="max-width:760px"><?= csrf_field() ?>
<div class="col-md-7"><label class="form-label req" for="r-n">Nom du rôle</label><input id="r-n" class="form-control" name="name" maxlength="120" required value="<?= e(old('name')) ?>" placeholder="Ex. Superviseur de plateau"></div>
<div class="col-md-5"><label class="form-label" for="r-c">Code (facultatif)</label><input id="r-c" class="form-control mono" name="code" maxlength="60" value="<?= e(old('code')) ?>" placeholder="généré depuis le nom"></div>
<div class="col-12"><label class="form-label" for="r-d">Description</label><input id="r-d" class="form-control" name="description" maxlength="255" value="<?= e(old('description')) ?>"></div>
<div class="col-md-7"><label class="form-label" for="r-f">Reprendre les droits du rôle</label><select id="r-f" class="form-select" name="copy_from"><option value="">— Aucun droit au départ —</option><?php foreach ($roles as $x): ?><option value="<?= (int)$x['id'] ?>" <?= $cp === (int)$x['id'] ? 'selected' : '' ?>><?= e($x['name']) ?></option><?php endforeach; ?></select></div>
<div class="col-12"><button class="btn btn-primary">Créer le rôle</button><div class="form-text">Vous choisirez ensuite les modules, sous-modules et droits détaillés.</div></div></form>
<?php unset($_SESSION['_err'], $_SESSION['_old']); ?>
