<div class="page-h"><h1>Administration</h1></div>
<div class="row g-3"><?php foreach ($cards as [$l, $u, $perm, $t]): ?><div class="col-sm-6 col-lg-4"><a class="tile" href="<?= url($u) ?>"><b><?= e($l) ?></b><span><?= e($t) ?></span></a></div><?php endforeach; ?></div>
