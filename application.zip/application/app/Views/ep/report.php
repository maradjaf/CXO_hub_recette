<?php use App\Core\{Rp, Ep}; require __DIR__ . '/../pj/_report_css.php'; echo Rp::css(); Rp::reset(); $per = 'p' . (int)$plan['id']; $back = 'ep/' . (int)$plan['id'] . '/report' . ($act !== '' ? '?activity=' . urlencode($act) : '');
$xtra = '<form method="get" class="d-flex gap-2"><select name="activity" class="form-select form-select-sm" style="width:260px" onchange="this.form.submit()"><option value="">Toutes les activités</option>' . implode('', array_map(fn($a) => '<option' . ($a === $act ? ' selected' : '') . '>' . e($a) . '</option>', $acts)) . '</select></form>';
echo Rp::bar($title, url('ep/' . $plan['id']), $xtra);
$tot = 0; $sm = 0; $cnt = array_fill_keys(array_keys(Ep::ST), 0); foreach ($sum as $a => $s) { if ($act !== '' && $a !== $act) continue; $tot += $s['n']; $sm += $s['sum']; foreach ($s['st'] as $k => $n) $cnt[$k] += $n; } $avg = $tot ? (int)round($sm / $tot) : 0; ?>
<?= Rp::open('Execution plan — ' . $plan['period_label'], 'Direction CX & Opérations · ' . ($act !== '' ? $act : 'Toutes les activités') . ' · bilan au ' . d($plan['end_date'])) ?>
<div class="kcs"><?= Rp::kpi($avg . ' %', 'Taux d\'atteinte moyen', $tot . ' programme(s)', true) ?><?= Rp::kpi((string)$cnt['done'], 'Terminés') ?><?= Rp::kpi((string)$cnt['in_progress'], 'En cours') ?><?= Rp::kpi((string)($cnt['at_risk'] + $cnt['delayed']), 'À risque / en retard', $cnt['at_risk'] . ' à risque · ' . $cnt['delayed'] . ' en retard') ?></div>
<?php $t = []; foreach ($sum as $a => $s) { if ($act !== '' && $a !== $act) continue; $t[] = [$a, $s['n'], $s['avg'] . ' %', $s['st']['done'], $s['st']['in_progress'], $s['st']['at_risk'], $s['st']['delayed']]; } echo Rp::table(['Activité', 'Programmes', 'Taux moyen', 'Terminés', 'En cours', 'À risque', 'En retard'], $t, [1, 2, 3, 4, 5, 6]); ?>
<?= Rp::note('ep', $per, 'synth' . ($act !== '' ? '' : ''), 'Synthèse', $edit, $back, 'À rédiger par le responsable du plan.') ?>
<?= Rp::close() ?>
<?php $wt = fn($r) => 2 + array_sum(array_map(fn($i) => 1 + count($i['subs']) + (int)ceil(strlen(implode(' ', array_column($i['subs'], 'comment'))) / 110), $r['inis']));
foreach ($by as $a => $rows): $pages = []; $cu = []; $w = 0; foreach ($rows as $r) { if ($cu && $w + $wt($r) > 17) { $pages[] = $cu; $cu = []; $w = 0; } $cu[] = $r; $w += $wt($r); } if ($cu) $pages[] = $cu;
foreach ($pages as $ci => $chunk): ?>
<?= Rp::open('Execution plan — ' . $plan['period_label'] . ' — ' . $a, count($pages) > 1 ? 'Page ' . ($ci + 1) . ' / ' . count($pages) : '') ?>
<?php $t = []; foreach ($chunk as $r) { $in = ''; foreach ($r['inis'] as $i) { $in .= '<div style="margin-top:3px">• <b>' . e($i['label']) . '</b> — ' . (int)$i['progress'] . ' % (' . e(Ep::label($i['status'])) . ')' . ($i['timeline'] ? ' <i>' . e($i['timeline']) . '</i>' : '') . ($i['owner_employee_id'] ? '<div style="margin-left:14px;color:#6B7788">↳ ' . e(Ep::empName((int)$i['owner_employee_id'])) . ($i['activity'] ? ' · ' . e($i['activity']) : '') . '</div>' : '') . '</div>';
        foreach ($i['subs'] as $x) $in .= '<div style="margin-left:14px">◦ ' . e($x['label']) . ' => <b>' . e(Ep::label($x['status'])) . ' ' . (int)$x['progress'] . ' %</b>' . ($x['comment'] ? ' <i>— ' . e($x['comment']) . '</i>' : '') . '</div>';
        if (!$i['subs'] && $i['comment']) $in .= '<div style="margin-left:14px"><i>' . e($i['comment']) . '</i></div>'; }
    $t[] = [['h' => '<b>' . e($r['name']) . '</b>'], ['h' => '<div style="font-size:11px">' . $in . '</div>'], ['h' => '<div style="font-size:11px;white-space:pre-line">' . e($r['comment']) . '</div>'], $r['timeline'], Ep::owner($r), ['h' => Ep::chip($r['status'])], $r['progress'] . ' %']; }
echo Rp::table(['Programmes', 'Initiatives / sous-initiatives', 'Commentaires', 'Timeline', 'Responsable', 'Statut', 'Taux d\'atteinte'], $t, [6]); ?>
<?= Rp::close() ?>
<?php endforeach; endforeach; ?>
<?php if (!$by): ?><?= Rp::open('Execution plan — ' . $plan['period_label']) ?><div class="nb">Aucun programme.</div><?= Rp::close() ?><?php endif; ?>
