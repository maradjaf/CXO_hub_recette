<?php use App\Core\Ep; ?>
<div class="page-h"><h1><?= e($title) ?></h1><?php if (can('ep.manage')): ?><a class="btn btn-primary" href="<?= url('ep/new') ?>"><i class="bi bi-plus-lg me-1"></i>Nouveau plan</a><?php endif; ?></div>
<p class="text-muted">Chaque activité définit ses programmes et initiatives pour la période, puis renseigne l'avancement en fin de période.</p>
<div class="row g-3"><?php foreach ($plans as $p): ?><div class="col-md-6 col-xl-4"><div class="cardx h-100"><div class="d-flex justify-content-between"><h2 class="h5 mb-1"><a href="<?= url('ep/' . $p['id']) ?>"><?= e($p['name']) ?></a></h2><?= $p['status'] === 'open' ? badge('Ouvert', 'success') : badge('Clôturé', 'secondary') ?></div>
<div class="small text-muted mb-2"><?= e($p['period_label']) ?> · <?= d($p['start_date']) ?> → <?= d($p['end_date']) ?></div>
<div class="progress mb-2" style="height:10px"><div class="progress-bar" style="width:<?= (int)$p['avg'] ?>%"></div></div>
<div class="small"><b><?= (int)$p['avg'] ?> %</b> d'atteinte moyenne · <?= (int)$p['n'] ?> programme(s) · <?= (int)$p['acts'] ?> activité(s)<?= $p['late'] ? ' · <span class="text-danger">' . (int)$p['late'] . ' à risque / en retard</span>' : '' ?></div>
<div class="mt-2 d-flex gap-2"><a class="btn btn-sm btn-outline-primary" href="<?= url('ep/' . $p['id']) ?>">Ouvrir</a><a class="btn btn-sm btn-outline-secondary" href="<?= url('ep/' . $p['id'] . '/report') ?>">Rapport</a></div></div></div><?php endforeach; ?>
<?php if (!$plans): ?><div class="col-12"><div class="empty"><i class="bi bi-list-check"></i>Aucun plan d'exécution.<?php if (can('ep.manage')): ?> Créez le premier plan de la période.<?php endif; ?></div></div><?php endif; ?></div>
