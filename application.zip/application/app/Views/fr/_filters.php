<?php use App\Core\{Voc, FrStats}; /** Filtres partagés : $f (filtres), $o (listes), $action (URL), $extra (champs cachés) */
$action = $action ?? ''; $extra = $extra ?? []; $fo = $o['franchises']; ?>
<form method="get" class="cardx voc-filters mb-2" action="<?= e($action) ?>" aria-label="Filtres">
<?= Voc::dayField('Du', 'from', $f['from']) ?><?= Voc::dayField('Au', 'to', $f['to']) ?><?= Voc::select('Pas de temps', 'grain', FrStats::GRAINS, $f['grain']) ?>
<?= Voc::multi('Zones', 'zone', array_combine($o['zones'], $o['zones']), $f['zone']) ?>
<?= Voc::select('Zone selon', 'zmode', ['now' => 'Périmètre actuel', 'then' => 'Périmètre de l\'époque'], $f['zmode']) ?>
<?php if (empty($noFr)): ?><?= Voc::multi('Franchises', 'fr', $fo, array_map('strval', $f['fr'])) ?><?php endif; ?>
<?= Voc::select('Service', 'service', ['' => 'Tous'] + array_combine($o['services'], $o['services']), $f['service']) ?>
<?= Voc::select('Typologie', 'typology', ['' => 'Toutes'] + array_combine($o['typologies'], $o['typologies']), $f['typology']) ?>
<?= Voc::select('Priorité', 'priority', ['' => 'Toutes'] + \App\Core\Fr::PRIO, $f['priority']) ?>
<?php if ($o['teams']): ?><?= Voc::select('Équipe', 'team', ['' => 'Toutes'] + array_combine($o['teams'], $o['teams']), $f['team']) ?><?php endif; ?>
<?php foreach ($extra as $k => $v): ?><input type="hidden" name="<?= e($k) ?>" value="<?= e((string)$v) ?>"><?php endforeach; ?>
<a class="btn btn-sm btn-link" href="<?= e($action) ?>">Réinitialiser</a></form>
<?= \App\Controllers\FrController::scopeLine($f) ?>
