<?php $v = fn($k, $d = '') => old($k, $fr[$k] ?? $d); $err = $_SESSION["_err"] ?? []; ?>
<div class="page-h"><h1><?= e($title) ?></h1><a class="btn btn-outline-secondary" href="<?= url($fr ? 'fr/franchises/' . $fr['id'] : 'fr/franchises') ?>">Retour</a></div>
<?php include __DIR__ . "/_errs.php"; ?>
<form method="post" action="<?= url($fr ? 'fr/franchises/' . $fr['id'] . '/edit' : 'fr/franchises/new') ?>" class="cardx" data-nowizard><?= csrf_field() ?>
<div class="row g-3">
<div class="col-md-6"><label class="form-label" for="f_name">Nom officiel *</label><input id="f_name" class="form-control" name="name" value="<?= e($v('name')) ?>" required maxlength="190"></div>
<div class="col-md-3"><label class="form-label" for="f_code">Code métier</label><input id="f_code" class="form-control" name="code" value="<?= e($v('code')) ?>" maxlength="40"><div class="form-check mt-1"><input class="form-check-input" type="checkbox" name="code_ok" value="1" id="f_cok" <?= $fr && $fr['code_ok'] ? 'checked' : '' ?>><label class="form-check-label small" for="f_cok">Code approuvé par le métier</label></div></div>
<div class="col-md-3"><label class="form-label" for="f_zone">Zone *</label><input id="f_zone" class="form-control" name="zone" list="zl" value="<?= e($v('zone')) ?>" required maxlength="80"><datalist id="zl"><?php foreach ($zones as $z): ?><option value="<?= e($z) ?>"><?php endforeach; ?></datalist></div>
<div class="col-md-4"><label class="form-label" for="f_man">Responsable</label><input id="f_man" class="form-control" name="manager" value="<?= e($v('manager')) ?>" maxlength="150"></div>
<div class="col-md-4"><label class="form-label" for="f_bo">BO de rattachement</label><input id="f_bo" class="form-control" name="bo_team" value="<?= e($v('bo_team')) ?>" maxlength="120"></div>
<div class="col-md-4"><label class="form-label" for="f_ph">Téléphone</label><input id="f_ph" class="form-control" name="phone" value="<?= e($v('phone')) ?>" maxlength="40"></div>
<div class="col-md-4"><label class="form-label" for="f_em">E-mail</label><input id="f_em" type="email" class="form-control" name="email" value="<?= e($v('email')) ?>" maxlength="190"></div>
<div class="col-md-4"><label class="form-label" for="f_ci">Ville</label><input id="f_ci" class="form-control" name="city" value="<?= e($v('city')) ?>" maxlength="100"></div>
<div class="col-md-4"><label class="form-label" for="f_ad">Adresse</label><input id="f_ad" class="form-control" name="address" value="<?= e($v('address')) ?>" maxlength="300"></div>
<div class="col-md-3"><label class="form-label" for="f_ef">Date d'effet</label><input id="f_ef" type="date" class="form-control" name="effective_from" value="<?= e($v('effective_from')) ?>"></div>
<div class="col-md-3"><label class="form-label" for="f_et">Date de fin</label><input id="f_et" type="date" class="form-control" name="effective_to" value="<?= e($v('effective_to')) ?>"></div>
<div class="col-md-6"><label class="form-label" for="f_no">Note</label><input id="f_no" class="form-control" name="note" value="<?= e($v('note')) ?>" maxlength="600"></div>
<?php if ($fr): ?><div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" name="active" value="1" id="f_ac" <?= $fr['active'] ? 'checked' : '' ?>><label class="form-check-label" for="f_ac">Franchise active</label></div></div>
<div class="col-12"><div class="alert alert-info small mb-0"><strong>Changement de zone, de responsable ou de BO :</strong> l'ancienne affectation est conservée avec ses dates. Renseignez la date d'effet et le motif ci-dessous si l'un de ces champs change.<div class="row g-2 mt-1"><div class="col-md-3"><label class="form-label small mb-0" for="a_f">Effectif depuis</label><input id="a_f" type="date" class="form-control form-control-sm" name="assign_from" value="<?= e(date('Y-m-d')) ?>"></div><div class="col-md-9"><label class="form-label small mb-0" for="a_r">Motif</label><input id="a_r" class="form-control form-control-sm" name="assign_reason" maxlength="190"></div></div></div></div><?php endif; ?>
</div><div class="mt-3"><button class="btn btn-primary">Enregistrer</button></div></form>
<?php unset($_SESSION["_err"], $_SESSION["_old"]); ?>
