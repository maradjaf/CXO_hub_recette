<?php use App\Core\{Fr, FrChart, FrStats}; use App\Controllers\FrController as C;
$g = ['from' => $f['from'], 'to' => $f['to']]; $rq = url('fr/requests'); ?>
<div class="page-h"><div><h1>Synthèse réseau</h1><p class="text-muted mb-0">Entrées, sorties, stock et retards des franchises</p></div>
<div class="d-flex gap-2"><?php if (can('fr.handle')): ?><a class="btn btn-primary" href="<?= url('fr/requests/new') ?>"><i class="bi bi-plus-lg me-1"></i>Nouvelle demande</a><?php endif; ?><a class="btn btn-outline-secondary" href="<?= url('fr/franchises') ?>">Franchises</a></div></div>
<?php if (!$cov['to']): ?><div class="cardx"><div class="empty"><i class="bi bi-shop"></i>Aucun dossier pour l'instant.<?php if (can('fr.import')): ?> <a href="<?= url('fr/import') ?>">Importez une reprise</a> ou créez une demande.<?php endif; ?></div></div><?php endif; ?>
<?php include __DIR__ . '/_filters.php'; ?>
<?php if ($f['to'] > ($cov['to'] ?? $f['to'])): ?><div class="alert alert-warning small">Période partielle : les données dossiers s'arrêtent au <?= e(d($cov['to'])) ?>.</div><?php endif; ?>
<div class="row g-3 mb-3">
<?= C::kpi('received', $f, $f['from'], $f['to'], $rq . '?' . http_build_query($g)) ?><?= C::kpi('closed', $f, $f['from'], $f['to'], $rq . '?' . http_build_query($g + ['status' => 'term'])) ?>
<?= C::kpi('stock', $f, $f['from'], $f['to'], $rq . '?status=open') ?><?= C::kpi('late', $f, $f['from'], $f['to'], $rq . '?overdue=1') ?>
<?= C::kpi('exec', $f, $f['from'], $f['to']) ?><?= C::kpi('sla', $f, $f['from'], $f['to']) ?><?= C::kpi('median', $f, $f['from'], $f['to']) ?><?= C::kpi('ops', $f, $f['from'], $f['to'], url('fr/operations') . '?' . http_build_query($g)) ?>
</div>
<div class="row g-3 mb-3">
<div class="col-lg-6"><div class="cardx h-100"><h2 class="h5">Entrées</h2><?= FrChart::line($labels, $S['received'], ['label' => 'Entrées par période']) ?></div></div>
<div class="col-lg-6"><div class="cardx h-100"><h2 class="h5">Sorties</h2><?= FrChart::line($labels, $S['closed'], ['label' => 'Sorties par période']) ?></div></div>
<div class="col-12"><div class="cardx"><h2 class="h5">Stock ouvert</h2><?= FrChart::line($labels, $S['stock'], ['label' => 'Stock ouvert en fin de période']) ?></div></div></div>
<div class="cardx"><h2 class="h5">Franchises à surveiller</h2><p class="small text-muted">Classées par dossiers hors délai puis par stock ouvert (<?= (int)$nrows ?> franchise(s) avec activité).</p>
<?= \App\Core\Voc::table(['Franchise', 'Zone', 'Reçues', 'Stock ouvert', 'Hors délai', 'Respect SLA'], array_map(fn($r) => ['<a href="' . e(url('fr/franchises/' . $r['f']['id'])) . '">' . e($r['f']['name']) . '</a>', e($r['f']['zone']), Fr::n($r['recv']), Fr::n($r['stock']), $r['late'] ? '<a class="text-danger" href="' . e($rq . '?' . http_build_query(['fr' => $r['f']['id'], 'overdue' => 1])) . '">' . Fr::n($r['late']) . '</a>' : '0', $r['sla'] && ($r['sla']['v'] ?? null) !== null ? e(Fr::dec($r['sla']['v'])) . ' %' : '—'], $rows)) ?></div>
