<div class="page-h"><h1>Modèles de réponse</h1></div>
<div class="cardx mb-3"><p class="small text-muted mb-2">Textes prêts à l'emploi proposés aux techniciens dans le commentaire (<b>réponse</b>) et dans la saisie de la solution (<b>solution</b>). Variables : <code>{demandeur}</code> (prénom), <code>{reference}</code>, <code>{titre}</code>, <code>{technicien}</code>. Un modèle lié à une catégorie n'est proposé que pour cette catégorie.</p>
<?php foreach ($rows as $r): ?><form method="post" action="<?= url('at/templates/' . $r['id']) ?>" class="row g-2 border-bottom pb-2 mb-2 <?= $r['active'] ? '' : 'opacity-50' ?>"><?= csrf_field() ?>
<div class="col-md-3"><input class="form-control form-control-sm" name="title" value="<?= e($r['title']) ?>" required></div>
<div class="col-md-2"><select class="form-select form-select-sm" name="kind"><option value="reply" <?= $r['kind'] === 'reply' ? 'selected' : '' ?>>Réponse</option><option value="solution" <?= $r['kind'] === 'solution' ? 'selected' : '' ?>>Solution</option></select></div>
<div class="col-md-3"><select class="form-select form-select-sm" name="category"><option value="">Toutes catégories</option><?php foreach ($cats as $c): ?><option value="<?= e($c['code']) ?>" <?= $r['category'] === $c['code'] ? 'selected' : '' ?>><?= e($c['label']) ?></option><?php endforeach; ?></select></div>
<div class="col-md-2 form-check ps-5"><input class="form-check-input" type="checkbox" name="active" value="1" <?= $r['active'] ? 'checked' : '' ?>><label class="form-check-label small">Actif</label></div>
<div class="col-md-1"><button class="btn btn-sm btn-outline-primary">OK</button></div>
<div class="col-12"><textarea class="form-control form-control-sm" name="body" rows="2" maxlength="1500" required><?= e($r['body']) ?></textarea></div></form><?php endforeach; ?></div>
<form method="post" action="<?= url('at/templates') ?>" class="cardx row g-2"><?= csrf_field() ?><h2>Nouveau modèle</h2>
<div class="col-md-4"><input class="form-control" name="title" placeholder="Titre" required maxlength="150"></div>
<div class="col-md-3"><select class="form-select" name="kind"><option value="reply">Réponse</option><option value="solution">Solution</option></select></div>
<div class="col-md-3"><select class="form-select" name="category"><option value="">Toutes catégories</option><?php foreach ($cats as $c): ?><option value="<?= e($c['code']) ?>"><?= e($c['label']) ?></option><?php endforeach; ?></select></div>
<div class="col-12"><textarea class="form-control" name="body" rows="3" maxlength="1500" placeholder="Texte du modèle" required></textarea></div>
<div class="col-12"><button class="btn btn-primary">Créer le modèle</button></div></form>
