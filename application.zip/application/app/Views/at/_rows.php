<?php use App\Core\Tickets; ?>
<div class="tbl"><table class="table table-hover"><thead><tr><th>Réf.</th><th>Titre</th><th>Priorité</th><th>Canal</th><th>Niv.</th><th>Statut</th><?php if (!empty($showReq)): ?><th>Demandeur</th><?php endif; ?><th>Technicien</th><th>Échéance</th></tr></thead><tbody>
<?php foreach ($p['rows'] as $r): ?><tr>
<td class="mono"><a href="<?= url('at/' . $r['id']) ?>"><?= e($r['reference']) ?></a></td>
<td><?= e($r['title']) ?><div class="small text-muted"><?= e(Tickets::KIND[$r['kind']] ?? $r['kind']) ?><?= $r['store_name'] ? ' · ' . e($r['store_name']) : '' ?></div></td>
<td><?= Tickets::prioBadge($r['priority']) ?></td><td class="small"><?= e(\App\Core\Esc::CHANNEL[$r['channel'] ?? 'portal'] ?? '') ?></td><td>N<?= (int)($r['tier'] ?? 1) ?><?= (int)($r['esc_level'] ?? 0) > 0 ? ' <i class="bi bi-exclamation-triangle-fill text-danger" title="Escaladé"></i>' : '' ?><?= ($r['ext_status'] ?? '') === 'open' ? ' <i class="bi bi-box-arrow-up-right text-warning" title="Chez le prestataire"></i>' : '' ?></td><td><?= Tickets::statusBadge($r['status']) ?></td>
<?php if (!empty($showReq)): ?><td><?= e($r['requester']) ?></td><?php endif; ?>
<td><?= $r['assignee'] ? e($r['assignee']) : '<span class="text-muted">—</span>' ?></td>
<td><?= dt($r['due_at']) ?><div><?= Tickets::slaBadge($r) ?></div></td></tr>
<?php endforeach; if (!$p['rows']): ?><tr><td colspan="9"><div class="empty"><i class="bi bi-life-preserver"></i>Aucun ticket.</div></td></tr><?php endif; ?></tbody></table></div>
<?php require __DIR__ . '/../layout/pager.php'; ?>
