<div class="page-h"><h1>Mes tickets</h1><a class="btn btn-primary" href="<?= url('at/new') ?>"><i class="bi bi-plus-lg me-1"></i>Nouveau ticket</a></div>
<?php $showReq = false; require __DIR__ . '/_rows.php'; ?>
