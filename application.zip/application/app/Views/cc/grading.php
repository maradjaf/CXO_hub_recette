<?php $tab = 'grading'; ?>
<div class="page-h"><h1>Études de cas à corriger</h1></div>
<?php require __DIR__ . '/_nav.php'; ?>
<div class="cardx"><table class="table table-sm"><thead><tr><th>Collaborateur</th><th>Étude de cas</th><th>Soumise le</th><th></th></tr></thead><tbody><?php foreach ($rows as $r): ?><tr><td><?= e($r['last_name'] . ' ' . $r['first_name']) ?></td><td><?= e($r['ref'] . ' · ' . $r['title']) ?></td><td class="small"><?= e(dt($r['submitted_at'])) ?></td><td><a class="btn btn-sm btn-primary" href="<?= url('cc/grade/' . (int)$r['id']) ?>">Corriger</a></td></tr><?php endforeach; if (!$rows): ?><tr><td colspan="4" class="text-muted">Rien à corriger.</td></tr><?php endif; ?></tbody></table></div>
