<?php $err = $_SESSION['_err'] ?? []; $v = fn($k, $d = '') => old($k, $d); ?>
<div class="page-h"><h1><?= e($title) ?></h1><a class="btn btn-outline-secondary" href="<?= url('ag/objectives') ?>">Retour</a></div>
<?php foreach ($err as $m): ?><div class="alert alert-danger py-2"><?= e($m) ?></div><?php endforeach; ?>
<form method="post" action="<?= url('ag/objectives/mass') ?>" class="cardx row g-3" style="max-width:1000px"><?= csrf_field() ?>
<?php require __DIR__ . '/_scope.php'; ?>
<div class="col-12"></div><?php require __DIR__ . '/_period.php'; ?>
<div class="col-md-9"><label class="form-label req" for="m-t">Objectif</label><input id="m-t" class="form-control" name="title" maxlength="190" required value="<?= e($v('title')) ?>"></div>
<div class="col-md-3"><label class="form-label" for="m-w">Poids (1 à 10)</label><input id="m-w" type="number" min="1" max="10" class="form-control" name="weight" value="<?= e($v('weight', 1)) ?>"></div>
<div class="col-md-6"><label class="form-label" for="m-g">Cible commune</label><input id="m-g" class="form-control" name="target" maxlength="150" value="<?= e($v('target')) ?>"></div>
<div class="col-12"><label class="form-label" for="m-d">Description / mode de mesure</label><textarea id="m-d" class="form-control" name="description" rows="2" maxlength="1000"><?= e($v('description')) ?></textarea></div>
<div class="col-12"><label class="form-label" for="m-s">Exclure certains collaborateurs</label><select id="m-s" class="form-select" name="skip[]" multiple size="5"><?php foreach ($emps as $x): ?><option value="<?= (int)$x['id'] ?>"><?= e($x['last_name'] . ' ' . $x['first_name'] . ' (' . $x['matricule'] . ')') ?></option><?php endforeach; ?></select><div class="form-text">Ctrl/Cmd + clic pour en choisir plusieurs. La cible de chacun pourra ensuite être adaptée.</div></div>
<div class="col-12"><label class="form-check"><input type="checkbox" class="form-check-input" name="validate_now" value="1"> Valider directement (pour les collaborateurs dont je suis le N+1)</label></div>
<div class="col-12"><button class="btn btn-primary">Attribuer</button></div></form>
<?php unset($_SESSION['_err'], $_SESSION['_old']); ?>
