<?php $err = $_SESSION['_err'] ?? []; $v = fn($k, $d = '') => old($k, $d); $emps = []; ?>
<div class="page-h"><h1><?= e($title) ?></h1><a class="btn btn-outline-secondary" href="<?= url('ag/campaigns') ?>">Retour</a></div>
<?php foreach ($err as $m): ?><div class="alert alert-danger py-2"><?= e($m) ?></div><?php endforeach; ?>
<form method="post" action="<?= url('ag/campaigns') ?>" class="cardx row g-3" style="max-width:1000px"><?= csrf_field() ?>
<div class="col-md-8"><label class="form-label req" for="c-n">Nom de la campagne</label><input id="c-n" class="form-control" name="name" maxlength="190" required value="<?= e($v('name')) ?>" placeholder="Ex. Évaluation T2 2026"></div><div class="col-md-4"></div>
<?php $pl = 'Périodicité évaluée'; $dl = 'Date dans la période évaluée'; require __DIR__ . '/_period.php'; ?>
<div class="col-md-3"><label class="form-label req" for="c-o">Début de la campagne</label><input id="c-o" type="date" class="form-control" name="opens_on" required value="<?= e($v('opens_on')) ?>"></div>
<div class="col-md-3"><label class="form-label req" for="c-c">Clôture de la campagne</label><input id="c-c" type="date" class="form-control" name="closes_on" required value="<?= e($v('closes_on')) ?>"></div>
<?php require __DIR__ . '/_scope.php'; ?>
<div class="col-md-3"><label class="form-label" for="c-r1">1re relance (jours avant la clôture)</label><input id="c-r1" type="number" min="1" max="60" class="form-control" name="remind1_days" value="<?= e($v('remind1_days', 7)) ?>"></div>
<div class="col-md-3"><label class="form-label" for="c-r2">2e relance (jours avant la clôture)</label><input id="c-r2" type="number" min="1" max="60" class="form-control" name="remind2_days" value="<?= e($v('remind2_days', 3)) ?>"></div>
<div class="col-md-6 align-self-end"><label class="form-check"><input type="checkbox" class="form-check-input" name="remind_email" value="1" checked> Envoyer aussi les relances par e-mail</label></div>
<div class="col-12"><button class="btn btn-primary">Créer la campagne</button><div class="form-text">La campagne s'ouvre et se clôture automatiquement aux dates choisies. Les agents sans auto-évaluation remise (et leur N+1) sont relancés à J-7 et J-3 par défaut.</div></div></form>
<?php unset($_SESSION['_err'], $_SESSION['_old']); ?>
