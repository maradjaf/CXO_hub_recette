<?php use App\Core\Ag; ?>
<div class="page-h"><h1>Lot d'objectifs : <?= e($b['label']) ?></h1><a class="btn btn-outline-secondary" href="<?= url('ag/objectives?batch=' . (int)$b['id']) ?>">Voir dans la liste</a></div>
<p class="text-muted">Périmètre : <b><?= e($scopeName) ?></b> · créé le <?= d($b['created_at']) ?>. Adaptez la cible ou le poids d'un collaborateur (l'objectif repart en validation N+1), ou retirez-le du lot.</p>
<form method="post" action="<?= url('ag/batches/' . $b['id']) ?>"><?= csrf_field() ?>
<div class="tbl"><table class="table"><thead><tr><th>Collaborateur</th><th>Période</th><th style="width:260px">Cible</th><th style="width:90px">Poids</th><th>Statut</th><th>Retirer</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?><tr><td><?= e($r['last_name'] . ' ' . $r['first_name']) ?><div class="small text-muted mono"><?= e($r['matricule']) ?></div></td><td><?= e(Ag::label($r['period_type'], $r['period_start'], $r['period_end'])) ?></td>
<td><input class="form-control form-control-sm" name="target[<?= (int)$r['id'] ?>]" maxlength="150" value="<?= e($r['target']) ?>"><?= $r['adapted'] ? '<span class="small text-info">Adapté</span>' : '' ?></td>
<td><input type="number" min="1" max="10" class="form-control form-control-sm" name="weight[<?= (int)$r['id'] ?>]" value="<?= (int)$r['weight'] ?>"></td><td><?= badge(Ag::OS[$r['status']][0], Ag::OS[$r['status']][1]) ?></td><td><input type="checkbox" name="rm[<?= (int)$r['id'] ?>]" value="1"></td></tr><?php endforeach; ?>
<?php if (!$rows): ?><tr><td colspan="6"><div class="empty">Aucun objectif dans ce lot pour votre périmètre.</div></td></tr><?php endif; ?></tbody></table></div>
<button class="btn btn-primary">Enregistrer les adaptations</button></form>
