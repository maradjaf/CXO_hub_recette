<?php $err = $_SESSION['_err'] ?? []; ?>
<div class="page-h"><h1><?= e($title) ?></h1><a class="btn btn-outline-secondary" href="<?= url('ag/objectives') ?>">Retour</a></div>
<p class="text-muted">Copie les objectifs d'une période vers la période suivante (ou une autre période cible). Ils repassent en validation N+1.</p>
<form method="post" action="<?= url('ag/objectives/renew') ?>" class="cardx row g-3" style="max-width:1000px"><?= csrf_field() ?>
<?php $pn = 'period_type'; $dn = 'src_date'; $dl = 'Date dans la période source'; require __DIR__ . '/_period.php'; ?>
<div class="col-md-3"><label class="form-label" for="r-d">Date dans la période cible</label><input id="r-d" type="date" class="form-control" name="dst_date"><div class="form-text">Vide = période qui suit la source.</div></div>
<div class="col-md-3"><label class="form-label" for="r-o">Objectifs repris</label><select id="r-o" class="form-select" name="only"><option value="validated">Validés uniquement</option><option value="all">Tous statuts</option></select></div>
<?php require __DIR__ . '/_scope.php'; ?>
<div class="col-12"><button class="btn btn-primary">Reconduire</button></div></form>
<?php unset($_SESSION['_err'], $_SESSION['_old']); ?>
