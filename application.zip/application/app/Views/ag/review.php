<?php use App\Core\Ag; ?>
<div class="page-h"><h1><?= e($title) ?></h1></div>
<form class="filters row g-2" method="get"><div class="col-md-4"><input class="form-control" name="q" placeholder="Collaborateur ou matricule" value="<?= e($_GET['q'] ?? '') ?>"></div>
<div class="col-md-3"><select class="form-select" name="status"><?php foreach (Ag::ES as $k => [$l]): ?><option value="<?= $k ?>" <?= ($_GET['status'] ?? 'self_done') === $k ? 'selected' : '' ?>><?= e($l) ?></option><?php endforeach; ?></select></div>
<div class="col-md-3"><select class="form-select" name="campaign"><option value="">Campagne : toutes</option><?php foreach ($camps as $c): ?><option value="<?= (int)$c['id'] ?>" <?= ($_GET['campaign'] ?? '') == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div><div class="col-md-1"><button class="btn btn-primary w-100">OK</button></div></form>
<div class="tbl"><table class="table table-hover"><thead><tr><th>Collaborateur</th><th>Campagne</th><th>Clôture</th><th>Statut</th><th>Auto-éval.</th><th>Note finale</th><th></th></tr></thead><tbody>
<?php foreach ($p['rows'] as $r): ?><tr><td><?= e($r['last_name'] . ' ' . $r['first_name']) ?><div class="small text-muted mono"><?= e($r['matricule']) ?></div></td><td><?= e($r['cname']) ?></td><td><?= d($r['closes_on']) ?></td><td><?= badge(Ag::ES[$r['status']][0], Ag::ES[$r['status']][1]) ?></td>
<td><?= $r['self_score'] === null ? '—' : (int)$r['self_score'] . ' %' ?></td><td><?= $r['final_score'] === null ? '—' : (int)$r['final_score'] . ' %' ?></td><td><a class="btn btn-sm btn-primary" href="<?= url('ag/eval/' . $r['id']) ?>">Examiner</a></td></tr><?php endforeach; ?>
<?php if (!$p['rows']): ?><tr><td colspan="7"><div class="empty"><i class="bi bi-clipboard-check"></i>Aucune évaluation à examiner.</div></td></tr><?php endif; ?></tbody></table></div>
<?php require __DIR__ . '/../layout/pager.php'; ?>
