<?php use App\Core\Ag; ?>
<div class="page-h"><h1><?= e($title) ?></h1><a class="btn btn-primary" href="<?= url('ag/campaigns/new') ?>"><i class="bi bi-plus-lg me-1"></i>Nouvelle campagne</a></div>
<div class="tbl"><table class="table table-hover"><thead><tr><th>Campagne</th><th>Période évaluée</th><th>Ouverture</th><th>Clôture</th><th>Participation</th><th>Statut</th></tr></thead><tbody>
<?php foreach ($p['rows'] as $c): $pc = $c['n'] ? (int)round(100 * $c['done'] / $c['n']) : 0; ?><tr><td><a class="fw-semibold text-decoration-none" href="<?= url('ag/campaigns/' . $c['id']) ?>"><?= e($c['name']) ?></a></td><td><?= e(Ag::label($c['period_type'], $c['period_start'], $c['period_end'])) ?></td><td><?= d($c['opens_on']) ?></td><td><?= d($c['closes_on']) ?></td>
<td style="min-width:170px"><div class="progress" style="height:8px"><div class="progress-bar" style="width:<?= $pc ?>%"></div></div><small><?= (int)$c['done'] ?>/<?= (int)$c['n'] ?> remises · <?= (int)$c['rev'] ?> évaluées</small></td><td><?= badge(Ag::CS[$c['status']][0], Ag::CS[$c['status']][1]) ?></td></tr><?php endforeach; ?>
<?php if (!$p['rows']): ?><tr><td colspan="6"><div class="empty"><i class="bi bi-calendar-check"></i>Aucune campagne. Créez la première.</div></td></tr><?php endif; ?></tbody></table></div>
<?php require __DIR__ . '/../layout/pager.php'; ?>
