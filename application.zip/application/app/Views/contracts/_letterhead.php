<?php /** En-tête (logo / bandeau / texte) de la société employeuse du document $lhCode, et pied de page via $lhFoot. */
$b = App\Core\Brand::forEmployer($lhCode ?? null); $lines = array_values(array_filter(preg_split('/\R/u', (string)$b['header_text']), fn($x) => trim($x) !== '')); ?>
<?php if (!empty($lhFoot)): ?>
<?php if ($b['footer_img'] && App\Core\Brand::path($b['footer_img'])): ?><div class="mt-3 text-center"><img src="<?= e(App\Core\Brand::url($b['footer_img'])) ?>" alt="" style="max-width:100%;max-height:70px"></div>
<?php elseif (trim((string)$b['footer_text']) !== ''): ?><div class="mt-3 pt-2 small text-muted text-center" style="border-top:1px solid #dde4ee"><?= nl2br(e((string)$b['footer_text'])) ?></div><?php endif; ?>
<?php else: ?>
<?php if ($b['header_img'] && App\Core\Brand::path($b['header_img'])): ?><div class="mb-3"><img src="<?= e(App\Core\Brand::url($b['header_img'])) ?>" alt="" style="max-width:100%;max-height:110px"></div>
<?php elseif ($b['logo'] || $lines): ?><div class="d-flex align-items-center gap-3 pb-2 mb-3" style="border-bottom:1px solid #dde4ee"><?php if ($b['logo'] && App\Core\Brand::path($b['logo'])): ?><img src="<?= e(App\Core\Brand::url($b['logo'])) ?>" alt="" style="max-height:56px;max-width:160px"><?php endif; ?>
<div><?php if ($lines): foreach ($lines as $k => $l): ?><div class="<?= $k ? 'small text-muted' : 'fw-bold' ?>"><?= e($l) ?></div><?php endforeach; elseif ($b['name']): ?><div class="fw-bold"><?= e($b['name']) ?></div><?php if ($b['slogan']): ?><div class="small text-muted"><?= e($b['slogan']) ?></div><?php endif; endif; ?></div></div><?php endif; ?>
<?php endif; ?>
