<div class="container py-5" style="max-width:600px"><div class="alert alert-danger">Ce lien est invalide ou a été retiré. Contactez la personne qui vous l'a envoyé.</div></div>
