<?php use App\Core\Cx; ?>
<div class="page-h"><h1>Grilles Mystery Customer</h1><a class="btn btn-outline-primary btn-sm" href="<?= url('cx/journeys') ?>">Parcours client</a></div>
<div class="row g-3"><div class="col-lg-8"><div class="tbl"><table class="table table-hover"><thead><tr><th>Code</th><th>Nom</th><th>Canal</th><th class="text-end">Critères</th><th class="text-end">Visites</th><th>Statut</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?><tr><td><?= e($r['code']) ?></td><td><a href="<?= url('cx/grids/' . $r['id']) ?>"><?= e($r['name']) ?></a></td><td><?= e(Cx::CH[$r['channel']] ?? '') ?></td><td class="text-end"><?= (int)$r['nc'] ?></td><td class="text-end"><?= (int)$r['nv'] ?></td><td><?= badge(Cx::GS[$r['status']] ?? '', Cx::GS_COLOR[$r['status']] ?? 'secondary') ?></td></tr>
<?php endforeach; if (!$rows): ?><tr><td colspan="6"><div class="empty"><i class="bi bi-card-checklist"></i>Aucune grille.</div></td></tr><?php endif; ?></tbody></table></div></div>
<div class="col-lg-4"><form method="post" action="<?= url('cx/grids') ?>" class="cardx"><?= csrf_field() ?><h2>Nouvelle grille</h2>
<input class="form-control mb-2" name="code" maxlength="40" required placeholder="Code (MC-STORE)"><input class="form-control mb-2" name="name" maxlength="150" required placeholder="Nom">
<textarea class="form-control mb-2" name="description" rows="2" maxlength="500" placeholder="Description"></textarea>
<select class="form-select mb-2" name="channel"><?php foreach (Cx::CH as $k => $l): ?><option value="<?= $k ?>"><?= e($l) ?></option><?php endforeach; ?></select>
<label class="form-label">Seuil de conformité (%)</label><input type="number" min="1" max="100" class="form-control mb-3" name="pass_pct" value="80"><button class="btn btn-primary">Créer</button></form></div></div>
