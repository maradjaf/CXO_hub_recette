<?php use App\Core\Cx; ?>
<div class="page-h"><h1>Planifier une visite mystère</h1></div>
<form method="post" action="<?= url('cx/visits/new') ?>" class="cardx" style="max-width:640px"><?= csrf_field() ?>
<label class="form-label">Grille</label><select class="form-select mb-2" name="grid_id" required><option value="">—</option><?php foreach ($grids as $g): ?><option value="<?= $g['id'] ?>"><?= e($g['name']) ?> (<?= e(Cx::CH[$g['channel']] ?? '') ?>)</option><?php endforeach; ?></select>
<label class="form-label">Store <small class="text-muted">(grille « store »)</small></label><select class="form-select mb-2" name="store_id"><option value="">—</option><?php foreach ($stores as $s): ?><option value="<?= $s['id'] ?>"><?= e($s['name']) ?></option><?php endforeach; ?></select>
<label class="form-label">Équipe <small class="text-muted">(grille « call center »)</small></label><select class="form-select mb-2" name="team_id"><option value="">—</option><?php foreach ($teams as $t): ?><option value="<?= $t['id'] ?>"><?= e($t['name']) ?></option><?php endforeach; ?></select>
<label class="form-label">Client mystère</label><select class="form-select mb-2" name="shopper_id" required><option value="">—</option><?php foreach ($shoppers as $u): ?><option value="<?= $u['id'] ?>"><?= e($u['name']) ?></option><?php endforeach; ?></select>
<label class="form-label">Libellé externe <small class="text-muted">(agence, optionnel — jamais montré aux managers)</small></label><input class="form-control mb-2" name="shopper_label" maxlength="150">
<label class="form-label">Date prévue</label><input type="date" class="form-control mb-3" name="planned_date" value="<?= date('Y-m-d') ?>"><button class="btn btn-primary">Planifier</button></form>
