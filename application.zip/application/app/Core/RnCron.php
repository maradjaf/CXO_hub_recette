<?php
namespace App\Core;
/** Rappels du module Réunions : lancés par le cron (bin/rn-reminders.php) ou, à défaut, par un filet de sécurité déclenché par la navigation. */
class RnCron {
    static function run(): array {
        if (!Rn::on()) return [];
        $out = ['rappels' => 0, 'à clore' => 0, 'comptes rendus' => 0, 'actions' => 0, 'retards' => 0];
        // 1. rappel avant la réunion
        foreach (DB::all("SELECT id FROM rn_meetings WHERE status='planned' AND reminder_sent=0 AND start_at>=? AND start_at<=?", [date('Y-m-d H:i:s', time() - 120), date('Y-m-d H:i:s', time() + Xchg::int('rn.reminder_min', 5, 2880) * 60)]) as $m) {
            DB::update('rn_meetings', ['reminder_sent' => 1], 'id=?', [(int)$m['id']]); Rn::notify((int)$m['id'], 'RAPPEL'); $out['rappels']++;
        }
        $recent = fn(int $mid, string $kind, int $days) => (bool)DB::val('SELECT 1 FROM rn_events WHERE meeting_id=? AND kind=? AND created_at>=?', [$mid, $kind, date('Y-m-d H:i:s', time() - $days * 86400)]);
        $ev = fn(int $mid, string $kind, string $txt) => DB::insert('rn_events', ['meeting_id' => $mid, 'user_id' => null, 'kind' => $kind, 'text' => $txt, 'created_at' => now()]);
        // 2. réunion terminée mais non clôturée (ni « tenue » ni annulée)
        foreach (DB::all("SELECT * FROM rn_meetings WHERE status='planned' AND start_at<?", [date('Y-m-d H:i:s', time() - 3 * 3600)]) as $m) {
            if ($recent((int)$m['id'], 'chase_held', 3)) continue; Notifier::send((int)$m['organizer_id'], 'Réunion à clôturer · ' . $m['ref'], $m['title'] . ' : marquez-la comme tenue (ou annulée) et enregistrez les présences.', '/rn/' . $m['id']); $ev((int)$m['id'], 'chase_held', 'Rappel automatique : réunion à clôturer.'); $out['à clore']++;
        }
        // 3. compte rendu manquant ou non diffusé
        $lim = date('Y-m-d H:i:s', time() - Xchg::int('rn.minutes_chase_days', 1, 60) * 86400);
        foreach (DB::all("SELECT * FROM rn_meetings WHERE status='held' AND minutes_status IN ('none','draft','validated') AND COALESCE(held_at, start_at)<?", [$lim]) as $m) {
            if ($recent((int)$m['id'], 'chase_min', 3)) continue; $txt = ['none' => 'à rédiger', 'draft' => 'à valider', 'validated' => 'à diffuser'][$m['minutes_status']];
            foreach (array_unique(array_filter([(int)$m['organizer_id'], (int)$m['secretary_id']])) as $u) Notifier::send($u, 'Compte rendu ' . $txt . ' · ' . $m['ref'], $m['title'] . ' — réunion du ' . date('d/m/Y', strtotime($m['start_at'])) . '.', '/rn/' . $m['id'] . '/minutes' . ($m['minutes_status'] === 'none' ? '/edit' : ''));
            $ev((int)$m['id'], 'chase_min', 'Rappel automatique : compte rendu ' . $txt . '.'); $out['comptes rendus']++;
        }
        // 4. actions : rappel avant l'échéance (une fois par échéance), puis relance des retards tous les 3 jours
        $ahead = date('Y-m-d', strtotime('+' . Xchg::int('rn.action_remind_days', 0, 60) . ' days')); $today = date('Y-m-d'); $late = []; $mail = Xchg::on('rn.action_email');
        foreach (DB::all("SELECT a.*, m.ref, m.title mtitle, m.organizer_id, u.email FROM rn_actions a JOIN rn_meetings m ON m.id=a.meeting_id LEFT JOIN users u ON u.id=a.owner_id AND u.status='active' WHERE a.status IN ('open','in_progress') AND a.due_date<=?", [$ahead]) as $a) {
            $overdue = $a['due_date'] < $today; if ($a['reminded_at'] && $a['reminded_at'] >= date('Y-m-d H:i:s', time() - ($overdue ? 3 : 365) * 86400)) { if ($overdue) $late[(int)$a['organizer_id']][] = $a; continue; }
            $t = $overdue ? 'Action en retard · ' . $a['ref'] : 'Échéance proche · ' . $a['ref']; $b = $a['title'] . ' — échéance ' . d($a['due_date']) . ' (' . $a['mtitle'] . ')';
            Notifier::send((int)$a['owner_id'], $t, $b, '/rn/actions/' . $a['id']); if ($mail && $a['email']) Mailer::queue($a['email'], $t, "Bonjour,\n\n$b\n\n" . (Rn::abs('rn/actions/' . $a['id']) ?: ''));
            DB::update('rn_actions', ['reminded_at' => now()], 'id=?', [(int)$a['id']]); $out['actions']++; if ($overdue) { $late[(int)$a['organizer_id']][] = $a; $out['retards']++; }
        }
        foreach ($late as $org => $l) { $title = 'Actions en retard dans vos réunions'; if (DB::val('SELECT 1 FROM notifications WHERE user_id=? AND title=? AND read_at IS NULL', [$org, $title])) continue; Notifier::send((int)$org, $title, count($l) . ' action(s) en retard, dont « ' . mb_substr($l[0]['title'], 0, 80) . ' ».', '/rn/actions?view=all&late=1'); }
        return $out;
    }
    /** Filet de sécurité sans cron : au plus toutes les 10 minutes, après l'envoi de la réponse, et seulement si le cron n'est pas passé récemment. */
    static function lazyRun(): void {
        if (PHP_SAPI === 'cli' || Request::method() !== 'GET' || !Xchg::on('rn.lazy') || !Rn::on()) return;
        if (time() - (int)strtotime((string)setting('rn.cron_last', '2000-01-01')) < 600) return;
        Settings::set('rn.cron_last', now());
        $j = DB::one('SELECT last_end, last_output FROM sys_jobs WHERE name=?', ['rn-reminders']);
        if ($j && $j['last_end'] && time() - strtotime($j['last_end']) < 900 && !str_starts_with((string)$j['last_output'], 'filet')) return;
        register_shutdown_function(function () {
            if (function_exists('fastcgi_finish_request')) @fastcgi_finish_request(); $t0 = now();
            try { $o = self::run(); $st = 'ok'; $txt = json_encode($o, JSON_UNESCAPED_UNICODE); } catch (\Throwable $e) { $st = 'error'; $txt = 'ERREUR : ' . $e->getMessage(); }
            try {
                $d = ['last_start' => $t0, 'last_end' => now(), 'last_status' => $st, 'last_output' => mb_substr('filet : ' . $txt, 0, 500)]; if ($st === 'error') $d['last_error_at'] = $d['last_end'];
                $r = DB::one('SELECT id, runs FROM sys_jobs WHERE name=?', ['rn-reminders']);
                if ($r) DB::update('sys_jobs', $d + ['runs' => (int)$r['runs'] + 1], 'id=?', [(int)$r['id']]); else DB::insert('sys_jobs', $d + ['name' => 'rn-reminders', 'runs' => 1]);
            } catch (\Throwable $e) {}
        });
    }
}
