<?php
namespace App\Core;

/**
 * Lot 60 — Franchises : jeu de démonstration SYNTHÉTIQUE. Les noms de franchises sont des localités togolaises utilisées comme étiquettes de test ;
 * les volumes reconstituent les chiffres publiés dans le cahier des besoins (quinzaine du 16 au 31 octobre 2026) mais ne sont pas les fichiers réels.
 */
final class FrDemo {
    const NAMES = ['ADETA' => 'Plateaux', 'ADETIKOPE' => 'Maritime', 'ADIDOME' => 'Maritime', 'AFIDEGNIGBA' => 'Maritime', 'AGBELOUVE' => 'Maritime', 'AGOU GARE' => 'Plateaux', 'AKEPE' => 'Maritime', 'AMLAME' => 'Plateaux', 'ANIE' => 'Plateaux', 'ANEHO' => 'Maritime',
        'ASSAHOUN' => 'Plateaux', 'ATAKPAME' => 'Plateaux', 'BADOU' => 'Plateaux', 'BAGUIDA' => 'Grand Lomé', 'BASSAR' => 'Kara', 'BLITTA' => 'Centrale', 'CINKASSE' => 'Savanes', 'DANYI' => 'Plateaux', 'DAPAONG' => 'Savanes', 'DAVIE' => 'Maritime',
        'DJAGBLE' => 'Grand Lomé', 'ELAVAGNON' => 'Plateaux', 'GLEI' => 'Plateaux', 'KARA' => 'Kara', 'KEVE' => 'Maritime', 'KOUVE' => 'Maritime', 'KPALIME' => 'Plateaux', 'KPELE' => 'Plateaux', 'MANGO' => 'Savanes', 'NOTSE' => 'Plateaux',
        'SOKODE' => 'Centrale', 'SOTOUBOUA' => 'Centrale', 'TABLIGBO' => 'Maritime', 'TSEVIE' => 'Maritime', 'VOGAN' => 'Maritime', 'ZOUGBE' => 'Maritime', 'ADIDOGOME' => 'Grand Lomé', 'AGOE NYIVE' => 'Grand Lomé', 'HANOUKOPE' => 'Grand Lomé', 'BE KLIKAME' => 'Grand Lomé'];

    static function present(): bool { return (bool)DB::val('SELECT 1 FROM fr_franchises WHERE is_demo=1 LIMIT 1'); }
    private static function pick(array $a) { return $a[mt_rand(0, count($a) - 1)]; }
    /** Répartit $total au prorata des poids, avec un minimum par entrée (méthode du plus fort reste). */
    private static function spread(int $total, array $w, int $min = 0): array {
        $n = count($w); $left = $total - $min * $n; $sum = array_sum($w); $out = array_fill_keys(array_keys($w), $min); $rem = [];
        foreach ($w as $k => $x) { $q = $left * $x / $sum; $out[$k] += (int)floor($q); $rem[$k] = $q - floor($q); } $d = $total - array_sum($out); arsort($rem);
        foreach (array_keys($rem) as $k) { if ($d <= 0) break; $out[$k]++; $d--; } return $out;
    }
    static function load(): void {
        if (self::present()) return; mt_srand(6001); Fr::$system = true; Fr::resetCal(); Fr::resetMap(); FrStats::resetCache(); $pdo = DB::pdo(); $own = !$pdo->inTransaction(); if ($own) $pdo->beginTransaction();
        try { $ids = self::franchises(); self::reprise($ids); self::requests($ids); self::quality($ids); self::extras($ids); if ($own) $pdo->commit(); } catch (\Throwable $e) { if ($own) $pdo->rollBack(); Fr::$system = false; throw $e; }
        Fr::$system = false; Fr::resetMap(); FrStats::resetCache();
    }
    private static function franchises(): array {
        $ids = []; $i = 0; $now = now();
        foreach (self::NAMES as $name => $zone) { $i++; $code = strtoupper(preg_replace('/[^A-Z0-9]/', '', $name)); $ok = $i % 7 !== 0;
            $id = DB::insert('fr_franchises', ['crm_id' => Fr::nextCrmId(), 'code' => $ok ? $code : null, 'code_ok' => $ok ? 1 : 0, 'name' => $name, 'zone' => $zone, 'active' => 1, 'manager' => 'Responsable ' . ucfirst(strtolower($name)), 'bo_team' => $zone === 'Grand Lomé' || $zone === 'Maritime' ? 'BO Sud' : 'BO Nord', 'phone' => '+228 90 ' . sprintf('%02d %02d %02d', $i, $i * 3 % 100, $i * 7 % 100), 'email' => strtolower(str_replace(' ', '', $name)) . '@franchise.exemple', 'address' => 'Quartier test ' . $i . ', ' . ucfirst(strtolower($name)), 'city' => ucfirst(strtolower($name)), 'effective_from' => '2024-01-01', 'is_demo' => 1, 'created_at' => $now, 'updated_at' => $now]);
            DB::insert('fr_assign', ['franchise_id' => $id, 'zone' => $zone, 'manager' => 'Responsable ' . ucfirst(strtolower($name)), 'bo_team' => $zone === 'Grand Lomé' || $zone === 'Maritime' ? 'BO Sud' : 'BO Nord', 'from_day' => '2024-01-01', 'to_day' => null, 'reason' => 'Création', 'created_at' => $now]);
            DB::insert('fr_aliases', ['franchise_id' => $id, 'alias' => $name . ' BT', 'kind' => 'bt', 'created_at' => $now]); if ($i % 3 === 0) DB::insert('fr_aliases', ['franchise_id' => $id, 'alias' => 'FR ' . $name, 'kind' => 'bt', 'created_at' => $now]); if ($i % 10 === 0) DB::insert('fr_aliases', ['franchise_id' => $id, 'alias' => 'Ancien ' . $name, 'kind' => 'former', 'created_at' => $now]);
            $ids[$name] = $id; }
        // réaffectations historisées : ADIDOME et ADETIKOPE changent de zone au 20 octobre 2026, AKEPE change de BO
        foreach (['ADIDOME' => ['Plateaux', 'BO Nord'], 'ADETIKOPE' => ['Grand Lomé', 'BO Sud']] as $n => [$z, $bo]) { DB::exec('UPDATE fr_assign SET to_day=? WHERE franchise_id=? AND to_day IS NULL', ['2026-10-19', $ids[$n]]); DB::insert('fr_assign', ['franchise_id' => $ids[$n], 'zone' => $z, 'manager' => 'Responsable ' . ucfirst(strtolower($n)), 'bo_team' => $bo, 'from_day' => '2026-10-20', 'to_day' => null, 'reason' => 'Réorganisation des zones (jeu de démonstration)', 'created_at' => $now]); DB::update('fr_franchises', ['zone' => $z, 'bo_team' => $bo], 'id=?', [$ids[$n]]); }
        $ids['ASSOLI (fermée)'] = DB::insert('fr_franchises', ['crm_id' => Fr::nextCrmId(), 'code' => 'ASSOLI', 'code_ok' => 1, 'name' => 'ASSOLI (fermée)', 'zone' => 'Maritime', 'active' => 0, 'manager' => 'Sans objet', 'bo_team' => 'BO Sud', 'effective_from' => '2023-01-01', 'effective_to' => '2026-06-30', 'note' => 'Franchise désactivée : historique conservé.', 'is_demo' => 1, 'created_at' => $now, 'updated_at' => $now]);
        return $ids;
    }
    /** Reconstitue la quinzaine du 16 au 31 octobre 2026 : BOSS et TRAITEMENT (5 761 lignes chacun), Restitution (5 097 lignes, 40 franchises). */
    private static function reprise(array $ids): void {
        $names = array_keys(self::NAMES); $nf = count($names); $w1 = ['2026-10-16', '2026-10-17', '2026-10-19', '2026-10-20', '2026-10-21', '2026-10-22']; $w2 = ['2026-10-23', '2026-10-24', '2026-10-26', '2026-10-27', '2026-10-28', '2026-10-29']; $w3 = ['2026-10-30', '2026-10-31'];
        $weights = []; foreach ($names as $i => $n) $weights[$i] = 0.5 + mt_rand(0, 100) / 70; $fixed = [[24, 28, 7], [121, 133, 30], [122, 146, 31]];
        $count = [0 => [], 1 => [], 2 => []]; foreach ([0 => 2263, 1 => 2236] as $w => $tot) { $rest = $tot; $wt = []; foreach ($fixed as $i => $f) { $count[$w][$i] = $f[$w]; $rest -= $f[$w]; } for ($i = 3; $i < $nf; $i++) $wt[$i] = $weights[$i]; foreach (self::spread($rest, $wt, 5) as $i => $c) $count[$w][$i] = $c; }
        $wt = []; for ($i = 3; $i < $nf; $i++) $wt[$i] = $weights[$i]; $rest = 598 - array_sum(array_column($fixed, 2)); foreach (self::spread($rest, $wt, 1) as $i => $c) $count[2][$i] = $c; foreach ($fixed as $i => $f) $count[2][$i] = $f[2];
        $svc = array_merge(array_fill(0, 4177, 'Changement_SIM'), array_fill(0, 548, 'Achat SIM PDV'), array_fill(0, 306, 'SIM_SWAP_4G'), array_fill(0, 66, 'PDV éligible')); shuffle($svc); $lines = []; $k = 0; $used = [];
        $iccid = function () use (&$used) { do { $x = '8922801' . sprintf('%012d', mt_rand(0, 999999999999)); } while (isset($used[$x])); $used[$x] = 1; return $x; };
        $agents = []; for ($a = 1; $a <= 24; $a++) $agents[] = 'Agent ' . $a;
        foreach ([[$w1, 0], [$w2, 1], [$w3, 2]] as [$days, $w]) foreach ($count[$w] as $i => $n) for ($j = 0; $j < $n; $j++) $lines[] = ['day' => self::pick($days), 'f' => $i, 'svc' => $svc[$k++], 'icc' => $iccid(), 'st' => 'Effectué', 'ag' => self::pick($agents), 'cust' => '9' . mt_rand(0, 1) . sprintf('%07d', mt_rand(0, 9999999))];
        $base = $lines; $alld = array_merge($w1, $w2, $w3);
        for ($j = 0; $j < 38; $j++) $lines[] = ['day' => self::pick($alld), 'f' => mt_rand(0, $nf - 1), 'svc' => self::pick(['Changement_SIM', 'Changement_SIM', 'Changement_SIM', 'Achat SIM PDV']), 'icc' => $iccid(), 'st' => 'Effectué', 'ag' => self::pick($agents), 'cust' => '9' . mt_rand(0, 1) . sprintf('%07d', mt_rand(0, 9999999))];
        $retained = $lines; $extra = [];
        for ($j = 0; $j < 7; $j++) $extra[] = ['day' => self::pick($alld), 'f' => null, 'svc' => 'Changement_SIM', 'icc' => $iccid(), 'st' => 'Effectué', 'ag' => self::pick($agents), 'cust' => '9' . mt_rand(0, 1) . sprintf('%07d', mt_rand(0, 9999999))];
        for ($j = 0; $j < 211; $j++) $extra[] = ['day' => self::pick($alld), 'f' => mt_rand(0, $nf - 1), 'svc' => self::pick(['Changement_SIM', 'Achat SIM PDV', 'SIM_SWAP_4G']), 'icc' => $iccid(), 'st' => 'Traitement non effectué', 'ag' => self::pick($agents), 'cust' => '9' . mt_rand(0, 1) . sprintf('%07d', mt_rand(0, 9999999))];
        for ($j = 0; $j < 220; $j++) $extra[] = ['day' => self::pick($alld), 'f' => mt_rand(0, $nf - 1), 'svc' => self::pick(['Autre service', 'Réclamation facture', 'Mise à jour profil']), 'icc' => $iccid(), 'st' => 'Effectué', 'ag' => self::pick($agents), 'cust' => '9' . mt_rand(0, 1) . sprintf('%07d', mt_rand(0, 9999999))];
        for ($j = 0; $j < 188; $j++) { $o = $retained[mt_rand(0, count($retained) - 1)]; $o['dup'] = 1; $extra[] = $o; }
        $all = array_merge($retained, $extra); usort($all, fn($a, $b) => [$a['day'], mt_rand()] <=> [$b['day'], mt_rand()]); $batch = DB::insert('fr_batches', ['kind' => 'reprise', 'name' => 'Reprise quinzaine 16–31 oct. 2026 (reconstitution synthétique)', 'sheets' => 'BOSS, TRAITEMENT, Restitution', 'period_from' => '2026-10-16', 'period_to' => '2026-10-31', 'rows_read' => 5761 * 2 + 5097, 'rows_ok' => 5761 * 2 + 5097, 'user_id' => null, 'is_demo' => 1, 'stats' => json_encode(['note' => 'Jeu de démonstration : volumes alignés sur le cahier des besoins, lignes générées.'], JSON_UNESCAPED_UNICODE), 'created_at' => now()]);
        $raw = function (int $i) use ($names) { $n = $names[$i]; $c = strtoupper(preg_replace('/[^A-Z0-9]/', '', $n)); return self::pick([$c, $n, $n . ' BT', 'FR ' . $n]); }; $rows = [];
        $mk = function (string $src, int $no, array $l, ?string $icc) use ($ids, $names, $batch, $raw) { $f = $l['f']; return ['batch_id' => $batch, 'source' => $src, 'sheet' => $src === 'RESTITUTION' ? 'Restitution' : $src, 'row_no' => $no, 'day' => $l['day'], 'franchise_id' => $f === null ? null : $ids[$names[$f]], 'franchise_raw' => $f === null ? null : ($l['raw'] ?? $raw($f)), 'service' => $l['svc'], 'status_label' => $l['st'], 'cust_mask' => Fr::mask($l['cust']), 'iccid' => $icc, 'agent' => $l['ag'], 'skey' => sha1($src . $no . $l['icc'] . mt_rand())]; };
        foreach ($all as $i => $l) $all[$i]['raw'] = $l['f'] === null ? null : $raw($l['f']); $diff = array_flip(array_rand($all, 12)); $no = 1; foreach ($all as $i => $l) { $no++; $rows[] = $mk('TRAITEMENT', $no, $l, $l['icc']); $b = $l['icc']; if (isset($diff[$i])) $b = substr($b, 0, -1) . (((int)substr($b, -1) + 1) % 10); $rows[] = $mk('BOSS', $no, $l, $b); }
        usort($base, fn($a, $b) => $a['day'] <=> $b['day']); foreach ($base as $i => $l) $rows[] = $mk('RESTITUTION', $i + 2, $l, $l['icc']);
        FrImport::bulk('fr_src', ['batch_id', 'source', 'sheet', 'row_no', 'day', 'franchise_id', 'franchise_raw', 'service', 'status_label', 'cust_mask', 'iccid', 'agent', 'skey'], $rows);
        DB::insert('fr_rejects', ['batch_id' => $batch, 'kind' => 'ambig', 'sheet' => 'BOSS', 'row_no' => 9, 'fld' => 'Franchise', 'val_text' => 'ADETIKOPE-2', 'reason' => 'Code inconnu du référentiel : à rattacher.', 'status' => 'open', 'created_at' => now()]);
        DB::insert('fr_rejects', ['batch_id' => $batch, 'kind' => 'warn', 'sheet' => 'TRAITEMENT', 'row_no' => 14, 'fld' => 'ICCID', 'val_text' => '8.9228E+18', 'reason' => 'ICCID enregistré en nombre : précision perdue (à ressaisir en texte).', 'status' => 'ignored', 'created_at' => now()]);
        FrImport::reconcile('2026-10-16', '2026-10-31', true);
    }
    /** Dossiers CRM des deux premières semaines de novembre : circuit complet avec horodatage de chaque transition. */
    private static function requests(array $ids): void {
        $names = array_slice(array_keys(self::NAMES), 0, 14); $cats = DB::all('SELECT * FROM fr_catalog WHERE active=1 ORDER BY id'); if (!$cats) return; $opTypes = DB::all('SELECT label FROM fr_opdict WHERE counted=1'); $now = time(); $hold = Fr::reasons('hold'); $rej = Fr::reasons('reject'); $can = Fr::reasons('cancel'); $nox = Fr::reasons('noexec');
        $days = []; for ($d = '2026-11-02'; $d <= '2026-11-13'; $d = Fr::addDays($d, 1)) if (Fr::isWork($d)) $days[] = $d; $n = 0;
        $ts = fn(string $day, int $h, int $m = 0) => $day . sprintf(' %02d:%02d:00', $h, $m); $cap = fn(string $t) => strtotime($t) > $now ? date('Y-m-d H:i:s', $now - 60) : $t;
        foreach ($days as $di => $day) for ($j = 0; $j < 12; $j++) {
            $n++; $cat = self::pick($cats); $fn = self::pick($names); $h = mt_rand(8, 15); $created = $cap($ts($day, $h, mt_rand(0, 59))); $iccid = '8922801' . sprintf('%012d', mt_rand(0, 999999999999));
            [$id, $err] = Fr::create(['franchise_id' => $ids[$fn], 'catalog_id' => $cat['id'], 'created_at' => $created, 'reporter' => 'Agent ' . mt_rand(1, 24), 'channel' => self::pick(['crm', 'store', 'phone', 'whatsapp']), 'priority' => self::pick(['normal', 'normal', 'normal', 'high', 'low', 'urgent']), 'team' => self::pick(['BO Sud', 'BO Nord']),
                'customer_no' => '90' . sprintf('%06d', mt_rand(0, 999999)), 'customer_name' => 'Client test ' . $n, 'iccid' => $iccid, 'id_proof' => 'CNI test ' . mt_rand(100000, 999999), 'owner_doc' => 'Justificatif test', 'agent_doc' => 'Mandat test', 'is_demo' => 1, 'comment' => 'Dossier de démonstration']);
            if (!$id) continue; $r = mt_rand(1, 100); $t1 = $cap(date('Y-m-d H:i:s', strtotime($created) + mt_rand(20, 180) * 60));
            $ops = fn() => ['op_type' => [self::pick($opTypes)['label']], 'op_ref' => ['']];
            if ($r <= 48) { Fr::act($id, 'take', [], $t1); $t2 = $cap(date('Y-m-d H:i:s', strtotime($t1) + ($r % 7 === 0 ? mt_rand(2600, 6500) : mt_rand(30, 1500)) * 60)); Fr::act($id, 'execute', ['action_done' => 'Opération réalisée dans le CRM', 'executed_at' => $t2] + $ops(), $t2); if ($r <= 3) { Fr::act($id, 'reopen', ['note' => 'Réclamation du client : SIM non activée.'], $cap(date('Y-m-d H:i:s', strtotime($t2) + 86400))); } }
            elseif ($r <= 60) { Fr::act($id, 'take', [], $t1); $t2 = $cap(date('Y-m-d H:i:s', strtotime($t1) + 3600)); Fr::act($id, 'hold', ['reason_id' => self::pick($hold)['id'], 'wait_owner' => 'Franchise', 'wait_action' => 'Transmettre le justificatif demandé'], $t2); $t3 = $cap(date('Y-m-d H:i:s', strtotime($t2) + mt_rand(3, 30) * 3600)); Fr::act($id, 'resume', ['note' => 'Justificatif transmis'], $t3); $t4 = $cap(date('Y-m-d H:i:s', strtotime($t3) + mt_rand(30, 600) * 60)); Fr::act($id, 'execute', ['action_done' => 'Opération réalisée après complément', 'executed_at' => $t4] + $ops(), $t4); }
            elseif ($r <= 68) { Fr::act($id, 'take', [], $t1); Fr::act($id, 'reject', ['reason_id' => self::pick($rej)['id'], 'note' => 'Pièces non conformes'], $cap(date('Y-m-d H:i:s', strtotime($t1) + 3600))); }
            elseif ($r <= 72) { Fr::act($id, 'cancel', ['reason_id' => self::pick($can)['id'], 'note' => 'Demande retirée'], $cap(date('Y-m-d H:i:s', strtotime($created) + 7200))); }
            elseif ($r <= 78) { Fr::act($id, 'take', [], $t1); Fr::act($id, 'noexec', ['reason_id' => self::pick($nox)['id'], 'note' => 'Échec technique côté plateforme'], $cap(date('Y-m-d H:i:s', strtotime($t1) + 5400))); }
            elseif ($r <= 88) { Fr::act($id, 'take', [], $t1); $t2 = $cap(date('Y-m-d H:i:s', strtotime($t1) + 3600)); Fr::act($id, 'hold', ['reason_id' => self::pick($hold)['id'], 'wait_owner' => 'Franchise', 'wait_action' => 'Transmettre la pièce d\'identité lisible'], $t2); }
            elseif ($r <= 95) { Fr::act($id, 'take', [], $t1); if ($r > 92) Fr::act($id, 'escalate', ['note' => 'Client en attente depuis plusieurs jours'], $cap(date('Y-m-d H:i:s', strtotime($t1) + 7200))); }
        }
    }
    private static function quality(array $ids): void {
        $names = array_slice(array_keys(self::NAMES), 0, 12); $reasons = ['Pièce d\'identité illisible', 'ICCID mal saisi', 'Justificatif manquant', 'Procédure non suivie']; $rows = [];
        foreach ($names as $i => $n) for ($d = '2026-10-05'; $d <= '2026-11-09'; $d = Fr::addDays($d, 7)) { $c = mt_rand(10, 40); $nc = mt_rand(0, max(1, intdiv($c, 8))); $max = $c * 10; $rows[] = ['franchise_id' => $ids[$n], 'day' => $d, 'scope' => $i % 3 === 0 ? 'BO' : 'FO', 'controls' => $c, 'nonconform' => $nc, 'points_got' => $max - $nc * mt_rand(4, 10), 'points_max' => $max, 'reason' => $nc ? self::pick($reasons) : null, 'plan_ref' => null, 'source' => 'Grille qualité franchises (démonstration)', 'is_demo' => 1]; }
        FrImport::bulk('fr_qc', ['franchise_id', 'day', 'scope', 'controls', 'nonconform', 'points_got', 'points_max', 'reason', 'plan_ref', 'source', 'is_demo'], $rows);
    }
    private static function extras(array $ids): void {
        $a = $ids['ADETA']; $b = $ids['ADETIKOPE']; $c = $ids['ADIDOME'];
        DB::insert('fr_compare_cfg', ['name' => 'Octobre — deux fenêtres de sept jours (3 franchises)', 'mode' => 'periods', 'config' => json_encode(['measure' => 'rest', 'a_from' => '2026-10-16', 'a_to' => '2026-10-22', 'b_from' => '2026-10-23', 'b_to' => '2026-10-29', 'fr' => [$a, $b, $c], 'grain' => 'day'], JSON_UNESCAPED_UNICODE), 'user_id' => null, 'shared' => 1, 'created_at' => now()]);
        DB::insert('fr_compare_cfg', ['name' => 'ADIDOME — trois fenêtres non contiguës', 'mode' => 'windows', 'config' => json_encode(['measure' => 'rest', 'fr' => $c, 'windows' => [['n' => 'Fenêtre 1', 'from' => '2026-10-16', 'to' => '2026-10-19'], ['n' => 'Fenêtre 2', 'from' => '2026-10-23', 'to' => '2026-10-26'], ['n' => 'Fenêtre 3', 'from' => '2026-10-29', 'to' => '2026-10-31']], 'grain' => 'day'], JSON_UNESCAPED_UNICODE), 'user_id' => null, 'shared' => 1, 'created_at' => now()]);
        FrReport::generate('2026-10', 'reprise', null, 'jeu de démonstration');
    }
    /** Retire le jeu de démonstration (les référentiels de service — catalogue, motifs, dictionnaire, règles — sont conservés). */
    static function remove(): void {
        $pdo = DB::pdo(); $own = !$pdo->inTransaction(); if ($own) $pdo->beginTransaction();
        try {
            $reqs = "SELECT id FROM fr_requests WHERE is_demo=1"; DB::exec("DELETE FROM fr_events WHERE request_id IN ($reqs)"); DB::exec("DELETE FROM fr_alert_log WHERE request_id IN ($reqs)"); DB::exec('DELETE FROM fr_ops WHERE is_demo=1'); DB::exec('DELETE FROM fr_requests WHERE is_demo=1');
            $b = 'SELECT id FROM fr_batches WHERE is_demo=1'; DB::exec("DELETE FROM fr_src WHERE batch_id IN ($b)"); DB::exec("DELETE FROM fr_rejects WHERE batch_id IN ($b)"); DB::exec('DELETE FROM fr_batches WHERE is_demo=1');
            DB::exec('DELETE FROM fr_qc WHERE is_demo=1'); DB::exec('DELETE FROM fr_report_log WHERE report_id IN (SELECT id FROM fr_reports WHERE is_demo=1)'); DB::exec('DELETE FROM fr_reports WHERE is_demo=1'); DB::exec('DELETE FROM fr_compare_cfg WHERE user_id IS NULL');
            $f = 'SELECT id FROM fr_franchises WHERE is_demo=1'; foreach (['fr_aliases', 'fr_assign', 'fr_access'] as $t) DB::exec("DELETE FROM $t WHERE franchise_id IN ($f)"); DB::exec('DELETE FROM fr_franchises WHERE is_demo=1'); if ($own) $pdo->commit();
        } catch (\Throwable $e) { if ($own) $pdo->rollBack(); throw $e; }
        Fr::resetMap(); FrStats::resetCache();
    }
}
