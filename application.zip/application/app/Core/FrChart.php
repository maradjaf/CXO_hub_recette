<?php
namespace App\Core;

/**
 * Lot 60 — Franchises : graphiques SVG sans bibliothèque (courbes avec interruptions, barres, barres jumelées, cascade, Pareto, carte de contrôle p, carte thermique).
 * Chaque visuel est accompagné d'un tableau accessible (« Valeurs du graphique ») et d'états explicites : zéro, donnée absente, période partielle.
 */
final class FrChart {
    const COL = ['#003A84', '#D97706', '#0E9F6E', '#B42318', '#7C3AED', '#0891B2', '#64748B', '#DB2777'];
    private static function nice(float $max): float { if ($max <= 0) return 1; $p = 10 ** floor(log10($max)); foreach ([1, 2, 2.5, 5, 10] as $m) if ($m * $p >= $max) return $m * $p; return 10 * $p; }
    private static function f($v, string $u = ''): string { return $v === null ? '—' : ($u === '%' ? Fr::dec($v) . ' %' : ($u === 'h' ? Fr::dec($v) . ' h' : (abs($v - round($v)) < 0.005 ? Fr::n($v) : Fr::dec($v)))); }
    static function state(?array $p): string {
        if (!$p) return 'Donnée absente'; $s = $p['state'] ?? 'ok'; if ($s === 'unavailable') return 'Donnée indisponible'; if ($s === 'na') return 'Non calculable'; if ($s === 'nodata') return 'Jour sans donnée'; if (($p['v'] ?? null) === null) return 'Donnée absente'; return !empty($p['partial']) ? 'Période partielle' : '';
    }
    static function legend(array $items): string { return '<div class="d-flex flex-wrap gap-3 small text-muted my-1">' . implode('', array_map(fn($i) => '<span><i style="display:inline-block;width:11px;height:11px;border-radius:2px;background:' . $i[1] . ';margin-right:5px"></i>' . e($i[0]) . '</span>', $items)) . '</div>'; }
    private static function details(array $head, array $rows): string { return '<details class="voc-disclose"><summary>Valeurs du graphique</summary>' . Voc::table($head, $rows) . '</details>'; }

    /** Courbes. $series : [['name','color','dashed','points'=>[?array{v,n,state,partial}]]] ; o : unit, range, target, threshold, label, h */
    static function line(array $labels, array $series, array $o = []): string {
        $n = count($labels); if (!$n || !$series) return '<p class="text-muted small my-3">Aucune période à afficher.</p>'; $u = $o['unit'] ?? ''; $vals = [];
        foreach ($series as $s) foreach ($s['points'] as $p) if ($p && $p['v'] !== null) $vals[] = $p['v']; foreach (['target', 'threshold'] as $k) if (isset($o[$k])) $vals[] = $o[$k];
        $lo = $o['range'][0] ?? 0; $hi = $o['range'][1] ?? self::nice((float)max($vals ?: [1])); if ($hi <= $lo) $hi = $lo + 1; $W = 640; $H = $o['h'] ?? 240; $l = 46; $r = $W - 14; $t = 12; $b = $H - 34;
        $x = fn($i) => $n === 1 ? ($l + $r) / 2 : $l + $i * ($r - $l) / ($n - 1); $y = fn($v) => $b - (min($hi, max($lo, $v)) - $lo) / ($hi - $lo) * ($b - $t);
        $svg = '<svg viewBox="0 0 ' . $W . ' ' . $H . '" class="w-100 fr-chart" role="img" aria-label="' . e($o['label'] ?? 'Courbe') . '" style="font:11px system-ui,sans-serif">';
        for ($j = 0; $j <= 4; $j++) { $v = $lo + ($hi - $lo) * $j / 4; $yy = round($y($v), 1); $svg .= '<line x1="' . $l . '" x2="' . $r . '" y1="' . $yy . '" y2="' . $yy . '" stroke="#E3E9F1"/><text x="' . ($l - 6) . '" y="' . ($yy + 4) . '" text-anchor="end" fill="#536782">' . e(self::f($v, $u === '%' ? '' : $u)) . '</text>'; }
        $stride = (int)ceil($n / max(2, floor(($r - $l) / 62))); foreach ($labels as $i => $lb) { if ($i % $stride && $i !== $n - 1) continue; if ($i !== 0 && $i !== $n - 1 && $n - 1 - $i < $stride * .6) continue; $svg .= '<text x="' . round($x($i), 1) . '" y="' . ($b + 18) . '" text-anchor="' . ($n === 1 ? 'middle' : ($i === 0 ? 'start' : ($i === $n - 1 ? 'end' : 'middle'))) . '" fill="#536782">' . e($lb) . '</text>'; }
        foreach (['target' => ['#0E9F6E', 'Objectif'], 'threshold' => ['#B42318', 'Seuil']] as $k => [$c, $nm]) if (isset($o[$k])) { $yy = round($y($o[$k]), 1); $svg .= '<line x1="' . $l . '" x2="' . $r . '" y1="' . $yy . '" y2="' . $yy . '" stroke="' . $c . '" stroke-dasharray="6 4" stroke-width="1.5"/><text x="' . $r . '" y="' . ($yy - 4) . '" text-anchor="end" fill="' . $c . '">' . $nm . ' ' . e(self::f($o[$k], $u)) . '</text>'; }
        foreach ($series as $k => $s) { $d = ''; $on = false; $dots = '';
            foreach ($s['points'] as $i => $p) {
                if (!$p || $p['v'] === null) { $on = false; if ($p && ($p['state'] ?? '') === 'nodata') $dots .= '<rect x="' . round($x($i) - 3, 1) . '" y="' . ($b - 4) . '" width="6" height="4" fill="#AAB4C3"><title>' . e($s['name'] . ' · ' . $labels[$i] . ' · jour sans donnée') . '</title></rect>'; continue; }
                $xx = round($x($i), 1); $yy = round($y($p['v']), 1); $d .= ($on ? 'L' : 'M') . $xx . ' ' . $yy; $on = true; $tip = '<title>' . e($s['name'] . ' · ' . $labels[$i] . ' · ' . self::f($p['v'], $u) . (isset($p['n']) && $p['n'] !== null ? ' · effectif ' . Fr::n($p['n']) : '') . (!empty($p['partial']) ? ' · période partielle' : '')) . '</title>';
                $fill = !empty($p['partial']) ? '#fff' : $s['color']; $dots .= $k % 2 ? '<rect x="' . ($xx - 3.4) . '" y="' . ($yy - 3.4) . '" width="6.8" height="6.8" fill="' . $fill . '" stroke="' . $s['color'] . '" stroke-width="1.6">' . $tip . '</rect>' : '<circle cx="' . $xx . '" cy="' . $yy . '" r="3.6" fill="' . $fill . '" stroke="' . $s['color'] . '" stroke-width="1.6">' . $tip . '</circle>'; }
            $svg .= '<path d="' . $d . '" fill="none" stroke="' . $s['color'] . '" stroke-width="2.4" stroke-linejoin="round"' . (!empty($s['dashed']) ? ' stroke-dasharray="5 4"' : '') . '/>' . $dots; }
        $svg .= '</svg>'; $rows = [];
        foreach ($labels as $i => $lb) { $row = [e($lb)]; foreach ($series as $s) { $p = $s['points'][$i] ?? null; $st = self::state($p); $row[] = ($p && $p['v'] !== null ? e(self::f($p['v'], $u)) : '—') . ($st !== '' ? '<small class="d-block text-muted">' . e($st) . '</small>' : '') . ($p && isset($p['n']) && $p['n'] !== null && $p['v'] !== null ? '<small class="d-block text-muted">effectif ' . Fr::n($p['n']) . '</small>' : ''); } $rows[] = $row; }
        return $svg . self::legend(array_map(fn($s) => [$s['name'], $s['color']], $series)) . self::details(array_merge(['Période'], array_map(fn($s) => e($s['name']), $series)), $rows);
    }
    /** Barres verticales groupées ou empilées. $series : [['name','color','values'=>[float|null]]]. */
    static function bars(array $labels, array $series, array $o = []): string {
        $n = count($labels); if (!$n || !$series) return '<p class="text-muted small my-3">Aucune donnée à afficher.</p>'; $stack = !empty($o['stack']); $u = $o['unit'] ?? ''; $W = 640; $H = $o['h'] ?? 240; $l = 46; $r = $W - 14; $t = 12; $b = $H - 40; $max = 0;
        for ($i = 0; $i < $n; $i++) { $sum = 0; foreach ($series as $s) { $v = (float)($s['values'][$i] ?? 0); $sum += $v; if (!$stack) $max = max($max, $v); } if ($stack) $max = max($max, $sum); } $hi = self::nice($max ?: 1); $y = fn($v) => $b - $v / $hi * ($b - $t); $bw = ($r - $l) / $n; $k = count($series);
        $svg = '<svg viewBox="0 0 ' . $W . ' ' . $H . '" class="w-100 fr-chart" role="img" aria-label="' . e($o['label'] ?? 'Barres') . '" style="font:11px system-ui,sans-serif">';
        for ($j = 0; $j <= 4; $j++) { $v = $hi * $j / 4; $yy = round($y($v), 1); $svg .= '<line x1="' . $l . '" x2="' . $r . '" y1="' . $yy . '" y2="' . $yy . '" stroke="#E3E9F1"/><text x="' . ($l - 6) . '" y="' . ($yy + 4) . '" text-anchor="end" fill="#536782">' . e(self::f($v, $u === '%' ? '' : $u)) . '</text>'; }
        $stride = (int)ceil($n / max(2, floor(($r - $l) / 54)));
        for ($i = 0; $i < $n; $i++) { $x0 = $l + $i * $bw; $acc = 0;
            foreach ($series as $si => $s) { $v = $s['values'][$i] ?? null; if ($v === null) continue; $v = (float)$v; $w = $stack ? $bw * .62 : $bw * .78 / $k; $xx = $stack ? $x0 + $bw * .19 : $x0 + $bw * .11 + $si * $w; $h = $v / $hi * ($b - $t); $yy = $stack ? $y($acc + $v) : $b - $h; $acc += $v;
                $svg .= '<rect x="' . round($xx, 1) . '" y="' . round($yy, 1) . '" width="' . round($w - 1, 1) . '" height="' . round(max(0, $h), 1) . '" fill="' . ($s['color'] ?? self::COL[$si % 8]) . '"><title>' . e($s['name'] . ' · ' . $labels[$i] . ' · ' . self::f($v, $u)) . '</title></rect>'; }
            if ($i % $stride === 0) $svg .= '<text x="' . round($x0 + $bw / 2, 1) . '" y="' . ($b + 16) . '" text-anchor="middle" fill="#536782">' . e(mb_strimwidth($labels[$i], 0, 12, '…')) . '</text>'; }
        $svg .= '</svg>'; $rows = []; foreach ($labels as $i => $lb) { $row = [e($lb)]; foreach ($series as $s) $row[] = isset($s['values'][$i]) && $s['values'][$i] !== null ? e(self::f($s['values'][$i], $u)) : '—'; $rows[] = $row; }
        return $svg . self::legend(array_map(fn($s, $i) => [$s['name'], $s['color'] ?? self::COL[$i % 8]], $series, array_keys($series))) . self::details(array_merge(['Libellé'], array_map(fn($s) => e($s['name']), $series)), $rows);
    }
    /** Barres horizontales jumelées A/B. $rows : [['label','a','b','href'?]]. */
    static function hbars(array $rows, string $na, string $nb, array $o = []): string {
        if (!$rows) return '<p class="text-muted small my-3">Aucune ligne à comparer.</p>'; $u = $o['unit'] ?? ''; $max = 0; foreach ($rows as $r) $max = max($max, (float)$r['a'], (float)$r['b']); $max = $max ?: 1; $h = '<div class="fr-hb" role="img" aria-label="' . e($o['label'] ?? 'Comparaison') . '">'; $t = [];
        foreach ($rows as $r) { $lab = $r['href'] ?? null ? '<a href="' . e($r['href']) . '">' . e($r['label']) . '</a>' : e($r['label']);
            $h .= '<div class="fr-hb-row"><div class="fr-hb-l">' . $lab . '</div><div class="fr-hb-b">' . self::hb($r['a'], $max, self::COL[0], $na, $u) . self::hb($r['b'], $max, self::COL[1], $nb, $u) . '</div></div>'; $t[] = [$lab, e(self::f($r['a'], $u)), e(self::f($r['b'], $u))]; }
        return $h . '</div>' . self::legend([[$na, self::COL[0]], [$nb, self::COL[1]]]) . self::details(['Libellé', e($na), e($nb)], $t);
    }
    private static function hb($v, float $max, string $c, string $name, string $u): string { return $v === null ? '<div class="fr-hb-v text-muted small">—</div>' : '<div class="fr-hb-v" title="' . e($name . ' : ' . self::f($v, $u)) . '"><i style="width:' . round(100 * (float)$v / $max, 1) . '%;background:' . $c . '"></i><span>' . e(self::f($v, $u)) . '</span></div>'; }
    /** Cascade des contributions : valeur A, contributions, valeur B. $steps : [['label','diff']]. */
    static function waterfall(float $a, float $b, array $steps, string $la, string $lb): string {
        $items = [['label' => $la, 'tot' => $a]]; foreach ($steps as $s) $items[] = ['label' => $s['label'], 'diff' => (float)$s['diff']]; $items[] = ['label' => $lb, 'tot' => $b]; $n = count($items); $run = 0; $lo = 0; $hi = 0;
        foreach ($items as &$it) { if (isset($it['tot'])) { $it['from'] = 0; $it['to'] = $it['tot']; $run = $it['tot']; } else { $it['from'] = $run; $run += $it['diff']; $it['to'] = $run; } $lo = min($lo, $it['from'], $it['to']); $hi = max($hi, $it['from'], $it['to']); } unset($it);
        $hi = self::nice($hi ?: 1); $W = 640; $H = 250; $l = 46; $r = $W - 14; $t = 14; $bt = $H - 56; $y = fn($v) => $bt - ($v - $lo) / ($hi - $lo) * ($bt - $t); $bw = ($r - $l) / $n;
        $svg = '<svg viewBox="0 0 ' . $W . ' ' . $H . '" class="w-100 fr-chart" role="img" aria-label="Cascade des contributions à l\'écart" style="font:11px system-ui,sans-serif"><line x1="' . $l . '" x2="' . $r . '" y1="' . round($y(0), 1) . '" y2="' . round($y(0), 1) . '" stroke="#AAB4C3"/>'; $rows = [];
        foreach ($items as $i => $it) { $x = $l + $i * $bw + $bw * .15; $w = $bw * .7; $y1 = $y(max($it['from'], $it['to'])); $y2 = $y(min($it['from'], $it['to'])); $c = isset($it['tot']) ? self::COL[0] : ($it['diff'] >= 0 ? '#0E9F6E' : '#B42318'); $v = $it['tot'] ?? $it['diff'];
            $svg .= '<rect x="' . round($x, 1) . '" y="' . round($y1, 1) . '" width="' . round($w, 1) . '" height="' . round(max(1, $y2 - $y1), 1) . '" fill="' . $c . '"><title>' . e($it['label'] . ' : ' . (isset($it['tot']) ? self::f($v) : Fr::sgn($v))) . '</title></rect><text x="' . round($x + $w / 2, 1) . '" y="' . round($y1 - 4, 1) . '" text-anchor="middle" fill="#1F2D3D">' . e(isset($it['tot']) ? self::f($v) : Fr::sgn($v)) . '</text><text x="' . round($x + $w / 2, 1) . '" y="' . ($H - 36) . '" text-anchor="middle" fill="#536782" transform="rotate(28 ' . round($x + $w / 2, 1) . ' ' . ($H - 36) . ')">' . e(mb_strimwidth($it['label'], 0, 14, '…')) . '</text>'; $rows[] = [e($it['label']), isset($it['tot']) ? 'Total' : 'Contribution', e(isset($it['tot']) ? self::f($v) : Fr::sgn($v))]; }
        return $svg . '</svg>' . self::details(['Étape', 'Nature', 'Valeur'], $rows);
    }
    /** Pareto : barres décroissantes et part cumulée. $items : [['label','n']]. */
    static function pareto(array $items, string $title = 'Pareto'): string {
        $tot = array_sum(array_column($items, 'n')); if (!$items || $tot <= 0) return '<p class="text-muted small my-3">Aucun motif sur cette période.</p>'; usort($items, fn($a, $b) => $b['n'] <=> $a['n']); $n = count($items); $W = 640; $H = 240; $l = 46; $r = $W - 40; $t = 14; $b = $H - 62; $max = self::nice((float)$items[0]['n']); $bw = ($r - $l) / $n; $cum = 0; $pts = []; $rows = [];
        $svg = '<svg viewBox="0 0 ' . $W . ' ' . $H . '" class="w-100 fr-chart" role="img" aria-label="' . e($title) . '" style="font:11px system-ui,sans-serif">'; for ($j = 0; $j <= 4; $j++) { $yy = $b - ($b - $t) * $j / 4; $svg .= '<line x1="' . $l . '" x2="' . $r . '" y1="' . round($yy, 1) . '" y2="' . round($yy, 1) . '" stroke="#E3E9F1"/><text x="' . ($l - 6) . '" y="' . round($yy + 4, 1) . '" text-anchor="end" fill="#536782">' . Fr::n($max * $j / 4) . '</text><text x="' . ($r + 6) . '" y="' . round($yy + 4, 1) . '" fill="#B42318">' . ($j * 25) . ' %</text>'; }
        foreach ($items as $i => $it) { $x = $l + $i * $bw + $bw * .15; $h = $it['n'] / $max * ($b - $t); $cum += $it['n']; $cx = $x + $bw * .35; $cy = $b - $cum / $tot * ($b - $t); $pts[] = round($cx, 1) . ',' . round($cy, 1);
            $svg .= '<rect x="' . round($x, 1) . '" y="' . round($b - $h, 1) . '" width="' . round($bw * .7, 1) . '" height="' . round($h, 1) . '" fill="' . self::COL[0] . '"><title>' . e($it['label'] . ' : ' . Fr::n($it['n']) . ' (' . Fr::dec($it['n'] / $tot * 100) . ' %)') . '</title></rect><circle cx="' . round($cx, 1) . '" cy="' . round($cy, 1) . '" r="3" fill="#B42318"/><text x="' . round($x + $bw * .35, 1) . '" y="' . ($H - 44) . '" text-anchor="end" fill="#536782" transform="rotate(-30 ' . round($x + $bw * .35, 1) . ' ' . ($H - 44) . ')">' . e(mb_strimwidth($it['label'], 0, 22, '…')) . '</text>'; $rows[] = [e($it['label']), Fr::n($it['n']), e(Fr::dec($it['n'] / $tot * 100) . ' %'), e(Fr::dec($cum / $tot * 100) . ' %')]; }
        return $svg . '<polyline points="' . implode(' ', $pts) . '" fill="none" stroke="#B42318" stroke-width="2"/></svg>' . self::legend([['Volume', self::COL[0]], ['Part cumulée', '#B42318']]) . self::details(['Motif', 'Volume', 'Part', 'Part cumulée'], $rows);
    }
    /** Carte de contrôle p : points [label, num, den] ; limites à ± 3 σ selon l'effectif de chaque point. Exige au moins 8 points d'effectif ≥ $minN. */
    static function pchart(array $pts, int $minN = 10): string {
        $ok = array_values(array_filter($pts, fn($p) => $p['den'] >= $minN)); if (count($ok) < 8) return '<p class="text-muted small my-3">Carte de contrôle non calculable : au moins 8 points d\'effectif ≥ ' . $minN . ' sont nécessaires (' . count($ok) . ' disponibles).</p>';
        $N = array_sum(array_column($ok, 'num')); $D = array_sum(array_column($ok, 'den')); $pb = $D > 0 ? $N / $D : 0; $labels = array_column($ok, 'label'); $mk = []; $up = []; $lw = [];
        foreach ($ok as $i => $p) { $pi = $p['num'] / $p['den']; $sd = sqrt(max(0, $pb * (1 - $pb)) / $p['den']); $mk[] = ['v' => round($pi * 100, 2), 'n' => (int)$p['den'], 'state' => 'ok']; $up[] = ['v' => round(min(1, $pb + 3 * $sd) * 100, 2), 'n' => null, 'state' => 'ok']; $lw[] = ['v' => round(max(0, $pb - 3 * $sd) * 100, 2), 'n' => null, 'state' => 'ok']; }
        return self::line($labels, [['name' => 'Taux de non-conformité', 'color' => self::COL[0], 'points' => $mk], ['name' => 'Limite haute (3 σ)', 'color' => '#B42318', 'dashed' => true, 'points' => $up], ['name' => 'Limite basse (3 σ)', 'color' => '#0E9F6E', 'dashed' => true, 'points' => $lw]], ['unit' => '%', 'target' => round($pb * 100, 2), 'label' => 'Carte de contrôle p']) . '<p class="small text-muted mb-0">Ligne centrale : ' . e(Fr::dec($pb * 100)) . ' % sur ' . Fr::n($D) . ' contrôles.</p>';
    }
    /** Carte thermique en tableau : $cells[r][c] = ['v','n','href'?,'t'?] ; $good = 'high' (haut = bon) ou 'low' (haut = mauvais). */
    static function heat(array $rowLabels, array $colLabels, array $cells, string $u, string $good = 'high', ?float $max = null, string $rowHead = 'Franchise'): string {
        if (!$rowLabels || !$colLabels) return '<p class="text-muted small my-3">Aucune donnée à afficher.</p>'; $vals = []; foreach ($cells as $r) foreach ($r as $c) if ($c && $c['v'] !== null) $vals[] = $c['v']; $lo = $vals ? min($vals) : 0; $hi = $max ?? ($vals ? max($vals) : 1); if ($hi <= $lo) $hi = $lo + 1;
        $h = '<div class="table-responsive"><table class="table table-sm table-bordered fr-heat align-middle mb-1"><thead><tr><th scope="col">' . e($rowHead) . '</th>' . implode('', array_map(fn($c) => '<th scope="col" class="text-center small fw-normal">' . e($c) . '</th>', $colLabels)) . '</tr></thead><tbody>';
        foreach ($rowLabels as $ri => $rl) { $h .= '<tr><th scope="row" class="fw-normal text-nowrap">' . $rl . '</th>';
            foreach ($colLabels as $ci => $_) { $c = $cells[$ri][$ci] ?? null; if (!$c || $c['v'] === null) { $h .= '<td class="text-center text-muted small" title="' . e(self::state($c) ?: 'Donnée absente') . '">—</td>'; continue; }
                $q = ($c['v'] - $lo) / ($hi - $lo); $bad = $good === 'high' ? 1 - $q : $q; $bg = sprintf('rgb(%d,%d,%d)', 255 - (int)(40 * $bad), 255 - (int)(150 * $bad) , 255 - (int)(190 * $bad)); $txt = e(self::f($c['v'], $u)) . (isset($c['n']) ? '<small class="d-block text-muted" style="font-size:.68rem">n=' . Fr::n($c['n']) . '</small>' : '');
                $h .= '<td class="text-center small" style="background:' . $bg . '" title="' . e(($c['t'] ?? '') . ' ' . self::f($c['v'], $u) . (isset($c['n']) ? ' · effectif ' . Fr::n($c['n']) : '')) . '">' . (!empty($c['href']) ? '<a class="text-decoration-none text-body" href="' . e($c['href']) . '">' . $txt . '</a>' : $txt) . '</td>'; }
            $h .= '</tr>'; }
        return $h . '</tbody></table></div><p class="small text-muted mb-0">Couleur : plus la teinte est foncée, plus la valeur est ' . ($good === 'high' ? 'faible (moins bon)' : 'élevée (moins bon)') . '. La valeur et l\'effectif sont écrits dans chaque case.</p>';
    }
}
