<?php
namespace App\Core;
/** Capacitaire : besoin en effectifs d'une unité à partir des flux, de la productivité et des hypothèses d'un scénario. */
class Cap {
    /** Hypothèses : clé => [libellé, unité, défaut (réglage), min, max, niveau 'g' global / 'u' aussi par unité] */
    const HYP = [
        'growth_pct' => ['Croissance mensuelle du volume', '% / mois', null, -50, 100, 'u'],
        'aht_delta_pct' => ['Variation de la durée de traitement', '%', null, -50, 100, 'u'],
        'prod_delta_pct' => ['Variation de la productivité (boutiques, support)', '%', null, -50, 100, 'u'],
        'prod_per_hour' => ['Productivité de référence (opérations par heure et agent) — vide : observée', 'op/h', null, 0, 1000, 'u'],
        'shrinkage_pct' => ['Perte de capacité : pauses, formation, réunions', '%', 'pl.shrinkage', 0, 80, 'u'],
        'absenteeism_pct' => ['Absentéisme', '%', null, 0, 60, 'u'],
        'sl_target' => ['Objectif de taux de service', '%', 'pl.t_sl', 1, 100, 'u'],
        'sl_threshold' => ['Seuil du taux de service', 's', 'pl.sl_threshold', 1, 600, 'u'],
        'occ_max' => ['Occupation maximale', '%', null, 30, 100, 'u'],
        'fte_hours' => ['Heures hebdomadaires par ETP', 'h', null, 10, 60, 'u'],
    ];
    const DEFAULT = ['shrinkage_pct' => 25, 'sl_target' => 80, 'sl_threshold' => 20, 'growth_pct' => 0, 'aht_delta_pct' => 0, 'prod_delta_pct' => 0, 'absenteeism_pct' => 5, 'occ_max' => 85, 'fte_hours' => 40];

    static function scenario(int $id): ?array { return DB::one('SELECT * FROM pl_scenarios WHERE id=?', [$id]); }
    static function scenarios(): array { return DB::all("SELECT * FROM pl_scenarios WHERE status<>'archived' ORDER BY is_base DESC, id"); }
    /** Hypothèses effectives : défauts, puis valeurs globales du scénario, puis surcharges de l'unité. */
    static function params(int $scen, ?array $u = null): array {
        $p = []; foreach (self::HYP as $k => $m) { $d = $m[2] ? setting($m[2], self::DEFAULT[$k]) : (self::DEFAULT[$k] ?? null); $p[$k] = $d === null ? null : (float)$d; }
        if ($u) $p['sl_target'] = Pl::targets($u)['sl'];
        foreach (DB::all('SELECT unit_type, unit_id, hkey, value FROM pl_hypotheses WHERE scenario_id=?', [$scen]) as $h) if ($h['unit_type'] === null || $h['unit_type'] === '') $p[$h['hkey']] = (float)$h['value'];
        if ($u) foreach (DB::all('SELECT hkey, value FROM pl_hypotheses WHERE scenario_id=? AND unit_type=? AND unit_id=?', [$scen, $u['type'], $u['id']]) as $h) $p[$h['hkey']] = (float)$h['value'];
        return $p;
    }
    static function globalValues(int $scen): array { $o = []; foreach (DB::all("SELECT hkey, value FROM pl_hypotheses WHERE scenario_id=? AND (unit_type IS NULL OR unit_type='')", [$scen]) as $h) $o[$h['hkey']] = (float)$h['value']; return $o; }
    static function unitOverrides(int $scen): array { return DB::all("SELECT * FROM pl_hypotheses WHERE scenario_id=? AND unit_type IS NOT NULL AND unit_type<>'' ORDER BY unit_type, unit_id, hkey", [$scen]); }
    static function events(int $scen): array { return DB::all('SELECT * FROM pl_events WHERE scenario_id=? ORDER BY date_from', [$scen]); }

    /** Historique de 56 jours : volume moyen par jour de semaine, DMT, profil horaire, productivité observée. */
    static function history(array $u): array {
        $from = date('Y-m-d', strtotime('-56 days')); $to = date('Y-m-d'); $vol = []; $a = 0.0; $h = 0;
        foreach (DB::all('SELECT day, offered, handled, aht_sec FROM pl_stats WHERE unit_type=? AND unit_id=? AND day>=? AND day<?', [$u['type'], $u['id'], $from, $to]) as $r) { $vol[(int)date('N', strtotime($r['day']))][] = (int)$r['offered']; $a += (float)$r['aht_sec'] * (int)$r['handled']; $h += (int)$r['handled']; }
        $dayTot = []; $hr = []; foreach (DB::all('SELECT day, hour, offered FROM pl_flows WHERE unit_type=? AND unit_id=? AND day>=? AND day<?', [$u['type'], $u['id'], $from, $to]) as $r) { $n = (int)date('N', strtotime($r['day'])); $dayTot[$n][$r['day']] = ($dayTot[$n][$r['day']] ?? 0) + (int)$r['offered']; $hr[$n][(int)$r['hour']][$r['day']] = (int)$r['offered']; }
        $prof = []; $flowDays = 0;
        foreach ($hr as $n => $hours) { $days = count($dayTot[$n]); if ($days < 2) continue; $flowDays += $days; $sum = array_sum(array_map('array_sum', $hours)); if ($sum <= 0) continue; for ($x = 0; $x < 24; $x++) $prof[$n][$x] = isset($hours[$x]) ? array_sum($hours[$x]) / $sum : 0.0; }
        $pr = DB::one('SELECT COALESCE(SUM(a.handled),0) h, COALESCE(SUM(a.logged_min),0) m FROM pl_agent_stats a JOIN employees e ON e.id=a.employee_id WHERE ' . ($u['type'] === 'team' ? 'e.team_id' : 'e.store_id') . '=? AND a.day>=? AND a.logged_min>0', [$u['id'], $from]);
        return ['vol' => array_map(fn($x) => array_sum($x) / count($x), array_filter($vol, fn($x) => count($x) >= 2)), 'aht' => $h ? $a / $h : null, 'profile' => $prof, 'prod' => $pr && $pr['m'] > 0 && $pr['h'] > 0 ? $pr['h'] / ($pr['m'] / 60) : null, 'flow_days' => $flowDays];
    }
    /** Profil horaire d'un jour de semaine : mesuré, sinon réparti à plat sur les heures couvertes par les shifts. */
    static function profile(array $hist, array $u, int $n): array {
        if (isset($hist['profile'][$n])) return [$hist['profile'][$n], true];
        $sh = Pl::shifts(false); $on = array_fill(0, 24, 0);
        foreach (Pl::needs($u)[$n] ?? [] as $sid => $req) { $s = $sh[$sid] ?? null; if (!Pl::isWork($s) || !$req) continue; $a = (int)substr($s['start_time'], 0, 2); $b = (int)substr($s['end_time'], 0, 2); for ($x = $a; $x != $b; $x = ($x + 1) % 24) $on[$x] = 1; }
        if (!array_sum($on)) for ($x = 8; $x < 20; $x++) $on[$x] = 1; $t = array_sum($on); return [array_map(fn($v) => $v / $t, $on), false];
    }
    static function headcount(array $u): int { return (int)DB::val("SELECT COUNT(*) FROM employees WHERE status<>'left' AND " . ($u['type'] === 'team' ? 'team_id' : 'store_id') . '=?', [$u['id']]); }

    /** Besoin hebdomadaire d'une unité pour un scénario. @return array{weeks:array[],warn:string[],estimated:bool,hc:int,mode:string} */
    static function compute(int $scen, array $u, ?int $weeks = null): array {
        $sc = self::scenario($scen); $weeks = $weeks ?: (int)($sc['horizon_weeks'] ?? 12); $p = self::params($scen, $u); $hist = self::history($u); $ev = self::events($scen);
        $queue = Pl::queueUnit($u); $hc = self::headcount($u); $warn = []; $estimated = false; $out = [];
        $aht = ($hist['aht'] ?? ($queue ? 300 : null)); if ($hist['aht'] === null && $queue) $warn[] = 'Aucune durée de traitement observée : 300 s supposées.';
        $aht = $aht === null ? null : $aht * (1 + $p['aht_delta_pct'] / 100);
        $prod = $p['prod_per_hour'] ?: $hist['prod']; if (!$queue) { if (!$prod) $warn[] = 'Aucune productivité connue (importez les données par conseiller ou fixez-la dans les hypothèses).'; else $prod *= 1 + $p['prod_delta_pct'] / 100; }
        if (!$hist['vol']) $warn[] = 'Historique insuffisant (2 semaines de même jour minimum).';
        $net = 1 - $p['shrinkage_pct'] / 100; $abs = 1 - $p['absenteeism_pct'] / 100; $start = Pl::addDays(Pl::monday(date('Y-m-d')), 7);
        for ($w = 0; $w < $weeks; $w++) {
            $ws = Pl::addDays($start, 7 * $w); $vol = 0.0; $hours = 0.0; $peak = 0; $ok = false;
            for ($d = 0; $d < 7; $d++) {
                $day = Pl::addDays($ws, $d); $n = $d + 1; if (!isset($hist['vol'][$n])) continue; $ok = true;
                $v = $hist['vol'][$n] * pow(1 + $p['growth_pct'] / 100, max(0, (strtotime($day) - time()) / 86400 / 30));
                foreach ($ev as $e) if ($day >= $e['date_from'] && $day <= $e['date_to'] && (($e['unit_type'] ?? '') === '' || ($e['unit_type'] === $u['type'] && (int)$e['unit_id'] === $u['id']))) $v *= 1 + (float)$e['uplift_pct'] / 100;
                $vol += $v;
                if ($queue) { [$pr, $meas] = self::profile($hist, $u, $n); if (!$meas) $estimated = true;
                    for ($x = 0; $x < 24; $x++) { $c = $v * $pr[$x]; if ($c <= 0.01) continue; $ag = self::agents($c, $aht, $p['sl_target'], $p['sl_threshold']); $ag = max($ag, (int)ceil($c * $aht / 3600 / ($p['occ_max'] / 100))); $hours += $ag; $peak = max($peak, $ag); } }
                elseif ($prod) { $hours += $v / $prod; $peak = max($peak, (int)ceil($v / $prod / 8)); }
            }
            $fte = $ok && ($queue || $prod) ? $hours / ($net * $abs) / max(1, $p['fte_hours']) : null;
            $out[] = ['week' => $ws, 'volume' => $ok ? (int)round($vol) : null, 'hours' => $ok ? round($hours, 1) : null, 'peak' => $peak, 'fte' => $fte === null ? null : round($fte, 1), 'gap' => $fte === null ? null : round($hc - $fte, 1)];
        }
        if ($estimated) $warn[] = 'Profil horaire estimé (aucun flux horaire importé pour certains jours) : le besoin aux heures de pointe est sous-estimé.';
        return ['weeks' => $out, 'warn' => $warn, 'estimated' => $estimated, 'hc' => $hc, 'mode' => $queue ? 'Erlang C par heure' : 'volume / productivité', 'aht' => $aht, 'prod' => $prod];
    }
    /** Agents requis (Erlang C), mémorisés : le volume est arrondi à 0,5 appel par heure. */
    static function agents(float $c, float $aht, float $sl, float $thr): int { static $m = []; $k = round($c * 2) . '|' . round($aht) . '|' . round($sl) . '|' . round($thr); return $m[$k] ??= Pl::agents(max(0.5, round($c * 2) / 2), $aht, $sl, $thr); }
    static function summary(array $c): array {
        $f = array_filter(array_column($c['weeks'], 'fte'), fn($v) => $v !== null); $g = array_filter(array_column($c['weeks'], 'gap'), fn($v) => $v !== null);
        return ['avg' => $f ? round(array_sum($f) / count($f), 1) : null, 'max' => $f ? max($f) : null, 'worst' => $g ? min($g) : null, 'hc' => $c['hc']];
    }
    static function channelOf(array $u): string { return ['CALLCENTER' => 'Call center', 'DIGITAL' => 'Digital', 'STORE' => 'Boutiques'][$u['channel']] ?? 'Fonctions support'; }
}
