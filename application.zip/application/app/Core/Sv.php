<?php
namespace App\Core;
/**
 * Lot 65 : enquêtes de satisfaction (CSAT, NPS, CES) — modèles, import du dump d'interactions et des résultats (CSV/Excel, correspondance de colonnes),
 * rattachement conseiller / équipe / agence, indicateurs. L'identité du client est conservée ; son affichage dépend du droit survey.identity.
 */
class Sv {
    const KIND = ['csat' => 'CSAT (satisfaction)', 'nps' => 'NPS (recommandation)', 'ces' => 'CES (effort client)', 'custom' => 'Enquête libre'];
    const QTYPE = ['scale5' => 'Échelle 1 à 5', 'scale10' => 'Échelle 0 à 10', 'yesno' => 'Oui / Non', 'choice' => 'Choix', 'text' => 'Texte libre'];
    const DIM = ['offer' => 'Offres, produits et services', 'relation' => 'Relation client', 'advisor' => 'Prestation du conseiller', 'global' => 'Global'];
    const METRIC = ['none' => 'Aucun', 'csat' => 'Note CSAT', 'nps' => 'Note NPS', 'ces' => 'Note d\'effort (CES)', 'advisor' => 'Note du conseiller'];
    const CHAN = ['call' => 'Call center', 'store' => 'Store', 'digital' => 'Digital'];
    const FREQ = ['hourly' => 'Toutes les heures', 'daily' => 'Chaque jour', 'weekly' => 'Chaque semaine'];
    const SOURCE = ['hermes' => 'Hermes 360', 'qualtrics' => 'Qualtrics', 'fichier' => 'Fichier de la direction', 'autre' => 'Autre outil'];
    const TARGET = ['csat' => [1, 5], 'nps' => [0, 10], 'ces' => [1, 7], 'advisor' => [1, 5]];
    const DUMP_FIELDS = ['ref' => 'Référence de l\'interaction *', 'occurred_at' => 'Date et heure *', 'channel' => 'Canal', 'client_ref' => 'Référence client', 'client_name' => 'Nom du client', 'client_phone' => 'Téléphone du client', 'matricule' => 'Matricule du conseiller', 'team_code' => 'Code équipe', 'store_code' => 'Code store / agence', 'reason' => 'Motif de contact', 'segment' => 'Segment', 'lang' => 'Langue'];
    const RES_FIELDS = ['ext_ref' => 'Identifiant de la réponse', 'ref' => 'Référence de l\'interaction', 'answered_at' => 'Date de réponse *', 'channel' => 'Canal', 'matricule' => 'Matricule du conseiller', 'team_code' => 'Code équipe', 'store_code' => 'Code store / agence', 'client_ref' => 'Référence client', 'client_name' => 'Nom du client', 'client_phone' => 'Téléphone du client', 'csat' => 'Note CSAT', 'nps' => 'Note NPS', 'ces' => 'Note d\'effort', 'advisor' => 'Note du conseiller', 'comment' => 'Commentaire'];

    static function cfg(string $k): int { return (int)setting('sv.' . $k, ['satisfied_min' => '4', 'min_responses' => '5', 'promoter_min' => '9', 'detractor_max' => '6'][$k] ?? '0'); }
    static function max(string $type): int { return ['scale5' => 5, 'scale10' => 10, 'yesno' => 1][$type] ?? 0; }

    // ------------------------------------------------------------------ lecture de fichier
    /** @return array{0:array<int,string>,1:array<int,array{line:int,data:array<string,string>}>,2:?string} */
    static function read(string $bytes, string $ext): array {
        $tmp = tempnam(sys_get_temp_dir(), 'sv'); file_put_contents($tmp, $bytes);
        try {
            if (in_array($ext, ['xlsx'], true)) {
                [$sheets, $err] = Xlsx::read($tmp); if ($err) return [[], [], $err]; $rows = reset($sheets) ?: []; if (!$rows) return [[], [], 'Classeur vide.'];
                ksort($rows); $first = array_shift($rows); $head = array_map(fn($h) => strtolower(trim((string)$h)), array_values($first)); $out = [];
                foreach ($rows as $n => $r) { $r = array_values($r); if (!array_filter($r, fn($x) => trim((string)$x) !== '')) continue; $d = []; foreach ($head as $i => $h) if ($h !== '') $d[$h] = trim((string)($r[$i] ?? '')); $out[] = ['line' => (int)$n, 'data' => $d]; }
                return [$head, $out, null];
            }
            if (!in_array($ext, ['csv', 'txt'], true)) return [[], [], 'Format attendu : CSV ou Excel (.xlsx).'];
            [$head, $rows] = Importer::parse($tmp);
            return [$head, array_map(fn($r) => ['line' => $r['line'], 'data' => array_map(fn($v) => trim((string)$v), $r['data'])], $rows), null];
        } finally { @unlink($tmp); }
    }
    static function lines(?string $t): array { $o = []; foreach (preg_split('/\R/', (string)$t) as $l) { if (!str_contains($l, '=')) continue; [$a, $b] = array_map('trim', explode('=', $l, 2)); if ($a !== '' && $b !== '') $o[$a] = strtolower($b); } return $o; }
    static function scales(?string $t): array { $o = ['csat' => 5, 'nps' => 10, 'ces' => 7, 'advisor' => 5]; foreach (explode(',', (string)$t) as $p) if (str_contains($p, '=')) { [$k, $v] = array_map('trim', explode('=', $p, 2)); if (isset($o[$k]) && (int)$v > 0) $o[$k] = (int)$v; } return $o; }

    // ------------------------------------------------------------------ conversions
    static function date(string $v, ?string $fmt = null): ?string {
        $v = trim($v); if ($v === '') return null;
        if (is_numeric($v) && (float)$v > 20000 && (float)$v < 80000) return gmdate('Y-m-d H:i:s', (int)round(((float)$v - 25569) * 86400));
        $try = $fmt ? [$fmt] : []; $try = array_merge($try, ['Y-m-d H:i:s', 'Y-m-d H:i', 'Y-m-d\TH:i:s', 'Y-m-d\TH:i:sP', 'Y-m-d\TH:i:s\Z', 'Y-m-d', 'd/m/Y H:i:s', 'd/m/Y H:i', 'd/m/Y', 'd-m-Y H:i', 'd-m-Y', 'd.m.Y']);
        foreach ($try as $f) { $d = \DateTime::createFromFormat('!' . $f, $v); $e = \DateTime::getLastErrors(); if ($d && (!$e || (!$e['warning_count'] && !$e['error_count']))) { $y = (int)$d->format('Y'); if ($y >= 2000 && $y <= 2100) return $d->format('Y-m-d H:i:s'); } }
        return null;
    }
    static function channel(?string $v): ?string {
        $v = mb_strtolower(trim((string)$v)); if ($v === '') return null;
        if (preg_match('/call|appel|voix|voice|phone|t[ée]l[ée]ph|cc$/u', $v)) return 'call'; if (preg_match('/store|boutique|agence|magasin|point de vente/u', $v)) return 'store';
        if (preg_match('/digit|web|app|whats|chat|sms|mail|social|facebook|bot/u', $v)) return 'digital'; return null;
    }
    /** Note convertie sur l'échelle cible ; null si absente ou hors bornes. */
    static function score(?string $v, string $metric, int $max): ?int {
        $v = trim((string)$v); if ($v === '') return null; $v = str_replace([',', '%', ' '], ['.', '', ''], $v); if (!is_numeric($v)) return null;
        [$lo, $hi] = self::TARGET[$metric]; $n = (float)$v; if ($max !== $hi && $max > 0) $n = $n * $hi / $max;
        $n = (int)round($n); return $n >= $lo && $n <= $hi ? $n : null;
    }
    static function phoneMask(?string $p): string { $d = preg_replace('/\D/', '', (string)$p); return strlen($d) < 6 ? '••••' : substr($d, 0, 2) . ' •• •• ' . substr($d, -2); }
    static function nameMask(?string $n): string { $p = preg_split('/\s+/', trim((string)$n)); return $p && $p[0] !== '' ? mb_substr($p[0], 0, 1) . '. ' . (isset($p[1]) ? mb_substr($p[count($p) - 1], 0, 1) . '.' : '') : '—'; }
    static function identity(array $r): array { $f = can('survey.identity'); return [$f ? ($r['client_name'] ?: '—') : self::nameMask($r['client_name'] ?? ''), $f ? ($r['client_phone'] ?: '—') : self::phoneMask($r['client_phone'] ?? ''), $f ? ($r['client_ref'] ?: '—') : ($r['client_ref'] ? '••••' . substr((string)$r['client_ref'], -3) : '—')]; }

    // ------------------------------------------------------------------ import
    private static function lookups(): array {
        $emp = []; foreach (DB::all('SELECT id, matricule, qa_ref, team_id, store_id FROM employees') as $e) { $emp[strtolower((string)$e['matricule'])] = $e; if ($e['qa_ref']) $emp[strtolower((string)$e['qa_ref'])] ??= $e; }
        return ['emp' => $emp, 'team' => array_change_key_case(array_column(DB::all('SELECT id, code FROM teams'), 'id', 'code'), CASE_LOWER), 'store' => array_change_key_case(array_column(DB::all('SELECT id, code FROM stores'), 'id', 'code'), CASE_LOWER)];
    }
    /**
     * Importe des lignes lues par read(). $kind : dump | results. Retourne le bilan ; rien n'est écrit si $dry.
     * @return array{total:int,created:int,updated:int,rejected:int,warnings:int,lines:array<int,string>}
     */
    static function import(string $kind, array $map, array $rows, ?int $surveyId, ?int $batchId, bool $dry, string $source): array {
        $cols = self::lines($map['columns'] ?? ''); $qmap = $kind === 'results' ? self::lines($map['questions'] ?? '') : []; $sc = self::scales($map['scales'] ?? ''); $fmt = ($map['date_format'] ?? '') ?: null; $lk = self::lookups();
        $bil = ['total' => count($rows), 'created' => 0, 'updated' => 0, 'rejected' => 0, 'warnings' => 0, 'lines' => []]; $note = function (string $m) use (&$bil) { if (count($bil['lines']) < 300) $bil['lines'][] = $m; };
        $questions = $surveyId ? array_column(DB::all('SELECT * FROM sv_questions WHERE survey_id=?', [$surveyId]), null, 'code') : [];
        $get = fn(array $d, string $f) => isset($cols[$f]) ? ($d[$cols[$f]] ?? '') : '';
        $seen = [];
        foreach ($rows as $r) {
            $d = $r['data']; $ln = $r['line']; $emp = null; $mat = strtolower($get($d, 'matricule'));
            if ($mat !== '') { $emp = $lk['emp'][$mat] ?? null; if (!$emp) { $bil['warnings']++; $note("Ligne $ln : conseiller « {$get($d, 'matricule')} » inconnu (réponse conservée sans conseiller)."); } }
            $team = $emp['team_id'] ?? null; $store = $emp['store_id'] ?? null;
            if (($t = strtolower($get($d, 'team_code'))) !== '' && isset($lk['team'][$t])) $team = $lk['team'][$t]; if (($t = strtolower($get($d, 'store_code'))) !== '' && isset($lk['store'][$t])) $store = $lk['store'][$t];
            $common = ['employee_id' => $emp['id'] ?? null, 'team_id' => $team, 'store_id' => $store, 'channel' => self::channel($get($d, 'channel')), 'client_ref' => mb_substr($get($d, 'client_ref'), 0, 80) ?: null, 'client_name' => mb_substr($get($d, 'client_name'), 0, 160) ?: null, 'client_phone' => mb_substr($get($d, 'client_phone'), 0, 40) ?: null];
            if ($kind === 'dump') {
                $ref = $get($d, 'ref'); $at = self::date($get($d, 'occurred_at'), $fmt);
                if ($ref === '') { $bil['rejected']++; $note("Ligne $ln : référence d'interaction manquante."); continue; } if (!$at) { $bil['rejected']++; $note("Ligne $ln : date invalide (« {$get($d, 'occurred_at')} »)."); continue; }
                if (isset($seen[$ref])) { $bil['rejected']++; $note("Ligne $ln : référence « $ref » en double dans le fichier."); continue; } $seen[$ref] = 1;
                $row = $common + ['occurred_at' => $at, 'reason' => mb_substr($get($d, 'reason'), 0, 160) ?: null, 'segment' => mb_substr($get($d, 'segment'), 0, 40) ?: null, 'lang' => mb_substr($get($d, 'lang'), 0, 5) ?: null, 'survey_id' => $surveyId];
                $ex = DB::one('SELECT id FROM sv_interactions WHERE ref=?', [$ref]); $ex ? $bil['updated']++ : $bil['created']++;
                if (!$dry) { if ($ex) DB::update('sv_interactions', $row, 'id=?', [$ex['id']]); else DB::insert('sv_interactions', $row + ['batch_id' => $batchId, 'ref' => $ref, 'status' => 'pending', 'created_at' => now()]); }
                continue;
            }
            // résultats
            $at = self::date($get($d, 'answered_at'), $fmt); if (!$at) { $bil['rejected']++; $note("Ligne $ln : date de réponse invalide (« {$get($d, 'answered_at')} »)."); continue; }
            $iref = $get($d, 'ref'); $ext = $get($d, 'ext_ref') ?: $iref ?: md5($source . json_encode($d)); if (isset($seen[$ext])) { $bil['rejected']++; $note("Ligne $ln : réponse « $ext » en double dans le fichier."); continue; } $seen[$ext] = 1;
            $inter = $iref !== '' ? DB::one('SELECT * FROM sv_interactions WHERE ref=?', [$iref]) : null;
            if ($inter) { foreach (['employee_id', 'team_id', 'store_id', 'channel', 'client_ref', 'client_name', 'client_phone'] as $f) if ($common[$f] === null && $inter[$f] !== null) $common[$f] = $inter[$f]; }
            $met = []; foreach (['csat', 'nps', 'ces', 'advisor'] as $m) { $raw = $get($d, $m); $met[$m] = self::score($raw, $m, $sc[$m]); if ($raw !== '' && $met[$m] === null) { $bil['warnings']++; $note("Ligne $ln : $m « $raw » hors échelle (ignorée)."); } }
            $ans = [];
            foreach ($qmap as $qc => $colName) { $q = $questions[$qc] ?? $questions[strtoupper($qc)] ?? null; if (!$q) continue; $raw = $d[$colName] ?? ''; if ($raw === '') continue;
                if ($q['type'] === 'text') { $ans[] = [(int)$q['id'], null, mb_substr($raw, 0, 600)]; continue; } if ($q['type'] === 'choice') { $ans[] = [(int)$q['id'], null, mb_substr($raw, 0, 600)]; continue; }
                $n = self::answerNum($raw, $q['type']); if ($n === null) { $bil['warnings']++; $note("Ligne $ln : réponse « $raw » invalide pour {$q['code']} (ignorée)."); continue; } $ans[] = [(int)$q['id'], $n, null];
                if ($q['metric'] !== 'none' && $met[$q['metric']] === null) $met[$q['metric']] = self::score((string)$n, $q['metric'], self::max($q['type'])); }
            if ($met['csat'] === null && $met['nps'] === null && $met['ces'] === null && $met['advisor'] === null && !$ans && $get($d, 'comment') === '') { $bil['rejected']++; $note("Ligne $ln : aucune note ni commentaire."); continue; }
            $row = $common + ['survey_id' => (int)$surveyId, 'answered_at' => $at, 'interaction_id' => $inter['id'] ?? null, 'csat' => $met['csat'], 'nps' => $met['nps'], 'ces' => $met['ces'], 'advisor' => $met['advisor'], 'comment' => $get($d, 'comment') ?: null];
            $ex = DB::one('SELECT id FROM sv_responses WHERE source=? AND ext_ref=?', [$source, $ext]); $ex ? $bil['updated']++ : $bil['created']++;
            if ($dry) continue;
            if ($ex) { DB::update('sv_responses', $row, 'id=?', [$ex['id']]); DB::exec('DELETE FROM sv_answers WHERE response_id=?', [$ex['id']]); $rid = (int)$ex['id']; }
            else $rid = DB::insert('sv_responses', $row + ['batch_id' => $batchId, 'source' => $source, 'ext_ref' => $ext, 'created_at' => now()]);
            foreach ($ans as [$qid, $n, $t]) DB::insert('sv_answers', ['response_id' => $rid, 'question_id' => $qid, 'num' => $n, 'txt' => $t]);
            if ($inter) DB::update('sv_interactions', ['status' => 'answered'], 'id=?', [$inter['id']]);
        }
        return $bil;
    }
    static function answerNum(string $raw, string $type): ?int {
        $v = mb_strtolower(trim($raw)); if ($type === 'yesno') return in_array($v, ['1', 'oui', 'yes', 'o', 'y', 'true'], true) ? 1 : (in_array($v, ['0', 'non', 'no', 'n', 'false'], true) ? 0 : null);
        $v = str_replace(',', '.', $v); if (!is_numeric($v)) return null; $n = (int)round((float)$v); return $n >= ($type === 'scale5' ? 1 : 0) && $n <= self::max($type) ? $n : null;
    }
    /** Enregistre un lot (journal) puis importe ; retourne [batchId, bilan]. */
    static function run(string $kind, array $map, array $file, ?int $surveyId, bool $dry, string $label): array {
        [$head, $rows, $err] = self::read($file['bytes'], $file['ext']); if ($err) return [0, ['total' => 0, 'created' => 0, 'updated' => 0, 'rejected' => 0, 'warnings' => 0, 'lines' => [$err]]];
        $cols = self::lines($map['columns'] ?? ''); $missing = []; foreach (array_unique(array_merge(array_values($cols), array_values($kind === 'results' ? self::lines($map['questions'] ?? '') : []))) as $c) if (!in_array($c, $head, true)) $missing[] = $c;
        $req = $kind === 'dump' ? ['ref', 'occurred_at'] : ['answered_at']; foreach ($req as $f) if (!isset($cols[$f])) return [0, ['total' => 0, 'created' => 0, 'updated' => 0, 'rejected' => 0, 'warnings' => 0, 'lines' => ["La correspondance ne définit pas la colonne obligatoire « $f »."]]];
        if ($kind === 'results' && !$surveyId) return [0, ['total' => 0, 'created' => 0, 'updated' => 0, 'rejected' => 0, 'warnings' => 0, 'lines' => ['Choisissez le modèle d\'enquête des résultats.']]];
        $src = $kind === 'results' ? (string)($map['source'] ?? 'fichier') . ':' . (int)($map['id'] ?? 0) : 'dump';
        $bid = $dry ? null : DB::insert('sv_batches', ['kind' => $kind, 'name' => mb_substr($label, 0, 190), 'source' => $map['source'] ?? null, 'mapping_id' => $map['id'] ?? null, 'survey_id' => $surveyId, 'dry_run' => 0, 'user_id' => Auth::id(), 'created_at' => now()]);
        $bil = self::import($kind, $map, $rows, $surveyId, $bid, $dry, $src); if (!$dry && $kind === 'results') Followup::scan(); if ($missing) array_unshift($bil['lines'], 'Colonnes du modèle absentes du fichier : ' . implode(', ', $missing) . '.');
        if ($bid) DB::update('sv_batches', ['total' => $bil['total'], 'created' => $bil['created'], 'updated' => $bil['updated'], 'rejected' => $bil['rejected'], 'report' => implode("\n", $bil['lines'])], 'id=?', [$bid]);
        return [(int)$bid, $bil];
    }

    // ------------------------------------------------------------------ indicateurs
    static function where(array $f): array {
        $w = ['1=1']; $p = [];
        if (!empty($f['from'])) { $w[] = 'r.answered_at>=?'; $p[] = $f['from'] . ' 00:00:00'; } if (!empty($f['to'])) { $w[] = 'r.answered_at<=?'; $p[] = $f['to'] . ' 23:59:59'; }
        foreach (['survey_id', 'employee_id', 'team_id', 'store_id'] as $k) if (!empty($f[$k])) { $w[] = "r.$k=?"; $p[] = (int)$f[$k]; }
        if (!empty($f['channel'])) { $w[] = 'r.channel=?'; $p[] = $f['channel']; }
        if (!empty($f['scope'])) { [$s, $sp] = Scope::sql('r.employee_id'); $w[] = $s; $p = array_merge($p, $sp); }
        return [implode(' AND ', $w), $p];
    }
    /** Agrégats par clé de regroupement : employee_id | team_id | store_id | channel | month | all. */
    static function stats(array $f, string $by = 'all'): array {
        [$w, $p] = self::where($f); $g = $by === 'all' ? "'all'" : ($by === 'month' ? 'SUBSTR(r.answered_at,1,7)' : "r.$by"); $sat = self::cfg('satisfied_min'); $pm = self::cfg('promoter_min'); $dm = self::cfg('detractor_max');
        $rows = DB::all("SELECT $g k, COUNT(*) n, COUNT(r.csat) c_n, SUM(CASE WHEN r.csat>=? THEN 1 ELSE 0 END) c_sat, AVG(r.csat) c_avg, COUNT(r.nps) n_n, SUM(CASE WHEN r.nps>=? THEN 1 ELSE 0 END) prom, SUM(CASE WHEN r.nps IS NOT NULL AND r.nps<=? THEN 1 ELSE 0 END) det, AVG(r.ces) ces_avg, COUNT(r.advisor) a_n, AVG(r.advisor) a_avg FROM sv_responses r WHERE $w GROUP BY $g ORDER BY $g", array_merge([$sat, $pm, $dm], $p));
        $min = self::cfg('min_responses'); $o = [];
        foreach ($rows as $r) { $cn = (int)$r['c_n']; $nn = (int)$r['n_n'];
            $o[(string)$r['k']] = ['n' => (int)$r['n'], 'csat_pct' => $cn ? round(100 * $r['c_sat'] / $cn, 1) : null, 'csat_avg' => $cn ? round((float)$r['c_avg'], 2) : null, 'csat_n' => $cn, 'nps' => $nn ? round(100 * ($r['prom'] - $r['det']) / $nn, 1) : null, 'nps_n' => $nn, 'prom' => (int)$r['prom'], 'det' => (int)$r['det'], 'pas' => $nn - (int)$r['prom'] - (int)$r['det'],
                'ces' => $r['ces_avg'] !== null ? round((float)$r['ces_avg'], 2) : null, 'adv' => (int)$r['a_n'] ? round((float)$r['a_avg'], 2) : null, 'low' => (int)$r['n'] < $min]; }
        return $o;
    }
    /** Moyenne (en % de l'échelle) des réponses numériques, par dimension. */
    static function dimensions(array $f): array {
        [$w, $p] = self::where($f); $o = [];
        foreach (DB::all("SELECT q.dimension, q.type, AVG(a.num) av, COUNT(*) n FROM sv_answers a JOIN sv_questions q ON q.id=a.question_id JOIN sv_responses r ON r.id=a.response_id WHERE a.num IS NOT NULL AND q.type IN ('scale5','scale10','yesno') AND $w GROUP BY q.dimension, q.type", $p) as $r) {
            $max = self::max($r['type']); $lo = $r['type'] === 'scale5' ? 1 : 0; $pct = $max > $lo ? 100 * ($r['av'] - $lo) / ($max - $lo) : 0; $d = &$o[$r['dimension']]; $d = ['sum' => ($d['sum'] ?? 0) + $pct * $r['n'], 'n' => ($d['n'] ?? 0) + $r['n']]; unset($d); }
        foreach ($o as $k => $v) $o[$k] = ['pct' => round($v['sum'] / $v['n'], 1), 'n' => $v['n']]; return $o;
    }
    static function periodDefault(): array { return [date('Y-m-d', strtotime('first day of -2 months')), date('Y-m-d')]; }
    /** Traite les fichiers déposés dans storage/surveys/inbox/<dossier> ; les fichiers traités sont déplacés dans processed/. */
    static function runSource(array $src): string {
        $map = DB::one('SELECT * FROM sv_mappings WHERE id=?', [(int)$src['mapping_id']]); if (!$map) return 'Correspondance introuvable.';
        $base = ROOT . '/storage/surveys/inbox/' . $src['folder']; if (!is_dir($base) && !@mkdir($base . '/processed', 0775, true)) return 'Dossier illisible.'; @mkdir($base . '/processed', 0775, true);
        $files = array_values(array_filter(glob($base . '/*') ?: [], 'is_file')); sort($files); $tot = ['f' => 0, 'c' => 0, 'u' => 0, 'r' => 0];
        foreach ($files as $path) {
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION)); if (!in_array($ext, ['csv', 'txt', 'xlsx'], true)) continue;
            [, $bil] = self::run($map['kind'], $map, ['bytes' => (string)file_get_contents($path), 'ext' => $ext], $src['survey_id'] ?: $map['survey_id'], false, 'Dossier « ' . $src['name'] . ' » : ' . basename($path));
            @rename($path, $base . '/processed/' . date('Ymd_His') . '_' . basename($path)); $tot['f']++; $tot['c'] += $bil['created']; $tot['u'] += $bil['updated']; $tot['r'] += $bil['rejected'];
        }
        $msg = $tot['f'] ? "{$tot['f']} fichier(s) : {$tot['c']} créé(s), {$tot['u']} mis à jour, {$tot['r']} rejeté(s)." : 'Aucun fichier à traiter.';
        DB::update('sv_sources', ['last_run' => now(), 'last_result' => $msg], 'id=?', [(int)$src['id']]); return $msg;
    }
    static function due(array $s): bool { if (!$s['active']) return false; if (!$s['last_run']) return true; $age = time() - strtotime($s['last_run']); return $age >= ['hourly' => 3500, 'daily' => 82800, 'weekly' => 597000][$s['frequency']]; }
}
