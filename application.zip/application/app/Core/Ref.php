<?php
namespace App\Core;
/** Accès aux listes de valeurs paramétrables (Administration > Référentiels) avec repli sur des valeurs par défaut. */
class Ref {
    private static array $c = [];
    /** @return array<string,array{label:string,color:?string,active:int}> valeurs d'une liste, dans l'ordre d'affichage */
    static function rows(string $code, bool $all = false): array {
        if (!isset(self::$c[$code])) {
            self::$c[$code] = [];
            try { foreach (DB::all('SELECT v.code, v.label, v.color, v.active FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code=? AND l.active=1 ORDER BY v.sort_order, v.label', [$code]) as $r) self::$c[$code][$r['code']] = $r; } catch (\Throwable $e) {}
        }
        return $all ? self::$c[$code] : array_filter(self::$c[$code], fn($r) => (int)$r['active'] === 1);
    }
    /** @return array<string,string> code => libellé (valeurs actives) */
    static function items(string $code): array { return array_map(fn($r) => $r['label'], self::rows($code)); }
    static function label(string $code, ?string $v): string { if ($v === null || $v === '') return '—'; return self::rows($code, true)[$v]['label'] ?? $v; }
    static function has(string $code, ?string $v): bool { return $v !== null && isset(self::rows($code)[$v]); }
    static function color(string $code, ?string $v): string { return self::rows($code, true)[$v ?? '']['color'] ?? '#6c757d'; }
    /** Liste déroulante HTML (la valeur courante reste affichée même si elle a été désactivée). */
    static function select(string $code, ?string $cur, string $name, bool $blank = true, string $cls = 'form-select'): string {
        $items = self::items($code); if ($cur && !isset($items[$cur])) $items[$cur] = self::label($code, $cur);
        $o = $blank ? '<option value="">—</option>' : '';
        foreach ($items as $k => $l) $o .= '<option value="' . e($k) . '"' . ((string)$cur === (string)$k ? ' selected' : '') . '>' . e($l) . '</option>';
        return '<select class="' . e($cls) . '" name="' . e($name) . '">' . $o . '</select>';
    }
    /** Crée la liste et ses valeurs si elle n'existe pas (amorçage idempotent) ; ne touche jamais à une liste existante. */
    static function seed(string $code, string $label, string $module, array $values): void {
        if (DB::val('SELECT 1 FROM ref_lists WHERE code=?', [$code])) return;
        $l = DB::insert('ref_lists', ['code' => $code, 'label' => $label, 'module' => $module, 'active' => 1]);
        foreach ($values as $i => $v) { [$c, $n] = $v; DB::insert('ref_values', ['list_id' => $l, 'code' => $c, 'label' => $n, 'sort_order' => ($i + 1) * 10, 'color' => $v[2] ?? null, 'active' => 1]); }
    }
    static function reset(): void { self::$c = []; }
}
