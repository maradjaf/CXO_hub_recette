<?php
namespace App\Core;

/** Lot 66 : note qualité composée (évaluations qualité + CSAT individuel / agence / équipe), règles paramétrables par profil. */
class Qn {
    const KIND = ['callcenter' => 'Call center', 'store' => 'Store', 'other' => 'Digital / autre'];
    const MISSING = ['redistribute' => 'Répartir le poids sur les composantes disponibles', 'none' => 'Ne pas calculer la note'];
    const CSATMODE = ['pct' => '% de clients satisfaits', 'avg' => 'Moyenne convertie sur 100'];
    const AGG = ['all' => 'Toutes les réponses du groupe', 'mean' => 'Moyenne des CSAT individuels des membres'];
    const COMP = ['qc' => 'Évaluation qualité', 'self' => 'CSAT individuel', 'store' => 'CSAT de l\'agence', 'team' => 'CSAT de l\'équipe'];
    const STATUS = ['ok' => 'Complète', 'partial' => 'Partielle', 'incomplete' => 'Non calculable', 'noprofile' => 'Aucun profil'];
    private static array $cache = [];

    /** Version en vigueur de chaque profil à une date, triée par priorité (le plus petit nombre passe en premier). */
    static function profiles(string $date): array {
        $seen = []; $o = [];
        foreach (DB::all('SELECT * FROM qn_profiles WHERE effective_from<=? ORDER BY code, effective_from DESC, version DESC', [$date]) as $r) { if (isset($seen[$r['code']])) continue; $seen[$r['code']] = 1; if ($r['active']) $o[] = $r; }
        usort($o, fn($a, $b) => [(int)$a['priority'], (int)$a['id']] <=> [(int)$b['priority'], (int)$b['id']]); return $o;
    }
    static function employee(int $id): ?array { return DB::one('SELECT e.*, c.kind channel_kind FROM employees e LEFT JOIN channels c ON c.id=e.channel_id WHERE e.id=?', [$id]); }
    static function matches(array $e, array $p): bool {
        if ($p['channel_kind'] && ($e['channel_kind'] ?? '') !== $p['channel_kind']) return false;
        if ($p['function_like'] && stripos((string)($e['job_function'] ?? ''), $p['function_like']) === false) return false;
        if ($p['position_id'] && (int)$e['position_id'] !== (int)$p['position_id']) return false;
        if ($p['team_id'] && (int)$e['team_id'] !== (int)$p['team_id']) return false; return true;
    }
    static function profileFor(array $e, string $date): ?array { foreach (self::profiles($date) as $p) if (self::matches($e, $p)) return $p; return null; }

    private static function csatVal(int $n, $s, $a, string $mode): ?float { if ($n <= 0) return null; return $mode === 'avg' ? round(max(0, min(100, ((float)$a - 1) / 4 * 100)), 1) : round(100 * $s / $n, 1); }
    /** CSAT d'un groupe (conseiller, store ou équipe) sur la période. */
    static function csat(string $field, int $id, string $from, string $to, string $mode, string $agg): array {
        if (!in_array($field, ['employee_id', 'store_id', 'team_id'], true) || !$id) return ['v' => null, 'n' => 0];
        $k = "$field|$id|$from|$to|$mode|$agg"; if (isset(self::$cache[$k])) return self::$cache[$k]; $sat = Sv::cfg('satisfied_min');
        $rows = DB::all("SELECT employee_id e, COUNT(csat) n, SUM(CASE WHEN csat>=? THEN 1 ELSE 0 END) s, AVG(csat) a FROM sv_responses WHERE $field=? AND csat IS NOT NULL AND answered_at>=? AND answered_at<=? GROUP BY employee_id", [$sat, $id, $from . ' 00:00:00', $to . ' 23:59:59']);
        $N = 0; $S = 0; $A = 0.0; $vals = []; $nm = 0;
        foreach ($rows as $r) { $n = (int)$r['n']; $N += $n; $S += (int)$r['s']; $A += (float)$r['a'] * $n; if ($r['e'] !== null && $n > 0) { $vals[] = self::csatVal($n, $r['s'], $r['a'], $mode); $nm += $n; } }
        if ($field !== 'employee_id' && $agg === 'mean') $out = ['v' => $vals ? round(array_sum($vals) / count($vals), 1) : null, 'n' => $nm];
        else $out = ['v' => $N ? self::csatVal($N, $S, $A / $N, $mode) : null, 'n' => $N];
        return self::$cache[$k] = $out;
    }
    static function qc(int $emp, string $from, string $to): array {
        $r = DB::one("SELECT COUNT(*) n, AVG(score_pct) a FROM qa_evaluations WHERE employee_id=? AND eval_date>=? AND eval_date<=? AND status<>'cancelled'", [$emp, $from, $to]);
        return ['v' => (int)$r['n'] ? round((float)$r['a'], 1) : null, 'n' => (int)$r['n']];
    }
    /** Calcule la note d'un conseiller ; $p force un profil (simulation). */
    static function compute(int $empId, string $from, string $to, ?array $p = null): array {
        $e = self::employee($empId); $out = ['employee_id' => $empId, 'profile' => null, 'comps' => [], 'score' => null, 'status' => 'noprofile', 'team_id' => (int)($e['team_id'] ?? 0), 'store_id' => (int)($e['store_id'] ?? 0), 'qc_n' => 0];
        if (!$e) return $out; $p = $p ?? self::profileFor($e, $to); if (!$p) return $out; $out['profile'] = $p;
        $min = (int)($p['min_csat'] ?: Sv::cfg('min_responses')); $W = ['qc' => (float)$p['w_qc'], 'self' => (float)$p['w_self'], 'store' => (float)$p['w_store'], 'team' => (float)$p['w_team']]; $all = 0.0; $av = 0.0;
        foreach ($W as $c => $w) { if ($w <= 0) continue;
            $x = match ($c) { 'qc' => self::qc($empId, $from, $to), 'self' => self::csat('employee_id', $empId, $from, $to, $p['csat_mode'], 'all'), 'store' => self::csat('store_id', (int)$e['store_id'], $from, $to, $p['csat_mode'], $p['agg_mode']), 'team' => self::csat('team_id', (int)$e['team_id'], $from, $to, $p['csat_mode'], $p['agg_mode']) };
            $need = $c === 'qc' ? (int)$p['min_qc'] : $min; $x['w'] = $w; $x['need'] = $need; $x['ok'] = $x['v'] !== null && $x['n'] >= $need; $out['comps'][$c] = $x; $all += $w; if ($x['ok']) $av += $w; }
        $out['qc_n'] = (int)($out['comps']['qc']['n'] ?? 0);
        if ($all <= 0) return $out;
        if ($av > 0 && ($av >= $all - 0.0001 || $p['missing'] === 'redistribute')) { $s = 0.0; foreach ($out['comps'] as $c => &$x) { $x['eff'] = $x['ok'] ? round(100 * $x['w'] / $av, 1) : 0; if ($x['ok']) $s += $x['v'] * $x['w'] / $av; } unset($x); $out['score'] = round($s, 1); $out['status'] = $av >= $all - 0.0001 ? 'ok' : 'partial'; }
        else { foreach ($out['comps'] as &$x) $x['eff'] = 0; unset($x); $out['status'] = 'incomplete'; }
        return $out;
    }
    /** Notes des conseillers du périmètre (filtres : team_id, store_id, kind). */
    static function scopeRows(string $from, string $to, array $f = []): array {
        [$w, $pp] = Scope::sql('e.id'); $q = "SELECT e.id FROM employees e LEFT JOIN channels c ON c.id=e.channel_id WHERE e.status<>'left' AND $w"; $par = $pp;
        if (!empty($f['team_id'])) { $q .= ' AND e.team_id=?'; $par[] = (int)$f['team_id']; } if (!empty($f['store_id'])) { $q .= ' AND e.store_id=?'; $par[] = (int)$f['store_id']; } if (!empty($f['kind'])) { $q .= ' AND c.kind=?'; $par[] = $f['kind']; }
        $o = []; foreach (DB::all($q . ' ORDER BY e.last_name, e.first_name', $par) as $r) $o[] = self::compute((int)$r['id'], $from, $to); return $o;
    }
    /** Moyenne par équipe ou par store ; pondérée par le nombre d'évaluations qualité si demandé. */
    static function groupAvg(array $rows, string $key, bool $weighted): array {
        $g = [];
        foreach ($rows as $r) { $k = (int)$r[$key]; if (!$k) continue; $g[$k]['n'] = ($g[$k]['n'] ?? 0) + 1; if ($r['score'] === null) continue; $w = $weighted ? max(1, (int)$r['qc_n']) : 1; $g[$k]['s'] = ($g[$k]['s'] ?? 0) + $r['score'] * $w; $g[$k]['w'] = ($g[$k]['w'] ?? 0) + $w; $g[$k]['r'] = ($g[$k]['r'] ?? 0) + 1; }
        foreach ($g as $k => $v) $g[$k] = ['members' => $v['n'], 'rated' => $v['r'] ?? 0, 'avg' => !empty($v['w']) ? round($v['s'] / $v['w'], 1) : null];
        uasort($g, fn($a, $b) => ($b['avg'] ?? -1) <=> ($a['avg'] ?? -1)); return $g;
    }
    static function period(array $in): array {
        [$a, $b] = Sv::periodDefault(); $f = (string)($in['from'] ?? $a); $t = (string)($in['to'] ?? $b);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $f)) $f = $a; if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $t)) $t = $b; return [$f, $t];
    }
}
