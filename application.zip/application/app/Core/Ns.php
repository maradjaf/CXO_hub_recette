<?php
namespace App\Core;

/** Notes de service (demande → secrétariat → visas → signature) et mémos (rédaction → N+1 → avis). */
final class Ns {
    const ST = ['requested' => 'Demandée', 'drafting' => 'En rédaction', 'visa' => 'En validation', 'to_sign' => 'À signer', 'signed' => 'Signée', 'rejected' => 'À corriger', 'cancelled' => 'Annulée'];
    const ST_C = ['requested' => 'warning', 'drafting' => 'info', 'visa' => 'primary', 'to_sign' => 'primary', 'signed' => 'success', 'rejected' => 'danger', 'cancelled' => 'dark'];
    const MM = ['draft' => 'Brouillon', 'pending_n1' => 'En validation N+1', 'to_sign' => 'En attente d\'avis', 'signed' => 'Validé', 'rejected' => 'À corriger', 'cancelled' => 'Annulé'];
    const MM_C = ['draft' => 'secondary', 'pending_n1' => 'warning', 'to_sign' => 'primary', 'signed' => 'success', 'rejected' => 'danger', 'cancelled' => 'dark'];
    const LOG = ['request' => 'Demande', 'take' => 'Prise en charge', 'draft' => 'Rédaction', 'submit' => 'Envoi en validation', 'visa' => 'Visa', 'reject' => 'Refus', 'sign' => 'Signature', 'cancel' => 'Annulation', 'create' => 'Création', 'edit' => 'Modification', 'n1' => 'Validation N+1', 'avis' => 'Avis'];
    const VARS = ['{demandeur}' => 'Nom du demandeur', '{objet}' => 'Objet de la note', '{contexte}' => 'Précisions du demandeur', '{ticket}' => 'Référence du ticket', '{boutique}' => 'Boutique ou site du ticket', '{date}' => 'Date du jour', '{memo}' => 'Référence du mémo'];

    static function log(int $id, string $kind, string $c = '', string $t = 'ns'): void { DB::insert($t === 'mm' ? 'mm_log' : 'ns_log', [($t === 'mm' ? 'memo_id' : 'note_id') => $id, 'user_id' => Auth::id(), 'kind' => $kind, 'comment' => mb_substr($c, 0, 500) ?: null, 'created_at' => now()]); }
    static function entity(): string { return (string)setting('ns.entity', 'DIRECTION GENERALE'); }
    static function suffix(): string { return (string)setting('ns.ref_suffix', 'TGC/DG/CXO'); }
    static function cats(): array { return DB::all("SELECT v.code, v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='at_categories' AND v.active=1 ORDER BY v.sort_order, v.label"); }
    static function motif(?string $cat): ?array { if (!$cat) return null; $m = DB::one('SELECT m.*, t.name tname FROM ns_motifs m LEFT JOIN ns_templates t ON t.id=m.template_id WHERE m.category=? AND m.active=1', [$cat]); return $m ?: null; }
    /** Remplace les variables du modèle. */
    static function fill(string $txt, array $n): string {
        $tk = !empty($n['ticket_id']) ? DB::one('SELECT t.reference, s.name store FROM at_tickets t LEFT JOIN stores s ON s.id=t.store_id WHERE t.id=?', [(int)$n['ticket_id']]) : null;
        return strtr($txt, ['{demandeur}' => (string)DB::val('SELECT name FROM users WHERE id=?', [(int)($n['requester_id'] ?? 0)]), '{objet}' => (string)($n['title'] ?? ''), '{contexte}' => (string)($n['context'] ?? ''), '{ticket}' => (string)($tk['reference'] ?? ''), '{boutique}' => (string)($tk['store'] ?? ''), '{date}' => date('d/m/Y'), '{memo}' => (string)($n['memo_ref'] ?? '')]);
    }
    /** Crée une demande de note (depuis l'écran dédié ou depuis un ticket) et prévient le secrétariat. */
    static function request(array $d, int $requester): int {
        $tpl = !empty($d['template_id']) ? DB::one('SELECT * FROM ns_templates WHERE id=? AND active=1', [(int)$d['template_id']]) : null;
        $n = ['template_id' => $tpl['id'] ?? null, 'ticket_id' => $d['ticket_id'] ?? null, 'title' => mb_substr((string)$d['title'], 0, 200), 'addressee' => mb_substr((string)($d['addressee'] ?? ($tpl['addressee'] ?? '')), 0, 200) ?: null, 'memo_ref' => mb_substr((string)($d['memo_ref'] ?? ''), 0, 80) ?: null, 'context' => mb_substr((string)($d['context'] ?? ''), 0, 5000) ?: null,
            'entity' => $tpl['entity'] ?? self::entity(), 'ref_suffix' => $tpl['ref_suffix'] ?? self::suffix(), 'signer_title' => $tpl['signer_title'] ?? null, 'signer_id' => $tpl['signer_id'] ?? null, 'requester_id' => $requester, 'status' => 'requested', 'place' => (string)setting('ns.place', 'Lomé'), 'created_at' => now(), 'updated_at' => now()];
        $n['body'] = $tpl ? self::fill((string)$tpl['body'], $n) : null;
        $id = (int)DB::insert('ns_notes', $n); self::log($id, 'request', $n['title']);
        foreach (ESign::usersWith('ns.secretary') as $u) if ((int)$u['id'] !== (int)Auth::id()) Notifier::send((int)$u['id'], 'Note de service à rédiger', $n['title'] . ' — demandée par ' . DB::val('SELECT name FROM users WHERE id=?', [$requester]), '/ns/' . $id);
        if (!empty($n['ticket_id'])) Tickets::event((int)$n['ticket_id'], 'link', 'Note de service demandée au secrétariat : ' . $n['title'], Auth::id());
        return $id;
    }
    static function sees(array $n): bool { $me = (int)Auth::id(); return can('ns.secretary') || can('ns.all') || (int)$n['requester_id'] === $me || (int)$n['signer_id'] === $me || (bool)DB::val("SELECT 1 FROM esign WHERE doc_type='ns' AND doc_id=? AND user_id=?", [(int)$n['id'], $me]); }
    static function hash(array $n): string { return hash('sha256', implode('|', [$n['title'], $n['addressee'], $n['memo_ref'], $n['body']])); }
    static function number(string $table): array { $y = (int)date('Y'); $no = (int)DB::val("SELECT MAX(ref_no) FROM $table WHERE year=?", [$y]) + 1; return [$no, $y]; }
    static function visas(?string $json): array { $v = json_decode((string)$json, true); return is_array($v) ? array_values(array_filter($v, fn($x) => !empty($x['label']) && !empty($x['user_id']))) : []; }

    // ───── Mémos ─────
    static function mmSees(array $m): bool { $me = (int)Auth::id(); return can('mm.all') || (int)$m['author_id'] === $me || (int)$m['n1_id'] === $me || (bool)DB::val("SELECT 1 FROM esign WHERE doc_type='memo' AND doc_id=? AND user_id=?", [(int)$m['id'], $me]); }
    static function mmHash(array $m): string { return hash('sha256', implode('|', [$m['subject'], $m['author_entity'], $m['addressee'], $m['body'], $m['annex']])); }
}
