<?php
namespace App\Core;
/** Construit le DDL MySQL ou SQLite à partir d'une définition unique (database/schema.php). */
class Schema {
    static function parse(string $spec): array {
        $p = explode(':', $spec); $o = ['type' => array_shift($p), 'len' => null, 'req' => false, 'uniq' => false, 'idx' => false, 'fk' => null, 'def' => null];
        foreach ($p as $x) {
            if (ctype_digit($x)) $o['len'] = (int)$x;
            elseif ($x === 'req') $o['req'] = true;
            elseif ($x === 'uniq') $o['uniq'] = true;
            elseif ($x === 'idx') $o['idx'] = true;
            elseif (str_starts_with($x, 'fk=')) { $o['fk'] = substr($x, 3); $o['idx'] = true; }
            elseif (str_starts_with($x, 'def=')) $o['def'] = substr($x, 4);
        }
        return $o;
    }
    static function ddl(string $driver, ?array $only = null): array {
        $defs = require ROOT . '/database/schema.php';
        $out = []; $deps = [];
        foreach ($defs as $table => $cols) {
            if ($only && !in_array($table, $only)) continue;
            $lines = []; $idx = []; $fks = []; $deps[$table] = [];
            foreach ($cols as $name => $spec) {
                $c = self::parse($spec); $t = $c['type'];
                if ($t === 'id') { $lines[] = $driver === 'sqlite' ? "$name INTEGER PRIMARY KEY AUTOINCREMENT" : "$name BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY"; continue; }
                $sql = match ($t) {
                    'str' => ($driver === 'sqlite' ? 'TEXT' : 'VARCHAR(' . ($c['len'] ?? 190) . ')'),
                    'txt' => 'TEXT',
                    'int' => ($c['fk'] && $driver !== 'sqlite') ? 'BIGINT UNSIGNED' : ($driver === 'sqlite' ? 'INTEGER' : 'INT'),
                    'bool' => $driver === 'sqlite' ? 'INTEGER' : 'TINYINT(1)',
                    'date' => $driver === 'sqlite' ? 'TEXT' : 'DATE',
                    'dt' => $driver === 'sqlite' ? 'TEXT' : 'DATETIME',
                    'dec' => $driver === 'sqlite' ? 'REAL' : 'DECIMAL(12,2)',
                };
                $line = "$name $sql";
                if ($c['req']) $line .= ' NOT NULL';
                if ($t === 'bool') $line .= ' NOT NULL DEFAULT ' . ($c['def'] ?? '0');
                elseif ($c['def'] !== null) $line .= " DEFAULT '" . $c['def'] . "'";
                if ($c['uniq']) $line .= ' UNIQUE';
                $lines[] = $line;
                if ($c['fk']) { if ($c['fk'] !== $table) $deps[$table][] = $c['fk']; } if ($c['fk']) $fks[] = "FOREIGN KEY ($name) REFERENCES {$c['fk']}(id)";
                if ($c['idx'] && !$c['uniq']) $idx[] = "CREATE INDEX idx_{$table}_$name ON $table($name)";
            }
            $lines = array_merge($lines, $fks);
            $tail = $driver === 'sqlite' ? '' : ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
            $out[] = ['table' => $table, 'create' => "CREATE TABLE IF NOT EXISTS $table (\n  " . implode(",\n  ", $lines) . "\n)$tail", 'indexes' => $idx];
        }
        // MySQL exige que la table référencée existe déjà : tri par dépendances (ordre d'origine conservé autrement).
        $by = []; foreach ($out as $t) $by[$t['table']] = $t; $sorted = []; $done = [];
        while ($by) { $progress = false;
            foreach ($by as $n => $t) { if (!array_filter($deps[$n] ?? [], fn($d) => isset($by[$d]) && !isset($done[$d]))) { $sorted[] = $t; $done[$n] = true; unset($by[$n]); $progress = true; } }
            if (!$progress) { foreach ($by as $t) $sorted[] = $t; break; } }
        return $sorted;
    }
    /** Triggers rendant un journal en ajout seul. */
    static function appendOnlyTriggers(string $driver, string $table): array {
        if ($driver === 'sqlite') {
            return [
                "CREATE TRIGGER IF NOT EXISTS {$table}_no_update BEFORE UPDATE ON $table BEGIN SELECT RAISE(ABORT, '$table est en ajout seul'); END",
                "CREATE TRIGGER IF NOT EXISTS {$table}_no_delete BEFORE DELETE ON $table BEGIN SELECT RAISE(ABORT, '$table est en ajout seul'); END",
            ];
        }
        return [
            "DROP TRIGGER IF EXISTS {$table}_no_update", "CREATE TRIGGER {$table}_no_update BEFORE UPDATE ON $table FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '$table est en ajout seul'",
            "DROP TRIGGER IF EXISTS {$table}_no_delete", "CREATE TRIGGER {$table}_no_delete BEFORE DELETE ON $table FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '$table est en ajout seul'",
        ];
    }
    static function migrate(): void {
        $drv = DB::driver();
        foreach (self::ddl($drv) as $t) {
            DB::pdo()->exec($t["create"]);
            foreach ($t['indexes'] as $i) { try { DB::pdo()->exec($i); } catch (\Throwable $e) { /* index déjà présent */ } }
        }
        foreach (self::appendOnlyTriggers($drv, "audit_logs") as $s) DB::pdo()->exec($s);
    }
}
