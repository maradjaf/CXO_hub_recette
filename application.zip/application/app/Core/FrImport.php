<?php
namespace App\Core;

/**
 * Lot 60 — Franchises : reprise historique (Excel/CSV), file de correction, rapprochement BOSS / TRAITEMENT / Restitution.
 * Un même fichier rejoué ne crée aucun doublon (clé de contenu + rang d'occurrence). Les valeurs vides, inconnues et nulles restent distinctes.
 */
final class FrImport {
    const SYN = [
        'day' => ['date', 'jour', 'day', 'statsdate', 'datecreation', 'datetraitement', 'datedemande'], 'franchise' => ['franchise', 'codefranchise', 'codefranchisebt', 'codebt', 'site', 'pointdevente', 'pdv', 'boutique', 'code', 'nomfranchise'],
        'service' => ['service', 'libelle', 'operation', 'typeoperation', 'type', 'produit', 'natureoperation'], 'typology' => ['typologie', 'typedemande'], 'status' => ['statut', 'status', 'resultat', 'etat', 'traitement', 'etattraitement'],
        'iccid' => ['iccid', 'sim', 'numerosim', 'numsim'], 'customer' => ['client', 'numeroclient', 'msisdn', 'numero', 'contact', 'idclient', 'numclient'], 'agent' => ['agent', 'conseiller', 'utilisateur', 'declarant', 'operateur'],
        'reason' => ['motif', 'raison', 'commentaire'], 'op_ref' => ['referenceoperation', 'refoperation', 'idexecution', 'refop'],
    ];
    const SHEETS = ['BOSS' => 'boss', 'TRAITEMENT' => 'traitement', 'RESTITUTION' => 'restitution'];

    /** Lit un fichier XLSX ou CSV : feuille => lignes. @return array{0:array,1:?string} */
    static function read(string $path, string $name): array {
        if (preg_match('/\.xlsx?$/i', $name)) return Xlsx::read($path);
        [$head, $rows] = Importer::parse($path); $out = [1 => array_map(fn($h, $i) => $h, $head, array_keys($head))]; $n = 1;
        foreach ($rows as $r) $out[++$n] = array_values($r['data']); return [['CSV' => $out], null];
    }
    /** Trouve la ligne d'en-tête et les colonnes. @return array{0:?int,1:array<string,int>} */
    static function header(array $rows): array {
        $i = 0;
        foreach ($rows as $n => $cells) { if (++$i > 15) break; $map = [];
            foreach ($cells as $c => $txt) { $k = Fr::norm((string)$txt); foreach (self::SYN as $f => $syn) if (!isset($map[$f]) && in_array($k, $syn, true)) { $map[$f] = (int)$c; break; } }
            if (isset($map['day']) && (isset($map['franchise']) || isset($map['service']))) return [(int)$n, $map]; }
        return [null, []];
    }
    private static function cell(array $cells, array $map, string $f): ?string { if (!isset($map[$f])) return null; $v = trim((string)($cells[$map[$f]] ?? '')); return $v === '' ? null : $v; }
    private static function unknownToken(?string $v): bool { return $v !== null && in_array(Fr::norm($v), ['inconnu', 'na', 'nd', 'nc', 'null', 'none'], true); }

    // ───────────────────────── Reprise (BOSS / TRAITEMENT / Restitution) ─────────────────────────
    /**
     * Analyse (et enregistre si $commit) un classeur de reprise. @return array statistiques, anomalies (liste), erreurs
     * @param array $sheets feuille => lignes
     */
    static function reprise(array $sheets, bool $commit, string $fileName, ?int $batchId = null): array {
        $st = ['sheets' => [], 'read' => 0, 'ok' => 0, 'dup' => 0, 'reject' => 0, 'ambig' => 0, 'warn' => 0, 'errors' => [], 'from' => null, 'to' => null]; $issues = []; $keys = []; $rowsOut = []; $seen = [];
        Fr::resetMap();
        foreach ($sheets as $sheet => $rows) {
            $src = null; foreach (self::SHEETS as $S => $needle) if (str_contains(Fr::norm((string)$sheet), $needle)) $src = $S;
            if ($src === null) { $st['sheets'][$sheet] = ['source' => null, 'read' => 0, 'note' => 'Feuille ignorée (ni BOSS, ni TRAITEMENT, ni Restitution).']; continue; }
            [$h, $map] = self::header($rows); if ($h === null) { $st['errors'][] = "Feuille « $sheet » : en-tête introuvable (colonnes Date et Franchise ou Service attendues)."; continue; }
            $info = ['source' => $src, 'read' => 0, 'ok' => 0, 'dup' => 0, 'reject' => 0, 'header_row' => $h, 'columns' => array_keys($map)]; $occ = [];
            foreach ($rows as $n => $cells) {
                if ($n <= $h) continue; $info['read']++; $st['read']++;
                $dayRaw = self::cell($cells, $map, 'day'); $day = $dayRaw === null ? null : Xlsx::day($dayRaw);
                if ($day === null) { $issues[] = [$sheet, $n, 'Date', $dayRaw, $dayRaw === null ? 'Date absente : ligne non retenue.' : 'Date illisible : ligne non retenue.', 'reject']; $info['reject']++; $st['reject']++; continue; }
                $fr = self::cell($cells, $map, 'franchise'); $svc = self::cell($cells, $map, 'service'); $stat = self::cell($cells, $map, 'status'); $icc = self::cell($cells, $map, 'iccid'); $cust = self::cell($cells, $map, 'customer'); $ag = self::cell($cells, $map, 'agent');
                if (self::unknownToken($stat)) $stat = 'Inconnu';
                $fid = null; if ($fr !== null) { [$fid, $why] = Fr::resolve($fr); if ($why !== 'ok') { $issues[] = [$sheet, $n, 'Franchise', $fr, $why === 'ambiguous' ? 'Code ou nom rattaché à plusieurs franchises : à corriger.' : 'Code inconnu du référentiel : à rattacher.', 'ambig']; $st['ambig']++; } }
                if ($icc !== null && preg_match('/^\d+(\.\d+)?[eE][+-]?\d+$/', $icc)) { $issues[] = [$sheet, $n, 'ICCID', $icc, 'ICCID enregistré en nombre : précision perdue (à ressaisir en texte).', 'warn']; $st['warn']++; }
                $base = implode('|', [$src, $sheet, $day, Fr::norm((string)$fr), Fr::norm((string)$svc), Fr::norm((string)$stat), (string)$icc, (string)$cust, Fr::norm((string)$ag)]); $occ[$base] = ($occ[$base] ?? 0) + 1;
                $key = sha1($base . '#' . $occ[$base]); $keys[] = $key;
                $rowsOut[] = ['source' => $src, 'sheet' => (string)$sheet, 'row_no' => $n, 'day' => $day, 'franchise_id' => $fid, 'franchise_raw' => $fr === null ? null : mb_substr($fr, 0, 120), 'service' => $svc === null ? null : mb_substr($svc, 0, 80), 'status_label' => $stat === null ? null : mb_substr($stat, 0, 80),
                    'cust_mask' => $cust === null ? null : Fr::mask($cust), 'iccid' => $icc === null ? null : mb_substr($icc, 0, 30), 'agent' => $ag === null ? null : mb_substr($ag, 0, 100), 'skey' => $key];
                $st['from'] = $st['from'] === null ? $day : min($st['from'], $day); $st['to'] = $st['to'] === null ? $day : max($st['to'], $day);
            }
            $st['sheets'][$sheet] = $info;
        }
        $existing = []; foreach (array_chunk($keys, 500) as $ch) foreach (DB::all('SELECT skey FROM fr_src WHERE skey IN (' . implode(',', array_fill(0, count($ch), '?')) . ')', $ch) as $r) $existing[$r['skey']] = 1;
        $new = []; foreach ($rowsOut as $r) { if (isset($existing[$r['skey']])) { $st['dup']++; $st['sheets'][$r['sheet']]['dup'] = ($st['sheets'][$r['sheet']]['dup'] ?? 0) + 1; } else $new[] = $r; }
        $st['ok'] = count($new); foreach ($new as $r) $st['sheets'][$r['sheet']]['ok'] = ($st['sheets'][$r['sheet']]['ok'] ?? 0) + 1;
        $st['by_source'] = []; foreach ($new as $r) $st['by_source'][$r['source']] = ($st['by_source'][$r['source']] ?? 0) + 1;
        if (!$commit) return [$st, $issues];
        $pdo = DB::pdo(); $own = !$pdo->inTransaction(); if ($own) $pdo->beginTransaction();
        try {
            $bid = $batchId ?: DB::insert('fr_batches', ['kind' => 'reprise', 'name' => mb_substr($fileName, 0, 190), 'sheets' => mb_substr(implode(', ', array_keys($st['sheets'])), 0, 300), 'period_from' => $st['from'], 'period_to' => $st['to'], 'rows_read' => $st['read'], 'rows_ok' => $st['ok'], 'rows_dup' => $st['dup'], 'rows_rejected' => $st['reject'], 'rows_amb' => $st['ambig'], 'stats' => json_encode($st, JSON_UNESCAPED_UNICODE), 'user_id' => Auth::id(), 'created_at' => now()]);
            foreach ($new as &$r) $r['batch_id'] = $bid; unset($r); self::bulk('fr_src', ['batch_id', 'source', 'sheet', 'row_no', 'day', 'franchise_id', 'franchise_raw', 'service', 'status_label', 'cust_mask', 'iccid', 'agent', 'skey'], $new);
            self::saveIssues($bid, $issues); if ($own) $pdo->commit();
        } catch (\Throwable $e) { if ($own) $pdo->rollBack(); throw $e; }
        FrStats::resetCache(); $st['batch_id'] = $bid; return [$st, $issues];
    }
    private static function saveIssues(int $bid, array $issues): void {
        $rows = []; foreach ($issues as [$sheet, $n, $fld, $val, $why, $kind]) $rows[] = ['batch_id' => $bid, 'kind' => $kind, 'sheet' => $sheet, 'row_no' => $n, 'fld' => $fld, 'val_text' => $val === null ? null : mb_substr(in_array($fld, ['ICCID', 'Client'], true) ? Fr::mask((string)$val) : (string)$val, 0, 300), 'reason' => $why, 'status' => $kind === 'warn' ? 'ignored' : 'open', 'created_at' => now()];
        self::bulk('fr_rejects', ['batch_id', 'kind', 'sheet', 'row_no', 'fld', 'val_text', 'reason', 'status', 'created_at'], $rows);
    }
    /** Insertion multi-lignes par paquets. */
    static function bulk(string $table, array $cols, array $rows): void {
        foreach (array_chunk($rows, 200) as $ch) { $ph = '(' . implode(',', array_fill(0, count($cols), '?')) . ')'; $p = [];
            foreach ($ch as $r) foreach ($cols as $c) $p[] = $r[$c] ?? null; DB::run("INSERT INTO $table (" . implode(',', $cols) . ') VALUES ' . implode(',', array_fill(0, count($ch), $ph)), $p); }
    }

    // ───────────────────────── Dossiers (fichier de traitement, saisies Excel) ─────────────────────────
    /**
     * Crée les dossiers d'un tableau (une feuille) : statuts repris par le dictionnaire des libellés, cas ambigus envoyés en file de correction.
     * @return array{0:array,1:array} statistiques, anomalies
     */
    static function dossiers(array $sheets, bool $commit, string $fileName): array {
        $st = ['read' => 0, 'ok' => 0, 'dup' => 0, 'reject' => 0, 'ambig' => 0, 'warn' => 0, 'errors' => [], 'sheets' => [], 'from' => null, 'to' => null, 'by_status' => []]; $issues = []; $plan = [];
        Fr::resetMap(); $map = []; foreach (DB::all('SELECT * FROM fr_status_map') as $m) $map[$m['raw']] = $m; $cats = DB::all('SELECT * FROM fr_catalog WHERE active=1 ORDER BY sort_order, id'); $dict = []; foreach (DB::all('SELECT * FROM fr_opdict') as $o) $dict[Fr::norm($o['label'])] = $o;
        foreach ($sheets as $sheet => $rows) {
            [$h, $cols] = self::header($rows); if ($h === null) { $st['errors'][] = "Feuille « $sheet » : en-tête introuvable (Date, Franchise et Service attendus)."; continue; } $info = ['read' => 0, 'ok' => 0]; $occ = [];
            foreach ($rows as $n => $cells) {
                if ($n <= $h) continue; $st['read']++; $info['read']++;
                $day = Xlsx::day((string)self::cell($cells, $cols, 'day')); $fr = self::cell($cells, $cols, 'franchise'); $svc = self::cell($cells, $cols, 'service'); $stat = self::cell($cells, $cols, 'status'); $icc = self::cell($cells, $cols, 'iccid'); $cust = self::cell($cells, $cols, 'customer');
                $ag = self::cell($cells, $cols, 'agent'); $why = self::cell($cells, $cols, 'reason'); $typ = self::cell($cells, $cols, 'typology'); $opref = self::cell($cells, $cols, 'op_ref');
                if ($day === null) { $issues[] = [$sheet, $n, 'Date', self::cell($cells, $cols, 'day'), 'Date absente ou illisible : ligne non retenue.', 'reject']; $st['reject']++; continue; }
                if ($fr === null) { $issues[] = [$sheet, $n, 'Franchise', null, 'Franchise non renseignée : ligne non retenue.', 'reject']; $st['reject']++; continue; }
                [$fid, $w] = Fr::resolve($fr); if ($fid === null) { $issues[] = [$sheet, $n, 'Franchise', $fr, $w === 'ambiguous' ? 'Code ou nom rattaché à plusieurs franchises : cas ambigu.' : 'Franchise inconnue : cas ambigu à rattacher.', 'ambig']; $st['ambig']++; continue; }
                $cat = null; foreach ($cats as $c) if ($svc !== null && Fr::norm($c['service']) === Fr::norm($svc) && ($typ === null || Fr::norm($c['typology']) === Fr::norm($typ))) { $cat = $c; break; }
                if (!$cat) { $issues[] = [$sheet, $n, 'Service', $svc, 'Service ou typologie absent du catalogue : cas ambigu.', 'ambig']; $st['ambig']++; continue; }
                $m = $stat === null ? null : ($map[Fr::norm($stat)] ?? null);
                if (!$m) { $issues[] = [$sheet, $n, 'Statut', $stat, $stat === null ? 'Statut absent : cas ambigu.' : 'Libellé de statut non repris au dictionnaire : cas ambigu.', 'ambig']; $st['ambig']++; continue; }
                if ($m['status'] === 'executed' && !isset($dict[Fr::norm((string)$svc)])) { $issues[] = [$sheet, $n, 'Service', $svc, 'Exécution déclarée mais type d\'opération absent du dictionnaire : cas ambigu.', 'ambig']; $st['ambig']++; continue; }
                if ($icc !== null && preg_match('/^\d+(\.\d+)?[eE][+-]?\d+$/', $icc)) { $issues[] = [$sheet, $n, 'ICCID', $icc, 'ICCID enregistré en nombre : précision perdue (non repris).', 'warn']; $st['warn']++; $icc = null; }
                elseif ($icc !== null && !preg_match('/^\d{18,22}$/', $icc)) { $issues[] = [$sheet, $n, 'ICCID', $icc, 'ICCID invalide (18 à 22 chiffres) : non repris.', 'warn']; $st['warn']++; $icc = null; }
                $base = implode('|', ['dos', $day, $fid, Fr::norm((string)$svc), Fr::norm((string)$typ), Fr::norm((string)$stat), (string)$icc, (string)$cust, Fr::norm((string)$ag)]); $occ[$base] = ($occ[$base] ?? 0) + 1; $key = sha1($base . '#' . $occ[$base]);
                $plan[] = ['key' => $key, 'day' => $day, 'fid' => $fid, 'cat' => $cat, 'status' => $m['status'], 'reason_id' => $m['reason_id'], 'icc' => $icc, 'cust' => $cust, 'agent' => $ag, 'why' => $why, 'opref' => $opref, 'svc' => $svc, 'sheet' => $sheet, 'row' => $n, 'stat' => $stat];
            }
            $st['sheets'][$sheet] = $info;
        }
        $keys = array_column($plan, 'key'); $existing = [];
        foreach (array_chunk($keys, 500) as $ch) foreach (DB::all('SELECT import_key FROM fr_requests WHERE import_key IN (' . implode(',', array_fill(0, count($ch), '?')) . ')', $ch) as $r) $existing[$r['import_key']] = 1;
        $todo = []; foreach ($plan as $p) { if (isset($existing[$p['key']])) $st['dup']++; else { $todo[] = $p; $st['by_status'][$p['status']] = ($st['by_status'][$p['status']] ?? 0) + 1; $st['from'] = $st['from'] === null ? $p['day'] : min($st['from'], $p['day']); $st['to'] = $st['to'] === null ? $p['day'] : max($st['to'], $p['day']); } }
        $st['ok'] = count($todo); if (!$commit) return [$st, $issues];
        $pdo = DB::pdo(); $own = !$pdo->inTransaction(); if ($own) $pdo->beginTransaction();
        try {
            $bid = DB::insert('fr_batches', ['kind' => 'dossiers', 'name' => mb_substr($fileName, 0, 190), 'sheets' => mb_substr(implode(', ', array_keys($st['sheets'])), 0, 300), 'period_from' => $st['from'], 'period_to' => $st['to'], 'rows_read' => $st['read'], 'rows_ok' => $st['ok'], 'rows_dup' => $st['dup'], 'rows_rejected' => $st['reject'], 'rows_amb' => $st['ambig'], 'stats' => json_encode($st, JSON_UNESCAPED_UNICODE), 'user_id' => Auth::id(), 'created_at' => now()]);
            Fr::$system = true;
            foreach ($todo as $p) self::oneDossier($p, $bid);
            self::saveIssues($bid, $issues); if ($own) $pdo->commit();
        } catch (\Throwable $e) { if ($own) $pdo->rollBack(); Fr::$system = false; throw $e; }
        Fr::$system = false; FrStats::resetCache(); $st['batch_id'] = $bid; return [$st, $issues];
    }
    private static function oneDossier(array $p, int $bid): void {
        $at = $p['day'] . ' 09:00:00'; $cat = $p['cat'];
        [$id, $err] = Fr::create(['franchise_id' => $p['fid'], 'catalog_id' => $cat['id'], 'created_at' => $at, 'reporter' => $p['agent'] ?: 'Reprise Excel', 'channel' => 'excel', 'customer_no' => $p['cust'], 'iccid' => $p['icc'], 'comment' => $p['why'], 'import_key' => $p['key'], 'batch_id' => $bid, 'priority' => 'normal', 'team' => 'BO']);
        if (!$id) throw new \RuntimeException('Création du dossier impossible : ' . $err); $close = $p['day'] . ' 16:00:00'; $s = $p['status']; $r = DB::one('SELECT * FROM fr_requests WHERE id=?', [$id]);
        if ($s === 'executed') { $e = Fr::act($id, 'take', [], $p['day'] . ' 10:00:00'); $e = $e ?: Fr::act($id, 'execute', ['action_done' => 'Traitement repris du fichier source', 'executed_at' => $close, 'op_type' => [$p['svc']], 'op_ref' => [$p['opref'] ?: 'IMP-' . substr($p['key'], 0, 12)]], $close); if ($e) throw new \RuntimeException($e); }
        elseif ($s === 'waiting') { $e = Fr::act($id, 'take', [], $p['day'] . ' 10:00:00'); if ($e) throw new \RuntimeException($e); $rid = $p['reason_id'] ?: (int)DB::val("SELECT id FROM fr_reasons WHERE kind='hold' ORDER BY id LIMIT 1"); $e = Fr::act($id, 'hold', ['reason_id' => $rid, 'wait_owner' => 'Franchise', 'wait_action' => $p['why'] ?: 'Complément à fournir (repris du fichier)'], $close); if ($e) throw new \RuntimeException($e); }
        elseif (in_array($s, ['rejected', 'cancelled', 'not_executed'], true)) { $k = ['rejected' => 'reject', 'cancelled' => 'cancel', 'not_executed' => 'noexec'][$s]; $rid = $p['reason_id'] ?: (int)DB::val('SELECT id FROM fr_reasons WHERE kind=? ORDER BY id LIMIT 1', [$k]); $e = Fr::act($id, 'take', [], $p['day'] . ' 10:00:00'); $e = $e ?: Fr::act($id, $k, ['reason_id' => $rid, 'note' => $p['why'] ?: 'Repris du fichier : ' . $p['stat']], $close); if ($e) throw new \RuntimeException($e); }
        elseif ($s === 'in_progress') { $e = Fr::act($id, 'take', [], $p['day'] . ' 10:00:00'); if ($e) throw new \RuntimeException($e); }
    }

    // ───────────────────────── File de correction ─────────────────────────
    /** Rattache une ligne ambiguë à une franchise (et mémorise l'alias de la source si demandé). */
    static function fix(int $rejectId, int $fid, bool $alias): ?string {
        $r = DB::one('SELECT * FROM fr_rejects WHERE id=?', [$rejectId]); if (!$r) return 'Anomalie introuvable.'; if ($r['status'] !== 'open') return 'Anomalie déjà traitée.'; if ($r['kind'] !== 'ambig' || $r['fld'] !== 'Franchise') return 'Seule une franchise ambiguë se corrige ici.';
        $f = Fr::franchise($fid); if (!$f) return 'Choisissez une franchise du référentiel.'; $raw = (string)$r['val_text'];
        $src = DB::one('SELECT id FROM fr_src WHERE batch_id=? AND sheet=? AND row_no=?', [$r['batch_id'], $r['sheet'], $r['row_no']]);
        if ($src) DB::update('fr_src', ['franchise_id' => $fid], 'id=?', [$src['id']]);
        if ($alias && $raw !== '' && !DB::val('SELECT 1 FROM fr_aliases WHERE franchise_id=? AND alias=?', [$fid, $raw])) { DB::insert('fr_aliases', ['franchise_id' => $fid, 'alias' => mb_substr($raw, 0, 190), 'kind' => 'bt', 'created_at' => now()]); Fr::resetMap(); }
        if ($alias && $raw !== '') foreach (DB::all('SELECT x.id FROM fr_rejects x WHERE x.status=? AND x.fld=? AND x.val_text=? AND x.id<>?', ['open', 'Franchise', $raw, $rejectId]) as $o) { $s2 = DB::one('SELECT x.batch_id, x.sheet, x.row_no FROM fr_rejects x WHERE x.id=?', [$o['id']]); $sr = DB::one('SELECT id FROM fr_src WHERE batch_id=? AND sheet=? AND row_no=?', [$s2['batch_id'], $s2['sheet'], $s2['row_no']]); if ($sr) DB::update('fr_src', ['franchise_id' => $fid], 'id=?', [$sr['id']]); DB::update('fr_rejects', ['status' => 'fixed', 'correction' => 'Rattachée à ' . $f['name'] . ' (alias mémorisé)', 'resolved_by' => Auth::id(), 'resolved_at' => now()], 'id=?', [$o['id']]); }
        DB::update('fr_rejects', ['status' => 'fixed', 'correction' => 'Rattachée à ' . $f['name'] . ($alias ? ' (alias mémorisé)' : ''), 'resolved_by' => Auth::id(), 'resolved_at' => now()], 'id=?', [$rejectId]);
        Audit::log('fr.correct', 'fr_rejects', $rejectId, ['valeur' => $raw], ['franchise' => $f['name']]); FrStats::resetCache(); return null;
    }

    // ───────────────────────── Rapprochement ─────────────────────────
    const CATS = ['nofr' => 'Sans franchise renseignée ou identifiée', 'nodict' => 'Service hors dictionnaire des opérations comptées', 'noexec' => 'Traitement non effectué', 'dup' => 'Doublon (même jour, franchise, service et ICCID)'];
    /** Rapproche TRAITEMENT (et BOSS) de la Restitution sur une plage. Enregistre la catégorie de chaque ligne TRAITEMENT. */
    static function reconcile(string $from, string $to, bool $store = true): array {
        $counted = []; foreach (DB::all('SELECT label FROM fr_opdict WHERE counted=1') as $o) $counted[Fr::norm($o['label'])] = 1; $mapNo = [];
        foreach (DB::all('SELECT raw, status FROM fr_status_map') as $m) if (in_array($m['status'], ['rejected', 'cancelled', 'not_executed'], true)) $mapNo[$m['raw']] = 1;
        $tot = []; foreach (['BOSS', 'TRAITEMENT', 'RESTITUTION'] as $s) $tot[$s] = (int)DB::val('SELECT COUNT(*) FROM fr_src WHERE source=? AND day>=? AND day<=?', [$s, $from, $to]);
        $lines = DB::all("SELECT id, row_no, day, franchise_id, service, status_label, iccid FROM fr_src WHERE source='TRAITEMENT' AND day>=? AND day<=? ORDER BY row_no, id", [$from, $to]); $cat = []; $seen = []; $upd = [];
        foreach ($lines as $l) {
            if ($l['franchise_id'] === null) $c = 'nofr'; elseif ($l['service'] === null || !isset($counted[Fr::norm((string)$l['service'])])) $c = 'nodict'; elseif (isset($mapNo[Fr::norm((string)$l['status_label'])])) $c = 'noexec';
            else { $c = 'ret'; if ($l['iccid'] !== null) { $k = $l['day'] . '|' . $l['franchise_id'] . '|' . Fr::norm((string)$l['service']) . '|' . $l['iccid']; if (isset($seen[$k])) $c = 'dup'; else $seen[$k] = 1; } }
            $cat[$c] = ($cat[$c] ?? 0) + 1; $upd[$c][] = (int)$l['id'];
        }
        if ($store) { DB::exec("UPDATE fr_src SET cat=NULL WHERE source='TRAITEMENT' AND day>=? AND day<=?", [$from, $to]); foreach ($upd as $c => $ids) foreach (array_chunk($ids, 500) as $ch) DB::exec("UPDATE fr_src SET cat='$c' WHERE id IN (" . implode(',', $ch) . ')'); }
        $ret = (int)($cat['ret'] ?? 0); $explained = (int)(($cat['nofr'] ?? 0) + ($cat['nodict'] ?? 0) + ($cat['noexec'] ?? 0) + ($cat['dup'] ?? 0)); $gap = $tot['TRAITEMENT'] - $tot['RESTITUTION'];
        // cellules (jour, franchise, service) : lignes retenues vs restitution
        $a = []; foreach (DB::all("SELECT day, franchise_id, service, COUNT(*) n FROM fr_src WHERE source='TRAITEMENT' AND cat='ret' AND day>=? AND day<=? GROUP BY day, franchise_id, service", [$from, $to]) as $r) $a[$r['day'] . '|' . $r['franchise_id'] . '|' . $r['service']] = (int)$r['n'];
        $b = []; foreach (DB::all("SELECT day, franchise_id, service, COUNT(*) n FROM fr_src WHERE source='RESTITUTION' AND franchise_id IS NOT NULL AND service IS NOT NULL AND day>=? AND day<=? GROUP BY day, franchise_id, service", [$from, $to]) as $r) $b[$r['day'] . '|' . $r['franchise_id'] . '|' . $r['service']] = (int)$r['n'];
        $cells = []; foreach (array_unique(array_merge(array_keys($a), array_keys($b))) as $k) { $d = ($a[$k] ?? 0) - ($b[$k] ?? 0); if ($d !== 0) { [$day, $fid, $svc] = explode('|', $k, 3); $cells[] = ['day' => $day, 'fid' => (int)$fid, 'service' => $svc, 'retained' => $a[$k] ?? 0, 'restitution' => $b[$k] ?? 0, 'diff' => $d]; } }
        usort($cells, fn($x, $y) => [$x['day'], $x['fid']] <=> [$y['day'], $y['fid']]);
        // BOSS ↔ TRAITEMENT : comparaison position par position sur les champs communs
        $pos = ['same_count' => $tot['BOSS'] === $tot['TRAITEMENT'], 'concordant' => 0, 'diffs' => [], 'diff_count' => 0, 'nofr_boss' => (int)DB::val("SELECT COUNT(*) FROM fr_src WHERE source='BOSS' AND franchise_id IS NULL AND (franchise_raw IS NULL OR franchise_raw='') AND day>=? AND day<=?", [$from, $to])];
        if ($pos['same_count']) {
            $bo = DB::all("SELECT row_no, day, franchise_raw, service, status_label, iccid, agent, cust_mask FROM fr_src WHERE source='BOSS' AND day>=? AND day<=? ORDER BY row_no, id", [$from, $to]); $tr = DB::all("SELECT row_no, day, franchise_raw, service, status_label, iccid, agent, cust_mask FROM fr_src WHERE source='TRAITEMENT' AND day>=? AND day<=? ORDER BY row_no, id", [$from, $to]);
            foreach ($bo as $i => $x) { $y = $tr[$i] ?? null; if (!$y) break; $d = []; foreach (['day', 'franchise_raw', 'service', 'status_label', 'iccid', 'agent', 'cust_mask'] as $f) if ((string)$x[$f] !== (string)$y[$f]) $d[] = [$f, (string)$x[$f], (string)$y[$f]];
                if (!$d) $pos['concordant']++; else { $pos['diff_count']++; if (count($pos['diffs']) < 100) foreach ($d as [$f, $v1, $v2]) $pos['diffs'][] = ['row' => (int)$x['row_no'], 'field' => $f, 'boss' => $f === 'iccid' ? Fr::mask($v1) : $v1, 'trt' => $f === 'iccid' ? Fr::mask($v2) : $v2]; } }
        }
        return ['from' => $from, 'to' => $to, 'tot' => $tot, 'gap' => $gap, 'cats' => ['nofr' => (int)($cat['nofr'] ?? 0), 'nodict' => (int)($cat['nodict'] ?? 0), 'noexec' => (int)($cat['noexec'] ?? 0), 'dup' => (int)($cat['dup'] ?? 0)], 'retained' => $ret, 'explained' => $explained, 'residual' => $gap - $explained, 'cells' => $cells, 'pos' => $pos];
    }
    /** Règles d'inclusion / dictionnaire non validés : empêche la validation d'un état SND. */
    static function blockers(string $basis): array {
        $o = []; if ($basis === 'reprise') foreach (DB::all('SELECT label FROM fr_rules WHERE validated_at IS NULL ORDER BY position') as $r) $o[] = 'Règle d\'inclusion non validée : ' . $r['label'];
        foreach (DB::all('SELECT label FROM fr_opdict WHERE counted=1 AND (bo_ok IS NULL OR cxo_ok IS NULL) ORDER BY label') as $r) $o[] = 'Opération comptée non validée par le BO et CXO : ' . $r['label'];
        return $o;
    }
}
