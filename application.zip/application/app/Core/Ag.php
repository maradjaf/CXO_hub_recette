<?php
namespace App\Core;

/** Évaluation des agents : objectifs périodiques validés par le N+1, campagnes d'auto-évaluation avec preuves, relances avant la clôture. */
class Ag {
    const PT = ['week' => 'Hebdomadaire', 'month' => 'Mensuel', 'quarter' => 'Trimestriel'];
    const OS = ['submitted' => ['À valider', 'warning'], 'validated' => ['Validé', 'success'], 'rejected' => ['Refusé', 'danger']];
    const ES = ['todo' => ['À renseigner', 'warning'], 'self_done' => ['Auto-évaluation faite', 'info'], 'reviewed' => ['Évalué', 'success']];
    const CS = ['planned' => ['Planifiée', 'secondary'], 'open' => ['Ouverte', 'success'], 'closed' => ['Clôturée', 'dark']];
    const EV_TYPES = ['png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'pdf' => 'application/pdf', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
    static int $mails = 0;

    /** [début, fin] de la période (semaine du lundi au dimanche, mois, trimestre) contenant la date de référence. */
    static function period(string $type, string $ref): array {
        $t = strtotime($ref) ?: time();
        if ($type === 'week') { $s = date('Y-m-d', strtotime(date('Y-m-d', $t) . ' -' . ((int)date('N', $t) - 1) . ' day')); return [$s, date('Y-m-d', strtotime("$s +6 day"))]; }
        if ($type === 'quarter') { $m = 3 * intdiv((int)date('n', $t) - 1, 3) + 1; $s = date('Y-', $t) . sprintf('%02d', $m) . '-01'; return [$s, date('Y-m-t', strtotime("$s +2 month"))]; }
        return [date('Y-m-01', $t), date('Y-m-t', $t)];
    }
    static function next(string $type, string $start): array {
        $n = $type === 'week' ? "$start +7 day" : ($type === 'quarter' ? "$start +3 month" : "$start +1 month");
        return self::period($type, date('Y-m-d', strtotime($n)));
    }
    static function label(string $type, string $s, string $e): string {
        if ($type === 'week') return 'Semaine ' . date('W', strtotime($s)) . ' · ' . date('d/m', strtotime($s)) . ' – ' . date('d/m/Y', strtotime($e));
        if ($type === 'quarter') return 'T' . (intdiv((int)date('n', strtotime($s)) - 1, 3) + 1) . ' ' . date('Y', strtotime($s));
        $m = ['', 'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre']; return $m[(int)date('n', strtotime($s))] . ' ' . date('Y', strtotime($s));
    }
    static function myEmployee(): ?int { $u = Auth::user(); return $u && $u['employee_id'] ? (int)$u['employee_id'] : null; }
    static function userOfEmployee(?int $emp): ?int { return $emp ? (int)(DB::val("SELECT id FROM users WHERE employee_id=? AND status='active' ORDER BY id LIMIT 1", [$emp]) ?: 0) ?: null : null; }
    static function managerOf(int $emp): ?int { return (int)DB::val('SELECT manager_id FROM employees WHERE id=?', [$emp]) ?: null; }
    static function n1User(int $emp): ?int { return self::userOfEmployee(self::managerOf($emp)); }
    static function name(?int $emp): string { $e = $emp ? DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [$emp]) : null; return $e ? trim($e['last_name'] . ' ' . $e['first_name']) : '—'; }
    /** Collaborateurs que l'utilisateur encadre directement (N+1) ; null = tous (gestionnaire). */
    static function reports(): ?array {
        if (can('ag.manage')) return null; $me = self::myEmployee(); if (!$me || !can('ag.team')) return [];
        return array_map(fn($r) => (int)$r['id'], DB::all('SELECT id FROM employees WHERE manager_id=?', [$me]));
    }
    /** Fragment SQL limitant une colonne aux collaborateurs visibles : soi-même, son équipe directe, ou tous. */
    static function scope(string $col, array &$p): string {
        $r = self::reports(); if ($r === null) return '1=1'; $me = self::myEmployee(); if ($me) $r[] = $me;
        if (!$r) return '0=1'; return "$col IN (" . implode(',', array_map('intval', $r)) . ')';
    }
    static function canSee(int $emp): bool { $r = self::reports(); return $r === null || $emp === self::myEmployee() || in_array($emp, $r, true); }
    static function canSet(int $emp): bool { $r = self::reports(); return $r === null || ($r && in_array($emp, $r, true)); }
    static function canValidate(array $o): bool { return self::canSet((int)$o['employee_id']); }
    /** Collaborateurs actifs proposés pour fixer des objectifs. */
    static function pickable(): array {
        $r = self::reports(); $w = "status='active'"; if ($r !== null) { if (!$r) return []; $w .= ' AND id IN (' . implode(',', array_map('intval', $r)) . ')'; }
        return DB::all("SELECT id, matricule, first_name, last_name FROM employees WHERE $w ORDER BY last_name, first_name");
    }
    /** Collaborateurs d'un périmètre : all, unit (activité et sous-unités), team, store, channel. */
    static function inScope(string $scope, string $ref): array {
        $w = ["status='active'"]; $p = [];
        if ($scope === 'unit') { $ids = Org::descendants((int)$ref); $w[] = 'org_unit_id IN (' . implode(',', array_map('intval', $ids)) . ')'; }
        elseif (in_array($scope, ['team', 'store', 'channel'], true)) { $w[] = $scope . '_id=?'; $p[] = (int)$ref; }
        elseif ($scope === 'emps') { $ids = array_filter(array_map('intval', explode(',', $ref))); if (!$ids) return []; $w[] = 'id IN (' . implode(',', $ids) . ')'; }
        $r = self::reports(); if ($r !== null) { if (!$r) return []; $w[] = 'id IN (' . implode(',', array_map('intval', $r)) . ')'; }
        return DB::all('SELECT * FROM employees WHERE ' . implode(' AND ', $w) . ' ORDER BY last_name, first_name', $p);
    }
    static function scopeName(string $scope, string $ref): string {
        return match ($scope) { 'unit' => (string)DB::val('SELECT name FROM org_units WHERE id=?', [(int)$ref]), 'team' => (string)DB::val('SELECT name FROM teams WHERE id=?', [(int)$ref]), 'store' => (string)DB::val('SELECT name FROM stores WHERE id=?', [(int)$ref]),
            'channel' => (string)DB::val('SELECT name FROM channels WHERE id=?', [(int)$ref]), 'emps' => count(array_filter(explode(',', $ref))) . ' collaborateur(s) choisi(s)', default => 'Tous les collaborateurs' };
    }
    /** Crée une demande d'objectif ; avertit le N+1 (une notification par lot). */
    static function notifyN1(array $empIds, string $text, string $url): void {
        $users = []; foreach (array_unique($empIds) as $e) if ($u = self::n1User((int)$e)) $users[$u] = ($users[$u] ?? 0) + 1;
        foreach ($users as $u => $n) if ($u !== Auth::id()) Notifier::send($u, 'Objectifs à valider', "$n objectif(s) $text", $url);
    }

    /** Ouvre et clôture les campagnes aux dates prévues. @return int nombre de changements */
    static function sync(?string $today = null): int {
        $today = $today ?? date('Y-m-d'); $n = 0;
        $n += DB::exec("UPDATE ag_campaigns SET status='closed' WHERE status IN ('planned','open') AND closes_on < ?", [$today]);
        $n += DB::exec("UPDATE ag_campaigns SET status='open' WHERE status='planned' AND opens_on <= ? AND closes_on >= ?", [$today, $today]);
        return $n;
    }
    /** Ajoute à l'évaluation les objectifs validés de la période pas encore repris (ils peuvent être validés après l'ouverture). */
    static function syncItems(array $ev, array $camp): void {
        $have = array_map('intval', array_column(DB::all('SELECT objective_id FROM ag_eval_items WHERE eval_id=? AND objective_id IS NOT NULL', [(int)$ev['id']]), 'objective_id'));
        foreach (DB::all("SELECT * FROM ag_objectives WHERE employee_id=? AND status='validated' AND period_start<=? AND period_end>=? ORDER BY period_start, id", [(int)$ev['employee_id'], $camp['period_end'], $camp['period_start']]) as $o)
            if (!in_array((int)$o['id'], $have, true)) DB::insert('ag_eval_items', ['eval_id' => (int)$ev['id'], 'objective_id' => (int)$o['id'], 'label' => $o['title'], 'target' => $o['target'], 'weight' => max(1, (int)$o['weight'])]);
    }
    /** Moyenne pondérée des notes (0-100) renseignées ; null si aucune. */
    static function avg(array $items, string $key): ?int {
        $s = 0; $w = 0; foreach ($items as $i) if ($i[$key] !== null && $i[$key] !== '') { $s += (int)$i[$key] * max(1, (int)$i['weight']); $w += max(1, (int)$i['weight']); }
        return $w ? (int)round($s / $w) : null;
    }
    static function rating(?int $s): array { return $s === null ? ['—', 'secondary'] : ($s >= 90 ? ['Excellent', 'success'] : ($s >= 75 ? ['Objectif atteint', 'primary'] : ($s >= 50 ? ['Partiellement atteint', 'warning'] : ['Insuffisant', 'danger']))); }
    static function dir(): string { $d = ROOT . '/storage/uploads/ag'; if (!is_dir($d)) @mkdir($d, 0775, true); return $d; }
    /** Peut-on voir cette évaluation (l'agent, son N+1, un gestionnaire) ? */
    static function canSeeEval(array $ev): bool { return self::canSee((int)$ev['employee_id']); }

    /** Deux relances avant la clôture : agents n'ayant pas remis leur auto-évaluation, et N+1 ayant des évaluations à examiner. @return int notifications envoyées */
    static function sendReminders(?string $today = null): int {
        $today = $today ?? date('Y-m-d'); $sent = 0; self::$mails = 0; self::sync($today);
        foreach (DB::all("SELECT * FROM ag_campaigns WHERE status='open' AND closes_on>=?", [$today]) as $c) {
            $d1 = (int)$c['remind1_days']; $d2 = (int)$c['remind2_days']; $w1 = date('Y-m-d', strtotime($c['closes_on'] . " -$d1 day")); $w2 = date('Y-m-d', strtotime($c['closes_on'] . " -$d2 day"));
            $which = ($today >= $w2 && !$c['reminded2_at']) ? 2 : (($today >= $w1 && $today < $w2 && !$c['reminded1_at']) ? 1 : 0); if (!$which) continue;
            DB::update('ag_campaigns', $which === 2 ? ['reminded1_at' => $c['reminded1_at'] ?: now(), 'reminded2_at' => now()] : ['reminded1_at' => now()], 'id=?', [(int)$c['id']]);
            $left = (int)round((strtotime($c['closes_on']) - strtotime($today)) / 86400); $when = $left > 0 ? "J-$left" : 'aujourd\'hui'; $close = date('d/m/Y', strtotime($c['closes_on']));
            $title = 'Évaluation : ' . ($which === 2 ? '2e' : '1re') . ' relance'; $link = (string)env('APP_URL', '') !== '' ? "\nAccès : " . rtrim((string)env('APP_URL'), '/') . '/ag/my' : '';
            $to = []; // user => [texte]
            foreach (DB::all("SELECT * FROM ag_evals WHERE campaign_id=? AND status='todo'", [(int)$c['id']]) as $ev)
                if ($u = self::userOfEmployee((int)$ev['employee_id'])) $to[$u][] = ["Votre auto-évaluation « {$c['name']} » est à remettre avant le $close ($when).", '/ag/eval/' . $ev['id']];
            foreach (DB::all("SELECT e.manager_id, COUNT(*) n FROM ag_evals v JOIN employees e ON e.id=v.employee_id WHERE v.campaign_id=? AND v.status IN ('todo','self_done') AND e.manager_id IS NOT NULL GROUP BY e.manager_id", [(int)$c['id']]) as $m)
                if ($u = self::userOfEmployee((int)$m['manager_id'])) $to[$u][] = [(int)$m['n'] . " évaluation(s) de votre équipe sont à examiner avant la clôture de « {$c['name']} » le $close ($when).", '/ag/review'];
            foreach ($to as $u => $lines) {
                Notifier::send($u, $title, implode(' ', array_column($lines, 0)), $lines[0][1]); $sent++;
                if ((int)$c['remind_email'] === 1 && Mailer::enabled()) {
                    $us = DB::one("SELECT name, email FROM users WHERE id=? AND status='active'", [$u]);
                    if ($us && $us['email'] && Mailer::queue((string)$us['email'], $title . ' : clôture le ' . $close, "Bonjour {$us['name']},\n\n" . implode("\n", array_column($lines, 0)) . $link . "\n\nMessage automatique de CXO Excellence Hub.")) self::$mails++;
                }
            }
        }
        return $sent;
    }
}
