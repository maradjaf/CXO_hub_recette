<?php
namespace App\Core;

/** Planificateur de tâches : attribution, suivi, relances. */
final class Pk {
    const ST = ['open' => 'À faire', 'in_progress' => 'En cours', 'done' => 'Clôturée', 'cancelled' => 'Annulée'];
    const ST_C = ['open' => 'secondary', 'in_progress' => 'primary', 'done' => 'success', 'cancelled' => 'dark'];
    const PRIO = ['low' => 'Basse', 'normal' => 'Normale', 'high' => 'Haute', 'urgent' => 'Urgente'];
    const PRIO_C = ['low' => 'secondary', 'normal' => 'info', 'high' => 'warning', 'urgent' => 'danger'];
    const OPEN = "('open','in_progress')";
    const LOG = ['create' => 'Création', 'edit' => 'Modification', 'assign' => 'Changement de destinataire', 'postpone' => 'Report', 'progress' => 'Avancement', 'remind' => 'Relance', 'auto' => 'Relance automatique', 'close' => 'Clôture', 'reopen' => 'Réouverture', 'cancel' => 'Annulation', 'comment' => 'Commentaire', 'delete' => 'Suppression'];

    static function ref(): string { $y = date('y'); $n = (int)DB::val("SELECT COUNT(*) FROM pk_tasks WHERE ref LIKE ?", ["TCH-$y-%"]) + 1; do { $r = sprintf('TCH-%s-%04d', $y, $n++); } while (DB::val('SELECT 1 FROM pk_tasks WHERE ref=?', [$r])); return $r; }
    static function log(int $tid, string $kind, string $c = '', ?int $uid = null): void { DB::insert('pk_log', ['task_id' => $tid, 'user_id' => $uid ?? Auth::id(), 'kind' => $kind, 'comment' => mb_substr($c, 0, 500) ?: null, 'created_at' => now()]); }
    static function late(array $t): bool { return in_array($t['status'], ['open', 'in_progress'], true) && $t['due_date'] < date('Y-m-d'); }
    /** Périmètre visible : tout (pk.all) ou les tâches que je porte / que j'ai créées. */
    static function scope(string $a = 't'): array { return can('pk.all') ? ["$a.deleted_at IS NULL", []] : ["$a.deleted_at IS NULL AND ($a.assignee_id=? OR $a.created_by=?)", [(int)Auth::id(), (int)Auth::id()]]; }
    static function sees(array $t): bool { return !$t['deleted_at'] && (can('pk.all') || (int)$t['assignee_id'] === (int)Auth::id() || (int)$t['created_by'] === (int)Auth::id()); }
    static function owns(array $t): bool { return can('pk.all') || (int)$t['created_by'] === (int)Auth::id(); }
    static function tell(int $uid, string $title, string $body, int $tid): void { if ($uid && $uid !== (int)Auth::id()) Notifier::send($uid, $title, mb_substr($body, 0, 400), '/pk/' . $tid); }
    static function remind(array $t, string $kind = 'remind', string $extra = ''): void {
        $late = $t['due_date'] < date('Y-m-d');
        Notifier::send((int)$t['assignee_id'], ($late ? 'Tâche en retard : ' : 'Rappel de tâche : ') . $t['ref'], $t['title'] . ' — échéance ' . d($t['due_date']) . ($extra !== '' ? ' — ' . $extra : ''), '/pk/' . $t['id']);
        DB::update('pk_tasks', ['reminded_at' => now(), 'reminders' => (int)$t['reminders'] + 1], 'id=?', [(int)$t['id']]);
        self::log((int)$t['id'], $kind, $extra !== '' ? $extra : ($late ? 'Tâche en retard' : 'Échéance proche'), $kind === 'auto' ? 0 : null);
    }
    /** Relances automatiques : veille de l'échéance, jour J, puis tous les N jours de retard (réglage pk.remind_days, 2 par défaut). */
    static function sweep(): int {
        $n = 0; $today = date('Y-m-d'); $gap = max(1, (int)setting('pk.remind_days', 2));
        foreach (DB::all("SELECT * FROM pk_tasks WHERE deleted_at IS NULL AND status IN " . self::OPEN . " AND due_date<=? LIMIT 500", [date('Y-m-d', strtotime('+1 day'))]) as $t) {
            $last = $t['reminded_at'] ? substr((string)$t['reminded_at'], 0, 10) : null;
            if ($t['due_date'] >= $today) { if ($last !== null && $last >= $today) continue; }
            elseif ($last !== null && $last > $t['due_date'] && $last > date('Y-m-d', strtotime("-$gap days"))) continue;
            $first = $t['due_date'] < $today && ($last === null || $last <= $t['due_date']);
            self::remind($t, 'auto'); $n++;
            if ($first && (int)$t['created_by'] && (int)$t['created_by'] !== (int)$t['assignee_id']) Notifier::send((int)$t['created_by'], 'Tâche en retard : ' . $t['ref'], $t['title'] . ' — confiée à ' . DB::val('SELECT name FROM users WHERE id=?', [(int)$t['assignee_id']]), '/pk/' . $t['id']);
        }
        return $n;
    }
}
