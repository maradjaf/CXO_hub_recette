<?php
namespace App\Core;
use PDO;
class DB {
    private static ?PDO $pdo = null;
    static function driver(): string { return env('DB_DRIVER', 'mysql'); }
    static function pdo(): PDO {
        if (!self::$pdo) {
            if (self::driver() === 'sqlite') {
                $path = env('DB_PATH', ROOT . '/storage/cxo.sqlite');
                $pdo = new PDO('sqlite:' . $path);
                $pdo->exec('PRAGMA foreign_keys=ON');
            } else {
                $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', env('DB_HOST', '127.0.0.1'), env('DB_PORT', '3306'), env('DB_NAME', 'cxo_hub'));
                $pdo = new PDO($dsn, env('DB_USER', 'root'), env('DB_PASS', ''));
            }
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            self::$pdo = $pdo;
        }
        return self::$pdo;
    }
    static function reset(): void { self::$pdo = null; }
    static function run(string $sql, array $p = []): \PDOStatement { $s = self::pdo()->prepare($sql); $s->execute($p); return $s; }
    static function all(string $sql, array $p = []): array { return self::run($sql, $p)->fetchAll(); }
    static function one(string $sql, array $p = []): ?array { $r = self::run($sql, $p)->fetch(); return $r ?: null; }
    static function val(string $sql, array $p = []) { $r = self::run($sql, $p)->fetch(PDO::FETCH_NUM); return $r ? $r[0] : null; }
    static function exec(string $sql, array $p = []): int { return self::run($sql, $p)->rowCount(); }
    static function insert(string $t, array $d): int {
        $c = array_keys($d);
        self::run("INSERT INTO $t (" . implode(',', $c) . ') VALUES (' . implode(',', array_fill(0, count($c), '?')) . ')', array_values($d));
        return (int)self::pdo()->lastInsertId();
    }
    static function update(string $t, array $d, string $where, array $wp = []): int {
        $set = implode(',', array_map(fn($c) => "$c=?", array_keys($d)));
        return self::exec("UPDATE $t SET $set WHERE $where", array_merge(array_values($d), $wp));
    }
}
