<?php
namespace App\Core;

/**
 * Lot 57 : compétences (M16). Matrice collaborateur × compétence à six niveaux, niveau requis par poste,
 * écarts, historique daté, propositions issues des sessions de formation (résultat « Acquis »).
 */
final class Skill {
    const LEVELS = [0 => 'Non acquis', 1 => 'Débutant', 2 => 'Intermédiaire', 3 => 'Avancé', 4 => 'Expert', 5 => 'Polyvalent'];
    const LEVEL_C = [0 => 'secondary', 1 => 'danger', 2 => 'warning', 3 => 'info', 4 => 'success', 5 => 'primary'];
    const SOURCES = ['manager' => 'Manager', 'trainer' => 'Formateur', 'session' => 'Session de formation', 'quality' => 'Évaluation qualité', 'self' => 'Auto-évaluation', 'import' => 'Import'];
    /** Nombre de compétences d'une même famille au niveau Avancé ou plus qui vaut la polyvalence sur cette famille (réglage `sk.poly_min`). */
    static function polyMin(): int { return max(2, (int)setting('sk.poly_min', 3)); }

    static function badge(?int $lv, bool $short = false): string {
        $lv = $lv === null ? 0 : max(0, min(5, $lv));
        return '<span class="badge text-bg-' . self::LEVEL_C[$lv] . '" title="' . e(self::LEVELS[$lv]) . '">' . ($short ? $lv : e(self::LEVELS[$lv])) . '</span>';
    }

    /** Niveau requis par compétence pour un poste. @return array<int,int> skill_id => niveau */
    static function required(?int $positionId): array {
        if (!$positionId) return [];
        $out = []; foreach (DB::all('SELECT skill_id, level FROM sk_position_reqs WHERE position_id=?', [$positionId]) as $r) $out[(int)$r['skill_id']] = (int)$r['level'];
        return $out;
    }

    /** Niveaux actuels d'un collaborateur. @return array<int,array> skill_id => ligne */
    static function levels(int $emp): array {
        $out = []; foreach (DB::all('SELECT * FROM sk_levels WHERE employee_id=?', [$emp]) as $r) $out[(int)$r['skill_id']] = $r;
        return $out;
    }

    /**
     * Fiche d'écart : pour chaque compétence active, niveau actuel, niveau requis par le poste, écart (requis − actuel, 0 si couvert),
     * plus la polyvalence calculée par famille. Les compétences non requises mais évaluées sont listées aussi.
     */
    static function gapSheet(int $emp): array {
        $e = DB::one('SELECT id, position_id FROM employees WHERE id=?', [$emp]); if (!$e) return ['rows' => [], 'families' => [], 'gaps' => 0, 'covered' => 0, 'required' => 0];
        $req = self::required($e['position_id'] ? (int)$e['position_id'] : null); $cur = self::levels($emp);
        $skills = DB::all('SELECT s.*, f.name family, f.sort_order fs FROM sk_skills s JOIN sk_families f ON f.id=s.family_id WHERE s.active=1 ORDER BY f.sort_order, f.name, s.name');
        $rows = []; $fam = []; $gaps = 0; $covered = 0; $nreq = 0;
        foreach ($skills as $s) {
            $sid = (int)$s['id']; $lv = isset($cur[$sid]) ? (int)$cur[$sid]['level'] : null; $rq = $req[$sid] ?? null;
            if ($lv === null && $rq === null) continue;
            $eff = $lv ?? 0; $gap = $rq !== null ? max(0, $rq - min($eff, 4)) : 0;   // « Polyvalent » (5) vaut Expert pour l'écart
            if ($rq !== null) { $nreq++; if ($gap === 0) $covered++; else $gaps++; }
            $rows[] = ['skill' => $s, 'level' => $lv, 'required' => $rq, 'gap' => $gap, 'row' => $cur[$sid] ?? null];
            $f = (int)$s['family_id']; $fam[$f] ??= ['name' => $s['family'], 'adv' => 0, 'total' => 0]; $fam[$f]['total']++; if ($eff >= 3) $fam[$f]['adv']++;
        }
        $pm = self::polyMin(); foreach ($fam as &$f) $f['poly'] = $f['adv'] >= $pm; unset($f);
        return ['rows' => $rows, 'families' => $fam, 'gaps' => $gaps, 'covered' => $covered, 'required' => $nreq, 'position_id' => $e['position_id']];
    }

    /** Fixe un niveau daté ; l'ancien niveau part dans l'historique. Retourne false si rien ne change. */
    static function setLevel(int $emp, int $skill, int $level, string $source, ?int $assessor, ?string $note = null, ?string $ref = null, ?string $date = null): bool {
        $level = max(0, min(5, $level)); if (!isset(self::SOURCES[$source])) $source = 'manager';
        $cur = DB::one('SELECT * FROM sk_levels WHERE employee_id=? AND skill_id=?', [$emp, $skill]);
        $date = $date && strtotime($date) ? date('Y-m-d', strtotime($date)) : date('Y-m-d');
        if ($cur && (int)$cur['level'] === $level && $note === null) return false;
        $data = ['level' => $level, 'assessed_at' => $date, 'source' => $source, 'assessor_id' => $assessor, 'source_ref' => $ref ? mb_substr($ref, 0, 80) : null, 'note' => $note ? mb_substr($note, 0, 300) : null, 'updated_at' => now()];
        if ($cur) DB::update('sk_levels', $data, 'id=?', [(int)$cur['id']]); else DB::insert('sk_levels', $data + ['employee_id' => $emp, 'skill_id' => $skill]);
        $name = $assessor ? (string)DB::val('SELECT name FROM users WHERE id=?', [$assessor]) : null;
        DB::insert('sk_history', ['employee_id' => $emp, 'skill_id' => $skill, 'old_level' => $cur ? (int)$cur['level'] : null, 'new_level' => $level, 'source' => $source, 'assessor_id' => $assessor, 'assessor_name' => $name ? mb_substr($name, 0, 150) : null, 'note' => $note ? mb_substr($note, 0, 300) : null, 'created_at' => now()]);
        return true;
    }

    /**
     * Une inscription « Acquis » (passed) à une session propose, pour chaque compétence liée à la formation, le niveau cible de la formation —
     * seulement s'il dépasse le niveau actuel et qu'aucune proposition n'est déjà en attente. Retourne le nombre de propositions créées.
     */
    static function proposeFromEnrollment(int $enrollmentId): int {
        $en = DB::one('SELECT en.id, en.employee_id, en.status, s.id session_id, s.training_id FROM training_enrollments en JOIN training_sessions s ON s.id=en.session_id WHERE en.id=?', [$enrollmentId]);
        if (!$en || $en['status'] !== 'passed') return 0;
        $n = 0;
        foreach (DB::all('SELECT ts.skill_id, ts.level FROM sk_training_skills ts JOIN sk_skills s ON s.id=ts.skill_id WHERE ts.training_id=? AND s.active=1', [(int)$en['training_id']]) as $ts) {
            $sid = (int)$ts['skill_id']; $cur = DB::val('SELECT level FROM sk_levels WHERE employee_id=? AND skill_id=?', [(int)$en['employee_id'], $sid]);
            if ($cur !== null && (int)$cur >= (int)$ts['level']) continue;
            if (DB::val("SELECT 1 FROM sk_proposals WHERE employee_id=? AND skill_id=? AND status='pending'", [(int)$en['employee_id'], $sid])) continue;
            if (DB::val('SELECT 1 FROM sk_proposals WHERE enrollment_id=? AND skill_id=?', [$enrollmentId, $sid])) continue;   // déjà traitée pour cette inscription
            DB::insert('sk_proposals', ['employee_id' => (int)$en['employee_id'], 'skill_id' => $sid, 'level' => (int)$ts['level'], 'current_level' => $cur === null ? null : (int)$cur, 'source' => 'session', 'session_id' => (int)$en['session_id'], 'enrollment_id' => $enrollmentId, 'status' => 'pending', 'created_at' => now()]);
            $n++;
        }
        return $n;
    }

    /** Parcourt toutes les inscriptions « Acquis » sans proposition et en crée (job idempotent). */
    static function proposeAll(): int {
        $n = 0; foreach (DB::all("SELECT en.id FROM training_enrollments en WHERE en.status='passed' AND EXISTS (SELECT 1 FROM training_sessions s JOIN sk_training_skills ts ON ts.training_id=s.training_id WHERE s.id=en.session_id) ORDER BY en.id") as $r) $n += self::proposeFromEnrollment((int)$r['id']);
        return $n;
    }

    /** Couverture d'une équipe (ou d'un ensemble de collaborateurs) : par compétence requise, effectif concerné, couverts, écart moyen. */
    static function teamCoverage(array $empIds): array {
        if (!$empIds) return [];
        $in = implode(',', array_fill(0, count($empIds), '?'));
        $emps = DB::all("SELECT id, position_id FROM employees WHERE id IN ($in)", $empIds);
        $reqByPos = []; $levels = [];
        foreach (DB::all("SELECT * FROM sk_levels WHERE employee_id IN ($in)", $empIds) as $l) $levels[(int)$l['employee_id']][(int)$l['skill_id']] = (int)$l['level'];
        $out = []; $skills = []; foreach (DB::all('SELECT s.id, s.name, s.code, f.name family FROM sk_skills s JOIN sk_families f ON f.id=s.family_id WHERE s.active=1') as $s) $skills[(int)$s['id']] = $s;
        foreach ($emps as $e) {
            $pid = $e['position_id'] ? (int)$e['position_id'] : 0; $reqByPos[$pid] ??= self::required($pid ?: null); $eid = (int)$e['id'];
            foreach ($reqByPos[$pid] as $sid => $rq) {
                if (!isset($skills[$sid])) continue;
                $out[$sid] ??= ['skill' => $skills[$sid], 'required' => 0, 'covered' => 0, 'gap_sum' => 0, 'missing' => [], 'levels' => array_fill(0, 6, 0)];
                $lv = $levels[$eid][$sid] ?? 0; $out[$sid]['required']++; $out[$sid]['levels'][max(0, min(5, $lv))]++;
                if (min($lv, 4) >= $rq) $out[$sid]['covered']++; else { $out[$sid]['gap_sum'] += $rq - min($lv, 4); $out[$sid]['missing'][] = $eid; }
            }
            foreach ($levels[$eid] ?? [] as $sid => $lv) if (!isset($reqByPos[$pid][$sid]) && isset($skills[$sid])) { $out[$sid] ??= ['skill' => $skills[$sid], 'required' => 0, 'covered' => 0, 'gap_sum' => 0, 'missing' => [], 'levels' => array_fill(0, 6, 0)]; $out[$sid]['levels'][max(0, min(5, $lv))]++; }
        }
        foreach ($out as &$o) { $o['pct'] = $o['required'] ? (int)round(100 * $o['covered'] / $o['required']) : null; $o['gap_avg'] = $o['missing'] ? round($o['gap_sum'] / count($o['missing']), 1) : 0; } unset($o);
        uasort($out, fn($a, $b) => [$b['required'] - $b['covered'], $a['skill']['family'], $a['skill']['name']] <=> [$a['required'] - $a['covered'], $b['skill']['family'], $b['skill']['name']]);
        return $out;
    }
}
