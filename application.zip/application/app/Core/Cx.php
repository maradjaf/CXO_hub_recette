<?php
namespace App\Core;
/** Mystery Customer et tests de parcours client : calcul des résultats, périmètre, actions d'amélioration, tests récurrents. */
class Cx {
    const CH = ['store' => 'Store', 'call' => 'Call center', 'digital' => 'Digital'];
    const CH_J = ['store' => 'Store', 'call' => 'Call center', 'digital' => 'Digital', 'multi' => 'Multicanal'];
    const GS = ['draft' => 'Brouillon', 'active' => 'Active', 'archived' => 'Archivée'];
    const GS_COLOR = ['draft' => 'secondary', 'active' => 'success', 'archived' => 'dark'];
    const VS = ['planned' => 'Planifiée', 'in_progress' => 'En cours', 'submitted' => 'À valider', 'validated' => 'Validée', 'rejected' => 'À reprendre', 'cancelled' => 'Annulée'];
    const VS_COLOR = ['planned' => 'secondary', 'in_progress' => 'primary', 'submitted' => 'warning', 'validated' => 'success', 'rejected' => 'danger', 'cancelled' => 'dark'];
    const RES = ['conform' => 'Conforme', 'non_conform' => 'Non conforme', 'critical' => 'Écart critique'];
    const RES_COLOR = ['conform' => 'success', 'non_conform' => 'warning', 'critical' => 'danger'];
    const ANS = ['ok' => 'Conforme', 'ko' => 'Non conforme', 'na' => 'Non applicable'];
    const RS = ['planned' => 'Planifié', 'in_progress' => 'En cours', 'completed' => 'Terminé', 'cancelled' => 'Annulé'];
    const JRES = ['passed' => 'Réussi', 'degraded' => 'Dégradé', 'failed' => 'En échec'];
    const JRES_COLOR = ['passed' => 'success', 'degraded' => 'warning', 'failed' => 'danger'];
    const STEP = ['pass' => 'Réussie', 'fail' => 'En échec', 'blocked' => 'Bloquée', 'na' => 'Non testée'];
    const AS = ['open' => 'À traiter', 'in_progress' => 'En cours', 'done' => 'À vérifier', 'verified' => 'Vérifiée', 'cancelled' => 'Annulée'];
    const AS_COLOR = ['open' => 'secondary', 'in_progress' => 'primary', 'done' => 'warning', 'verified' => 'success', 'cancelled' => 'dark'];
    const FREQ = ['none' => 'Aucune', 'weekly' => 'Hebdomadaire', 'monthly' => 'Mensuelle', 'quarterly' => 'Trimestrielle'];
    const OPEN_ACT = ['open', 'in_progress', 'done'];

    static function subject(array $v): string {
        if (!empty($v['store_id'])) return (string)(DB::val('SELECT name FROM stores WHERE id=?', [(int)$v['store_id']]) ?: 'Store');
        if (!empty($v['team_id'])) return (string)(DB::val('SELECT name FROM teams WHERE id=?', [(int)$v['team_id']]) ?: 'Équipe');
        return 'Canal digital';
    }
    /**
     * Visites visibles (alias $a) : administrateur et qualité (« cx.manage ») voient tout ; le client mystère ses propres visites ;
     * les autres (« cx.view ») uniquement les visites VALIDÉES de leur périmètre hiérarchique, jamais celles en cours de saisie.
     * @return array{0:string,1:array}
     */
    static function scope(string $a = 'v'): array {
        $me = Auth::id(); if (can('cx.manage')) return ['1=1', []];
        $own = "$a.shopper_id=?"; if (!can('cx.view')) return [$own, [$me]];
        $ids = Scope::ids(); if ($ids === null) return ["($own OR $a.status='validated')", [$me]];
        if (!$ids) return [$own, [$me]];
        $in = implode(',', array_fill(0, count($ids), '?'));
        return ["($own OR ($a.status='validated' AND ($a.store_id IN (SELECT store_id FROM employees WHERE id IN ($in) AND store_id IS NOT NULL) OR $a.team_id IN (SELECT team_id FROM employees WHERE id IN ($in) AND team_id IS NOT NULL))))", array_merge([$me], $ids, $ids)];
    }
    static function canSee(array $v): bool { [$w, $p] = self::scope('v'); return (bool)DB::val("SELECT 1 FROM mc_visits v WHERE v.id=? AND $w", array_merge([(int)$v['id']], $p)); }
    /** L'identité du client mystère n'est visible que du gestionnaire et de l'intéressé. */
    static function shopperName(array $v): string {
        if (!can('cx.manage') && (int)($v['shopper_id'] ?? 0) !== Auth::id()) return 'Client mystère';
        return (string)($v['shopper_label'] ?: (DB::val('SELECT name FROM users WHERE id=?', [(int)$v['shopper_id']]) ?: 'Client mystère'));
    }
    /** @return array{0:?float,1:string} */
    static function computeVisit(int $visitId, int $passPct): array {
        $ok = 0; $tot = 0; $crit = false;
        foreach (DB::all('SELECT a.answer, c.weight, c.critical FROM mc_answers a JOIN mc_criteria c ON c.id=a.criterion_id WHERE a.visit_id=?', [$visitId]) as $r) {
            if ($r['answer'] === 'na') continue; $w = max(1, (int)$r['weight']); $tot += $w; if ($r['answer'] === 'ok') $ok += $w; elseif ($r['critical']) $crit = true;
        }
        $score = $tot ? round($ok / $tot * 100, 2) : null;
        return [$score, $crit ? 'critical' : (($score === null || $score >= $passPct) ? 'conform' : 'non_conform')];
    }
    /** Échec/bloqué => « failed » ; tout réussi mais une étape plus lente que son seuil => « degraded ». */
    static function computeRun(int $runId): array {
        $rows = DB::all('SELECT r.status, r.seconds, s.max_seconds FROM jr_results r JOIN jr_steps s ON s.id=r.step_id WHERE r.run_id=?', [$runId]);
        $res = 'passed'; $tot = 0;
        foreach ($rows as $r) { $tot += (int)$r['seconds']; if (in_array($r['status'], ['fail', 'blocked'], true)) $res = 'failed'; elseif ($res === 'passed' && $r['status'] === 'pass' && $r['max_seconds'] && (int)$r['seconds'] > (int)$r['max_seconds']) $res = 'degraded'; }
        return [$res, $tot];
    }
    static function dueDays(string $priority): int { return Ca::setting($priority === 'critical' ? 'cx_due_critical' : 'cx_due_days', $priority === 'critical' ? 7 : 30); }
    static function newAction(array $d): int {
        $id = DB::insert('cx_actions', $d + ['reference' => Ca::ref('AMC', 'cx_actions'), 'status' => 'open', 'created_by' => Auth::id(), 'created_at' => now()]);
        if (!empty($d['owner_id'])) Notifier::send((int)$d['owner_id'], 'Action d\'amélioration à traiter', (string)DB::val('SELECT reference FROM cx_actions WHERE id=?', [$id]) . ' · ' . $d['title'], '/cx/actions/' . $id);
        return $id;
    }
    /** Crée les tests de parcours échus (parcours actifs avec fréquence) ; une seule occurrence même en retard. @return int */
    static function generate(?string $today = null): int {
        $today = $today ?: date('Y-m-d'); $n = 0;
        foreach (DB::all("SELECT * FROM jr_journeys WHERE status='active' AND frequency<>'none' AND tester_id IS NOT NULL AND next_date IS NOT NULL AND next_date<=?", [$today]) as $j) {
            $id = DB::insert('jr_runs', ['reference' => Ca::ref('PAR', 'jr_runs'), 'journey_id' => (int)$j['id'], 'tester_id' => (int)$j['tester_id'], 'planned_date' => $j['next_date'], 'status' => 'planned', 'created_at' => now()]);
            $next = Ca::nextDate($j['next_date'], $j['frequency']); while ($next <= $today) $next = Ca::nextDate($next, $j['frequency']);
            DB::update('jr_journeys', ['next_date' => $next], 'id=?', [(int)$j['id']]);
            Notifier::send((int)$j['tester_id'], 'Test de parcours à réaliser', $j['name'] . ' · prévu le ' . d($j['next_date']), '/cx/runs/' . $id); $n++;
        }
        return $n;
    }
}
