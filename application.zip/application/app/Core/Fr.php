<?php
namespace App\Core;

/**
 * Lot 60 — Franchises : référentiel, périmètre d'accès, calendrier ouvré, SLA, circuit des demandes, opérations confirmées, masquage des données sensibles.
 * Les dates et heures sont en heure locale de l'application (Africa/Lome, UTC+0).
 */
final class Fr {
    const ST = ['new' => 'Créée', 'assigned' => 'Affectée', 'in_progress' => 'En traitement', 'waiting' => 'En attente', 'executed' => 'Exécutée', 'rejected' => 'Rejetée', 'cancelled' => 'Annulée', 'not_executed' => 'Non exécutée'];
    const ST_C = ['new' => 'info', 'assigned' => 'primary', 'in_progress' => 'warning', 'waiting' => 'secondary', 'executed' => 'success', 'rejected' => 'danger', 'cancelled' => 'dark', 'not_executed' => 'danger'];
    const OPEN = ['new', 'assigned', 'in_progress', 'waiting'];
    const TERM = ['executed', 'rejected', 'cancelled', 'not_executed'];
    const RESOLVED = ['executed', 'rejected', 'not_executed'];
    const PRIO = ['urgent' => 'Urgente', 'high' => 'Haute', 'normal' => 'Normale', 'low' => 'Basse'];
    const PRIO_C = ['urgent' => 'danger', 'high' => 'warning', 'normal' => 'primary', 'low' => 'secondary'];
    const CHANNELS = ['crm' => 'CRM', 'store' => 'Boutique', 'phone' => 'Téléphone', 'whatsapp' => 'WhatsApp', 'email' => 'E-mail', 'excel' => 'Fichier Excel'];
    const KINDS = ['hold' => 'Mise en attente', 'reject' => 'Rejet', 'cancel' => 'Annulation', 'noexec' => 'Non-exécution'];
    const EVT = ['create' => 'Création', 'assign' => 'Affectation', 'take' => 'Prise en charge', 'hold' => 'Mise en attente', 'resume' => 'Reprise', 'execute' => 'Exécution confirmée', 'reject' => 'Rejet', 'cancel' => 'Annulation', 'noexec' => 'Non-exécution', 'reassign' => 'Réaffectation', 'escalate' => 'Escalade', 'reopen' => 'Réouverture', 'comment' => 'Commentaire', 'correct' => 'Correction', 'import' => 'Reprise historique'];
    const SENS = ['customer_no', 'customer_name', 'iccid', 'id_proof', 'owner_doc', 'agent_doc', 'guarantor_doc'];

    /** Mode système (jeux de démonstration, reprises, tâches planifiées) : aucun contrôle de droit ni de périmètre. */
    public static bool $system = false;
    private static ?array $cal = null; private static ?array $map = null; private static ?array $scope = [0 => 'unset'];

    // ───────────────────────── Périmètre et droits ─────────────────────────
    /** Identifiants de franchises visibles par l'utilisateur ; null = toutes. */
    static function scope(): ?array {
        if (self::$system) return null;
        if (self::$scope !== [0 => 'unset']) return self::$scope;
        $uid = (int)Auth::id(); if (!$uid) return self::$scope = [];
        $rows = DB::all('SELECT * FROM fr_access WHERE user_id=?', [$uid]);
        if ($rows) {
            $ids = []; foreach ($rows as $r) { if ($r['kind'] === 'zone') foreach (DB::all('SELECT id FROM fr_franchises WHERE zone=?', [$r['zone']]) as $f) $ids[(int)$f['id']] = 1; elseif ($r['franchise_id']) $ids[(int)$r['franchise_id']] = 1; }
            return self::$scope = array_keys($ids);
        }
        if (can('fr.view') || can('fr.handle') || can('fr.manage') || can('fr.import') || can('fr.report')) return self::$scope = null;
        return self::$scope = [];
    }
    static function resetScope(): void { self::$scope = [0 => 'unset']; }
    static function sees(int $fid): bool { $s = self::scope(); return $s === null || in_array($fid, $s, true); }
    /** Clause SQL de périmètre : [sql commençant par AND, paramètres]. */
    static function sqlScope(string $col): array { $s = self::scope(); if ($s === null) return ['', []]; if (!$s) return [' AND 1=0', []]; return [" AND $col IN (" . implode(',', array_map('intval', $s)) . ')', []]; }
    static function franchiseUser(): bool { return can('fr.own') && !can('fr.handle') && !can('fr.view') && !can('fr.manage'); }

    // ───────────────────────── Textes et formats ─────────────────────────
    static function n($v): string { return number_format((float)$v, 0, ',', "\u{202f}"); }
    static function dec($v, int $d = 1): string { if ($v === null) return '—'; $v = (float)$v; if (abs($v) < 0.05 && $d === 1) $v = 0.0; return number_format($v, $d, ',', "\u{202f}"); }
    static function sgn($v, int $d = 0): string { if ($v === null) return '—'; return ($v > 0 ? '+' : ($v < 0 ? '−' : '')) . number_format(abs((float)$v), $d, ',', "\u{202f}"); }
    static function fold(string $s): string { return Voc::fold($s); }
    static function norm(string $s): string { return preg_replace('/[^a-z0-9]+/', '', strtolower(Voc::fold($s))); }
    static function mask(?string $s, int $keep = 3): string { $s = (string)$s; if ($s === '') return ''; $l = mb_strlen($s); return str_repeat('•', max(3, $l - $keep)) . mb_substr($s, -min($keep, $l)); }
    static function isDay($v): bool { return is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $v) && checkdate((int)substr($v, 5, 2), (int)substr($v, 8, 2), (int)substr($v, 0, 4)); }
    static function addDays(string $d, int $n): string { return date('Y-m-d', strtotime("$d $n days")); }
    static function setting(string $k, string $d = ''): string { return (string)(setting($k, $d) ?? $d); }

    // ───────────────────────── Franchises ─────────────────────────
    static function nextCrmId(): string { $m = (string)DB::val("SELECT MAX(crm_id) FROM fr_franchises WHERE crm_id LIKE 'FR-%'"); return sprintf('FR-%05d', (int)substr($m, 3) + 1); }
    static function franchise(int $id): ?array { return DB::one('SELECT * FROM fr_franchises WHERE id=?', [$id]); }
    static function franchiseList(bool $activeOnly = false): array { [$sc] = self::sqlScope('id'); return DB::all('SELECT id, crm_id, code, name, zone, active FROM fr_franchises WHERE 1=1' . ($activeOnly ? ' AND active=1' : '') . $sc . ' ORDER BY name'); }
    static function zones(): array { return array_column(DB::all("SELECT DISTINCT zone FROM fr_franchises WHERE zone IS NOT NULL AND zone<>'' ORDER BY zone"), 'zone'); }
    /** Recherche par code, identifiant CRM, nom partiel ou alias. */
    static function search(string $q, int $limit = 50): array {
        $q = trim($q); if ($q === '') return []; [$sc] = self::sqlScope('f.id'); $like = '%' . str_replace(['|', '%', '_'], ['||', '|%', '|_'], $q) . '%';
        return DB::all("SELECT DISTINCT f.id, f.crm_id, f.code, f.name, f.zone, f.active FROM fr_franchises f LEFT JOIN fr_aliases a ON a.franchise_id=f.id WHERE (f.code LIKE ? ESCAPE '|' OR f.crm_id LIKE ? ESCAPE '|' OR f.name LIKE ? ESCAPE '|' OR a.alias LIKE ? ESCAPE '|')" . $sc . " ORDER BY f.name LIMIT $limit", [$like, $like, $like, $like]);
    }
    /** Résout un libellé de source (code, BT, nom, alias, identifiant CRM) → [id|null, 'ok'|'unknown'|'ambiguous']. */
    static function resolve(string $raw): array {
        if (self::$map === null) { self::$map = [];
            foreach (DB::all('SELECT id, crm_id, code, name FROM fr_franchises') as $f) foreach ([$f['crm_id'], $f['code'], $f['name']] as $k) { $k = self::norm((string)$k); if ($k !== '') self::$map[$k][(int)$f['id']] = 1; }
            foreach (DB::all('SELECT franchise_id, alias FROM fr_aliases') as $a) { $k = self::norm((string)$a['alias']); if ($k !== '') self::$map[$k][(int)$a['franchise_id']] = 1; } }
        $k = self::norm($raw); if ($k === '') return [null, 'unknown']; $ids = array_keys(self::$map[$k] ?? []);
        return count($ids) === 1 ? [$ids[0], 'ok'] : [null, $ids ? 'ambiguous' : 'unknown'];
    }
    static function resetMap(): void { self::$map = null; }
    /** Zone de la franchise à une date (périmètre de l'époque) ; $day null = zone actuelle. */
    static function zoneAt(int $fid, ?string $day): ?string {
        if ($day === null) return DB::val('SELECT zone FROM fr_franchises WHERE id=?', [$fid]);
        $z = DB::val('SELECT zone FROM fr_assign WHERE franchise_id=? AND from_day<=? AND (to_day IS NULL OR to_day>=?) ORDER BY from_day DESC LIMIT 1', [$fid, $day, $day]);
        return $z ?? DB::val('SELECT zone FROM fr_franchises WHERE id=?', [$fid]);
    }
    /** Enregistre une affectation (zone, responsable, BO) en fermant la précédente. */
    static function assignPeriod(int $fid, ?string $zone, ?string $manager, ?string $bo, string $from, string $reason): void {
        DB::exec('UPDATE fr_assign SET to_day=? WHERE franchise_id=? AND to_day IS NULL AND from_day<?', [self::addDays($from, -1), $fid, $from]);
        DB::insert('fr_assign', ['franchise_id' => $fid, 'zone' => $zone, 'manager' => $manager, 'bo_team' => $bo, 'from_day' => $from, 'to_day' => null, 'reason' => mb_substr($reason, 0, 300), 'user_id' => Auth::id(), 'created_at' => now()]);
    }

    // ───────────────────────── Calendrier ouvré et SLA ─────────────────────────
    private static function cal(): array {
        if (self::$cal === null) { self::$cal = []; foreach (DB::all('SELECT day, kind FROM fr_calendar') as $r) self::$cal[$r['day']] = $r['kind']; } return self::$cal;
    }
    static function resetCal(): void { self::$cal = null; }
    static function workdays(): array { return array_map('intval', array_filter(explode(',', self::setting('fr.workdays', '1,2,3,4,5,6')), 'strlen')); }
    static function isWork(string $day): bool {
        $k = self::cal()[$day] ?? null; if ($k === 'holiday' || $k === 'closed') return false; if ($k === 'open') return true;
        return in_array((int)date('N', strtotime($day)), self::workdays(), true);
    }
    static function workDaysBetween(string $from, string $to): int { $n = 0; for ($d = $from, $i = 0; $d <= $to && $i < 800; $d = self::addDays($d, 1), $i++) if (self::isWork($d)) $n++; return $n; }
    static function daysBetween(string $from, string $to): int { return max(0, (int)round((strtotime($to) - strtotime($from)) / 86400) + 1); }
    private static function hm(string $k, string $d): int { [$h, $m] = array_map('intval', explode(':', self::setting($k, $d)) + [0, 0]); return $h * 3600 + $m * 60; }
    /** Heures ouvrées entre deux instants (jours ouvrés et plage horaire du paramétrage). */
    static function bizBetween(string $a, string $b): float {
        $ta = strtotime($a); $tb = strtotime($b); if ($tb <= $ta) return 0.0; $s = self::hm('fr.day_start', '08:00'); $e = self::hm('fr.day_end', '17:00'); $h = 0.0;
        for ($d = date('Y-m-d', $ta), $i = 0; $d <= date('Y-m-d', $tb) && $i < 800; $d = self::addDays($d, 1), $i++) {
            if (!self::isWork($d)) continue; $t0 = strtotime($d) + $s; $t1 = strtotime($d) + $e; $x = max($ta, $t0); $y = min($tb, $t1); if ($y > $x) $h += ($y - $x) / 3600;
        }
        return round($h, 2);
    }
    static function addBiz(string $start, float $hours): string {
        $t = strtotime($start); if ($hours <= 0) return date('Y-m-d H:i:s', $t); $s = self::hm('fr.day_start', '08:00'); $e = self::hm('fr.day_end', '17:00'); $left = $hours * 3600;
        for ($d = date('Y-m-d', $t), $i = 0; $i < 800; $d = self::addDays($d, 1), $i++) {
            if (!self::isWork($d)) continue; $t0 = max($t, strtotime($d) + $s); $t1 = strtotime($d) + $e; if ($t0 >= $t1) continue;
            if ($left <= $t1 - $t0) return date('Y-m-d H:i:s', (int)($t0 + $left)); $left -= $t1 - $t0;
        }
        return date('Y-m-d H:i:s', $t + (int)($hours * 3600));
    }
    static function prioFactor(string $p): float { $m = []; foreach (explode(',', self::setting('fr.prio_factor', 'urgent:0.5,high:0.75,normal:1,low:1.5')) as $x) { $kv = explode(':', $x); if (count($kv) === 2) $m[trim($kv[0])] = (float)$kv[1]; } return $m[$p] ?? 1.0; }
    static function dueAt(string $from, ?array $cat, string $prio): ?string {
        if (!$cat || !(int)$cat['sla_hours']) return null; $h = (float)$cat['sla_hours'] * self::prioFactor($prio);
        return ($cat['calendar'] ?? 'business') === 'continuous' ? date('Y-m-d H:i:s', strtotime($from) + (int)($h * 3600)) : self::addBiz($from, $h);
    }
    static function delayHours(string $from, string $to, string $calendar): float { return $calendar === 'continuous' ? round((strtotime($to) - strtotime($from)) / 3600, 2) : self::bizBetween($from, $to); }

    // ───────────────────────── Circuit des demandes ─────────────────────────
    static function nextRef(): string { $y = date('Y'); $n = (int)DB::val('SELECT COUNT(*) FROM fr_requests WHERE ref LIKE ?', ["DEM-$y-%"]) + 1; do { $ref = sprintf('DEM-%s-%06d', $y, $n++); } while (DB::val('SELECT 1 FROM fr_requests WHERE ref=?', [$ref])); return $ref; }
    static function ev(int $rid, string $kind, ?string $from, ?string $to, string $reason = '', string $note = '', ?string $at = null, ?int $uid = null, ?string $uname = null): void {
        DB::insert('fr_events', ['request_id' => $rid, 'at' => $at ?? now(), 'user_id' => $uid ?? Auth::id(), 'user_name' => $uname ?? (Auth::user()['name'] ?? 'système'), 'kind' => $kind, 'from_status' => $from, 'to_status' => $to, 'reason' => mb_substr($reason, 0, 190) ?: null, 'note' => mb_substr($note, 0, 500) ?: null]);
    }
    static function catalogRow(?int $id): ?array { return $id ? DB::one('SELECT * FROM fr_catalog WHERE id=?', [$id]) : null; }
    /** Crée un dossier. Retourne [id, message d'erreur]. */
    static function create(array $d): array {
        $fid = (int)($d['franchise_id'] ?? 0); $f = $fid ? self::franchise($fid) : null;
        if (!$f) return [0, 'Franchise obligatoire.']; if (!(int)$f['active']) return [0, 'Cette franchise est désactivée : aucun dossier ne peut être créé.']; if (!self::sees($fid)) return [0, 'Franchise hors de votre périmètre.'];
        $cat = self::catalogRow((int)($d['catalog_id'] ?? 0)); if (!$cat || !(int)$cat['active']) return [0, 'Service et typologie obligatoires (catalogue).'];
        foreach (self::requiredFields($cat) as $k => $lab) if (trim((string)($d[$k] ?? '')) === '') return [0, "$lab est obligatoire pour ce motif."];
        $prio = isset(self::PRIO[$d['priority'] ?? '']) ? $d['priority'] : 'normal'; $at = $d['created_at'] ?? now();
        $status = !empty($d['assignee_id']) || !empty($d['team']) ? 'assigned' : 'new'; $iccid = trim((string)($d['iccid'] ?? ''));
        if ($iccid !== '' && !preg_match('/^\d{18,22}$/', $iccid)) return [0, 'L\'ICCID doit contenir 18 à 22 chiffres (saisi comme texte).'];
        $id = DB::insert('fr_requests', ['ref' => self::nextRef(), 'franchise_id' => $fid, 'created_at' => $at, 'reporter' => trim((string)($d['reporter'] ?? '')) ?: (Auth::user()['name'] ?? null), 'channel' => isset(self::CHANNELS[$d['channel'] ?? '']) ? $d['channel'] : 'crm',
            'source_ref' => self::nz($d['source_ref'] ?? null), 'bt_ref' => self::nz($d['bt_ref'] ?? null), 'catalog_id' => (int)$cat['id'], 'service' => $cat['service'], 'typology' => $cat['typology'], 'subtype' => $cat['subtype'], 'eligible' => (int)$cat['eligible'], 'priority' => $prio,
            'team' => self::nz($d['team'] ?? null), 'assignee_id' => !empty($d['assignee_id']) ? (int)$d['assignee_id'] : null, 'status' => $status, 'due_at' => self::dueAt($at, $cat, $prio),
            'customer_no' => self::nz($d['customer_no'] ?? null), 'customer_name' => self::nz($d['customer_name'] ?? null), 'new_sub' => !empty($d['new_sub']) ? 1 : 0, 'iccid' => $iccid ?: null, 'id_proof' => self::nz($d['id_proof'] ?? null), 'owner_doc' => self::nz($d['owner_doc'] ?? null),
            'agent_doc' => self::nz($d['agent_doc'] ?? null), 'guarantor_doc' => self::nz($d['guarantor_doc'] ?? null), 'comment' => self::nz($d['comment'] ?? null), 'import_key' => $d['import_key'] ?? null, 'batch_id' => $d['batch_id'] ?? null, 'is_demo' => (int)($d['is_demo'] ?? 0), 'updated_at' => $at]);
        self::ev($id, 'create', null, $status, '', 'Dossier créé (' . $cat['service'] . ' · ' . $cat['typology'] . ')', $at); return [$id, null];
    }
    private static function nz($v): ?string { $v = trim((string)$v); return $v === '' ? null : $v; }
    /** Champs exigés selon le justificatif configuré dans le catalogue (« client », « iccid », « mandataire »…). */
    static function requiredFields(array $cat): array {
        $m = ['client' => ['customer_no', 'Le numéro client'], 'nom' => ['customer_name', 'Le nom du client'], 'iccid' => ['iccid', 'L\'ICCID'], 'piece' => ['id_proof', 'La preuve d\'identité'], 'proprietaire' => ['owner_doc', 'Les pièces du propriétaire'], 'mandataire' => ['agent_doc', 'Les pièces du mandataire'], 'caution' => ['guarantor_doc', 'Les pièces de la caution']];
        $o = []; foreach (array_filter(array_map('trim', explode(',', (string)($cat['required_docs'] ?? '')))) as $k) { $k = self::norm($k); if (isset($m[$k])) $o[$m[$k][0]] = $m[$k][1]; } return $o;
    }
    static function reasons(string $kind): array { return DB::all('SELECT id, label FROM fr_reasons WHERE kind=? AND active=1 ORDER BY label', [$kind]); }
    private static function waitedSeconds(int $rid, string $until): array {
        $biz = 0.0; $cal = 0; $open = null;
        foreach (DB::all('SELECT kind, at FROM fr_events WHERE request_id=? ORDER BY at, id', [$rid]) as $e) {
            if ($e['kind'] === 'hold') $open = $e['at']; elseif ($open !== null && in_array($e['kind'], ['resume', 'execute', 'reject', 'cancel', 'noexec', 'reopen', 'reassign'], true) && ($e['kind'] !== 'reassign')) { $biz += self::bizBetween($open, $e['at']); $cal += max(0, strtotime($e['at']) - strtotime($open)); $open = null; }
        }
        if ($open !== null) { $biz += self::bizBetween($open, $until); $cal += max(0, strtotime($until) - strtotime($open)); }
        return [$biz, $cal];
    }
    /**
     * Applique une action sur un dossier. Actions : assign, take, hold, resume, execute, reject, cancel, noexec, reassign, escalate, reopen, comment.
     * @return ?string message d'erreur (null si l'action est enregistrée)
     */
    static function act(int $rid, string $act, array $in, ?string $at = null): ?string {
        $r = DB::one('SELECT * FROM fr_requests WHERE id=?', [$rid]); if (!$r) return 'Dossier introuvable.'; if (!self::sees((int)$r['franchise_id'])) return 'Dossier hors de votre périmètre.';
        $now = $at ?? now(); $st = $r['status']; $open = in_array($st, self::OPEN, true); $term = !$open; $uid = Auth::id(); $note = trim((string)($in['note'] ?? ''));
        $handle = self::$system || can('fr.handle'); $own = !self::$system && can('fr.own') && !$handle;
        if ($own && !in_array($act, ['comment', 'resume'], true)) return 'Cette action est réservée au back-office.';
        if (!$handle && !$own) return 'Droit insuffisant.';
        if ($own && $act === 'resume' && $st !== 'waiting') return 'Le dossier n\'est pas en attente.';
        $reasonId = (int)($in['reason_id'] ?? 0); $kindFor = ['hold' => 'hold', 'reject' => 'reject', 'cancel' => 'cancel', 'noexec' => 'noexec'];
        $reasonLabel = ''; if (isset($kindFor[$act])) { $row = $reasonId ? DB::one('SELECT label, kind FROM fr_reasons WHERE id=? AND active=1', [$reasonId]) : null; if (!$row || $row['kind'] !== $kindFor[$act]) return 'Choisissez un motif de la liste (' . strtolower(self::KINDS[$act === 'hold' ? 'hold' : $act]) . ').'; $reasonLabel = $row['label']; }
        $upd = ['updated_at' => $now]; $new = $st; $evKind = $act; $reason = $reasonLabel;
        switch ($act) {
            case 'comment': if ($note === '') return 'Le commentaire est vide.'; self::ev($rid, 'comment', $st, $st, '', $note, $now); DB::update('fr_requests', $upd, 'id=?', [$rid]); return null;
            case 'assign': if (!$open) return 'Le dossier est clôturé.'; if ($st !== 'new') return 'Le dossier est déjà affecté : utilisez la réaffectation.';
                if (empty($in['assignee_id']) && trim((string)($in['team'] ?? '')) === '') return 'Indiquez une équipe ou un agent.'; $new = 'assigned'; $upd['assignee_id'] = !empty($in['assignee_id']) ? (int)$in['assignee_id'] : null; $upd['team'] = self::nz($in['team'] ?? null); break;
            case 'take': if (!in_array($st, ['new', 'assigned'], true)) return 'Seul un dossier créé ou affecté peut être pris en charge.'; $new = 'in_progress'; $upd['assignee_id'] = $uid; $upd['taken_at'] = $now; break;
            case 'hold': if (!in_array($st, ['assigned', 'in_progress'], true)) return 'Le dossier doit être affecté ou en traitement pour être mis en attente.';
                if (trim((string)($in['wait_owner'] ?? '')) === '') return 'Indiquez qui doit agir (responsable de l\'attente).'; if (trim((string)($in['wait_action'] ?? '')) === '') return 'Indiquez l\'action attendue.';
                $new = 'waiting'; $upd += ['reason_id' => $reasonId, 'wait_owner' => trim((string)$in['wait_owner']), 'wait_action' => trim((string)$in['wait_action']), 'wait_since' => $now]; break;
            case 'resume': if ($st !== 'waiting') return 'Le dossier n\'est pas en attente.'; if ($own && $note === '') return 'Précisez le complément transmis.'; $new = 'in_progress';
                if (self::setting('fr.sla_pause', '1') === '1' && $r['due_at'] && $r['wait_since']) { $cat = self::catalogRow((int)$r['catalog_id']); $upd['due_at'] = ($cat['calendar'] ?? 'business') === 'continuous' ? date('Y-m-d H:i:s', strtotime($r['due_at']) + max(0, strtotime($now) - strtotime($r['wait_since']))) : self::addBiz($r['due_at'], self::bizBetween($r['wait_since'], $now)); }
                $upd += ['wait_owner' => null, 'wait_action' => null, 'wait_since' => null, 'reason_id' => null]; break;
            case 'execute':
                if (!in_array($st, ['assigned', 'in_progress'], true)) return 'Le dossier doit être affecté ou en traitement pour confirmer l\'exécution.';
                $action = trim((string)($in['action_done'] ?? '')); if ($action === '') return 'Décrivez l\'action réalisée.'; $ex = trim((string)($in['executed_at'] ?? '')); if ($ex === '') return 'La date et l\'heure d\'exécution sont obligatoires.';
                $ex = str_replace('T', ' ', $ex); if (strlen($ex) === 16) $ex .= ':00'; if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $ex) || strtotime($ex) === false) return 'Date d\'exécution invalide.';
                if ($ex < $r['created_at']) return 'La date d\'exécution précède la création du dossier.'; if ($ex > date('Y-m-d H:i:s', strtotime($now) + 300)) return 'La date d\'exécution est dans le futur.';
                $ops = []; foreach ((array)($in['op_type'] ?? []) as $i => $t) { $t = trim((string)$t); if ($t === '') continue; $dict = DB::one('SELECT * FROM fr_opdict WHERE label=?', [$t]); if (!$dict) return "Type d'opération inconnu : $t."; $ops[] = [$dict, trim((string)(((array)($in['op_ref'] ?? []))[$i] ?? ''))]; }
                if (!$ops) return 'Une exécution confirmée exige au moins une opération CRM (type et référence).';
                foreach ($ops as $i => [$dict, $ref]) { $ref = $ref !== '' ? $ref : 'OP-' . $r['ref'] . '-' . ($i + 1); if (DB::val('SELECT 1 FROM fr_ops WHERE op_ref=?', [$ref])) return "La référence d'opération $ref existe déjà."; $ops[$i][1] = $ref; }
                foreach ($ops as [$dict, $ref]) DB::insert('fr_ops', ['op_ref' => $ref, 'request_id' => $rid, 'franchise_id' => (int)$r['franchise_id'], 'service' => $r['service'], 'op_type' => $dict['label'], 'subtype' => $r['subtype'], 'effective_at' => $ex, 'day' => substr($ex, 0, 10), 'result' => 'ok', 'counted' => (int)$dict['counted'], 'source' => 'crm', 'is_demo' => (int)$r['is_demo']]);
                $new = 'executed'; $upd += ['action_done' => $action, 'executed_at' => $ex, 'outcome' => 'executed']; $reason = ''; $note = $note ?: count($ops) . ' opération(s) CRM confirmée(s)'; break;
            case 'reject': case 'cancel': case 'noexec': if (!$open) return 'Le dossier est déjà clôturé.'; $new = ['reject' => 'rejected', 'cancel' => 'cancelled', 'noexec' => 'not_executed'][$act]; $upd['outcome'] = $new; $upd['reason_id'] = $reasonId; break;
            case 'reassign': if (!$open) return 'Le dossier est clôturé.'; if ($note === '') return 'Un motif de réaffectation est obligatoire (journalisé).'; if (empty($in['assignee_id']) && trim((string)($in['team'] ?? '')) === '') return 'Indiquez la nouvelle équipe ou le nouvel agent.';
                $upd['assignee_id'] = !empty($in['assignee_id']) ? (int)$in['assignee_id'] : null; $upd['team'] = self::nz($in['team'] ?? null); if ($st === 'new') $new = 'assigned'; break;
            case 'escalate': if (!$open) return 'Le dossier est clôturé.'; if ($note === '') return 'Un motif d\'escalade est obligatoire.'; $upd['escalated'] = 1; if (!in_array($r['priority'], ['urgent'], true)) $upd['priority'] = $r['priority'] === 'high' ? 'urgent' : 'high'; break;
            case 'reopen': if (!$term) return 'Le dossier n\'est pas clôturé.'; if ($note === '') return 'Un motif de réouverture est obligatoire (journalisé).'; $new = 'in_progress'; $upd += ['closed_at' => null, 'outcome' => null, 'delay_h' => null, 'reopen_count' => (int)$r['reopen_count'] + 1, 'taken_at' => $now, 'assignee_id' => $uid];
                if (self::setting('fr.sla_reopen', 'keep') === 'restart') $upd['due_at'] = self::dueAt($now, self::catalogRow((int)$r['catalog_id']), $r['priority']); break;
            default: return 'Action inconnue.';
        }
        if (in_array($new, self::TERM, true) && $open) {
            $upd['closed_at'] = $act === 'execute' ? $upd['executed_at'] : $now; if ($upd['closed_at'] < $r['created_at']) $upd['closed_at'] = $now; $cat = self::catalogRow((int)$r['catalog_id']); $cal = $cat['calendar'] ?? 'business';
            [$wb, $wc] = self::setting('fr.sla_pause', '1') === '1' ? self::waitedSeconds($rid, $upd['closed_at']) : [0.0, 0]; $h = self::delayHours($r['created_at'], $upd['closed_at'], $cal) - ($cal === 'continuous' ? $wc / 3600 : $wb); $upd['delay_h'] = max(0, round($h, 2));
        }
        $upd['status'] = $new; DB::update('fr_requests', $upd, 'id=?', [$rid]);
        $evAt = $act === 'execute' ? $now : $now; self::ev($rid, $evKind, $st, $new, $reason, $note, $evAt);
        if ($act === 'escalate') Notifier::toPermission('fr.manage', 'Dossier franchise escaladé : ' . $r['ref'], $note, '/fr/requests/' . $rid);
        if ($act === 'hold' && !empty($r['reporter'])) { /* la franchise consulte la file : pas de notification nominative (aucun compte rattaché au déclarant) */ }
        return null;
    }
    /** Statut d'un dossier à une date de coupe, reconstitué depuis l'historique ; null si non créé à cette date. */
    static function statusAt(array $events, string $created, string $cut): ?string { if ($created > $cut) return null; $s = null; foreach ($events as $e) { if ($e['at'] > $cut) break; if ($e['to_status']) $s = $e['to_status']; } return $s; }

    // ───────────────────────── Données sensibles ─────────────────────────
    static function canReveal(int $fid): bool { return (can('fr.sensitive') || (can('fr.own') && self::franchiseUser())) && self::sees($fid); }
    static function revealLog(array $r): void { Audit::log('fr.reveal', 'fr_requests', $r['id'], null, ['ref' => $r['ref'], 'champs' => 'numéro client, ICCID, pièces']); }
    /** Dossier avec champs sensibles masqués (sauf $reveal). */
    static function view(array $r, bool $reveal): array { if ($reveal) return $r; foreach (self::SENS as $k) if (!empty($r[$k])) $r[$k] = self::mask((string)$r[$k]); return $r; }
}
