<?php
namespace App\Core;
/** Client IMAP minimal (LOGIN, SELECT, UID SEARCH UNSEEN, UID FETCH, STORE \Seen). Pas d'OAuth2 : mot de passe ou mot de passe d'application. */
class Imap {
    private $fp; private int $n = 0;
    /** @param string $secure ssl | tls (STARTTLS) | none */
    function connect(string $host, int $port, string $secure = 'ssl', bool $verify = true): void {
        $secure = strtolower($secure);
        $ctx = stream_context_create(['ssl' => ['verify_peer' => $verify, 'verify_peer_name' => $verify, 'peer_name' => $host]]);
        $this->fp = @stream_socket_client(($secure === 'ssl' ? 'ssl://' : 'tcp://') . "$host:$port", $en, $es, 15, STREAM_CLIENT_CONNECT, $ctx);
        if (!$this->fp) throw new \RuntimeException("Connexion IMAP impossible ($host:$port) : $es");
        stream_set_timeout($this->fp, 30);
        $g = fgets($this->fp, 2048); if ($g === false || !str_starts_with($g, '* OK') && !str_starts_with($g, '* PREAUTH')) throw new \RuntimeException('IMAP : accueil inattendu.');
        if ($secure === 'tls') {
            $this->cmd('STARTTLS');
            if (!@stream_socket_enable_crypto($this->fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new \RuntimeException('IMAP : négociation TLS refusée.');
        }
    }
    private static function q(string $s): string {
        if (preg_match('/[\r\n\x00]/', $s)) throw new \RuntimeException('Caractère interdit dans un identifiant IMAP.');
        return '"' . addcslashes($s, '"\\') . '"';
    }
    /** Envoie une commande et lit la réponse (littéraux {N} compris). @return array{0:string,1:array} lignes non étiquetées (littéraux inclus), texte final */
    function cmd(string $c): array {
        $tag = 'A' . str_pad((string)++$this->n, 4, '0', STR_PAD_LEFT); fwrite($this->fp, "$tag $c\r\n");
        $lines = []; $cur = '';
        while (true) {
            $l = fgets($this->fp, 65536); if ($l === false) throw new \RuntimeException('Connexion IMAP interrompue.');
            if (preg_match('/\{(\d+)\}\r?\n$/', $l, $m)) {
                $len = (int)$m[1]; $cur .= $l; $buf = '';
                while (strlen($buf) < $len) { $p = fread($this->fp, $len - strlen($buf)); if ($p === false || $p === '') throw new \RuntimeException('Connexion IMAP interrompue.'); $buf .= $p; }
                $cur .= "\0LIT\0" . $buf . "\0END\0"; continue;
            }
            if (str_starts_with($l, $tag . ' ')) {
                if (!preg_match('/^' . $tag . ' OK/i', $l)) throw new \RuntimeException('IMAP : ' . mb_substr(trim($l), 0, 160));
                if ($cur !== '') $lines[] = $cur; return [$lines, trim($l)];
            }
            $cur .= $l; if (str_ends_with($l, "\n")) { $lines[] = $cur; $cur = ''; }
        }
    }
    function login(string $user, string $pass): void { $this->cmd('LOGIN ' . self::q($user) . ' ' . self::q($pass)); }
    function select(string $folder): void { $this->cmd('SELECT ' . self::q($folder)); }
    /** @return int[] UID des messages non lus */
    function unseen(): array {
        [$l] = $this->cmd('UID SEARCH UNSEEN'); $ids = [];
        foreach ($l as $x) if (preg_match('/^\* SEARCH ?(.*)$/m', $x, $m)) foreach (preg_split('/\s+/', trim($m[1])) as $i) if (ctype_digit($i)) $ids[] = (int)$i;
        return $ids;
    }
    function size(int $uid): int { [$l] = $this->cmd("UID FETCH $uid (RFC822.SIZE)"); foreach ($l as $x) if (preg_match('/RFC822\.SIZE (\d+)/', $x, $m)) return (int)$m[1]; return 0; }
    /** Récupère le message brut sans le marquer comme lu. */
    function fetch(int $uid): string {
        [$l] = $this->cmd("UID FETCH $uid BODY.PEEK[]");
        foreach ($l as $x) if (preg_match("/\0LIT\0(.*)\0END\0/s", $x, $m)) return $m[1];
        throw new \RuntimeException("IMAP : message $uid introuvable.");
    }
    function markSeen(int $uid): void { $this->cmd("UID STORE $uid +FLAGS (\\Seen)"); }
    function logout(): void { try { $this->cmd('LOGOUT'); } catch (\Throwable $e) {} if (is_resource($this->fp)) @fclose($this->fp); }
}
