<?php
namespace App\Core;
/** Chiffrement des secrets (clés API) stockés en base : libsodium secretbox, clé dans storage/.appkey (créée au premier usage, à sauvegarder avec la base). */
class Secret {
    private static function key(): string {
        $e = (string)env('APP_KEY', ''); if ($e !== '') return hash('sha256', $e, true);
        $f = ROOT . '/storage/.appkey'; if (!is_file($f)) { @mkdir(dirname($f), 0775, true); file_put_contents($f, bin2hex(random_bytes(32))); @chmod($f, 0600); }
        return hash('sha256', trim((string)file_get_contents($f)), true);
    }
    static function enc(string $v): string { if ($v === '') return ''; $n = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES); return 'enc:' . base64_encode($n . sodium_crypto_secretbox($v, $n, self::key())); }
    static function dec(string $v): string {
        if ($v === '' || !str_starts_with($v, 'enc:')) return $v; $raw = base64_decode(substr($v, 4), true); if ($raw === false || strlen($raw) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) return '';
        $p = sodium_crypto_secretbox_open(substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), self::key()); return $p === false ? '' : $p;
    }
}
