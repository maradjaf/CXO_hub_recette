<?php
namespace App\Core;

/**
 * Lecture et écriture minimales de classeurs XLSX (ZipArchive + XML), sans dépendance externe.
 * Lecture : toutes les feuilles (visibles ou masquées), cellules rendues en texte brut ; les nombres gardent leur écriture XML d'origine
 * (un ICCID saisi en nombre apparaît donc en notation scientifique, ce que le contrôle d'import signale).
 * Écriture : toutes les valeurs texte sont écrites en texte (jamais converties en nombre), pour préserver ICCID et numéros.
 */
final class Xlsx {
    /** @return array{0:array<string,array<int,array<int,string>>>,1:?string} feuilles => lignes (index de ligne Excel => colonnes), message d'erreur */
    static function read(string $path): array {
        if (!class_exists(\ZipArchive::class)) return [[], 'L\'extension PHP « zip » est requise pour lire un classeur XLSX.'];
        $z = new \ZipArchive();
        if ($z->open($path) !== true) return [[], 'Classeur illisible (fichier XLSX attendu).'];
        $wb = $z->getFromName('xl/workbook.xml'); if ($wb === false) { $z->close(); return [[], 'Classeur illisible (workbook.xml absent).']; }
        $rels = []; $rx = $z->getFromName('xl/_rels/workbook.xml.rels');
        if ($rx !== false) { $x = @simplexml_load_string($rx); if ($x) foreach ($x->Relationship as $r) $rels[(string)$r['Id']] = ltrim((string)$r['Target'], '/'); }
        $ss = []; $sx = $z->getFromName('xl/sharedStrings.xml');
        if ($sx !== false) { $x = @simplexml_load_string($sx); if ($x) foreach ($x->si as $si) { $t = ''; if (isset($si->t)) $t .= (string)$si->t; foreach ($si->r as $run) $t .= (string)$run->t; $ss[] = $t; } }
        $x = @simplexml_load_string($wb); if (!$x) { $z->close(); return [[], 'Classeur illisible (structure invalide).']; }
        $x->registerXPathNamespace('m', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main');
        $out = [];
        foreach ($x->sheets->sheet as $sh) {
            $rid = (string)$sh->attributes('http://schemas.openxmlformats.org/officeDocument/2006/relationships')['id']; $target = $rels[$rid] ?? '';
            $file = str_starts_with($target, 'xl/') ? $target : 'xl/' . $target; $xml = $z->getFromName($file); if ($xml === false) continue;
            $out[(string)$sh['name']] = self::sheet($xml, $ss);
        }
        $z->close();
        return [$out, $out ? null : 'Le classeur ne contient aucune feuille lisible.'];
    }
    private static function sheet(string $xml, array $ss): array {
        $rows = []; $r = new \XMLReader(); $r->XML($xml, null, LIBXML_NONET | LIBXML_COMPACT);
        while ($r->read()) {
            if ($r->nodeType !== \XMLReader::ELEMENT || $r->localName !== 'row') continue;
            $n = (int)$r->getAttribute('r'); $node = simplexml_load_string($r->readOuterXml()); if (!$node) continue; $cells = []; $seq = 0;
            foreach ($node->c as $c) {
                $ref = (string)$c['r']; $col = $ref !== '' ? self::col($ref) : $seq; $seq = $col + 1; $t = (string)$c['t'];
                if ($t === 's') $v = $ss[(int)$c->v] ?? ''; elseif ($t === 'inlineStr') { $v = (string)$c->is->t; foreach ($c->is->r as $run) $v .= (string)$run->t; } else $v = isset($c->v) ? (string)$c->v : '';
                if ($v !== '') $cells[$col] = $v;
            }
            if ($cells) { ksort($cells); $rows[$n ?: count($rows) + 1] = $cells; }
        }
        $r->close(); return $rows;
    }
    private static function col(string $ref): int { $l = preg_replace('/\d+/', '', $ref); $n = 0; foreach (str_split(strtoupper($l)) as $ch) $n = $n * 26 + ord($ch) - 64; return $n - 1; }
    static function colName(int $i): string { $s = ''; $i++; while ($i > 0) { $m = ($i - 1) % 26; $s = chr(65 + $m) . $s; $i = intdiv($i - $m - 1, 26); } return $s; }
    /** Date Excel (numéro de série) ou texte → AAAA-MM-JJ ; null si illisible. */
    static function day(string $v): ?string {
        $v = trim($v); if ($v === '') return null;
        if (preg_match('/^(\d{4})-(\d{2})-(\d{2})/', $v, $m) && checkdate((int)$m[2], (int)$m[3], (int)$m[1])) return "$m[1]-$m[2]-$m[3]";
        if (preg_match('/^(\d{4})(\d{2})(\d{2})$/', $v, $m) && checkdate((int)$m[2], (int)$m[3], (int)$m[1])) return "$m[1]-$m[2]-$m[3]";
        if (preg_match('#^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})#', $v, $m) && checkdate((int)$m[2], (int)$m[1], (int)$m[3])) return sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
        if (preg_match('/^\d{5}(\.\d+)?$/', $v)) { $ts = ((int)floor((float)$v) - 25569) * 86400; $d = gmdate('Y-m-d', $ts); return $d >= '2000-01-01' && $d <= '2100-12-31' ? $d : null; }
        return null;
    }
    /**
     * Écrit un classeur. $sheets = [nom => ['rows' => [[...]], 'widths' => [..]?, 'head' => 1 (nb de lignes d'en-tête en gras)]].
     * Les cellules numériques (int/float) restent des nombres, les chaînes restent du texte.
     */
    static function write(array $sheets): string {
        $z = new \ZipArchive(); $tmp = tempnam(sys_get_temp_dir(), 'xlsx'); $z->open($tmp, \ZipArchive::OVERWRITE);
        $ct = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';
        $wbs = ''; $wrel = ''; $i = 0;
        foreach ($sheets as $name => $sh) {
            $i++; $ct .= '<Override PartName="/xl/worksheets/sheet' . $i . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
            $wbs .= '<sheet name="' . htmlspecialchars(mb_substr(preg_replace('/[\\\\\/?*\[\]:]/', ' ', (string)$name), 0, 31), ENT_XML1) . '" sheetId="' . $i . '" r:id="rId' . $i . '"/>';
            $wrel .= '<Relationship Id="rId' . $i . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $i . '.xml"/>';
            $z->addFromString('xl/worksheets/sheet' . $i . '.xml', self::sheetXml($sh));
        }
        $wrel .= '<Relationship Id="rId' . ($i + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';
        $z->addFromString('[Content_Types].xml', $ct . '</Types>');
        $z->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
        $z->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' . $wbs . '</sheets></workbook>');
        $z->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' . $wrel . '</Relationships>');
        $z->addFromString('xl/styles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF003A84"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>');
        $z->close(); $b = (string)file_get_contents($tmp); @unlink($tmp); return $b;
    }
    private static function sheetXml(array $sh): string {
        $head = (int)($sh['head'] ?? 1); $x = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';
        if (!empty($sh['widths'])) { $x .= '<cols>'; foreach ($sh['widths'] as $k => $w) $x .= '<col min="' . ($k + 1) . '" max="' . ($k + 1) . '" width="' . (float)$w . '" customWidth="1"/>'; $x .= '</cols>'; }
        $x .= '<sheetData>'; $n = 0;
        foreach ($sh['rows'] as $row) {
            $n++; $x .= '<row r="' . $n . '">';
            foreach (array_values($row) as $c => $v) {
                if ($v === null || $v === '') continue; $ref = self::colName($c) . $n; $s = $n <= $head ? ' s="1"' : '';
                if (is_int($v) || is_float($v)) $x .= '<c r="' . $ref . '"' . $s . '><v>' . (is_float($v) ? rtrim(rtrim(sprintf('%.6F', $v), '0'), '.') : $v) . '</v></c>';
                else $x .= '<c r="' . $ref . '"' . $s . ' t="inlineStr"><is><t xml:space="preserve">' . htmlspecialchars(preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', (string)$v), ENT_XML1 | ENT_SUBSTITUTE, 'UTF-8') . '</t></is></c>';
            }
            $x .= '</row>';
        }
        return $x . '</sheetData></worksheet>';
    }
}
