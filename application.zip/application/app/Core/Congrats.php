<?php
namespace App\Core;

/** Félicitations de mobilité : à chaque mobilité effectuée, un message est publié pour tout le personnel (photo, nom, ancien et nouveau poste). */
class Congrats {
    const VARS = ['{prenom}' => 'Prénom', '{nom}' => 'Nom', '{ancien_poste}' => 'Ancien poste', '{nouveau_poste}' => 'Nouveau poste', '{date}' => 'Date d\'effet'];
    const DEFAULT_TITLE = 'Félicitations à {prenom} {nom} !';
    const DEFAULT_BODY = '{prenom} {nom} change de poste : de {ancien_poste} à {nouveau_poste}. Toute l\'équipe lui souhaite pleine réussite dans ses nouvelles fonctions !';
    static function enabled(): bool { return Settings::get('congrats.enabled', '1') !== '0'; }
    static function template(): array {
        $t = DB::one('SELECT * FROM congrats_templates WHERE active=1 ORDER BY is_default DESC, id LIMIT 1');
        return $t ?: ['id' => 0, 'name' => 'Modèle intégré', 'title' => self::DEFAULT_TITLE, 'body' => self::DEFAULT_BODY];
    }
    static function fill(string $s, array $v): string { return strtr($s, ['{prenom}' => $v['prenom'], '{nom}' => $v['nom'], '{ancien_poste}' => $v['old'], '{nouveau_poste}' => $v['new'], '{date}' => $v['date']]); }
    /** Libellé « poste · unité » d'une extrémité de la mobilité. */
    private static function label(?int $pos, ?int $unit): string {
        $p = $pos ? (string)DB::val('SELECT name FROM positions WHERE id=?', [$pos]) : ''; $u = $unit ? (string)DB::val('SELECT name FROM org_units WHERE id=?', [$unit]) : '';
        return trim($p . ($p !== '' && $u !== '' ? ' · ' : '') . $u) ?: 'son poste précédent';
    }
    /** Publie le message d'une mobilité effectuée (une seule fois) et prévient tous les utilisateurs actifs. */
    static function publish(int $moveId, ?int $templateId = null, bool $notify = true): ?int {
        if (!self::enabled() || DB::val('SELECT 1 FROM congrats_posts WHERE move_id=?', [$moveId])) return null;
        $m = DB::one("SELECT * FROM mobility_moves WHERE id=? AND status='done'", [$moveId]); if (!$m) return null;
        $e = DB::one('SELECT * FROM employees WHERE id=?', [(int)$m['employee_id']]); if (!$e) return null;
        $old = self::label($m['from_position_id'] ? (int)$m['from_position_id'] : null, $m['from_unit_id'] ? (int)$m['from_unit_id'] : null);
        $new = self::label($m['to_position_id'] ? (int)$m['to_position_id'] : ($e['position_id'] ? (int)$e['position_id'] : null), $m['to_unit_id'] ? (int)$m['to_unit_id'] : null);
        $t = $templateId ? (DB::one('SELECT * FROM congrats_templates WHERE id=? AND active=1', [$templateId]) ?: self::template()) : self::template();
        $v = ['prenom' => (string)$e['first_name'], 'nom' => (string)$e['last_name'], 'old' => $old, 'new' => $new, 'date' => d($m['effective_date'] ?: date('Y-m-d'))];
        $id = DB::insert('congrats_posts', ['move_id' => $moveId, 'employee_id' => (int)$e['id'], 'title' => mb_substr(self::fill($t['title'], $v), 0, 190), 'message' => mb_substr(self::fill($t['body'], $v), 0, 1000), 'from_position' => mb_substr($old, 0, 150), 'to_position' => mb_substr($new, 0, 150),
            'effective_date' => $m['effective_date'] ?: date('Y-m-d'), 'created_by' => Auth::id(), 'created_at' => now(), 'active' => 1]);
        if (!$notify) return $id;
        $me = DB::val('SELECT id FROM users WHERE employee_id=?', [(int)$e['id']]);
        foreach (DB::all("SELECT id FROM users WHERE status='active'") as $u) if (!$me || (int)$u['id'] !== (int)$me) Notifier::send((int)$u['id'], 'Mobilité : félicitations à ' . $e['first_name'] . ' ' . $e['last_name'], $new, '/congrats');
        return $id;
    }
}
