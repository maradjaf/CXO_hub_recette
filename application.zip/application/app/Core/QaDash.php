<?php
namespace App\Core;
/** Tableau de bord qualité CXO : calculs par période (semaine, mois, trimestre, année), activités, niveaux, taux de non-conformité. */
class QaDash {
    const GRAN = ['week' => 'Semaine', 'month' => 'Mois', 'quarter' => 'Trimestre', 'year' => 'Année'];
    const MONTHS = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
    static function target(): float { return (float)setting('qa.target', 100); }
    static function threshold(): float { return (float)setting('qa.nc_threshold', 3); }
    /** Niveau : 1 Star (≥ cible), 2 High performer (≥ 90), 3 Middle performer (≥ 85), 4 Low performer. */
    static function level(?float $pct): array {
        if ($pct === null) return [0, '—', '#fff', '#6B7788'];
        if ($pct >= self::target() - 0.005) return [1, 'Star', '#2FB27C', '#fff'];
        if ($pct >= (float)setting('qa.lvl_high', 90)) return [2, 'High performer', '#003A84', '#fff'];
        if ($pct >= (float)setting('qa.lvl_mid', 85)) return [3, 'Middle performer', '#FFCE00', '#172033'];
        return [4, 'Low performer', '#D72D32', '#fff'];
    }
    static function key(string $date, string $gran): string {
        $t = strtotime($date);
        return match ($gran) { 'week' => date('o', $t) . '-W' . date('W', $t), 'month' => date('Y-m', $t), 'quarter' => date('Y', $t) . '-Q' . (int)ceil((int)date('n', $t) / 3), default => date('Y', $t) };
    }
    static function label(string $key, string $gran): string {
        return match ($gran) { 'week' => 'S' . substr($key, 6) . '_' . substr($key, 2, 2), 'month' => self::MONTHS[(int)substr($key, 5, 2) - 1] . '-' . substr($key, 2, 2), 'quarter' => 'T' . substr($key, 6) . ' ' . substr($key, 0, 4), default => $key };
    }
    /** Périodes (clé => libellé) couvrant [from, to], dans l'ordre. */
    static function periods(string $from, string $to, string $gran): array {
        $out = []; for ($t = strtotime($from); $t <= strtotime($to); $t += 86400) { $k = self::key(date('Y-m-d', $t), $gran); if (!isset($out[$k])) $out[$k] = self::label($k, $gran); } return $out;
    }
    static function defaults(string $gran): array {
        $to = date('Y-m-d');
        $from = match ($gran) { 'week' => date('Y-m-d', strtotime('monday this week -7 weeks')), 'month' => date('Y-m-01', strtotime('-5 months')), 'quarter' => date('Y-m-d', mktime(0, 0, 0, ((int)ceil((int)date('n') / 3) - 1) * 3 + 1 - 9, 1, (int)date('Y'))), default => date('Y-01-01', strtotime('-2 years')) };
        return [$from, $to];
    }
    static function build(array $f): array {
        $gran = $f['gran']; $per = self::periods($f['from'], $f['to'], $gran); $pk = array_keys($per);
        [$w, $p] = Scope::sql('v.employee_id'); [$w2, $p2] = Scope::sql('c.employee_id');
        $extra = ''; $ep = []; if ($f['office'] !== '') { $extra .= ' AND t.office=?'; $ep[] = $f['office']; } $tids = array_values(array_unique(array_filter(array_map('intval', $f['team_ids'] ?? ($f['team_id'] ? [$f['team_id']] : []))))); if ($tids) { $extra .= ' AND e.team_id IN (' . implode(',', array_fill(0, count($tids), '?')) . ')'; array_push($ep, ...$tids); }
        $join = 'JOIN employees e ON e.id=v.employee_id LEFT JOIN teams t ON t.id=e.team_id';
        $base = [$f['from'], $f['to']];
        $rows = DB::all("SELECT v.employee_id eid, v.eval_date d, v.score_pct s, COALESCE(t.name,'Sans équipe') team, t.office off, e.first_name fn, e.last_name ln FROM qa_evaluations v $join WHERE v.eval_date>=? AND v.eval_date<=? AND $w$extra", array_merge($base, $p, $ep));
        $z = fn() => array_fill_keys($pk, null);
        $per_n = array_fill_keys($pk, 0); $per_100 = $per_n; $per_sum = array_fill_keys($pk, 0.0); $team = []; $emp = []; $names = [];
        foreach ($rows as $r) {
            $k = self::key($r['d'], $gran); if (!isset($per_n[$k])) continue; $s = (float)$r['s'];
            $per_n[$k]++; $per_sum[$k] += $s; if ($s >= self::target() - 0.005) $per_100[$k]++;
            $team[$r['team']][$k]['n'] = ($team[$r['team']][$k]['n'] ?? 0) + 1; $team[$r['team']][$k]['sum'] = ($team[$r['team']][$k]['sum'] ?? 0) + $s;
            $emp[$r['eid']][$k]['n'] = ($emp[$r['eid']][$k]['n'] ?? 0) + 1; $emp[$r['eid']][$k]['sum'] = ($emp[$r['eid']][$k]['sum'] ?? 0) + $s; $names[$r['eid']] = [trim($r['ln'] . ' ' . $r['fn']), $r['team']];
        }
        $avg = []; foreach ($pk as $k) $avg[$k] = $per_n[$k] ? $per_sum[$k] / $per_n[$k] : null;
        $teamAvg = []; foreach ($team as $name => $byP) { foreach ($pk as $k) $teamAvg[$name][$k] = isset($byP[$k]) ? $byP[$k]['sum'] / $byP[$k]['n'] : null; }
        ksort($teamAvg);
        $lv1 = array_fill_keys($pk, 0); $cc = $lv1;
        foreach ($emp as $byP) foreach ($byP as $k => $a) { $cc[$k]++; if ($a['sum'] / $a['n'] >= self::target() - 0.005) $lv1[$k]++; }
        // Coachings réalisés
        $coach = array_fill_keys($pk, 0);
        foreach (DB::all("SELECT SUBSTR(c.planned_at,1,10) d, COUNT(*) n FROM qa_coachings c JOIN employees e ON e.id=c.employee_id LEFT JOIN teams t ON t.id=e.team_id WHERE c.status='done' AND SUBSTR(c.planned_at,1,10)>=? AND SUBSTR(c.planned_at,1,10)<=? AND $w2$extra GROUP BY SUBSTR(c.planned_at,1,10)", array_merge($base, $p2, $ep)) as $r) { $k = self::key($r['d'], $gran); if (isset($coach[$k])) $coach[$k] += (int)$r['n']; }
        // Non-conformités : un critère est non conforme quand ses points sont inférieurs au maximum
        $crit = []; $ncO = ['FO' => [], 'BO' => [], 'SUP' => []]; foreach (['FO', 'BO', 'SUP'] as $o) foreach ($pk as $k) $ncO[$o][$k] = ['n' => 0, 'nc' => 0];
        $tot = ['n' => 0, 'nc' => 0];
        foreach (DB::all("SELECT c.label, v.eval_date d, t.office off, COUNT(*) n, SUM(CASE WHEN s.points < c.max_points - 0.0001 THEN 1 ELSE 0 END) nc FROM qa_scores s JOIN qa_criteria c ON c.id=s.criterion_id JOIN qa_evaluations v ON v.id=s.evaluation_id $join WHERE v.eval_date>=? AND v.eval_date<=? AND $w$extra GROUP BY c.label, v.eval_date, t.office", array_merge($base, $p, $ep)) as $r) {
            $k = self::key($r['d'], $gran); if (!isset($per_n[$k])) continue; $n = (int)$r['n']; $nc = (int)$r['nc'];
            $crit[$r['label']]['n'] = ($crit[$r['label']]['n'] ?? 0) + $n; $crit[$r['label']]['nc'] = ($crit[$r['label']]['nc'] ?? 0) + $nc; $tot['n'] += $n; $tot['nc'] += $nc;
            if (in_array($r['off'], ['FO', 'BO', 'SUP'], true)) { $ncO[$r['off']][$k]['n'] += $n; $ncO[$r['off']][$k]['nc'] += $nc; }
        }
        uasort($crit, fn($a, $b) => ($b['nc'] / max(1, $b['n'])) <=> ($a['nc'] / max(1, $a['n'])) ?: $b['nc'] <=> $a['nc']);
        // NC par conseiller et par période
        $empNc = [];
        foreach (DB::all("SELECT v.employee_id eid, v.eval_date d, SUM(CASE WHEN s.points < c.max_points - 0.0001 THEN 1 ELSE 0 END) nc FROM qa_scores s JOIN qa_criteria c ON c.id=s.criterion_id JOIN qa_evaluations v ON v.id=s.evaluation_id $join WHERE v.eval_date>=? AND v.eval_date<=? AND $w$extra GROUP BY v.employee_id, v.eval_date", array_merge($base, $p, $ep)) as $r) { $k = self::key($r['d'], $gran); if (isset($per_n[$k])) $empNc[$r['eid']][$k] = ($empNc[$r['eid']][$k] ?? 0) + (int)$r['nc']; }
        $empAvg = []; foreach ($emp as $eid => $byP) { $sum = 0; $n = 0; foreach ($byP as $a) { $sum += $a['sum']; $n += $a['n']; } $empAvg[$eid] = $sum / $n; }
        asort($empAvg);
        $all = array_sum($per_n);
        return ['per' => $per, 'pk' => $pk, 'n' => $per_n, 'n100' => $per_100, 'avg' => $avg, 'team' => $teamAvg, 'teamN' => $team, 'cc' => $cc, 'lv1' => $lv1, 'coach' => $coach,
            'crit' => $crit, 'ncO' => $ncO, 'tot' => $tot, 'emp' => $emp, 'empNc' => $empNc, 'empAvg' => $empAvg, 'names' => $names,
            'all' => ['n' => $all, 'avg' => $all ? array_sum($per_sum) / $all : null, 'n100' => array_sum($per_100), 'cc' => count($emp), 'lv1' => count(array_filter($empAvg, fn($a) => $a >= self::target() - 0.005)), 'coach' => array_sum($coach)]];
    }
}
