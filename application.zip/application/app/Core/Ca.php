<?php
namespace App\Core;
/** Contrôle et audit de niveau 1 : calcul des résultats, périmètre, génération des actions correctives et des contrôles planifiés. */
class Ca {
    const ANS = ['ok' => 'Conforme', 'ko' => 'Non conforme', 'na' => 'Non applicable'];
    const CS = ['planned' => 'Planifié', 'in_progress' => 'En cours', 'completed' => 'Terminé', 'cancelled' => 'Annulé'];
    const RES = ['conform' => 'Conforme', 'non_conform' => 'Non conforme', 'critical' => 'Écart critique'];
    const RES_COLOR = ['conform' => 'success', 'non_conform' => 'warning', 'critical' => 'danger'];
    const AS = ['open' => 'À traiter', 'in_progress' => 'En cours', 'done' => 'À vérifier', 'verified' => 'Vérifiée', 'cancelled' => 'Annulée'];
    const AS_COLOR = ['open' => 'secondary', 'in_progress' => 'primary', 'done' => 'warning', 'verified' => 'success', 'cancelled' => 'dark'];
    const PRIO = ['normal' => 'Normale', 'high' => 'Élevée', 'critical' => 'Critique'];
    const FREQ = ['weekly' => 'Hebdomadaire', 'monthly' => 'Mensuelle', 'quarterly' => 'Trimestrielle'];
    const CHK = ['draft' => 'Brouillon', 'active' => 'Active', 'archived' => 'Archivée'];
    const OPEN_ACT = ['open', 'in_progress', 'done'];

    /** Utilisateurs actifs disposant d'un droit (l'administrateur les a tous). */
    static function usersWith(string $perm): array {
        return DB::all("SELECT DISTINCT u.id, u.name FROM users u JOIN user_roles ur ON ur.user_id=u.id JOIN roles r ON r.id=ur.role_id LEFT JOIN role_permissions rp ON rp.role_id=r.id LEFT JOIN permissions p ON p.id=rp.permission_id WHERE u.status='active' AND (r.code='admin' OR p.code=?) ORDER BY u.name", [$perm]);
    }
    static function ref(string $prefix, string $table): string {
        $p = $prefix . '-' . date('y') . '-'; $last = DB::val("SELECT reference FROM $table WHERE reference LIKE ? ORDER BY id DESC LIMIT 1", [$p . '%']);
        return $p . str_pad((string)(($last ? (int)substr($last, strlen($p)) : 0) + 1), 5, '0', STR_PAD_LEFT);
    }
    static function setting(string $k, int $d): int { $v = (int)setting($k, $d); return $v > 0 && $v < 365 ? $v : $d; }
    /** Libellé du périmètre contrôlé. */
    static function subject(array $c): string {
        if (!empty($c['store_id'])) return (string)(DB::val('SELECT name FROM stores WHERE id=?', [(int)$c['store_id']]) ?: 'Store');
        if (!empty($c['team_id'])) return (string)(DB::val('SELECT name FROM teams WHERE id=?', [(int)$c['team_id']]) ?: 'Équipe');
        return 'Fonction support';
    }
    /**
     * Condition SQL restreignant les contrôles (alias $a) au périmètre de l'utilisateur : tous si « scope.all », sinon ceux qu'il réalise
     * et ceux dont le store ou l'équipe compte au moins un collaborateur de sa ligne hiérarchique.
     * @return array{0:string,1:array}
     */
    static function scope(string $a = 'c'): array {
        $ids = Scope::ids(); if ($ids === null) return ['1=1', []];
        $me = Auth::id(); if (!$ids) return ["$a.controller_id=?", [$me]];
        $in = implode(',', array_fill(0, count($ids), '?'));
        return ["($a.controller_id=? OR $a.store_id IN (SELECT store_id FROM employees WHERE id IN ($in) AND store_id IS NOT NULL) OR $a.team_id IN (SELECT team_id FROM employees WHERE id IN ($in) AND team_id IS NOT NULL))", array_merge([$me], $ids, $ids)];
    }
    static function canSee(array $control): bool {
        [$w, $p] = self::scope('c'); return (bool)DB::val("SELECT 1 FROM ca_controls c WHERE c.id=? AND $w", array_merge([(int)$control['id']], $p));
    }
    /** Score pondéré (points conformes / points applicables) et résultat ; un point critique non conforme impose « Écart critique ». @return array{0:?float,1:string} */
    static function compute(int $controlId, int $passPct): array {
        $rows = DB::all('SELECT r.answer, i.weight, i.critical FROM ca_results r JOIN ca_items i ON i.id=r.item_id WHERE r.control_id=?', [$controlId]);
        $ok = 0; $tot = 0; $crit = false;
        foreach ($rows as $r) { if ($r['answer'] === 'na') continue; $w = max(1, (int)$r['weight']); $tot += $w; if ($r['answer'] === 'ok') $ok += $w; elseif ($r['critical']) $crit = true; }
        $score = $tot ? round($ok / $tot * 100, 2) : null;
        return [$score, $crit ? 'critical' : (($score === null || $score >= $passPct) ? 'conform' : 'non_conform')];
    }
    /** Crée une action corrective par point non conforme sans action ; échéance selon la gravité. @return int nombre d'actions créées */
    static function openActions(array $control, ?int $owner): int {
        $n = 0; $rows = DB::all("SELECT r.*, i.label, i.critical, i.section FROM ca_results r JOIN ca_items i ON i.id=r.item_id WHERE r.control_id=? AND r.answer='ko'", [(int)$control['id']]);
        foreach ($rows as $r) {
            if (DB::val('SELECT 1 FROM ca_actions WHERE control_id=? AND item_id=? AND status<>\'cancelled\'', [(int)$control['id'], (int)$r['item_id']])) continue;
            $days = $r['critical'] ? self::setting('ca_due_critical', 7) : self::setting('ca_due_days', 30);
            $id = DB::insert('ca_actions', ['reference' => self::ref('ACT', 'ca_actions'), 'control_id' => (int)$control['id'], 'item_id' => (int)$r['item_id'], 'title' => mb_substr('Corriger : ' . $r['label'], 0, 300),
                'description' => mb_substr(trim(($r['section'] ? $r['section'] . ' · ' : '') . self::subject($control) . ($r['comment'] ? ' — ' . $r['comment'] : '')), 0, 1000), 'priority' => $r['critical'] ? 'critical' : 'normal', 'owner_id' => $owner, 'due_date' => date('Y-m-d', strtotime("+$days days")), 'status' => 'open', 'created_by' => Auth::id(), 'created_at' => now()]);
            if ($owner) Notifier::send($owner, 'Action corrective à traiter', DB::val('SELECT reference FROM ca_actions WHERE id=?', [$id]) . ' · ' . $r['label'], '/ca/actions/' . $id);
            $n++;
        }
        return $n;
    }
    static function nextDate(string $from, string $freq): string { return date('Y-m-d', strtotime(['weekly' => '+7 days', 'monthly' => '+1 month', 'quarterly' => '+3 months'][$freq] ?? '+1 month', strtotime($from))); }
    /** Crée les contrôles dont la date est arrivée (plannings actifs) ; une seule occurrence en retard est créée, puis la date est avancée. @return int */
    static function generate(?string $today = null): int {
        $today = $today ?: date('Y-m-d'); $n = 0;
        foreach (DB::all("SELECT s.*, (SELECT a.id FROM ca_checklists a WHERE a.code=k.code AND a.status='active' ORDER BY a.version DESC LIMIT 1) active_id FROM ca_schedules s JOIN ca_checklists k ON k.id=s.checklist_id WHERE s.active=1 AND s.next_date<=?", [$today]) as $s) {
            if (!$s['active_id']) continue; // aucun référentiel actif pour ce code : le planning attend
            $cid = DB::insert('ca_controls', ['reference' => self::ref('CTL', 'ca_controls'), 'checklist_id' => (int)$s['active_id'], 'store_id' => $s['store_id'] ?: null, 'team_id' => $s['team_id'] ?: null, 'controller_id' => (int)$s['controller_id'], 'planned_date' => $s['next_date'], 'status' => 'planned', 'schedule_id' => (int)$s['id'], 'created_by' => null, 'created_at' => now()]);
            $next = self::nextDate($s['next_date'], $s['frequency']); while ($next <= $today) $next = self::nextDate($next, $s['frequency']);
            DB::update('ca_schedules', ['next_date' => $next], 'id=?', [(int)$s['id']]);
            Notifier::send((int)$s['controller_id'], 'Contrôle à réaliser', DB::val('SELECT reference FROM ca_controls WHERE id=?', [$cid]) . ' · ' . self::subject($s) . ' · prévu le ' . d($s['next_date']), '/ca/controls/' . $cid); $n++;
        }
        return $n;
    }
}
