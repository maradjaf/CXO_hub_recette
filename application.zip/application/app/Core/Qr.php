<?php
namespace App\Core;

/** Générateur de QR code en PHP pur (mode octets, correction d'erreur M, versions 1 à 10 ≈ 213 octets). Aucune dépendance. */
class Qr {
    // version => [mots de code totaux, mots de correction par bloc, [[nb blocs, mots de données]…]]
    private const V = [1 => [26, 10, [[1, 16]]], 2 => [44, 16, [[1, 28]]], 3 => [70, 26, [[1, 44]]], 4 => [100, 18, [[2, 32]]], 5 => [134, 24, [[2, 43]]], 6 => [172, 16, [[4, 27]]],
        7 => [196, 18, [[4, 31]]], 8 => [242, 22, [[2, 38], [2, 39]]], 9 => [292, 22, [[3, 36], [2, 37]]], 10 => [346, 26, [[4, 43], [1, 44]]]];
    private const ALIGN = [1 => [], 2 => [6, 18], 3 => [6, 22], 4 => [6, 26], 5 => [6, 30], 6 => [6, 34], 7 => [6, 22, 38], 8 => [6, 24, 42], 9 => [6, 26, 46], 10 => [6, 28, 50]];

    /** @return bool[][] matrice [ligne][colonne], true = module noir */
    static function matrix(string $text): array {
        $bytes = array_values(unpack('C*', $text) ?: []); $n = count($bytes); $ver = 0;
        foreach (self::V as $v => [$tot, $ec, $bl]) { $dc = 0; foreach ($bl as [$c, $k]) $dc += $c * $k; $need = 4 + ($v < 10 ? 8 : 16) + 8 * $n; if ($need <= 8 * $dc) { $ver = $v; break; } }
        if (!$ver) throw new \RuntimeException('Texte trop long pour le QR code.');
        [$tot, $ecLen, $blocks] = self::V[$ver]; $dc = 0; foreach ($blocks as [$c, $k]) $dc += $c * $k;
        $bits = ''; $put = function (int $v, int $len) use (&$bits) { $bits .= str_pad(decbin($v), $len, '0', STR_PAD_LEFT); };
        $put(4, 4); $put($n, $ver < 10 ? 8 : 16); foreach ($bytes as $b) $put($b, 8);
        $bits .= str_repeat('0', min(4, 8 * $dc - strlen($bits))); if (strlen($bits) % 8) $bits .= str_repeat('0', 8 - strlen($bits) % 8);
        $data = array_map('bindec', str_split($bits, 8)); for ($pad = 0xEC; count($data) < $dc; $pad ^= 0xEC ^ 0x11) $data[] = $pad;
        // blocs + correction d'erreur
        $div = self::divisor($ecLen); $dBlocks = []; $eBlocks = []; $o = 0;
        foreach ($blocks as [$c, $k]) for ($i = 0; $i < $c; $i++) { $d = array_slice($data, $o, $k); $o += $k; $dBlocks[] = $d; $eBlocks[] = self::remainder($d, $div); }
        $out = []; $maxD = max(array_map('count', $dBlocks));
        for ($i = 0; $i < $maxD; $i++) foreach ($dBlocks as $d) if (isset($d[$i])) $out[] = $d[$i];
        for ($i = 0; $i < $ecLen; $i++) foreach ($eBlocks as $e) $out[] = $e[$i];
        $size = 17 + 4 * $ver; $m = array_fill(0, $size, array_fill(0, $size, false)); $fn = $m;
        $set = function (int $x, int $y, bool $v) use (&$m, &$fn, $size) { if ($x >= 0 && $y >= 0 && $x < $size && $y < $size) { $m[$y][$x] = $v; $fn[$y][$x] = true; } };
        for ($i = 0; $i < $size; $i++) { $set(6, $i, $i % 2 === 0); $set($i, 6, $i % 2 === 0); }
        foreach ([[3, 3], [$size - 4, 3], [3, $size - 4]] as [$cx, $cy]) for ($dy = -4; $dy <= 4; $dy++) for ($dx = -4; $dx <= 4; $dx++) { $dist = max(abs($dx), abs($dy)); $set($cx + $dx, $cy + $dy, $dist !== 2 && $dist !== 4); }
        $al = self::ALIGN[$ver]; $last = count($al) - 1;
        foreach ($al as $i => $ax) foreach ($al as $j => $ay) { if (($i === 0 && $j === 0) || ($i === 0 && $j === $last) || ($i === $last && $j === 0)) continue; for ($dy = -2; $dy <= 2; $dy++) for ($dx = -2; $dx <= 2; $dx++) $set($ax + $dx, $ay + $dy, max(abs($dx), abs($dy)) !== 1); }
        self::format($set, $size, 0, 0); // réserve les zones de format
        if ($ver >= 7) { $rem = $ver; for ($i = 0; $i < 12; $i++) $rem = ($rem << 1) ^ (($rem >> 11) * 0x1F25); $vb = ($ver << 12) | $rem;
            for ($i = 0; $i < 18; $i++) { $bit = (($vb >> $i) & 1) === 1; $a = $size - 11 + $i % 3; $b = intdiv($i, 3); $set($a, $b, $bit); $set($b, $a, $bit); } }
        // placement des données en zigzag
        $i = 0; $nbits = count($out) * 8;
        for ($right = $size - 1; $right >= 1; $right -= 2) { if ($right === 6) $right = 5;
            for ($vert = 0; $vert < $size; $vert++) for ($j = 0; $j < 2; $j++) { $x = $right - $j; $up = (($right + 1) & 2) === 0; $y = $up ? $size - 1 - $vert : $vert;
                if (!$fn[$y][$x] && $i < $nbits) { $m[$y][$x] = (($out[$i >> 3] >> (7 - ($i & 7))) & 1) === 1; $i++; } } }
        // choix du masque
        $best = null; $bestP = PHP_INT_MAX;
        for ($mask = 0; $mask < 8; $mask++) {
            $t = $m; for ($y = 0; $y < $size; $y++) for ($x = 0; $x < $size; $x++) if (!$fn[$y][$x] && self::masked($mask, $x, $y)) $t[$y][$x] = !$t[$y][$x];
            $f2 = $fn; $set2 = function (int $x, int $y, bool $v) use (&$t, &$f2, $size) { if ($x >= 0 && $y >= 0 && $x < $size && $y < $size) { $t[$y][$x] = $v; $f2[$y][$x] = true; } };
            self::format($set2, $size, $mask, 1); $p = self::penalty($t, $size); if ($p < $bestP) { $bestP = $p; $best = $t; }
        }
        return $best;
    }
    private static function masked(int $k, int $x, int $y): bool {
        switch ($k) { case 0: return ($x + $y) % 2 === 0; case 1: return $y % 2 === 0; case 2: return $x % 3 === 0; case 3: return ($x + $y) % 3 === 0; case 4: return (intdiv($x, 3) + intdiv($y, 2)) % 2 === 0;
            case 5: return $x * $y % 2 + $x * $y % 3 === 0; case 6: return ($x * $y % 2 + $x * $y % 3) % 2 === 0; default: return (($x + $y) % 2 + $x * $y % 3) % 2 === 0; }
    }
    /** Bits de format (niveau M = 0) et module sombre. $real = 0 : simple réservation. */
    private static function format(callable $set, int $size, int $mask, int $real): void {
        $data = (0 << 3) | $mask; $rem = $data; for ($i = 0; $i < 10; $i++) $rem = ($rem << 1) ^ (($rem >> 9) * 0x537); $bits = (($data << 10) | $rem) ^ 0x5412;
        $b = fn(int $i) => $real ? ((($bits >> $i) & 1) === 1) : false;
        for ($i = 0; $i <= 5; $i++) $set(8, $i, $b($i)); $set(8, 7, $b(6)); $set(8, 8, $b(7)); $set(7, 8, $b(8)); for ($i = 9; $i < 15; $i++) $set(14 - $i, 8, $b($i));
        for ($i = 0; $i < 8; $i++) $set($size - 1 - $i, 8, $b($i)); for ($i = 8; $i < 15; $i++) $set(8, $size - 15 + $i, $b($i)); $set(8, $size - 8, true);
    }
    private static function penalty(array $t, int $size): int {
        $p = 0; $dark = 0;
        for ($pass = 0; $pass < 2; $pass++) for ($a = 0; $a < $size; $a++) {
            $run = 1; $line = ''; for ($c = 0; $c < $size; $c++) { $v = $pass ? $t[$c][$a] : $t[$a][$c]; $line .= $v ? '1' : '0'; if ($c > 0) { $pv = $pass ? $t[$c - 1][$a] : $t[$a][$c - 1]; if ($v === $pv) { $run++; if ($run === 5) $p += 3; elseif ($run > 5) $p++; } else $run = 1; } if (!$pass && $v) $dark++; }
            $p += 40 * (substr_count($line, '10111010000') + substr_count($line, '00001011101'));
        }
        for ($y = 0; $y < $size - 1; $y++) for ($x = 0; $x < $size - 1; $x++) { $v = $t[$y][$x]; if ($v === $t[$y][$x + 1] && $v === $t[$y + 1][$x] && $v === $t[$y + 1][$x + 1]) $p += 3; }
        $total = $size * $size; $k = (int)ceil(abs($dark * 20 - $total * 10) / $total) - 1; return $p + max(0, $k) * 10;
    }
    private static function mul(int $x, int $y): int { $z = 0; for ($i = 7; $i >= 0; $i--) { $z = ($z << 1) ^ (($z >> 7) * 0x11D); $z ^= (($y >> $i) & 1) * $x; } return $z & 0xFF; }
    private static function divisor(int $deg): array {
        $r = array_fill(0, $deg, 0); $r[$deg - 1] = 1; $root = 1;
        for ($i = 0; $i < $deg; $i++) { for ($j = 0; $j < $deg; $j++) { $r[$j] = self::mul($r[$j], $root); if ($j + 1 < $deg) $r[$j] ^= $r[$j + 1]; } $root = self::mul($root, 2); }
        return $r;
    }
    private static function remainder(array $data, array $div): array {
        $r = array_fill(0, count($div), 0);
        foreach ($data as $b) { $f = $b ^ array_shift($r); $r[] = 0; foreach ($div as $i => $c) $r[$i] ^= self::mul($c, $f); }
        return $r;
    }
    /** SVG autonome (zone de silence de 4 modules incluse). */
    static function svg(string $text, int $px = 160): string {
        $m = self::matrix($text); $n = count($m); $q = 4; $s = '';
        foreach ($m as $y => $row) { $x = 0; while ($x < $n) { if ($row[$x]) { $w = 1; while ($x + $w < $n && $row[$x + $w]) $w++; $s .= 'M' . ($x + $q) . ',' . ($y + $q) . 'h' . $w . 'v1h-' . $w . 'z'; $x += $w; } else $x++; } }
        $t = $n + 2 * $q; return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $t . ' ' . $t . '" width="' . $px . '" height="' . $px . '" role="img" aria-label="QR code de vérification" shape-rendering="crispEdges"><rect width="' . $t . '" height="' . $t . '" fill="#fff"/><path d="' . $s . '" fill="#000"/></svg>';
    }
    /** Dessine le QR dans un PDF (coin bas-gauche en $x,$y, côté $side). */
    static function pdf(Pdf $p, string $text, float $x, float $y, float $side): void {
        $m = self::matrix($text); $n = count($m); $u = $side / ($n + 8); $p->rect($x, $y, $side, $side, 'FFFFFF');
        foreach ($m as $r => $row) foreach ($row as $c => $v) if ($v) $p->rect(round($x + ($c + 4) * $u, 3), round($y + $side - ($r + 5) * $u, 3), round($u + 0.05, 3), round($u + 0.05, 3), '000000');
    }
}
