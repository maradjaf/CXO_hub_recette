<?php
namespace App\Core;

/**
 * Lot 60 — Franchises : état mensuel SND (totaux par franchise et service, comparaison à une période de référence, données manquantes, écarts expliqués),
 * versions conservées, validation par le back-office, exports Excel et PDF. Aucune donnée client n'est portée par l'état agrégé.
 */
final class FrReport {
    const BASIS = ['reprise' => 'Reprise historique (lignes de la Restitution)', 'crm' => 'CRM (opérations confirmées)'];
    const ST = ['draft' => 'Brouillon', 'validated' => 'Validée', 'superseded' => 'Remplacée'];
    const ST_C = ['draft' => 'warning', 'validated' => 'success', 'superseded' => 'secondary'];

    static function bounds(string $ym): array { return [$ym . '-01', date('Y-m-t', strtotime($ym . '-01'))]; }
    static function ymOk($v): bool { return is_string($v) && preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $v) === 1; }
    static function label(string $ym): string { return FrStats::MONTHS[(int)substr($ym, 5, 2) - 1] . ' ' . substr($ym, 0, 4); }

    /** Totaux franchise × service sur une plage, selon la base retenue. @return array<int,array<string,int>> */
    private static function counts(string $basis, string $from, string $to): array {
        $o = [];
        if ($basis === 'crm') $q = DB::all("SELECT franchise_id fid, service, COUNT(*) n FROM fr_ops WHERE counted=1 AND result='ok' AND day>=? AND day<=? GROUP BY franchise_id, service", [$from, $to]);
        else $q = DB::all("SELECT franchise_id fid, service, COUNT(*) n FROM fr_src WHERE source='RESTITUTION' AND franchise_id IS NOT NULL AND service IS NOT NULL AND day>=? AND day<=? GROUP BY franchise_id, service", [$from, $to]);
        foreach ($q as $r) $o[(int)$r['fid']][(string)$r['service']] = (int)$r['n']; return $o;
    }
    /** Construit l'instantané des données de l'état. */
    static function build(string $ym, string $basis, ?string $ref): array {
        [$from, $to] = self::bounds($ym); $cur = self::counts($basis, $from, $to); $refc = $ref ? self::counts($basis, ...self::bounds($ref)) : []; $svcT = [];
        foreach ($cur as $row) foreach ($row as $s => $n) $svcT[$s] = ($svcT[$s] ?? 0) + $n; arsort($svcT); $services = array_keys($svcT); $rows = []; $tot = 0; $refTot = 0;
        $fr = DB::all('SELECT id, crm_id, code, name FROM fr_franchises ORDER BY name');
        foreach ($fr as $f) { $id = (int)$f['id']; $c = $cur[$id] ?? []; $r = array_sum($refc[$id] ?? []); $t = array_sum($c); if (!$t && !$r && !(int)DB::val('SELECT active FROM fr_franchises WHERE id=?', [$id])) continue;
            $rows[] = ['fid' => $id, 'code' => (string)($f['code'] ?? $f['crm_id']), 'name' => $f['name'], 'zone' => (string)Fr::zoneAt($id, $to), 'svc' => $c, 'total' => $t, 'ref' => $ref ? $r : null, 'diff' => $ref ? $t - $r : null, 'rel' => $ref && $r > 0 ? round(($t - $r) / $r * 100, 2) : null]; $tot += $t; $refTot += $r; }
        $missing = ['days' => [], 'franchises' => []]; $have = []; $q = $basis === 'crm' ? DB::all('SELECT DISTINCT day d FROM fr_ops WHERE day>=? AND day<=?', [$from, $to]) : DB::all("SELECT DISTINCT day d FROM fr_src WHERE source='RESTITUTION' AND day>=? AND day<=?", [$from, $to]);
        foreach ($q as $r) $have[$r['d']] = 1; for ($d = $from; $d <= $to; $d = Fr::addDays($d, 1)) if (Fr::isWork($d) && !isset($have[$d])) $missing['days'][] = $d;
        foreach ($rows as $r) if ($r['total'] === 0) $missing['franchises'][] = $r['name'];
        $noFr = $basis === 'crm' ? 0 : (int)DB::val("SELECT COUNT(*) FROM fr_src WHERE source='RESTITUTION' AND franchise_id IS NULL AND day>=? AND day<=?", [$from, $to]);
        $recon = null; if ($basis === 'reprise' && (int)DB::val("SELECT COUNT(*) FROM fr_src WHERE source='TRAITEMENT' AND day>=? AND day<=?", [$from, $to])) { $recon = FrImport::reconcile($from, $to, false); $recon['cells'] = array_slice($recon['cells'], 0, 200); }
        $cov = FrStats::coverage($basis === 'crm' ? 'ops' : 'rest');
        return ['meta' => ['period' => $ym, 'from' => $from, 'to' => $to, 'basis' => $basis, 'ref' => $ref, 'unit' => $basis === 'crm' ? 'opérations' : 'lignes', 'fresh' => $cov['to'], 'cov_from' => $cov['from'], 'calendar_validated' => Fr::setting('fr.calendar_validated', '0') === '1', 'workdays' => Fr::workDaysBetween($from, $to), 'days' => Fr::daysBetween($from, $to)],
            'services' => $services, 'svc_totals' => $svcT, 'rows' => $rows, 'total' => $tot, 'ref_total' => $ref ? $refTot : null, 'missing' => $missing, 'unassigned' => $noFr, 'recon' => $recon, 'blockers' => FrImport::blockers($basis)];
    }
    /** Enregistre une nouvelle version (brouillon). */
    static function generate(string $ym, string $basis, ?string $ref, string $why = ''): int {
        $data = self::build($ym, $basis, $ref); $v = (int)DB::val('SELECT COALESCE(MAX(version),0) FROM fr_reports WHERE period=?', [$ym]) + 1;
        $id = DB::insert('fr_reports', ['period' => $ym, 'version' => $v, 'status' => 'draft', 'basis' => $basis, 'ref_period' => $ref, 'filters' => json_encode(['périmètre' => 'Réseau complet', 'base' => self::BASIS[$basis], 'référence' => $ref], JSON_UNESCAPED_UNICODE), 'data' => json_encode($data, JSON_UNESCAPED_UNICODE), 'total' => $data['total'], 'generated_at' => now(), 'generated_by' => Auth::id(), 'is_demo' => Fr::$system ? 1 : 0]);
        self::log($id, $v > 1 ? 'correct' : 'generate', ($v > 1 ? 'Nouvelle version' : 'Première version') . ' v' . $v . ($why !== '' ? ' — ' . $why : '')); return $id;
    }
    static function log(int $id, string $action, string $detail): void { DB::insert('fr_report_log', ['report_id' => $id, 'at' => now(), 'user_id' => Auth::id(), 'action' => $action, 'detail' => mb_substr($detail, 0, 500)]); }
    /** Valide une version : exige règles et dictionnaire validés, et une justification si un écart résiduel subsiste. @return ?string erreur */
    static function validate(int $id, string $justification): ?string {
        $r = DB::one('SELECT * FROM fr_reports WHERE id=?', [$id]); if (!$r) return 'Version introuvable.'; if ($r['status'] !== 'draft') return 'Seul un brouillon peut être validé.';
        $d = json_decode((string)$r['data'], true) ?: []; $b = FrImport::blockers($r['basis']); if ($b) return 'Validation impossible : ' . implode(' ; ', array_slice($b, 0, 3)) . (count($b) > 3 ? ' (+' . (count($b) - 3) . ')' : '') . '.';
        $res = (int)($d['recon']['residual'] ?? 0); if ($res !== 0 && trim($justification) === '') return "Un écart résiduel de $res ligne(s) n'est pas expliqué : saisissez une justification pour valider.";
        DB::exec("UPDATE fr_reports SET status='superseded' WHERE period=? AND status='validated'", [$r['period']]);
        if ($res !== 0) { $d['justification'] = trim($justification); DB::update('fr_reports', ['data' => json_encode($d, JSON_UNESCAPED_UNICODE)], 'id=?', [$id]); }
        DB::update('fr_reports', ['status' => 'validated', 'validated_at' => now(), 'validated_by' => Auth::id()], 'id=?', [$id]); self::log($id, 'validate', 'Version v' . $r['version'] . ' validée pour la SND' . ($res !== 0 ? ' (écart résiduel justifié : ' . $res . ')' : ''));
        Audit::log('fr.report.validate', 'fr_reports', $id, null, ['période' => $r['period'], 'version' => $r['version']]); return null;
    }
    static function stamp(array $r): string { return 'Version v' . $r['version'] . ' · ' . self::ST[$r['status']] . ($r['validated_at'] ? ' le ' . dt($r['validated_at']) : '') . ' · générée le ' . dt($r['generated_at']); }

    // ───────────────────────── Exports ─────────────────────────
    private static function pr(?float $v): string { return $v === null ? 'n/d' : (($v > 0 ? '+' : '') . number_format($v, 1, ',', ' ') . ' %'); }
    static function xlsx(array $r): string {
        $d = json_decode((string)$r['data'], true) ?: []; $m = $d['meta'] ?? []; $svc = $d['services'] ?? []; $u = $m['unit'] ?? 'lignes';
        $info = [['État mensuel SND — franchises Yas Togo'], ['Période', self::label($r['period']) . ' (' . d($m['from'] ?? null) . ' au ' . d($m['to'] ?? null) . ', dates inclusives, heure locale Togo)'], ['Version', self::stamp($r)], ['Source', self::BASIS[$r['basis']] ?? $r['basis']],
            ['Dernière actualisation des données', isset($m['fresh']) ? d($m['fresh']) : 'inconnue'], ['Couverture', ($m['cov_from'] ?? null) ? 'du ' . d($m['cov_from']) . ' au ' . d($m['fresh'] ?? null) : 'aucune donnée'], ['Filtres', 'Réseau complet · tous services · ' . ($r['ref_period'] ? 'référence : ' . self::label($r['ref_period']) : 'sans période de référence')],
            ['Unité', "Nombre de $u"], ['Jours calendaires / ouvrés', ($m['days'] ?? '') . ' / ' . ($m['workdays'] ?? '') . ($m['calendar_validated'] ?? false ? ' (calendrier validé)' : ' (calendrier à valider)')], ['Total', $d['total'] ?? 0], ['Données client', 'Aucune : numéros clients, ICCID et pièces sont exclus de cet état.']];
        if (!empty($d['justification'])) $info[] = ['Justification de l\'écart résiduel', $d['justification']];
        $head = array_merge(['Code', 'Franchise', 'Zone (à la fin de période)'], $svc, ['Total', $r['ref_period'] ? 'Référence ' . self::label($r['ref_period']) : 'Référence', 'Écart', 'Variation relative']); $rows = [$head];
        foreach ($d['rows'] ?? [] as $x) { $line = [$x['code'], $x['name'], $x['zone']]; foreach ($svc as $s) $line[] = (int)($x['svc'][$s] ?? 0); $line[] = (int)$x['total']; $line[] = $x['ref']; $line[] = $x['diff']; $line[] = $x['rel'] === null ? ($x['ref'] === null ? '' : 'n/d') : $x['rel'] / 100; $rows[] = $line; }
        $tl = ['', 'TOTAL RÉSEAU', '']; foreach ($svc as $s) $tl[] = (int)($d['svc_totals'][$s] ?? 0); $tl[] = (int)($d['total'] ?? 0); $tl[] = $d['ref_total']; $tl[] = $d['ref_total'] === null ? null : (int)$d['total'] - (int)$d['ref_total']; $tl[] = ''; $rows[] = $tl;
        $miss = [['Type', 'Détail']]; foreach (($d['missing']['days'] ?? []) as $x) $miss[] = ['Jour ouvré sans donnée', d($x)]; foreach (($d['missing']['franchises'] ?? []) as $x) $miss[] = ['Franchise sans ligne sur la période', $x]; if (!empty($d['unassigned'])) $miss[] = ['Lignes sans franchise identifiée', (int)$d['unassigned']]; if (count($miss) === 1) $miss[] = ['Aucune donnée manquante signalée', ''];
        $sheets = ['Synthèse' => ['rows' => $info, 'widths' => [38, 90], 'head' => 1], 'Franchises x services' => ['rows' => $rows, 'widths' => array_merge([12, 30, 20], array_fill(0, count($svc) + 4, 16))], 'Données manquantes' => ['rows' => $miss, 'widths' => [40, 60]]];
        if (!empty($d['recon'])) { $c = $d['recon']; $rr = [['Étape', 'Lignes'], ['Lignes BOSS', $c['tot']['BOSS']], ['Lignes TRAITEMENT', $c['tot']['TRAITEMENT']], ['Lignes Restitution', $c['tot']['RESTITUTION']], ['Écart à expliquer (TRAITEMENT − Restitution)', $c['gap']]];
            foreach (FrImport::CATS as $k => $lab) $rr[] = ['  dont ' . $lab, $c['cats'][$k] ?? 0]; $rr[] = ['Total expliqué', $c['explained']]; $rr[] = ['Reliquat non expliqué', $c['residual']]; $rr[] = ['', '']; $rr[] = ['Cellules en écart', 'Jour · franchise · service · retenues · restitution · écart'];
            foreach ($c['cells'] as $x) $rr[] = [d($x['day']), (string)DB::val('SELECT name FROM fr_franchises WHERE id=?', [$x['fid']]) . ' · ' . $x['service'], $x['retained'], $x['restitution'], $x['diff']]; $sheets['Rapprochement'] = ['rows' => $rr, 'widths' => [48, 50, 12, 12, 10]]; }
        return Xlsx::write($sheets);
    }
    static function pdf(array $r): string {
        $d = json_decode((string)$r['data'], true) ?: []; $m = $d['meta'] ?? []; $svc = $d['services'] ?? []; $u = $m['unit'] ?? 'lignes';
        $p = new PdfDoc(842, 595, 32, 'Yas Togo · CXO · État SND ' . $r['period'] . ' v' . $r['version'] . ' · ' . self::ST[$r['status']], 'Données agrégées : aucun numéro client, ICCID ni pièce d\'identité');
        $p->title('État mensuel SND — franchises · ' . self::label($r['period'])); $p->para(self::stamp($r), 9, '6B7C93');
        $p->table(['Élément', 'Valeur'], [['Période', d($m['from'] ?? null) . ' au ' . d($m['to'] ?? null) . ' (dates inclusives, heure locale Togo)'], ['Source', self::BASIS[$r['basis']] ?? $r['basis']], ['Dernière actualisation des données', isset($m['fresh']) ? d($m['fresh']) : 'inconnue'],
            ['Filtres', 'Réseau complet · tous services · ' . ($r['ref_period'] ? 'référence ' . self::label($r['ref_period']) : 'sans référence')], ['Jours calendaires / ouvrés', ($m['days'] ?? '') . ' / ' . ($m['workdays'] ?? '') . (($m['calendar_validated'] ?? false) ? '' : ' (calendrier à valider)')], ['Total ' . $u, Fr::n($d['total'] ?? 0) . ($d['ref_total'] !== null ? ' (référence ' . Fr::n($d['ref_total']) . ', écart ' . Fr::sgn((int)$d['total'] - (int)$d['ref_total']) . ')' : '')]], [1, 4]);
        $p->h2('Totaux par service'); $p->table(['Service', $u, 'Part'], array_map(fn($s) => [$s, Fr::n($d['svc_totals'][$s] ?? 0), Fr::dec(($d['total'] ?? 0) > 0 ? ($d['svc_totals'][$s] ?? 0) / $d['total'] * 100 : 0) . ' %'], $svc), [4, 1, 1], [1, 2]);
        $p->h2('Totaux par franchise et service'); $head = array_merge(['Code', 'Franchise'], $svc, ['Total', 'Réf.', 'Écart', 'Var.']); $rows = [];
        foreach ($d['rows'] ?? [] as $x) { $l = [$x['code'], $x['name']]; foreach ($svc as $s) $l[] = Fr::n($x['svc'][$s] ?? 0); $l[] = Fr::n($x['total']); $l[] = $x['ref'] === null ? '' : Fr::n($x['ref']); $l[] = $x['diff'] === null ? '' : Fr::sgn($x['diff']); $l[] = $x['ref'] === null ? '' : self::pr($x['rel']); $rows[] = $l; }
        $tl = ['', 'TOTAL RÉSEAU']; foreach ($svc as $s) $tl[] = Fr::n($d['svc_totals'][$s] ?? 0); $tl[] = Fr::n($d['total'] ?? 0); $tl[] = $d['ref_total'] === null ? '' : Fr::n($d['ref_total']); $tl[] = $d['ref_total'] === null ? '' : Fr::sgn((int)$d['total'] - (int)$d['ref_total']); $tl[] = ''; $rows[] = $tl;
        $p->table($head, $rows, array_merge([1.2, 3], array_fill(0, count($svc), 1.4), [1.2, 1.2, 1.1, 1.2]), range(2, count($head) - 1), true);
        $p->h2('Données manquantes'); $mm = []; foreach ($d['missing']['days'] ?? [] as $x) $mm[] = ['Jour ouvré sans donnée', d($x)]; foreach ($d['missing']['franchises'] ?? [] as $x) $mm[] = ['Franchise sans ligne', $x]; if (!empty($d['unassigned'])) $mm[] = ['Lignes sans franchise identifiée', Fr::n($d['unassigned'])]; if (!$mm) $mm[] = ['Aucune donnée manquante signalée', '']; $p->table(['Type', 'Détail'], $mm, [3, 5]);
        if (!empty($d['recon'])) { $c = $d['recon']; $p->h2('Rapprochement BOSS · TRAITEMENT · Restitution'); $rr = [['Lignes BOSS', Fr::n($c['tot']['BOSS'])], ['Lignes TRAITEMENT', Fr::n($c['tot']['TRAITEMENT'])], ['Lignes Restitution', Fr::n($c['tot']['RESTITUTION'])], ['Écart à expliquer', Fr::n($c['gap'])]];
            foreach (FrImport::CATS as $k => $lab) $rr[] = ['  dont ' . $lab, Fr::n($c['cats'][$k] ?? 0)]; $rr[] = ['Reliquat non expliqué', Fr::n($c['residual'])]; $p->table(['Étape', 'Lignes'], $rr, [5, 1], [1]); if (!empty($d['justification'])) $p->para('Justification de l\'écart résiduel : ' . $d['justification']); }
        if ($d['blockers'] ?? []) { $p->h2('Points à valider avant diffusion'); foreach ($d['blockers'] as $b) $p->para('• ' . $b, 8.5, 'B42318'); }
        return $p->output();
    }
}
