<?php
namespace App\Core;

/** Contenus riches (éditeur WYSIWYG) : assainissement par liste blanche, rendu, extraits. Tout HTML enregistré passe par clean(). */
class Html {
    const OK = ['p', 'br', 'strong', 'b', 'em', 'i', 'u', 's', 'strike', 'h2', 'h3', 'h4', 'ul', 'ol', 'li', 'blockquote', 'a', 'code', 'pre', 'hr', 'div', 'span', 'table', 'thead', 'tbody', 'tr', 'th', 'td'];
    const VOID = ['br', 'hr'];
    const DROP = ['script', 'style', 'iframe', 'object', 'embed', 'form', 'input', 'button', 'textarea', 'select', 'svg', 'math', 'link', 'meta', 'template', 'noscript', 'applet', 'frame', 'frameset', 'base', 'audio', 'video', 'img', 'canvas'];
    static function isHtml(?string $s): bool { return (bool)preg_match('/<(p|br|div|h[1-6]|ul|ol|li|strong|b|em|i|u|s|a|blockquote|pre|code|span|table|hr)(\s[^>]*)?\/?>/i', (string)$s); }
    static function clean(?string $html): string {
        $html = (string)$html; if (trim($html) === '') return '';
        $html = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $html);
        if (!self::isHtml($html)) return '<p>' . preg_replace("/\r?\n/", '<br>', htmlspecialchars(trim($html), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')) . '</p>';   // texte brut : paragraphe échappé
        $prev = libxml_use_internal_errors(true); $doc = new \DOMDocument('1.0', 'UTF-8');
        $doc->loadHTML('<?xml encoding="UTF-8"><body>' . $html . '</body>', LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_NONET); libxml_clear_errors(); libxml_use_internal_errors($prev);
        $body = $doc->getElementsByTagName('body')->item(0); if (!$body) return '';
        $out = ''; foreach ($body->childNodes as $n) $out .= self::walk($n);
        return trim($out);
    }
    private static function walk(\DOMNode $n): string {
        if ($n instanceof \DOMText) return htmlspecialchars($n->nodeValue, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        if (!($n instanceof \DOMElement)) return '';
        $t = strtolower($n->tagName); if (in_array($t, self::DROP, true)) return '';
        $in = ''; foreach ($n->childNodes as $c) $in .= self::walk($c);
        if (!in_array($t, self::OK, true)) return $in;
        if (in_array($t, self::VOID, true)) return "<$t>";
        if ($t === 'a') {
            $h = trim((string)$n->getAttribute('href')); $c = preg_replace('/[\x00-\x20]+/', '', $h);
            if ($c === '' || !preg_match('#^(https?://|mailto:|tel:|/)#i', $c)) return $in;
            return '<a href="' . htmlspecialchars($h, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '" target="_blank" rel="noopener noreferrer nofollow">' . $in . '</a>';
        }
        if (in_array($t, ['span', 'div'], true) && trim(strip_tags($in)) === '' && stripos($in, '<br') === false) return $in;
        return "<$t>$in</$t>";
    }
    /** Texte brut d'un contenu (extrait, recherche, vérification « vide »). */
    static function text(?string $s, int $max = 0): string {
        $s = (string)$s; if (self::isHtml($s)) $s = preg_replace('#<(br|/p|/div|/li|/h[2-4]|/tr|/blockquote)[^>]*>#i', ' ', $s);
        $t = trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags($s), ENT_QUOTES, 'UTF-8')));
        return $max && mb_strlen($t) > $max ? mb_substr($t, 0, $max) . '…' : $t;
    }
    /** HTML sûr à afficher : contenu riche assaini, ou texte brut historique converti en paragraphes. */
    static function render(?string $s): string { $s = (string)$s; return '<div class="rich">' . (self::isHtml($s) ? self::clean($s) : nl2br(htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'))) . '</div>'; }
    /** Valeur à injecter dans un champ d'édition : le texte brut historique devient du HTML. */
    static function forEditor(?string $s): string { $s = (string)$s; return self::isHtml($s) ? self::clean($s) : nl2br(htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')); }
}
