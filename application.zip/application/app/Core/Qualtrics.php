<?php
namespace App\Core;

/** Lot 68 : récupération des réponses d'une enquête Qualtrics (API v3, export de réponses) et import par les correspondances existantes. */
class Qualtrics {
    static function get(string $k): string { $v = (string)setting('qx.' . $k, ''); return $k === 'token' && $v !== '' ? Secret::dec($v) : $v; }
    static function base(): string { $b = rtrim(self::get('base'), '/'); if ($b !== '') return $b; $dc = self::get('datacenter'); return $dc !== '' ? 'https://' . $dc . '.qualtrics.com' : ''; }
    static function ready(): bool { return self::base() !== '' && self::get('token') !== ''; }
    private static function urlOk(string $u): bool { $x = parse_url($u); $s = strtolower($x['scheme'] ?? ''); return $s === 'https' || ($s === 'http' && in_array($x['host'] ?? '', ['127.0.0.1', 'localhost'], true)); }
    /** @return array{0:int,1:string,2:?string} statut HTTP, corps brut, erreur */
    static function http(string $method, string $path, $body = null): array {
        $url = self::base() . $path; if (!self::urlOk($url)) return [0, '', 'Adresse non autorisée (https requis).'];
        $c = curl_init($url); $h = ['X-API-TOKEN: ' . self::get('token'), 'Accept: application/json']; if ($body !== null) $h[] = 'Content-Type: application/json';
        curl_setopt_array($c, [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 60, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_HTTPHEADER => $h, CURLOPT_FOLLOWLOCATION => false]); if ($body !== null) curl_setopt($c, CURLOPT_POSTFIELDS, json_encode($body));
        $r = curl_exec($c); $st = (int)curl_getinfo($c, CURLINFO_HTTP_CODE); $err = $r === false ? curl_error($c) : null; curl_close($c); return [$st, (string)$r, $err];
    }
    private static function json(string $path, string $m = 'GET', $body = null): array {
        [$st, $b, $err] = self::http($m, $path, $body); $d = json_decode($b, true);
        if ($err || $st < 200 || $st >= 300 || !is_array($d)) throw new \RuntimeException('Qualtrics : ' . ($err ?: 'HTTP ' . ($st ?: 'aucune réponse') . (is_array($d) && !empty($d['meta']['error']['errorMessage']) ? ' — ' . $d['meta']['error']['errorMessage'] : '')));
        return $d['result'] ?? [];
    }
    static function test(): array { try { if (!self::ready()) return [false, 'Configuration incomplète.']; $r = self::json('/API/v3/whoami'); return [true, 'Connexion réussie' . (!empty($r['userName']) ? ' (' . $r['userName'] . ')' : '') . '.']; } catch (\Throwable $e) { return [false, $e->getMessage()]; } }
    /** Télécharge les réponses (depuis $since) sous forme de lignes à plat : colonnes = clés de « values » et « embeddedData » + responseId. */
    static function fetch(string $qid, ?string $since = null): array {
        $req = ['format' => 'json', 'useLabels' => false]; if ($since) $req['startDate'] = gmdate('Y-m-d\TH:i:s\Z', strtotime($since));
        $p = self::json('/API/v3/surveys/' . rawurlencode($qid) . '/export-responses', 'POST', $req); $pid = $p['progressId'] ?? null; if (!$pid) throw new \RuntimeException('Qualtrics : export non démarré.');
        for ($i = 0; $i < 30; $i++) { $s = self::json('/API/v3/surveys/' . rawurlencode($qid) . '/export-responses/' . rawurlencode($pid)); if (($s['status'] ?? '') === 'failed') throw new \RuntimeException('Qualtrics : export en échec.'); if (($s['status'] ?? '') === 'complete') break; usleep(300000 + $i * 100000); }
        if (empty($s['fileId'])) throw new \RuntimeException('Qualtrics : export trop long, réessayez plus tard.');
        [$st, $zip, $err] = self::http('GET', '/API/v3/surveys/' . rawurlencode($qid) . '/export-responses/' . rawurlencode($s['fileId']) . '/file'); if ($err || $st !== 200) throw new \RuntimeException('Qualtrics : téléchargement impossible (HTTP ' . $st . ').');
        $tmp = tempnam(sys_get_temp_dir(), 'qx'); file_put_contents($tmp, $zip); $za = new \ZipArchive(); if ($za->open($tmp) !== true || !$za->numFiles) { @unlink($tmp); throw new \RuntimeException('Qualtrics : archive illisible.'); }
        $j = json_decode((string)$za->getFromIndex(0), true); $za->close(); @unlink($tmp); $rows = []; $ln = 1;
        foreach ((array)($j['responses'] ?? []) as $r) { $ln++; $v = (array)($r['values'] ?? []); $row = ['responseid' => (string)($r['responseId'] ?? $v['_recordId'] ?? '')];
            foreach ($v + (array)($r['embeddedData'] ?? []) as $k => $x) if (is_scalar($x) || $x === null) $row[strtolower((string)$k)] = (string)$x; $rows[] = ['line' => $ln, 'data' => $row]; }
        return $rows;
    }
    /** Synchronise une source : import par la correspondance choisie, dans un lot consigné. */
    static function sync(array $src): string {
        try {
            $map = DB::one('SELECT * FROM sv_mappings WHERE id=?', [(int)$src['mapping_id']]); if (!$map) return 'Correspondance introuvable.'; if (!self::ready()) return 'Qualtrics non configuré.';
            $rows = self::fetch($src['qualtrics_id'], $src['last_sync'] ? date('Y-m-d H:i:s', strtotime($src['last_sync']) - 86400) : null);
            $label = 'Qualtrics « ' . $src['name'] . ' »'; $bid = DB::insert('sv_batches', ['kind' => 'results', 'name' => mb_substr($label, 0, 190), 'source' => 'qualtrics', 'mapping_id' => $map['id'], 'survey_id' => $src['survey_id'], 'dry_run' => 0, 'user_id' => Auth::id(), 'created_at' => now()]);
            $bil = Sv::import('results', $map, $rows, (int)$src['survey_id'], $bid, false, 'qualtrics:' . $src['id']);
            DB::update('sv_batches', ['total' => $bil['total'], 'created' => $bil['created'], 'updated' => $bil['updated'], 'rejected' => $bil['rejected'], 'report' => implode("\n", $bil['lines'])], 'id=?', [$bid]); Followup::scan();
            $msg = count($rows) . " réponse(s) lue(s) : {$bil['created']} créée(s), {$bil['updated']} mise(s) à jour, {$bil['rejected']} rejetée(s).";
        } catch (\Throwable $e) { $msg = $e->getMessage(); }
        DB::update('sv_qsources', ['last_sync' => now(), 'last_result' => mb_substr($msg, 0, 300)], 'id=?', [(int)$src['id']]); return $msg;
    }
}
