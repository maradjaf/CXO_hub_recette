<?php
namespace App\Core;
/** Données du tableau de bord du conseiller client : qualité, formations, tickets, congés, présence, absentéisme, tâches. */
final class AdvisorDash {
    /** @return array|null null si l'utilisateur n'est pas rattaché à une fiche collaborateur */
    static function load(int $uid, ?int $emp): array {
        $D = ['emp' => $emp, 'months' => []];
        for ($i = 5; $i >= 0; $i--) $D['months'][] = date('Y-m', strtotime(date('Y-m-01') . " -$i month"));
        $lab = fn(string $m) => date('m/y', strtotime("$m-01"));
        $D['mlab'] = array_map($lab, $D['months']);
        // Qualité : note moyenne mensuelle (12 mois) et objectif
        $D['qa'] = ['labels' => [], 'avg' => [], 'obj' => [], 'last' => null, 'prev' => null, 'n' => 0, 'obj_v' => Tr::obj('qa', 85)];
        if ($emp && can('qa.own')) {
            $by = []; foreach (DB::all('SELECT eval_date, score_pct FROM qa_evaluations WHERE employee_id=? AND eval_date>=? ORDER BY eval_date', [$emp, date('Y-m-01', strtotime('-11 months'))]) as $r) $by[substr($r['eval_date'], 0, 7)][] = (float)$r['score_pct'];
            for ($i = 11; $i >= 0; $i--) { $m = date('Y-m', strtotime(date('Y-m-01') . " -$i month")); $D['qa']['labels'][] = $lab($m); $v = isset($by[$m]) ? round(array_sum($by[$m]) / count($by[$m]), 1) : null; $D['qa']['avg'][] = $v; $D['qa']['obj'][] = $D['qa']['obj_v']; $D['qa']['n'] += count($by[$m] ?? []); }
            $vals = array_values(array_filter($D['qa']['avg'], fn($x) => $x !== null)); $D['qa']['last'] = $vals ? end($vals) : null; $D['qa']['prev'] = count($vals) > 1 ? $vals[count($vals) - 2] : null;
            $D['qa']['recent'] = DB::all('SELECT id, eval_date, score_pct, critical_fail FROM qa_evaluations WHERE employee_id=? ORDER BY eval_date DESC, id DESC LIMIT 5', [$emp]);
        }
        // Formations
        $c = ['assigned' => 0, 'in_progress' => 0, 'passed' => 0, 'failed' => 0]; foreach (DB::all('SELECT status, COUNT(*) n FROM el_enrollments WHERE user_id=? GROUP BY status', [$uid]) as $r) $c[$r['status']] = (int)$r['n'];
        $D['el'] = ['waiting' => $c['assigned'], 'followed' => $c['in_progress'] + $c['passed'] + $c['failed'], 'validated' => $c['passed'], 'closed' => $c['passed'] + $c['failed'], 'failed' => $c['failed'], 'raw' => $c,
            'todo' => DB::all("SELECT en.id, c.title, en.due_date, en.status FROM el_enrollments en JOIN el_courses c ON c.id=en.course_id WHERE en.user_id=? AND en.status IN ('assigned','in_progress') ORDER BY en.due_date IS NULL, en.due_date LIMIT 5", [$uid])];
        $mv = []; foreach (DB::all("SELECT completed_at FROM el_enrollments WHERE user_id=? AND status='passed' AND completed_at>=?", [$uid, $D['months'][0] . '-01']) as $r) $mv[substr($r['completed_at'], 0, 7)] = ($mv[substr($r['completed_at'], 0, 7)] ?? 0) + 1;
        $D['el']['by_month'] = array_map(fn($m) => $mv[$m] ?? 0, $D['months']);
        // Tickets créés
        $T = []; foreach (DB::all('SELECT status, COUNT(*) n FROM at_tickets WHERE requester_id=? GROUP BY status', [$uid]) as $r) $T[$r['status']] = (int)$r['n'];
        $tm = []; foreach (DB::all('SELECT created_at FROM at_tickets WHERE requester_id=? AND created_at>=?', [$uid, $D['months'][0] . '-01']) as $r) $tm[substr($r['created_at'], 0, 7)] = ($tm[substr($r['created_at'], 0, 7)] ?? 0) + 1;
        $D['tk'] = ['by_status' => $T, 'total' => array_sum($T), 'open' => array_sum(array_intersect_key($T, array_flip(['approval', 'new', 'assigned', 'in_progress', 'waiting']))), 'by_month' => array_map(fn($m) => $tm[$m] ?? 0, $D['months']),
            'recent' => DB::all('SELECT id, reference, title, status, created_at FROM at_tickets WHERE requester_id=? ORDER BY id DESC LIMIT 5', [$uid])];
        // Congés
        $D['leave'] = []; $D['leave_pending'] = 0; $D['leave_next'] = null;
        if ($emp) {
            foreach (DB::all('SELECT * FROM leave_types WHERE active=1 AND controlled=1 ORDER BY name') as $t) $D['leave'][] = ['name' => $t['name']] + \App\Controllers\LeaveController::balance($emp, $t, (int)date('Y'));
            $D['leave_pending'] = (int)DB::val("SELECT COUNT(*) FROM leave_requests WHERE employee_id=? AND status='pending'", [$emp]);
            $D['leave_next'] = DB::one("SELECT start_date, end_date, days FROM leave_requests WHERE employee_id=? AND status='approved' AND end_date>=? ORDER BY start_date LIMIT 1", [$emp, date('Y-m-d')]);
        }
        // Présence (30 derniers jours) et absentéisme (mois en cours, année)
        $P = []; $D['abs'] = ['month_days' => 0.0, 'year_days' => 0.0, 'rate' => null, 'by_month' => array_fill(0, 6, 0.0)];
        if ($emp) {
            foreach (DB::all('SELECT day_status, COUNT(*) n FROM att_days WHERE employee_id=? AND day>=? AND day<=? GROUP BY day_status', [$emp, date('Y-m-d', strtotime('-29 days')), date('Y-m-d')]) as $r) $P[$r['day_status']] = (int)$r['n'];
            $a0 = date('Y-m-01'); $a1 = date('Y-m-t');
            $D['abs']['month_days'] = (float)DB::val('SELECT COALESCE(SUM(days),0) FROM absences WHERE employee_id=? AND start_date<=? AND end_date>=?', [$emp, $a1, $a0]);
            $D['abs']['year_days'] = (float)DB::val('SELECT COALESCE(SUM(days),0) FROM absences WHERE employee_id=? AND start_date>=? AND start_date<=?', [$emp, date('Y-01-01'), date('Y-12-31')]);
            $wd = \App\Controllers\LeaveController::workingDays($a0, date('Y-m-d')); $D['abs']['rate'] = $wd ? round(100 * min($wd, $D['abs']['month_days']) / $wd, 1) : null;
            $am = []; foreach (DB::all('SELECT start_date, days FROM absences WHERE employee_id=? AND start_date>=?', [$emp, $D['months'][0] . '-01']) as $r) $am[substr($r['start_date'], 0, 7)] = ($am[substr($r['start_date'], 0, 7)] ?? 0) + (float)$r['days'];
            $D['abs']['by_month'] = array_map(fn($m) => $am[$m] ?? 0, $D['months']);
        }
        $okDays = ($P['on_time'] ?? 0) + ($P['present'] ?? 0) + ($P['late'] ?? 0) + ($P['early_leave'] ?? 0); $tot = $okDays + ($P['absent'] ?? 0) + ($P['incomplete'] ?? 0);
        $D['att'] = ['by_status' => $P, 'rate' => $tot ? round(100 * $okDays / $tot, 1) : null, 'late' => (int)($P['late'] ?? 0), 'absent' => (int)($P['absent'] ?? 0)];
        // Tâches assignées
        $K = []; foreach (DB::all("SELECT status, COUNT(*) n FROM pk_tasks WHERE assignee_id=? AND deleted_at IS NULL GROUP BY status", [$uid]) as $r) $K[$r['status']] = (int)$r['n'];
        $D['tasks'] = ['by_status' => $K, 'open' => ($K['open'] ?? 0) + ($K['in_progress'] ?? 0), 'late' => (int)DB::val("SELECT COUNT(*) FROM pk_tasks WHERE assignee_id=? AND deleted_at IS NULL AND status IN ('open','in_progress') AND due_date<?", [$uid, date('Y-m-d')]),
            'next' => DB::all("SELECT id, title, due_date, status, priority FROM pk_tasks WHERE assignee_id=? AND deleted_at IS NULL AND status IN ('open','in_progress') ORDER BY due_date LIMIT 5", [$uid])];
        return $D;
    }
}
