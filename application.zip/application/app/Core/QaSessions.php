<?php
namespace App\Core;
/** Coachings qualité et débriefings d'activité : table, report, journal, commentaires et rappels J-3 / J-1. */
class QaSessions {
    const TABLE = ['coaching' => 'qa_coachings', 'debrief' => 'qa_debriefs'];
    const ST = ['planned' => ['Programmé', 'primary'], 'postponed' => ['Reporté', 'warning'], 'done' => ['Fait', 'success'], 'cancelled' => ['Annulé', 'secondary']];
    static function t(string $kind): string { return self::TABLE[$kind]; }
    /** Date/heure postée (champs date + heure) → "Y-m-d H:i:00" ou null. */
    static function when(?string $d, ?string $h): ?string {
        if (!$d || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) || !strtotime($d)) return null;
        $h = $h && preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $h) ? $h : '09:00'; return "$d $h:00";
    }
    static function userOfEmployee(?int $empId): ?int { if (!$empId) return null; $u = DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [$empId]); return $u ? (int)$u : null; }
    static function log(string $kind, int $id, string $action, ?string $old, ?string $new, ?string $reason): void {
        DB::insert('qa_session_log', ['kind' => $kind, 'ref_id' => $id, 'action' => $action, 'old_at' => $old, 'new_at' => $new, 'reason' => $reason, 'user_id' => Auth::id(), 'created_at' => now()]);
    }
    /** Reporte et reprogramme : l'ancienne date reste dans le journal, les rappels sont réarmés. */
    static function postpone(string $kind, array $row, string $newAt, string $reason): void {
        DB::update(self::t($kind), ['planned_at' => $newAt, 'status' => 'postponed', 'remind3_at' => null, 'remind1_at' => null], 'id=?', [(int)$row['id']]);
        self::log($kind, (int)$row['id'], 'postpone', $row['planned_at'], $newAt, $reason);
    }
    /** Destinataires d'une séance : coach, collaborateur + N+1 (coaching) ; coach, responsable d'équipe, qualité (débriefing). */
    static function recipients(string $kind, array $row): array {
        $r = [(int)$row['coach_user_id']];
        if ($kind === 'coaching') { $r[] = self::userOfEmployee((int)$row['employee_id']); $m = DB::val('SELECT manager_id FROM employees WHERE id=?', [(int)$row['employee_id']]); $r[] = self::userOfEmployee($m ? (int)$m : null); }
        else { if ($row['team_id']) $r[] = self::userOfEmployee((int)DB::val('SELECT lead_employee_id FROM teams WHERE id=?', [(int)$row['team_id']]) ?: null); foreach (Ca::usersWith('qa.manage') as $u) $r[] = (int)$u['id']; if (($row['audience'] ?? 'quality') === 'team' && $row['team_id']) $r = array_merge($r, self::teamUsers((int)$row['team_id'])); }
        return array_values(array_unique(array_filter(array_map('intval', $r))));
    }
    /** Notification dans l'application et, si l'envoi est configuré, copie par e-mail (sauf $mail=false : l'e-mail est alors l'invitation .ics). */
    static function tell(int $userId, string $title, string $body, string $url, bool $mail = true): void {
        Notifier::send($userId, $title, $body, $url);
        if (!$mail || !Mailer::enabled()) return;
        $u = DB::one("SELECT email, name FROM users WHERE id=? AND status='active'", [$userId]); if (!$u) return;
        $link = (string)env('APP_URL', '') !== '' ? "\n\nVoir dans l'application : " . rtrim((string)env('APP_URL'), '/') . $url : '';
        Mailer::queue($u['email'], $title, "Bonjour {$u['name']},\n\n$title\n" . ($body !== '' ? "$body\n" : '') . $link . "\n\nMessage automatique du Contrôle qualité.");
    }
    /** Membres de l'équipe disposant d'un compte actif (diffusion « toute l'équipe »). */
    static function teamUsers(int $teamId): array {
        return array_map('intval', array_column(DB::all("SELECT u.id FROM users u JOIN employees e ON e.id=u.employee_id WHERE e.team_id=? AND e.status<>'left' AND u.status='active'", [$teamId]), 'id'));
    }
    static function label(string $kind, array $row): string {
        return $kind === 'coaching' ? 'Coaching qualité · ' . $row['topic'] : 'Débriefing d\'activité · ' . $row['title'];
    }
    /** Rappels à J-3 et J-1 (une fois chacun, réarmés après un report) ; une séance créée trop tard ne reçoit pas de rappel rétroactif. Alerte au coach pour toute séance passée non clôturée. */
    static function sendReminders(): int {
        $n = 0; $today = date('Y-m-d');
        foreach (['coaching', 'debrief'] as $kind) {
            $url = '/qa/' . ($kind === 'coaching' ? 'coachings' : 'debriefs') . '/';
            foreach (DB::all('SELECT * FROM ' . self::t($kind) . " WHERE status IN ('planned','postponed')") as $row) {
                $days = (int)round((strtotime(substr($row['planned_at'], 0, 10)) - strtotime($today)) / 86400); $upd = [];
                if ($days < 0) {
                    $title = 'Séance non clôturée · ' . self::label($kind, $row);
                    if (!DB::val('SELECT 1 FROM notifications WHERE user_id=? AND title=? AND created_at>=?', [(int)$row['coach_user_id'], $title, $today . ' 00:00:00'])) { self::tell((int)$row['coach_user_id'], $title, 'Prévue le ' . dt($row['planned_at']) . ' : renseignez le compte rendu ou reportez-la.', $url . $row['id']); $n++; }
                    continue;
                }
                foreach ([['remind3_at', 3, 'J-3'], ['remind1_at', 1, 'J-1']] as [$col, $d, $tag]) {
                    if ($row[$col] || $days > $d) continue;
                    $upd[$col] = now(); if ($days < $d - 1 && $d === 3) continue;       // J-3 manqué : on n'envoie pas
                    foreach (self::recipients($kind, $row) as $u) { self::tell($u, "Rappel $tag · " . self::label($kind, $row), 'Prévu le ' . dt($row['planned_at']), $url . $row['id']); $n++; }
                }
                if ($upd) DB::update(self::t($kind), $upd, 'id=?', [(int)$row['id']]);
            }
        }
        return $n;
    }
    /** Filet de sécurité si la tâche planifiée ne tourne pas : au plus toutes les 6 h, après l'envoi de la réponse, on envoie les rappels puis la file d'e-mails. */
    static function lazyRun(): void {
        if (PHP_SAPI === 'cli' || Request::method() !== 'GET') return;
        $last = (int)strtotime((string)setting('qa.reminders_last', '2000-01-01')); if (time() - $last < 6 * 3600) return;
        Settings::set('qa.reminders_last', now());
        register_shutdown_function(function () {
            if (function_exists('fastcgi_finish_request')) @fastcgi_finish_request();
            try { if (self::sendReminders() && Mailer::enabled()) Mailer::flush(20); } catch (\Throwable $e) { /* le prochain passage réessaiera */ }
        });
    }
}
