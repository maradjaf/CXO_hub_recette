<?php
namespace App\Core;
/**
 * Historique d'activité (M06) : chaque requête authentifiée est enregistrée automatiquement à la fin de la réponse.
 * Jamais enregistrés : mots de passe, corps de formulaire, pièces jointes.
 */
class Activity {
    private static bool $skip = false;
    private static array $ctx = [];
    private static float $t0;
    const SENSITIVE = ['password', 'pass', 'pwd', 'token', '_csrf', 'secret', 'code'];

    static function start(?array $route, array $params): void {
        self::$t0 = microtime(true);
        self::$ctx = ['route' => $route, 'params' => $params];
    }
    static function skipRequest(): void { self::$skip = true; }

    /** Événement explicite (connexion, échec, déconnexion, export...). */
    static function event(string $type, array $extra = [], ?array $user = null): void {
        try {
            $ip = Request::ip(); $geo = Geo::locate($ip); $dev = Geo::device(Request::ua());
            $user ??= Auth::user();
            $row = [
                'created_at' => now(), 'user_id' => $user['id'] ?? null, 'user_name' => $user['name'] ?? ($extra['user_name'] ?? null),
                'role_code' => self::roleCodes($user['id'] ?? null), 'team_name' => self::teamName($user),
                'session_hash' => session_id() ? hash('sha256', session_id()) : null, 'event_type' => $type,
                'method' => Request::method(), 'url' => substr(self::cleanUrl(), 0, 500), 'ip' => $ip,
                'country' => $geo['country'], 'city' => $geo['city'], 'network' => $geo['network'],
                'device' => $dev['device'], 'os' => $dev['os'], 'browser' => $dev['browser'], 'referer' => substr($_SERVER['HTTP_REFERER'] ?? '', 0, 300),
                'result' => 'success',
            ];
            foreach ($extra as $k => $v) if (array_key_exists($k, $row) || $k === 'module' || $k === 'route' || $k === 'object_type' || $k === 'object_id' || $k === 'menu_code' || $k === 'status_code' || $k === 'duration_ms') $row[$k] = $v;
            DB::insert('user_activity_events', $row);
        } catch (\Throwable $e) { error_log('[activity] ' . $e->getMessage(), 3, ROOT . '/storage/logs/app.log'); }
    }

    /** Tentative suspecte (compte inconnu ou bloqué, force brute, jeton CSRF invalide, lien de réinitialisation falsifié...). */
    static function intrusion(string $reason, string $target = '', ?array $user = null, array $extra = []): void {
        self::event('intrusion', $extra + ['module' => 'security', 'result' => 'denied', 'status_code' => 401, 'object_type' => $reason, 'object_id' => substr($target, 0, 60), 'user_name' => $user['name'] ?? ($target !== '' ? $target : null)], $user);
    }

    /** Appelé en fin de requête (shutdown) pour toute page authentifiée. */
    static function commit(): void {
        if (self::$skip || !Auth::check()) return;
        $route = self::$ctx['route'] ?? null; $params = self::$ctx['params'] ?? [];
        $status = http_response_code() ?: 200;
        $handler = $route['handler'] ?? '';
        [$ctl, $method] = array_pad(explode('@', $handler), 2, '');
        $module = strtolower(str_replace('Controller', '', $ctl)) ?: 'app';
        $type = match (true) {
            str_starts_with($method, 'store') => 'create', str_starts_with($method, 'update') => 'update', str_starts_with($method, 'delete') => 'delete',
            str_starts_with($method, 'import') || str_starts_with($method, 'commit') => 'import', str_starts_with($method, 'export') => 'export',
            str_starts_with($method, 'download') => 'download', Request::method() === 'POST' => 'action', default => 'page_view',
        };
        $result = $status === 403 ? 'denied' : ($status >= 500 ? 'error' : 'success');
        if ($status === 403) $type = 'denied'; elseif ($status >= 500) $type = 'error';
        $obj = isset($params['id']) ? (string)$params['id'] : null;
        self::event($type, [
            'module' => $module, 'route' => $route['path'] ?? Request::path(), 'menu_code' => self::menuFor(Request::path()),
            'object_type' => $obj ? ($params['entity'] ?? $module) : null, 'object_id' => $obj, 'status_code' => $status,
            'duration_ms' => (int)round((microtime(true) - self::$t0) * 1000), 'result' => $result,
        ]);
    }

    private static function cleanUrl(): string {
        $path = Request::path(); $q = $_GET;
        foreach ($q as $k => $v) if (in_array(strtolower((string)$k), self::SENSITIVE, true)) $q[$k] = '***';
        return $path . ($q ? '?' . http_build_query($q) : '');
    }
    private static function menuFor(string $path): ?string {
        $best = null; $len = 0;
        foreach (Menu::items() as $m) {
            if ($m['url'] && ($path === $m['url'] || ($m['url'] !== '/' && str_starts_with($path, $m['url'] . '/'))) && strlen($m['url']) > $len) { $best = $m['code']; $len = strlen($m['url']); }
        }
        return $best;
    }
    private static function roleCodes(?int $uid): ?string {
        if (!$uid) return null;
        return implode(',', array_column(DB::all('SELECT r.code FROM roles r JOIN user_roles ur ON ur.role_id=r.id WHERE ur.user_id=?', [$uid]), 'code')) ?: null;
    }
    private static function teamName(?array $u): ?string {
        if (!$u || empty($u['employee_id'])) return null;
        return DB::val('SELECT t.name FROM employees e JOIN teams t ON t.id=e.team_id WHERE e.id=?', [$u['employee_id']]);
    }
}
