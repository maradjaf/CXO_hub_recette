<?php
namespace App\Core;
/** Lieu approché depuis l'adresse IP : réseau interne détecté, externe résolu par la table geo_ranges (importable). */
class Geo {
    static function locate(string $ip): array {
        if (self::isPrivate($ip)) return ['network' => 'interne', 'country' => '', 'city' => 'Réseau interne'];
        $n = ip2long($ip);
        if ($n !== false) {
            $r = DB::one('SELECT country, city FROM geo_ranges WHERE ip_from <= ? AND ip_to >= ? ORDER BY ip_from DESC LIMIT 1', [$n, $n]);
            if ($r) return ['network' => 'externe', 'country' => (string)$r['country'], 'city' => (string)$r['city']];
        }
        return ['network' => 'externe', 'country' => '', 'city' => 'Non résolu'];
    }
    static function isPrivate(string $ip): bool {
        return $ip === '::1' || $ip === '127.0.0.1' || !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
    }
    static function device(string $ua): array {
        $os = match (true) { (bool)preg_match('/Windows/i', $ua) => 'Windows', (bool)preg_match('/Android/i', $ua) => 'Android', (bool)preg_match('/iPhone|iPad|iOS/i', $ua) => 'iOS',
            (bool)preg_match('/Mac OS/i', $ua) => 'macOS', (bool)preg_match('/Linux/i', $ua) => 'Linux', default => 'Autre' };
        $br = match (true) { (bool)preg_match('/Edg\//', $ua) => 'Edge', (bool)preg_match('/OPR\/|Opera/', $ua) => 'Opera', (bool)preg_match('/Chrome\//', $ua) => 'Chrome',
            (bool)preg_match('/Firefox\//', $ua) => 'Firefox', (bool)preg_match('/Safari\//', $ua) => 'Safari', (bool)preg_match('/curl|bot/i', $ua) => 'Outil', default => 'Autre' };
        $dev = preg_match('/Mobile|Android|iPhone/i', $ua) ? 'Mobile' : (preg_match('/iPad|Tablet/i', $ua) ? 'Tablette' : 'Ordinateur');
        return ['os' => $os, 'browser' => $br, 'device' => $dev];
    }
}
