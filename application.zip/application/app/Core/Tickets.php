<?php
namespace App\Core;
/** Règles métier de l'assistance technique : références, délais (SLA), journal d'événements. */
class Tickets {
    const STATUS = ['approval' => 'En attente de validation', 'new' => 'Nouveau', 'assigned' => 'Affecté', 'in_progress' => 'En cours', 'waiting' => 'En attente', 'resolved' => 'Résolu', 'closed' => 'Clos'];
    const PRIO = ['critical' => 'Critique', 'high' => 'Haute', 'normal' => 'Normale', 'low' => 'Basse'];
    const KIND = ['incident' => 'Incident / panne', 'request' => 'Demande', 'maintenance' => 'Maintenance préventive'];
    const ASSET_STATUS = ['in_service' => 'En service', 'repair' => 'En réparation', 'spare' => 'En stock', 'retired' => 'Réformé'];
    const OPEN = ['approval', 'new', 'assigned', 'in_progress', 'waiting'];

    static function sla(string $prio): array {
        $r = DB::one('SELECT response_hours, resolve_hours, calendar FROM at_sla WHERE priority=?', [$prio]);
        return $r ? ['r' => (int)$r['response_hours'], 's' => (int)$r['resolve_hours'], 'cal' => $r['calendar'] ?: '24x7'] : ['r' => 4, 's' => 24, 'cal' => '24x7'];
    }
    // ---- Calendrier d'heures ouvrées (calendrier par défaut, ou calendrier propre à l'équipe)
    static function cal(?int $teamId = null): array {
        static $cache = []; $key = (int)$teamId; if (isset($cache[$key])) return $cache[$key];
        $days = (string)setting('at_cal_days', '1,2,3,4,5'); $st = (string)setting('at_cal_start', ''); $en = (string)setting('at_cal_end', '');
        if ($teamId) { try { $c = DB::one('SELECT c.* FROM at_team_cal t JOIN at_calendars c ON c.id=t.calendar_id WHERE t.team_id=?', [$teamId]); if ($c) { $days = $c['days']; $st = $c['start_time']; $en = $c['end_time']; } } catch (\Throwable $e) {} }
        $days = array_values(array_filter(array_map('intval', explode(',', $days)), fn($d) => $d >= 1 && $d <= 7));
        if (!preg_match('/^\d{2}:\d{2}$/', $st)) $st = '08:00'; if (!preg_match('/^\d{2}:\d{2}$/', $en)) $en = '17:00';
        if ($en <= $st) { $st = '08:00'; $en = '17:00'; }
        $h = []; try { foreach (DB::all('SELECT day FROM at_holidays') as $r) $h[$r['day']] = true; } catch (\Throwable $e) {}
        return $cache[$key] = ['days' => $days ?: [1, 2, 3, 4, 5], 'start' => $st, 'end' => $en, 'holidays' => $h];
    }
    private static function isOpenDay(string $ymd, array $c): bool { return in_array((int)date('N', strtotime($ymd)), $c['days'], true) && !isset($c['holidays'][$ymd]); }
    /** Premier instant ouvré à partir de $ts (lui-même s'il est dans la plage d'ouverture). */
    static function nextOpen(int $ts, ?array $c = null): int {
        $c ??= self::cal();
        for ($i = 0; $i < 800; $i++) {
            $d = date('Y-m-d', $ts);
            if (self::isOpenDay($d, $c)) { $s = strtotime("$d {$c['start']}"); $e = strtotime("$d {$c['end']}"); if ($ts < $s) return $s; if ($ts < $e) return $ts; }
            $ts = strtotime($d . ' 00:00:00 +1 day');
        }
        return $ts;
    }
    /** Ajoute $seconds de temps ouvré (jours ouvrés, plage horaire, hors jours fériés). */
    static function addBusiness(int $ts, int $seconds, ?array $c = null): int {
        $c ??= self::cal();
        for ($g = 0; $g < 3000; $g++) {
            $ts = self::nextOpen($ts, $c); $end = strtotime(date('Y-m-d', $ts) . ' ' . $c['end']); $avail = $end - $ts;
            if ($seconds <= $avail) return $ts + $seconds;
            $seconds -= $avail; $ts = $end;
        }
        return $ts;
    }
    /** Secondes ouvrées écoulées entre deux instants. */
    static function businessSeconds(int $from, int $to, ?array $c = null): int {
        $c ??= self::cal(); $sum = 0;
        for ($g = 0; $g < 3000 && $from < $to; $g++) {
            $from = self::nextOpen($from, $c); if ($from >= $to) break;
            $end = min($to, strtotime(date('Y-m-d', $from) . ' ' . $c['end'])); $sum += max(0, $end - $from); $from = strtotime(date('Y-m-d', $from) . ' ' . $c['end']);
        }
        return $sum;
    }
    static function addHours(string $from, int $hours, string $cal, ?int $teamId = null): string { return self::addSeconds($from, $hours * 3600, $cal, $teamId); }
    static function addSeconds(string $from, int $secs, string $cal, ?int $teamId = null): string {
        $t = strtotime($from); return date('Y-m-d H:i:s', $cal === 'business' ? self::addBusiness($t, $secs, self::cal($teamId)) : $t + $secs);
    }
    /** Échéances d'un ticket ; $shift = secondes de suspension déjà cumulées (même unité que le décompte de la priorité). */
    static function due(string $createdAt, string $prio, ?int $teamId = null, int $shift = 0): array {
        $s = self::sla($prio);
        return ['response_due' => self::addSeconds($createdAt, $s['r'] * 3600, $s['cal'], $teamId), 'due_at' => self::addSeconds($createdAt, $s['s'] * 3600 + $shift, $s['cal'], $teamId)];
    }
    /** Gestion de la suspension des délais (statut « En attente ») : retourne les champs à mettre à jour lors d'un changement de statut. */
    static function transition(array $t, string $new): array {
        $out = [];
        if ($t['status'] !== 'waiting' && $new === 'waiting') $out['paused_at'] = now();
        elseif ($t['status'] === 'waiting' && $new !== 'waiting' && !empty($t['paused_at'])) {
            $s = self::sla($t['priority']); $cal = self::cal($t['team_id'] ? (int)$t['team_id'] : null); $from = strtotime($t['paused_at']); $to = time();
            $secs = $s['cal'] === 'business' ? self::businessSeconds($from, $to, $cal) : max(0, $to - $from);
            if ($secs > 0 && $t['due_at']) $out['due_at'] = self::addSeconds($t['due_at'], $secs, $s['cal'], $t['team_id'] ? (int)$t['team_id'] : null);
            if ($secs > 0 && $t['response_due'] && empty($t['first_response_at'])) $out['response_due'] = self::addSeconds($t['response_due'], $secs, $s['cal'], $t['team_id'] ? (int)$t['team_id'] : null);
            $out['paused_at'] = null; $out['paused_secs'] = (int)$t['paused_secs'] + $secs;
        }
        return $out;
    }
    static function reference(): string {
        $p = 'AT-' . date('y') . '-';
        $last = DB::val('SELECT reference FROM at_tickets WHERE reference LIKE ? ORDER BY id DESC LIMIT 1', [$p . '%']);
        $n = $last ? (int)substr($last, strlen($p)) + 1 : 1;
        return $p . str_pad((string)$n, 5, '0', STR_PAD_LEFT);
    }
    /** @param array $d kind, category, priority, title, description, requester_id, store_id, team_id, asset_id, assignee_id, created_at */
    static function create(array $d): int {
        $created = $d['created_at'] ?? now(); $prio = Esc::priority($d['impact'] ?? null, $d['urgency'] ?? null) ?? ($d['priority'] ?? 'normal'); if (!isset(self::PRIO[$prio])) $prio = 'normal';
        $channel = isset(Esc::CHANNEL[$d['channel'] ?? '']) ? $d['channel'] : 'portal';
        $row = ['reference' => self::reference(), 'kind' => $d['kind'] ?? 'incident', 'category' => $d['category'] ?? null, 'priority' => $prio, 'title' => $d['title'], 'description' => $d['description'] ?? null,
            'requester_id' => $d['requester_id'] ?? null, 'store_id' => $d['store_id'] ?? null, 'team_id' => $d['team_id'] ?? null, 'asset_id' => $d['asset_id'] ?? null,
            'assignee_id' => $d['assignee_id'] ?? null, 'status' => !empty($d['assignee_id']) ? 'assigned' : 'new', 'created_at' => $created,
            'channel' => $channel, 'impact' => isset(Esc::IMPACT[$d['impact'] ?? '']) ? $d['impact'] : null, 'urgency' => isset(Esc::URGENCY[$d['urgency'] ?? '']) ? $d['urgency'] : null, 'tier' => 1, 'group_id' => $d['group_id'] ?? Esc::route($d['category'] ?? null), 'logged_by' => $d['logged_by'] ?? null] + self::due($created, $prio, !empty($d['team_id']) ? (int)$d['team_id'] : null);
        $id = DB::insert('at_tickets', $row);
        self::event($id, 'created', 'Ticket créé via ' . (Esc::CHANNEL[$channel] ?? $channel) . ' (' . (self::PRIO[$prio] ?? $prio) . ').', $d['logged_by'] ?? $d['requester_id'] ?? null);
        return $id;
    }
    static function event(int $tid, string $kind, string $body, ?int $uid = null, ?string $at = null): void {
        $name = $uid ? (string)DB::val('SELECT name FROM users WHERE id=?', [$uid]) : 'Système';
        DB::insert('at_events', ['ticket_id' => $tid, 'user_id' => $uid, 'user_name' => $name ?: 'Système', 'kind' => $kind, 'body' => mb_substr($body, 0, 1500), 'created_at' => $at ?? now()]);
    }
    /** ok | warn | breach | done */
    static function slaState(array $t): string {
        if (!in_array($t['status'], self::OPEN, true)) return 'done';
        if ($t['status'] === 'waiting') return 'paused';
        if (!$t['due_at']) return 'ok';
        $now = time(); $due = strtotime($t['due_at']); if ($due < $now) return 'breach';
        $total = max(1, $due - strtotime($t['created_at']));
        return ($due - $now) <= $total * 0.25 ? 'warn' : 'ok';
    }
    static function slaBadge(array $t): string {
        return match (self::slaState($t)) {
            'breach' => badge('Délai dépassé', 'danger'), 'warn' => badge('Échéance proche', 'warning'),
            'ok' => badge('Dans les délais', 'success'), 'paused' => badge('Délai suspendu', 'info'), default => !empty($t['resolved_at']) && $t['due_at'] && $t['resolved_at'] > $t['due_at'] ? badge('Résolu hors délai', 'secondary') : badge('Résolu', 'secondary')};
    }
    static function handlers(): array {
        return DB::all("SELECT DISTINCT u.id, u.name FROM users u JOIN user_roles ur ON ur.user_id=u.id JOIN roles r ON r.id=ur.role_id LEFT JOIN role_permissions rp ON rp.role_id=r.id LEFT JOIN permissions p ON p.id=rp.permission_id WHERE u.status='active' AND (r.code='admin' OR p.code='at.handle') ORDER BY u.name");
    }
    static function notifyHandlers(string $title, string $body, string $url): void { Notifier::toPermission('at.handle', $title, $body, $url); }
    static function statusBadge(string $s): string { return badge(self::STATUS[$s] ?? $s, ['approval' => 'secondary', 'new' => 'primary', 'assigned' => 'info', 'in_progress' => 'warning', 'waiting' => 'secondary', 'resolved' => 'success', 'closed' => 'dark'][$s] ?? 'secondary'); }
    static function prioBadge(string $p): string { return badge(self::PRIO[$p] ?? $p, ['critical' => 'danger', 'high' => 'warning', 'normal' => 'primary', 'low' => 'secondary'][$p] ?? 'secondary'); }

    // ---- Ouverture d'un ticket (formulaire ou e-mail) ; une demande d'accès passe par le circuit de validation
    static function open(array $d, int $uid): int {
        $id = self::create($d + ['requester_id' => $uid]);
        $t = DB::one('SELECT * FROM at_tickets WHERE id=?', [$id]);
        $def = ($d['kind'] ?? '') === 'request' && ($d['category'] ?? '') === 'COMPTE' ? DB::val("SELECT id FROM wf_definitions WHERE code='ACCES_TECH' AND active=1") : null;
        if ($def) {
            try {
                $wf = Workflow::start((int)$def, 'Accès : ' . $t['title'], mb_substr((string)$t['description'], 0, 500), 'at_ticket', $id, $uid);
                DB::update('at_tickets', ['status' => 'approval', 'wf_request_id' => $wf], 'id=?', [$id]);
                self::event($id, 'status', 'Demande d\'accès envoyée pour validation (responsable puis sécurité).', $uid);
                return $id;
            } catch (\Throwable $e) { /* circuit indisponible : le ticket suit le traitement normal */ }
        }
        self::notifyHandlers('Nouveau ticket ' . $t['reference'], ($t['priority'] === 'critical' ? '[CRITIQUE] ' : '') . $t['title'], '/at/' . $id);
        return $id;
    }
    /** Appelé par le workflow à la fin du circuit de validation d'une demande d'accès. */
    static function approvalDone(int $tid, string $status): void {
        $t = DB::one('SELECT * FROM at_tickets WHERE id=?', [$tid]); if (!$t || $t['status'] !== 'approval') return;
        if ($status === 'approved') {
            DB::update('at_tickets', ['status' => $t['assignee_id'] ? 'assigned' : 'new'] + self::due(now(), $t['priority'], $t['team_id'] ? (int)$t['team_id'] : null), 'id=?', [$tid]);
            self::event($tid, 'status', 'Demande d\'accès validée : le ticket est transmis aux techniciens (délais recalculés à partir de maintenant).', Auth::id());
            self::notifyHandlers('Accès validé à créer : ' . $t['reference'], $t['title'], '/at/' . $tid);
            if ($t['requester_id']) Notifier::send((int)$t['requester_id'], 'Demande d\'accès validée : ' . $t['reference'], 'Un technicien va la traiter.', '/at/' . $tid);
        } else {
            DB::update('at_tickets', ['status' => 'closed', 'resolution' => 'Demande d\'accès ' . ($status === 'rejected' ? 'refusée' : 'annulée') . ' au cours de la validation.', 'resolved_at' => now(), 'closed_at' => now()], 'id=?', [$tid]);
            self::event($tid, 'status', 'Demande d\'accès ' . ($status === 'rejected' ? 'refusée' : 'annulée') . ' : ticket clos.', Auth::id());
            if ($t['requester_id']) Notifier::send((int)$t['requester_id'], 'Demande d\'accès ' . ($status === 'rejected' ? 'refusée' : 'annulée') . ' : ' . $t['reference'], '', '/at/' . $tid);
        }
    }

    // ---- Pièces jointes
    const FILE_MAX = 5242880;   // conservé pour compatibilité ; la limite effective vient de Files::maxBytes()
    static function fileDir(): string { $d = ROOT . '/storage/uploads/at'; if (!is_dir($d)) @mkdir($d, 0775, true); return $d; }
    /** Enregistre un fichier (contenu en mémoire) ; retourne un message d'erreur ou null. */
    static function saveBytes(int $tid, string $name, string $bytes, ?int $uid, bool $internal = false): ?string {
        $name = Files::cleanName($name); [$e, $ext, $mime] = Files::check($name, $bytes); if ($e) return $e;
        if ((int)DB::val('SELECT COUNT(*) FROM at_files WHERE ticket_id=?', [$tid]) >= 30) return 'Nombre maximal de pièces jointes atteint pour ce ticket.';
        $stored = bin2hex(random_bytes(16)) . '.' . $ext;
        if (file_put_contents(self::fileDir() . '/' . $stored, $bytes) === false) return "« $name » : enregistrement impossible.";
        $uname = $uid ? (string)DB::val('SELECT name FROM users WHERE id=?', [$uid]) : 'E-mail';
        DB::insert('at_files', ['ticket_id' => $tid, 'user_id' => $uid, 'user_name' => $uname ?: 'Système', 'original_name' => $name, 'stored_name' => $stored, 'mime' => $mime, 'size' => strlen($bytes), 'internal' => $internal ? 1 : 0, 'created_at' => now()]);
        self::event($tid, 'file', 'Pièce jointe ajoutée : ' . $name, $uid);
        return null;
    }
    /** Traite $_FILES[$field] (jusqu'à 5 fichiers) ; retourne la liste des erreurs. */
    static function saveUploads(int $tid, string $field, ?int $uid, bool $internal = false): array {
        $err = []; $f = $_FILES[$field] ?? null; if (!$f || !is_array($f['name'])) return $err;
        $n = 0;
        foreach ($f['name'] as $i => $name) {
            if ($f['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
            if (++$n > Files::maxCount()) { $err[] = 'Seuls les ' . Files::maxCount() . ' premiers fichiers ont été pris en compte.'; break; }
            if ($f['error'][$i] === UPLOAD_ERR_INI_SIZE || $f['error'][$i] === UPLOAD_ERR_FORM_SIZE) { $err[] = "« $name » dépasse la taille maximale acceptée par le serveur."; continue; }
            if ($f['error'][$i] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'][$i])) { $err[] = "« $name » : envoi échoué."; continue; }
            if ($m = self::saveBytes($tid, (string)$name, (string)file_get_contents($f['tmp_name'][$i]), $uid, $internal)) $err[] = $m;
        }
        return $err;
    }

    // ---- Stock de pièces
    /** kind : in | out | adjust (qty = nouveau stock). Retourne un message d'erreur ou null. */
    static function stockMove(int $item, string $kind, int $qty, ?int $ticket, ?int $uid, string $note = '', ?float $cost = null): ?string {
        $it = DB::one('SELECT * FROM at_stock WHERE id=?', [$item]); if (!$it) return 'Article inconnu.';
        if ($kind === 'adjust' ? $qty < 0 : $qty < 1) return 'Quantité invalide.';
        if ($qty > 1000000) return 'Quantité trop élevée.';
        $cur = (int)$it['qty'];
        $delta = match ($kind) { 'in' => $qty, 'out' => -$qty, 'adjust' => $qty - $cur, default => 0 };
        if (!$delta && $kind !== 'adjust') return 'Mouvement invalide.';
        if ($cur + $delta < 0) return 'Stock insuffisant : ' . $cur . ' ' . $it['unit'] . ' disponible(s).';
        $after = $cur + $delta; $uname = $uid ? (string)DB::val('SELECT name FROM users WHERE id=?', [$uid]) : 'Système';
        $upd = ['qty' => $after, 'updated_at' => now()];
        if ($kind === 'in' && $cost !== null && $cost >= 0 && $after > 0) $upd['unit_cost'] = ($it['unit_cost'] === null || $cur <= 0) ? round($cost, 2) : round(($cur * (float)$it['unit_cost'] + $qty * $cost) / $after, 2);   // coût moyen pondéré
        DB::update('at_stock', $upd, 'id=?', [$item]);
        DB::insert('at_stock_moves', ['item_id' => $item, 'kind' => $kind, 'delta' => $delta, 'qty_after' => $after, 'ticket_id' => $ticket, 'user_id' => $uid, 'user_name' => $uname, 'note' => $note !== '' ? mb_substr($note, 0, 300) : null, 'created_at' => now()]);
        if ($cur > (int)$it['min_qty'] && $after <= (int)$it['min_qty'] && (int)$it['min_qty'] > 0) Notifier::toPermission('at.manage', 'Stock bas : ' . $it['label'], $after . ' ' . $it['unit'] . ' restant(s) (seuil ' . $it['min_qty'] . ')', '/at/stock/' . $item);
        return null;
    }
}
