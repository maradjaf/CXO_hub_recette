<?php
namespace App\Core;
/** Moteur de workflow : demandes validées étape par étape (responsable, rôle ou utilisateur), délais (SLA), historique et escalade. */
class Workflow {
    const STATUS = ['pending' => 'En cours', 'approved' => 'Approuvée', 'rejected' => 'Refusée', 'cancelled' => 'Annulée'];
    static function steps(int $def): array { return DB::all('SELECT * FROM wf_steps WHERE definition_id=? ORDER BY position', [$def]); }
    static function step(array $req): ?array { return DB::one('SELECT * FROM wf_steps WHERE definition_id=? AND position=?', [$req['definition_id'], $req['current_step']]); }
    /** Identifiants des utilisateurs habilités à traiter l'étape courante. */
    static function approvers(array $req): array {
        $st = self::step($req); if (!$st) return [];
        $ids = [];
        if ($st['approver_type'] === 'user') $ids = [(int)$st['approver_ref']];
        elseif ($st['approver_type'] === 'role') $ids = array_column(DB::all('SELECT ur.user_id FROM user_roles ur JOIN roles r ON r.id=ur.role_id JOIN users u ON u.id=ur.user_id WHERE r.code=? AND u.status=?', [$st['approver_ref'], 'active']), 'user_id');
        else {
            $emp = DB::val('SELECT employee_id FROM users WHERE id=?', [$req['requester_id']]);
            $mgr = $emp ? DB::val('SELECT manager_id FROM employees WHERE id=?', [$emp]) : null;
            $uid = $mgr ? DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [$mgr]) : null;
            $ids = $uid ? [(int)$uid] : array_column(DB::all("SELECT ur.user_id FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE r.code='hr'"), 'user_id');
        }
        $ids = array_values(array_diff(array_unique(array_map('intval', $ids)), [(int)$req['requester_id']]));
        if (!$ids) $ids = array_map('intval', array_column(DB::all("SELECT ur.user_id FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE r.code='admin' AND ur.user_id<>?", [(int)$req['requester_id']]), 'user_id'));
        return $ids;
    }
    static function canAct(int $uid, array $req): bool { return $req['status'] === 'pending' && $uid !== (int)$req['requester_id'] && (in_array($uid, self::approvers($req), true) || Auth::can('workflow.manage')); }
    private static function enter(array $req): void {
        $st = self::step($req); if (!$st) return;
        DB::update('wf_requests', ['due_at' => date('Y-m-d H:i:s', time() + 3600 * (int)$st['sla_hours']), 'escalated_at' => null], 'id=?', [$req['id']]);
        foreach (self::approvers($req) as $u) Notifier::send($u, 'Demande à valider : ' . $req['reference'], $req['title'] . ' — étape « ' . $st['name'] . ' »', '/workflow/' . $req['id']);
    }
    private static function log(int $rid, ?int $pos, string $action, string $comment = ''): void {
        $u = Auth::user();
        DB::insert('wf_actions', ['request_id' => $rid, 'step_position' => $pos, 'user_id' => Auth::id(), 'user_name' => $u['name'] ?? 'Système', 'action' => $action, 'comment' => $comment ?: null, 'created_at' => now()]);
    }
    static function start(int $def, string $title, ?string $desc, ?string $subjectType = null, ?int $subjectId = null, ?int $requester = null): int {
        $d = DB::one('SELECT * FROM wf_definitions WHERE id=? AND active=1', [$def]);
        if (!$d || !self::steps($def)) throw new \RuntimeException('Circuit indisponible');
        $id = DB::insert('wf_requests', ['reference' => 'TMP' . bin2hex(random_bytes(4)), 'definition_id' => $def, 'title' => $title, 'description' => $desc, 'requester_id' => $requester ?? Auth::id(), 'subject_type' => $subjectType, 'subject_id' => $subjectId, 'status' => 'pending', 'current_step' => 1, 'created_at' => now()]);
        $ref = strtoupper(substr($d['code'], 0, 4)) . '-' . date('y') . '-' . str_pad((string)$id, 5, '0', STR_PAD_LEFT);
        DB::update('wf_requests', ['reference' => $ref], 'id=?', [$id]);
        self::log($id, 1, 'submit', $desc ?? '');
        self::enter(DB::one('SELECT * FROM wf_requests WHERE id=?', [$id]));
        return $id;
    }
    static function act(array $req, string $action, string $comment): string {
        $pos = (int)$req['current_step'];
        if ($action === 'comment') { self::log($req['id'], $pos, 'comment', $comment); return 'Commentaire ajouté.'; }
        if ($req['status'] !== 'pending') return 'Cette demande est clôturée.';
        if ($action === 'cancel') {
            if ((int)$req['requester_id'] !== Auth::id()) return 'Seul le demandeur peut annuler.';
            DB::update('wf_requests', ['status' => 'cancelled', 'closed_at' => now()], 'id=?', [$req['id']]); self::log($req['id'], $pos, 'cancel', $comment); self::closed($req, 'cancelled'); return 'Demande annulée.';
        }
        if (!self::canAct(Auth::id(), $req)) return 'Vous n\'êtes pas habilité à traiter cette étape.';
        if ($action === 'reject') {
            if ($comment === '') return 'Un motif est obligatoire pour refuser.';
            DB::update('wf_requests', ['status' => 'rejected', 'closed_at' => now()], 'id=?', [$req['id']]); self::log($req['id'], $pos, 'reject', $comment);
            Notifier::send((int)$req['requester_id'], 'Demande refusée : ' . $req['reference'], $comment, '/workflow/' . $req['id']); self::closed($req, 'rejected'); return 'Demande refusée.';
        }
        self::log($req['id'], $pos, 'approve', $comment);
        $next = DB::one('SELECT 1 FROM wf_steps WHERE definition_id=? AND position>?', [$req['definition_id'], $pos]);
        if ($next) {
            $nextPos = (int)DB::val('SELECT MIN(position) FROM wf_steps WHERE definition_id=? AND position>?', [$req['definition_id'], $pos]);
            DB::update('wf_requests', ['current_step' => $nextPos], 'id=?', [$req['id']]);
            self::enter(DB::one('SELECT * FROM wf_requests WHERE id=?', [$req['id']])); return 'Étape validée ; la demande passe à l\'étape suivante.';
        }
        DB::update('wf_requests', ['status' => 'approved', 'closed_at' => now()], 'id=?', [$req['id']]);
        Notifier::send((int)$req['requester_id'], 'Demande approuvée : ' . $req['reference'], $req['title'], '/workflow/' . $req['id']); self::closed($req, 'approved'); return 'Demande approuvée.';
    }
    /** Répercute la clôture d'une demande sur l'objet métier lié (congé, etc.). */
    private static function closed(array $req, string $status): void {
        if (($req['subject_type'] ?? null) === 'at_ticket' && $req['subject_id']) Tickets::approvalDone((int)$req['subject_id'], $status);
        if (($req['subject_type'] ?? null) === 'leave' && $req['subject_id']) {
            $leave = DB::one('SELECT * FROM leave_requests WHERE id=?', [(int)$req['subject_id']]);
            DB::update('leave_requests', ['status' => $status], 'id=?', [(int)$req['subject_id']]);
            Audit::log('leave_' . $status, 'leave_request', $req['subject_id'], ['status' => $leave['status'] ?? null], ['status' => $status]);
        }
    }
    /** Relance les approbateurs et alerte les gestionnaires du workflow pour toute étape dépassée. Retourne le nombre d'escalades. */
    static function escalate(): int {
        $n = 0;
        foreach (DB::all("SELECT * FROM wf_requests WHERE status='pending' AND due_at IS NOT NULL AND due_at<? AND escalated_at IS NULL", [now()]) as $r) {
            DB::update('wf_requests', ['escalated_at' => now()], 'id=?', [$r['id']]);
            DB::insert('wf_actions', ['request_id' => $r['id'], 'step_position' => $r['current_step'], 'user_name' => 'Système', 'action' => 'escalate', 'comment' => 'Délai dépassé', 'created_at' => now()]);
            foreach (self::approvers($r) as $u) Notifier::send($u, 'Relance : ' . $r['reference'], 'Le délai de traitement est dépassé.', '/workflow/' . $r['id']);
            Notifier::toPermission('workflow.manage', 'Délai dépassé : ' . $r['reference'], $r['title'], '/workflow/' . $r['id']); $n++;
        }
        return $n;
    }
}
