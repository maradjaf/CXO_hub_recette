<?php
namespace App\Core;
/**
 * Intégrations API : Zoom (Server-to-Server OAuth), Microsoft Teams (Graph, application permissions) et WhatsApp Business Cloud API.
 * Tous les paramètres (identifiants, URLs, options) sont saisis en base par l'admin / le coordinateur technique ; les secrets sont chiffrés.
 * Sans configuration valide, rien n'est appelé : l'organisateur colle le lien de la réunion comme avant.
 */
class Integ {
    const DEF = [
        'zoom.enabled' => '0', 'zoom.account_id' => '', 'zoom.client_id' => '', 'zoom.client_secret' => '', 'zoom.host' => 'me', 'zoom.api_base' => 'https://api.zoom.us/v2', 'zoom.oauth_url' => 'https://zoom.us/oauth/token',
        'teams.enabled' => '0', 'teams.tenant_id' => '', 'teams.client_id' => '', 'teams.client_secret' => '', 'teams.organizer' => '', 'teams.graph_base' => 'https://graph.microsoft.com/v1.0', 'teams.login_base' => 'https://login.microsoftonline.com',
        'wa.enabled' => '0', 'wa.phone_id' => '', 'wa.token' => '', 'wa.api_base' => 'https://graph.facebook.com/v20.0', 'wa.mode' => 'template', 'wa.template' => '', 'wa.lang' => 'fr',
    ];
    const SECRETS = ['zoom.client_secret', 'teams.client_secret', 'wa.token'];
    static function get(string $k): string {
        $v = (string)Settings::get('integ.' . $k, self::DEF[$k] ?? ''); if ($v === '' && isset(self::DEF[$k])) $v = self::DEF[$k];
        return in_array($k, self::SECRETS, true) ? Secret::dec($v) : $v;
    }
    static function set(string $k, string $v): void { Settings::set('integ.' . $k, in_array($k, self::SECRETS, true) && $v !== '' ? Secret::enc($v) : $v); }
    static function has(string $k): bool { return (string)Settings::get('integ.' . $k, '') !== ''; }
    static function ready(string $p): bool {
        if (self::get($p . '.enabled') !== '1') return false;
        return match ($p) { 'zoom' => self::get('zoom.account_id') !== '' && self::get('zoom.client_id') !== '' && self::get('zoom.client_secret') !== '', 'teams' => self::get('teams.tenant_id') !== '' && self::get('teams.client_id') !== '' && self::get('teams.client_secret') !== '' && self::get('teams.organizer') !== '', 'wa' => self::get('wa.phone_id') !== '' && self::get('wa.token') !== '' && (self::get('wa.mode') !== 'template' || self::get('wa.template') !== ''), default => false };
    }
    private static function log(string $p, string $a, bool $ok, int $st, string $msg): void { try { DB::insert('integ_log', ['provider' => $p, 'action' => $a, 'ok' => $ok ? 1 : 0, 'http_status' => $st, 'message' => mb_substr($msg, 0, 400), 'user_id' => Auth::id(), 'created_at' => now()]); } catch (\Throwable $e) {} }
    /** URL autorisée : https, ou http vers la machine locale (essais). */
    private static function urlOk(string $u): bool { $x = parse_url($u); if (!$x || empty($x['host'])) return false; $s = strtolower($x['scheme'] ?? ''); return $s === 'https' || ($s === 'http' && in_array($x['host'], ['127.0.0.1', 'localhost'], true)); }
    /** @return array{0:int,1:mixed,2:?string} statut HTTP, corps décodé, erreur réseau */
    static function http(string $method, string $url, array $headers = [], $body = null, bool $json = true): array {
        if (!self::urlOk($url)) return [0, null, 'URL non autorisée (https requis).'];
        $c = curl_init($url); $h = $headers; $data = null;
        if ($body !== null) { $data = $json ? json_encode($body, JSON_UNESCAPED_UNICODE) : http_build_query($body); $h[] = 'Content-Type: ' . ($json ? 'application/json' : 'application/x-www-form-urlencoded'); }
        curl_setopt_array($c, [CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 6, CURLOPT_HTTPHEADER => $h, CURLOPT_FOLLOWLOCATION => false, CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS]);
        if ($data !== null) curl_setopt($c, CURLOPT_POSTFIELDS, $data);
        $r = curl_exec($c); $st = (int)curl_getinfo($c, CURLINFO_HTTP_CODE); $err = $r === false ? curl_error($c) : null; curl_close($c);
        $dec = is_string($r) && $r !== '' ? (json_decode($r, true) ?? $r) : null; return [$st, $dec, $err];
    }
    private static function errMsg(int $st, $b, ?string $err): string {
        if ($err) return 'Réseau : ' . $err; $m = is_array($b) ? ($b['message'] ?? $b['error_description'] ?? ($b['error']['message'] ?? ($b['error'] ?? ''))) : ''; return 'HTTP ' . $st . (is_string($m) && $m !== '' ? ' — ' . $m : '');
    }
    private static function token(string $p): string {
        $key = 'integ.' . $p . '.tok'; $c = json_decode((string)Settings::get($key, ''), true);
        if (is_array($c) && ($c['exp'] ?? 0) > time() + 60 && !empty($c['t'])) return Secret::dec($c['t']);
        if ($p === 'zoom') { $url = self::get('zoom.oauth_url') . '?grant_type=account_credentials&account_id=' . rawurlencode(self::get('zoom.account_id')); [$st, $b, $err] = self::http('POST', $url, ['Authorization: Basic ' . base64_encode(self::get('zoom.client_id') . ':' . self::get('zoom.client_secret'))]); }
        else { [$st, $b, $err] = self::http('POST', rtrim(self::get('teams.login_base'), '/') . '/' . rawurlencode(self::get('teams.tenant_id')) . '/oauth2/v2.0/token', [], ['client_id' => self::get('teams.client_id'), 'client_secret' => self::get('teams.client_secret'), 'scope' => 'https://graph.microsoft.com/.default', 'grant_type' => 'client_credentials'], false); }
        if ($st !== 200 || !is_array($b) || empty($b['access_token'])) { self::log($p, 'token', false, $st, self::errMsg($st, $b, $err)); throw new \RuntimeException(ucfirst($p) . ' : authentification refusée (' . self::errMsg($st, $b, $err) . ').'); }
        Settings::set($key, json_encode(['t' => Secret::enc($b['access_token']), 'exp' => time() + (int)($b['expires_in'] ?? 3000)])); return $b['access_token'];
    }
    private static function call(string $p, string $action, string $method, string $url, $body = null): array {
        $try = function () use ($p, $method, $url, $body) { return self::http($method, $url, ['Authorization: Bearer ' . self::token($p), 'Accept: application/json'], $body); };
        [$st, $b, $err] = $try(); if ($st === 401) { Settings::set('integ.' . $p . '.tok', ''); [$st, $b, $err] = $try(); }
        $ok = $st >= 200 && $st < 300; self::log($p, $action, $ok, $st, $ok ? 'OK' : self::errMsg($st, $b, $err)); if (!$ok) throw new \RuntimeException(ucfirst($p) . ' : ' . self::errMsg($st, $b, $err)); return is_array($b) ? $b : [];
    }
    private static function iso(string $local, int $addMin = 0): string { return gmdate('Y-m-d\TH:i:s\Z', strtotime($local) + $addMin * 60); }
    /** Crée la réunion chez le prestataire. @return array{0:string,1:string,2:string} lien, identifiant, téléphone/pont éventuel */
    static function createMeeting(string $p, string $title, string $startLocal, int $dur, string $agenda = ''): array {
        if (!self::ready($p)) throw new \RuntimeException(ucfirst($p) . ' : intégration non configurée.');
        if ($p === 'zoom') { $r = self::call('zoom', 'create', 'POST', rtrim(self::get('zoom.api_base'), '/') . '/users/' . rawurlencode(self::get('zoom.host')) . '/meetings', ['topic' => $title, 'type' => 2, 'start_time' => self::iso($startLocal), 'duration' => $dur, 'timezone' => 'UTC', 'agenda' => mb_substr($agenda, 0, 1900), 'settings' => ['join_before_host' => true, 'waiting_room' => false]]);
            if (empty($r['join_url'])) throw new \RuntimeException('Zoom : réponse sans lien de réunion.'); return [(string)$r['join_url'], (string)($r['id'] ?? ''), (string)($r['password'] ?? '') !== '' ? 'Code : ' . $r['password'] : '']; }
        $r = self::call('teams', 'create', 'POST', rtrim(self::get('teams.graph_base'), '/') . '/users/' . rawurlencode(self::get('teams.organizer')) . '/onlineMeetings', ['subject' => $title, 'startDateTime' => self::iso($startLocal), 'endDateTime' => self::iso($startLocal, $dur)]);
        if (empty($r['joinWebUrl'])) throw new \RuntimeException('Teams : réponse sans lien de réunion.'); return [(string)$r['joinWebUrl'], (string)($r['id'] ?? ''), (string)($r['audioConferencing']['tollNumber'] ?? '')];
    }
    static function updateMeeting(string $p, string $id, string $title, string $startLocal, int $dur, string $agenda = ''): void {
        if (!self::ready($p) || $id === '') return;
        if ($p === 'zoom') self::call('zoom', 'update', 'PATCH', rtrim(self::get('zoom.api_base'), '/') . '/meetings/' . rawurlencode($id), ['topic' => $title, 'start_time' => self::iso($startLocal), 'duration' => $dur, 'timezone' => 'UTC', 'agenda' => mb_substr($agenda, 0, 1900)]);
        else self::call('teams', 'update', 'PATCH', rtrim(self::get('teams.graph_base'), '/') . '/users/' . rawurlencode(self::get('teams.organizer')) . '/onlineMeetings/' . rawurlencode($id), ['subject' => $title, 'startDateTime' => self::iso($startLocal), 'endDateTime' => self::iso($startLocal, $dur)]);
    }
    static function deleteMeeting(string $p, string $id): void {
        if (!self::ready($p) || $id === '') return;
        if ($p === 'zoom') self::call('zoom', 'delete', 'DELETE', rtrim(self::get('zoom.api_base'), '/') . '/meetings/' . rawurlencode($id));
        else self::call('teams', 'delete', 'DELETE', rtrim(self::get('teams.graph_base'), '/') . '/users/' . rawurlencode(self::get('teams.organizer')) . '/onlineMeetings/' . rawurlencode($id));
    }
    /** Envoie un message WhatsApp (modèle approuvé ou texte libre selon le mode). $vars : valeurs {{1}}…{{4}} du modèle. */
    static function waSend(string $phone, string $text, array $vars = []): void {
        if (!self::ready('wa')) throw new \RuntimeException('WhatsApp : intégration non configurée.');
        $to = preg_replace('/\D+/', '', (string)Sms::normalize($phone)); if ($to === '') throw new \RuntimeException('WhatsApp : numéro invalide.');
        $body = ['messaging_product' => 'whatsapp', 'to' => $to];
        if (self::get('wa.mode') === 'template') { $body += ['type' => 'template', 'template' => ['name' => self::get('wa.template'), 'language' => ['code' => self::get('wa.lang') ?: 'fr'], 'components' => [['type' => 'body', 'parameters' => array_map(fn($v) => ['type' => 'text', 'text' => mb_substr(str_replace(["\n", "\t"], ' ', (string)$v), 0, 400)], array_values($vars))]]]]; }
        else $body += ['type' => 'text', 'text' => ['preview_url' => true, 'body' => mb_substr($text, 0, 1000)]];
        $r = self::http('POST', rtrim(self::get('wa.api_base'), '/') . '/' . rawurlencode(self::get('wa.phone_id')) . '/messages', ['Authorization: Bearer ' . self::get('wa.token')], $body); [$st, $b, $err] = $r;
        $ok = $st >= 200 && $st < 300; self::log('wa', 'send', $ok, $st, $ok ? 'OK' : self::errMsg($st, $b, $err)); if (!$ok) throw new \RuntimeException('WhatsApp : ' . self::errMsg($st, $b, $err));
    }
    /** Test de connexion depuis la page de configuration. @return array{0:bool,1:string} */
    static function test(string $p): array {
        try {
            if ($p === 'wa') { if (!self::ready('wa')) return [false, 'Configuration incomplète ou désactivée.']; [$st, $b, $err] = self::http('GET', rtrim(self::get('wa.api_base'), '/') . '/' . rawurlencode(self::get('wa.phone_id')), ['Authorization: Bearer ' . self::get('wa.token')]); $ok = $st === 200; self::log('wa', 'test', $ok, $st, $ok ? 'OK' : self::errMsg($st, $b, $err)); return [$ok, $ok ? 'Connexion WhatsApp Cloud API valide' . (is_array($b) && !empty($b['display_phone_number']) ? ' (numéro ' . $b['display_phone_number'] . ').' : '.') : self::errMsg($st, $b, $err)]; }
            if (!self::ready($p)) return [false, 'Configuration incomplète ou désactivée.'];
            Settings::set('integ.' . $p . '.tok', ''); self::token($p); self::log($p, 'test', true, 200, 'OK'); return [true, 'Authentification ' . ($p === 'zoom' ? 'Zoom' : 'Microsoft Graph') . ' réussie (jeton obtenu).'];
        } catch (\Throwable $e) { return [false, $e->getMessage()]; }
    }
}
