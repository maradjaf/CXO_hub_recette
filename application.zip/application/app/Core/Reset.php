<?php
namespace App\Core;
/** Liens de mot de passe à usage unique (réinitialisation ou invitation). Seul l'empreinte du jeton est stockée. */
class Reset {
    const TTL_HOURS = 24;
    static function issue(int $userId, string $purpose = 'reset', ?int $by = null): string {
        DB::exec('UPDATE pw_tokens SET used_at=? WHERE user_id=? AND used_at IS NULL', [now(), $userId]);
        $tok = bin2hex(random_bytes(24));
        DB::insert('pw_tokens', ['user_id' => $userId, 'token_hash' => hash('sha256', $tok), 'purpose' => $purpose, 'expires_at' => date('Y-m-d H:i:s', time() + 3600 * self::TTL_HOURS), 'created_by' => $by, 'created_at' => now()]);
        return $tok;
    }
    static function find(string $tok): ?array {
        if (!preg_match('/^[a-f0-9]{48}$/', $tok)) return null;
        $t = DB::one('SELECT t.*, u.name, u.email, u.status FROM pw_tokens t JOIN users u ON u.id=t.user_id WHERE t.token_hash=?', [hash('sha256', $tok)]);
        if (!$t || $t['used_at'] || strtotime($t['expires_at']) < time()) return null;
        return $t;
    }
    /** Lien affichable : APP_URL si défini, sinon l'adresse de la requête (affichage à l'administrateur seulement). */
    static function link(string $tok): string {
        $base = rtrim((string)env('APP_URL', ''), '/');
        if ($base !== '') return $base . '/reset/' . $tok;
        return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . preg_replace('/[^A-Za-z0-9.:\-\[\]]/', '', $_SERVER['HTTP_HOST'] ?? 'localhost') . url('reset/' . $tok);
    }
    /** Envoie le lien par e-mail si le courrier est configuré ; retourne true si mis en file. */
    static function mail(array $u, string $tok, string $purpose): bool {
        if (!Mailer::enabled()) return false;
        if ((string)env('APP_URL', '') === '') return false; $link = self::link($tok);
        return Mailer::queue($u['email'], $purpose === 'invite' ? 'Activez votre compte' : 'Réinitialisation de votre mot de passe', "Bonjour {$u['name']},\n\nUtilisez ce lien pour choisir un nouveau mot de passe (valable " . self::TTL_HOURS . " h, usage unique) :\n$link\n\nSi vous n'êtes pas à l'origine de cette demande, ignorez ce message.");
    }
}
