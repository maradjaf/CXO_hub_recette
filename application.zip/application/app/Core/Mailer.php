<?php
namespace App\Core;
/**
 * Envoi d'e-mails par SMTP (sockets PHP, sans bibliothèque). Les messages passent par une file (at_outbox) vidée par bin/mail-send.php,
 * pour qu'une panne du serveur de messagerie ne bloque jamais une action de l'utilisateur.
 * Activé uniquement si SMTP_HOST est renseigné. Variables : SMTP_HOST, SMTP_PORT, SMTP_SECURE (tls|ssl|none), SMTP_USER, SMTP_PASS,
 * SMTP_VERIFY_PEER (1 par défaut), MAIL_FROM, MAIL_FROM_NAME, APP_URL.
 */
class Mailer {
    static function enabled(): bool { return (string)env('SMTP_HOST', '') !== ''; }
    private static function clean(string $s): string { return trim(preg_replace('/[\r\n\x00]+/', ' ', $s)); }
    /** Met un message en file d'envoi ; retourne false si l'envoi est désactivé ou l'adresse invalide. */
    static function queue(string $to, string $subject, string $body, ?int $ticketId = null, ?string $ics = null): bool {
        $to = strtolower(self::clean($to));
        if (!self::enabled() || !filter_var($to, FILTER_VALIDATE_EMAIL)) return false;
        DB::insert('at_outbox', ['to_email' => $to, 'subject' => mb_substr(self::clean($subject), 0, 250), 'body' => mb_substr($body, 0, 20000), 'status' => 'pending', 'tries' => 0, 'ticket_id' => $ticketId, 'created_at' => now(), 'ics' => $ics]);
        return true;
    }
    /** Met en file la notification d'un ticket pour un utilisateur (objet : « [AT-yy-nnnnn] titre »). */
    static function queueTicketNotice(int $userId, string $title, string $body, int $ticketId): void {
        if (!self::enabled()) return;
        $u = DB::one("SELECT email, name FROM users WHERE id=? AND status='active'", [$userId]); $t = DB::one('SELECT reference, title FROM at_tickets WHERE id=?', [$ticketId]);
        if (!$u || !$t) return;
        $subj = str_contains($title, $t['reference']) ? $title : '[' . $t['reference'] . '] ' . $title;
        $link = (string)env('APP_URL', '') !== '' ? "\n\n" . rtrim((string)env('APP_URL'), '/') . '/at/' . $ticketId : '';
        $txt = "Bonjour {$u['name']},\n\n$title\n" . ($body !== '' ? "$body\n" : '') . "\nTicket : {$t['reference']} - {$t['title']}$link\n\nPour répondre, répondez à ce message sans modifier l'objet (la référence du ticket doit y rester).\nMessage automatique de l'assistance technique.";
        self::queue($u['email'], $subj, $txt, $ticketId);
    }
    /** Envoie les messages en attente (5 essais maximum, un message en échec n'arrête pas les autres). @return array{0:int,1:int} envoyés, en échec */
    static function flush(int $limit = 50): array {
        $ok = 0; $ko = 0;
        foreach (DB::all("SELECT * FROM at_outbox WHERE status='pending' AND tries<5 ORDER BY id LIMIT " . (int)$limit) as $m) {
            try {
                self::deliver($m['to_email'], $m['subject'], $m['body'], $m['ics'] ?? null);
                DB::update('at_outbox', ['status' => 'sent', 'tries' => (int)$m['tries'] + 1, 'sent_at' => now(), 'last_error' => null], 'id=?', [(int)$m['id']]); $ok++;
            } catch (\Throwable $e) {
                $n = (int)$m['tries'] + 1; DB::update('at_outbox', ['tries' => $n, 'status' => $n >= 5 ? 'failed' : 'pending', 'last_error' => mb_substr($e->getMessage(), 0, 300)], 'id=?', [(int)$m['id']]); $ko++;
            }
        }
        return [$ok, $ko];
    }
    /** Construit le message MIME (en-têtes UTF-8 encodés, corps en base64, « Auto-Submitted » pour éviter les boucles de réponse). */
    static function build(string $to, string $subject, string $body, ?string $ics = null): string {
        $from = self::clean((string)env('MAIL_FROM', '')); $name = self::clean((string)env('MAIL_FROM_NAME', (string)env('APP_NAME', 'Assistance technique')));
        $enc = fn(string $s) => preg_match('/[^\x20-\x7e]/', $s) ? '=?UTF-8?B?' . base64_encode($s) . '?=' : $s;
        $h = ['Date: ' . date('r'), 'From: ' . $enc($name) . ' <' . $from . '>', 'To: ' . self::clean($to), 'Subject: ' . $enc(self::clean($subject)),
              'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . (substr(strrchr($from, '@') ?: '@localhost', 1) ?: 'localhost') . '>', 'MIME-Version: 1.0'];
        $b64 = fn(string $t) => chunk_split(base64_encode(str_replace("\r\n", "\n", $t)), 76, "\r\n");
        $tail = ['Auto-Submitted: auto-generated', 'X-Auto-Response-Suppress: All'];
        if ($ics === null || $ics === '') return implode("\r\n", array_merge($h, ['Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: base64'], $tail)) . "\r\n\r\n" . $b64($body);
        $bd = '=_cxo_' . bin2hex(random_bytes(8)); $method = preg_match('/^METHOD:([A-Z]+)/m', $ics, $mm) ? $mm[1] : 'REQUEST';
        return implode("\r\n", array_merge($h, ["Content-Type: multipart/mixed; boundary=\"$bd\""], $tail)) . "\r\n\r\n--$bd\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . $b64($body)
            . "--$bd\r\nContent-Type: text/calendar; charset=UTF-8; method=$method; name=\"invitation.ics\"\r\nContent-Disposition: attachment; filename=\"invitation.ics\"\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($ics), 76, "\r\n") . "--$bd--\r\n";
    }
    private static function read($fp): array {
        $code = ''; $txt = [];
        while (($l = fgets($fp, 2048)) !== false) { $txt[] = rtrim($l); if (strlen($l) < 4 || $l[3] !== '-') { $code = substr($l, 0, 3); break; } }
        if ($code === '') throw new \RuntimeException('Connexion SMTP interrompue.');
        return [(int)$code, implode("\n", $txt)];
    }
    private static function cmd($fp, string $c, array $expect): array {
        fwrite($fp, $c . "\r\n"); $r = self::read($fp);
        if (!in_array($r[0], $expect, true)) throw new \RuntimeException('SMTP : réponse inattendue (' . $r[0] . ') ' . mb_substr(preg_replace('/\s+/', ' ', $r[1]), 0, 120));
        return $r;
    }
    static function deliver(string $to, string $subject, string $body, ?string $ics = null): void {
        $host = (string)env('SMTP_HOST'); $sec = strtolower((string)env('SMTP_SECURE', 'tls')); $port = (int)env('SMTP_PORT', $sec === 'ssl' ? 465 : ($sec === 'none' ? 25 : 587));
        $from = self::clean((string)env('MAIL_FROM', '')); if (!filter_var($from, FILTER_VALIDATE_EMAIL)) throw new \RuntimeException('MAIL_FROM absent ou invalide.');
        $to = self::clean($to); if (!filter_var($to, FILTER_VALIDATE_EMAIL)) throw new \RuntimeException('Destinataire invalide.');
        $verify = (string)env('SMTP_VERIFY_PEER', '1') !== '0';
        $ctx = stream_context_create(['ssl' => ['verify_peer' => $verify, 'verify_peer_name' => $verify, 'peer_name' => $host]]);
        $fp = @stream_socket_client(($sec === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port, $en, $es, 15, STREAM_CLIENT_CONNECT, $ctx);
        if (!$fp) throw new \RuntimeException("Connexion SMTP impossible ($host:$port) : $es");
        stream_set_timeout($fp, 20);
        try {
            $r = self::read($fp); if ($r[0] !== 220) throw new \RuntimeException('SMTP : accueil inattendu.');
            $me = preg_replace('/[^A-Za-z0-9.-]/', '', (string)(gethostname() ?: 'localhost')) ?: 'localhost';
            $ehlo = self::cmd($fp, "EHLO $me", [250]);
            if ($sec === 'tls') {
                self::cmd($fp, 'STARTTLS', [220]);
                if (!@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new \RuntimeException('SMTP : négociation TLS refusée.');
                $ehlo = self::cmd($fp, "EHLO $me", [250]);
            }
            $user = (string)env('SMTP_USER', '');
            if ($user !== '') {
                if (preg_match('/AUTH[ =].*\bPLAIN\b/i', $ehlo[1]) && !preg_match('/AUTH[ =].*\bLOGIN\b/i', $ehlo[1])) self::cmd($fp, 'AUTH PLAIN ' . base64_encode("\0$user\0" . (string)env('SMTP_PASS', '')), [235]);
                else { self::cmd($fp, 'AUTH LOGIN', [334]); self::cmd($fp, base64_encode($user), [334]); self::cmd($fp, base64_encode((string)env('SMTP_PASS', '')), [235]); }
            }
            self::cmd($fp, "MAIL FROM:<$from>", [250]); self::cmd($fp, "RCPT TO:<$to>", [250, 251]); self::cmd($fp, 'DATA', [354]);
            $msg = preg_replace('/^\./m', '..', self::build($to, $subject, $body, $ics));
            fwrite($fp, $msg . "\r\n.\r\n"); $r = self::read($fp); if ($r[0] !== 250) throw new \RuntimeException('SMTP : message refusé (' . $r[0] . ').');
            @fwrite($fp, "QUIT\r\n");
        } finally { @fclose($fp); }
    }
}
