<?php
namespace App\Core;
/** Contrats RH : modèles à variables, rédaction, signature électronique par lien personnel, partage par e-mail, PDF. */
final class Ct {
    const DOC = ['none' => 'Pas de document', 'draft' => 'Brouillon', 'to_sign' => 'En signature', 'signed' => 'Signé', 'cancelled' => 'Annulé'];
    const DOC_COLOR = ['none' => 'secondary', 'draft' => 'secondary', 'to_sign' => 'warning', 'signed' => 'success', 'cancelled' => 'dark'];
    const ROLES = ['Employeur', 'Collaborateur', 'Témoin', 'Autre partie'];
    const KNOWN = ['nom_complet' => 'Nom complet du collaborateur', 'prenom' => 'Prénom', 'nom' => 'Nom', 'matricule' => 'Matricule', 'email' => 'E-mail', 'telephone' => 'Téléphone',
        'poste' => 'Poste', 'fonction' => 'Fonction', 'equipe' => 'Équipe', 'boutique' => 'Boutique / store', 'type_contrat' => 'Type de contrat', 'date_debut' => 'Date de début', 'date_fin' => 'Date de fin',
        'duree' => 'Durée', 'date_embauche' => 'Date d\'embauche', 'date_jour' => 'Date du jour', 'entreprise' => 'Entreprise', 'employeur' => 'Employeur (société)', 'representant' => 'Représentant de l\'employeur (nom, poste)', 'lieu' => 'Lieu de signature',
        'slogan' => 'Slogan de la société', 'secteur' => 'Secteur d\'activité', 'forme_juridique' => 'Forme juridique', 'capital' => 'Capital', 'rccm' => 'N° RCCM', 'nif' => 'N° NIF', 'cnss' => 'N° CNSS', 'siege' => 'Adresse du siège social',
        'tel_societe' => 'Téléphone de la société', 'email_societe' => 'E-mail de la société', 'dirigeant_poste' => 'Poste du premier responsable', 'dirigeant_nom' => 'Nom et prénoms du premier responsable', 'rh_poste' => 'Poste du responsable RH', 'rh_nom' => 'Nom et prénoms du responsable RH',
        'societe_accueil' => 'Société d\'accueil / lieu d\'affectation'];

    /** Valeurs connues pour un contrat et son collaborateur. */
    static function values(array $c): array {
        $e = DB::one('SELECT e.*, p.name pos, t.name team, s.name store, s.city FROM employees e LEFT JOIN positions p ON p.id=e.position_id LEFT JOIN teams t ON t.id=e.team_id LEFT JOIN stores s ON s.id=e.store_id WHERE e.id=?', [(int)$c['employee_id']]) ?: [];
        $type = (string)DB::val("SELECT v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='contract_types' AND v.code=?", [$c['type']]) ?: (string)$c['type'];
        $dur = '';
        if (!empty($c['end_date']) && !empty($c['start_date'])) { $a = new \DateTime($c['start_date']); $b = new \DateTime($c['end_date']); $df = $a->diff($b); $m = $df->y * 12 + $df->m; $dur = $m > 0 ? $m . ' mois' . ($df->d ? ' et ' . $df->d . ' jour(s)' : '') : $df->days . ' jour(s)'; } else $dur = 'indéterminée';
        $co = (string)setting('company_name', (string)setting('app.name', 'CXO Excellence Hub'));
        return ['nom_complet' => trim(($e['first_name'] ?? '') . ' ' . mb_strtoupper((string)($e['last_name'] ?? ''))), 'prenom' => $e['first_name'] ?? '', 'nom' => mb_strtoupper((string)($e['last_name'] ?? '')), 'matricule' => $e['matricule'] ?? '',
            'email' => $e['email'] ?? '', 'telephone' => $e['phone'] ?? '', 'poste' => $e['pos'] ?? '', 'fonction' => $e['job_function'] ?? '', 'equipe' => $e['team'] ?? '', 'boutique' => $e['store'] ?? '', 'type_contrat' => $type,
            'date_debut' => !empty($c['start_date']) ? d($c['start_date']) : '', 'date_fin' => !empty($c['end_date']) ? d($c['end_date']) : 'indéterminée', 'duree' => $dur, 'date_embauche' => !empty($e['hire_date']) ? d($e['hire_date']) : '',
            'date_jour' => date('d/m/Y'), 'entreprise' => $co, 'lieu' => (string)($e['city'] ?? '') ?: (string)setting('company_city', ''),
            'societe_accueil' => ($e['placement'] ?? '') === 'other' ? (string)($e['host_company'] ?? '') : (!empty($e['employer']) && DB::val("SELECT 1 FROM employers WHERE code=? AND kind<>'own'", [$e['employer']]) ? 'Yas Togo (intérim)' : '')] + self::employerVars($c, $e) + ['representant' => (string)(Auth::user()['name'] ?? '')];
    }
    /** Code de la société employeuse d'un contrat (celui du contrat, sinon celui du collaborateur). */
    static function employerCode(array $c, ?array $e = null): ?string {
        if (!empty($c['employer_code'])) return (string)$c['employer_code'];
        $e = $e ?? DB::one('SELECT employer FROM employees WHERE id=?', [(int)($c['employee_id'] ?? 0)]); $x = (string)($e['employer'] ?? ''); return $x !== '' ? $x : null;
    }
    static function employerVars(array $c, ?array $e = null): array { $v = Brand::vars(self::employerCode($c, $e)); if (trim($v['representant']) === '') unset($v['representant']); return $v; }
    /** Variables {{x}} présentes dans un texte. */
    static function placeholders(string $body): array { preg_match_all('/\{\{\s*([a-z0-9_]+)\s*\}\}/i', $body, $m); return array_values(array_unique(array_map('strtolower', $m[1]))); }
    const BLANK = '……………';
    static function hasBlank(string $body): bool { return str_contains($body, self::BLANK) || (bool)self::placeholders($body); }
    static function render(string $body, array $vals): string {
        return (string)preg_replace_callback('/\{\{\s*([a-z0-9_]+)\s*\}\}/i', function ($m) use ($vals) { $k = strtolower($m[1]); return (isset($vals[$k]) && trim((string)$vals[$k]) !== '') ? (string)$vals[$k] : self::BLANK; }, $body);
    }
    static function hash(array $c): string { return hash('sha256', $c['id'] . '|' . $c['title'] . '|' . $c['body']); }
    static function abs(string $path): string {
        $b = rtrim((string)env('APP_URL', ''), '/');
        if ($b === '' && !empty($_SERVER['HTTP_HOST'])) $b = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
        return $b . url(ltrim($path, '/'));
    }
    static function token(): string { return bin2hex(random_bytes(24)); }
    /** Met un e-mail en file et tente l'envoi ; false si l'envoi n'est pas configuré. */
    static function mail(string $to, string $subject, string $body): bool {
        $ok = Mailer::queue($to, $subject, $body);
        if ($ok) { try { Mailer::flush(10); } catch (\Throwable $e) {} }
        return $ok;
    }
    static function signers(int $cid): array { return DB::all('SELECT * FROM ct_signers WHERE contract_id=? ORDER BY position, id', [$cid]); }
    /** Passe le contrat à « signé » quand tous les signataires ont signé. */
    static function refresh(int $cid): bool {
        $c = DB::one('SELECT * FROM contracts WHERE id=?', [$cid]); if (!$c || $c['doc_status'] !== 'to_sign') return false;
        $left = (int)DB::val("SELECT COUNT(*) FROM ct_signers WHERE contract_id=? AND status<>'signed'", [$cid]); $n = (int)DB::val('SELECT COUNT(*) FROM ct_signers WHERE contract_id=?', [$cid]);
        if ($n && !$left) { DB::update('contracts', ['doc_status' => 'signed', 'signed_at' => now()], 'id=?', [$cid]); if ($c['status'] === 'planned') CtFlow::activate($cid); return true; }
        return false;
    }
    /** PDF du contrat : texte, puis tableau des signatures avec code de vérification. */
    static function pdf(array $c): string {
        $e = DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [(int)$c['employee_id']]) ?: ['first_name' => '', 'last_name' => ''];
        $pd = new PdfDoc(595, 842, 54, 'Contrat n° ' . $c['id'], ''); $pd->brand(self::brandPaths(self::employerCode($c)));
        $pd->title((string)($c['title'] ?: 'Contrat'), 16); $pd->gap(6);
        foreach (preg_split('/\R/u', (string)$c['body']) as $l) {
            $l = rtrim($l); if (trim($l) === '') { $pd->gap(5); continue; }
            if (preg_match('/^#{2,3}\s+(.+)$/u', $l, $m)) { $pd->h2($m[1]); continue; }
            if (preg_match('/^\s*[-*]\s+(.+)$/u', $l, $m)) $l = '•  ' . $m[1];
            $pd->para(str_replace(['**', '`'], '', $l), 10);
        }
        $pd->gap(14); $pd->h2('Signatures électroniques');
        $rows = []; foreach (self::signers((int)$c['id']) as $s) $rows[] = [$s['role'], $s['signed_name'] ?: $s['name'], $s['status'] === 'signed' ? 'Signé' : ($s['status'] === 'rejected' ? 'Refusé' : 'En attente'), $s['signed_at'] ? dt($s['signed_at']) : '', $s['ip'] ?: '', $s['doc_hash'] ? substr($s['doc_hash'], 0, 16) : ''];
        $pd->table(['Qualité', 'Signataire', 'Statut', 'Date', 'Adresse IP', 'Empreinte'], $rows, [2, 3, 2, 3, 3, 3]);
        if ($c['verify_code']) $pd->para('Code de vérification : ' . $c['verify_code'] . '  ·  ' . self::abs('ct/verify/' . $c['verify_code']), 8, '6B7C93');
        $pd->para('Signature électronique simple : le signataire a confirmé son identité par le lien personnel reçu à son adresse e-mail ; l\'empreinte atteste que le texte signé n\'a pas été modifié.', 8, '6B7C93');
        return $pd->output();
    }
    /** Éléments d'en-tête et de pied de page résolus en chemins de fichiers. */
    static function brandPaths(?string $code): array {
        $b = Brand::forEmployer($code); foreach (['logo', 'header_img', 'footer_img'] as $k) $b[$k] = Brand::path($b[$k]);
        return $b;
    }
    static function pdfOut(array $c, string $name): never {
        $out = self::pdf($c); header('Content-Type: application/pdf'); header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9_.-]/', '_', $name) . '.pdf"'); header('X-Content-Type-Options: nosniff'); header('Content-Length: ' . strlen($out)); echo $out; exit;
    }
}
