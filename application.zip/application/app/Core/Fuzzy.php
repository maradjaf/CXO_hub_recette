<?php
namespace App\Core;
/** Recherche tolérante aux fautes de frappe et aux accents (repli lorsque la recherche exacte ne trouve rien ou presque). */
class Fuzzy {
    /** Minuscules, sans accents ni ponctuation. */
    static function fold(string $s): string {
        $s = mb_strtolower($s);
        $t = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
        if ($t === false || $t === '') $t = $s;
        $t = preg_replace('/[^a-z0-9]+/', ' ', str_replace(["'", '`', '^', '~', '"'], '', $t));
        return trim((string)$t);
    }
    /** Mots de la requête (2 caractères minimum). */
    static function terms(string $q): array { return array_slice(array_values(array_filter(explode(' ', self::fold($q)), fn($t) => strlen($t) >= 2)), 0, 6); }
    /** Distance acceptée selon la longueur du mot : 0 (très court), 1, puis 2. */
    static function tol(string $t): int { $n = strlen($t); return $n <= 3 ? 0 : ($n <= 7 ? 1 : 2); }
    /** Score d'un texte pour une requête : 0 si un mot n'est trouvé nulle part, sinon 0-100 (plus haut = plus proche). */
    static function score(array $terms, string $text): float {
        if (!$terms) return 0; $words = array_unique(array_filter(explode(' ', self::fold($text)))); $flat = ' ' . implode(' ', $words) . ' '; $sum = 0.0;
        foreach ($terms as $t) {
            $best = 0.0;
            if (str_contains($flat, $t)) $best = str_contains($flat, ' ' . $t . ' ') ? 100 : 85;
            else {
                $tol = self::tol($t);
                foreach ($words as $w) {
                    if (abs(strlen($w) - strlen($t)) > $tol + 1) continue;
                    $d = levenshtein($t, $w); if ($d <= $tol) $best = max($best, 80 - 15 * $d);
                    elseif (strlen($t) >= 5 && strlen($w) >= strlen($t) && levenshtein($t, substr($w, 0, strlen($t))) <= $tol) $best = max($best, 60);   // début de mot avec faute
                    if ($best >= 80) break;
                }
            }
            if ($best <= 0) return 0; $sum += $best;
        }
        return round($sum / count($terms), 1);
    }
    /** Filtre et classe des lignes : $textOf(ligne) renvoie les textes cherchés (le premier compte double). @return array[] avec la clé _score */
    static function rank(array $rows, string $q, callable $textOf, int $limit = 50): array {
        $terms = self::terms($q); if (!$terms) return [];
        $out = [];
        foreach ($rows as $r) { $tx = (array)$textOf($r); $s = self::score($terms, implode(' ', $tx)); if ($s > 0 && isset($tx[0])) $s += min(10, self::score($terms, (string)$tx[0]) / 10); if ($s > 0) { $r['_score'] = $s; $out[] = $r; } }
        usort($out, fn($a, $b) => $b['_score'] <=> $a['_score']);
        return array_slice($out, 0, $limit);
    }
}
