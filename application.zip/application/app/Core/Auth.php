<?php
namespace App\Core;
class Auth {
    private static ?array $perms = null;
    static function id(): ?int { return $_SESSION['uid'] ?? null; }
    static function check(): bool { return self::id() !== null; }
    static function user(): ?array {
        static $u = false;
        if ($u === false) $u = self::id() ? DB::one('SELECT * FROM users WHERE id=?', [self::id()]) : null;
        return $u;
    }
    static function roles(): array {
        if (!self::id()) return [];
        return DB::all('SELECT r.code, r.name FROM roles r JOIN user_roles ur ON ur.role_id=r.id WHERE ur.user_id=?', [self::id()]);
    }
    static function permissions(): array {
        if (self::$perms === null) {
            self::$perms = [];
            if (self::id()) {
                foreach (self::roles() as $r) if ($r['code'] === 'admin') self::$perms['*'] = true;
                foreach (DB::all('SELECT p.code FROM permissions p JOIN role_permissions rp ON rp.permission_id=p.id JOIN user_roles ur ON ur.role_id=rp.role_id WHERE ur.user_id=?', [self::id()]) as $p) self::$perms[$p['code']] = true;
            }
        }
        return self::$perms;
    }
    static function can(string $perm): bool { $p = self::permissions(); return isset($p['*']) || isset($p[$perm]); }
    static function attempt(string $email, string $password): array {
        $ip = Request::ip();
        $u = DB::one('SELECT * FROM users WHERE email=?', [strtolower(trim($email))]);
        DB::insert('login_attempts', ['email' => strtolower(trim($email)), 'ip' => $ip, 'success' => 0, 'created_at' => now()]);
        if (!$u) return ['ok' => false, 'msg' => 'Identifiant ou mot de passe incorrect.', 'user' => null, 'reason' => 'unknown_account'];
        if ($u['status'] === 'blocked') return ['ok' => false, 'msg' => 'Ce compte est bloqué. Contactez votre responsable ou l\'administrateur.', 'user' => $u, 'reason' => 'blocked_account'];
        if ($u['status'] !== 'active') return ['ok' => false, 'msg' => "Ce compte est désactivé. Contactez l'administrateur.", 'user' => $u, 'reason' => 'inactive_account'];
        if ($u['locked_until'] && strtotime($u['locked_until']) > time()) return ['ok' => false, 'msg' => 'Compte verrouillé après plusieurs échecs. Réessayez à ' . date('H:i', strtotime($u['locked_until'])) . '.', 'user' => $u, 'reason' => 'locked_account'];
        if (!password_verify($password, $u['password_hash'])) {
            $n = (int)$u['failed_attempts'] + 1;
            $lock = $n >= (int)setting('security.max_attempts', 5) ? date('Y-m-d H:i:s', time() + 60 * (int)setting('security.lock_minutes', 15)) : null;
            DB::update('users', ['failed_attempts' => $n, 'locked_until' => $lock], 'id=?', [$u['id']]);
            return ['ok' => false, 'msg' => 'Identifiant ou mot de passe incorrect.', 'user' => $u, 'reason' => 'bad_password'];
        }
        DB::update('users', ['failed_attempts' => 0, 'locked_until' => null, 'last_login_at' => now(), 'last_ip' => $ip], 'id=?', [$u['id']]);
        session_regenerate_id(true);
        $_SESSION['uid'] = (int)$u['id'];
        return ['ok' => true, 'msg' => '', 'user' => $u];
    }
    /** Nombre d'échecs de connexion récents depuis une adresse IP. */
    static function recentFailures(string $ip, int $minutes = 15): int { return (int)DB::val('SELECT COUNT(*) FROM login_attempts WHERE ip=? AND success=0 AND created_at>=?', [$ip, date('Y-m-d H:i:s', time() - 60 * $minutes)]); }
    static function logout(): void { $_SESSION = []; session_destroy(); }
}
