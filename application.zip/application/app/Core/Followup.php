<?php
namespace App\Core;

/** Lot 68 : file d'appels de rappel — suivi des clients détracteurs ou très insatisfaits (délai, tentatives, escalade, journal). */
class Followup {
    const KIND = ['detractor' => 'Détracteur (NPS)', 'lowcsat' => 'Satisfaction faible', 'lowadv' => 'Conseiller mal noté', 'nocontact' => 'Sans réponse à rappeler', 'manual' => 'Ajout manuel'];
    const STATUS = ['todo' => 'À appeler', 'doing' => 'En cours', 'done' => 'Clos', 'unreachable' => 'Injoignable', 'cancelled' => 'Annulé'];
    const OUTCOME = ['resolved' => 'Problème résolu', 'explained' => 'Explication donnée', 'escalated' => 'Transmis à un service', 'refused' => 'Client ne souhaite pas être rappelé', 'noaction' => 'Aucune action nécessaire'];
    const RESULT = ['reached' => 'Client joint', 'noanswer' => 'Pas de réponse', 'busy' => 'Occupé', 'wrong' => 'Numéro erroné', 'callback' => 'Rappel demandé'];
    const DEFAULTS = ['auto' => '1', 'csat_max' => '2', 'adv_max' => '2', 'sla_hours' => '48', 'max_attempts' => '3', 'retry_hours' => '4'];
    static function cfg(string $k): int { return (int)setting('sv.fu.' . $k, self::DEFAULTS[$k] ?? '0'); }
    static function open(string $a = ''): string { return "{$a}status IN ('todo','doing')"; }
    /** Analyse les nouvelles réponses et crée les rappels nécessaires. @return int nombre de rappels créés */
    static function scan(int $days = 45): int {
        if (!self::cfg('auto')) return 0; $last = (int)setting('sv.fu.last_id', '0'); $dm = Sv::cfg('detractor_max'); $n = 0; $max = $last;
        foreach (DB::all("SELECT * FROM sv_responses WHERE id>? ORDER BY id LIMIT 2000", [$last]) as $r) {
            $max = max($max, (int)$r['id']); if (strtotime((string)$r['answered_at']) < time() - $days * 86400) continue;
            $why = []; $kind = null; $prio = 3;
            if ($r['nps'] !== null && (int)$r['nps'] <= $dm) { $why[] = 'NPS ' . $r['nps'] . '/10'; $kind = 'detractor'; $prio = (int)$r['nps'] <= 3 ? 1 : 2; }
            if ($r['csat'] !== null && (int)$r['csat'] <= self::cfg('csat_max')) { $why[] = 'Satisfaction ' . $r['csat'] . '/5'; $kind = $kind ?: 'lowcsat'; $prio = min($prio, (int)$r['csat'] <= 1 ? 1 : 2); }
            if ($r['advisor'] !== null && (int)$r['advisor'] <= self::cfg('adv_max')) { $why[] = 'Conseiller ' . $r['advisor'] . '/5'; $kind = $kind ?: 'lowadv'; $prio = min($prio, 2); }
            if (!$kind || DB::val('SELECT 1 FROM sv_followups WHERE response_id=?', [(int)$r['id']])) continue;
            if (!empty($r['comment'])) $why[] = '« ' . mb_substr((string)$r['comment'], 0, 120) . ' »';
            self::create(['kind' => $kind, 'priority' => $prio, 'response_id' => (int)$r['id'], 'interaction_id' => $r['interaction_id'], 'survey_id' => $r['survey_id'], 'client_name' => $r['client_name'], 'client_phone' => $r['client_phone'], 'employee_id' => $r['employee_id'], 'team_id' => $r['team_id'], 'store_id' => $r['store_id'], 'reason' => implode(' · ', $why)]); $n++;
        }
        if ($max !== $last) Settings::set('sv.fu.last_id', (string)$max); return $n;
    }
    /** Crée un rappel : échéance selon le délai paramétré (priorité 1 : moitié), affectation automatique au responsable du conseiller. */
    static function create(array $d): int {
        $h = self::cfg('sla_hours') * (($d['priority'] ?? 2) === 1 ? 0.5 : 1); $user = null;
        if (!empty($d['employee_id'])) { $m = (int)DB::val('SELECT manager_id FROM employees WHERE id=?', [(int)$d['employee_id']]); if ($m) $user = DB::val('SELECT id FROM users WHERE employee_id=? ORDER BY id LIMIT 1', [$m]); }
        if (!$user && !empty($d['store_id'])) { $m = (int)DB::val('SELECT lead_employee_id FROM stores WHERE id=?', [(int)$d['store_id']]); if ($m) $user = DB::val('SELECT id FROM users WHERE employee_id=? ORDER BY id LIMIT 1', [$m]); }
        $id = DB::insert('sv_followups', $d + ['status' => 'todo', 'assigned_user_id' => $user ?: null, 'due_at' => date('Y-m-d H:i:s', time() + (int)($h * 3600)), 'created_at' => now()]);
        self::log($id, 'create', null, (string)($d['reason'] ?? ''), 'Système');
        if ($user) Notifier::send((int)$user, 'Client à rappeler', ($d['client_name'] ?: 'Client') . ' — ' . ($d['reason'] ?? ''), '/surveys/followup/' . $id);
        return $id;
    }
    static function log(int $id, string $action, ?string $result = null, string $note = '', ?string $who = null): void {
        DB::insert('sv_followup_logs', ['followup_id' => $id, 'user_id' => Auth::id(), 'user_name' => $who ?? (Auth::user()['name'] ?? 'Système'), 'action' => $action, 'result' => $result, 'note' => mb_substr($note, 0, 1000), 'created_at' => now()]);
    }
    /** Enregistre une tentative d'appel ; au-delà du maximum sans réponse, le rappel passe en « injoignable ». */
    static function attempt(array $f, string $result, string $note, ?int $retryMin = null): string {
        $n = (int)$f['attempts'] + 1; $upd = ['attempts' => $n, 'last_attempt_at' => now(), 'status' => 'doing'];
        if ($result === 'reached') { $upd['next_call_at'] = null; }
        elseif ($result === 'callback') { $upd['next_call_at'] = date('Y-m-d H:i:s', time() + max(15, (int)($retryMin ?: 60)) * 60); }
        elseif ($result === 'wrong') { $upd = ['status' => 'unreachable', 'closed_at' => now()] + $upd; }
        else { if ($n >= self::cfg('max_attempts')) $upd = ['status' => 'unreachable', 'closed_at' => now()] + $upd; else $upd['next_call_at'] = date('Y-m-d H:i:s', time() + self::cfg('retry_hours') * 3600); }
        DB::update('sv_followups', $upd, 'id=?', [(int)$f['id']]); self::log((int)$f['id'], 'call', $result, $note); return $upd['status'];
    }
    static function close(array $f, string $outcome, string $note): void {
        DB::update('sv_followups', ['status' => 'done', 'outcome' => $outcome, 'closed_at' => now(), 'next_call_at' => null], 'id=?', [(int)$f['id']]); self::log((int)$f['id'], 'close', $outcome, $note);
    }
    /** Alerte les responsables qualité pour les rappels dont l'échéance est dépassée (une fois par rappel). */
    static function escalate(): int {
        $n = 0; foreach (DB::all("SELECT * FROM sv_followups WHERE " . self::open() . " AND escalated=0 AND due_at<? ORDER BY id LIMIT 200", [now()]) as $f) {
            DB::update('sv_followups', ['escalated' => 1], 'id=?', [$f['id']]); self::log((int)$f['id'], 'escalate', null, 'Échéance dépassée', 'Système');
            Notifier::toPermission('survey.manage', 'Rappel client en retard', ($f['client_name'] ?: 'Client') . ' — ' . $f['reason'], '/surveys/followup/' . $f['id']); $n++; }
        return $n;
    }
    /** Visibilité : responsables enquêtes (tout), personne affectée, ou périmètre hiérarchique du conseiller concerné. */
    static function visible(array $f): bool {
        if (Auth::can('survey.manage')) return true; if ((int)$f['assigned_user_id'] === (int)Auth::id()) return true;
        return !$f['assigned_user_id'] && $f['employee_id'] && Scope::allows((int)$f['employee_id']);
    }
}
