<?php
namespace App\Core;
/** File d'envoi WhatsApp (API Cloud), vidée par bin/wa-send.php ou le cron des alertes. */
class Wa {
    static function enabled(): bool { return Integ::ready('wa'); }
    static function queue(string $phone, string $kind, string $text, array $vars, ?int $meetingId = null): bool {
        $p = Sms::normalize($phone); if (!$p || !self::enabled()) return false;
        DB::insert('wa_outbox', ['to_phone' => $p, 'kind' => $kind, 'body' => mb_substr($text, 0, 1000), 'params' => mb_substr(json_encode($vars, JSON_UNESCAPED_UNICODE), 0, 1000), 'status' => 'pending', 'tries' => 0, 'meeting_id' => $meetingId, 'created_at' => now()]); return true;
    }
    static function flush(int $limit = 50): array {
        $ok = 0; $ko = 0; if (!self::enabled()) return [0, 0];
        foreach (DB::all("SELECT * FROM wa_outbox WHERE status='pending' AND tries<5 ORDER BY id LIMIT " . (int)$limit) as $m) {
            try { Integ::waSend($m['to_phone'], $m['body'], (array)json_decode((string)$m['params'], true)); DB::update('wa_outbox', ['status' => 'sent', 'tries' => (int)$m['tries'] + 1, 'sent_at' => now(), 'last_error' => null], 'id=?', [(int)$m['id']]); $ok++; }
            catch (\Throwable $e) { $n = (int)$m['tries'] + 1; DB::update('wa_outbox', ['tries' => $n, 'status' => $n >= 5 ? 'failed' : 'pending', 'last_error' => mb_substr($e->getMessage(), 0, 300)], 'id=?', [(int)$m['id']]); $ko++; }
        }
        return [$ok, $ko];
    }
}
