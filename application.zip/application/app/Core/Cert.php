<?php
namespace App\Core;

/** Certificats et attestations configurables : modèles (logo Yas, textes, signataires, informations affichées) rendus en PDF. */
class Cert {
    const KINDS = ['course' => 'Cours en ligne', 'path' => 'Parcours de formation', 'training' => 'Formation (session)', 'hr' => 'Attestation RH (collaborateur)', 'any' => 'Tous usages'];
    const VARS = ['{nom}' => 'Nom du participant', '{formation}' => 'Intitulé du cours, du parcours ou de la formation', '{score}' => 'Score (%)', '{date}' => 'Date de délivrance', '{duree}' => 'Durée', '{formateur}' => 'Formateur', '{numero}' => 'Numéro de référence', '{organisation}' => 'Organisation', '{poste}' => 'Poste (attestations RH)', '{matricule}' => 'Matricule (attestations RH)', '{embauche}' => 'Date d\'embauche (attestations RH)', '{contrat}' => 'Type de contrat (attestations RH)', '{competence}' => 'Compétence acquise (fiche de la formation)', '{niveau}' => 'Niveau de réussite (selon le score)'];

    /** Modèle à utiliser : celui demandé, sinon le modèle par défaut du type, sinon n'importe quel modèle actif, sinon un modèle intégré. */
    static function template(string $kind, ?int $id = null): array {
        $t = $id ? DB::one('SELECT * FROM cert_templates WHERE id=? AND active=1', [$id]) : null;
        $t = $t ?: DB::one('SELECT * FROM cert_templates WHERE active=1 AND is_default=1 AND kind=? ORDER BY id LIMIT 1', [$kind]);
        $t = $t ?: DB::one("SELECT * FROM cert_templates WHERE active=1 AND kind IN (?, 'any') ORDER BY is_default DESC, id LIMIT 1", [$kind]);
        return $t ?: self::builtin($kind);
    }
    static function builtin(string $kind): array {
        return ['id' => 0, 'name' => 'Modèle intégré', 'kind' => $kind, 'title' => $kind === 'course' ? 'CERTIFICAT DE RÉUSSITE' : ($kind === 'hr' ? 'ATTESTATION DE TRAVAIL' : 'ATTESTATION'), 'intro' => 'Il est certifié que', 'body' => $kind === 'hr' ? 'est employé(e) au poste de {poste} (matricule {matricule}) depuis le {embauche}' : 'a suivi avec succès « {formation} »',
            'footer' => 'Document généré par CXO Excellence Hub.', 'color' => '#003A84', 'accent' => '#FFCE00', 'signer1_name' => '', 'signer1_title' => '', 'signer2_name' => '', 'signer2_title' => '', 'org_name' => (string)env('CERT_ORG', 'Yas Togo'),
            'orientation' => 'landscape', 'show_logo' => 1, 'show_score' => 1, 'show_date' => 1, 'show_duration' => 1, 'show_trainer' => 0, 'show_number' => 1, 'show_border' => 1, 'show_qr' => 1, 'layout' => 'classic', 'competence' => '', 'body2' => '', 'levels' => ''];
    }
    private static function hex(?string $c, string $d): string { return preg_match('/^#?([0-9A-Fa-f]{6})$/', (string)$c, $m) ? strtoupper($m[1]) : $d; }
    static function hours(?float $h): string { if (!$h) return ''; return (floor($h) == $h ? (int)$h : str_replace('.', ',', (string)round($h, 1))) . ' h'; }
    static function minutes(?int $m): string { if (!$m) return ''; return $m >= 60 ? floor($m / 60) . ' h' . ($m % 60 ? ' ' . $m % 60 : '') : $m . ' min'; }

    /** @param array $d name, item, score, date, no, duration, trainer */
    static function render(array $t, array $d, ?string $code = null): string {
        $d += ['position' => '', 'matricule' => '', 'hired' => '', 'contract' => '', 'competence' => ''];
        $land = ($t['orientation'] ?? 'landscape') !== 'portrait'; $W = $land ? 842.0 : 595.0; $H = $land ? 595.0 : 842.0;
        $c1 = self::hex($t['color'] ?? '', '003A84'); $c2 = self::hex($t['accent'] ?? '', 'FFCE00'); $p = new Pdf;
        $org = trim((string)($t['org_name'] ?: env('CERT_ORG', 'Yas Togo')));
        $rep = fn(string $s) => strtr($s, ['{nom}' => (string)$d['name'], '{formation}' => (string)$d['item'], '{score}' => (string)$d['score'], '{date}' => (string)$d['date'], '{duree}' => (string)$d['duration'], '{formateur}' => (string)$d['trainer'], '{numero}' => (string)$d['no'], '{organisation}' => $org, '{poste}' => (string)$d['position'], '{matricule}' => (string)$d['matricule'], '{embauche}' => (string)$d['hired'], '{contrat}' => (string)$d['contract'], '{competence}' => (string)$d['competence'], '{niveau}' => CertYas::level((string)$d['score'], $t['levels'] ?? null)[1]]);
        if (($t['layout'] ?? 'classic') === 'yas') return CertYas::render($t, $d, $code, $rep, $org);
        $qr = !empty($t['show_qr']) && $code !== null;
        $p->rect(0, 0, $W, $H, 'FFFFFF'); $p->rect(0, $H - 40, $W, 40, $c1); $p->rect(0, $H - 50, $W, 10, $c2); $p->rect(0, 0, $W, 22, $c1);
        if (!empty($t['show_border'])) { $p->frame(28, 36, $W - 56, $H - 94, $c1, 2.5); $p->frame(36, 44, $W - 72, $H - 110, $c2, 1); }
        $p->center(mb_strtoupper($org), $H - 27, 14, 'FFFFFF', true, $W, $W - 240);
        if (!empty($t['show_logo'])) { $lw = 62.0; $p->rect($W - $lw - 52, $H - 160, $lw + 10, 70, 'FFFFFF'); $p->image(ROOT . '/public/assets/logo.jpg', $W - $lw - 46, $H - 156, $lw, $lw * 270 / 340); }
        $y = $H - 125; $mw = $W - 140;
        $p->center((string)$rep((string)($t['title'] ?: 'CERTIFICAT')), $y - 5, $land ? 32 : 26, $c1, true, $W, $mw - 120); $y -= 55;
        if (trim((string)$t['intro']) !== '') { $p->center($rep((string)$t['intro']), $y, 14, '555555', false, $W, $mw); $y -= 48; }
        $p->center((string)$d['name'], $y, $land ? 30 : 26, '000000', true, $W, $mw); $y -= 44;
        foreach (array_slice(Pdf::wrap($rep((string)$t['body']), 18, $mw - 60, true), 0, 3) as $ln) { $p->center($ln, $y, 18, $c1, true, $W, $mw); $y -= 28; }
        $y -= 10; $facts = [];
        if (!empty($t['show_score']) && $d['score'] !== '') $facts[] = 'Score : ' . $d['score'] . ' %';
        if (!empty($t['show_duration']) && $d['duration'] !== '') $facts[] = 'Durée : ' . $d['duration'];
        if (!empty($t['show_trainer']) && $d['trainer'] !== '') $facts[] = 'Formateur : ' . $d['trainer'];
        if ($facts) { $p->center(implode('  ·  ', $facts), $y, 13, '000000', false, $W, $mw); $y -= 30; }
        if (!empty($t['show_date'])) { $p->center('Délivré le ' . $d['date'], $y, 13, '555555', false, $W, $mw); $y -= 24; }
        if (!empty($t['show_number'])) { $p->center('Référence : ' . $d['no'], $y, 11, '777777', false, $W, $mw); }
        $sy = $qr ? 138 : 112; $sg = array_values(array_filter([[$t['signer1_name'] ?? '', $t['signer1_title'] ?? ''], [$t['signer2_name'] ?? '', $t['signer2_title'] ?? '']], fn($s) => trim($s[0] . $s[1]) !== ''));
        foreach ($sg as $i => [$n, $ti]) { $cx = count($sg) === 1 ? $W / 2 : ($i === 0 ? $W * 0.3 : $W * 0.7); $p->line($cx - 90, $sy, $cx + 90, $sy, '999999', 0.8);
            $p->text($n, round($cx - Pdf::width($n, 11, true) / 2, 2), $sy - 14, 11, '000000', true); $p->text($ti, round($cx - Pdf::width($ti, 9) / 2, 2), $sy - 27, 9, '555555'); }
        if (trim((string)$t['footer']) !== '') $p->center($rep((string)$t['footer']), 54, 9, '777777', false, $W, $qr ? $mw - 170 : $mw);
        if ($qr) { $side = 66.0; $qx = $W - 52 - $side; Qr::pdf($p, self::verifyUrl($code), $qx, 66, $side); $p->center($code, 58, 7, '555555', true, 2 * $qx + $side, $side + 8); $p->center('Scanner pour vérifier', 50, 6.5, '777777', false, 2 * $qx + $side, $side + 8); }
        return $p->output($W, $H);
    }
    static function sample(array $t): string {
        return self::render($t, ['name' => 'Kossi AGBO', 'item' => 'Maîtrise de la relation client', 'score' => '92', 'date' => date('d/m/Y'), 'no' => 'CXO-000123', 'duration' => '14 h', 'trainer' => 'Essi ADJOVI', 'competence' => 'Maîtrise de la gestion de la relation client et de l’expérience client.', 'position' => 'Conseiller client', 'matricule' => 'MAT00123', 'hired' => '01/03/2022', 'contract' => 'CDI'], 'APERCU');
    }
    static function send(string $pdf, string $name): never {
        header('Content-Type: application/pdf'); header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9_.-]/', '_', $name) . '.pdf"'); header('X-Content-Type-Options: nosniff'); header('Content-Length: ' . strlen($pdf)); echo $pdf; exit;
    }
    static function forCourse(array $e): ?array {
        $c = DB::one('SELECT * FROM el_courses WHERE id=?', [(int)$e['course_id']]); if (!$c || $e['status'] !== 'passed' || !$c['certificate']) return null;
        $u = DB::one('SELECT name FROM users WHERE id=?', [(int)$e['user_id']]);
        return [self::template('course', $c['cert_template_id'] ? (int)$c['cert_template_id'] : null), ['name' => (string)($u['name'] ?? ''), 'item' => $c['title'], 'score' => (string)round((float)$e['best_pct']), 'date' => d($e['completed_at'] ?: now()), 'no' => ELearn::certNo($e), 'duration' => self::minutes($c['duration_min'] ? (int)$c['duration_min'] : null), 'trainer' => '']];
    }
    /** Attestation de fin de parcours : tous les cours publiés du parcours doivent être réussis. */
    static function forPath(int $pathId, int $userId): ?array {
        $p = DB::one('SELECT * FROM el_paths WHERE id=?', [$pathId]); if (!$p) return null;
        $cs = DB::all("SELECT c.* FROM el_path_courses pc JOIN el_courses c ON c.id=pc.course_id WHERE pc.path_id=? AND c.status='published'", [$pathId]); if (!$cs) return null;
        $last = null; $min = 0; $n = 0;
        foreach ($cs as $c) { $e = DB::one("SELECT * FROM el_enrollments WHERE course_id=? AND user_id=? AND status='passed'", [(int)$c['id'], $userId]); if (!$e) return null; $last = max((string)$last, (string)$e['completed_at']); $min += (int)$c['duration_min']; $n += (float)$e['best_pct']; }
        $u = DB::one('SELECT name FROM users WHERE id=?', [$userId]);
        return [self::template('path', $p['cert_template_id'] ? (int)$p['cert_template_id'] : null), ['name' => (string)($u['name'] ?? ''), 'item' => $p['name'], 'score' => (string)round($n / count($cs)), 'date' => d($last ?: now()), 'no' => 'PAR-' . str_pad((string)$pathId, 3, '0', STR_PAD_LEFT) . '-' . str_pad((string)$userId, 5, '0', STR_PAD_LEFT), 'duration' => self::minutes($min ?: null), 'trainer' => '']];
    }
    static function forTraining(array $en): ?array {
        if ($en['status'] !== 'passed') return null;
        $s = DB::one('SELECT s.*, t.title, t.duration_hours, t.cert_template_id, t.competence FROM training_sessions s JOIN trainings t ON t.id=s.training_id WHERE s.id=?', [(int)$en['session_id']]); $e = DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [(int)$en['employee_id']]);
        if (!$s || !$e) return null;
        return [self::template('training', $s['cert_template_id'] ? (int)$s['cert_template_id'] : null), ['name' => $e['first_name'] . ' ' . $e['last_name'], 'item' => $s['title'], 'score' => $en['score'] !== null ? (string)round((float)$en['score']) : '', 'date' => d($s['end_date'] ?: $s['session_date']), 'no' => 'FOR-' . str_pad((string)$en['id'], 6, '0', STR_PAD_LEFT),
            'duration' => Tr::hoursLabel((int)$s['id'], (float)$s['duration_hours']), 'trainer' => Tr::trainerName($s), 'competence' => (string)($s['competence'] ?? '')]];
    }

    // ---- Registre des documents émis et vérification par un tiers (QR code) ----
    const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    static function newCode(): string { do { $c = 'CXO-'; for ($i = 0; $i < 8; $i++) $c .= self::ALPHA[random_int(0, 31)]; } while (DB::val('SELECT 1 FROM cert_issued WHERE code=?', [$c])); return $c; }
    /** Adresse absolue de la page de vérification (APP_URL si défini, sinon l'hôte de la requête). */
    static function verifyUrl(string $code): string {
        $base = rtrim((string)env('APP_URL', ''), '/');
        if ($base === '') { $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https'; $base = ($https ? 'https' : 'http') . '://' . preg_replace('/[^A-Za-z0-9.:\-\[\]]/', '', (string)($_SERVER['HTTP_HOST'] ?? 'localhost')); }
        return $base . url('verify/' . $code);
    }
    /** Enregistre (une seule fois par document) l'émission et renvoie le code de vérification. */
    static function issue(array $t, array $d, string $refType, int $refId, ?int $empId = null): string {
        $r = DB::one('SELECT code FROM cert_issued WHERE ref_type=? AND ref_id=?', [$refType, $refId]); if ($r) return $r['code'];
        $code = self::newCode();
        DB::insert('cert_issued', ['code' => $code, 'template_id' => $t['id'] ?: null, 'kind' => (string)($t['kind'] ?? ''), 'ref_type' => $refType, 'ref_id' => $refId, 'holder_name' => mb_substr((string)$d['name'], 0, 190), 'item' => mb_substr((string)$d['item'], 0, 300),
            'snapshot' => json_encode(['title' => (string)($t['title'] ?? ''), 'org' => (string)(($t['org_name'] ?? '') ?: env('CERT_ORG', 'Yas Togo')), 'no' => (string)($d['no'] ?? ''), 'score' => (string)($d['score'] ?? ''), 'date' => (string)($d['date'] ?? ''), 'duration' => (string)($d['duration'] ?? '')], JSON_UNESCAPED_UNICODE),
            'employee_id' => $empId, 'issued_by' => Auth::id(), 'issued_at' => now(), 'revoked' => 0, 'checks' => 0]);
        return $code;
    }
    /** Émet (si besoin) puis envoie le PDF avec son QR code. */
    static function deliver(array $t, array $d, string $refType, int $refId, string $filename, ?int $empId = null): never {
        $code = self::issue($t, $d, $refType, $refId, $empId); self::send(self::render($t, $d, $code), $filename);
    }
    /** Attestation RH d'un collaborateur (travail, emploi…) : poste, matricule, embauche, contrat. */
    static function forEmployee(int $empId, ?int $tplId = null): ?array {
        $e = DB::one('SELECT e.*, p.name pos FROM employees e LEFT JOIN positions p ON p.id=e.position_id WHERE e.id=?', [$empId]); if (!$e) return null;
        $t = self::template('hr', $tplId);
        return [$t, ['name' => trim($e['first_name'] . ' ' . $e['last_name']), 'item' => (string)($e['pos'] ?: ($e['job_function'] ?: 'Collaborateur')), 'score' => '', 'date' => d(date('Y-m-d')), 'no' => 'RH-' . $e['matricule'] . '-' . date('ymd'), 'duration' => '', 'trainer' => '',
            'position' => (string)($e['pos'] ?: $e['job_function']), 'matricule' => (string)$e['matricule'], 'hired' => $e['hire_date'] ? d($e['hire_date']) : '', 'contract' => (string)$e['contract_type']]];
    }
    static function lookup(string $code): ?array {
        $code = strtoupper(trim($code)); if (!preg_match('/^CXO-[A-Z0-9]{8}$/', $code)) return null;
        $r = DB::one('SELECT * FROM cert_issued WHERE code=?', [$code]); if (!$r) return null;
        DB::exec('UPDATE cert_issued SET checks=checks+1, last_check_at=? WHERE id=?', [now(), (int)$r['id']]); $r['snap'] = json_decode((string)$r['snapshot'], true) ?: [];
        return $r;
    }
}

