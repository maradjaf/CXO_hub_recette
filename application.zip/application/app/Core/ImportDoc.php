<?php
namespace App\Core;

/**
 * Import de documents Word (.docx), PowerPoint (.pptx) et PDF vers une arborescence de sections.
 * Résultat : ['title'=>string, 'sections'=>[['depth'=>1..3,'title'=>string,'html'=>string],…], 'warnings'=>string[]].
 * La qualité dépend de la structure du document source (styles de titre Word, titres de diapositives) ; le PDF est traité au mieux.
 */
class ImportDoc {
    const EXT = ['docx', 'pptx', 'pdf'];
    const MAX_UNZIPPED = 60 * 1048576;

    /** @return array{0:?array,1:?string} résultat, erreur */
    static function parse(string $path, string $origName): array {
        $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION)); if (!in_array($ext, self::EXT, true)) return [null, 'Format non pris en charge : utilisez .docx, .pptx ou .pdf (enregistrez un .doc/.ppt au format récent depuis Word/PowerPoint).'];
        $head = (string)file_get_contents($path, false, null, 0, 8);
        try {
            if ($ext === 'pdf') { if (!str_starts_with($head, '%PDF')) return [null, 'Ce fichier n\'est pas un PDF valide.']; return self::pdf($path, $origName); }
            if (!str_starts_with($head, 'PK')) return [null, 'Ce fichier n\'est pas un document ' . strtoupper($ext) . ' valide.'];
            if (!class_exists(\ZipArchive::class)) return [null, 'L\'extension PHP « zip » est requise pour lire les fichiers Word et PowerPoint (à activer dans php.ini).'];
            return $ext === 'docx' ? self::docx($path, $origName) : self::pptx($path, $origName);
        } catch (\Throwable $t) { return [null, 'Lecture impossible : ' . mb_substr($t->getMessage(), 0, 160)]; }
    }
    private static function title(string $name): string { $t = preg_replace('/\.[A-Za-z0-9]+$/', '', $name); $t = trim(preg_replace('/[_\s]+/', ' ', $t)); return mb_substr($t !== '' ? $t : 'Document importé', 0, 190); }
    private static function zipRead(\ZipArchive $z, string $name): ?string {
        $i = $z->locateName($name); if ($i === false) return null; $st = $z->statIndex($i); if (!$st || $st['size'] > self::MAX_UNZIPPED) return null; $d = $z->getFromIndex($i); return $d === false ? null : $d;
    }
    private static function xml(string $s): ?\DOMDocument { $d = new \DOMDocument(); $p = libxml_use_internal_errors(true); $ok = $d->loadXML($s, LIBXML_NONET | LIBXML_COMPACT | LIBXML_PARSEHUGE); libxml_clear_errors(); libxml_use_internal_errors($p); return $ok ? $d : null; }
    private static function h(string $t): string { return htmlspecialchars($t, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

    // ---------- Word ----------
    private static function docx(string $path, string $name): array {
        $z = new \ZipArchive(); if ($z->open($path) !== true) return [null, 'Archive Word illisible.'];
        $doc = self::zipRead($z, 'word/document.xml'); if ($doc === null) return [null, 'Document Word vide ou invalide.']; $styles = self::zipRead($z, 'word/styles.xml'); $imgs = 0; for ($i = 0; $i < $z->numFiles; $i++) if (str_starts_with((string)$z->getNameIndex($i), 'word/media/')) $imgs++; $z->close();
        $dom = self::xml($doc); if (!$dom) return [null, 'Document Word illisible.']; $W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'; $xp = new \DOMXPath($dom); $xp->registerNamespace('w', $W);
        $hl = []; if ($styles && ($sd = self::xml($styles))) { $sx = new \DOMXPath($sd); $sx->registerNamespace('w', $W); foreach ($sx->query('//w:style[@w:type="paragraph"]') as $s) { $id = $s->getAttributeNS($W, 'styleId'); $nm = ''; foreach ($s->getElementsByTagNameNS($W, 'name') as $n) $nm = $n->getAttributeNS($W, 'val'); if (preg_match('/^(heading|titre)\s*([1-6])$/i', $nm) || preg_match('/^(heading|titre)\s*([1-6])$/i', $id)) $hl[$id] = (int)preg_replace('/\D/', '', $nm ?: $id); elseif (in_array(strtolower($nm), ['title', 'titre'], true)) $hl[$id] = 1; } }
        $body = $dom->getElementsByTagNameNS($W, 'body')->item(0); if (!$body) return [null, 'Document Word vide.'];
        $blocks = []; $inList = false;
        foreach ($body->childNodes as $n) {
            if (!($n instanceof \DOMElement)) continue;
            if ($n->localName === 'p') {
                $style = ''; foreach ($n->getElementsByTagNameNS($W, 'pStyle') as $ps) { $style = $ps->getAttributeNS($W, 'val'); break; }
                $runs = ''; $plain = ''; $allBold = true; $any = false;
                foreach ($n->getElementsByTagNameNS($W, 'r') as $r) { $t = ''; foreach ($r->childNodes as $c) { if (!($c instanceof \DOMElement)) continue; if ($c->localName === 't') $t .= $c->textContent; elseif ($c->localName === 'tab') $t .= ' '; elseif ($c->localName === 'br') $t .= "\n"; }
                    if ($t === '') continue; $any = true; $plain .= $t; $rp = $r->getElementsByTagNameNS($W, 'rPr')->item(0); $b = $rp && $rp->getElementsByTagNameNS($W, 'b')->length && $rp->getElementsByTagNameNS($W, 'b')->item(0)->getAttributeNS($W, 'val') !== '0'; $i2 = $rp && $rp->getElementsByTagNameNS($W, 'i')->length; if (!$b) $allBold = false;
                    $s = nl2br(self::h($t)); if ($b) $s = "<strong>$s</strong>"; if ($i2) $s = "<em>$s</em>"; $runs .= $s; }
                $plain = trim($plain); if ($plain === '') { $inList = false; continue; }
                $isList = $n->getElementsByTagNameNS($W, 'numPr')->length > 0 || preg_match('/^(list|liste)/i', $style) || preg_match('/^[•\-–·▪]\s+\S/u', $plain);
                if (isset($hl[$style])) { $blocks[] = ['h', $hl[$style], $plain]; $inList = false; }
                else { $blocks[] = $isList ? ['li', $allBold && $any ? 0 : 0, preg_replace('/^[•\-–·▪]\s+/u', '', $runs)] : ['p', $allBold && $any && mb_strlen($plain) < 140 ? 1 : 0, $runs, $plain]; }
            } elseif ($n->localName === 'tbl') {
                $rows = ''; foreach ($n->getElementsByTagNameNS($W, 'tr') as $tr) { $cells = ''; foreach ($tr->childNodes as $tc) if ($tc instanceof \DOMElement && $tc->localName === 'tc') $cells .= '<td>' . self::h(trim(preg_replace('/\s+/', ' ', $tc->textContent))) . '</td>'; $rows .= "<tr>$cells</tr>"; }
                $blocks[] = ['raw', 0, "<table><tbody>$rows</tbody></table>"];
            }
        }
        $w = []; if ($imgs) $w[] = "$imgs image(s) du document ne sont pas importées : réinsérez-les avec l'éditeur.";
        return [self::build(self::title($name), $blocks, $w), null];
    }

    // ---------- PowerPoint ----------
    private static function pptx(string $path, string $name): array {
        $z = new \ZipArchive(); if ($z->open($path) !== true) return [null, 'Archive PowerPoint illisible.']; $slides = [];
        for ($i = 0; $i < $z->numFiles; $i++) if (preg_match('#^ppt/slides/slide(\d+)\.xml$#', (string)$z->getNameIndex($i), $m)) $slides[(int)$m[1]] = $z->getNameIndex($i); ksort($slides);
        if (!$slides) { $z->close(); return [null, 'Aucune diapositive trouvée.']; } $A = 'http://schemas.openxmlformats.org/drawingml/2006/main'; $P = 'http://schemas.openxmlformats.org/presentationml/2006/main'; $blocks = []; $n = 0;
        foreach ($slides as $num => $fn) {
            $x = self::zipRead($z, $fn); $d = $x ? self::xml($x) : null; if (!$d) continue; $title = ''; $items = [];
            foreach ($d->getElementsByTagNameNS($P, 'sp') as $sp) {
                $ph = $sp->getElementsByTagNameNS($P, 'ph')->item(0); $type = $ph ? $ph->getAttribute('type') : ''; $paras = [];
                foreach ($sp->getElementsByTagNameNS($A, 'p') as $p) { $t = ''; foreach ($p->getElementsByTagNameNS($A, 't') as $tt) $t .= $tt->textContent; $t = trim($t); if ($t !== '') $paras[] = $t; }
                if (!$paras) continue; if (!$title && in_array($type, ['title', 'ctrTitle'], true)) { $title = implode(' ', $paras); continue; }
                if (in_array($type, ['sldNum', 'dt', 'ftr'], true)) continue; foreach ($paras as $t) $items[] = $t;
            }
            foreach ($d->getElementsByTagNameNS($A, 'tbl') as $tb) { $rows = ''; foreach ($tb->getElementsByTagNameNS($A, 'tr') as $tr) { $c = ''; foreach ($tr->getElementsByTagNameNS($A, 'tc') as $tc) $c .= '<td>' . self::h(trim($tc->textContent)) . '</td>'; $rows .= "<tr>$c</tr>"; } $items[] = ['raw', "<table><tbody>$rows</tbody></table>"]; }
            if (!$title && !$items) continue; $n++; $blocks[] = ['h', 2, $title ?: ('Diapositive ' . $num)];
            foreach ($items as $it) $blocks[] = is_array($it) ? ['raw', 0, $it[1]] : (count($items) > 1 ? ['li', 0, self::h($it)] : ['p', 0, self::h($it), $it]);
        }
        $z->close(); if (!$n) return [null, 'Aucun texte trouvé dans les diapositives.'];
        return [self::build(self::title($name), $blocks, ['Les images, schémas et notes du présentateur ne sont pas importés.'], true), null];
    }

    // ---------- PDF ----------
    /** Emplacement de pdftotext : réglage « elearn.pdftotext_path », PATH, puis dossiers usuels (Laragon / poppler sous Windows). */
    static function pdftotextBin(): ?string {
        if (!function_exists('exec') || in_array('exec', array_map('trim', explode(',', (string)ini_get('disable_functions'))), true)) return null;
        $win = PHP_OS_FAMILY === 'Windows'; $c = [];
        $cfg = trim((string)Xchg::get('elearn.pdftotext_path')); if ($cfg !== '') $c[] = $cfg;
        $c[] = 'pdftotext';
        if ($win) foreach (['C:/laragon/bin/poppler*', 'C:/laragon/bin/*/poppler*', 'C:/poppler*', 'C:/Program Files/poppler*', 'C:/tools/poppler*'] as $g) foreach (glob($g) ?: [] as $d) foreach (['/Library/bin/pdftotext.exe', '/bin/pdftotext.exe', '/pdftotext.exe'] as $sfx) if (is_file($d . $sfx)) $c[] = $d . $sfx;
        foreach ($c as $b) { $o = []; @exec(escapeshellarg($b) . ' -v 2>&1', $o, $rc); if (stripos(implode(' ', $o), 'pdftotext') !== false) return $b; }
        return null;
    }
    /** Diagnostic pour l'écran d'import : outil trouvé, version, et consignes d'installation. @return array{bin:?string,version:string} */
    static function pdfStatus(): array {
        $b = self::pdftotextBin(); $v = ''; if ($b) { $o = []; @exec(escapeshellarg($b) . ' -v 2>&1', $o); $v = trim((string)($o[0] ?? '')); }
        return ['bin' => $b, 'version' => $v, 'zip' => class_exists(\ZipArchive::class)];
    }
    private static function pdf(string $path, string $name): array {
        $txt = null; $w = [];
        if ($bin = self::pdftotextBin()) { $o = []; @exec(escapeshellarg($bin) . ' -enc UTF-8 -layout ' . escapeshellarg($path) . ' - 2>' . (PHP_OS_FAMILY === 'Windows' ? 'NUL' : '/dev/null'), $o, $rc); if ($rc === 0 && $o) $txt = implode("\n", $o); }
        if ($txt === null) { $txt = self::pdfMinimal($path); $w[] = 'Extraction PDF intégrée (pdftotext non installé) : relisez attentivement le résultat.'; }
        $clean = preg_replace('/[^\p{L}\p{N}\s.,;:!?\'"()\-–—%€\/]/u', '', $txt); $letters = preg_match_all('/\p{L}/u', (string)$clean);
        if ($letters < 40 || $letters < mb_strlen(preg_replace('/\s+/', '', (string)$txt)) * 0.5) return [null, 'Aucun texte exploitable dans ce PDF (document scanné ou polices encodées)' . ($w ? ' — extraction simplifiée : installez « pdftotext » (poppler) sur le serveur' : '') . ' : utilisez plutôt la version Word/PowerPoint d\'origine.'];
        $blocks = []; $para = ''; $flush = function () use (&$blocks, &$para) { if (trim($para) !== '') $blocks[] = ['p', 0, self::h(trim($para)), trim($para)]; $para = ''; };
        foreach (preg_split('/\r?\n/', str_replace("\f", "\n\n", $txt)) as $line) {
            $l = trim(preg_replace('/\s{3,}/', '  ', $line)); if ($l === '') { $flush(); continue; }
            if (preg_match('/^\d{1,3}$/', $l)) continue;   // numéros de page
            if (self::looksHeading($l, $lv)) { $flush(); $blocks[] = ['h', $lv, $l]; continue; }
            if (preg_match('/^([•\-–·▪*]|\d+[\.\)])\s+\S/u', $l)) { $flush(); $blocks[] = ['li', 0, self::h(preg_replace('/^([•\-–·▪*]|\d+[\.\)])\s+/u', '', $l))]; continue; }
            $para .= ($para === '' ? '' : (preg_match('/-$/', $para) ? '' : ' ')) . $l;
        } $flush();
        return [self::build(self::title($name), $blocks, array_merge($w, ['Les images et la mise en page du PDF ne sont pas importées.'])), null];
    }
    private static function looksHeading(string $l, &$lv): bool {
        if (mb_strlen($l) > 100 || preg_match('/[.;,]$/u', $l)) return false;
        if (preg_match('/^(module|chapitre|partie|section)\s+[\dIVXivx]+\b/iu', $l)) { $lv = preg_match('/^module/iu', $l) ? 1 : (preg_match('/^chapitre|^partie/iu', $l) ? 2 : 3); return true; }
        if (preg_match('/^(\d+)(\.\d+){0,2}[\.\)]?\s+\p{Lu}/u', $l, $m)) { $lv = min(3, substr_count(preg_replace('/[\.\)]\s.*$/u', '', $l), '.') + 1); return mb_strlen($l) < 90; }
        if (mb_strlen($l) >= 4 && mb_strtoupper($l, 'UTF-8') === $l && preg_match('/\p{L}{3}/u', $l) && !preg_match('/\d{3,}/', $l)) { $lv = 1; return true; }
        return false;
    }
    /** Extracteur PDF intégré (sans outil externe) : flux Flate, flux d'objets, polices avec table ToUnicode, opérateurs Tj/TJ. */
    private static function pdfMinimal(string $path): string {
        $raw = (string)file_get_contents($path); if (strlen($raw) > 60 * 1048576) return '';
        $inflate = function (string $d, string $dict): string { if (str_contains($dict, 'FlateDecode')) { $x = @gzuncompress($d); if ($x === false) $x = @gzinflate(substr($d, 2)); return $x === false ? '' : (strlen($x) > 24 * 1048576 ? '' : $x); } return $d; };
        $objs = []; $n = 0;
        if (preg_match_all('/(\d+)\s+\d+\s+obj(.*?)endobj/s', $raw, $ms, PREG_SET_ORDER)) foreach ($ms as $m) {
            if (++$n > 20000) break; $id = (int)$m[1]; $b = $m[2]; $dict = $b; $data = null;
            if (($sp = strpos($b, 'stream')) !== false && preg_match('/stream\r?\n(.*?)\r?\n?endstream/s', $b, $sm)) { $dict = substr($b, 0, $sp); $data = $inflate($sm[1], $dict); }
            $objs[$id] = ['dict' => $dict, 'data' => $data];
            if ($data !== null && str_contains($dict, '/ObjStm') && preg_match('#/N\s+(\d+)#', $dict, $nn) && preg_match('#/First\s+(\d+)#', $dict, $ff)) {
                $cnt = (int)$nn[1]; $first = (int)$ff[1]; $hdr = preg_split('/\s+/', trim(substr($data, 0, $first))); $offs = [];
                for ($k = 0; $k < $cnt && isset($hdr[2 * $k + 1]); $k++) $offs[] = [(int)$hdr[2 * $k], (int)$hdr[2 * $k + 1]];
                foreach ($offs as $k => [$oid, $off]) { $end = isset($offs[$k + 1]) ? $offs[$k + 1][1] : strlen($data) - $first; $objs[$oid] = ['dict' => substr($data, $first + $off, max(0, $end - $off)), 'data' => null]; }
            }
        }
        // tables ToUnicode par police
        $cmaps = []; $cmapOf = function (int $ref) use (&$cmaps, $objs) {
            if (isset($cmaps[$ref])) return $cmaps[$ref]; $d = (string)($objs[$ref]['data'] ?? ''); $map = []; $w = 1;
            if (preg_match_all('/beginbfchar(.*?)endbfchar/s', $d, $bc)) foreach ($bc[1] as $blk) if (preg_match_all('/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>/', $blk, $pp, PREG_SET_ORDER)) foreach ($pp as $q) { $w = max($w, intdiv(strlen($q[1]), 2)); $map[hexdec($q[1])] = self::u16($q[2]); }
            if (preg_match_all('/beginbfrange(.*?)endbfrange/s', $d, $br)) foreach ($br[1] as $blk) if (preg_match_all('/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*(<[0-9A-Fa-f]+>|\[[^\]]*\])/', $blk, $pp, PREG_SET_ORDER)) foreach ($pp as $q) {
                $lo = hexdec($q[1]); $hi = min(hexdec($q[2]), $lo + 65535); $w = max($w, intdiv(strlen($q[1]), 2));
                if ($q[3][0] === '[') { preg_match_all('/<([0-9A-Fa-f]+)>/', $q[3], $ds); foreach ($ds[1] as $k => $h) $map[$lo + $k] = self::u16($h); }
                else { $base = hexdec(substr($q[3], 1, -1)); $len = strlen($q[3]) - 2; for ($c = $lo; $c <= $hi; $c++) $map[$c] = self::u16(str_pad(dechex($base + ($c - $lo)), $len, '0', STR_PAD_LEFT)); }
            }
            return $cmaps[$ref] = ['map' => $map, 'w' => $w];
        };
        $fontObjCmap = []; foreach ($objs as $id => $o) if (preg_match('#/Type\s*/Font\b#', $o['dict']) && preg_match('#/ToUnicode\s+(\d+)\s+\d+\s+R#', $o['dict'], $tu)) $fontObjCmap[$id] = (int)$tu[1];
        $byName = [];   // nom de ressource (/F1) -> objet police
        $scan = function (string $txt) use (&$byName) { if (preg_match_all('#/Font\s*<<(.*?)>>#s', $txt, $fb)) foreach ($fb[1] as $blk) if (preg_match_all('#/([A-Za-z0-9_.+-]+)\s+(\d+)\s+\d+\s+R#', $blk, $pp, PREG_SET_ORDER)) foreach ($pp as $q) $byName[$q[1]] = (int)$q[2]; };
        foreach ($objs as $o) { $scan($o['dict']); if (preg_match('#/Font\s+(\d+)\s+\d+\s+R#', $o['dict'], $fr) && isset($objs[(int)$fr[1]])) $scan('/Font<<' . trim(preg_replace('/^.*?<<|>>.*$/s', '', $objs[(int)$fr[1]]['dict'])) . '>>'); }
        $dec = function (string $bytes, ?array $cm): string {
            if (!$cm || !$cm['map']) return self::pdfStr($bytes, false); $w = $cm['w'] ?: 1; $o = ''; $L = strlen($bytes);
            for ($i = 0; $i + $w <= $L; $i += $w) { $c = 0; for ($k = 0; $k < $w; $k++) $c = ($c << 8) | ord($bytes[$i + $k]); $o .= $cm['map'][$c] ?? ''; }
            return $o;
        };
        $hexb = function (string $h): string { $h = preg_replace('/\s+/', '', $h); if (strlen($h) % 2) $h .= '0'; $b = ''; for ($i = 0; $i < strlen($h); $i += 2) $b .= chr(hexdec(substr($h, $i, 2))); return $b; };
        $str = function (string $tok, ?array $cm) use ($dec, $hexb): string { return $tok[0] === '<' ? $dec($hexb(substr($tok, 1, -1)), $cm) : $dec(self::pdfUnesc(substr($tok, 1, -1)), $cm); };
        $out = '';
        foreach ($objs as $o) {
            $d = $o['data']; if ($d === null || !str_contains($d, 'BT')) continue; $cm = null;
            if (!preg_match_all('/BT(.*?)ET/s', $d, $bts)) continue;
            foreach ($bts[1] as $bt) {
                if (!preg_match_all('~/([A-Za-z0-9_.+-]+)\s+[\d.]+\s+Tf|\[((?:\\\\.|[^\]\\\\])*)\]\s*TJ|(\((?:\\\\.|[^\\\\)])*\)|<[0-9A-Fa-f\s]*>)\s*(?:Tj|\'|")|(-?[\d.]+)\s+(-?[\d.]+)\s+T[dD]|(T\*)|((?:-?[\d.]+\s+){5}-?[\d.]+\s+Tm)~s', $bt, $tk, PREG_SET_ORDER)) continue;
                foreach ($tk as $t) {
                    if (($t[1] ?? '') !== '') { $ref = $fontObjCmap[$byName[$t[1]] ?? 0] ?? null; $cm = $ref ? $cmapOf($ref) : null; }
                    elseif (($t[2] ?? '') !== '') { if (preg_match_all('/\((?:\\\\.|[^\\\\)])*\)|<[0-9A-Fa-f\s]*>|-?[\d.]+/', $t[2], $parts)) foreach ($parts[0] as $pt) { if ($pt[0] === '(' || $pt[0] === '<') $out .= $str($pt, $cm); elseif ((float)$pt < -200) $out .= ' '; } }
                    elseif (($t[3] ?? '') !== '') $out .= $str($t[3], $cm);
                    elseif (($t[4] ?? '') !== '') { if (abs((float)$t[5]) > 0.5) $out .= "\n"; }
                    elseif (($t[6] ?? '') !== '' || ($t[7] ?? '') !== '') $out .= "\n";
                }
                $out .= "\n";
            }
        }
        return preg_replace("/\n{3,}/", "\n\n", $out);
    }
    private static function u16(string $hex): string { $b = ''; for ($i = 0; $i + 1 < strlen($hex); $i += 2) $b .= chr(hexdec(substr($hex, $i, 2))); return mb_convert_encoding($b, 'UTF-8', 'UTF-16BE'); }
    private static function pdfUnesc(string $s): string { return preg_replace_callback('/\\\\(\d{1,3}|.)/s', fn($m) => ctype_digit($m[1]) ? chr(octdec($m[1]) & 255) : (['n' => "\n", 'r' => '', 't' => ' ', 'b' => '', 'f' => ''][$m[1]] ?? $m[1]), $s); }
    private static function pdfStr(string $s, bool $esc = true): string {
        if ($esc) $s = preg_replace_callback('/\\\\(\d{1,3}|.)/s', fn($m) => ctype_digit($m[1]) ? chr(octdec($m[1]) & 255) : (['n' => "\n", 'r' => '', 't' => ' ', 'b' => '', 'f' => ''][$m[1]] ?? $m[1]), $s);
        return mb_check_encoding($s, 'UTF-8') ? $s : mb_convert_encoding($s, 'UTF-8', 'Windows-1252');
    }

    // ---------- construction de l'arborescence ----------
    /** @param list<array> $blocks ['h',niveau,texte] | ['p',gras,html,texte] | ['li',0,html] | ['raw',0,html] */
    private static function build(string $title, array $blocks, array $warnings, bool $slides = false): array {
        $lv = array_filter(array_map(fn($b) => $b[0] === 'h' ? $b[1] : null, $blocks)); $min = $lv ? min($lv) : 1; $secs = []; $cur = null; $prevDepth = 0; $list = false; $buf = '';
        $close = function () use (&$cur, &$buf, &$list) { if ($list) { $buf .= '</ul>'; $list = false; } if ($cur !== null) $cur['html'] .= $buf; $buf = ''; };
        $intro = ['depth' => 1, 'title' => $title, 'html' => '', 'intro' => true]; $cur = $intro;
        foreach ($blocks as $b) {
            if ($b[0] === 'h') { $close(); $secs[] = $cur; $depth = min(3, $b[1] - $min + 1); $depth = max(1, min($depth, $prevDepth + 1)); if ($slides) $depth = 2; $prevDepth = $depth; $cur = ['depth' => $depth, 'title' => mb_substr($b[2], 0, 190), 'html' => '']; continue; }
            if ($b[0] === 'li') { if (!$list) { $buf .= '<ul>'; $list = true; } $buf .= '<li>' . $b[2] . '</li>'; continue; }
            if ($list) { $buf .= '</ul>'; $list = false; }
            $buf .= $b[0] === 'raw' ? $b[2] : ($b[1] ? '<h4>' . $b[2] . '</h4>' : '<p>' . $b[2] . '</p>');
        } $close(); $secs[] = $cur;
        $first = $secs[0]; $rest = array_slice($secs, 1);
        if ($slides) $secs = array_merge([$first], $rest);
        elseif (!$rest) $secs = [$first];
        elseif (RichHtml::text($first['html']) === '') $secs = $rest;
        foreach ($secs as &$s) { $s['html'] = RichHtml::clean($s['html']); unset($s['intro']); }
        if (count($secs) === 1 && $secs[0]['html'] === '') $warnings[] = 'Aucun texte détecté.';
        $nh = count($lv); if (!$nh && !$slides) $warnings[] = 'Aucun titre détecté : tout le contenu est placé dans une seule partie (utilisez les styles « Titre 1/2/3 » dans Word pour obtenir un découpage automatique).';
        return ['title' => $title, 'sections' => $secs, 'warnings' => $warnings];
    }
}
