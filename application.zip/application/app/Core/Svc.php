<?php
namespace App\Core;
/** Lot 38 : tickets enfants et liés, propagation des statuts, satisfaction (CSAT), modèles de réponse. */
class Svc {
    const LINK = ['related' => 'Lié à', 'duplicate' => 'Doublon de', 'caused_by' => 'Causé par'];
    const CSAT = [1 => 'Très insatisfait', 2 => 'Insatisfait', 3 => 'Correct', 4 => 'Satisfait', 5 => 'Très satisfait'];

    static function openChildren(int $parent): array {
        return DB::all("SELECT id, reference, title, status FROM at_tickets WHERE parent_id=? AND status NOT IN ('resolved','closed')", [$parent]);
    }
    static function children(int $parent): array {
        return DB::all('SELECT t.id, t.reference, t.title, t.status, t.priority, u.name assignee FROM at_tickets t LEFT JOIN users u ON u.id=t.assignee_id WHERE t.parent_id=? ORDER BY t.id', [$parent]);
    }
    /** Liens dans les deux sens, avec libellé orienté depuis le ticket consulté. */
    static function links(int $id): array {
        $out = [];
        foreach (DB::all('SELECT l.id, l.kind, t.id tid, t.reference, t.title, t.status FROM at_links l JOIN at_tickets t ON t.id=l.other_id WHERE l.ticket_id=?', [$id]) as $r) $out[] = $r + ['label' => self::LINK[$r['kind']] ?? $r['kind']];
        foreach (DB::all('SELECT l.id, l.kind, t.id tid, t.reference, t.title, t.status FROM at_links l JOIN at_tickets t ON t.id=l.ticket_id WHERE l.other_id=?', [$id]) as $r) {
            $out[] = $r + ['label' => ['related' => 'Lié à', 'duplicate' => 'A pour doublon', 'caused_by' => 'Est la cause de'][$r['kind']] ?? $r['kind']];
        }
        return $out;
    }
    /** Après un changement de statut : un enfant terminé prévient le parent ; un ticket d'origine résolu clôt ses doublons. */
    static function afterStatus(array $t, string $new, ?int $uid): void {
        if (!in_array($new, ['resolved', 'closed'], true)) return;
        $id = (int)$t['id'];
        if ($t['parent_id']) {
            $pid = (int)$t['parent_id']; Tickets::event($pid, 'child', 'Ticket enfant ' . $t['reference'] . ' : ' . Tickets::STATUS[$new] . '.', $uid);
            if (!self::openChildren($pid)) {
                $p = DB::one('SELECT * FROM at_tickets WHERE id=?', [$pid]);
                if ($p && $p['assignee_id']) Notifier::send((int)$p['assignee_id'], 'Tous les tickets enfants sont terminés : ' . $p['reference'], 'Vous pouvez résoudre le ticket parent.', '/at/' . $pid);
            }
        }
        $res = (string)DB::val('SELECT resolution FROM at_tickets WHERE id=?', [$id]);
        foreach (DB::all("SELECT t.* FROM at_links l JOIN at_tickets t ON t.id=l.ticket_id WHERE l.other_id=? AND l.kind='duplicate' AND t.status IN ('new','assigned','in_progress','waiting')", [$id]) as $d) {
            DB::update('at_tickets', ['status' => 'resolved', 'resolved_at' => now(), 'resolution' => 'Doublon de ' . $t['reference'] . ($res !== '' ? ' — ' . $res : '')] + Tickets::transition($d, 'resolved'), 'id=?', [(int)$d['id']]);
            Tickets::event((int)$d['id'], 'status', 'Résolu automatiquement : le ticket d\'origine ' . $t['reference'] . ' est ' . mb_strtolower(Tickets::STATUS[$new]) . '.', $uid);
            if ($d['requester_id']) Notifier::send((int)$d['requester_id'], 'Ticket résolu : ' . $d['reference'], 'Même problème que ' . $t['reference'] . ' : donnez votre avis sur le traitement.', '/at/' . $d['id']);
        }
    }
    /** Remplace les variables d'un modèle ({demandeur}, {reference}, {titre}, {technicien}). */
    static function fill(string $body, array $t): string {
        $first = fn($n) => $n ? explode(' ', trim((string)$n))[0] : '';
        $req = $t['requester_id'] ? (string)DB::val('SELECT name FROM users WHERE id=?', [(int)$t['requester_id']]) : '';
        $tech = $t['assignee_id'] ? (string)DB::val('SELECT name FROM users WHERE id=?', [(int)$t['assignee_id']]) : (Auth::user()['name'] ?? 'un technicien');
        return strtr($body, ['{demandeur}' => $first($req) ?: 'Madame, Monsieur', '{reference}' => $t['reference'], '{titre}' => $t['title'], '{technicien}' => $tech]);
    }
    static function templatesFor(array $t): array {
        $out = ['reply' => [], 'solution' => []];
        foreach (DB::all("SELECT * FROM at_templates WHERE active=1 AND (category IS NULL OR category='' OR category=?) ORDER BY title", [(string)$t['category']]) as $x) $out[$x['kind']][] = ['id' => (int)$x['id'], 'title' => $x['title'], 'body' => self::fill($x['body'], $t)];
        return $out;
    }
    /** Indicateurs de satisfaction sur une période (où : fragment SQL sur at_tickets t, déjà filtré). */
    static function csatStats(string $where, array $p): array {
        $n = (int)DB::val("SELECT COUNT(*) FROM at_tickets t WHERE $where AND t.csat_score IS NOT NULL", $p);
        $avg = $n ? round((float)DB::val("SELECT AVG(t.csat_score) FROM at_tickets t WHERE $where AND t.csat_score IS NOT NULL", $p), 2) : null;
        $sat = $n ? (int)DB::val("SELECT COUNT(*) FROM at_tickets t WHERE $where AND t.csat_score>=4", $p) : 0;
        $asked = (int)DB::val("SELECT COUNT(*) FROM at_tickets t WHERE $where AND t.status IN ('resolved','closed')", $p);
        return ['n' => $n, 'avg' => $avg, 'sat_pct' => $n ? round($sat / $n * 100) : null, 'asked' => $asked, 'rate' => $asked ? round($n / $asked * 100) : null];
    }
}
