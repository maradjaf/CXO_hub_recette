<?php
namespace App\Core;

/**
 * Lot 60 — Franchises : indicateurs, séries, comparaisons.
 * Règles : taux = Σ numérateurs ÷ Σ dénominateurs de la période ; médiane et P90 sur les délais individuels (interpolation linéaire, comme PERCENTILE.INC) ;
 * stock = valeur à la dernière date couverte de la période ; variation relative = (B − A) ÷ A, indisponible si A = 0 ; écart d'un taux en points.
 */
final class FrStats {
    /** code => [libellé, unité, type, date de référence, définition] */
    const M = [
        'received' => ['Demandes reçues', 'n', 'vol', 'Date de création', 'ID distincts créés pendant la période. Une réouverture conserve le même ID.'],
        'ops' => ['Opérations réalisées', 'n', 'vol', 'Date effective', 'Opérations exécutées et confirmées dont le type est compté au dictionnaire métier.'],
        'closed' => ['Demandes clôturées', 'n', 'vol', 'Date de clôture', 'ID distincts ayant atteint un statut terminal pendant la période.'],
        'exec' => ['Taux d\'exécution', '%', 'rate', 'Date de clôture', 'Demandes éligibles clôturées avec exécution confirmée ÷ demandes éligibles clôturées.'],
        'sla' => ['Respect du SLA', '%', 'rate', 'Date de clôture', 'Dossiers résolus dans le délai ÷ dossiers résolus soumis au SLA mesurable.'],
        'stock' => ['Stock ouvert', 'n', 'stock', 'Date de coupe', 'Demandes ouvertes (attentes comprises) à la dernière date couverte, d\'après le dernier événement connu.'],
        'late' => ['Stock hors délai', 'n', 'stock', 'Date de coupe', 'Demandes ouvertes dont l\'échéance SLA est dépassée à la date de coupe.'],
        'median' => ['Délai médian', 'h', 'delay', 'Date de clôture', 'Médiane des délais individuels (création → résolution) des dossiers résolus dans la période.'],
        'p90' => ['Délai P90', 'h', 'delay', 'Date de clôture', '90e percentile des délais individuels des dossiers résolus dans la période.'],
        'nc' => ['Taux de non-conformité', '%', 'rate', 'Date du contrôle', 'Contrôles non conformes ÷ contrôles applicables.'],
        'quality' => ['Score qualité', '%', 'rate', 'Date du contrôle', 'Points obtenus ÷ points applicables selon la grille approuvée.'],
        'complete' => ['Complétude des lignes', '%', 'rate', 'Date de la ligne', 'Lignes avec date, franchise et service renseignés ÷ lignes contrôlées (onglets BOSS et TRAITEMENT).'],
        'rest' => ['Lignes de la restitution', 'n', 'vol', 'Date de la ligne', 'Lignes de l\'onglet Restitution comportant une date, une franchise et un service.'],
    ];
    const GRAINS = ['day' => 'Jour', 'week' => 'Semaine (lun.–dim.)', 'fortnight' => 'Quinzaine', 'month' => 'Mois', 'quarter' => 'Trimestre', 'semester' => 'Semestre', 'year' => 'Année'];
    const MONTHS = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
    private static array $memo = []; private static array $covs = [];

    // ───────────────────────── Filtres ─────────────────────────
    static function filters(array $g, ?string $defFrom = null, ?string $defTo = null): array {
        $arr = fn($k) => array_values(array_unique(array_filter(array_map('strval', (array)($g[$k] ?? [])), fn($x) => $x !== '')));
        $day = fn($k, $d) => Fr::isDay($g[$k] ?? null) ? $g[$k] : $d;
        $to = $day('to', $defTo ?? date('Y-m-d')); $from = $day('from', $defFrom ?? Fr::addDays($to, -29)); if ($from > $to) [$from, $to] = [$to, $from];
        $grain = isset(self::GRAINS[$g['grain'] ?? '']) ? $g['grain'] : 'day';
        return ['from' => $from, 'to' => $to, 'grain' => $grain, 'zone' => $arr('zone'), 'zmode' => ($g['zmode'] ?? 'now') === 'then' ? 'then' : 'now', 'fr' => array_map('intval', $arr('fr')),
            'service' => (string)($g['service'] ?? ''), 'typology' => (string)($g['typology'] ?? ''), 'subtype' => (string)($g['subtype'] ?? ''), 'status' => isset(Fr::ST[$g['status'] ?? '']) ? $g['status'] : '',
            'priority' => isset(Fr::PRIO[$g['priority'] ?? '']) ? $g['priority'] : '', 'team' => (string)($g['team'] ?? ''), 'norm' => !empty($g['norm']) ? 1 : 0, 'align' => !empty($g['align']) ? 1 : 0];
    }
    /** Franchises retenues par les filtres et le périmètre : null = toutes. */
    static function ids(array $f, ?string $asOf = null): ?array {
        $ids = Fr::scope();
        if ($f['fr']) $ids = $ids === null ? $f['fr'] : array_values(array_intersect($ids, $f['fr']));
        if ($f['zone']) {
            $asOf = $f['zmode'] === 'then' ? ($asOf ?? $f['to']) : null; $ok = [];
            foreach (DB::all('SELECT id, zone FROM fr_franchises') as $r) { $z = $asOf === null ? $r['zone'] : Fr::zoneAt((int)$r['id'], $asOf); if (in_array((string)$z, $f['zone'], true)) $ok[] = (int)$r['id']; }
            $ids = $ids === null ? $ok : array_values(array_intersect($ids, $ok));
        }
        return $ids;
    }
    private static function inList(?array $ids, string $col): string { if ($ids === null) return ''; if (!$ids) return ' AND 1=0'; return " AND $col IN (" . implode(',', array_map('intval', $ids)) . ')'; }
    /** Conditions communes sur fr_requests (alias donné). @return array{0:string,1:array} */
    private static function reqCond(array $f, ?array $ids, string $a = ''): array {
        $p = $a === '' ? '' : "$a."; $w = self::inList($ids, $p . 'franchise_id'); $v = [];
        foreach (['service', 'typology', 'subtype', 'priority', 'team'] as $k) if ($f[$k] !== '') { $w .= " AND {$p}$k=?"; $v[] = $f[$k]; }
        if (!empty($f['status'])) { $w .= " AND {$p}status=?"; $v[] = $f['status']; }
        return [$w, $v];
    }

    // ───────────────────────── Couverture ─────────────────────────
    /** Couverture des données de la source d'une mesure : [from, to (au plus aujourd'hui), events_from]. */
    static function coverage(string $code = 'received'): array {
        $src = ['ops' => ['fr_ops', 'day', ''], 'nc' => ['fr_qc', 'day', ''], 'quality' => ['fr_qc', 'day', ''], 'complete' => ['fr_src', 'day', " WHERE source IN ('BOSS','TRAITEMENT')"], 'rest' => ['fr_src', 'day', " WHERE source='RESTITUTION'"]][$code] ?? ['fr_requests', 'substr(created_at,1,10)', ''];
        $k = $src[0] . $src[2]; if (isset(self::$covs[$k])) return self::$covs[$k];
        $r = DB::one("SELECT MIN({$src[1]}) a, MAX({$src[1]}) b FROM {$src[0]}{$src[2]}"); $cl = $src[0] === 'fr_requests' ? DB::val('SELECT MAX(substr(closed_at,1,10)) FROM fr_requests') : null;
        $to = $r && $r['b'] ? min(max($r['b'], (string)$cl), date('Y-m-d')) : null; $ev = $src[0] === 'fr_requests' ? (DB::val('SELECT MIN(substr(at,1,10)) FROM fr_events') ?: null) : null;
        return self::$covs[$k] = ['from' => $r['a'] ?? null, 'to' => $to, 'events_from' => $ev ?: ($r['a'] ?? null)];
    }
    static function resetCache(): void { self::$memo = []; self::$covs = []; }

    // ───────────────────────── Périodes ─────────────────────────
    /** @return array<int,array{id:string,label:string,from:string,to:string,partial:bool}> ; partial = la plage filtrée coupe la période. */
    static function periods(string $from, string $to, string $grain): array {
        $out = []; $d = $from; $i = 0;
        while ($d <= $to && $i++ < 400) {
            [$a, $b, $lab] = self::bounds($d, $grain); $s = max($a, $from); $e = min($b, $to);
            $out[] = ['id' => $a, 'label' => $lab, 'from' => $s, 'to' => $e, 'partial' => $s > $a || $e < $b, 'full_from' => $a, 'full_to' => $b]; $d = Fr::addDays($b, 1);
        }
        return $out;
    }
    private static function bounds(string $d, string $g): array {
        $t = strtotime($d); $y = (int)date('Y', $t); $m = (int)date('n', $t); $day = (int)date('j', $t);
        switch ($g) {
            case 'week': $a = date('Y-m-d', strtotime('monday this week', $t)); $b = Fr::addDays($a, 6); return [$a, $b, 'S' . date('W', strtotime($a)) . ' · ' . date('d/m', strtotime($a))];
            case 'fortnight': return $day <= 15 ? [sprintf('%04d-%02d-01', $y, $m), sprintf('%04d-%02d-15', $y, $m), '1–15 ' . self::MONTHS[$m - 1] . ' ' . $y] : [sprintf('%04d-%02d-16', $y, $m), date('Y-m-t', $t), '16–' . date('t', $t) . ' ' . self::MONTHS[$m - 1] . ' ' . $y];
            case 'month': return [sprintf('%04d-%02d-01', $y, $m), date('Y-m-t', $t), self::MONTHS[$m - 1] . ' ' . $y];
            case 'quarter': $q = intdiv($m - 1, 3); return [sprintf('%04d-%02d-01', $y, $q * 3 + 1), date('Y-m-t', strtotime(sprintf('%04d-%02d-01', $y, $q * 3 + 3))), 'T' . ($q + 1) . ' ' . $y];
            case 'semester': $h = $m <= 6 ? 0 : 1; return [sprintf('%04d-%02d-01', $y, $h * 6 + 1), date('Y-m-t', strtotime(sprintf('%04d-%02d-01', $y, $h * 6 + 6))), 'S' . ($h + 1) . ' ' . $y];
            case 'year': return ["$y-01-01", "$y-12-31", (string)$y];
            default: return [$d, $d, date('d/m', $t)];
        }
    }
    static function periodOf(string $day, string $grain): array { [$a, $b, $l] = self::bounds($day, $grain); return [$a, $b, $l]; }

    // ───────────────────────── Faits ─────────────────────────
    /** Lignes de faits d'une mesure entre deux dates : [d, fid, service, typology, num, den] ou [d, fid, service, typology, val] pour les délais. */
    static function facts(string $code, array $f, string $from, string $to, ?array $ids): array {
        $key = md5(json_encode([$code, $f['service'], $f['typology'], $f['subtype'], $f['status'], $f['priority'], $f['team'], $from, $to, $ids])); if (isset(self::$memo[$key])) return self::$memo[$key];
        [$w, $v] = self::reqCond($f, $ids); $a = "$from 00:00:00"; $b = "$to 23:59:59"; $rows = [];
        $grp = fn($sql, $p) => array_map(fn($r) => ['d' => $r['d'], 'fid' => (int)$r['fid'], 'service' => (string)$r['service'], 'typology' => (string)$r['typology'], 'num' => (float)$r['num'], 'den' => (float)$r['den']], DB::all($sql, $p));
        switch ($code) {
            case 'received': $rows = $grp("SELECT substr(created_at,1,10) d, franchise_id fid, service, typology, COUNT(*) num, 0 den FROM fr_requests WHERE created_at>=? AND created_at<=?$w GROUP BY d, franchise_id, service, typology", array_merge([$a, $b], $v)); break;
            case 'closed': $rows = $grp("SELECT substr(closed_at,1,10) d, franchise_id fid, service, typology, COUNT(*) num, 0 den FROM fr_requests WHERE closed_at>=? AND closed_at<=?$w GROUP BY d, franchise_id, service, typology", array_merge([$a, $b], $v)); break;
            case 'exec': $rows = $grp("SELECT substr(closed_at,1,10) d, franchise_id fid, service, typology, SUM(CASE WHEN outcome='executed' THEN 1 ELSE 0 END) num, COUNT(*) den FROM fr_requests WHERE eligible=1 AND closed_at>=? AND closed_at<=?$w GROUP BY d, franchise_id, service, typology", array_merge([$a, $b], $v)); break;
            case 'sla': $rows = $grp("SELECT substr(closed_at,1,10) d, franchise_id fid, service, typology, SUM(CASE WHEN closed_at<=due_at THEN 1 ELSE 0 END) num, COUNT(*) den FROM fr_requests WHERE due_at IS NOT NULL AND status IN ('executed','rejected','not_executed') AND closed_at>=? AND closed_at<=?$w GROUP BY d, franchise_id, service, typology", array_merge([$a, $b], $v)); break;
            case 'median': case 'p90': foreach (DB::all("SELECT substr(closed_at,1,10) d, franchise_id fid, service, typology, delay_h val FROM fr_requests WHERE delay_h IS NOT NULL AND status IN ('executed','rejected','not_executed') AND closed_at>=? AND closed_at<=?$w", array_merge([$a, $b], $v)) as $r) $rows[] = ['d' => $r['d'], 'fid' => (int)$r['fid'], 'service' => (string)$r['service'], 'typology' => (string)$r['typology'], 'val' => (float)$r['val']]; break;
            case 'ops': $o = self::inList($ids, 'franchise_id') . ($f['service'] !== '' ? ' AND service=?' : ''); $rows = $grp("SELECT day d, franchise_id fid, service, op_type typology, COUNT(*) num, 0 den FROM fr_ops WHERE counted=1 AND result='ok' AND day>=? AND day<=?$o GROUP BY day, franchise_id, service, op_type", array_merge([$from, $to], $f['service'] !== '' ? [$f['service']] : [])); break;
            case 'nc': case 'quality': $o = self::inList($ids, 'franchise_id'); $n = $code === 'nc' ? ['nonconform', 'controls'] : ['points_got', 'points_max'];
                $rows = $grp("SELECT day d, franchise_id fid, scope service, COALESCE(reason, '') typology, SUM({$n[0]}) num, SUM({$n[1]}) den FROM fr_qc WHERE day>=? AND day<=?$o" . ($code === 'quality' ? ' AND points_max IS NOT NULL' : '') . " GROUP BY day, franchise_id, scope, reason", [$from, $to]); break;
            case 'complete': $o = self::inList($ids, 'franchise_id'); $o = $ids === null ? '' : ' AND (franchise_id IS NULL OR franchise_id IN (' . ($ids ? implode(',', array_map('intval', $ids)) : '0') . '))';
                $rows = $grp("SELECT day d, COALESCE(franchise_id, 0) fid, COALESCE(service, '') service, '' typology, SUM(CASE WHEN franchise_id IS NOT NULL AND service IS NOT NULL THEN 1 ELSE 0 END) num, COUNT(*) den FROM fr_src WHERE source IN ('BOSS','TRAITEMENT') AND day>=? AND day<=?$o GROUP BY day, franchise_id, service", [$from, $to]); break;
            case 'rest': $o = self::inList($ids, 'franchise_id') . ($f['service'] !== '' ? ' AND service=?' : ''); $rows = $grp("SELECT day d, franchise_id fid, service, '' typology, COUNT(*) num, 0 den FROM fr_src WHERE source='RESTITUTION' AND franchise_id IS NOT NULL AND service IS NOT NULL AND day>=? AND day<=?$o GROUP BY day, franchise_id, service", array_merge([$from, $to], $f['service'] !== '' ? [$f['service']] : [])); break;
        }
        return self::$memo[$key] = $rows;
    }
    /** Percentile par interpolation linéaire (PERCENTILE.INC). */
    static function pct(array $v, float $p): ?float { if (!$v) return null; sort($v); $n = count($v); if ($n === 1) return (float)$v[0]; $r = ($n - 1) * $p; $lo = (int)floor($r); $hi = (int)ceil($r); return round($v[$lo] + ($v[$hi] - $v[$lo]) * ($r - $lo), 2); }

    // ───────────────────────── Stock à date de coupe ─────────────────────────
    /** @param string[] $cuts dates AAAA-MM-JJ ; @return array<string,array{stock:int,late:int,fid:array,ages:array}> */
    static function openAt(array $f, array $cuts, ?array $ids): array {
        if (!$cuts) return []; $max = max($cuts); [$w, $v] = self::reqCond(array_merge($f, ['status' => '']), $ids, 'r');
        $reqs = DB::all("SELECT r.id, r.franchise_id fid, r.created_at, r.due_at FROM fr_requests r WHERE r.created_at<=?$w", array_merge(["$max 23:59:59"], $v)); $ev = [];
        foreach (DB::all("SELECT e.request_id, e.at, e.to_status FROM fr_events e JOIN fr_requests r ON r.id=e.request_id WHERE r.created_at<=?$w ORDER BY e.at, e.id", array_merge(["$max 23:59:59"], $v)) as $e) $ev[(int)$e['request_id']][] = $e;
        $out = [];
        foreach ($cuts as $c) {
            $end = "$c 23:59:59"; $o = ['stock' => 0, 'late' => 0, 'fid' => [], 'ages' => []];
            foreach ($reqs as $r) {
                $s = Fr::statusAt($ev[(int)$r['id']] ?? [], $r['created_at'], $end); if ($s === null || !in_array($s, Fr::OPEN, true)) continue; if ($f['status'] !== '' && $s !== $f['status']) continue;
                $fid = (int)$r['fid']; $o['stock']++; $o['fid'][$fid]['stock'] = ($o['fid'][$fid]['stock'] ?? 0) + 1; $age = max(0, (strtotime($end) - strtotime($r['created_at'])) / 86400); $o['ages'][] = ['fid' => $fid, 'age' => $age, 'id' => (int)$r['id'], 's' => $s];
                if ($r['due_at'] && $r['due_at'] < $end) { $o['late']++; $o['fid'][$fid]['late'] = ($o['fid'][$fid]['late'] ?? 0) + 1; }
            }
            $out[$c] = $o;
        }
        return $out;
    }

    // ───────────────────────── Valeurs et séries ─────────────────────────
    /**
     * Valeur d'une mesure sur une plage. @return array{v:?float,num:?float,den:?float,n:int,state:string,cut:?string,weak:bool}
     * state : ok | na (dénominateur nul : « Non calculable ») | unavailable (« Donnée indisponible », plage hors historique).
     */
    static function value(string $code, array $f, string $from, string $to, ?array $ids = null, bool $useIds = false): array {
        $m = self::M[$code]; $ids = $useIds ? $ids : self::ids($f, $to); $cov = self::coverage($code); $weak = (int)Fr::setting('fr.weak_base', '20');
        $res = ['v' => null, 'num' => null, 'den' => null, 'n' => 0, 'state' => 'ok', 'cut' => null, 'weak' => false];
        $lo = $m[2] === 'stock' || in_array($code, ['median', 'p90', 'sla'], true) ? ($cov['events_from'] ?? $cov['from']) : $cov['from'];
        if (!$cov['from'] || $from > $cov['to'] || $to < $lo) { $res['state'] = 'unavailable'; return $res; }
        switch ($m[2]) {
            case 'vol': $n = 0.0; foreach (self::facts($code, $f, $from, $to, $ids) as $r) $n += $r['num']; $res['v'] = $n; $res['num'] = $n; $res['n'] = (int)$n; break;
            case 'rate': $n = 0.0; $d = 0.0; foreach (self::facts($code, $f, $from, $to, $ids) as $r) { $n += $r['num']; $d += $r['den']; } $res['num'] = $n; $res['den'] = $d; $res['n'] = (int)$d;
                if ($d > 0) $res['v'] = round($n / $d * 100, 2); else $res['state'] = 'na'; $res['weak'] = $d > 0 && $d < $weak; break;
            case 'delay': $vals = array_column(self::facts($code, $f, $from, $to, $ids), 'val'); $res['n'] = count($vals); if (!$vals) { $res['state'] = 'na'; break; } $res['v'] = self::pct($vals, $code === 'median' ? 0.5 : 0.9); $res['weak'] = count($vals) < $weak; break;
            case 'stock': $cut = min($to, $cov['to'] ?? $to, date('Y-m-d')); $res['cut'] = $cut; $o = self::openAt($f, [$cut], $ids)[$cut]; $res['v'] = (float)($code === 'late' ? $o['late'] : $o['stock']); $res['num'] = $res['v']; $res['n'] = $o['stock']; break;
        }
        return $res;
    }
    /** Série par période. @return array{periods:array,points:array<int,?array{v:?float,n:?int,state:string}>} */
    static function series(string $code, array $f, string $from, string $to, string $grain, ?array $ids = null, bool $useIds = false): array {
        $periods = self::periods($from, $to, $grain); $pts = []; $m = self::M[$code]; $ids = $useIds ? $ids : self::ids($f, $to);
        if ($m[2] === 'stock') { $cov = self::coverage($code); $cuts = []; foreach ($periods as $p) { $c = min($p['to'], $cov['to'] ?? $p['to'], date('Y-m-d')); if ($cov['from'] && $p['from'] <= $c) $cuts[$p['id']] = $c; } $o = self::openAt($f, array_values(array_unique($cuts)), $ids); }
        foreach ($periods as $i => $p) {
            if ($m[2] === 'stock') { $c = $cuts[$p['id']] ?? null; $pts[$i] = $c === null ? ['v' => null, 'n' => null, 'state' => 'unavailable', 'partial' => $p['partial']] : ['v' => (float)($code === 'late' ? $o[$c]['late'] : $o[$c]['stock']), 'n' => $o[$c]['stock'], 'state' => 'ok', 'partial' => $p['partial']]; continue; }
            $x = self::value($code, $f, $p['from'], $p['to'], $ids, true);
            if ($grain === 'day' && $m[2] === 'vol' && $x['state'] === 'ok' && (float)$x['v'] === 0.0 && (!Fr::isWork($p['from']) || $code === 'rest')) $x['state'] = 'nodata';
            $pts[$i] = ['v' => in_array($x['state'], ['ok'], true) ? $x['v'] : null, 'n' => $x['n'], 'state' => $x['state'], 'partial' => $p['partial'] || ($x['state'] === 'ok' && ($cov = self::coverage($code)) && $cov['to'] && $p['to'] > $cov['to']), 'weak' => $x['weak']];
        }
        return ['periods' => $periods, 'points' => $pts];
    }
    /** Valeur d'une mesure ventilée : clé => [v, num, den, n]. $dim : fid | service | typology. */
    static function by(string $code, array $f, string $from, string $to, string $dim, ?array $ids = null, bool $useIds = false): array {
        $m = self::M[$code]; $ids = $useIds ? $ids : self::ids($f, $to); $out = [];
        if ($m[2] === 'stock') { $cov = self::coverage($code); $cut = min($to, $cov['to'] ?? $to, date('Y-m-d')); $o = self::openAt($f, [$cut], $ids)[$cut] ?? ['fid' => []];
            if ($dim === 'fid') foreach ($o['fid'] as $fid => $x) { $v = (float)($code === 'late' ? ($x['late'] ?? 0) : ($x['stock'] ?? 0)); $out[$fid] = ['v' => $v, 'num' => $v, 'den' => null, 'n' => (int)($x['stock'] ?? 0)]; } return $out; }
        $facts = self::facts($code, $f, $from, $to, $ids); $acc = [];
        foreach ($facts as $r) { $k = $dim === 'fid' ? $r['fid'] : $r[$dim]; $acc[$k]['num'] = ($acc[$k]['num'] ?? 0) + ($r['num'] ?? 0); $acc[$k]['den'] = ($acc[$k]['den'] ?? 0) + ($r['den'] ?? 0); if (isset($r['val'])) $acc[$k]['vals'][] = $r['val']; }
        foreach ($acc as $k => $a) {
            if ($m[2] === 'vol') $out[$k] = ['v' => $a['num'], 'num' => $a['num'], 'den' => null, 'n' => (int)$a['num']];
            elseif ($m[2] === 'rate') $out[$k] = ['v' => $a['den'] > 0 ? round($a['num'] / $a['den'] * 100, 2) : null, 'num' => $a['num'], 'den' => $a['den'], 'n' => (int)$a['den']];
            else $out[$k] = ['v' => self::pct($a['vals'] ?? [], $code === 'median' ? 0.5 : 0.9), 'num' => null, 'den' => null, 'n' => count($a['vals'] ?? [])];
        }
        return $out;
    }

    // ───────────────────────── Comparaisons ─────────────────────────
    /** Écart entre deux valeurs : absolu, relatif, en points. */
    static function gap(string $code, array $a, array $b): array {
        $m = self::M[$code]; $o = ['abs' => null, 'rel' => null, 'pts' => null, 'rel_note' => ''];
        if ($a['v'] === null || $b['v'] === null) return $o;
        $o['abs'] = round($b['v'] - $a['v'], 2); if ($m[1] === '%') { $o['pts'] = $o['abs']; return $o; }
        if ((float)$a['v'] === 0.0) $o['rel_note'] = 'Variation relative indisponible (A = 0)'; else $o['rel'] = round(($b['v'] - $a['v']) / $a['v'] * 100, 2);
        return $o;
    }
    /** Normalisation par jour ouvré couvert (si le calendrier est validé et la mesure est un volume). */
    static function perWorkday(array $x, string $from, string $to): ?float { $d = Fr::workDaysBetween($from, $to); return $d > 0 && $x['v'] !== null ? round($x['v'] / $d, 2) : null; }
    /** Contexte de comparabilité d'une plage : bornes, jours calendaires/ouvrés, fraîcheur, partiel. */
    static function span(string $from, string $to, string $code = 'received'): array {
        $cov = self::coverage($code); $lim = $cov['to'] ?? null;
        return ['from' => $from, 'to' => $to, 'days' => Fr::daysBetween($from, $to), 'work' => Fr::workDaysBetween($from, $to), 'fresh' => $lim, 'partial' => $lim === null ? true : ($to > $lim), 'covered' => $lim !== null && $cov['from'] !== null && $from <= $lim && $to >= $cov['from']];
    }
    static function overlap(string $a1, string $a2, string $b1, string $b2): bool { return $a1 <= $b2 && $b1 <= $a2; }
    /** Alignement sur un même nombre de jours écoulés : raccourcit la plage la plus longue. */
    static function align(array $r1, array $r2): array { $d = min(Fr::daysBetween($r1[0], $r1[1]), Fr::daysBetween($r2[0], $r2[1])); return [[$r1[0], Fr::addDays($r1[0], $d - 1)], [$r2[0], Fr::addDays($r2[0], $d - 1)]]; }
    /** Raccourcis de période : précédente (même durée) ou même période de l'année précédente. */
    static function shift(string $from, string $to, string $how): array { if ($how === 'year') return [date('Y-m-d', strtotime("$from -1 year")), date('Y-m-d', strtotime("$to -1 year"))]; $n = Fr::daysBetween($from, $to); return [Fr::addDays($from, -$n), Fr::addDays($from, -1)]; }
    /** Contribution à l'écart de volume A → B par dimension, avec Top N et reliquat « Autres ». */
    static function contributions(string $code, array $f, array $A, array $B, string $dim, int $top = 8): array {
        $a = self::by($code, $f, $A[0], $A[1], $dim); $b = self::by($code, $f, $B[0], $B[1], $dim); $keys = array_unique(array_merge(array_keys($a), array_keys($b))); $rows = [];
        foreach ($keys as $k) $rows[] = ['key' => $k, 'a' => $a[$k]['v'] ?? 0, 'b' => $b[$k]['v'] ?? 0, 'diff' => ($b[$k]['v'] ?? 0) - ($a[$k]['v'] ?? 0)];
        usort($rows, fn($x, $y) => abs($y['diff']) <=> abs($x['diff'])); $head = array_slice($rows, 0, $top); $rest = array_slice($rows, $top);
        if ($rest) $head[] = ['key' => '__other', 'a' => array_sum(array_column($rest, 'a')), 'b' => array_sum(array_column($rest, 'b')), 'diff' => array_sum(array_column($rest, 'diff')), 'n' => count($rest)];
        return $head;
    }
    /** Rang et percentile d'une valeur parmi des valeurs (le plus élevé = rang 1). */
    static function rank(array $vals, $v): array { $c = array_values(array_filter($vals, fn($x) => $x !== null)); rsort($c); $r = 1; foreach ($c as $x) if ($x > $v) $r++; $n = count($c); return [$r, $n > 1 ? round(100 * ($n - $r) / ($n - 1)) : 100]; }
}
