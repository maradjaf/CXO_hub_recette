<?php
namespace App\Core;
/** Modes opératoires (base de connaissances) : références, versions, accusés de lecture, recherche. Les accusés servent aussi aux scripts (kind = 'script'). */
class Sop {
    const RISK = ['normal' => 'Courant', 'critical' => 'Critique'];
    static function months(): int { $m = (int)setting('kb.sop_review_months', 12); return $m >= 1 && $m <= 60 ? $m : 12; }
    static function nextRef(string $table = 'kb_sops', string $prefix = 'MO'): string {
        $n = (int)DB::val("SELECT COUNT(*) FROM $table") + 1; do { $r = sprintf('%s-%03d', $prefix, $n++); } while (DB::val("SELECT 1 FROM $table WHERE ref=?", [$r]));
        return $r;
    }
    static function visibleSql(string $a = 'a'): string { return "$a.status='published'" . (Kb::canInternal() ? '' : " AND $a.internal=0"); }
    static function steps(int $id): array { return DB::all('SELECT * FROM kb_sop_steps WHERE sop_id=? ORDER BY position', [$id]); }
    static function duration(array $s, array $steps): int { $t = array_sum(array_map(fn($x) => (int)$x['duration_min'], $steps)); return $t ?: (int)$s['estimated_min']; }
    const FIELDS = ['title', 'summary', 'category_id', 'objective', 'scope', 'prerequisites', 'tools', 'tags', 'owner_id', 'estimated_min', 'risk_level', 'mandatory', 'team_id', 'internal'];
    /** Mémorise la version courante (champs + étapes) pour l'historique et la restauration. */
    static function snapshot(int $id, ?string $note = null): void {
        $s = DB::one('SELECT * FROM kb_sops WHERE id=?', [$id]); if (!$s) return;
        $data = ['f' => array_intersect_key($s, array_flip(self::FIELDS)), 'steps' => array_map(fn($x) => array_diff_key($x, ['id' => 1, 'sop_id' => 1]), self::steps($id))];
        $old = DB::one('SELECT id FROM kb_sop_versions WHERE sop_id=? AND version=?', [$id, (int)$s['version']]);
        $row = ['data' => json_encode($data, JSON_UNESCAPED_UNICODE), 'user_id' => Auth::id(), 'user_name' => (string)(Auth::user()['name'] ?? ''), 'note' => $note ? mb_substr($note, 0, 200) : null, 'created_at' => now()];
        if ($old) DB::update('kb_sop_versions', $row, 'id=?', [(int)$old['id']]); else DB::insert('kb_sop_versions', $row + ['sop_id' => $id, 'version' => (int)$s['version']]);
    }
    static function replaceSteps(int $id, array $steps): void {
        DB::exec('DELETE FROM kb_sop_steps WHERE sop_id=?', [$id]); $i = 0;
        foreach ($steps as $x) DB::insert('kb_sop_steps', ['sop_id' => $id, 'position' => ++$i, 'title' => $x['title'], 'instruction' => $x['instruction'] ?? null, 'expected' => $x['expected'] ?? null, 'warning' => $x['warning'] ?? null, 'tool' => $x['tool'] ?? null, 'role' => $x['role'] ?? null, 'duration_min' => $x['duration_min'] ?? null, 'article_id' => $x['article_id'] ?? null]);
    }
    /** Lit les étapes saisies (tableaux st_title[], st_inst[]…) ; ignore les lignes vides. @return array{0:array,1:?string} */
    static function readSteps(): array {
        $t = (array)($_POST['st_title'] ?? []); $out = [];
        foreach ($t as $i => $title) {
            $title = trim((string)$title); $inst = trim((string)($_POST['st_inst'][$i] ?? '')); if ($title === '' && $inst === '') continue;
            if ($title === '') return [[], 'Chaque étape doit avoir un titre.'];
            $min = trim((string)($_POST['st_min'][$i] ?? '')); if ($min !== '' && (!ctype_digit($min) || (int)$min > 1440)) return [[], 'Durée d\'étape invalide (minutes, 0 à 1440).'];
            $art = (int)($_POST['st_art'][$i] ?? 0);
            $out[] = ['title' => mb_substr($title, 0, 200), 'instruction' => mb_substr($inst, 0, 4000) ?: null, 'expected' => mb_substr(trim((string)($_POST['st_exp'][$i] ?? '')), 0, 500) ?: null, 'warning' => mb_substr(trim((string)($_POST['st_warn'][$i] ?? '')), 0, 500) ?: null,
                'tool' => mb_substr(trim((string)($_POST['st_tool'][$i] ?? '')), 0, 150) ?: null, 'role' => mb_substr(trim((string)($_POST['st_role'][$i] ?? '')), 0, 100) ?: null, 'duration_min' => $min !== '' ? (int)$min : null, 'article_id' => $art && DB::val('SELECT 1 FROM kb_articles WHERE id=?', [$art]) ? $art : null];
            if (count($out) > 80) return [[], '80 étapes au maximum.'];
        }
        return [$out, null];
    }
    // ---- Accusés de lecture (modes opératoires et scripts) ----
    static function acked(string $kind, int $id, int $version, int $uid): bool { return (bool)DB::val('SELECT 1 FROM kb_acks WHERE kind=? AND item_id=? AND version=? AND user_id=?', [$kind, $id, $version, $uid]); }
    static function ack(string $kind, int $id, int $version, int $uid): void { if (!self::acked($kind, $id, $version, $uid)) DB::insert('kb_acks', ['kind' => $kind, 'item_id' => $id, 'version' => $version, 'user_id' => $uid, 'read_at' => now()]); }
    /** Collaborateurs concernés par une lecture obligatoire (équipe visée ou tout le personnel actif disposant d'un compte). @return array[] id, first_name, last_name, user_id */
    static function audience(?int $teamId): array {
        return DB::all("SELECT e.id, e.first_name, e.last_name, e.matricule, u.id user_id FROM employees e JOIN users u ON u.employee_id=e.id AND u.status='active' WHERE e.status<>'left'" . ($teamId ? ' AND e.team_id=?' : '') . ' ORDER BY e.last_name, e.first_name', $teamId ? [$teamId] : []);
    }
    /** Lectures obligatoires en attente pour l'utilisateur courant : modes opératoires et scripts publiés dont la version courante n'est pas accusée. */
    static function pendingReads(?int $uid = null, ?int $team = null): array {
        $uid ??= Auth::id(); if (!$uid) return []; $team ??= (int)DB::val('SELECT e.team_id FROM users u JOIN employees e ON e.id=u.employee_id WHERE u.id=?', [$uid]);
        $out = [];
        foreach (DB::all("SELECT id, ref, title, version, team_id, internal FROM kb_sops WHERE status='published' AND mandatory=1") as $s) if ((!$s['team_id'] || (int)$s['team_id'] === $team) && !self::acked('sop', (int)$s['id'], (int)$s['version'], $uid)) $out[] = ['kind' => 'sop', 'id' => (int)$s['id'], 'ref' => $s['ref'], 'title' => $s['title'], 'version' => (int)$s['version'], 'url' => '/kb/sops/' . $s['id']];
        foreach (DB::all("SELECT id, ref, title, version, team_id FROM cs_scripts WHERE status='published' AND mandatory=1") as $s) if ((!$s['team_id'] || (int)$s['team_id'] === $team) && !self::acked('script', (int)$s['id'], (int)$s['version'], $uid)) $out[] = ['kind' => 'script', 'id' => (int)$s['id'], 'ref' => $s['ref'], 'title' => $s['title'], 'version' => (int)$s['version'], 'url' => '/cs/' . $s['id']];
        return $out;
    }
    static function search(string $q, int $limit = 20, ?int $category = null): array {
        $terms = array_slice(array_values(array_filter(preg_split('/\s+/u', mb_strtolower(trim($q))), fn($t) => mb_strlen($t) >= 2)), 0, 6); if (!$terms) return [];
        $w = [self::visibleSql()]; $p = [];
        foreach ($terms as $t) { $w[] = "(LOWER(a.title) LIKE ? ESCAPE '!' OR LOWER(a.summary) LIKE ? ESCAPE '!' OR LOWER(a.tags) LIKE ? ESCAPE '!' OR LOWER(a.objective) LIKE ? ESCAPE '!' OR a.id IN (SELECT sop_id FROM kb_sop_steps WHERE LOWER(title) LIKE ? ESCAPE '!' OR LOWER(instruction) LIKE ? ESCAPE '!'))"; $l = '%' . str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $t) . '%'; array_push($p, $l, $l, $l, $l, $l, $l); }
        if ($category) { $w[] = 'a.category_id=?'; $p[] = $category; }
        return DB::all('SELECT a.id, a.ref, a.title, a.summary, a.risk_level, a.version, c.name category FROM kb_sops a LEFT JOIN kb_categories c ON c.id=a.category_id WHERE ' . implode(' AND ', $w) . ' ORDER BY a.title LIMIT ' . (int)$limit, $p);
    }
}
