<?php
namespace App\Core;
/**
 * Pièces jointes : types autorisés (images, documents, tableurs, présentations, audio, vidéo, archives), contrôle du contenu (signature du fichier,
 * pas seulement l'extension), taille et nombre maximaux réglables (réglages files.max_mb et files.max_count). Stockage hors du dossier public.
 * Ne sont jamais acceptés : scripts, exécutables, HTML, SVG (risque d'injection de code).
 */
class Files {
    const GROUPS = [
        'Images et captures' => ['png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'gif' => 'image/gif', 'webp' => 'image/webp', 'bmp' => 'image/bmp'],
        'Documents' => ['pdf' => 'application/pdf', 'doc' => 'application/msword', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'odt' => 'application/vnd.oasis.opendocument.text', 'rtf' => 'application/rtf', 'txt' => 'text/plain', 'eml' => 'message/rfc822'],
        'Tableurs et données' => ['xls' => 'application/vnd.ms-excel', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'ods' => 'application/vnd.oasis.opendocument.spreadsheet', 'csv' => 'text/csv', 'json' => 'application/json', 'log' => 'text/plain'],
        'Présentations' => ['ppt' => 'application/vnd.ms-powerpoint', 'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'odp' => 'application/vnd.oasis.opendocument.presentation'],
        'Audio (messages vocaux)' => ['mp3' => 'audio/mpeg', 'wav' => 'audio/wav', 'm4a' => 'audio/mp4', 'ogg' => 'audio/ogg', 'opus' => 'audio/ogg'],
        'Vidéo (enregistrements d\'écran)' => ['mp4' => 'video/mp4', 'mov' => 'video/quicktime', 'webm' => 'video/webm'],
        'Archives' => ['zip' => 'application/zip'],
    ];
    const DEFAULTS = ['files.max_mb' => '10', 'files.max_count' => '10'];
    /** Groupes de formats autorisés (réglage `files.groups`, liste de noms ; vide = tous). */
    static function groups(): array { $sel = Xchg::csv('files.groups'); $o = []; foreach (self::GROUPS as $n => $g) if (!$sel || in_array($n, $sel, true)) $o[$n] = $g; return $o ?: self::GROUPS; }
    static function types(): array { $o = []; foreach (self::groups() as $g) $o += $g; return $o; }
    static function accept(): string { return '.' . implode(',.', array_keys(self::types())); }
    static function set(string $k) { return Settings::get($k, self::DEFAULTS[$k] ?? null); }
    private static function ini(string $k): int { $v = trim((string)ini_get($k)); $n = (int)$v; return match (strtolower(substr($v, -1))) { 'g' => $n * 1073741824, 'm' => $n * 1048576, 'k' => $n * 1024, default => $n }; }
    /** Taille maximale par fichier, en octets : réglage, plafonné par la configuration PHP. */
    static function maxBytes(): int { $cfg = max(1, min(100, (int)self::set('files.max_mb'))) * 1048576; $php = self::ini('upload_max_filesize'); return $php > 0 ? min($cfg, $php) : $cfg; }
    static function maxCount(): int { return max(1, min(30, (int)self::set('files.max_count'))); }
    static function hint(): string { return self::maxCount() . ' fichiers maximum, ' . round(self::maxBytes() / 1048576, 1) . ' Mo chacun. Formats : ' . mb_strtolower(implode(', ', array_map(fn($n) => trim(preg_replace('/\\s*\\(.*\\)/u', '', $n)), array_keys(self::groups())))) . '.'; }
    static function size(int $b): string { return $b >= 1048576 ? round($b / 1048576, 1) . ' Mo' : max(1, round($b / 1024)) . ' Ko'; }
    static function icon(string $name): string {
        $e = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        return match (true) { in_array($e, ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'], true) => 'file-earmark-image', $e === 'pdf' => 'file-earmark-pdf', in_array($e, ['doc', 'docx', 'odt', 'rtf', 'txt', 'eml'], true) => 'file-earmark-text', in_array($e, ['xls', 'xlsx', 'ods', 'csv', 'json', 'log'], true) => 'file-earmark-spreadsheet',
            in_array($e, ['ppt', 'pptx', 'odp'], true) => 'file-earmark-slides', in_array($e, ['mp3', 'wav', 'm4a', 'ogg', 'opus'], true) => 'file-earmark-music', in_array($e, ['mp4', 'mov', 'webm'], true) => 'file-earmark-play', $e === 'zip' => 'file-earmark-zip', default => 'paperclip' };
    }
    static function cleanName(string $name): string { $name = trim(preg_replace('#[\x00-\x1f\\\\/]+#', '', basename(str_replace('\\', '/', $name)))); return mb_substr($name !== '' ? $name : 'fichier', -150); }
    /** Contrôle d'un fichier en mémoire. @return array{0:?string,1:string,2:string} erreur, extension, type MIME */
    static function check(string $name, string $bytes): array {
        $name = self::cleanName($name); $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION)); $types = self::types();
        if (!isset($types[$ext])) return ["« $name » : type de fichier non autorisé.", $ext, ''];
        if ($bytes === '') return ["« $name » : fichier vide.", $ext, ''];
        if (strlen($bytes) > self::maxBytes()) return ["« $name » : dépasse " . round(self::maxBytes() / 1048576, 1) . ' Mo.', $ext, ''];
        $h = substr($bytes, 0, 12);
        $ok = match ($ext) {
            'png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp' => @getimagesizefromstring($bytes) !== false, 'pdf' => str_starts_with($bytes, '%PDF'), 'docx', 'xlsx', 'pptx', 'odt', 'ods', 'odp', 'zip' => str_starts_with($bytes, 'PK'),
            'doc', 'xls', 'ppt' => str_starts_with($bytes, "\xD0\xCF\x11\xE0"), 'rtf' => str_starts_with($bytes, '{\\rtf'), 'mp3' => str_starts_with($h, 'ID3') || ($h !== '' && ord($h[0]) === 0xFF), 'wav' => str_starts_with($h, 'RIFF'),
            'ogg', 'opus' => str_starts_with($h, 'OggS'), 'm4a', 'mp4', 'mov' => substr($h, 4, 4) === 'ftyp' || in_array(substr($h, 4, 4), ['moov', 'wide', 'mdat', 'free'], true), 'webm' => str_starts_with($h, "\x1A\x45\xDF\xA3"),
            default => !str_contains(substr($bytes, 0, 2000), "\0") };
        if (!$ok) return ["« $name » : le contenu ne correspond pas au type du fichier.", $ext, ''];
        return [null, $ext, $types[$ext]];
    }
    static function dir(string $sub): string { $d = ROOT . '/storage/uploads/' . $sub; if (!is_dir($d)) @mkdir($d, 0775, true); return $d; }
    /** Lit $_FILES[$field] (multiple) : fichiers valides [nom, contenu, ext, mime] et erreurs, dans la limite du nombre autorisé. @return array{0:array,1:array} */
    static function uploads(string $field, int $already = 0): array {
        $out = []; $err = []; $f = $_FILES[$field] ?? null; if (!$f || !is_array($f['name'])) return [$out, $err]; $n = 0;
        foreach ($f['name'] as $i => $name) {
            if ($f['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
            if (++$n + $already > self::maxCount()) { $err[] = 'Nombre maximal de pièces jointes atteint (' . self::maxCount() . ') : les suivantes sont ignorées.'; break; }
            if (in_array($f['error'][$i], [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)) { $err[] = "« $name » dépasse la taille maximale acceptée par le serveur (" . ini_get('upload_max_filesize') . ').'; continue; }
            if ($f['error'][$i] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'][$i])) { $err[] = "« $name » : envoi échoué."; continue; }
            $bytes = (string)file_get_contents($f['tmp_name'][$i]); [$e, $ext, $mime] = self::check((string)$name, $bytes);
            if ($e) { $err[] = $e; continue; }
            $out[] = ['name' => self::cleanName((string)$name), 'bytes' => $bytes, 'ext' => $ext, 'mime' => $mime];
        }
        return [$out, $err];
    }
    /** Écrit le fichier sur disque ; retourne le nom stocké (aléatoire) ou null. */
    static function put(string $sub, string $bytes, string $ext): ?string { $s = bin2hex(random_bytes(16)) . '.' . $ext; return file_put_contents(self::dir($sub) . '/' . $s, $bytes) === false ? null : $s; }
    /** Envoie le fichier en téléchargement (jamais interprété par le navigateur). */
    static function send(string $sub, string $stored, string $name, string $mime): never {
        $path = self::dir($sub) . '/' . basename($stored); if (!is_file($path)) { http_response_code(404); exit('Fichier introuvable.'); }
        header('Content-Type: ' . $mime); header('X-Content-Type-Options: nosniff'); header('Content-Length: ' . filesize($path));
        header('Content-Disposition: attachment; filename="' . rawurlencode($name) . '"; filename*=UTF-8\'\'' . rawurlencode($name)); readfile($path); exit;
    }
}
