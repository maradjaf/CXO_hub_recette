<?php
namespace App\Core;
/** Imports par fichier CSV (M05) : contrôle ligne à ligne avant validation, création ou mise à jour par clé. */
class Importer {
    const DOMAINS = [
        'employees' => ['label' => 'Collaborateurs', 'perm' => 'employees.import', 'key' => 'matricule',
            'cols' => ['matricule', 'last_name', 'first_name', 'email', 'phone', 'team_code', 'store_code', 'position_code', 'hire_date', 'contract_type', 'employer', 'unit_code', 'status', 'qa_ref_type', 'qa_ref'],
            'sample' => ['M0001', 'Agbo', 'Kossi', 'kossi.agbo@exemple.tg', '90000000', 'EQ01', 'ST01', 'CONSEILLER', '2024-03-04', 'CDI', 'YAS', '', 'active', 'HERMES', 'HRM-0001']],
        'teams' => ['label' => 'Équipes', 'perm' => 'org.manage', 'key' => 'code', 'cols' => ['code', 'name', 'channel_code'], 'sample' => ['EQ01', 'Équipe Réclamations', 'CALLCENTER']],
        'stores' => ['label' => 'Stores', 'perm' => 'org.manage', 'key' => 'code', 'cols' => ['code', 'name', 'city', 'region', 'address', 'situation', 'email', 'phone', 'phone2', 'gps_lat', 'gps_lng', 'hours'], 'sample' => ['ST01', 'Store exemple', 'Lomé', 'Maritime', 'Boulevard du 13 Janvier', 'En face de la pharmacie', 'store01@exemple.tg', '+228 90 00 00 00', '', '6.131900', '1.222800', 'Lun-Sam 8h-18h']],
        'ref_values' => ['label' => 'Valeurs de référentiel', 'perm' => 'referentials.manage', 'key' => 'list_code+code', 'cols' => ['list_code', 'code', 'label', 'sort_order', 'color'], 'sample' => ['assistance_reasons', 'PANNE_PC', 'Panne de PC', '10', '']],
        'geo_ranges' => ['label' => 'Plages IP et lieux', 'perm' => 'settings.manage', 'key' => 'ip_from', 'cols' => ['ip_from', 'ip_to', 'country', 'city'], 'sample' => ['41.207.0.0', '41.207.255.255', 'Togo', 'Lomé']],
    ];
    static function parse(string $path): array {
        $raw = file_get_contents($path);
        if (str_starts_with($raw, "\xEF\xBB\xBF")) $raw = substr($raw, 3);
        if (!mb_check_encoding($raw, 'UTF-8')) $raw = mb_convert_encoding($raw, 'UTF-8', 'Windows-1252');
        $first = strtok($raw, "\n"); $delim = substr_count($first, ';') >= substr_count($first, ',') ? ';' : ',';
        $f = fopen('php://temp', 'r+'); fwrite($f, $raw); rewind($f);
        $head = array_map(fn($h) => strtolower(trim($h)), fgetcsv($f, 0, $delim) ?: []);
        $rows = []; $n = 1;
        while (($r = fgetcsv($f, 0, $delim)) !== false) { $n++; if ($r === [null] || !array_filter($r, fn($x) => trim((string)$x) !== '')) continue; $rows[] = ['line' => $n, 'data' => array_combine($head, array_pad(array_map('trim', $r), count($head), '')) ?: []]; }
        fclose($f);
        return [$head, $rows];
    }
    /** @return array{0:array,1:?string} données normalisées, message d'erreur */
    static function check(string $domain, array $r): array {
        $c = self::DOMAINS[$domain]; $r = array_merge(array_fill_keys($c['cols'], ''), $r);
        $req = ['employees' => ['matricule', 'last_name', 'first_name'], 'teams' => ['code', 'name'], 'stores' => ['code', 'name'], 'ref_values' => ['list_code', 'code', 'label'], 'geo_ranges' => ['ip_from', 'ip_to']][$domain];
        foreach ($req as $f) if (($r[$f] ?? '') === '') return [$r, "Colonne « $f » obligatoire"];
        if ($domain === 'stores') {
            if ($r['email'] !== '' && !filter_var($r['email'], FILTER_VALIDATE_EMAIL)) return [$r, 'E-mail du store invalide'];
            foreach (['gps_lat' => 90, 'gps_lng' => 180] as $f => $lim) if ($r[$f] !== '') { $v = str_replace(',', '.', $r[$f]); if (!is_numeric($v) || abs((float)$v) > $lim) return [$r, "Coordonnée « $f » invalide"]; $r[$f] = number_format((float)$v, 6, '.', ''); }
            if (($r['gps_lat'] === '') !== ($r['gps_lng'] === '')) return [$r, 'Latitude et longitude vont ensemble'];
        }
        switch ($domain) {
            case 'employees':
                if ($r['email'] !== '' && !filter_var($r['email'], FILTER_VALIDATE_EMAIL)) return [$r, 'Email invalide'];
                if ($r['hire_date'] !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $r['hire_date'])) return [$r, 'Date d\'embauche : format AAAA-MM-JJ attendu'];
                foreach (['employer' => 'employers', 'contract_type' => 'contract_types'] as $f => $lst) { if ($r[$f] === '') continue; $c = $f === 'employer' ? DB::val('SELECT code FROM employers WHERE active=1 AND (UPPER(code)=UPPER(?) OR UPPER(name)=UPPER(?))', [$r[$f], $r[$f]]) : DB::val('SELECT v.code FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code=? AND (UPPER(v.code)=UPPER(?) OR UPPER(v.label)=UPPER(?))', [$lst, $r[$f], $r[$f]]); if (!$c) return [$r, ($f === 'employer' ? 'Employeur' : 'Type de contrat') . ' inconnu : ' . $r[$f] . ' (voir RH › Sociétés employeuses)']; $r[$f] = (string)$c; }
                if ($r['unit_code'] !== '' && !DB::val('SELECT 1 FROM org_units WHERE code=?', [$r['unit_code']])) return [$r, 'Code d\'unité (activité) inconnu : ' . $r['unit_code']];
                $r['status'] = $r['status'] ?: 'active';
                if (!in_array($r['status'], ['active', 'inactive', 'left'], true)) return [$r, 'Statut inconnu (active, inactive, left)'];
                foreach (['team_code' => 'teams', 'store_code' => 'stores', 'position_code' => 'positions'] as $f => $t) if ($r[$f] !== '' && !DB::val("SELECT 1 FROM $t WHERE code=?", [$r[$f]])) return [$r, "Code inconnu dans « $f » : {$r[$f]}"];
                break;
            case 'teams': if ($r['channel_code'] !== '' && !DB::val('SELECT 1 FROM channels WHERE code=?', [$r['channel_code']])) return [$r, 'Canal inconnu : ' . $r['channel_code']]; break;
            case 'ref_values': if (!DB::val('SELECT 1 FROM ref_lists WHERE code=?', [$r['list_code']])) return [$r, 'Liste inconnue : ' . $r['list_code']]; break;
            case 'geo_ranges': if (ip2long($r['ip_from']) === false || ip2long($r['ip_to']) === false) return [$r, 'Adresses IPv4 attendues']; break;
        }
        return [$r, null];
    }
    static function save(string $domain, array $r): string {
        switch ($domain) {
            case 'employees':
                $d = ['first_name' => $r['first_name'], 'last_name' => $r['last_name'], 'email' => $r['email'] ?: null, 'phone' => $r['phone'] ?: null, 'hire_date' => $r['hire_date'] ?: null,
                    'contract_type' => $r['contract_type'] ?: null, 'employer' => $r['employer'] ?: null, 'status' => $r['status'], 'updated_at' => now()];
                if ($r['qa_ref'] !== '') { $d['qa_ref'] = $r['qa_ref']; $d['qa_ref_type'] = $r['qa_ref_type'] ?: 'HERMES'; }
                $uid = $r['unit_code'] !== '' ? (int)DB::val('SELECT id FROM org_units WHERE code=?', [$r['unit_code']]) : 0;
                foreach (['team_code' => ['team_id', 'teams'], 'store_code' => ['store_id', 'stores'], 'position_code' => ['position_id', 'positions']] as $f => [$col, $t]) $d[$col] = $r[$f] !== '' ? (int)DB::val("SELECT id FROM $t WHERE code=?", [$r[$f]]) : null;
                $id = DB::val('SELECT id FROM employees WHERE matricule=?', [$r['matricule']]);
                $unit = ($d['team_id'] ? DB::val('SELECT org_unit_id FROM teams WHERE id=?', [$d['team_id']]) : null) ?: ($d['store_id'] ? DB::val('SELECT org_unit_id FROM stores WHERE id=?', [$d['store_id']]) : null) ?: null;
                $unit = $uid ?: $unit; $lvl = $d['position_id'] ? DB::val('SELECT org_level FROM positions WHERE id=?', [$d['position_id']]) : null;
                if ($id) { $cur = DB::one('SELECT org_unit_id, org_level FROM employees WHERE id=?', [$id]); if (($uid || $cur['org_unit_id'] === null) && $unit) $d['org_unit_id'] = (int)$unit; if ($cur['org_level'] === null) $d['org_level'] = (int)$lvl; DB::update('employees', $d, 'id=?', [$id]); return 'mis à jour'; }
                DB::insert('employees', $d + ['org_unit_id' => $unit ? (int)$unit : null, 'org_level' => (int)$lvl, 'matricule' => $r['matricule'], 'created_at' => now()]); return 'créé';
            case 'teams': case 'stores':
                $d = $domain === 'teams' ? ['name' => $r['name'], 'channel_id' => $r['channel_code'] ? (int)DB::val('SELECT id FROM channels WHERE code=?', [$r['channel_code']]) : null]
                    : ['name' => $r['name'], 'city' => $r['city'] ?: null, 'region' => $r['region'] ?: null];
                if ($domain === 'stores') foreach (['address', 'situation', 'email', 'phone', 'phone2', 'gps_lat', 'gps_lng', 'hours'] as $f) if ($r[$f] !== '') $d[$f] = $r[$f];
                $id = DB::val("SELECT id FROM $domain WHERE code=?", [$r['code']]);
                if ($id) { DB::update($domain, $d, 'id=?', [$id]); return 'mis à jour'; }
                DB::insert($domain, $d + ['code' => $r['code'], 'active' => 1]); return 'créé';
            case 'ref_values':
                $lid = (int)DB::val('SELECT id FROM ref_lists WHERE code=?', [$r['list_code']]);
                $d = ['label' => $r['label'], 'sort_order' => (int)$r['sort_order'], 'color' => $r['color'] ?: null];
                $id = DB::val('SELECT id FROM ref_values WHERE list_id=? AND code=?', [$lid, $r['code']]);
                if ($id) { DB::update('ref_values', $d, 'id=?', [$id]); return 'mis à jour'; }
                DB::insert('ref_values', $d + ['list_id' => $lid, 'code' => $r['code'], 'active' => 1]); return 'créé';
            case 'geo_ranges':
                DB::insert('geo_ranges', ['ip_from' => ip2long($r['ip_from']), 'ip_to' => ip2long($r['ip_to']), 'country' => $r['country'] ?: null, 'city' => $r['city'] ?: null]); return 'créé';
        }
        return '';
    }
}
