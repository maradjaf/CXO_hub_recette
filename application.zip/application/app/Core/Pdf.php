<?php
namespace App\Core;
/** Générateur PDF minimal (une page A4 paysage, Helvetica standard, aucun fichier externe) pour les certificats de réussite. */
class Pdf {
    private const W = [278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584];
    private const WB = [278,333,474,556,556,889,722,238,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,333,333,584,584,584,611,975,722,722,722,722,667,611,778,722,278,556,722,611,833,722,778,667,778,722,667,611,722,667,944,667,667,611,333,278,333,584,556,333,556,611,556,611,556,333,611,611,278,278,556,278,889,611,611,611,611,389,556,333,611,556,778,556,556,500,389,280,389,584];
    private string $c = '';
    private array $imgs = [];
    static function enc(string $s): string { $o = @iconv('UTF-8', 'CP1252//TRANSLIT//IGNORE', $s); return $o === false ? preg_replace('/[^\x20-\x7e]/', '?', $s) : $o; }
    static function width(string $s, float $size, bool $bold = false): float {
        $t = $bold ? self::WB : self::W; $w = 0;
        foreach (str_split(self::enc($s)) as $ch) { $o = ord($ch); $w += ($o >= 32 && $o <= 126) ? $t[$o - 32] : ($bold ? 611 : 556); }
        return $w * $size / 1000;
    }
    private static function esc(string $s): string { return str_replace(['\\', '(', ')', "\r", "\n"], ['\\\\', '\\(', '\\)', '', ' '], self::enc($s)); }
    private static function rgb(string $hex): string { return sprintf('%.3f %.3f %.3f', hexdec(substr($hex, 0, 2)) / 255, hexdec(substr($hex, 2, 2)) / 255, hexdec(substr($hex, 4, 2)) / 255); }
    function rect(float $x, float $y, float $w, float $h, string $fill): void { $this->c .= self::rgb($fill) . " rg $x $y $w $h re f\n"; }
    function frame(float $x, float $y, float $w, float $h, string $stroke, float $lw): void { $this->c .= self::rgb($stroke) . " RG $lw w $x $y $w $h re S\n"; }
    /** Texte centré horizontalement sur la page de largeur $pageW ; réduit la taille si la ligne dépasse $max. */
    function center(string $s, float $y, float $size, string $color = '000000', bool $bold = false, float $pageW = 842, float $max = 640, bool $italic = false): void {
        while ($size > 8 && self::width($s, $size, $bold) > $max) $size -= 1;
        $x = round(($pageW - self::width($s, $size, $bold)) / 2, 2);
        $this->c .= 'BT ' . self::rgb($color) . ' rg /' . self::font($bold, $italic) . " $size Tf $x $y Td (" . self::esc($s) . ") Tj ET\n";
    }
    private static function font(bool $bold, bool $italic): string { return $bold ? ($italic ? 'F4' : 'F2') : ($italic ? 'F3' : 'F1'); }
    /** Chemin rempli et/ou tracé. $cmds : ['m',x,y] ['l',x,y] ['c',x1,y1,x2,y2,x3,y3] ['h']. */
    function path(array $cmds, ?string $fill, ?string $stroke = null, float $lw = 1.0, bool $join = true): void {
        $o = self::pathOps($cmds); if ($fill !== null) $this->c .= self::rgb($fill) . ' rg '; if ($stroke !== null) $this->c .= self::rgb($stroke) . " RG $lw w " . ($join ? '1 j 1 J ' : '');
        $this->c .= $o . ($fill !== null && $stroke !== null ? 'B' : ($fill !== null ? 'f' : 'S')) . "\n";
    }
    private static function pathOps(array $cmds): string { $o = ''; foreach ($cmds as $k) { $o .= match ($k[0]) { 'm' => sprintf('%.2f %.2f m ', $k[1], $k[2]), 'l' => sprintf('%.2f %.2f l ', $k[1], $k[2]), 'c' => sprintf('%.2f %.2f %.2f %.2f %.2f %.2f c ', $k[1], $k[2], $k[3], $k[4], $k[5], $k[6]), default => 'h ' }; } return $o; }
    /** Cercle (4 courbes de Bézier). */
    static function circle(float $cx, float $cy, float $r): array {
        $k = 0.5523 * $r; return [['m', $cx + $r, $cy], ['c', $cx + $r, $cy + $k, $cx + $k, $cy + $r, $cx, $cy + $r], ['c', $cx - $k, $cy + $r, $cx - $r, $cy + $k, $cx - $r, $cy], ['c', $cx - $r, $cy - $k, $cx - $k, $cy - $r, $cx, $cy - $r], ['c', $cx + $k, $cy - $r, $cx + $r, $cy - $k, $cx + $r, $cy], ['h']];
    }
    /** Polygone régulier ou étoile : $n pointes, rayon extérieur $r, rayon intérieur $ri (= $r pour un polygone), première pointe vers le haut. */
    static function star(float $cx, float $cy, float $r, float $ri, int $n): array {
        $c = []; for ($i = 0; $i < 2 * $n; $i++) { $a = M_PI / 2 + $i * M_PI / $n; $rr = $i % 2 ? $ri : $r; $c[] = [$i ? 'l' : 'm', $cx + $rr * cos($a), $cy + $rr * sin($a)]; } $c[] = ['h']; return $c;
    }
    /** Image JPEG détourée par un chemin (le chemin est donné dans les coordonnées de la page). */
    function imageClipped(string $file, float $x, float $y, float $w, float $h, array $clip): void {
        if (!is_file($file) || !($i = @getimagesize($file)) || $i[2] !== IMAGETYPE_JPEG) return;
        $n = count($this->imgs) + 1; $this->imgs[$n] = ['d' => (string)file_get_contents($file), 'w' => $i[0], 'h' => $i[1], 'c' => ($i['channels'] ?? 3) == 1 ? '/DeviceGray' : '/DeviceRGB'];
        $this->c .= 'q ' . self::pathOps($clip) . "W n q $w 0 0 $h $x $y cm /Im$n Do Q Q\n";
    }
    /** Image JPEG (DCT) placée dans la page ; ignorée si le fichier est absent ou n'est pas un JPEG. */
    function image(string $file, float $x, float $y, float $w, float $h): void {
        if (!is_file($file) || !($i = @getimagesize($file)) || $i[2] !== IMAGETYPE_JPEG) return;
        $n = count($this->imgs) + 1; $this->imgs[$n] = ['d' => (string)file_get_contents($file), 'w' => $i[0], 'h' => $i[1], 'c' => ($i['channels'] ?? 3) == 1 ? '/DeviceGray' : '/DeviceRGB'];
        $this->c .= "q $w 0 0 $h $x $y cm /Im$n Do Q\n";
    }
    function text(string $s, float $x, float $y, float $size, string $color = '000000', bool $bold = false, bool $italic = false): void { $this->c .= 'BT ' . self::rgb($color) . ' rg /' . self::font($bold, $italic) . " $size Tf $x $y Td (" . self::esc($s) . ") Tj ET\n"; }
    function line(float $x1, float $y1, float $x2, float $y2, string $color = '000000', float $lw = 0.8): void { $this->c .= self::rgb($color) . " RG $lw w $x1 $y1 m $x2 $y2 l S\n"; }
    /** Découpe un texte en lignes qui tiennent dans $max points. */
    static function wrap(string $s, float $size, float $max, bool $bold = false): array {
        $out = []; $cur = ''; foreach (preg_split('/\s+/u', trim($s)) as $w) { $t = $cur === '' ? $w : $cur . ' ' . $w; if ($cur !== '' && self::width($t, $size, $bold) > $max) { $out[] = $cur; $cur = $w; } else $cur = $t; } if ($cur !== '') $out[] = $cur; return $out;
    }
    function output(float $w = 842, float $h = 595): string {
        $xo = ''; foreach ($this->imgs as $n => $_) $xo .= '/Im' . $n . ' ' . (8 + $n) . ' 0 R ';
        $o = [1 => '<< /Type /Catalog /Pages 2 0 R >>', 2 => '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
              3 => "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 $w $h] /Contents 4 0 R /Resources << /Font << /F1 5 0 R /F2 6 0 R /F3 7 0 R /F4 8 0 R >> " . ($xo ? "/XObject << $xo>> " : '') . ">> >>",
              4 => "<< /Length " . strlen($this->c) . " >>\nstream\n" . $this->c . "endstream",
              5 => '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>', 6 => '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>',
              7 => '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique /Encoding /WinAnsiEncoding >>', 8 => '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-BoldOblique /Encoding /WinAnsiEncoding >>'];
        foreach ($this->imgs as $n => $im) $o[8 + $n] = "<< /Type /XObject /Subtype /Image /Width {$im['w']} /Height {$im['h']} /ColorSpace {$im['c']} /BitsPerComponent 8 /Filter /DCTDecode /Length " . strlen($im['d']) . " >>\nstream\n" . $im['d'] . "\nendstream";
        $out = "%PDF-1.4\n"; $off = [];
        foreach ($o as $i => $b) { $off[$i] = strlen($out); $out .= "$i 0 obj\n$b\nendobj\n"; }
        $x = strlen($out); $out .= "xref\n0 " . (count($o) + 1) . "\n0000000000 65535 f \n";
        foreach ($off as $v) $out .= sprintf("%010d 00000 n \n", $v);
        return $out . "trailer\n<< /Size " . (count($o) + 1) . " /Root 1 0 R >>\nstartxref\n$x\n%%EOF\n";
    }
    /** Certificat de réussite aux couleurs Yas (bleu #003A84, jaune #FFCE00). @param array $d org, name, course, score, date, no, hours */
    static function certificate(array $d): string {
        $p = new self; $p->rect(0, 0, 842, 595, 'FFFFFF'); $p->rect(0, 555, 842, 40, '003A84'); $p->rect(0, 545, 842, 10, 'FFCE00'); $p->rect(0, 0, 842, 22, '003A84');
        $p->frame(28, 36, 786, 500, '003A84', 2.5); $p->frame(36, 44, 770, 484, 'FFCE00', 1);
        $p->center(mb_strtoupper($d['org']), 568, 14, 'FFFFFF', true);
        $p->center('CERTIFICAT DE RÉUSSITE', 470, 34, '003A84', true);
        $p->center('Il est certifié que', 420, 14, '555555');
        $p->center($d['name'], 368, 30, '000000', true, 842, 700);
        $p->center('a suivi avec succès la formation en ligne', 322, 14, '555555');
        $p->center('« ' . $d['course'] . ' »', 278, 22, '003A84', true, 842, 700);
        $p->center('avec un score de ' . $d['score'] . ' %' . (!empty($d['hours']) ? ' · durée : ' . $d['hours'] : ''), 236, 14, '000000');
        $p->center('Délivré le ' . $d['date'], 170, 13, '555555');
        $p->center('Référence : ' . $d['no'], 140, 11, '777777');
        $p->center('Document généré par CXO Excellence Hub — fait foi sous réserve de vérification dans l\'application.', 54, 9, '777777');
        return $p->output();
    }
}
