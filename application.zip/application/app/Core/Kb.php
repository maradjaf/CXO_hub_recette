<?php
namespace App\Core;
/** Base de connaissances et FAQ : visibilité, recherche, versions, rendu sécurisé du texte. */
class Kb {
    const ST = ['draft' => 'Brouillon', 'pending' => 'À relire', 'published' => 'Publié', 'rejected' => 'À corriger', 'archived' => 'Archivé'];
    const ST_COLOR = ['draft' => 'secondary', 'pending' => 'warning', 'published' => 'success', 'rejected' => 'danger', 'archived' => 'dark'];
    const KIND = ['article' => 'Article', 'faq' => 'Question / réponse'];

    /** Les articles « internes » (procédures du support) ne sont visibles que de ceux qui rédigent, gèrent ou traitent les tickets. */
    static function canInternal(): bool { return can('kb.write') || can('kb.manage') || can('at.handle'); }
    /** @return array{0:string,1:array} condition SQL (alias a) sur les articles publiés visibles de l'utilisateur */
    static function visible(string $a = 'a'): array { return ["$a.status='published'" . (self::canInternal() ? '' : " AND $a.internal=0"), []]; }
    static function months(): int { $m = (int)setting('kb_review_months', 12); return $m >= 1 && $m <= 60 ? $m : 12; }

    private static function like(string $t): string { return '%' . str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $t) . '%'; }
    const STOP = ['le', 'la', 'les', 'de', 'du', 'des', 'un', 'une', 'et', 'ou', 'en', 'au', 'aux', 'ce', 'ces', 'se', 'sa', 'son', 'ses', 'mon', 'ma', 'mes', 'ton', 'ta', 'tes', 'que', 'qui', 'quoi', 'comment', 'est', 'sont', 'pour', 'sur', 'dans', 'par', 'avec', 'sans', 'pas', 'plus', 'je', 'il', 'elle', 'nous', 'vous', 'ils', 'ne', 'me', 'te', 'si', 'peut', 'puis', 'fait', 'faire', 'quel', 'quelle', 'quels', 'quelles', 'yas'];
    private const ACC_FROM = 'àâäáãåçéèêëíìîïñóòôöõúùûüýÿœæÀÂÄÁÃÅÇÉÈÊËÍÌÎÏÑÓÒÔÖÕÚÙÛÜÝ';
    private const ACC_TO = 'aaaaaaceeeeiiiinooooouuuuyyoaAAAAAACEEEEIIIINOOOOOUUUUY';
    /** Minuscules sans accents, de même longueur que l'original (positions conservées : sert à surligner). */
    static function flat(string $s): string { $f = preg_split('//u', self::ACC_FROM, -1, PREG_SPLIT_NO_EMPTY); $t = preg_split('//u', self::ACC_TO, -1, PREG_SPLIT_NO_EMPTY); return mb_strtolower(strtr($s, array_combine($f, $t))); }
    /** Mots utiles de la requête, sans accents ni mots vides ; au besoin, tous les mots. */
    static function terms(string $q): array {
        $all = array_slice(array_values(array_unique(array_filter(preg_split('/[^a-z0-9]+/', self::flat(trim($q))), fn($t) => $t !== '' && (strlen($t) >= 2 || ctype_digit($t))))), 0, 8);
        $use = array_values(array_filter($all, fn($t) => !in_array($t, self::STOP, true))); return $use ?: $all;
    }
    /** Texte de recherche d'un article : titre, résumé, mots-clés et contenu, sans accents ni balises. */
    static function norm(array $a): string { return Fuzzy::fold(($a['title'] ?? '') . ' ' . ($a['summary'] ?? '') . ' ' . ($a['tags'] ?? '') . ' ' . Html::text((string)($a['body'] ?? ''))); }
    /** (Re)calcule le texte de recherche des articles nouveaux ou modifiés. */
    static function reindex(int $max = 800): void {
        foreach (DB::all("SELECT id, title, summary, tags, body FROM kb_articles WHERE search_norm IS NULL LIMIT $max") as $r) DB::exec('UPDATE kb_articles SET search_norm=? WHERE id=?', [self::norm($r) ?: '-', (int)$r['id']]);
    }
    /** Extrait du contenu autour du premier mot trouvé (texte brut). */
    static function snippet(string $body, array $terms, int $len = 220): string {
        $t = Html::text($body); if ($t === '') return ''; $f = self::flat($t); $pos = null;
        foreach ($terms as $w) { $p = mb_strpos($f, $w); if ($p !== false && ($pos === null || $p < $pos)) $pos = $p; }
        if ($pos === null) return mb_strlen($t) > $len ? mb_substr($t, 0, $len) . '…' : $t;
        $st = max(0, $pos - 70); if ($st > 0) { $sp = mb_strpos($t, ' ', $st); if ($sp !== false && $sp < $pos) $st = $sp + 1; }
        return ($st > 0 ? '…' : '') . mb_substr($t, $st, $len) . ($st + $len < mb_strlen($t) ? '…' : '');
    }
    /** Texte échappé avec les mots recherchés surlignés (sans tenir compte des accents ni de la casse). */
    static function mark(string $text, array $terms): string {
        if (!$terms || $text === '') return htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $f = self::flat($text); $n = mb_strlen($f); $on = array_fill(0, $n, false);
        foreach ($terms as $w) { $l = mb_strlen($w); for ($o = 0; ($p = mb_strpos($f, $w, $o)) !== false; $o = $p + max(1, $l)) for ($i = $p; $i < $p + $l; $i++) $on[$i] = true; }
        $out = ''; $buf = ''; $cur = false;
        for ($i = 0; $i < $n; $i++) { if ($on[$i] !== $cur) { $h = htmlspecialchars($buf, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); $out .= $cur ? "<mark>$h</mark>" : $h; $buf = ''; $cur = $on[$i]; } $buf .= mb_substr($text, $i, 1); }
        $h = htmlspecialchars($buf, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); return $out . ($cur ? "<mark>$h</mark>" : $h);
    }
    /** Recherche tolérante : sans accents ni mots vides, tous les mots d'abord, puis une partie des mots ; titre, mots-clés et référence comptent plus que le corps. @return array[] */
    static function search(string $q, int $limit = 30, ?int $category = null): array {
        $terms = self::terms($q); if (!$terms) return [];
        self::reindex(); [$vis] = self::visible(); $base = [$vis]; $bp = []; if ($category) { $base[] = 'a.category_id=?'; $bp[] = $category; }
        $cols = 'a.id, a.kind, a.title, a.summary, a.tags, a.useful, a.useless, a.views, a.internal, a.category_id, c.name category, a.search_norm';
        $run = function (string $glue) use ($terms, $base, $bp, $cols) {
            $cond = []; $p = $bp; foreach ($terms as $t) { $cond[] = "a.search_norm LIKE ? ESCAPE '!'"; $p[] = self::like($t); }
            return DB::all("SELECT $cols FROM kb_articles a LEFT JOIN kb_categories c ON c.id=a.category_id WHERE " . implode(' AND ', $base) . ' AND (' . implode($glue, $cond) . ') LIMIT 400', $p);
        };
        $ref = preg_match('/^[A-Za-z0-9]{2,8}-\d{1,4}$/', trim($q)) ? trim($q) : '';
        $rows = $run(' AND '); $exact = count($rows);
        if (count($terms) > 1 && $exact < 8) { $have = array_column($rows, 'id'); foreach ($run(' OR ') as $r) if (!in_array($r['id'], $have)) $rows[] = $r; }
        foreach ($rows as &$r) {
            $title = Fuzzy::fold($r['title']); $tags = Fuzzy::fold((string)$r['tags']); $sum = Fuzzy::fold((string)$r['summary']); $body = ' ' . $r['search_norm'] . ' '; $hit = 0; $s = 0;
            foreach ($terms as $t) { $h = false;
                if (str_contains($title, $t)) { $s += str_contains(' ' . $title . ' ', ' ' . $t . ' ') ? 14 : 10; $h = true; }
                if (str_contains($tags, $t)) { $s += str_contains(' ' . $tags . ' ', ' ' . $t . ' ') ? 8 : 5; $h = true; }
                if (str_contains($sum, $t)) { $s += 3; $h = true; }
                if (str_contains($body, $t)) { $s += 1; $h = true; }
                if ($h) $hit++; }
            $s += 6 * $hit; if ($hit === count($terms)) $s += 10; $s += min(5, (int)$r['useful'] - (int)$r['useless']) + min(3, (int)$r['views'] / 50);
            if ($ref !== '' && preg_match('/(^|,\s*)' . preg_quote($ref, '/') . '(\s*,|$)/i', (string)$r['tags'])) $s += 80;   // la référence exacte (MIXX-001) passe en tête
            $r['score'] = $s; $r['hits'] = $hit; unset($r['search_norm']);
        } unset($r);
        usort($rows, fn($x, $y) => $y['score'] <=> $x['score'] ?: strcmp($x['title'], $y['title']));
        if (count($rows) < 3) {   // repli : tolérance aux fautes de frappe
            $wc = $base; $p2 = $bp;
            $all = DB::all('SELECT a.id, a.kind, a.title, a.summary, a.tags, a.useful, a.useless, a.views, a.internal, a.category_id, c.name category FROM kb_articles a LEFT JOIN kb_categories c ON c.id=a.category_id WHERE ' . implode(' AND ', $wc) . ' LIMIT 3000', $p2);
            $have = array_column($rows, 'id');
            foreach (Fuzzy::rank(array_filter($all, fn($r) => !in_array($r['id'], $have)), $q, fn($r) => [$r['title'], (string)$r['tags'], (string)$r['summary']], $limit) as $r) { $r['score'] = 0; $r['fuzzy'] = true; $rows[] = $r; }
        }
        $rows = array_slice($rows, 0, $limit);
        if ($rows) { $ids = array_map(fn($r) => (int)$r['id'], $rows); $b = array_column(DB::all('SELECT id, body FROM kb_articles WHERE id IN (' . implode(',', $ids) . ')'), 'body', 'id'); foreach ($rows as &$r) $r['snippet'] = self::snippet((string)($b[$r['id']] ?? ''), $terms); unset($r); }
        return $rows;
    }
    /** Mémorise une version (historique complet, restauration possible). */
    static function snapshot(int $id, ?string $note = null): void {
        $a = DB::one('SELECT * FROM kb_articles WHERE id=?', [$id]); if (!$a) return;
        $v = (int)DB::val('SELECT COALESCE(MAX(version),0) FROM kb_versions WHERE article_id=?', [$id]) + 1;
        DB::insert('kb_versions', ['article_id' => $id, 'version' => $v, 'title' => $a['title'], 'summary' => $a['summary'], 'body' => $a['body'], 'user_id' => Auth::id(), 'user_name' => (string)(Auth::user()['name'] ?? ''), 'note' => $note ? mb_substr($note, 0, 200) : null, 'created_at' => now()]);
    }
    /** Texte simple enrichi → HTML sûr : ## titre, **gras**, `code`, listes « - » et « 1. », liens [texte](https://…). Tout le reste est échappé. */
    /** Valeur pour l'éditeur riche : un contenu ancien en syntaxe simple est converti en HTML. */
    static function forEditor(?string $text): string { return Html::isHtml($text) ? Html::clean($text) : self::render($text); }
    static function render(?string $text): string {
        if (Html::isHtml($text)) return '<div class="rich">' . Html::clean($text) . '</div>';
        $inline = function (string $s): string {
            $s = htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
            $s = preg_replace('/`([^`]+)`/', '<code>$1</code>', $s);
            $s = preg_replace('/\*\*([^*]+)\*\*/', '<strong>$1</strong>', $s);
            return preg_replace('#\[([^\]]+)\]\((https://[^\s)<>"\']+)\)#', '<a href="$2" target="_blank" rel="noopener noreferrer nofollow">$1</a>', $s);
        };
        $out = ''; $mode = null; $para = [];
        $close = function () use (&$out, &$mode, &$para, $inline) { if ($para) { $out .= '<p>' . implode('<br>', array_map($inline, $para)) . '</p>'; $para = []; } if ($mode) { $out .= "</$mode>"; $mode = null; } };
        foreach (preg_split('/\R/u', (string)$text) as $l) {
            $t = rtrim($l);
            if (trim($t) === '') { $close(); continue; }
            if (preg_match('/^(#{2,3})\s+(.+)$/u', $t, $m)) { $close(); $h = strlen($m[1]) === 2 ? 'h3' : 'h4'; $out .= "<$h>" . $inline($m[2]) . "</$h>"; continue; }
            if (preg_match('/^\s*[-*]\s+(.+)$/u', $t, $m)) { if ($mode !== 'ul') { $close(); $out .= '<ul>'; $mode = 'ul'; } $out .= '<li>' . $inline($m[1]) . '</li>'; continue; }
            if (preg_match('/^\s*\d+[.)]\s+(.+)$/u', $t, $m)) { if ($mode !== 'ol') { $close(); $out .= '<ol>'; $mode = 'ol'; } $out .= '<li>' . $inline($m[1]) . '</li>'; continue; }
            if ($mode) $close(); $para[] = $t;
        }
        $close(); return $out;
    }
}
