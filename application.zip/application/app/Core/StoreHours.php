<?php
namespace App\Core;

/** Horaires d'ouverture des stores : plages horaires paramétrables (store_slots) et grille jours × plages (store_hours). */
class StoreHours {
    const DAYS = [1 => 'Lundi', 2 => 'Mardi', 3 => 'Mercredi', 4 => 'Jeudi', 5 => 'Vendredi', 6 => 'Samedi', 7 => 'Dimanche'];
    const SHORT = [1 => 'lun.', 2 => 'mar.', 3 => 'mer.', 4 => 'jeu.', 5 => 'ven.', 6 => 'sam.', 7 => 'dim.'];

    static function valid(string $t): bool { return (bool)preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $t); }
    static function label(string $start, string $end): string { return str_replace(':', ' h ', $start) . ' - ' . str_replace(':', ' h ', $end); }
    static function slots(bool $onlyActive = false): array { return DB::all('SELECT * FROM store_slots' . ($onlyActive ? ' WHERE active=1' : '') . ' ORDER BY sort_order, start_time, end_time, id'); }
    /** Grille d'un store : [jour => [slot_id => true]]. */
    static function grid(int $storeId): array {
        $g = []; foreach (DB::all('SELECT dow, slot_id FROM store_hours WHERE store_id=?', [$storeId]) as $r) $g[(int)$r['dow']][(int)$r['slot_id']] = true; return $g;
    }
    /** Enregistre la grille ([jour => [slot_id,…]]) et régénère le texte d'horaires du store. */
    static function save(int $storeId, array $grid): string {
        $ids = array_column(self::slots(), 'id'); $own = !DB::pdo()->inTransaction(); if ($own) DB::pdo()->beginTransaction();
        DB::exec('DELETE FROM store_hours WHERE store_id=?', [$storeId]);
        foreach ($grid as $dow => $list) { $dow = (int)$dow; if ($dow < 1 || $dow > 7) continue; foreach (array_unique(array_map('intval', (array)$list)) as $sid) if (in_array($sid, array_map('intval', $ids), true)) DB::insert('store_hours', ['store_id' => $storeId, 'dow' => $dow, 'slot_id' => $sid]); }
        $txt = self::text($storeId); DB::update('stores', ['hours' => $txt !== '' ? $txt : null], 'id=?', [$storeId]); if ($own) DB::pdo()->commit(); return $txt;
    }
    /** Texte lisible regroupant les jours qui partagent les mêmes plages : « Lun.-ven. : 07 h 45 - 16 h 30 · Sam. : 08 h 30 - 12 h 30 ». */
    static function text(int $storeId): string {
        $sl = array_column(self::slots(), null, 'id'); $by = [];
        foreach (DB::all('SELECT dow, slot_id FROM store_hours WHERE store_id=?', [$storeId]) as $r) if (isset($sl[$r['slot_id']])) $by[(int)$r['dow']][] = $sl[$r['slot_id']];
        $sig = []; foreach ($by as $d => $list) { usort($list, fn($a, $b) => strcmp($a['start_time'], $b['start_time'])); $sig[$d] = implode(' / ', array_map(fn($x) => self::label($x['start_time'], $x['end_time']), $list)); }
        ksort($sig); $runs = []; foreach ($sig as $d => $s) { $l = count($runs) - 1; if ($l >= 0 && $runs[$l]['s'] === $s && end($runs[$l]['d']) === $d - 1) $runs[$l]['d'][] = $d; else $runs[] = ['s' => $s, 'd' => [$d]]; }
        $out = [];
        foreach ($runs as $r) { $d = $r['d']; $n = count($d);
            $name = $n >= 3 ? ucfirst(self::SHORT[$d[0]]) . '-' . substr(self::SHORT[$d[$n - 1]], 0, -1) . '.' : ($n === 2 ? ucfirst(self::SHORT[$d[0]]) . ', ' . self::SHORT[$d[1]] : ucfirst(self::SHORT[$d[0]]));
            $out[] = str_replace('-ven.', '-ven.', $name) . ' : ' . $r['s']; }
        return mb_substr(implode(' · ', $out), 0, 200);
    }
    /** Résumé « ouvert maintenant » pour l'affichage (null si aucune grille). */
    static function openNow(int $storeId, ?int $ts = null): ?bool {
        $g = self::grid($storeId); if (!$g) return null; $ts = $ts ?? time(); $dow = (int)date('N', $ts); $now = date('H:i', $ts); $sl = array_column(self::slots(), null, 'id');
        $prev = $dow === 1 ? 7 : $dow - 1;
        foreach (array_keys($g[$dow] ?? []) as $sid) { $s = $sl[$sid] ?? null; if (!$s) continue; if ($s['end_time'] > $s['start_time'] ? ($now >= $s['start_time'] && $now < $s['end_time']) : $now >= $s['start_time']) return true; }
        foreach (array_keys($g[$prev] ?? []) as $sid) { $s = $sl[$sid] ?? null; if ($s && $s['end_time'] <= $s['start_time'] && $now < $s['end_time']) return true; }
        return false;
    }
}
