<?php
namespace App\Core;
/** Demandes d'attestation : types à variables, établissement, signature électronique du signataire de la société, PDF avec code de vérification. */
final class Ar {
    const STATUS = ['requested' => 'Demandée', 'issued' => 'Délivrée', 'rejected' => 'Refusée', 'cancelled' => 'Annulée'];
    const COLOR = ['requested' => 'warning', 'issued' => 'success', 'rejected' => 'danger', 'cancelled' => 'secondary'];
    /** Contrat de référence du collaborateur : en cours, sinon le plus récent. */
    static function contract(int $emp): array {
        return DB::one("SELECT * FROM contracts WHERE employee_id=? AND status IN ('active','ended') ORDER BY (status='active') DESC, start_date DESC, id DESC LIMIT 1", [$emp]) ?: ['employee_id' => $emp, 'type' => '', 'start_date' => null, 'end_date' => null, 'employer_code' => null];
    }
    static function seniority(?string $hire): string {
        if (!$hire) return ''; $a = new \DateTime($hire); $df = $a->diff(new \DateTime('today')); $y = $df->y; $m = $df->m; $o = [];
        if ($y) $o[] = $y . ' an' . ($y > 1 ? 's' : ''); if ($m) $o[] = $m . ' mois'; if (!$o) $o[] = $df->d . ' jour(s)'; return implode(' et ', $o);
    }
    /** Signataire de la société : responsable RH, sinon premier responsable, sinon l'utilisateur connecté. */
    static function signatory(int $emp): array {
        $c = self::contract($emp); $co = DB::one('SELECT * FROM employers WHERE code=?', [(string)Ct::employerCode($c)]) ?: [];
        if (!empty($co['hr_name'])) return [(string)$co['hr_name'], (string)($co['hr_title'] ?: 'Responsable des ressources humaines')];
        if (!empty($co['head_name'])) return [(string)$co['head_name'], (string)($co['head_title'] ?: 'Direction')];
        return [(string)(Auth::user()['name'] ?? ''), 'Ressources humaines'];
    }
    static function values(int $emp, string $purpose = ''): array {
        $c = self::contract($emp); $v = Ct::values($c); [$sn, $st] = self::signatory($emp); $e = DB::one('SELECT hire_date FROM employees WHERE id=?', [$emp]) ?: [];
        return $v + ['motif' => trim($purpose) !== '' ? trim($purpose) : 'servir et valoir ce que de droit', 'anciennete' => self::seniority($e['hire_date'] ?? null), 'signataire_nom' => $sn, 'signataire_poste' => $st, 'date_demande' => date('d/m/Y')];
    }
    static function known(): array { return Ct::KNOWN + ['motif' => 'Motif indiqué par le collaborateur', 'anciennete' => 'Ancienneté', 'signataire_nom' => 'Signataire (nom)', 'signataire_poste' => 'Signataire (poste)', 'date_demande' => 'Date de la demande']; }
    static function hash(array $r): string { return hash('sha256', $r['id'] . '|' . $r['employee_id'] . '|' . $r['title'] . '|' . $r['body']); }
    static function pdf(array $r): string {
        $emp = (int)$r['employee_id']; $pd = new PdfDoc(595, 842, 54, 'Attestation n° ' . $r['id'], ''); $pd->brand(Ct::brandPaths(Ct::employerCode(self::contract($emp))));
        $pd->gap(8);
        foreach (preg_split('/\R/u', (string)$r['body']) as $l) {
            $l = rtrim($l); if (trim($l) === '') { $pd->gap(6); continue; }
            if (preg_match('/^#{1,3}\s+(.+)$/u', $l, $m)) { $pd->h2($m[1]); continue; }
            if (preg_match('/^\s*[-*]\s+(.+)$/u', $l, $m)) $l = '•  ' . $m[1];
            $pd->para(str_replace(['**', '`'], '', $l), 11);
        }
        if ($r['status'] === 'issued') {
            $pd->gap(18); $pd->para('Fait le ' . d(substr((string)$r['issued_at'], 0, 10)) . ', signé électroniquement par', 10); $pd->para((string)$r['signed_by'] . ($r['signed_title'] ? ' - ' . $r['signed_title'] : ''), 11);
            $pd->gap(8); $pd->para('Code de vérification : ' . $r['verify_code'] . '  ·  ' . Ct::abs('ar/verify/' . $r['verify_code']), 8, '6B7C93');
            $pd->para('Signature électronique simple : l\'attestation a été établie et validée par le service RH ; son authenticité se vérifie avec le code ci-dessus (empreinte ' . substr((string)$r['doc_hash'], 0, 16) . '…).', 8, '6B7C93');
        }
        return $pd->output();
    }
    static function pdfOut(array $r): never {
        $out = self::pdf($r); header('Content-Type: application/pdf'); header('Content-Disposition: attachment; filename="attestation-' . (int)$r['id'] . '.pdf"'); header('X-Content-Type-Options: nosniff'); header('Content-Length: ' . strlen($out)); echo $out; exit;
    }
}
