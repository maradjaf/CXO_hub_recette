<?php
namespace App\Core;
/** Exploitation : santé du système, suivi des tâches planifiées, sauvegardes, purge. */
class Sys {
    /** Tâches planifiées connues : script => [libellé, période attendue en heures, facultative]. */
    const JOBS = [
        'daily-alerts' => ['Alertes de fin de contrat', 24, false], 'aggregate-activity' => ['Agrégation et purge de l\'activité', 24, false],
        'at-alerts' => ['Alertes de l\'assistance technique', 1, false], 'maintenance-due' => ['Maintenance préventive', 24, false],
        'escalate-workflows' => ['Escalade des demandes', 24, false], 'elearn-reminders' => ['Relances e-learning', 24, false], 'rn-reminders' => ['Rappels des réunions et actions', 1, false], 'sat-surveys' => ['Enquêtes de satisfaction (formations et e-learning)', 24, false],
        'kb-review' => ['Revue de la base de connaissances', 168, false], 'ca-schedule' => ['Planification des contrôles N1', 24, false], 'ca-alerts' => ['Alertes des contrôles N1', 24, false], 'fr-alerts' => ['Alertes SLA des dossiers franchises', 1, false],
        'cx-schedule' => ['Planification Mystery Customer et parcours', 24, false], 'cx-alerts' => ['Alertes Mystery Customer et parcours', 24, false],
        'pr-review' => ['Revue périodique des processus', 24, false], 'att-close' => ['Clôture des statuts de présence', 1, false], 'pm-alerts' => ['Processus & Méthodes : revues de procédures, SLA MRP, actions en retard', 24, false], 'survey-import' => ['Enquêtes : lecture des dossiers surveillés (CSV/Excel)', 1, false], 'ged-alerts' => ['GED : rappels de revue et d\'expiration des documents', 24, false], 'skills-propose' => ['Propositions de niveau de compétence après les sessions', 24, false], 'readiness-recalc' => ['Recalcul de l\'Operational Readiness', 24, false], 'pr-ack' => ['Relances de lecture des processus', 24, false], 'pl-alerts' => ['Alertes de planification', 24, false], 'pj-weekly' => ['Cycle hebdomadaire des projets', 24, false], 'pj-alerts' => ['Alertes projet', 24, false],
        'hub-reminders' => ['Relances événements, modes opératoires, scripts et études de cas', 24, false], 'backup' => ['Sauvegarde de la base', 24, false], 'sys-purge' => ['Purge des données périmées', 168, false],
        'mail-fetch' => ['Relève IMAP', 1, true], 'mail-intake' => ['Import de courriels (dossier)', 1, true], 'mail-send' => ['Envoi SMTP', 1, true],
    ];
    const DIR = '/storage/backups';

    /** À appeler en tête d'un script CLI : enregistre début, fin, état et dernière sortie. */
    static function track(string $name): void {
        if (PHP_SAPI !== 'cli') return;
        $t0 = date('Y-m-d H:i:s'); ob_start();
        register_shutdown_function(function () use ($name, $t0) {
            $err = error_get_last(); $fatal = $err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true);
            $out = trim((string)ob_get_contents()); if ($fatal) $out = 'ERREUR : ' . $err['message'];
            try {
                $d = ['last_start' => $t0, 'last_end' => date('Y-m-d H:i:s'), 'last_status' => $fatal ? 'error' : 'ok', 'last_output' => mb_substr($out, 0, 500)]; if ($fatal) $d['last_error_at'] = $d['last_end'];
                $r = DB::one('SELECT id, runs FROM sys_jobs WHERE name=?', [$name]);
                if ($r) DB::update('sys_jobs', $d + ['runs' => (int)$r['runs'] + 1], 'id=?', [(int)$r['id']]); else DB::insert('sys_jobs', $d + ['name' => $name, 'runs' => 1]);
            } catch (\Throwable $e) { /* base indisponible : rien à consigner */ }
        });
    }
    /** @return array<int,array> état de chaque tâche : ok | late | error | never | unused */
    static function jobs(): array {
        $rows = []; foreach (DB::all('SELECT * FROM sys_jobs') as $r) $rows[$r['name']] = $r; $out = [];
        foreach (self::JOBS as $n => [$label, $h, $opt]) {
            $r = $rows[$n] ?? null; $st = 'ok';
            if (!$r) $st = $opt ? 'unused' : 'never';
            elseif ($r['last_status'] === 'error') $st = 'error';
            elseif ($r['last_end'] && strtotime($r['last_end']) < time() - max(2 * $h, 3) * 3600) $st = 'late';
            $out[] = ['name' => $n, 'label' => $label, 'hours' => $h, 'optional' => $opt, 'status' => $st, 'row' => $r];
        }
        return $out;
    }
    static function jobBad(): int { return count(array_filter(self::jobs(), fn($j) => in_array($j['status'], ['late', 'error', 'never'], true))); }

    // ---- Santé ----
    /** @return array<int,array{0:string,1:string,2:string,3:string}> [groupe, contrôle, état ok|warn|ko|info, détail] */
    static function health(): array {
        $h = []; $add = function ($g, $l, $s, $d) use (&$h) { $h[] = [$g, $l, $s, $d]; };
        $add('Serveur', 'PHP', version_compare(PHP_VERSION, '8.1.0', '>=') ? 'ok' : 'ko', PHP_VERSION . ' (8.1 minimum)');
        foreach (['pdo', 'mbstring', 'openssl', 'json', 'zlib'] as $x) $add('Serveur', "Extension $x", extension_loaded($x) ? 'ok' : ($x === 'zlib' ? 'warn' : 'ko'), extension_loaded($x) ? 'active' : ($x === 'zlib' ? 'absente : sauvegardes non compressées impossibles' : 'absente'));
        $free = @disk_free_space(ROOT); if ($free !== false) $add('Serveur', 'Espace disque libre', $free < 200 * 1048576 ? 'ko' : ($free < 1024 * 1048576 ? 'warn' : 'ok'), self::size((int)$free));
        $add('Serveur', 'Environnement', env('APP_DEBUG') ? 'warn' : 'ok', env('APP_DEBUG') ? 'APP_DEBUG actif : à désactiver en production' : 'débogage désactivé');
        $https = !empty($_SERVER['HTTPS']) || PHP_SAPI === 'cli'; if (PHP_SAPI !== 'cli') $add('Serveur', 'HTTPS', $https ? 'ok' : 'warn', $https ? 'connexion chiffrée' : 'connexion non chiffrée : activez HTTPS en production');
        $drv = DB::driver(); $ver = (string)DB::val($drv === 'sqlite' ? 'SELECT sqlite_version()' : 'SELECT VERSION()');
        $add('Base de données', 'Moteur', 'ok', ($drv === 'sqlite' ? 'SQLite ' : 'MySQL/MariaDB ') . $ver . ' · ' . self::dbSize());
        $defs = require ROOT . '/database/schema.php'; $have = array_map('strtolower', array_column($drv === 'sqlite' ? DB::all("SELECT name FROM sqlite_master WHERE type='table'") : DB::all('SELECT table_name name FROM information_schema.tables WHERE table_schema=DATABASE()'), 'name'));
        $miss = array_values(array_filter(array_keys($defs), fn($t) => !in_array($t, $have, true)));
        $add('Base de données', 'Schéma', $miss ? 'ko' : 'ok', $miss ? 'tables manquantes : ' . implode(', ', array_slice($miss, 0, 6)) . ' → lancez php bin/upgrade.php' : count($defs) . ' tables présentes');
        foreach (['storage/logs', 'storage/sessions', 'storage/uploads', 'storage/backups', 'storage/imports'] as $d) { $p = ROOT . "/$d"; $ok = is_dir($p) ? is_writable($p) : (is_dir(dirname($p)) && is_writable(dirname($p))); $add('Dossiers', $d, $ok ? 'ok' : 'ko', is_dir($p) ? ($ok ? 'inscriptible' : 'non inscriptible') : ($ok ? 'sera créé à la demande' : 'absent et non créable')); }
        $b = self::backups(); $age = $b ? (time() - $b[0]['time']) / 3600 : null;
        $add('Exploitation', 'Dernière sauvegarde', $age === null ? 'warn' : ($age > 48 ? 'warn' : 'ok'), $b ? date('d/m/Y H:i', $b[0]['time']) . ' · ' . $b[0]['sizeh'] : 'aucune sauvegarde');
        $bad = self::jobBad(); $add('Exploitation', 'Tâches planifiées', $bad ? 'warn' : 'ok', $bad ? "$bad tâche(s) en retard, en erreur ou jamais exécutée(s)" : 'toutes à jour');
        $lk = (int)DB::val('SELECT COUNT(*) FROM users WHERE locked_until>?', [now()]); $add('Sécurité', 'Comptes verrouillés', $lk ? 'warn' : 'ok', $lk ? "$lk compte(s) verrouillé(s)" : 'aucun');
        $pw = (int)DB::val("SELECT COUNT(*) FROM users WHERE must_change_password=1 AND status='active'"); $add('Sécurité', 'Mots de passe provisoires', $pw ? 'info' : 'ok', $pw ? "$pw compte(s) n'ont pas encore changé leur mot de passe" : 'aucun');
        $ad = (int)DB::val("SELECT COUNT(DISTINCT u.id) FROM users u JOIN user_roles ur ON ur.user_id=u.id JOIN roles r ON r.id=ur.role_id WHERE r.code='admin' AND u.status='active'"); $add('Sécurité', 'Administrateurs actifs', $ad < 1 ? 'ko' : ($ad > 3 ? 'warn' : 'ok'), "$ad compte(s)" . ($ad > 3 ? ' : limitez ce rôle' : ''));
        $ob = (int)DB::val("SELECT COUNT(*) FROM at_outbox WHERE status<>'sent'"); $add('Messagerie', 'E-mails sortants en attente ou en échec', $ob > 20 ? 'warn' : 'info', "$ob message(s)" . (env('SMTP_HOST') ? '' : ' · SMTP non configuré'));
        $e = self::logSize(); $add('Exploitation', 'Journal d\'erreurs', $e > 5 * 1048576 ? 'warn' : 'ok', self::size($e));
        $add('Assistant', 'Réponses de l\'assistant', 'info', Bot::llmEnabled() ? 'rédigées par un modèle Claude (' . setting('bot.model', 'claude-sonnet-5-5') . ')' : (setting('bot.llm', '0') === '1' ? 'mode IA demandé mais ANTHROPIC_API_KEY absente : recherche seule' : 'recherche dans les contenus (mode IA désactivé)'));
        if (setting('sys.maintenance', '0') === '1') $add('Exploitation', 'Mode maintenance', 'warn', 'ACTIF : seuls les administrateurs peuvent se connecter');
        return $h;
    }
    static function worst(array $h): string { $o = 'ok'; foreach ($h as $x) { if ($x[2] === 'ko') return 'ko'; if ($x[2] === 'warn') $o = 'warn'; } return $o; }
    static function size(int $b): string { foreach (['o', 'Ko', 'Mo', 'Go'] as $i => $u) { if ($b < 1024 || $i === 3) return ($i ? number_format($b, 1, ',', ' ') : $b) . ' ' . $u; $b /= 1024; } return ''; }
    static function dbSize(): string {
        if (DB::driver() === 'sqlite') { $p = env('DB_PATH', ROOT . '/storage/cxo.sqlite'); return is_file($p) ? self::size((int)filesize($p)) : ''; }
        return self::size((int)DB::val('SELECT COALESCE(SUM(data_length+index_length),0) FROM information_schema.tables WHERE table_schema=DATABASE()'));
    }

    // ---- Sauvegardes ----
    static function dir(): string { $d = ROOT . self::DIR; if (!is_dir($d)) @mkdir($d, 0770, true); return $d; }
    static function backups(): array {
        $o = []; foreach (glob(self::dir() . '/cxo-*.jsonl.gz') ?: [] as $f) $o[] = ['id' => basename($f, '.jsonl.gz'), 'file' => basename($f), 'time' => (int)filemtime($f), 'size' => (int)filesize($f), 'sizeh' => self::size((int)filesize($f))];
        usort($o, fn($a, $b) => $b['time'] <=> $a['time'] ?: strcmp($b['file'], $a['file'])); return $o;
    }
    static function validName(string $n): bool { return (bool)preg_match('/^cxo-\d{8}-\d{6}(-\d+)?$/', $n); }
    static function path(string $id): string { return self::dir() . '/' . $id . '.jsonl.gz'; }
    /** Sauvegarde logique (JSON par ligne, compressée) de toutes les tables. Les fichiers déposés (storage/uploads) ne sont pas inclus. */
    static function backup(): string {
        if (!function_exists('gzopen')) throw new \RuntimeException('Extension zlib requise.');
        $defs = require ROOT . '/database/schema.php'; $dir = self::dir(); $name = 'cxo-' . date('Ymd-His') . '.jsonl.gz'; for ($i = 1; is_file("$dir/$name"); $i++) $name = 'cxo-' . date('Ymd-His') . "-$i.jsonl.gz";
        $tmp = "$dir/.tmp-" . bin2hex(random_bytes(4)); $gz = gzopen($tmp, 'wb6'); if (!$gz) throw new \RuntimeException('Écriture impossible dans storage/backups.');
        gzwrite($gz, json_encode(['cxo_backup' => 1, 'created' => date('c'), 'driver' => DB::driver(), 'tables' => array_keys($defs)], JSON_UNESCAPED_UNICODE) . "\n");
        $n = 0;
        foreach (array_keys($defs) as $t) { $st = DB::pdo()->query("SELECT * FROM `$t`"); while ($r = $st->fetch(\PDO::FETCH_ASSOC)) { gzwrite($gz, json_encode(['t' => $t, 'r' => $r], JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE) . "\n"); $n++; } }
        gzwrite($gz, json_encode(['end' => $n]) . "\n"); gzclose($gz); rename($tmp, "$dir/$name"); @chmod("$dir/$name", 0640);
        return $name;
    }
    static function prune(int $keep): int {
        $n = 0; foreach (array_slice(self::backups(), max(1, $keep)) as $b) if (@unlink(self::dir() . '/' . $b['file'])) $n++; return $n;
    }
    /** Restaure une sauvegarde. $replace : vide d'abord toutes les tables. @return int lignes restaurées */
    static function restore(string $path, bool $replace): int {
        $gz = gzopen($path, 'rb'); if (!$gz) throw new \RuntimeException('Fichier illisible.');
        $head = json_decode((string)gzgets($gz), true); if (!is_array($head) || ($head['cxo_backup'] ?? 0) !== 1) throw new \RuntimeException('Ce fichier n\'est pas une sauvegarde CXO Hub.');
        $defs = require ROOT . '/database/schema.php'; $drv = DB::driver(); $pdo = DB::pdo();
        $have = (bool)DB::val($drv === 'sqlite' ? "SELECT name FROM sqlite_master WHERE type='table' AND name='users'" : "SELECT table_name FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='users'");
        if (!$have) Schema::migrate();
        elseif (!$replace) throw new \RuntimeException('La base contient déjà des données : ajoutez --replace pour les remplacer.');
        $pdo->exec($drv === 'sqlite' ? 'PRAGMA foreign_keys=OFF' : 'SET FOREIGN_KEY_CHECKS=0');
        $n = 0; $ended = false;
        try {
            foreach (['audit_logs_no_delete', 'audit_logs_no_update'] as $tr) $pdo->exec("DROP TRIGGER IF EXISTS $tr");
            $pdo->beginTransaction();
            foreach (array_keys($defs) as $t) $pdo->exec("DELETE FROM `$t`");
            $cache = [];
            while (($line = gzgets($gz)) !== false) {
                $j = json_decode($line, true); if (!is_array($j)) continue; if (isset($j['end'])) { $ended = true; if ((int)$j['end'] !== $n) throw new \RuntimeException('Nombre de lignes incohérent : fichier altéré.'); continue; }
                $t = $j['t'] ?? ''; if (!isset($defs[$t]) || !is_array($j['r'] ?? null)) continue;
                $cols = array_values(array_filter(array_keys($j['r']), fn($c) => isset($defs[$t][$c]))); $k = $t . '|' . implode(',', $cols);
                if (!isset($cache[$k])) $cache[$k] = $pdo->prepare("INSERT INTO `$t` (" . implode(',', array_map(fn($c) => "`$c`", $cols)) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')');
                $cache[$k]->execute(array_map(fn($c) => $j['r'][$c], $cols)); $n++;
            }
            if (!$ended) throw new \RuntimeException('Sauvegarde incomplète (fin de fichier absente).');
            $pdo->commit();
        } catch (\Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); throw $e; }
        finally { foreach (Schema::appendOnlyTriggers($drv, 'audit_logs') as $s) $pdo->exec($s); $pdo->exec($drv === 'sqlite' ? 'PRAGMA foreign_keys=ON' : 'SET FOREIGN_KEY_CHECKS=1'); gzclose($gz); }
        return $n;
    }

    // ---- Conservation ----
    /** @return array<string,array{label:string,count:int,sql:string,params:array}> */
    static function purgeable(): array {
        $nd = max(7, (int)setting('sys.purge_notif_days', 90)); $ld = max(7, (int)setting('sys.purge_login_days', 90)); $cut = fn($d) => date('Y-m-d H:i:s', strtotime("-$d days"));
        $q = [
            'notifications' => ['Notifications lues de plus de ' . $nd . ' jours', 'FROM notifications WHERE read_at IS NOT NULL AND created_at<?', [$cut($nd)]],
            'login' => ['Tentatives de connexion de plus de ' . $ld . ' jours', 'FROM login_attempts WHERE created_at<?', [$cut($ld)]],
            'outbox' => ['E-mails sortants envoyés de plus de ' . $nd . ' jours', "FROM at_outbox WHERE status='sent' AND sent_at<?", [$cut($nd)]],
        ];
        $bd = max(7, (int)setting('bot.retention_days', 180));
        $q['botmsg'] = ['Messages de l\'assistant de plus de ' . $bd . ' jours', 'FROM bot_messages WHERE created_at<?', [$cut($bd)]];
        $q['botconv'] = ['Conversations vides de l\'assistant', 'FROM bot_conversations WHERE updated_at<? AND id NOT IN (SELECT conversation_id FROM bot_messages)', [$cut($bd)]];
        $o = []; foreach ($q as $k => [$l, $from, $p]) $o[$k] = ['label' => $l, 'count' => (int)DB::val("SELECT COUNT(*) $from", $p), 'sql' => "DELETE $from", 'params' => $p];
        return $o;
    }
    static function purge(): array { Bot::purgeImages(date('Y-m-d H:i:s', strtotime('-' . max(7, (int)setting('bot.retention_days', 180)) . ' days'))); $r = []; foreach (self::purgeable() as $k => $x) $r[$k] = DB::exec($x['sql'], $x['params']); return $r; }

    // ---- Journal d'erreurs, sessions ----
    static function logFile(): string { return ROOT . '/storage/logs/app.log'; }
    static function logSize(): int { return is_file(self::logFile()) ? (int)filesize(self::logFile()) : 0; }
    static function logTail(int $n = 100): array { $f = self::logFile(); if (!is_file($f)) return []; $sz = filesize($f); $fh = fopen($f, 'rb'); fseek($fh, max(0, $sz - 200000)); $t = (string)stream_get_contents($fh); fclose($fh); $l = array_values(array_filter(explode("\n", $t), 'strlen')); return array_slice($l, -$n); }
    /** Ferme toutes les sessions sauf la courante. */
    static function killSessions(): int {
        $n = 0; $cur = session_id(); $dir = session_save_path() ?: sys_get_temp_dir(); if (str_contains($dir, ';')) $dir = substr($dir, strrpos($dir, ';') + 1);
        foreach (glob(rtrim($dir, '/') . '/sess_*') ?: [] as $f) { if ($cur !== '' && basename($f) === 'sess_' . $cur) continue; if (@unlink($f)) $n++; }
        return $n;
    }
}
