<?php
namespace App\Core;
/**
 * Envoi de SMS par passerelle HTTP. Les messages passent par une file (sms_outbox) vidée par bin/sms-send.php.
 * Activé uniquement si SMS_GATEWAY_URL est renseigné. Variables : SMS_GATEWAY_URL, SMS_GATEWAY_TOKEN (jeton Bearer, facultatif),
 * SMS_GATEWAY_FORMAT (json|form, défaut json), SMS_SENDER (expéditeur), SMS_FIELD_TO / SMS_FIELD_TEXT / SMS_FIELD_FROM (noms des champs, défaut to/text/from).
 * À adapter au prestataire retenu (passerelle de l'opérateur, agrégateur SMS…) : la requête est une simple POST.
 */
class Sms {
    static function enabled(): bool { return (string)env('SMS_GATEWAY_URL', '') !== ''; }
    /** Numéro au format international sans espace ; null si invalide (8 à 15 chiffres). */
    static function normalize(?string $p): ?string {
        $p = trim((string)$p); if ($p === '') return null; $plus = str_starts_with($p, '+') || str_starts_with($p, '00');
        $d = preg_replace('/\D+/', '', $p); if (str_starts_with($p, '00')) $d = substr($d, 2);
        if (strlen($d) < 8 || strlen($d) > 15) return null; return ($plus ? '+' : '') . $d;
    }
    static function queue(string $to, string $body, ?int $incidentId = null): bool {
        $to = self::normalize($to); if (!self::enabled() || !$to) return false;
        DB::insert('sms_outbox', ['to_phone' => $to, 'body' => mb_substr(trim($body), 0, 480), 'status' => 'pending', 'tries' => 0, 'incident_id' => $incidentId, 'created_at' => now()]);
        return true;
    }
    static function flush(int $limit = 50): array {
        $ok = 0; $ko = 0;
        foreach (DB::all("SELECT * FROM sms_outbox WHERE status='pending' AND tries<5 ORDER BY id LIMIT " . (int)$limit) as $m) {
            try { self::deliver($m['to_phone'], $m['body']); DB::update('sms_outbox', ['status' => 'sent', 'tries' => (int)$m['tries'] + 1, 'sent_at' => now(), 'last_error' => null], 'id=?', [(int)$m['id']]); $ok++; }
            catch (\Throwable $e) { $n = (int)$m['tries'] + 1; DB::update('sms_outbox', ['tries' => $n, 'status' => $n >= 5 ? 'failed' : 'pending', 'last_error' => mb_substr($e->getMessage(), 0, 300)], 'id=?', [(int)$m['id']]); $ko++; }
        }
        return [$ok, $ko];
    }
    static function deliver(string $to, string $text): void {
        $url = (string)env('SMS_GATEWAY_URL'); if ($url === '') throw new \RuntimeException('Passerelle SMS non configurée.');
        $f = [(string)env('SMS_FIELD_TO', 'to') => $to, (string)env('SMS_FIELD_TEXT', 'text') => $text];
        if ((string)env('SMS_SENDER', '') !== '') $f[(string)env('SMS_FIELD_FROM', 'from')] = (string)env('SMS_SENDER');
        $json = strtolower((string)env('SMS_GATEWAY_FORMAT', 'json')) !== 'form';
        $h = ['Content-Type: ' . ($json ? 'application/json' : 'application/x-www-form-urlencoded')];
        if ((string)env('SMS_GATEWAY_TOKEN', '') !== '') $h[] = 'Authorization: Bearer ' . env('SMS_GATEWAY_TOKEN');
        $ctx = stream_context_create(['http' => ['method' => 'POST', 'header' => implode("\r\n", $h), 'content' => $json ? json_encode($f, JSON_UNESCAPED_UNICODE) : http_build_query($f), 'timeout' => 15, 'ignore_errors' => true]]);
        $r = @file_get_contents($url, false, $ctx); $code = 0;
        foreach ($http_response_header ?? [] as $l) if (preg_match('#^HTTP/\S+\s+(\d{3})#', $l, $m)) $code = (int)$m[1];
        if ($r === false || $code < 200 || $code >= 300) throw new \RuntimeException('Passerelle SMS : réponse HTTP ' . ($code ?: 'aucune'));
    }
}
