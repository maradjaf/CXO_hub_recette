<?php
namespace App\Core;
/**
 * Lot 64 : GED (M41) — gestion électronique de documents. Dossiers hiérarchiques avec accès (tous / par rôle / privé), documents versionnés,
 * confidentialité, validation, verrou d'édition, revue/expiration, journal des consultations. Fichiers stockés hors du dossier public (storage/uploads/ged).
 */
class Ged {
    const STATUS = ['draft' => 'Brouillon', 'review' => 'À valider', 'validated' => 'Validé', 'archived' => 'Archivé'];
    const COLOR = ['draft' => 'secondary', 'review' => 'warning', 'validated' => 'success', 'archived' => 'dark'];
    const CONF = ['public' => 'Tout le personnel', 'internal' => 'Interne (selon le dossier)', 'restricted' => 'Restreint (propriétaire et gestionnaires)'];
    const CONF_COLOR = ['public' => 'info', 'internal' => 'secondary', 'restricted' => 'danger'];
    const ACCESS = ['all' => 'Tous les utilisateurs', 'roles' => 'Rôles choisis', 'private' => 'Privé (propriétaire et gestionnaires)'];

    static function roleIds(): array { static $c = []; $u = (int)Auth::id(); return $c[$u] ??= array_map(fn($r) => (int)$r['role_id'], DB::all('SELECT role_id FROM user_roles WHERE user_id=?', [$u])); }
    static function manager(): bool { return can('ged.manage'); }
    static function folders(): array { return DB::all('SELECT * FROM ged_folders WHERE active=1 ORDER BY sort_order, name'); }
    /** Niveau d'accès au dossier : null (aucun), 'read' ou 'write'. Un dossier n'est accessible que si ses parents le sont. */
    static function level(int $folderId, ?array $by = null): ?string {
        if (!can('ged.view')) return null;
        $by ??= array_column(self::folders(), null, 'id'); $mgr = self::manager(); $write = can('ged.write') || $mgr; $lv = $write ? 'write' : 'read'; $seen = 0;
        for ($id = $folderId; $id && isset($by[$id]) && $seen++ < 20; $id = (int)$by[$id]['parent_id']) {
            $f = $by[$id]; if ($mgr) continue;
            if ($f['access'] === 'private') { if ((int)$f['owner_id'] !== (int)Auth::id()) return null; }
            elseif ($f['access'] === 'roles') {
                $rows = DB::all('SELECT role_id, level FROM ged_folder_roles WHERE folder_id=?', [$id]); $mine = array_filter($rows, fn($r) => in_array((int)$r['role_id'], self::roleIds(), true));
                if (!$mine && (int)$f['owner_id'] !== (int)Auth::id()) return null;
                if (!in_array('write', array_column($mine, 'level'), true) && (int)$f['owner_id'] !== (int)Auth::id()) $lv = 'read';
            }
        }
        return $seen ? $lv : null;
    }
    static function readableIds(): array { $by = array_column(self::folders(), null, 'id'); $o = []; foreach ($by as $id => $f) if (self::level((int)$id, $by)) $o[] = (int)$id; return $o; }
    static function canRead(array $d): bool {
        if ($d['deleted_at']) return self::manager(); if (!self::level((int)$d['folder_id'])) return false;
        if ($d['confidentiality'] === 'restricted') return self::manager() || (int)$d['owner_id'] === (int)Auth::id();
        return true;
    }
    static function canWrite(array $d): bool {
        if ($d['deleted_at'] || $d['status'] === 'archived') return false; if (!self::canRead($d)) return false;
        if ($d['locked_by'] && (int)$d['locked_by'] !== (int)Auth::id() && !self::manager()) return false;
        return self::manager() || ((int)$d['owner_id'] === (int)Auth::id() && self::level((int)$d['folder_id']) === 'write') || (self::level((int)$d['folder_id']) === 'write' && $d['status'] !== 'validated');
    }
    static function log(int $docId, string $action, string $detail = ''): void { DB::insert('ged_log', ['doc_id' => $docId, 'user_id' => Auth::id(), 'action' => $action, 'detail' => mb_substr($detail, 0, 250), 'created_at' => now()]); }
    static function ref(): string { do { $r = 'GED-' . date('y') . '-' . strtoupper(bin2hex(random_bytes(3))); } while (DB::val('SELECT 1 FROM ged_docs WHERE ref=?', [$r])); return $r; }
    static function path(int $folderId): array { $by = array_column(self::folders(), null, 'id'); $o = []; for ($id = $folderId, $n = 0; $id && isset($by[$id]) && $n++ < 20; $id = (int)$by[$id]['parent_id']) array_unshift($o, $by[$id]); return $o; }
    /** Descendants d'un dossier (lui compris). */
    static function subtree(int $id): array { $by = self::folders(); $o = [$id]; $grew = true; while ($grew) { $grew = false; foreach ($by as $f) if (!in_array((int)$f['id'], $o, true) && in_array((int)$f['parent_id'], $o, true)) { $o[] = (int)$f['id']; $grew = true; } } return $o; }
    /** Liste à plat avec profondeur, pour l'arbre et les listes déroulantes. */
    static function tree(?array $only = null): array {
        $all = self::folders(); $kids = []; foreach ($all as $f) $kids[(int)$f['parent_id']][] = $f; $o = [];
        $walk = function (int $p, int $d) use (&$walk, &$o, $kids, $only) { foreach ($kids[$p] ?? [] as $f) { if ($only === null || in_array((int)$f['id'], $only, true)) { $f['depth'] = $d; $o[] = $f; } $walk((int)$f['id'], $d + 1); } };
        $walk(0, 0); return $o;
    }
    /** Enregistre un fichier comme nouvelle version ; retourne [version, erreur]. */
    static function addVersion(int $docId, array $f, string $comment = ''): array {
        $sha = hash('sha256', $f['bytes']); $d = DB::one('SELECT * FROM ged_docs WHERE id=?', [$docId]); if (!$d) return [0, 'Document introuvable.'];
        if (DB::val('SELECT 1 FROM ged_versions WHERE doc_id=? AND sha256=? AND version=?', [$docId, $sha, (int)$d['current_version']])) return [0, 'Ce fichier est identique à la version actuelle.'];
        $s = Files::put('ged', $f['bytes'], $f['ext']); if (!$s) return [0, 'Enregistrement impossible.'];
        $v = (int)DB::val('SELECT COALESCE(MAX(version),0) FROM ged_versions WHERE doc_id=?', [$docId]) + 1;
        DB::insert('ged_versions', ['doc_id' => $docId, 'version' => $v, 'original_name' => $f['name'], 'stored_name' => $s, 'mime' => $f['mime'], 'size' => strlen($f['bytes']), 'sha256' => $sha, 'comment' => mb_substr($comment, 0, 300), 'user_id' => Auth::id(), 'created_at' => now()]);
        DB::update('ged_docs', ['current_version' => $v, 'updated_at' => now()] + ($d['status'] === 'validated' ? ['status' => 'draft', 'validated_by' => null, 'validated_at' => null] : []), 'id=?', [$docId]);
        return [$v, null];
    }
    /** Documents dont la revue ou l'expiration approche (ou est dépassée). */
    static function due(int $days = 30): array {
        $lim = date('Y-m-d', strtotime("+$days days"));
        return DB::all("SELECT d.*, f.name folder_name FROM ged_docs d JOIN ged_folders f ON f.id=d.folder_id WHERE d.deleted_at IS NULL AND d.status<>'archived' AND ((d.review_date IS NOT NULL AND d.review_date<=?) OR (d.expires_at IS NOT NULL AND d.expires_at<=?)) ORDER BY COALESCE(d.expires_at, d.review_date)", [$lim, $lim]);
    }
    /** Notifie les propriétaires (une fois par échéance et par jour) ; retourne le nombre de notifications. */
    static function alerts(int $days = 30): int {
        $n = 0; $today = date('Y-m-d');
        foreach (self::due($days) as $d) {
            if (!$d['owner_id'] || DB::val('SELECT 1 FROM ged_log WHERE doc_id=? AND action=? AND DATE(created_at)=?', [(int)$d['id'], 'alerte', $today])) continue;
            $late = ($d['expires_at'] && $d['expires_at'] < $today) || ($d['review_date'] && $d['review_date'] < $today);
            Notifier::send((int)$d['owner_id'], ($late ? 'Document à réviser en retard : ' : 'Document à réviser : ') . $d['title'], 'Échéance de revue ou d\'expiration du document ' . $d['ref'] . '.', 'ged/doc/' . $d['id']);
            DB::insert('ged_log', ['doc_id' => (int)$d['id'], 'user_id' => null, 'action' => 'alerte', 'detail' => $late ? 'retard' : 'échéance proche', 'created_at' => now()]); $n++;
        }
        return $n;
    }
}
