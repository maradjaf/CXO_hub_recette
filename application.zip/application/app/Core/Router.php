<?php
namespace App\Core;
class Router {
    private array $routes = [];
    function add(string $m, string $path, string $handler, ?string $perm = null): void {
        $re = '#^' . preg_replace('#\{(\w+)\}#', '(?P<$1>[^/]+)', $path) . '$#';
        $this->routes[] = compact('m', 'path', 'handler', 'perm', 're');
    }
    function get(string $p, string $h, ?string $perm = null): void { $this->add('GET', $p, $h, $perm); }
    function post(string $p, string $h, ?string $perm = null): void { $this->add('POST', $p, $h, $perm); }
    /** @return array{0:?array,1:array,2:int} route, params, status */
    function match(string $method, string $path): array {
        $found = false;
        foreach ($this->routes as $r) {
            if (preg_match($r['re'], $path, $mm)) {
                if ($r['m'] === $method) return [$r, array_filter($mm, 'is_string', ARRAY_FILTER_USE_KEY), 200];
                $found = true;
            }
        }
        return [null, [], $found ? 405 : 404];
    }
}
