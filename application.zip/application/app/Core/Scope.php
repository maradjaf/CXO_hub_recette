<?php
namespace App\Core;
/** Périmètre de données : les utilisateurs sans le droit « scope.all » ne voient que leur ligne hiérarchique (eux-mêmes et tous leurs subordonnés). */
class Scope {
    private static $ids = false;
    /** @return int[]|null null = tous les collaborateurs */
    static function ids(): ?array {
        if (self::$ids !== false) return self::$ids;
        if (Auth::can('scope.all')) return self::$ids = null;
        if ($pc = (string)(Auth::user()['employer_code'] ?? '')) return self::$ids = array_map('intval', array_column(DB::all('SELECT id FROM employees WHERE employer=?', [$pc]), 'id'));   // responsable prestataire : tout son personnel
        $me = (int)(Auth::user()['employee_id'] ?? 0);
        if (!$me) return self::$ids = [];
        $all = [$me]; $front = [$me];
        while ($front) {
            $in = implode(',', array_fill(0, count($front), '?'));
            $front = array_values(array_diff(array_map('intval', array_column(DB::all("SELECT id FROM employees WHERE manager_id IN ($in)", $front), 'id')), $all));
            $all = array_merge($all, $front);
        }
        // Les collaborateurs affectés dans une autre société ne sont visibles que de leur société (prestataire) et des profils « scope.all ».
        $in = implode(',', array_fill(0, count($all), '?'));
        $hidden = array_map('intval', array_column(DB::all("SELECT id FROM employees WHERE placement='other' AND id IN ($in) AND id<>?", array_merge($all, [$me])), 'id'));
        return self::$ids = $hidden ? array_values(array_diff($all, $hidden)) : $all;
    }
    /** Fragment SQL restreignant une colonne d'identifiant collaborateur ; retourne [sql, paramètres]. */
    static function sql(string $col): array {
        $ids = self::ids(); if ($ids === null) return ['1=1', []];
        if (!$ids) return ['1=0', []];
        return ["$col IN (" . implode(',', array_fill(0, count($ids), '?')) . ')', $ids];
    }
    /** Fragment SQL masquant les collaborateurs affectés dans une autre société (hors profils « scope.all » et responsables prestataires). */
    static function hideOther(string $col = 'e.placement'): string { return (Auth::can('scope.all') || !empty(Auth::user()['employer_code'])) ? '1=1' : "($col IS NULL OR $col<>'other')"; }
    /** Vrai si cette fiche collaborateur doit rester invisible pour l'utilisateur connecté. */
    static function hidden(array $e): bool { return ($e['placement'] ?? '') === 'other' && self::hideOther() !== '1=1' && (int)$e['id'] !== (int)(Auth::user()['employee_id'] ?? 0); }
    static function allows(int $employeeId): bool { $ids = self::ids(); return $ids === null || in_array($employeeId, $ids, true); }
    static function employees(): array {
        [$w, $p] = self::sql('id');
        return DB::all("SELECT id, first_name, last_name, matricule, qa_ref_type, qa_ref FROM employees WHERE status<>'left' AND $w ORDER BY last_name, first_name", $p);
    }
    /** Libellé de liste déroulante : recherchable par nom, prénoms, matricule ou référence qualité. */
    static function label(array $e): string { return trim(($e['last_name'] ?? '') . ' ' . ($e['first_name'] ?? '')) . ' · ' . ($e['matricule'] ?? '') . (!empty($e['qa_ref']) ? ' · réf. ' . $e['qa_ref'] : ' · sans référence qualité'); }
}
