<?php
namespace App\Core;

/** Générateur PDF multipage (A4, Helvetica) pour les rapports tabulaires : titres, paragraphes, tableaux avec saut de page, pied de page numéroté. */
final class PdfDoc {
    private array $pages = []; private string $c = ''; private float $y = 0; private int $n = 0; private array $imgs = []; private ?array $brand = null; private float $bottom = 0;
    function __construct(private float $w = 842, private float $h = 595, private float $m = 36, private string $foot = '', private string $head = '') { $this->page(); }
    private function page(): void {
        if ($this->n) $this->pages[] = $this->c; $this->n++; $this->c = ''; $this->y = $this->h - $this->m;
        if ($this->brand) $this->drawBrandHead();
        elseif ($this->head !== '') { $this->t($this->head, $this->m, $this->h - 22, 8, '6B7C93'); $this->y = $this->h - 40; }
    }
    /** Image JPEG : retourne [numéro, largeur px, hauteur px] ou null. */
    private function img(?string $file): ?array {
        if (!$file || !is_file($file) || !($i = @getimagesize($file)) || $i[2] !== IMAGETYPE_JPEG) return null;
        foreach ($this->imgs as $n => $im) if ($im['f'] === $file) return [$n, $i[0], $i[1]];
        $n = count($this->imgs) + 1; $this->imgs[$n] = ['f' => $file, 'd' => (string)file_get_contents($file), 'w' => $i[0], 'h' => $i[1], 'c' => ($i['channels'] ?? 3) == 1 ? '/DeviceGray' : '/DeviceRGB']; return [$n, $i[0], $i[1]];
    }
    private function put(array $im, float $x, float $y, float $maxW, float $maxH): array {
        $r = min($maxW / $im[1], $maxH / $im[2]); $w = $im[1] * $r; $h = $im[2] * $r; $this->c .= 'q ' . round($w, 2) . ' 0 0 ' . round($h, 2) . ' ' . round($x, 2) . ' ' . round($y, 2) . ' cm /Im' . $im[0] . " Do Q\n"; return [$w, $h];
    }
    /** En-tête et pied de page de société : $b = logo, header_img, header_text, footer_img, footer_text (chemins de fichiers et textes). À appeler juste après la construction. */
    function brand(array $b): void {
        $this->brand = $b; $fh = 0; $fi = $this->img($b['footer_img'] ?? null);
        if ($fi) $fh += min(46, ($this->w - 2 * $this->m) * $fi[2] / $fi[1]) + 4;
        $fl = array_values(array_filter(preg_split('/\R/u', (string)($b['footer_text'] ?? '')), fn($x) => trim($x) !== '')); if (!$fi) $fh += count($fl) * 10 + 2;
        $this->bottom = $fh;
        $this->c = ''; $this->y = $this->h - $this->m; $this->drawBrandHead();
    }
    private function drawBrandHead(): void {
        $b = $this->brand; $top = $this->h - $this->m + 6; $avail = $this->w - 2 * $this->m;
        if ($hi = $this->img($b['header_img'] ?? null)) { [$w, $h] = $this->put($hi, $this->m, $top - min(80, $avail * $hi[2] / $hi[1]), $avail, 80); $this->y = $top - $h - 14; return; }
        $lg = $this->img($b['logo'] ?? null); $x = $this->m; $hh = 0;
        if ($lg) { [$w, $hh] = $this->put($lg, $this->m, $top - 50, 140, 50); $x = $this->m + $w + 12; $hh = max($hh, 0); }
        $lines = array_values(array_filter(preg_split('/\R/u', (string)($b['header_text'] ?? '')), fn($l) => trim($l) !== ''));
        if (!$lines && !empty($b['name']) && $lg) { $lines = [$b['name']]; if (!empty($b['slogan'])) $lines[] = $b['slogan']; }
        $ty = $top - 12; foreach ($lines as $k => $l) { $this->t($this->fit($l, $this->w - $this->m - $x, $k ? 8 : 10, !$k), $x, $ty, $k ? 8 : 10, $k ? '6B7C93' : '003A84', !$k); $ty -= $k ? 10 : 13; }
        $used = max($hh, $top - $ty - 2); if ($used > 0) { $this->c .= $this->rgb('D5DCE6') . ' RG 0.6 w ' . $this->m . ' ' . round($top - $used - 4, 2) . ' m ' . ($this->w - $this->m) . ' ' . round($top - $used - 4, 2) . " l S\n"; $this->y = $top - $used - 16; }
        else $this->y = $this->h - $this->m;
    }
    private function drawBrandFoot(string &$body): void {
        $b = $this->brand; if (!$b) return; $avail = $this->w - 2 * $this->m;
        if ($fi = $this->img($b['footer_img'] ?? null)) { $keep = $this->c; $this->c = ''; $this->put($fi, $this->m, 32, $avail, 46); $body .= $this->c; $this->c = $keep; return; }
        $lines = array_values(array_filter(preg_split('/\R/u', (string)($b['footer_text'] ?? '')), fn($x) => trim($x) !== '')); $y = 32 + count($lines) * 10;
        foreach ($lines as $l) { $y -= 10; $body .= 'BT ' . $this->rgb('6B7C93') . ' rg /F1 7.5 Tf ' . $this->m . ' ' . ($y + 4) . ' Td (' . $this->esc($this->fit($l, $avail, 7.5)) . ") Tj ET\n"; }
    }
    private function esc(string $s): string { return str_replace(['\\', '(', ')', "\r", "\n"], ['\\\\', '\\(', '\\)', '', ' '], Pdf::enc($s)); }
    private function rgb(string $x): string { return sprintf('%.3f %.3f %.3f', hexdec(substr($x, 0, 2)) / 255, hexdec(substr($x, 2, 2)) / 255, hexdec(substr($x, 4, 2)) / 255); }
    private function t(string $s, float $x, float $y, float $size, string $col = '1F2D3D', bool $b = false): void { $this->c .= 'BT ' . $this->rgb($col) . ' rg /' . ($b ? 'F2' : 'F1') . " $size Tf " . round($x, 2) . ' ' . round($y, 2) . ' Td (' . $this->esc($s) . ") Tj ET\n"; }
    private function fit(string $s, float $max, float $size, bool $b = false): string { if (Pdf::width($s, $size, $b) <= $max) return $s; while ($s !== '' && Pdf::width($s . '…', $size, $b) > $max) $s = mb_substr($s, 0, -1); return $s . '…'; }
    private function need(float $h): void { if ($this->y - $h < $this->m + 16 + $this->bottom) $this->page(); }
    function title(string $s, float $size = 18): void { $this->need($size + 10); $this->y -= $size; $this->t($s, $this->m, $this->y, $size, '003A84', true); $this->y -= 6; }
    function h2(string $s): void { $this->need(30); $this->y -= 20; $this->t($s, $this->m, $this->y, 12, '003A84', true); $this->y -= 4; }
    function para(string $s, float $size = 9, string $col = '1F2D3D'): void {
        foreach (Pdf::wrap($s, $size, $this->w - 2 * $this->m) as $ln) { $this->need($size + 4); $this->y -= $size + 3; $this->t($ln, $this->m, $this->y, $size, $col); }
        $this->y -= 3;
    }
    function gap(float $h = 8): void { $this->y -= $h; }
    /** Tableau : $head = [libellés], $rows = [[cellules]], $widths = parts relatives, $right = indices alignés à droite. Ligne « total » en gras si $boldLast. */
    function table(array $head, array $rows, array $widths, array $right = [], bool $boldLast = false): void {
        $tot = array_sum($widths); $avail = $this->w - 2 * $this->m; $cw = array_map(fn($x) => $x / $tot * $avail, $widths); $rh = 14; $fs = 8;
        $drawHead = function () use ($head, $cw, $rh, $fs, $right) {
            $this->need($rh * 2); $this->c .= $this->rgb('003A84') . ' rg ' . $this->m . ' ' . round($this->y - $rh, 2) . ' ' . round($this->w - 2 * $this->m, 2) . " $rh re f\n"; $x = $this->m;
            foreach ($head as $i => $hd) { $s = $this->fit((string)$hd, $cw[$i] - 6, $fs, true); $tx = in_array($i, $right, true) ? $x + $cw[$i] - 3 - Pdf::width($s, $fs, true) : $x + 3; $this->t($s, $tx, $this->y - $rh + 4, $fs, 'FFFFFF', true); $x += $cw[$i]; }
            $this->y -= $rh;
        };
        $drawHead(); $z = 0;
        foreach ($rows as $k => $r) {
            if ($this->y - $rh < $this->m + 16 + $this->bottom) { $this->page(); $drawHead(); }
            if ($z++ % 2) $this->c .= $this->rgb('F2F6FB') . ' rg ' . $this->m . ' ' . round($this->y - $rh, 2) . ' ' . round($this->w - 2 * $this->m, 2) . " $rh re f\n";
            $bold = $boldLast && $k === array_key_last($rows); $x = $this->m;
            foreach (array_values($r) as $i => $v) { $s = $this->fit((string)$v, ($cw[$i] ?? 40) - 6, $fs, $bold); $tx = in_array($i, $right, true) ? $x + ($cw[$i] ?? 40) - 3 - Pdf::width($s, $fs, $bold) : $x + 3; $this->t($s, $tx, $this->y - $rh + 4, $fs, '1F2D3D', $bold); $x += $cw[$i] ?? 40; }
            $this->y -= $rh;
        }
        if (!$rows) { $this->need($rh); $this->y -= $rh; $this->t('Aucune ligne.', $this->m + 3, $this->y + 4, $fs, '6B7C93'); }
        $this->y -= 6;
    }
    function output(): string {
        $this->pages[] = $this->c; $np = count($this->pages); $o = [1 => '<< /Type /Catalog /Pages 2 0 R >>']; $kids = '';
        $xo = ''; $base = 5 + 2 * $np; foreach ($this->imgs as $n => $_) $xo .= '/Im' . $n . ' ' . ($base + $n - 1) . ' 0 R ';
        $o[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>'; $o[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        for ($i = 0; $i < $np; $i++) {
            $pid = 5 + 2 * $i; $cid = $pid + 1; $kids .= "$pid 0 R "; $body = $this->pages[$i];
            $this->drawBrandFoot($body); $f = $this->foot . ($this->foot !== '' ? '  ·  ' : '') . 'Page ' . ($i + 1) . ' / ' . $np; $body .= 'BT ' . $this->rgb('6B7C93') . ' rg /F1 8 Tf ' . $this->m . ' 20 Td (' . $this->esc($f) . ") Tj ET\n";
            $o[$pid] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {$this->w} {$this->h}] /Contents $cid 0 R /Resources << /Font << /F1 3 0 R /F2 4 0 R >> " . ($xo ? "/XObject << $xo>> " : '') . ">> >>"; $o[$cid] = '<< /Length ' . strlen($body) . " >>\nstream\n" . $body . 'endstream';
        }
        foreach ($this->imgs as $n => $im) $o[$base + $n - 1] = '<< /Type /XObject /Subtype /Image /Width ' . $im['w'] . ' /Height ' . $im['h'] . ' /ColorSpace ' . $im['c'] . ' /BitsPerComponent 8 /Filter /DCTDecode /Length ' . strlen($im['d']) . " >>\nstream\n" . $im['d'] . "\nendstream";
        $o[2] = '<< /Type /Pages /Kids [' . trim($kids) . '] /Count ' . $np . ' >>'; ksort($o); $out = "%PDF-1.4\n"; $off = [];
        foreach ($o as $i => $b) { $off[$i] = strlen($out); $out .= "$i 0 obj\n$b\nendobj\n"; }
        $x = strlen($out); $out .= "xref\n0 " . (count($o) + 1) . "\n0000000000 65535 f \n"; foreach ($off as $v) $out .= sprintf("%010d 00000 n \n", $v);
        return $out . "trailer\n<< /Size " . (count($o) + 1) . " /Root 1 0 R >>\nstartxref\n$x\n%%EOF\n";
    }
}
