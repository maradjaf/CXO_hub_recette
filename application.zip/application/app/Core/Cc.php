<?php
namespace App\Core;
/** Études de cas pratiques : questions à choix (correction automatique) et réponses libres (correction par un formateur). */
class Cc {
    const ST = ['draft' => 'Brouillon', 'published' => 'Publiée', 'archived' => 'Archivée'];
    const KIND = ['open' => 'Réponse libre', 'single' => 'Choix unique', 'multi' => 'Choix multiples'];
    const AT = ['assigned' => 'À faire', 'in_progress' => 'En cours', 'submitted' => 'À corriger', 'graded' => 'Corrigée'];
    const AT_COLOR = ['assigned' => 'secondary', 'in_progress' => 'info', 'submitted' => 'warning', 'graded' => 'success'];
    static function me(): int { return (int)(Auth::user()['employee_id'] ?? 0); }
    static function maxAttempts(array $c): int { return (int)$c['max_attempts'] > 0 ? (int)$c['max_attempts'] : max(0, (int)setting('cc.max_attempts', 3)); }
    static function questions(int $caseId): array {
        $qs = DB::all('SELECT * FROM cc_questions WHERE case_id=? ORDER BY position', [$caseId]);
        foreach ($qs as &$q) $q['options'] = $q['kind'] === 'open' ? [] : DB::all('SELECT * FROM cc_options WHERE question_id=? ORDER BY position, id', [(int)$q['id']]); unset($q);
        return $qs;
    }
    /** Lit les questions saisies. Les choix s'écrivent un par ligne, précédés de « * » quand ils sont corrects. @return array{0:array,1:?string} */
    static function readQuestions(): array {
        $out = [];
        foreach ((array)($_POST['q_prompt'] ?? []) as $i => $pr) {
            $pr = trim((string)$pr); if ($pr === '') continue;
            $kind = (string)($_POST['q_kind'][$i] ?? 'open'); if (!isset(self::KIND[$kind])) return [[], 'Type de question inconnu.'];
            $pts = trim((string)($_POST['q_points'][$i] ?? '1')); if ($pts === '') $pts = '1'; if (!ctype_digit($pts) || (int)$pts < 1 || (int)$pts > 100) return [[], 'Les points d\'une question : entier de 1 à 100.'];
            $opts = [];
            if ($kind !== 'open') foreach (preg_split('/\R/u', (string)($_POST['q_opts'][$i] ?? '')) as $l) { $l = trim($l); if ($l === '') continue; $ok = str_starts_with($l, '*'); $l = trim($ok ? substr($l, 1) : $l); if ($l !== '') $opts[] = ['label' => mb_substr($l, 0, 400), 'correct' => $ok ? 1 : 0]; }
            $out[] = ['kind' => $kind, 'prompt' => mb_substr($pr, 0, 4000), 'points' => (int)$pts, 'expected' => mb_substr(trim((string)($_POST['q_exp'][$i] ?? '')), 0, 3000) ?: null, 'explanation' => mb_substr(trim((string)($_POST['q_expl'][$i] ?? '')), 0, 3000) ?: null, 'options' => $opts];
            if (count($out) > 60) return [[], '60 questions au maximum.'];
        }
        return [$out, null];
    }
    /** Contrôle de cohérence avant publication. */
    static function problems(int $caseId): array {
        $qs = self::questions($caseId); $p = []; if (!$qs) return ['Ajoutez au moins une question.'];
        foreach ($qs as $i => $q) if ($q['kind'] !== 'open') {
            $n = count($q['options']); $ok = count(array_filter($q['options'], fn($o) => $o['correct']));
            if ($n < 2) $p[] = 'Question ' . ($i + 1) . ' : au moins 2 choix.'; elseif ($ok < 1) $p[] = 'Question ' . ($i + 1) . ' : indiquez la bonne réponse.'; elseif ($q['kind'] === 'single' && $ok > 1) $p[] = 'Question ' . ($i + 1) . ' : un seul choix correct.';
        }
        return $p;
    }
    static function replaceQuestions(int $caseId, array $qs): void {
        foreach (DB::all('SELECT id FROM cc_questions WHERE case_id=?', [$caseId]) as $q) DB::exec('DELETE FROM cc_options WHERE question_id=?', [(int)$q['id']]);
        DB::exec('DELETE FROM cc_questions WHERE case_id=?', [$caseId]); $i = 0;
        foreach ($qs as $q) { $qid = DB::insert('cc_questions', ['case_id' => $caseId, 'position' => ++$i, 'kind' => $q['kind'], 'prompt' => $q['prompt'], 'points' => $q['points'], 'expected' => $q['expected'], 'explanation' => $q['explanation']]); $j = 0; foreach ($q['options'] as $o) DB::insert('cc_options', ['question_id' => $qid, 'position' => ++$j, 'label' => $o['label'], 'correct' => $o['correct']]); }
    }
    /** Note les questions à choix (points partiels pour les choix multiples) ; renvoie [points auto, points max, présence de questions libres]. */
    static function autoGrade(int $attemptId, int $caseId): array {
        $auto = 0.0; $max = 0.0; $open = false;
        foreach (self::questions($caseId) as $q) {
            $max += $q['points'];
            $a = DB::one('SELECT * FROM cc_answers WHERE attempt_id=? AND question_id=?', [$attemptId, (int)$q['id']]);
            if (!$a) { $aid = DB::insert('cc_answers', ['attempt_id' => $attemptId, 'question_id' => (int)$q['id'], 'answer' => null, 'selected' => null]); $a = ['id' => $aid, 'selected' => null]; }
            if ($q['kind'] === 'open') { $open = true; continue; }
            $sel = array_filter(array_map('intval', explode(',', (string)$a['selected']))); $good = array_map(fn($o) => (int)$o['id'], array_filter($q['options'], fn($o) => $o['correct'])); $all = array_map(fn($o) => (int)$o['id'], $q['options']);
            $sel = array_values(array_intersect($sel, $all)); $right = count(array_intersect($sel, $good)); $wrong = count(array_diff($sel, $good));
            $pts = $q['kind'] === 'single' ? ($right === 1 && !$wrong && count($good) === 1 ? (float)$q['points'] : 0.0) : ($good ? round(max(0, ($right - $wrong) / count($good)) * $q['points'], 2) : 0.0);
            DB::update('cc_answers', ['points' => $pts], 'id=?', [(int)$a['id']]); $auto += $pts;
        }
        return [$auto, $max, $open];
    }
    /** Totalise, calcule le résultat et clôt la correction. */
    static function finalize(int $attemptId, ?int $graderId = null): array {
        $at = DB::one('SELECT * FROM cc_attempts WHERE id=?', [$attemptId]); $c = DB::one('SELECT * FROM cc_cases WHERE id=?', [(int)$at['case_id']]);
        $auto = (float)DB::val('SELECT COALESCE(SUM(a.points),0) FROM cc_answers a JOIN cc_questions q ON q.id=a.question_id WHERE a.attempt_id=? AND q.kind<>\'open\'', [$attemptId]);
        $man = (float)DB::val('SELECT COALESCE(SUM(a.points),0) FROM cc_answers a JOIN cc_questions q ON q.id=a.question_id WHERE a.attempt_id=? AND q.kind=\'open\'', [$attemptId]);
        $max = (float)DB::val('SELECT COALESCE(SUM(points),0) FROM cc_questions WHERE case_id=?', [(int)$at['case_id']]); $pct = $max > 0 ? round(100 * ($auto + $man) / $max, 1) : 0.0;
        $res = $pct >= (int)$c['pass_pct'] ? 'pass' : 'fail';
        DB::update('cc_attempts', ['auto_points' => $auto, 'manual_points' => $man, 'max_points' => $max, 'score_pct' => $pct, 'result' => $res, 'status' => 'graded', 'graded_at' => now(), 'grader_id' => $graderId], 'id=?', [$attemptId]);
        return [$pct, $res];
    }
}
