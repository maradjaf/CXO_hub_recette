<?php
namespace App\Core;
/** Gestion des processus : statuts, droits, versions figées avec double validation, comparaison, prise de connaissance. */
class Pr {
    const ST = ['draft' => 'Brouillon', 'in_review' => 'En relecture', 'published' => 'Publié', 'archived' => 'Archivé'];
    const ST_COLOR = ['draft' => 'secondary', 'in_review' => 'warning', 'published' => 'success', 'archived' => 'dark'];
    const CH = ['open' => 'Ouverte', 'accepted' => 'Acceptée', 'rejected' => 'Refusée', 'done' => 'Traitée'];
    const CH_COLOR = ['open' => 'warning', 'accepted' => 'info', 'rejected' => 'dark', 'done' => 'success'];
    const FIELDS = ['name' => 'Nom', 'domain' => 'Domaine', 'purpose' => 'Finalité', 'scope_txt' => 'Périmètre', 'inputs' => 'Entrées', 'outputs' => 'Sorties', 'kpis' => 'Indicateurs', 'owner' => 'Pilote', 'review_months' => 'Revue (mois)'];

    static function pending(int $id): ?array { return DB::one("SELECT * FROM pr_versions WHERE process_id=? AND state='pending' ORDER BY id DESC LIMIT 1", [$id]); }
    static function canSee(array $p): bool {
        if ($p['status'] === 'published') return true;
        return can('pr.manage') || (int)$p['owner_id'] === Auth::id() || (int)$p['created_by'] === Auth::id();
    }
    /** Édition : gestionnaire, pilote, créateur (brouillon) ; gelée pendant qu'une version attend sa validation. */
    static function canEdit(array $p): bool {
        if ($p['status'] === 'archived') return false;
        if ($p['status'] === 'published' && self::pending((int)$p['id'])) return false;
        if (can('pr.manage') || (int)$p['owner_id'] === Auth::id()) return true;
        return $p['status'] === 'draft' && (int)$p['created_by'] === Auth::id();
    }
    static function isOwner(array $p): bool { return (int)$p['owner_id'] === Auth::id(); }
    /** Double validation : le validateur ne doit pas être celui qui a proposé (désactivable par l'administrateur). */
    static function fourEyesOk(array $submitters): bool { if ((string)setting('pr_four_eyes', '1') !== '1') return true; return !in_array(Auth::id(), array_map('intval', $submitters), true); }

    /** Contenu courant (fiche, étapes, liens) sous forme de tableau. */
    static function content(int $id): array {
        $p = DB::one('SELECT name, domain, purpose, scope_txt, inputs, outputs, kpis, owner_id, review_months FROM pr_processes WHERE id=?', [$id]) ?: [];
        $p['owner'] = !empty($p['owner_id']) ? DB::val('SELECT name FROM users WHERE id=?', [(int)$p['owner_id']]) : null;
        $p['steps'] = DB::all('SELECT position, label, role, tool, description, kind, goto_pos, goto_label FROM pr_steps WHERE process_id=? ORDER BY position, id', [$id]);
        $p['links'] = DB::all('SELECT title, url FROM pr_links WHERE process_id=? ORDER BY id', [$id]); return $p;
    }
    static function snapshot(int $id): string { return json_encode(self::content($id), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); }
    static function approved(int $id, int $version): ?array {
        $r = DB::one("SELECT * FROM pr_versions WHERE process_id=? AND version=? AND state='approved' ORDER BY id DESC LIMIT 1", [$id, $version]);
        if ($r) $r['data'] = json_decode((string)$r['snapshot'], true) ?: []; return $r;
    }
    static function dueFrom(string $from, int $months): string { return date('Y-m-d', strtotime("+$months months", strtotime($from))); }

    /** Publie une version approuvée : met à jour le processus, programme la revue et l'obligation de lecture, prévient les lecteurs. */
    static function release(array $p, string $note, ?array $row = null): int {
        $months = max(1, min(60, (int)$p['review_months'] ?: 12)); $name = (string)DB::val('SELECT name FROM users WHERE id=?', [Auth::id()]);
        if ($row) { $v = (int)$row['version']; DB::update('pr_versions', ['state' => 'approved', 'decided_by' => Auth::id(), 'decided_at' => now(), 'decision_note' => $note !== '' ? mb_substr($note, 0, 500) : null], 'id=?', [(int)$row['id']]); }
        else { $v = (int)$p['version'] + 1; DB::insert('pr_versions', ['process_id' => (int)$p['id'], 'version' => $v, 'snapshot' => self::snapshot((int)$p['id']), 'note' => mb_substr($note, 0, 500), 'user_id' => Auth::id(), 'user_name' => $name, 'created_at' => now(), 'state' => 'approved', 'decided_by' => Auth::id(), 'decided_at' => now()]); }
        $days = max(1, min(90, (int)$p['ack_days'] ?: 15));
        DB::update('pr_processes', ['status' => 'published', 'version' => $v, 'published_at' => now(), 'review_due' => self::dueFrom(date('Y-m-d'), $months), 'review_prealert_at' => null, 'review_notified_at' => null, 'needs_update' => 0, 'update_note' => null, 'ack_deadline' => $p['ack_required'] ? date('Y-m-d', strtotime("+$days days")) : null, 'updated_at' => now()], 'id=?', [(int)$p['id']]);
        $p['version'] = $v; $notified = [];
        if ($p['ack_required']) foreach (self::audience($p) as $uid) { Notifier::send($uid, 'Processus à lire', $p['name'] . ' · version ' . $v . ' · à lire avant le ' . date('d/m/Y', strtotime("+$days days")), '/pr/p/' . $p['id']); $notified[$uid] = 1; }
        if ($v > 1) foreach (DB::all('SELECT DISTINCT user_id FROM pr_reads WHERE process_id=? AND user_id<>?', [(int)$p['id'], Auth::id()]) as $r) if (!isset($notified[(int)$r['user_id']])) Notifier::send((int)$r['user_id'], 'Processus mis à jour', $p['name'] . ' · version ' . $v, '/pr/p/' . $p['id']);
        return $v;
    }

    // ---- Prise de connaissance imposée ----
    /** Utilisateurs concernés par la lecture obligatoire (tous les lecteurs, ou ceux des rôles désignés). @return int[] */
    static function audience(array $p): array {
        $all = array_map('intval', array_column(Ca::usersWith('pr.read'), 'id'));
        $codes = array_values(array_filter(array_map('trim', explode(',', (string)$p['ack_roles'])))); if (!$codes) return $all;
        $ids = array_map('intval', array_column(DB::all('SELECT DISTINCT ur.user_id id FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE r.code IN (' . implode(',', array_fill(0, count($codes), '?')) . ')', $codes), 'id'));
        return array_values(array_intersect($all, $ids));
    }
    /** @return array<int,array{id:int,name:string}> concernés n'ayant pas lu la version courante */
    static function unread(array $p): array {
        $read = array_map('intval', array_column(DB::all('SELECT user_id FROM pr_reads WHERE process_id=? AND version=?', [(int)$p['id'], (int)$p['version']]), 'user_id')); $out = [];
        foreach (self::audience($p) as $uid) if (!in_array($uid, $read, true)) $out[] = ['id' => $uid, 'name' => (string)DB::val('SELECT name FROM users WHERE id=?', [$uid])];
        return $out;
    }
    /** Processus publiés que l'utilisateur doit encore lire. */
    static function todo(int $uid): array {
        $out = [];
        foreach (DB::all("SELECT * FROM pr_processes WHERE status='published' AND ack_required=1 ORDER BY ack_deadline, name") as $p) {
            if (DB::val('SELECT 1 FROM pr_reads WHERE process_id=? AND version=? AND user_id=?', [(int)$p['id'], (int)$p['version'], $uid])) continue;
            if (in_array($uid, self::audience($p), true)) $out[] = $p;
        } return $out;
    }

    // ---- Comparaison de versions ----
    private static function lcs(array $a, array $b): array {
        $n = count($a); $m = count($b); $t = array_fill(0, $n + 1, array_fill(0, $m + 1, 0));
        for ($i = $n - 1; $i >= 0; $i--) for ($j = $m - 1; $j >= 0; $j--) $t[$i][$j] = $a[$i] === $b[$j] ? $t[$i + 1][$j + 1] + 1 : max($t[$i + 1][$j], $t[$i][$j + 1]);
        $ops = []; $i = 0; $j = 0;
        while ($i < $n && $j < $m) { if ($a[$i] === $b[$j]) { $ops[] = ['=', $i, $j]; $i++; $j++; } elseif ($t[$i + 1][$j] >= $t[$i][$j + 1]) { $ops[] = ['-', $i, null]; $i++; } else { $ops[] = ['+', null, $j]; $j++; } }
        while ($i < $n) $ops[] = ['-', $i++, null]; while ($j < $m) $ops[] = ['+', null, $j++]; return $ops;
    }
    /** Différence mot à mot, HTML échappé (<del> / <ins>). */
    static function wordDiff(string $old, string $new): string {
        $x = preg_split('/(\s+)/u', $old, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY) ?: []; $y = preg_split('/(\s+)/u', $new, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY) ?: [];
        if (count($x) > 400 || count($y) > 400) return ($old !== '' ? '<del class="text-danger">' . e($old) . '</del> ' : '') . ($new !== '' ? '<ins class="text-success">' . e($new) . '</ins>' : '');
        $o = ''; $buf = ['-' => '', '+' => ''];
        $flush = function () use (&$o, &$buf) { if ($buf['-'] !== '') $o .= '<del class="text-danger">' . e($buf['-']) . '</del>'; if ($buf['+'] !== '') $o .= '<ins class="text-success">' . e($buf['+']) . '</ins>'; $buf = ['-' => '', '+' => '']; };
        foreach (self::lcs($x, $y) as [$op, $i, $j]) { if ($op === '=') { $flush(); $o .= e($x[$i]); } elseif ($op === '-') $buf['-'] .= $x[$i]; else $buf['+'] .= $y[$j]; }
        $flush(); return $o;
    }
    /**
     * @param array $a contenu de référence (ancien)  @param array $b contenu comparé (nouveau)
     * @return array{changed:bool,fields:array,steps:array,links:array}
     */
    static function diff(array $a, array $b): array {
        $fields = []; $changed = false;
        foreach (self::FIELDS as $k => $l) { $x = (string)($a[$k] ?? ''); $y = (string)($b[$k] ?? ''); if ($x !== $y) { $fields[] = ['label' => $l, 'html' => self::wordDiff($x, $y)]; $changed = true; } }
        $sa = array_values($a['steps'] ?? []); $sb = array_values($b['steps'] ?? []); $norm = fn($s) => mb_strtolower(trim((string)$s['label'])); $steps = [];
        $ops = self::lcs(array_map($norm, $sa), array_map($norm, $sb)); $k = 0; $cnt = count($ops);
        $detail = function ($x, $y) { $d = []; foreach (['position' => 'Ordre', 'role' => 'Rôle', 'tool' => 'Outil', 'description' => 'Description', 'kind' => 'Type', 'goto_pos' => 'Renvoi vers l\'étape', 'goto_label' => 'Libellé du renvoi'] as $f => $l) { $p = (string)($x[$f] ?? ''); $q = (string)($y[$f] ?? ''); if ($p !== $q) $d[] = $l . ' : ' . self::wordDiff($p === '' ? '∅' : $p, $q === '' ? '∅' : $q); } return $d; };
        while ($k < $cnt) {
            [$op, $i, $j] = $ops[$k];
            if ($op === '=') { $d = $detail($sa[$i], $sb[$j]); $steps[] = ['type' => $d ? 'modified' : 'same', 'html' => e($sb[$j]['label']), 'details' => $d]; $k++; continue; }
            $rem = []; $add = []; while ($k < $cnt && $ops[$k][0] !== '=') { if ($ops[$k][0] === '-') $rem[] = $ops[$k][1]; else $add[] = $ops[$k][2]; $k++; }
            $pairs = min(count($rem), count($add));
            for ($q = 0; $q < $pairs; $q++) $steps[] = ['type' => 'modified', 'html' => self::wordDiff((string)$sa[$rem[$q]]['label'], (string)$sb[$add[$q]]['label']), 'details' => $detail($sa[$rem[$q]], $sb[$add[$q]])];
            for ($q = $pairs; $q < count($rem); $q++) $steps[] = ['type' => 'removed', 'html' => '<del class="text-danger">' . e($sa[$rem[$q]]['label']) . '</del>', 'details' => []];
            for ($q = $pairs; $q < count($add); $q++) $steps[] = ['type' => 'added', 'html' => '<ins class="text-success">' . e($sb[$add[$q]]['label']) . '</ins>', 'details' => []];
        }
        foreach ($steps as $s) if ($s['type'] !== 'same') $changed = true;
        $la = array_column($a['links'] ?? [], 'title', 'url'); $lb = array_column($b['links'] ?? [], 'title', 'url'); $links = [];
        foreach ($lb as $u => $t) if (!isset($la[$u])) { $links[] = ['type' => 'added', 'title' => $t, 'url' => $u]; $changed = true; }
        foreach ($la as $u => $t) if (!isset($lb[$u])) { $links[] = ['type' => 'removed', 'title' => $t, 'url' => $u]; $changed = true; }
        return ['changed' => $changed, 'fields' => $fields, 'steps' => $steps, 'links' => $links];
    }
}
