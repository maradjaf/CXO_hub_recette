<?php
namespace App\Core;

/** Sélection de collaborateurs pour les lancements en masse : cases cochées et/ou liste de matricules collée. */
class Bulk {
    static function candidates(string $where): array {
        return DB::all("SELECT e.id, e.matricule, e.first_name, e.last_name, e.hire_date, t.name team, ch.name channel FROM employees e LEFT JOIN teams t ON t.id=e.team_id LEFT JOIN channels ch ON ch.id=e.channel_id WHERE $where ORDER BY e.last_name, e.first_name LIMIT 3000");
    }
    /** @return array{0:int[],1:string[]} identifiants uniques (dans le périmètre de l'utilisateur) et matricules inconnus */
    static function ids(array $post): array {
        $ids = array_map('intval', (array)($post['ids'] ?? [])); $unknown = [];
        foreach (preg_split('/[\s,;]+/', (string)($post['matricules'] ?? ''), -1, PREG_SPLIT_NO_EMPTY) as $m) { $id = DB::val('SELECT id FROM employees WHERE matricule=?', [mb_substr($m, 0, 40)]); if ($id) $ids[] = (int)$id; else $unknown[] = $m; }
        $ids = array_values(array_unique(array_filter($ids, fn($i) => $i > 0 && DB::val('SELECT 1 FROM employees WHERE id=?', [$i]) && Scope::allows($i))));
        return [$ids, array_values(array_unique($unknown))];
    }
    static function report(int $ok, int $skip, array $unknown, string $what): string {
        return "$ok $what." . ($skip ? " $skip ignoré(s) (parcours déjà ouvert)." : '') . ($unknown ? ' Matricule(s) inconnu(s) : ' . implode(', ', array_slice($unknown, 0, 8)) . (count($unknown) > 8 ? '…' : '') . '.' : '');
    }
}
