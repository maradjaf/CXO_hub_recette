<?php
namespace App\Core;
class Menu {
    private static ?array $all = null;
    static function items(): array { return self::$all ??= DB::all('SELECT * FROM menu_items WHERE active=1 ORDER BY sort_order, id'); }
    /** Arbre filtré par droits : groupes avec leurs entrées visibles. */
    static function tree(): array {
        $out = [];
        foreach (self::items() as $m) if (!$m['parent_id']) $out[$m['id']] = $m + ['children' => []];
        foreach (self::items() as $m) {
            if ($m['parent_id'] && isset($out[$m['parent_id']]) && (!$m['permission'] || Auth::can($m['permission']))) $out[$m['parent_id']]['children'][] = $m;
        }
        return array_values(array_filter($out, fn($g) => $g['children'] || ($g['url'] && (!$g['permission'] || Auth::can($g['permission'])))));
    }
    static function activeCode(string $path): ?string {
        $best = null; $len = 0;
        foreach (self::items() as $m) if ($m['url'] && ($path === $m['url'] || ($m['url'] !== '/' && str_starts_with($path, $m['url'] . '/'))) && strlen($m['url']) > $len) { $best = $m['code']; $len = strlen($m['url']); }
        return $best;
    }
    /** Modules liés, proposés en « Voir aussi » sous le fil d'Ariane (codes de groupes du menu). */
    const RELATED = [
        'grp_rh' => ['grp_workflow', 'grp_training', 'grp_pl'], 'grp_workflow' => ['grp_rh'], 'grp_at' => ['grp_pr', 'grp_kb'],
        'grp_training' => ['grp_tq', 'grp_elearn', 'grp_ev'], 'grp_elearn' => ['grp_training', 'grp_cc', 'grp_kb'], 'grp_kb' => ['grp_cs', 'grp_pr', 'grp_bot'],
        'grp_ca' => ['grp_qa', 'grp_cx', 'grp_pr'], 'grp_cx' => ['grp_qa', 'grp_ca'], 'grp_pj' => ['grp_pr', 'grp_ev'], 'grp_tq' => ['grp_training', 'grp_elearn'],
        'grp_pr' => ['grp_kb', 'grp_ca'], 'grp_ev' => ['grp_training', 'grp_pj'], 'grp_pl' => ['grp_rh', 'grp_qa'], 'grp_org' => ['grp_rh', 'grp_pl'], 'grp_cs' => ['grp_eoc', 'grp_kb', 'grp_qa'],
        'grp_bot' => ['grp_kb'], 'grp_cc' => ['grp_elearn', 'grp_training', 'grp_cs'], 'grp_eoc' => ['grp_cs', 'grp_qa'], 'grp_qa' => ['grp_ca', 'grp_cs', 'grp_eoc', 'grp_cc'],
    ];
    /** Périmètre affiché en tête des modules qui pourraient être confondus : [texte, module à ne pas confondre]. */
    const ABOUT = [
        'grp_org' => ['Organisation du personnel : Direction › Département › Pôle › Activité ou store, niveaux N à N+6, organigramme filtrable, trombinoscope et publications périodiques.', 'grp_rh'],
        'grp_qa' => ['Contrôle qualité : évaluation des interactions des conseillers avec les clients (écoutes, grilles de notation, notes et coaching).', 'grp_ca'],
        'grp_ca' => ['Contrôle et audit de niveau 1 : vérification de la conformité des procédures et des points de contrôle sur un périmètre (store, équipe), avec plans de contrôle et actions correctives.', 'grp_qa'],
    ];
    /** Contexte de la page : groupe et entrée actifs, modules liés (accessibles), périmètre. */
    static function context(?string $active): array {
        $tree = self::tree(); $by = []; foreach ($tree as $g) $by[$g['code']] = $g;
        $grp = null; $item = null;
        foreach ($tree as $g) { if ($g['code'] === $active) { $grp = $g; break; } foreach ($g['children'] as $m) if ($m['code'] === $active) { $grp = $g; $item = $m; break 2; } }
        $link = fn(array $g) => ['label' => $g['label'], 'icon' => $g['icon'] ?: 'folder', 'url' => $g['children'][0]['url'] ?? $g['url'], 'code' => $g['code']];
        $rel = []; foreach (self::RELATED[$grp['code'] ?? ''] ?? [] as $c) if (isset($by[$c])) $rel[] = $link($by[$c]);
        $about = null; if ($grp && isset(self::ABOUT[$grp['code']])) { [$t, $o] = self::ABOUT[$grp['code']]; $about = ['text' => $t, 'other' => isset($by[$o]) ? $link($by[$o]) : null]; }
        return ['group' => $grp ? $link($grp) : null, 'children' => $grp['children'] ?? [], 'item' => $item, 'related' => $rel, 'about' => $about];
    }
}
