<?php
namespace App\Core;
/** Scripts d'appel, codes de fin d'appel et contrôles d'adhérence. */
class Cs {
    const CAT = ['resolved' => 'Résolu', 'follow_up' => 'Suivi / rappel', 'transfer' => 'Transfert', 'escalation' => 'Escalade', 'abandon' => 'Abandon', 'other' => 'Autre'];
    const FOLLOW = ['full' => 'Complet', 'partial' => 'Partiel', 'none' => 'Non suivi'];
    const FIELDS = ['family', 'keywords', 'title', 'kind', 'channel_id', 'language', 'situation', 'body', 'avoid', 'required_phrases', 'team_id', 'mandatory', 'owner_id'];
    static function months(): int { $m = (int)setting('cs.review_months', 6); return $m >= 1 && $m <= 60 ? $m : 6; }
    static function target(): int { return max(1, min(100, (int)setting('cs.adherence_target', 85))); }
    static function vars(?string $body): array { preg_match_all('/\{\{\s*([a-zA-Z0-9_]{1,30})\s*\}\}/', (string)$body, $m); return array_values(array_unique($m[1])); }
    /** Texte du script échappé, variables {{x}} repérées pour le remplissage dynamique. */
    static function render(?string $body): string {
        $h = e($body ?? '');
        return preg_replace('/\{\{\s*([a-zA-Z0-9_]{1,30})\s*\}\}/', '<mark class="sv" data-k="$1">{{$1}}</mark>', $h);
    }
    static function points(int $id): array { return DB::all('SELECT * FROM cs_script_points WHERE script_id=? ORDER BY position', [$id]); }
    static function replacePoints(int $id, array $pts): void {
        DB::exec('DELETE FROM cs_script_points WHERE script_id=?', [$id]); $i = 0;
        foreach ($pts as $p) DB::insert('cs_script_points', ['script_id' => $id, 'position' => ++$i, 'label' => $p['label'], 'mandatory' => $p['mandatory'], 'weight' => $p['weight']]);
    }
    /** Points de contrôle saisis (pt_label[], pt_weight[], pt_mand[] indexés). @return array{0:array,1:?string} */
    static function readPoints(): array {
        $out = [];
        foreach ((array)($_POST['pt_label'] ?? []) as $i => $l) {
            $l = trim((string)$l); if ($l === '') continue; $w = trim((string)($_POST['pt_weight'][$i] ?? '1')); if ($w === '') $w = '1';
            if (!ctype_digit($w) || (int)$w < 1 || (int)$w > 10) return [[], 'Le poids d\'un point de contrôle est un entier de 1 à 10.'];
            $out[] = ['label' => mb_substr($l, 0, 300), 'weight' => (int)$w, 'mandatory' => !empty($_POST['pt_mand'][$i]) ? 1 : 0];
            if (count($out) > 40) return [[], '40 points de contrôle au maximum.'];
        }
        return [$out, null];
    }
    static function snapshot(int $id, ?string $note = null): void {
        $s = DB::one('SELECT * FROM cs_scripts WHERE id=?', [$id]); if (!$s) return;
        $data = ['f' => array_intersect_key($s, array_flip(self::FIELDS)), 'points' => array_map(fn($x) => array_diff_key($x, ['id' => 1, 'script_id' => 1]), self::points($id))];
        $old = DB::one('SELECT id FROM cs_script_versions WHERE script_id=? AND version=?', [$id, (int)$s['version']]);
        $row = ['data' => json_encode($data, JSON_UNESCAPED_UNICODE), 'user_id' => Auth::id(), 'user_name' => (string)(Auth::user()['name'] ?? ''), 'note' => $note ? mb_substr($note, 0, 200) : null, 'created_at' => now()];
        if ($old) DB::update('cs_script_versions', $row, 'id=?', [(int)$old['id']]); else DB::insert('cs_script_versions', $row + ['script_id' => $id, 'version' => (int)$s['version']]);
    }
    /** @param array[] $pts lignes avec weight, mandatory, ok  @return array{0:float,1:bool,2:string} score %, tous les points obligatoires respectés, suivi (full|partial|none) */
    static function score(array $pts): array {
        $tot = array_sum(array_map(fn($p) => (int)$p['weight'], $pts)); if (!$tot) return [100.0, true, 'full'];
        $ok = array_sum(array_map(fn($p) => !empty($p['ok']) ? (int)$p['weight'] : 0, $pts)); $nb = count(array_filter($pts, fn($p) => !empty($p['ok'])));
        $mand = true; foreach ($pts as $p) if (!empty($p['mandatory']) && empty($p['ok'])) $mand = false;
        return [round(100 * $ok / $tot, 1), $mand, $nb === count($pts) ? 'full' : ($nb === 0 ? 'none' : 'partial')];
    }
    static function checkScope(): array { return can('cs.check') ? Scope::sql('c.employee_id') : ['c.employee_id=?', [(int)(Auth::user()['employee_id'] ?? 0)]]; }

    /** Extrait la liste de scripts d'un fichier : bibliothèque HTML exportée (bloc JSON « data »), ou JSON ({"scripts":[…]} ou liste). */
    static function parseLibrary(string $raw): array {
        if (preg_match('#<script[^>]*type="application/json"[^>]*id="data"[^>]*>(.*?)</script>#s', $raw, $m)) $raw = $m[1];
        $j = json_decode(trim($raw), true); if (is_array($j) && isset($j['scripts'])) $j = $j['scripts']; if (!is_array($j) || !$j) throw new \RuntimeException('Aucune liste de scripts reconnue dans ce fichier.');
        $out = []; foreach ($j as $x) if (is_array($x) && trim((string)($x['id'] ?? '')) !== '' && trim((string)($x['titre'] ?? '')) !== '' && trim((string)($x['script'] ?? '')) !== '') $out[] = $x;
        if (!$out) throw new \RuntimeException('Aucun script exploitable (id, titre et script sont obligatoires).'); return $out;
    }
    /** Variables de remplissage : [Prénom] devient {{prenom}}, etc. Les autres crochets (valeurs d'exemple) restent tels quels. */
    static function convertVars(string $t): string { return strtr($t, ['[Prénom]' => '{{prenom}}', '[date]' => '{{date}}', '[heure]' => '{{heure}}', '[numéro]' => '{{numero}}']); }
    /** Importe ou met à jour des scripts (clé : identifiant source). Ne supprime rien. Un script en alerte reste en brouillon pour relecture. */
    static function importLibrary(array $items, bool $publish = true): array {
        $n = ['créés' => 0, 'mis à jour' => 0, 'inchangés' => 0, 'à relire' => 0]; $notes = [];
        foreach ($items as $x) {
            $src = mb_substr(trim((string)$x['id']), 0, 30); $fam = (string)($x['p'] ?? ''); $fam = Ref::has('script_families', $fam) ? $fam : null;
            $d = ['title' => mb_substr(trim((string)$x['titre']), 0, 200), 'body' => self::convertVars(rtrim(str_replace("\r", '', (string)$x['script']))), 'keywords' => mb_substr(trim((string)($x['kw'] ?? '')), 0, 600) ?: null, 'family' => $fam, 'src_note' => isset($x['warn']) ? mb_substr((string)$x['warn'], 0, 300) : null];
            $old = DB::one('SELECT * FROM cs_scripts WHERE src_ref=?', [$src]);
            if (isset($x['warn'])) { $n['à relire']++; $notes[] = "$src : " . $x['warn']; }
            if (!$old) {
                $st = $publish && !isset($x['warn']) ? 'published' : 'draft';
                $id = DB::insert('cs_scripts', $d + ['ref' => Sop::nextRef('cs_scripts', 'SC'), 'src_ref' => $src, 'version' => 1, 'status' => $st, 'language' => 'fr', 'mandatory' => 0, 'author_id' => Auth::id() ?: null, 'published_at' => $st === 'published' ? now() : null,
                    'review_due' => date('Y-m-d', strtotime('+' . max(1, (int)setting('cs.review_months', 6)) . ' months')), 'created_at' => now(), 'updated_at' => now()]);
                self::snapshot($id, 'Import de la bibliothèque'); $n['créés']++; continue;
            }
            $chg = false; foreach (['title', 'body', 'keywords', 'family', 'src_note'] as $f) if ((string)$old[$f] !== (string)$d[$f]) $chg = true;
            if (!$chg) { $n['inchangés']++; continue; }
            $u = $d + ['updated_at' => now()];
            if ((string)$old['body'] !== (string)$d['body'] && $old['status'] === 'published') { $u['version'] = (int)$old['version'] + 1; $u['published_at'] = now(); $u['review_notified_at'] = null; }
            DB::update('cs_scripts', $u, 'id=?', [(int)$old['id']]); self::snapshot((int)$old['id'], 'Mise à jour depuis la bibliothèque'); $n['mis à jour']++;
        }
        return [$n, $notes];
    }
}
