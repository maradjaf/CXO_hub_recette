<?php
namespace App\Core;

/**
 * Lot 55 : recherche globale (M28). Chaque source applique le droit d'accès et le périmètre de l'utilisateur AVANT la recherche :
 * un objet hors périmètre n'est ni affiché ni compté.
 */
final class Search {
    const MIN = 2; const PREVIEW = 6; const FULL = 50;

    /** Découpe la saisie en mots, sans les jokers SQL ; ['%a%', '%b%'] */
    static function terms(string $q): array {
        $q = trim(str_replace(['%', '_', '\\'], ' ', $q)); $out = [];
        foreach (preg_split('/\s+/u', $q, -1, PREG_SPLIT_NO_EMPTY) ?: [] as $t) if (mb_strlen($t) >= 1) $out[] = '%' . $t . '%';
        return array_slice($out, 0, 6);
    }
    /** Condition « chaque mot figure dans l'une des colonnes » ; retourne [sql, paramètres]. */
    private static function match(array $cols, array $terms): array {
        $w = []; $p = [];
        foreach ($terms as $t) { $w[] = '(' . implode(' OR ', array_map(fn($c) => "$c LIKE ?", $cols)) . ')'; foreach ($cols as $_) $p[] = $t; }
        return [implode(' AND ', $w), $p];
    }
    /** Définition des sources : clé => [libellé, icône, droit requis (callable), construction]. */
    static function sources(): array {
        return [
            'emp' => ['Collaborateurs', 'people', fn() => can('employees.view'), function (array $t) {
                [$m, $p] = self::match(['e.first_name', 'e.last_name', 'e.matricule', 'e.email', 'e.qa_ref'], $t); [$sw, $sp] = Scope::sql('e.id');
                return ["employees e LEFT JOIN teams tm ON tm.id=e.team_id LEFT JOIN stores s ON s.id=e.store_id WHERE e.status<>'left' AND $sw AND $m", array_merge($sp, $p),
                        "e.id, e.last_name, e.first_name, e.matricule, tm.name team, s.name store", 'e.last_name, e.first_name',
                        fn($r) => [trim($r['last_name'] . ' ' . $r['first_name']), trim($r['matricule'] . ' · ' . ($r['team'] ?: ($r['store'] ?: '—')), ' ·'), 'employees/' . $r['id']]];
            }],
            'tk' => ['Tickets', 'life-preserver', fn() => can('at.view') || can('at.handle'), function (array $t) {
                [$m, $p] = self::match(['t.reference', 't.title'], $t); $vis = '1=1'; $vp = [];
                if (!can('at.handle') && !can('scope.all')) {
                    $ids = Scope::ids() ?? [];
                    if (!$ids) { $vis = 't.requester_id=?'; $vp = [Auth::id()]; }
                    else { $vis = '(t.requester_id=? OR t.requester_id IN (SELECT id FROM users WHERE employee_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ')))'; $vp = array_merge([Auth::id()], $ids); }
                }
                return ["at_tickets t WHERE $vis AND $m", array_merge($vp, $p), 't.id, t.reference, t.title, t.status, t.kind', 't.id DESC',
                        fn($r) => [$r['reference'] . ' · ' . $r['title'], (string)$r['status'] . ' · ' . $r['kind'], 'at/' . $r['id']]];
            }],
            'tr' => ['Formations', 'mortarboard', fn() => can('training.view'), function (array $t) {
                [$m, $p] = self::match(['t.code', 't.title', 't.category'], $t);
                return ["trainings t WHERE t.active=1 AND $m", $p, 't.id, t.code, t.title, t.category, t.mandatory', 't.title',
                        fn($r) => [$r['title'], trim($r['code'] . ' · ' . ($r['category'] ?: '') . ($r['mandatory'] ? ' · obligatoire' : ''), ' ·'), 'trainings/' . $r['id']]];
            }],
            'kb' => ['Articles', 'journal-text', fn() => can('kb.read'), function (array $t) {
                [$m, $p] = self::match(['a.title', 'a.summary', 'a.tags'], $t); [$vw, $vp] = Kb::visible('a');
                return ["kb_articles a WHERE $vw AND $m", array_merge($vp, $p), 'a.id, a.title, a.summary, a.kind', 'a.title',
                        fn($r) => [$r['title'], mb_strimwidth((string)$r['summary'], 0, 110, '…'), 'kb/a/' . $r['id']]];
            }],
            'ns' => ['Notes de service', 'file-earmark-text', fn() => can('ns.use'), function (array $t) {
                [$m, $p] = self::match(['n.title', 'n.ref', 'n.addressee'], $t); $vis = (can('ns.secretary') || can('ns.all')) ? '1=1' : 'n.requester_id=?'; $vp = $vis === '1=1' ? [] : [Auth::id()];
                return ["ns_notes n WHERE $vis AND $m", array_merge($vp, $p), 'n.id, n.ref, n.title, n.status', 'n.id DESC', fn($r) => [$r['ref'] . ' · ' . $r['title'], (string)$r['status'], 'ns/' . $r['id']]];
            }],
            'msg' => ['Messages', 'envelope', fn() => can('msg.use'), function (array $t) {
                [$m, $p] = self::match(['m.subject'], $t); $me = (int)Auth::id();
                return ["msg_messages m WHERE (m.sender_id=? OR EXISTS (SELECT 1 FROM msg_recipients r WHERE r.message_id=m.id AND r.user_id=? AND r.deleted=0)) AND $m", array_merge([$me, $me], $p), 'm.id, m.subject, m.created_at', 'm.id DESC',
                        fn($r) => [$r['subject'], date('d/m/Y', strtotime($r['created_at'])), 'msg/' . $r['id']]];
            }],
            'fo' => ['Forum', 'chat-square-text', fn() => can('fo.use'), function (array $t) {
                [$m, $p] = self::match(['t.title'], $t); $vis = can('fo.moderate') ? '' : ' AND c.staff_only=0';
                return ["fo_topics t JOIN fo_categories c ON c.id=t.category_id WHERE c.active=1$vis AND $m", $p, 't.id, t.title, c.name cat', 't.last_post_at DESC', fn($r) => [$r['title'], $r['cat'], 'forum/t/' . $r['id']]];
            }],
            'ref' => ['Référentiels', 'diagram-3', fn() => can('employees.view') || can('stores.directory'), function (array $t) {
                // magasins, équipes et canaux : une seule liste, chaque ligne ouvre la liste filtrée correspondante
                $parts = []; $ps = [];
                if (can('stores.directory')) { [$m, $p] = self::match(['s.name', 's.code', 's.city'], $t); $parts[] = "SELECT 'Store' kind, s.name, s.code, s.id, 's' k FROM stores s WHERE s.active=1 AND $m"; $ps = array_merge($ps, $p); }
                if (can('employees.view')) {
                    [$m, $p] = self::match(['x.name'], $t); $parts[] = "SELECT 'Équipe' kind, x.name, '' code, x.id, 't' k FROM teams x WHERE $m"; $ps = array_merge($ps, $p);
                    [$m, $p] = self::match(['x.name', 'x.code'], $t); $parts[] = "SELECT 'Canal' kind, x.name, x.code, x.id, 'c' k FROM channels x WHERE x.active=1 AND $m"; $ps = array_merge($ps, $p);
                }
                if (!$parts) return null;
                return ['(' . implode(' UNION ALL ', $parts) . ') u WHERE 1=1', $ps, 'u.kind, u.name, u.code, u.id, u.k', 'u.kind, u.name',
                        fn($r) => [$r['name'], $r['kind'] . ($r['code'] ? ' · ' . $r['code'] : ''), $r['k'] === 's' ? 'stores?q=' . rawurlencode($r['name']) : 'employees?' . ($r['k'] === 't' ? 'team_id' : 'channel_id') . '=' . $r['id']]];
            }],
        ];
    }

    /** @return array<string,array{label:string,icon:string,total:int,rows:array}> uniquement les sources autorisées ; $only limite à une source. */
    static function run(string $q, ?string $only = null): array {
        $terms = self::terms($q); $out = [];
        if (!$terms || mb_strlen(trim(str_replace(['%', '_'], '', $q))) < self::MIN) return $out;
        foreach (self::sources() as $k => [$label, $icon, $allowed, $build]) {
            if ($only !== null && $only !== $k) continue;
            if (!$allowed()) continue;
            $b = $build($terms); if (!$b) continue; [$from, $p, $sel, $ord, $fmt] = $b;
            $total = (int)DB::val("SELECT COUNT(*) FROM $from", $p); $rows = [];
            if ($total) foreach (DB::all("SELECT $sel FROM $from ORDER BY $ord LIMIT " . ($only === null ? self::PREVIEW : self::FULL), $p) as $r) { [$t, $s, $u] = $fmt($r); $rows[] = ['title' => $t, 'sub' => $s, 'url' => $u]; }
            if ($total) $out[$k] = ['label' => $label, 'icon' => $icon, 'total' => $total, 'rows' => $rows];
        }
        return $out;
    }
}
