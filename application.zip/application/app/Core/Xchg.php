<?php
namespace App\Core;
/** Réglages des échanges (appels planifiés, chat, pièces jointes) : modifiables par l'admin / le coordinateur technique dans « Visio, WhatsApp et chat ». */
class Xchg {
    const DEF = [
        'meet.enabled_inc' => '1', 'meet.enabled_at' => '1', 'meet.platforms' => 'teams,zoom,meet,whatsapp,phone,other', 'meet.default_duration' => '30', 'meet.reminder_min' => '15', 'meet.max_guests' => '40',
        'meet.ch_inapp' => '1', 'meet.ch_email' => '1', 'meet.ch_sms' => '1', 'meet.ch_wa' => '1', 'meet.auto_default' => '1',
        'chat.enabled_inc' => '1', 'chat.enabled_at' => '1', 'chat.poll_sec' => '5', 'chat.max_len' => '1000', 'chat.edit_min' => '10', 'chat.notify' => '1', 'chat.internal' => '1', 'chat.rate_per_min' => '20', 'chat.requester' => '1',
        'elearn.level_gate' => '1', 'elearn.pdftotext_path' => '', 'elearn.sequential_default' => '1', 'elearn.remind_days' => '3', 'elearn.inactive_days' => '7', 'elearn.qna' => '1', 'elearn.requests' => '1', 'elearn.self_enroll_paths' => '1', 'elearn.import_max_mb' => '20', 'elearn.media_max_mb' => '50',
        'rn.enabled' => '1', 'rn.lazy' => '1', 'rn.kinds' => 'Comité de pilotage,Point d\'équipe,Revue de performance,Réunion client,Réunion de service,Formation,Autre', 'rn.default_duration' => '60', 'rn.reminder_min' => '60', 'rn.max_attendees' => '100', 'rn.ch_inapp' => '1', 'rn.ch_email' => '1', 'rn.ch_sms' => '1', 'rn.ch_wa' => '0',
        'rn.four_eyes' => '0', 'rn.action_default_days' => '14', 'rn.action_remind_days' => '2', 'rn.action_email' => '1', 'rn.action_owner_close' => '1', 'rn.minutes_chase_days' => '2',
        'tc.enabled' => '1', 'tc.allow_groups' => '1', 'tc.group_max' => '50', 'tc.max_len' => '4000', 'tc.edit_min' => '15', 'tc.longpoll' => '20', 'tc.poll_sec' => '4', 'tc.files' => '1', 'tc.file_max_mb' => '10', 'tc.notify' => '1', 'tc.rate_per_min' => '60', 'tc.reactions' => '1',
        'files.max_mb' => '10', 'files.max_count' => '10', 'files.groups' => '',
    ];
    static function get(string $k): string { $v = Settings::get($k); return $v === null || $v === '' ? (self::DEF[$k] ?? '') : (string)$v; }
    static function on(string $k): bool { return self::get($k) === '1'; }
    static function int(string $k, int $min = 0, int $max = 100000): int { return max($min, min($max, (int)self::get($k))); }
    /** Liste CSV (valeur vide enregistrée = tout désactivé pour les plateformes ; défaut = toutes). */
    static function csv(string $k): array { $v = Settings::get($k); $v = $v === null ? (self::DEF[$k] ?? '') : (string)$v; return array_values(array_filter(array_map('trim', explode(',', $v)), 'strlen')); }
}
