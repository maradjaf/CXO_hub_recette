<?php
namespace App\Core;

/**
 * Lot 59 — Données d'exemple VOC & NPS reprises de la maquette : lots NPS Consumer et CSAT Mixx d'octobre 2026 (agrégés),
 * NPS publié 2025, focus group du 5 mars 2026 (constats, plan d'action, photos), séries CX de démonstration et fiches d'exemple.
 * Tout est marqué « exemple » : les lots importés prennent le pas sur les lots d'exemple, et l'ensemble se retire en un clic.
 */
final class VocDemo {
    const SERIES = [['s-cc-csat', 'Call Center', 'CSAT', 'Satisfaction post-appel', 'csat4', 'up', 84, 82], ['s-cc-fcr', 'Call Center', 'FCR', 'Résolution au premier contact', 'ratio', 'up', 78, 76], ['s-b2b-csat', 'B2B', 'CSAT', 'Satisfaction après prise en charge', 'csat4', 'up', 90, 86],
        ['s-b2b-ces', 'B2B', 'CES', 'Facilité de traitement', 'mean7', 'up', 5.6, 5.2], ['s-cvm-csat', 'CVM', 'CSAT', 'Satisfaction après campagne', 'csat4', 'up', 78, 73], ['s-store-fvr', 'Store', 'FVR', 'Résolution à la première visite', 'ratio', 'up', 84, 80],
        ['s-store-csat', 'Store', 'CSAT', 'Satisfaction après visite', 'csat4', 'up', 88, 86], ['s-mixx-fcr', 'Mixx', 'FCR', 'Résolution des contacts Mixx', 'ratio', 'up', 78, 73], ['s-digital-ces', 'Digital', 'CES', 'Effort perçu · 1 facile à 5 difficile', 'mean5', 'down', 2.5, 2.8]];
    const PLACES = ['Call Center' => ['Lomé', 'Kara'], 'B2B' => ['Lomé', 'Maritime'], 'CVM' => ['Lomé', 'Plateaux'], 'Store' => ['Lomé', 'Kara', 'Maritime'], 'Mixx' => ['Lomé', 'Centrale'], 'Digital' => ['Lomé', 'Savanes']];

    static function present(): bool { return (bool)(DB::val('SELECT 1 FROM vn_batches WHERE is_demo=1') || DB::val('SELECT 1 FROM vn_events WHERE is_demo=1') || DB::val('SELECT 1 FROM vn_series WHERE is_demo=1')); }

    static function load(): bool {
        if (self::present()) return false;
        $file = ROOT . '/database/data/voc/voc_demo.json'; $d = is_file($file) ? json_decode((string)file_get_contents($file), true) : null; if (!is_array($d)) return false;
        $pdo = DB::pdo(); $own = !$pdo->inTransaction(); if ($own) $pdo->beginTransaction();
        // lots d'octobre 2026
        $s = $d['nps']['summary']; $bid = DB::insert('vn_batches', ['type' => 'nps', 'name' => $s['name'], 'sheet' => $s['sheet'], 'date_from' => $s['from'], 'date_to' => $s['to'], 'total' => $s['total'], 'stats' => json_encode(array_intersect_key($s, array_flip(['total', 'contacts', 'answered', 'valid', 'qualified']))),
            'note' => 'Octobre 2026 · Base à réconcilier · Le rapport provisoire affiche Yas +41 (n = 900) et Moov +45 (n = 604). Le recalcul sur la feuille de données retient 390 qualifiés Yas/Moov de plus.', 'is_demo' => 1, 'created_at' => now()]);
        $st = $pdo->prepare('INSERT INTO vn_nps (batch_id, day, brand, region, band, age, driver, sub, det, pas, pro) VALUES (?,?,?,?,?,?,?,?,?,?,?)'); foreach ($d['nps']['rows'] as $r) $st->execute(array_merge([$bid], $r));
        $s = $d['csat']['summary']; $bid = DB::insert('vn_batches', ['type' => 'csat', 'name' => $s['name'], 'sheet' => $s['sheet'], 'date_from' => $s['from'], 'date_to' => $s['to'], 'total' => $s['total'], 'stats' => json_encode(['total' => $s['total']]), 'is_demo' => 1, 'created_at' => now()]);
        $st = $pdo->prepare('INSERT INTO vn_csat (batch_id, day, pay_day, channel, segment, question, n1, n2, n3, n4, n5) VALUES (?,?,?,?,?,?,?,?,?,?,?)'); foreach ($d['csat']['rows'] as $r) { $r[1] = $r[1] ?: null; $st->execute(array_merge([$bid], $r)); }
        // NPS publié
        if (!DB::val('SELECT 1 FROM vn_published')) {
            $yas = [30, 34, 42, 44, 43, 48, 47, 49, 51]; $moov = [39, 45, 46, 49, 45, 50, 45, 44, 50];
            foreach ($yas as $i => $y) DB::insert('vn_published', ['period' => sprintf('2025-%02d', $i + 2), 'method' => 'Global publié', 'yas' => $y, 'moov' => $moov[$i], 'source' => 'Rapport d\'octobre 2025, page 2', 'created_at' => now()]);
            DB::insert('vn_published', ['period' => '2026-10', 'method' => 'Consumer provisoire', 'yas' => 41, 'moov' => 45, 'yas_n' => 900, 'moov_n' => 604, 'source' => 'Rapport provisoire d\'octobre 2026', 'created_at' => now()]);
        }
        // séries CX de démonstration et mesures mensuelles
        $months = ['2026-05', '2026-06', '2026-07', '2026-08', '2026-09', '2026-10']; $shift = [-3, 0, -1, 1, 2, 3];
        foreach (self::SERIES as $idx => [$code, $scope, $metric, $name, $formula, $dir, $target, $center]) {
            if (DB::val('SELECT 1 FROM vn_series WHERE code=?', [$code])) continue; $pct = Voc::unit($formula) === '%';
            $sid = DB::insert('vn_series', ['code' => $code, 'name' => $name, 'metric' => $metric, 'scope' => $scope, 'formula' => $formula, 'direction' => $dir, 'target' => $target, 'origin' => 'Série de démonstration', 'description' => Voc::RULES[$metric], 'is_demo' => 1, 'created_at' => now()]);
            foreach ($months as $j => $m) foreach (self::PLACES[$scope] as $k => $region) { $n = 84 + (($idx * 19 + $j * 21 + $k * 13) % 89); $c = $center + ($dir === 'down' ? -1 : 1) * ($pct ? $shift[$j] + $k : $shift[$j] / 8 + $k / 10);
                DB::insert('vn_measures', ['series_id' => $sid, 'day' => "$m-01", 'region' => $region, 'segment' => $k ? 'B2C' : 'Tous profils', 'channel' => $scope === 'Digital' ? 'WhatsApp' : $scope, 'numerator' => (int)round($pct ? $n * $c / 100 : $n * $c), 'base' => $n, 'grain' => 'month', 'source' => 'Démonstration', 'created_at' => now()]); }
        }
        // focus group du 5 mars 2026
        $e = $d['focus']['event']; $h = $e['hotArchive'];
        $eid = DB::insert('vn_events', ['ref' => 'FG-MARS26', 'theme' => $e['theme'], 'day' => $e['date'], 'time_start' => $e['start'], 'time_end' => $e['end'], 'location' => $e['location'], 'owner' => $e['owner'], 'target' => $e['target'], 'expected' => $e['expected'], 'confirmed' => $e['confirmed'], 'present' => $e['present'], 'status' => $e['status'],
            'context' => $e['context'], 'objective' => $e['objective'], 'method' => $e['method'], 'agenda' => $e['agenda'], 'findings' => $e['findings'], 'report' => $e['report'], 'staff' => json_encode($e['staff'], JSON_UNESCAPED_UNICODE), 'profiles' => json_encode($e['profiles'], JSON_UNESCAPED_UNICODE), 'study' => json_encode($e['study'], JSON_UNESCAPED_UNICODE),
            'hot_invited' => $h['invited'], 'hot_responded' => $h['responded'], 'hot_very' => $h['verySatisfied'], 'hot_satisfied' => $h['satisfied'], 'hot_rate_deck' => $h['rateInDeck'], 'hot_note' => $h['recommend'], 'archive' => 1, 'source' => 'Rapport du focus group du 5 mars 2026', 'is_demo' => 1, 'created_at' => now(), 'updated_at' => now()]);
        foreach ($e['steps'] as $i => $x) DB::insert('vn_steps', ['entity' => 'event', 'entity_id' => $eid, 'position' => $i + 1, 'name' => $x['name'], 'owner' => $x['owner'], 'due' => $x['due'] ?: null, 'status' => $x['status'], 'note' => $x['note'], 'required' => $x['required'] ? 1 : 0]);
        $dir = Files::dir('voc');
        foreach ($e['media'] as $m) {
            if ($m['type'] === 'video/link') { DB::insert('vn_media', ['event_id' => $eid, 'name' => $m['name'], 'kind' => 'link', 'url' => $m['url'], 'original' => 1, 'created_at' => now()]); continue; }
            $src = ROOT . '/database/data/voc/' . basename($m['id']); if (!is_file($src)) continue; @copy($src, $dir . '/' . basename($m['id']));
            DB::insert('vn_media', ['event_id' => $eid, 'name' => $m['name'], 'kind' => 'image', 'stored_name' => basename($m['id']), 'mime' => 'image/webp', 'size' => filesize($src), 'original' => 1, 'created_at' => now()]);
        }
        foreach ($d['focus']['actions'] as $a) DB::insert('vn_actions', ['ref' => $a['id'], 'event_id' => $eid, 'axis' => $a['axis'], 'title' => $a['title'], 'owner' => $a['owner'], 'objective' => $a['objective'], 'due' => $a['due'] ?: null, 'horizon' => $a['horizon'], 'kpi' => $a['kpi'], 'priority' => $a['priority'], 'status' => $a['status'], 'closure' => $a['closure'] ?: null, 'source_note' => $a['sourceNote'], 'is_demo' => 1, 'created_at' => now(), 'updated_at' => now()]);
        // fiches d'exemple : focus group planifié, sortie terrain, dossiers Loop, action liée
        $e2 = DB::insert('vn_events', ['ref' => 'FG-01', 'theme' => 'Validité des forfaits mobile', 'day' => '2026-11-20', 'location' => 'Lomé', 'owner' => 'Coordination VoC', 'target' => 'Clients mobile par value band', 'expected' => 12, 'present' => 0, 'status' => 'Planifié', 'objective' => 'Comparer les besoins selon la value band.', 'archive' => 0, 'is_demo' => 1, 'created_at' => now(), 'updated_at' => now()]);
        foreach (Voc::EVENT_STEPS as $i => [$n, $req]) DB::insert('vn_steps', ['entity' => 'event', 'entity_id' => $e2, 'position' => $i + 1, 'name' => $n, 'status' => 'À faire', 'required' => $req]);
        $ter = DB::insert('vn_field', ['ref' => 'TER-01', 'title' => 'Parcours de paiement Mixx', 'day' => '2026-11-10', 'zone' => 'Maritime', 'owner' => 'Équipe terrain', 'target' => 18, 'completed' => 16, 'stage' => 'CR validé', 'goal' => 'Recueillir les irritants aux points de vente.', 'report' => 'Les clients souhaitent un statut de transaction plus lisible.', 'is_demo' => 1, 'created_at' => now(), 'updated_at' => now()]);
        DB::insert('vn_loop', ['ref' => 'LCF-01', 'source' => 'NPS Yas', 'theme' => 'Consommation et paiement', 'owner' => 'Service client', 'opened' => '2026-11-12', 'due' => '2026-11-16', 'stage' => 'Affecté', 'score' => 4, 'attempts' => 0, 'is_demo' => 1, 'created_at' => now(), 'updated_at' => now()]);
        DB::insert('vn_loop', ['ref' => 'LCF-02', 'source' => 'CSAT Mixx', 'theme' => 'Notification de paiement', 'owner' => 'Support Mixx', 'opened' => '2026-11-08', 'due' => '2026-11-12', 'first_contact' => '2026-11-09', 'closed' => '2026-11-10', 'stage' => 'Clôturé', 'ticket' => 'DÉMO-002', 'score' => 2, 'attempts' => 1, 'result' => 'Résolu · issue communiquée au client.', 'is_demo' => 1, 'created_at' => now(), 'updated_at' => now()]);
        $act = DB::insert('vn_actions', ['ref' => 'ACT-01', 'origin_type' => 'field', 'origin_id' => $ter, 'title' => 'Clarifier la confirmation de paiement', 'owner' => 'Équipe Mixx', 'due' => '2026-11-28', 'kpi' => 'CSAT Notifications et part de notes 1–2', 'priority' => 'Haute', 'status' => 'En cours', 'is_demo' => 1, 'created_at' => now(), 'updated_at' => now()]);
        foreach (Voc::ACTION_STEPS as $i => [$n, $req]) DB::insert('vn_steps', ['entity' => 'action', 'entity_id' => $act, 'position' => $i + 1, 'name' => $n, 'status' => $i ? 'À faire' : 'Terminé', 'required' => $req]);
        if ($own) $pdo->commit(); Voc::flush(); return true;
    }

    /** Retire toutes les données d'exemple (lots, séries, fiches, médias d'origine). */
    static function remove(): void {
        foreach (array_column(DB::all('SELECT id FROM vn_batches WHERE is_demo=1'), 'id') as $b) { DB::exec('DELETE FROM vn_nps WHERE batch_id=?', [$b]); DB::exec('DELETE FROM vn_csat WHERE batch_id=?', [$b]); }
        DB::exec('DELETE FROM vn_batches WHERE is_demo=1');
        foreach (array_column(DB::all('SELECT id FROM vn_series WHERE is_demo=1'), 'id') as $s) DB::exec('DELETE FROM vn_measures WHERE series_id=?', [$s]); DB::exec('DELETE FROM vn_series WHERE is_demo=1');
        foreach (array_column(DB::all('SELECT id FROM vn_events WHERE is_demo=1'), 'id') as $e) self::dropEvent((int)$e);
        foreach (array_column(DB::all('SELECT id FROM vn_actions WHERE is_demo=1'), 'id') as $a) { DB::exec("DELETE FROM vn_steps WHERE entity='action' AND entity_id=?", [$a]); DB::exec("DELETE FROM vn_journal WHERE entity='action' AND entity_id=?", [$a]); }
        DB::exec('DELETE FROM vn_actions WHERE is_demo=1'); DB::exec('DELETE FROM vn_field WHERE is_demo=1'); DB::exec('DELETE FROM vn_loop WHERE is_demo=1'); Voc::flush();
    }
    static function dropEvent(int $e): void {
        foreach (DB::all('SELECT stored_name FROM vn_media WHERE event_id=? AND stored_name IS NOT NULL', [$e]) as $m) @unlink(Files::dir('voc') . '/' . basename($m['stored_name']));
        foreach (array_column(DB::all('SELECT id FROM vn_surveys WHERE event_id=?', [$e]), 'id') as $s) { DB::exec('DELETE FROM vn_answers WHERE reply_id IN (SELECT id FROM vn_replies WHERE survey_id=?)', [$s]); DB::exec('DELETE FROM vn_replies WHERE survey_id=?', [$s]); DB::exec('DELETE FROM vn_questions WHERE survey_id=?', [$s]); }
        DB::exec('DELETE FROM vn_contacts WHERE participant_id IN (SELECT id FROM vn_participants WHERE event_id=?)', [$e]);
        foreach (['vn_surveys', 'vn_participants', 'vn_media'] as $t) DB::exec("DELETE FROM $t WHERE event_id=?", [$e]);
        DB::exec("DELETE FROM vn_steps WHERE entity='event' AND entity_id=?", [$e]); DB::exec("DELETE FROM vn_journal WHERE entity='event' AND entity_id=?", [$e]);
        DB::exec('UPDATE vn_actions SET event_id=NULL WHERE event_id=? AND is_demo=0', [$e]); DB::exec('DELETE FROM vn_events WHERE id=?', [$e]);
    }
}
