<?php
namespace App\Core;
class Csrf {
    static function token(): string { return $_SESSION['_csrf'] ??= bin2hex(random_bytes(24)); }
    static function check(): bool { return isset($_POST['_csrf']) && hash_equals(self::token(), (string)$_POST['_csrf']); }
}
