<?php
namespace App\Core;
/**
 * Diagramme de processus généré à partir des étapes : couloirs par rôle, événements de début et de fin, tâches, décisions (losanges)
 * et renvois (« sinon aller à l'étape n »). Rendu SVG sans script, export BPMN 2.0 (avec mise en page) pour les outils de modélisation.
 */
class PrDiagram {
    const COL = 150; const LANE = 110; const HEAD = 110; const TW = 120; const TH = 56; const DS = 72; const EV = 30;
    const KINDS = ['task' => 'Tâche', 'decision' => 'Décision', 'end' => 'Fin'];

    /** @return array{lanes:array,nodes:array,edges:array,w:int,h:int} */
    static function layout(array $steps): array {
        $lanes = []; $laneOf = function (?string $r) use (&$lanes): int { $r = trim((string)$r) ?: 'Non précisé'; $i = array_search($r, $lanes, true); if ($i === false) { $lanes[] = $r; $i = count($lanes) - 1; } return $i; };
        $nodes = []; $byPos = []; $n = count($steps);
        $firstLane = $n ? $laneOf($steps[0]['role'] ?? null) : 0;
        $nodes[] = ['id' => 'start', 'type' => 'start', 'label' => 'Début', 'col' => 0, 'lane' => $firstLane, 'step' => null];
        foreach ($steps as $i => $s) {
            $k = in_array($s['kind'] ?? 'task', ['task', 'decision', 'end'], true) ? ($s['kind'] ?? 'task') : 'task';
            $nodes[] = ['id' => 's' . $s['id'], 'type' => $k === 'end' ? 'end' : $k, 'label' => $s['position'] . '. ' . $s['label'], 'col' => $i + 1, 'lane' => $laneOf($s['role'] ?? null), 'step' => $s];
            $byPos[(int)$s['position']] = count($nodes) - 1;
        }
        $last = $n ? $steps[$n - 1] : null; $autoEnd = $last && ($last['kind'] ?? 'task') !== 'end';
        if ($autoEnd) $nodes[] = ['id' => 'end', 'type' => 'end', 'label' => 'Fin', 'col' => $n + 1, 'lane' => $nodes[$n]['lane'], 'step' => null];
        $edges = []; $total = count($nodes);
        $edges[] = ['from' => 0, 'to' => $n ? 1 : 0, 'label' => ''];
        foreach ($steps as $i => $s) {
            $idx = $i + 1; $k = $nodes[$idx]['type']; if ($k === 'end') continue;
            $next = $idx + 1 < $total ? $idx + 1 : null; $goto = isset($s['goto_pos']) && $s['goto_pos'] !== null && isset($byPos[(int)$s['goto_pos']]) ? $byPos[(int)$s['goto_pos']] : null;
            if ($k === 'decision') {
                if ($next !== null) $edges[] = ['from' => $idx, 'to' => $next, 'label' => 'oui'];
                if ($goto !== null) $edges[] = ['from' => $idx, 'to' => $goto, 'label' => (string)($s['goto_label'] ?: 'non')];
            } else { $t = $goto ?? $next; if ($t !== null) $edges[] = ['from' => $idx, 'to' => $t, 'label' => $goto !== null ? (string)($s['goto_label'] ?? '') : '']; }
        }
        if (!$lanes) $lanes[] = 'Non précisé';
        $L = count($lanes); $W = self::HEAD + ($total + 1) * self::COL; $laneBottom = $L * self::LANE;
        foreach ($nodes as &$nd) {
            [$w, $h] = match ($nd['type']) { 'start', 'end' => [self::EV, self::EV], 'decision' => [self::DS, self::DS], default => [self::TW, self::TH] };
            $nd['w'] = $w; $nd['h'] = $h; $nd['cx'] = self::HEAD + $nd['col'] * self::COL + self::COL / 2; $nd['cy'] = $nd['lane'] * self::LANE + self::LANE / 2; $nd['x'] = $nd['cx'] - $w / 2; $nd['y'] = $nd['cy'] - $h / 2;
        } unset($nd);
        $chan = 0;
        foreach ($edges as &$e) {
            $a = $nodes[$e['from']]; $b = $nodes[$e['to']]; $diff = $b['col'] - $a['col'];
            if ($diff === 1 && $a['lane'] === $b['lane']) $pts = [[$a['x'] + $a['w'], $a['cy']], [$b['x'], $b['cy']]];
            elseif ($diff === 1) { $mx = $b['x'] - 14; $pts = [[$a['x'] + $a['w'], $a['cy']], [$mx, $a['cy']], [$mx, $b['cy']], [$b['x'], $b['cy']]]; }
            else { $yb = $laneBottom + 16 + 10 * $chan++; $pts = [[$a['cx'], $a['y'] + $a['h']], [$a['cx'], $yb], [$b['cx'], $yb], [$b['cx'], $b['y'] + $b['h']]]; }
            $e['points'] = $pts;
        } unset($e);
        return ['lanes' => $lanes, 'nodes' => $nodes, 'edges' => $edges, 'w' => (int)$W, 'h' => (int)($laneBottom + 30 + 10 * $chan)];
    }
    private static function wrap(string $t, int $max, int $lines): array {
        $words = preg_split('/\s+/u', trim($t)) ?: []; $out = []; $cur = '';
        foreach ($words as $w) { if (mb_strlen($w) > $max) $w = mb_substr($w, 0, $max - 1) . '…'; if ($cur !== '' && mb_strlen($cur . ' ' . $w) > $max) { $out[] = $cur; $cur = $w; } else $cur = ltrim($cur . ' ' . $w); }
        if ($cur !== '') $out[] = $cur; if (count($out) > $lines) { $out = array_slice($out, 0, $lines); $out[$lines - 1] = rtrim(mb_substr($out[$lines - 1], 0, max(1, $max - 1))) . '…'; } return $out;
    }
    /** @param array<int,string> $links  url d'édition par identifiant d'étape (facultatif) */
    static function svg(array $steps, array $links = []): string {
        $g = self::layout($steps); $W = $g['w']; $H = $g['h']; $o = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $W . ' ' . $H . '" width="' . $W . '" height="' . $H . '" role="img" aria-label="Diagramme du processus" font-family="system-ui,Arial,sans-serif" font-size="11">';
        $o .= '<defs><marker id="ar" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#555"/></marker></defs>';
        foreach ($g['lanes'] as $i => $l) { $y = $i * self::LANE; $o .= '<rect x="0" y="' . $y . '" width="' . $W . '" height="' . self::LANE . '" fill="' . ($i % 2 ? '#f8f9fa' : '#fff') . '" stroke="#ccc"/><rect x="0" y="' . $y . '" width="' . self::HEAD . '" height="' . self::LANE . '" fill="#eef1f5" stroke="#ccc"/>';
            foreach (self::wrap($l, 14, 3) as $k => $t) $o .= '<text x="8" y="' . ($y + 24 + $k * 14) . '" font-weight="600" fill="#333">' . e($t) . '</text>'; }
        foreach ($g['edges'] as $ed) {
            $d = ''; foreach ($ed['points'] as $k => [$x, $y]) $d .= ($k ? 'L' : 'M') . round($x, 1) . ' ' . round($y, 1);
            $o .= '<path d="' . $d . '" fill="none" stroke="#555" stroke-width="1.4" marker-end="url(#ar)"/>';
            if ($ed['label'] !== '') { [$lx, $ly] = $ed['points'][1] ?? $ed['points'][0]; $o .= '<text x="' . round($lx + 4, 1) . '" y="' . round($ly - 5, 1) . '" fill="#a33" font-style="italic">' . e(mb_substr($ed['label'], 0, 20)) . '</text>'; }
        }
        foreach ($g['nodes'] as $n) {
            $href = $n['step'] && isset($links[(int)$n['step']['id']]) ? $links[(int)$n['step']['id']] : null; if ($href) $o .= '<a href="' . e($href) . '">';
            if ($n['type'] === 'start' || $n['type'] === 'end') $o .= '<circle cx="' . $n['cx'] . '" cy="' . $n['cy'] . '" r="' . self::EV / 2 . '" fill="' . ($n['type'] === 'start' ? '#e6f4ea' : '#fdecea') . '" stroke="#333" stroke-width="' . ($n['type'] === 'end' ? 3 : 1.4) . '"/>';
            elseif ($n['type'] === 'decision') $o .= '<polygon points="' . $n['cx'] . ',' . $n['y'] . ' ' . ($n['x'] + $n['w']) . ',' . $n['cy'] . ' ' . $n['cx'] . ',' . ($n['y'] + $n['h']) . ' ' . $n['x'] . ',' . $n['cy'] . '" fill="#fff8e1" stroke="#b8860b" stroke-width="1.4"/>';
            else $o .= '<rect x="' . $n['x'] . '" y="' . $n['y'] . '" width="' . $n['w'] . '" height="' . $n['h'] . '" rx="8" fill="#e8f0fe" stroke="#3b6fd4" stroke-width="1.4"/>';
            if ($n['type'] === 'start' || ($n['type'] === 'end' && !$n['step'])) { $o .= '<text x="' . $n['cx'] . '" y="' . ($n['cy'] + 26) . '" text-anchor="middle" fill="#333">' . e($n['label']) . '</text>'; }
            else { $max = $n['type'] === 'decision' ? 12 : 19; $ls = self::wrap($n['label'], $max, $n['type'] === 'decision' ? 3 : 3); $y0 = $n['cy'] - (count($ls) - 1) * 6.5 + 4; if ($n['type'] === 'end') { $y0 = $n['cy'] + 26; $ls = array_slice($ls, 0, 1); }
                foreach ($ls as $k => $t) $o .= '<text x="' . $n['cx'] . '" y="' . round($y0 + $k * 13, 1) . '" text-anchor="middle" fill="#222">' . e($t) . '</text>'; }
            if ($href) $o .= '</a>';
        }
        return $o . '</svg>';
    }
    private static function x(string $s): string { return htmlspecialchars($s, ENT_XML1 | ENT_QUOTES, 'UTF-8'); }
    /** Export BPMN 2.0 (processus, couloirs, passerelles exclusives, flux et mise en page) importable dans un outil de modélisation. */
    static function bpmn(string $name, array $steps): string {
        $g = self::layout($steps); $nm = fn($i) => $g['nodes'][$i]; $id = fn($i) => 'N_' . $i; $ox = 30;
        $x = '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" id="Defs_1" targetNamespace="http://cxo-hub/bpmn">' . "\n";
        $x .= '<bpmn:collaboration id="Collab_1"><bpmn:participant id="Part_1" name="' . self::x($name) . '" processRef="Proc_1"/></bpmn:collaboration>' . "\n" . '<bpmn:process id="Proc_1" isExecutable="false"><bpmn:laneSet id="Lanes_1">';
        foreach ($g['lanes'] as $li => $l) { $x .= '<bpmn:lane id="Lane_' . $li . '" name="' . self::x($l) . '">'; foreach ($g['nodes'] as $ni => $n) if ($n['lane'] === $li) $x .= '<bpmn:flowNodeRef>' . $id($ni) . '</bpmn:flowNodeRef>'; $x .= '</bpmn:lane>'; }
        $x .= '</bpmn:laneSet>';
        $out = []; $in = []; foreach ($g['edges'] as $ei => $e) { $out[$e['from']][] = 'F_' . $ei; $in[$e['to']][] = 'F_' . $ei; }
        foreach ($g['nodes'] as $ni => $n) {
            $tag = match ($n['type']) { 'start' => 'startEvent', 'end' => 'endEvent', 'decision' => 'exclusiveGateway', default => 'task' };
            $x .= '<bpmn:' . $tag . ' id="' . $id($ni) . '" name="' . self::x($n['type'] === 'start' || ($n['type'] === 'end' && !$n['step']) ? '' : $n['label']) . '">';
            foreach ($in[$ni] ?? [] as $f) $x .= '<bpmn:incoming>' . $f . '</bpmn:incoming>'; foreach ($out[$ni] ?? [] as $f) $x .= '<bpmn:outgoing>' . $f . '</bpmn:outgoing>'; $x .= '</bpmn:' . $tag . '>';
        }
        foreach ($g['edges'] as $ei => $e) $x .= '<bpmn:sequenceFlow id="F_' . $ei . '" sourceRef="' . $id($e['from']) . '" targetRef="' . $id($e['to']) . '"' . ($e['label'] !== '' ? ' name="' . self::x($e['label']) . '"' : '') . '/>';
        $x .= '</bpmn:process>' . "\n" . '<bpmndi:BPMNDiagram id="Diag_1"><bpmndi:BPMNPlane id="Plane_1" bpmnElement="Collab_1">';
        $x .= '<bpmndi:BPMNShape id="Part_1_di" bpmnElement="Part_1" isHorizontal="true"><dc:Bounds x="0" y="0" width="' . $g['w'] . '" height="' . (count($g['lanes']) * self::LANE) . '"/></bpmndi:BPMNShape>';
        foreach ($g['lanes'] as $li => $l) $x .= '<bpmndi:BPMNShape id="Lane_' . $li . '_di" bpmnElement="Lane_' . $li . '" isHorizontal="true"><dc:Bounds x="' . $ox . '" y="' . ($li * self::LANE) . '" width="' . ($g['w'] - $ox) . '" height="' . self::LANE . '"/></bpmndi:BPMNShape>';
        foreach ($g['nodes'] as $ni => $n) $x .= '<bpmndi:BPMNShape id="' . $id($ni) . '_di" bpmnElement="' . $id($ni) . '"' . ($n['type'] === 'decision' ? ' isMarkerVisible="true"' : '') . '><dc:Bounds x="' . round($n['x']) . '" y="' . round($n['y']) . '" width="' . $n['w'] . '" height="' . $n['h'] . '"/></bpmndi:BPMNShape>';
        foreach ($g['edges'] as $ei => $e) { $x .= '<bpmndi:BPMNEdge id="F_' . $ei . '_di" bpmnElement="F_' . $ei . '">'; foreach ($e['points'] as [$px, $py]) $x .= '<di:waypoint x="' . round($px) . '" y="' . round($py) . '"/>'; $x .= '</bpmndi:BPMNEdge>'; }
        return $x . '</bpmndi:BPMNPlane></bpmndi:BPMNDiagram></bpmn:definitions>' . "\n";
    }
}
