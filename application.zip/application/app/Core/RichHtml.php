<?php
namespace App\Core;
/** Assainissement du contenu riche (éditeur WYSIWYG) : liste blanche de balises, d'attributs et de styles ; aucune exécution de script possible. */
class RichHtml {
    const TAGS = ['p', 'br', 'h2', 'h3', 'h4', 'strong', 'b', 'em', 'i', 'u', 's', 'strike', 'sub', 'sup', 'ul', 'ol', 'li', 'blockquote', 'a', 'img', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'hr', 'pre', 'code', 'span', 'div', 'figure', 'figcaption', 'video', 'audio', 'iframe', 'mark'];
    const DROP = ['script', 'style', 'object', 'embed', 'form', 'input', 'button', 'select', 'textarea', 'link', 'meta', 'base', 'svg', 'math', 'noscript', 'template', 'frame', 'frameset', 'applet', 'head', 'title'];
    const ATTRS = ['a' => ['href', 'title'], 'img' => ['src', 'alt', 'width', 'height'], 'video' => ['src', 'controls', 'poster', 'width'], 'audio' => ['src', 'controls'], 'iframe' => ['src', 'title', 'allowfullscreen'], 'td' => ['colspan', 'rowspan'], 'th' => ['colspan', 'rowspan'], 'div' => ['class'], 'span' => ['style'], 'p' => ['style'], 'h2' => ['style'], 'h3' => ['style'], 'h4' => ['style'], 'li' => ['style'], 'td2' => []];
    const CLASSES = ['callout callout-info', 'callout callout-warn', 'callout callout-ok', 'callout callout-key', 'el-video', 'el-embed'];
    private static function safeUrl(string $u, bool $media = false): ?string {
        $u = trim(preg_replace('/[\x00-\x1f\x7f]/', '', $u)); if ($u === '') return null;
        if (preg_match('#^/(elearn|rn)/media/[a-f0-9]{32}$#', $u)) return $u;
        if ($media) return null; if (preg_match('#^(https?://|mailto:)[^\s<>"\']+$#i', $u) || preg_match('#^\#[\w-]*$#', $u)) return $u; return null;
    }
    private static function safeStyle(string $s): string {
        $o = []; foreach (explode(';', $s) as $d) { if (!str_contains($d, ':')) continue; [$k, $v] = array_map('trim', explode(':', $d, 2)); $k = strtolower($k);
            if (in_array($k, ['color', 'background-color'], true) && preg_match('/^(#[0-9a-f]{3,8}|rgb\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*\)|[a-z]{3,20})$/i', $v)) $o[] = "$k:$v";
            elseif ($k === 'text-align' && in_array(strtolower($v), ['left', 'right', 'center', 'justify'], true)) $o[] = "$k:" . strtolower($v); }
        return implode(';', $o);
    }
    private static function walk(\DOMNode $n, \DOMDocument $doc): void {
        $kids = []; foreach ($n->childNodes as $c) $kids[] = $c;
        foreach ($kids as $c) {
            if ($c instanceof \DOMComment || $c instanceof \DOMProcessingInstruction) { $n->removeChild($c); continue; }
            if (!($c instanceof \DOMElement)) continue;
            $t = strtolower($c->tagName);
            if (in_array($t, self::DROP, true)) { $n->removeChild($c); continue; }
            if (!in_array($t, self::TAGS, true)) { self::walk($c, $doc); while ($c->firstChild) $n->insertBefore($c->firstChild, $c); $n->removeChild($c); continue; }
            $allowed = self::ATTRS[$t] ?? []; foreach (iterator_to_array($c->attributes) as $a) if (!in_array(strtolower($a->name), $allowed, true)) $c->removeAttribute($a->name);
            foreach (['href' => false, 'src' => true] as $at => $media) if ($c->hasAttribute($at)) {
                $v = $c->getAttribute($at);
                if ($t === 'iframe') { $emb = ELearn::embedUrl($v); if (!$emb) { $n->removeChild($c); continue 2; } $c->setAttribute('src', $emb); $c->setAttribute('allowfullscreen', 'allowfullscreen'); }
                elseif ($t === 'img') { $u = self::safeUrl($v); if (!$u || str_starts_with($u, 'mailto:')) { $n->removeChild($c); continue 2; } $c->setAttribute('src', $u); }
                else { $u = self::safeUrl($v, $media); if (!$u) { if ($t === 'a') $c->removeAttribute('href'); else { $n->removeChild($c); continue 2; } } else $c->setAttribute($at, $u); }
            }
            if ($t === 'iframe' && !$c->hasAttribute('src')) { $n->removeChild($c); continue; }
            if (($t === 'video' || $t === 'audio') && !$c->hasAttribute('src')) { $n->removeChild($c); continue; }
            if ($t === 'video' || $t === 'audio') $c->setAttribute('controls', 'controls');
            if ($t === 'a' && $c->hasAttribute('href')) { $c->setAttribute('rel', 'noopener noreferrer'); $c->setAttribute('target', '_blank'); }
            if ($c->hasAttribute('style')) { $st = self::safeStyle($c->getAttribute('style')); if ($st === '') $c->removeAttribute('style'); else $c->setAttribute('style', $st); }
            if ($c->hasAttribute('class')) { $cl = trim(preg_replace('/\s+/', ' ', $c->getAttribute('class'))); if (in_array($cl, self::CLASSES, true)) $c->setAttribute('class', $cl); else $c->removeAttribute('class'); }
            foreach (['colspan', 'rowspan', 'width', 'height'] as $num) if ($c->hasAttribute($num) && !preg_match('/^\d{1,4}$/', $c->getAttribute($num))) $c->removeAttribute($num);
            self::walk($c, $doc);
        }
    }
    /** HTML assaini (UTF-8). Texte brut sans balise : converti en paragraphes. */
    static function clean(string $html, int $max = 200000): string {
        $html = trim(mb_substr($html, 0, $max)); if ($html === '') return '';
        if (!preg_match('/<[a-z][^>]*>/i', $html)) return self::fromText($html);
        $doc = new \DOMDocument('1.0', 'UTF-8'); $prev = libxml_use_internal_errors(true);
        $doc->loadHTML('<?xml encoding="UTF-8"><div id="__root">' . $html . '</div>', LIBXML_NONET | LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD); libxml_clear_errors(); libxml_use_internal_errors($prev);
        $root = $doc->getElementById('__root'); if (!$root) return self::fromText(strip_tags($html));
        self::walk($root, $doc); $out = ''; foreach ($root->childNodes as $c) $out .= $doc->saveHTML($c);
        return trim(preg_replace('/(<p>\s*(<br\s*\/?>)?\s*<\/p>\s*){3,}/i', '<p><br></p>', $out));
    }
    static function fromText(string $t): string { $o = ''; foreach (preg_split('/\n{2,}/', str_replace("\r", '', trim($t))) as $p) { $p = trim($p); if ($p !== '') $o .= '<p>' . nl2br(e($p), false) . '</p>'; } return $o; }
    /** Rendu pour l'affichage : contenu ancien en texte brut converti ; adresses relatives des médias rattachées au chemin de l'application. */
    static function render(?string $s): string {
        $s = (string)$s; if ($s === '') return ''; if (!preg_match('/<[a-z][^>]*>/i', $s)) $s = self::fromText($s);
        return str_replace(['"/elearn/media/', '"/rn/media/'], ['"' . base_path() . '/elearn/media/', '"' . base_path() . '/rn/media/'], $s);
    }
    static function text(?string $s): string { return trim(preg_replace('/\s+/', ' ', html_entity_decode(strip_tags(str_replace(['</p>', '</li>', '<br>', '</h2>', '</h3>', '</h4>', '</tr>'], ' ', (string)$s)), ENT_QUOTES, 'UTF-8'))); }
    static function hasVideo(?string $s): bool { return (bool)preg_match('/<(video|iframe)\b/i', (string)$s); }
    /** Durée de lecture estimée (minutes, 200 mots/min). */
    static function readMin(?string $s): int { $w = str_word_count(self::text($s), 0, 'àâäçéèêëîïôöùûüÿœÀÉÈ'); return max(1, (int)ceil($w / 200)); }
}
