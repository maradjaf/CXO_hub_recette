<?php
namespace App\Core;
/** Contenu du site web (yas.tg) mis à la disposition de l'assistant : exploration limitée du même domaine ou pages ajoutées à la main. */
final class BotWeb {
    const SKIP = '/\.(pdf|jpe?g|png|gif|webp|svg|ico|css|js|zip|rar|mp4|mp3|docx?|xlsx?|pptx?|xml|json)(\?|$)/i';
    static function fetch(string $url): ?string {
        $c = stream_context_create(['http' => ['method' => 'GET', 'timeout' => 15, 'follow_location' => 1, 'max_redirects' => 3, 'ignore_errors' => true, 'header' => "User-Agent: CXO-Hub-Assistant/1.0\r\nAccept: text/html\r\nAccept-Language: fr\r\n"]]);
        $h = @file_get_contents($url, false, $c, 0, 2000000); if ($h === false) return null;
        $code = 0; foreach ($http_response_header ?? [] as $x) if (preg_match('#^HTTP/\S+ (\d+)#', $x, $m)) $code = (int)$m[1];
        return $code >= 200 && $code < 300 ? $h : null;
    }
    /** Titre, texte lisible et liens d'une page HTML. @return array{title:string,text:string,links:string[]} */
    static function parse(string $html, string $base): array {
        $html = mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'); $d = new \DOMDocument(); libxml_use_internal_errors(true); @$d->loadHTML($html); libxml_clear_errors();
        $links = []; foreach ($d->getElementsByTagName('a') as $a) { $h = trim((string)$a->getAttribute('href')); if ($h !== '' && !preg_match('/^(mailto|tel|javascript|#)/i', $h)) $links[] = self::abs($h, $base); }
        $x = new \DOMXPath($d); foreach ($x->query('//script|//style|//noscript|//nav|//footer|//header|//form|//svg|//iframe') as $n) $n->parentNode?->removeChild($n);
        $title = trim((string)($d->getElementsByTagName('title')->item(0)?->textContent ?? ''));
        $t = $d->getElementsByTagName('body')->item(0)?->textContent ?? ''; $t = trim(preg_replace("/[ \t\xC2\xA0]+/u", ' ', preg_replace("/\n\s*\n+/", "\n", (string)$t)));
        return ['title' => mb_substr(preg_replace('/\s+/u', ' ', $title), 0, 250), 'text' => $t, 'links' => array_values(array_unique(array_filter($links)))];
    }
    static function abs(string $href, string $base): string {
        if (preg_match('#^https?://#i', $href)) return strtok($href, '#');
        $p = parse_url($base); $root = $p['scheme'] . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '');
        if (str_starts_with($href, '//')) return $p['scheme'] . ':' . strtok($href, '#');
        if ($href[0] === '/') return $root . strtok($href, '#');
        $dir = rtrim(dirname($p['path'] ?? '/') === '.' ? '' : dirname($p['path'] ?? '/'), '/'); return $root . $dir . '/' . strtok($href, '#');
    }
    static function save(string $url, string $title, string $text, bool $manual = false): void {
        $text = mb_substr(trim($text), 0, 60000); if ($text === '') return; $h = sha1($url); $row = ['url' => mb_substr($url, 0, 500), 'title' => mb_substr($title, 0, 250), 'body' => $text, 'fetched_at' => now()];
        if ($manual) $row['is_manual'] = 1;
        if (DB::val('SELECT 1 FROM bot_web_pages WHERE url_hash=?', [$h])) DB::update('bot_web_pages', $row, 'url_hash=?', [$h]); else DB::insert('bot_web_pages', $row + ['url_hash' => $h, 'active' => 1]);
    }
    /** Explore le site à partir de $start (même domaine, profondeur 2, $max pages). @return array{pages:int,errors:int,first_error:string} */
    static function sync(string $start, int $max = 40): array {
        $p = parse_url($start); if (!$p || empty($p['host']) || !in_array($p['scheme'] ?? '', ['http', 'https'], true)) return ['pages' => 0, 'errors' => 1, 'first_error' => 'Adresse invalide.'];
        $host = strtolower($p['host']); $queue = [[$start, 0]]; $seen = [$start => 1]; $n = 0; $err = 0; $first = '';
        while ($queue && $n < $max) {
            [$u, $depth] = array_shift($queue); $html = self::fetch($u);
            if ($html === null) { $err++; if ($first === '') $first = 'Page inaccessible : ' . $u; continue; }
            $pg = self::parse($html, $u); self::save($u, $pg['title'], $pg['text']); $n++;
            if ($depth < 2) foreach ($pg['links'] as $l) {
                $lp = parse_url($l); if (!$lp || strtolower($lp['host'] ?? '') !== $host && strtolower($lp['host'] ?? '') !== 'www.' . $host && 'www.' . strtolower($lp['host'] ?? '') !== $host) continue;
                if (preg_match(self::SKIP, $l) || isset($seen[$l]) || count($seen) > $max * 4) continue; $seen[$l] = 1; $queue[] = [$l, $depth + 1];
            }
        }
        return ['pages' => $n, 'errors' => $err, 'first_error' => $first];
    }
}
