<?php
namespace App\Core;
/** Cycle de vie des contrats : création (unitaire, en masse, renouvellement, avenant), rédaction, signataires automatiques, envoi en signature, activation. */
final class CtFlow {
    const KIND = ['new' => 'Nouveau contrat', 'renewal' => 'Renouvellement', 'amendment' => 'Avenant'];
    const STATUS = ['active' => 'En cours', 'ended' => 'Clos', 'planned' => 'Prévu (en attente de signature)', 'applied' => 'Avenant appliqué'];
    const STATUS_COLOR = ['active' => 'success', 'ended' => 'secondary', 'planned' => 'info', 'applied' => 'success'];

    /** Modèle actif le mieux adapté : celui du type de contrat, sinon un modèle générique ; pour un avenant, celui dont le nom évoque l'avenant. */
    static function bestTemplate(string $type, string $kind = 'new'): ?array {
        if ($kind === 'amendment') { $t = DB::one("SELECT * FROM ct_templates WHERE active=1 AND (name LIKE '%venant%') ORDER BY id LIMIT 1"); if ($t) return $t; }
        return DB::one('SELECT * FROM ct_templates WHERE active=1 AND type=? ORDER BY id LIMIT 1', [$type]) ?: DB::one("SELECT * FROM ct_templates WHERE active=1 AND (type IS NULL OR type='') AND name NOT LIKE '%venant%' ORDER BY id LIMIT 1") ?: DB::one('SELECT * FROM ct_templates WHERE active=1 ORDER BY id LIMIT 1');
    }
    /** Variables supplémentaires saisies sous forme « clé=valeur » (une par ligne). */
    static function parseVars(string $txt): array {
        $o = []; foreach (preg_split('/\R/u', $txt) as $l) if (preg_match('/^\s*\{?\{?\s*([a-z0-9_]{1,40})\s*\}?\}?\s*[=:]\s*(.+)$/iu', $l, $m)) $o[strtolower($m[1])] = mb_substr(trim($m[2]), 0, 300); return $o;
    }
    /** Signataires automatiques : le responsable de la société employeuse (à défaut l'utilisateur connecté), puis le collaborateur. */
    static function autoSigners(array $c): array {
        DB::exec('DELETE FROM ct_signers WHERE contract_id=?', [(int)$c['id']]);
        $e = DB::one('SELECT e.*, (SELECT u.email FROM users u WHERE u.employee_id=e.id LIMIT 1) user_email FROM employees e WHERE e.id=?', [(int)$c['employee_id']]) ?: [];
        $co = DB::one('SELECT * FROM employers WHERE code=?', [(string)Ct::employerCode($c, $e)]) ?: [];
        $me = Auth::user() ?: []; $missing = [];
        $pos = 0;
        if (!empty($co['head_email'])) { DB::insert('ct_signers', ['contract_id' => (int)$c['id'], 'role' => 'Employeur', 'name' => (string)($co['head_name'] ?: $co['name']), 'email' => strtolower($co['head_email']), 'position' => ++$pos, 'token' => Ct::token(), 'status' => 'pending']); }
        elseif (!empty($me['email'])) { DB::insert('ct_signers', ['contract_id' => (int)$c['id'], 'role' => 'Employeur', 'name' => (string)$me['name'], 'email' => strtolower($me['email']), 'position' => ++$pos, 'token' => Ct::token(), 'status' => 'pending']); }
        else $missing[] = 'employeur';
        $em = strtolower(trim((string)($e['email'] ?: ($e['user_email'] ?? ''))));
        if ($em !== '') DB::insert('ct_signers', ['contract_id' => (int)$c['id'], 'role' => 'Collaborateur', 'name' => trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '')), 'email' => $em, 'position' => ++$pos, 'token' => Ct::token(), 'status' => 'pending']);
        else $missing[] = 'collaborateur';
        return $missing;
    }
    /** Rédige le document depuis un modèle (variables connues + $extra) et prépare les signataires. Retourne les signataires sans e-mail (miss) et les variables restées vides (blank). */
    static function draft(array $c, array $tpl, array $extra = []): array {
        $e = DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [(int)$c['employee_id']]) ?: ['first_name' => '', 'last_name' => ''];
        $vals = Ct::values($c); foreach ($extra as $k => $v) if (trim((string)$v) !== '') $vals[strtolower((string)$k)] = (string)$v;
        if (trim((string)($vals['lieu'] ?? '')) === '') $vals['lieu'] = (string)setting('company_city', 'Lomé');
        $blank = array_values(array_filter(Ct::placeholders((string)$tpl['body']), fn($k) => trim((string)($vals[$k] ?? '')) === ''));
        $body = Ct::render((string)$tpl['body'], $vals);
        DB::update('contracts', ['template_id' => (int)$tpl['id'], 'title' => $tpl['name'] . ' - ' . $e['first_name'] . ' ' . mb_strtoupper($e['last_name']), 'body' => $body, 'doc_status' => 'draft', 'verify_code' => null, 'doc_hash' => null, 'sent_at' => null, 'signed_at' => null], 'id=?', [(int)$c['id']]);
        return ['miss' => self::autoSigners($c), 'blank' => $blank];
    }
    static function notify(int $sid, array $c, bool $reminder = false): bool {
        $s = DB::one('SELECT * FROM ct_signers WHERE id=?', [$sid]); if (!$s || $s['status'] === 'signed') return false;
        $link = Ct::abs('sign/c/' . $s['token']); $co = (string)setting('company_name', (string)setting('app.name', 'CXO Excellence Hub'));
        $txt = "Bonjour {$s['name']},\n\n" . ($reminder ? 'Rappel : ' : '') . "le document « {$c['title']} » vous attend pour signature électronique ({$s['role']}).\n\nOuvrez votre lien personnel, relisez le document puis signez ou refusez :\n$link\n\nVous pouvez aussi le retrouver dans « Mes contrats » sur votre tableau de bord.\nCe lien est personnel : ne le transmettez pas.\n\n$co";
        $ok = Ct::mail($s['email'], ($reminder ? 'Rappel - ' : '') . 'Signature demandée : ' . $c['title'], $txt);
        DB::update('ct_signers', ['notified_at' => now()], 'id=?', [$sid]);
        if ($uid = DB::val('SELECT id FROM users WHERE LOWER(email)=? LIMIT 1', [strtolower($s['email'])])) Notifier::send((int)$uid, 'Contrat à signer', '« ' . $c['title'] . ' » attend votre signature.', '/my/contracts');
        return $ok;
    }
    /** Envoie en signature : passe le contrat en « En signature » et prévient chaque signataire. Retourne [e-mails envoyés, signataires]. */
    static function send(array $c): array {
        $sg = Ct::signers((int)$c['id']); $code = $c['verify_code'] ?: strtoupper(bin2hex(random_bytes(6))); $c['title'] = (string)$c['title'];
        DB::update('contracts', ['doc_status' => 'to_sign', 'verify_code' => $code, 'doc_hash' => Ct::hash($c), 'sent_at' => now()], 'id=?', [(int)$c['id']]);
        $sent = 0; foreach ($sg as $s) if (self::notify((int)$s['id'], $c)) $sent++;
        return [$sent, count($sg)];
    }
    /** Crée un contrat (nouveau, renouvellement ou avenant), rédige le document et l'envoie si demandé. Retourne [id, état] avec état = sent|draft|incomplete|nosigner. */
    static function create(int $emp, string $type, string $start, ?string $end, ?array $tpl, string $kind = 'new', ?int $parent = null, bool $send = false, array $extra = [], ?string $note = null): array {
        $e = DB::one('SELECT employer FROM employees WHERE id=?', [$emp]); if (!$e) return [0, 'error'];
        $active = (int)DB::val("SELECT COUNT(*) FROM contracts WHERE employee_id=? AND status='active'", [$emp]);
        $status = ($kind === 'new' && !$active) ? 'active' : 'planned';
        $id = DB::insert('contracts', ['employee_id' => $emp, 'type' => $type, 'start_date' => $start, 'end_date' => $end ?: null, 'status' => $status, 'notes' => $note, 'created_by' => Auth::id(), 'created_at' => now(), 'kind' => $kind, 'parent_id' => $parent, 'employer_code' => $e['employer'] ?: null, 'doc_status' => 'none']);
        if ($status === 'active') DB::update('employees', ['contract_type' => $type, 'updated_at' => now()], 'id=?', [$emp]);
        Audit::log('create', 'contract', $id, null, ['kind' => $kind, 'employee' => $emp, 'start' => $start, 'end' => $end]);
        if (!$tpl) return [$id, 'nodoc'];
        $c = DB::one('SELECT * FROM contracts WHERE id=?', [$id]); $dr = self::draft($c, $tpl, $extra); $miss = $dr['miss'];
        if (!$send) return [$id, 'draft'];
        $c = DB::one('SELECT * FROM contracts WHERE id=?', [$id]);
        if ($miss) return [$id, 'nosigner'];
        if ($dr['blank']) return [$id, 'incomplete'];
        self::send($c); return [$id, 'sent'];
    }
    /** Active un contrat prévu (renouvellement ou nouveau) en clôturant l'ancien, ou applique un avenant au contrat d'origine. */
    static function activate(int $id): bool {
        $c = DB::one('SELECT * FROM contracts WHERE id=?', [$id]); if (!$c || $c['status'] !== 'planned') return false;
        if ($c['kind'] === 'amendment') {
            if ($c['parent_id']) { $p = DB::one('SELECT * FROM contracts WHERE id=?', [(int)$c['parent_id']]); if ($p) { $upd = ['end_date' => $c['end_date'] ?: $p['end_date']]; if ($p['status'] === 'ended' && $c['end_date'] && $c['end_date'] >= date('Y-m-d')) $upd['status'] = 'active'; DB::update('contracts', $upd, 'id=?', [(int)$p['id']]); Audit::log('amend', 'contract', $p['id'], $p, $upd); } }
            DB::update('contracts', ['status' => 'applied'], 'id=?', [$id]); return true;
        }
        foreach (DB::all("SELECT * FROM contracts WHERE employee_id=? AND status='active' AND id<>?", [(int)$c['employee_id'], $id]) as $o)
            DB::update('contracts', ['status' => 'ended', 'end_date' => $o['end_date'] && $o['end_date'] < $c['start_date'] ? $o['end_date'] : date('Y-m-d', strtotime($c['start_date'] . ' -1 day'))], 'id=?', [(int)$o['id']]);
        DB::update('contracts', ['status' => 'active'], 'id=?', [$id]); DB::update('employees', ['contract_type' => $c['type'], 'updated_at' => now()], 'id=?', [(int)$c['employee_id']]);
        Audit::log('activate', 'contract', $id, null, ['kind' => $c['kind']]); return true;
    }
    /** Contrats de l'utilisateur connecté : à signer, et les siens (copie téléchargeable). */
    static function mine(): array {
        $u = Auth::user() ?: []; $mail = strtolower((string)($u['email'] ?? '')); $emp = (int)($u['employee_id'] ?? 0);
        $sign = $mail === '' ? [] : DB::all("SELECT s.token, s.role, c.id, c.title, c.sent_at FROM ct_signers s JOIN contracts c ON c.id=s.contract_id WHERE LOWER(s.email)=? AND s.status='pending' AND c.doc_status='to_sign' ORDER BY c.sent_at DESC LIMIT 50", [$mail]);
        $own = $emp ? DB::all("SELECT id, title, doc_status, start_date, end_date, kind, signed_at FROM contracts WHERE employee_id=? AND doc_status IN ('to_sign','signed') ORDER BY id DESC LIMIT 50", [$emp]) : [];
        return ['sign' => $sign, 'own' => $own];
    }
}
