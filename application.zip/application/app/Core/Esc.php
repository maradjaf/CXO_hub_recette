<?php
namespace App\Core;
/** Ticketing ITIL : canaux, matrice impact × urgence, niveaux de support (N1/N2/N3), escalades fonctionnelle / hiérarchique / prestataire / opérateur-métier, relances. */
class Esc {
    const CHANNEL = ['portal' => 'Portail', 'email' => 'E-mail', 'phone' => 'Téléphone', 'walkin' => 'Sur place', 'chat' => 'Chat', 'chatbot' => 'Assistant (chatbot)', 'system' => 'Système', 'other' => 'Autre'];
    const SELF_CHANNELS = ['portal', 'chatbot'];                       // canaux qu'un demandeur simple peut déclarer lui-même
    const LEVEL = [0 => 'Aucune', 1 => 'N+1', 2 => 'N+2', 3 => 'Direction'];
    const IMPACT = ['high' => 'Élevé (plusieurs personnes / un service)', 'medium' => 'Moyen (une équipe)', 'low' => 'Faible (une personne)'];
    const URGENCY = ['high' => 'Élevée (bloquant, pas de contournement)', 'medium' => 'Moyenne (gênant)', 'low' => 'Faible (peut attendre)'];
    const MATRIX = ['high|high' => 'critical', 'high|medium' => 'high', 'high|low' => 'normal', 'medium|high' => 'high', 'medium|medium' => 'normal', 'medium|low' => 'low', 'low|high' => 'normal', 'low|medium' => 'low', 'low|low' => 'low'];

    static function matrix(): array {
        $j = json_decode((string)setting('at.matrix', ''), true); $m = self::MATRIX;
        if (is_array($j)) foreach ($j as $k => $v) if (isset($m[$k]) && isset(Tickets::PRIO[$v])) $m[$k] = $v;
        return $m;
    }
    static function priority(?string $impact, ?string $urgency): ?string {
        if (!isset(self::IMPACT[$impact ?? '']) || !isset(self::URGENCY[$urgency ?? ''])) return null; return self::matrix()[$impact . '|' . $urgency];
    }
    /** Groupe de résolution N1 par défaut pour une catégorie. */
    static function route(?string $category): ?int {
        foreach (DB::all("SELECT id, categories FROM at_groups WHERE active=1 AND tier=1 ORDER BY id") as $g)
            if ($category && $g['categories'] && in_array($category, array_map('trim', explode(',', $g['categories'])), true)) return (int)$g['id'];
        $d = DB::val("SELECT id FROM at_groups WHERE active=1 AND tier=1 ORDER BY id LIMIT 1"); return $d ? (int)$d : null;
    }
    static function groupUsers(int $groupId): array {
        $ids = array_map('intval', array_column(DB::all("SELECT m.user_id id FROM at_group_members m JOIN users u ON u.id=m.user_id WHERE m.group_id=? AND u.status='active'", [$groupId]), 'id'));
        $l = DB::val("SELECT u.id FROM at_groups g JOIN users u ON u.id=g.lead_user_id WHERE g.id=? AND u.status='active'", [$groupId]); if ($l) $ids[] = (int)$l; return array_values(array_unique($ids));
    }
    /** Responsable hiérarchique (compte actif) d'un utilisateur. */
    static function managerOf(?int $userId): ?int {
        if (!$userId) return null; $e = (int)DB::val('SELECT employee_id FROM users WHERE id=?', [$userId]); if (!$e) return null;
        $m = (int)DB::val('SELECT manager_id FROM employees WHERE id=?', [$e]); if (!$m) return null;
        $u = DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [$m]); return $u ? (int)$u : null;
    }
    /** Destinataires d'un niveau d'escalade hiérarchique : 1 = N+1 de l'agent (à défaut chef de groupe), 2 = N+2, 3 = direction (droit at.manage). */
    static function levelRecipients(array $t, int $level): array {
        $base = $t['assignee_id'] ? (int)$t['assignee_id'] : null; $out = [];
        if ($level >= 1) { $m1 = self::managerOf($base); if (!$m1 && $t['group_id']) { $l = DB::val('SELECT lead_user_id FROM at_groups WHERE id=?', [(int)$t['group_id']]); $m1 = $l ? (int)$l : null; } if ($m1) $out[] = $m1; }
        if ($level >= 2) { $m1 = $out[0] ?? null; $m2 = self::managerOf($m1); if ($m2) $out[] = $m2; }
        if ($level >= 3 || !$out) foreach (DB::all("SELECT DISTINCT ur.user_id id FROM user_roles ur JOIN roles r ON r.id=ur.role_id LEFT JOIN role_permissions rp ON rp.role_id=r.id LEFT JOIN permissions p ON p.id=rp.permission_id JOIN users u ON u.id=ur.user_id WHERE u.status='active' AND (r.code='admin' OR p.code='at.manage')") as $r) $out[] = (int)$r['id'];
        return array_values(array_unique($out));
    }
    static function log(int $tid, string $kind, array $f = []): int {
        return DB::insert('at_escalations', ['ticket_id' => $tid, 'kind' => $kind, 'created_by' => Auth::id(), 'created_at' => now(), 'auto' => 0] + $f);
    }
    static function notify(array $userIds, array $t, string $title, string $body): void {
        foreach (array_unique(array_map('intval', $userIds)) as $u) if ($u && $u !== (int)Auth::id()) Notifier::send($u, $title, $body, '/at/' . $t['id']);
    }
    /** Résumé du ticket envoyé aux contacts externes (aucune pièce jointe, aucune note interne). */
    static function summary(array $t, string $message): string {
        $app = (string)env('APP_URL', '');
        return "Référence : {$t['reference']}\nObjet : {$t['title']}\nCatégorie : " . ($t['category'] ?: '—') . "\nPriorité : " . (Tickets::PRIO[$t['priority']] ?? $t['priority']) . "\nCréé le : " . dt($t['created_at']) . "\n\nDescription :\n" . mb_substr((string)$t['description'], 0, 1500) . "\n\nDemande :\n$message\n\nMerci de répondre à ce message en conservant la référence {$t['reference']} dans l'objet.";
    }
    /** Pourcentage du délai de résolution consommé. */
    static function pct(array $t): int {
        if (!$t['due_at']) return 0; $total = max(1, strtotime($t['due_at']) - strtotime($t['created_at'])); return (int)round((time() - strtotime($t['created_at'])) / $total * 100);
    }
    /** Moteur automatique : escalade hiérarchique selon les règles, alerte de prise en charge manquée, relance prestataire. Retourne [escalades, alertes, relances]. */
    static function run(): array {
        $esc = 0; $al = 0; $rel = 0; $now = now();
        $rules = []; foreach (DB::all('SELECT * FROM at_esc_rules WHERE active=1 ORDER BY level') as $r) $rules[$r['priority']][] = $r;
        foreach (DB::all("SELECT * FROM at_tickets WHERE status IN ('new','assigned','in_progress') AND due_at IS NOT NULL") as $t) {
            $pct = self::pct($t); $target = (int)$t['esc_level'];
            foreach ($rules[$t['priority']] ?? [] as $r) if ($pct >= (int)$r['threshold_pct'] && (int)$r['level'] > $target) $target = (int)$r['level'];
            if ($target > (int)$t['esc_level']) {
                $to = self::levelRecipients($t, $target); DB::update('at_tickets', ['esc_level' => $target], 'id=?', [(int)$t['id']]);
                DB::insert('at_escalations', ['ticket_id' => (int)$t['id'], 'kind' => 'hierarchical', 'level' => $target, 'reason' => "Délai consommé à $pct % (règle automatique)", 'auto' => 1, 'created_at' => $now]);
                Tickets::event((int)$t['id'], 'escalation', 'Escalade hiérarchique automatique : ' . self::LEVEL[$target] . ' (' . $pct . ' % du délai).');
                foreach ($to as $u) Notifier::send($u, 'Escalade ' . self::LEVEL[$target] . ' : ' . $t['reference'], $t['title'] . ' — ' . $pct . ' % du délai consommé', '/at/' . $t['id']); $esc++;
            }
        }
        foreach (DB::all("SELECT * FROM at_tickets WHERE status IN ('new','assigned') AND first_response_at IS NULL AND response_due IS NOT NULL AND response_due<? AND response_alerted_at IS NULL", [$now]) as $t) {
            $to = $t['group_id'] ? self::groupUsers((int)$t['group_id']) : []; if (!$to) $to = self::levelRecipients($t + ['assignee_id' => null], 1);
            foreach ($to as $u) Notifier::send($u, 'Prise en charge en retard : ' . $t['reference'], $t['title'], '/at/' . $t['id']);
            DB::update('at_tickets', ['response_alerted_at' => $now], 'id=?', [(int)$t['id']]); Tickets::event((int)$t['id'], 'sla', 'Délai de première prise en charge dépassé : alerte envoyée.'); $al++;
        }
        $days = max(1, (int)setting('at.ext_days', 3));
        foreach (DB::all("SELECT * FROM at_tickets WHERE ext_status='open' AND ext_followup_at IS NOT NULL AND ext_followup_at<? AND status IN ('new','assigned','in_progress','waiting')", [$now]) as $t) {
            $to = array_filter([(int)$t['assignee_id'] ?: null] + [1 => $t['group_id'] ? (int)DB::val('SELECT lead_user_id FROM at_groups WHERE id=?', [(int)$t['group_id']]) : null]);
            foreach ($to as $u) Notifier::send((int)$u, 'Relance prestataire à faire : ' . $t['reference'], 'Sans retour du prestataire depuis le ' . dt($t['ext_since']) . ' (réf. ' . ($t['ext_ref'] ?: '—') . ').', '/at/' . $t['id']);
            DB::update('at_tickets', ['ext_followup_at' => date('Y-m-d H:i:s', time() + $days * 86400)], 'id=?', [(int)$t['id']]);
            DB::insert('at_escalations', ['ticket_id' => (int)$t['id'], 'kind' => 'reminder', 'supplier_id' => $t['ext_supplier_id'], 'reason' => 'Relance à effectuer (sans retour du prestataire)', 'auto' => 1, 'created_at' => $now]); $rel++;
        }
        return [$esc, $al, $rel];
    }
    /** Filet de sécurité (comme les rappels qualité) : au plus toutes les 30 min, après l'envoi de la réponse. */
    static function lazyRun(): void {
        if (PHP_SAPI === 'cli' || Request::method() !== 'GET') return;
        if (time() - (int)strtotime((string)setting('at.esc_last', '2000-01-01')) < 1800) return;
        Settings::set('at.esc_last', now());
        register_shutdown_function(function () { if (function_exists('fastcgi_finish_request')) @fastcgi_finish_request(); try { self::run(); } catch (\Throwable $e) {} });
    }
}
