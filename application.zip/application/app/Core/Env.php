<?php
namespace App\Core;
class Env {
    private static array $v = [];
    static function load(string $f): void {
        if (!is_file($f)) return;
        foreach (file($f, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $l) {
            $l = trim($l);
            if ($l === '' || $l[0] === '#' || !str_contains($l, '=')) continue;
            [$k, $x] = explode('=', $l, 2);
            self::$v[trim($k)] = trim(trim($x), "\"'");
        }
    }
    static function get(string $k, $d = null) { $e = getenv($k); return $e !== false ? $e : (self::$v[$k] ?? $d); }
    static function set(string $k, string $v): void { self::$v[$k] = $v; }
}
