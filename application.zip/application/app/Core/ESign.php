<?php
namespace App\Core;

/**
 * Signature électronique simple : le signataire confirme avec son mot de passe ; l'empreinte du document, la date,
 * l'adresse IP et son paraphe dessiné sont conservés. Ce n'est pas une signature qualifiée (pas de certificat).
 */
final class ESign {
    static function pad(int $uid): ?string { $v = DB::val('SELECT image FROM esign_pads WHERE user_id=?', [$uid]); return $v ? (string)$v : null; }
    static function savePad(int $uid, string $img): bool {
        if (!preg_match('#^data:image/png;base64,[A-Za-z0-9+/=]+$#', $img) || strlen($img) > 200000) return false;
        if (DB::val('SELECT 1 FROM esign_pads WHERE user_id=?', [$uid])) DB::update('esign_pads', ['image' => $img, 'updated_at' => now()], 'user_id=?', [$uid]);
        else DB::insert('esign_pads', ['user_id' => $uid, 'image' => $img, 'updated_at' => now()]);
        return true;
    }
    static function ask(string $type, int $doc, string $kind, string $role, int $uid, int $pos = 0): int {
        return (int)DB::insert('esign', ['doc_type' => $type, 'doc_id' => $doc, 'kind' => $kind, 'role' => mb_substr($role, 0, 80), 'position' => $pos, 'user_id' => $uid, 'status' => 'pending', 'created_at' => now()]);
    }
    static function rows(string $type, int $doc): array {
        return DB::all('SELECT s.*, u.name uname, p.image pad FROM esign s LEFT JOIN users u ON u.id=s.user_id LEFT JOIN esign_pads p ON p.user_id=s.user_id WHERE s.doc_type=? AND s.doc_id=? ORDER BY s.position, s.id', [$type, $doc]);
    }
    static function clear(string $type, int $doc): void { DB::exec('DELETE FROM esign WHERE doc_type=? AND doc_id=?', [$type, $doc]); }
    static function mine(string $type, int $doc, ?string $kind = null): ?array {
        $r = DB::one("SELECT * FROM esign WHERE doc_type=? AND doc_id=? AND user_id=? AND status='pending'" . ($kind ? ' AND kind=?' : '') . ' ORDER BY position, id LIMIT 1', $kind ? [$type, $doc, Auth::id(), $kind] : [$type, $doc, Auth::id()]);
        return $r ?: null;
    }
    static function left(string $type, int $doc, ?string $kind = null): int {
        return (int)DB::val("SELECT COUNT(*) FROM esign WHERE doc_type=? AND doc_id=? AND status='pending'" . ($kind ? ' AND kind=?' : ''), $kind ? [$type, $doc, $kind] : [$type, $doc]);
    }
    /** Vérifie le mot de passe du signataire connecté. */
    static function confirm(string $password): bool { $u = Auth::user(); return $u && $password !== '' && password_verify($password, (string)$u['password_hash']); }
    static function sign(int $id, string $hash, string $comment = ''): void {
        DB::update('esign', ['status' => 'signed', 'signed_at' => now(), 'doc_hash' => $hash, 'ip' => mb_substr((string)Request::ip(), 0, 45), 'comment' => mb_substr($comment, 0, 500) ?: null], 'id=?', [$id]);
    }
    static function reject(int $id, string $comment): void {
        DB::update('esign', ['status' => 'rejected', 'signed_at' => now(), 'ip' => mb_substr((string)Request::ip(), 0, 45), 'comment' => mb_substr($comment, 0, 500)], 'id=?', [$id]);
    }
    static function code(): string { return strtoupper(bin2hex(random_bytes(6))); }
    /** Utilisateurs actifs disposant d'un droit. */
    static function usersWith(string $perm): array {
        return DB::all("SELECT DISTINCT u.id, u.name FROM users u JOIN user_roles ur ON ur.user_id=u.id JOIN roles r ON r.id=ur.role_id LEFT JOIN role_permissions rp ON rp.role_id=r.id LEFT JOIN permissions p ON p.id=rp.permission_id WHERE u.status='active' AND (p.code=? OR r.code='admin') ORDER BY u.name", [$perm]);
    }
    /** Nettoie un texte riche saisi (gras, italique, listes, paragraphes, tableaux simples). */
    static function clean(string $html): string {
        $html = strip_tags($html, '<p><br><b><strong><i><em><u><ul><ol><li><table><thead><tbody><tr><td><th><h3><h4>');
        return (string)preg_replace('/<(\/?)(\w+)[^>]*>/', '<$1$2>', $html);
    }
    /** Texte simple → paragraphes HTML (lignes commençant par « - » = puces). */
    static function toHtml(string $txt): string {
        if (preg_match('/<(p|ul|ol|br|table)\b/i', $txt)) return self::clean($txt);
        $out = ''; $li = [];
        $flush = function () use (&$out, &$li) { if ($li) { $out .= '<ul><li>' . implode('</li><li>', $li) . '</li></ul>'; $li = []; } };
        foreach (preg_split('/\R/', trim($txt)) as $l) { $l = trim($l); if ($l === '') { $flush(); continue; }
            if (preg_match('/^[-•*]\s+(.*)$/u', $l, $m)) $li[] = e($m[1]); else { $flush(); $out .= '<p>' . e($l) . '</p>'; } }
        $flush(); return $out;
    }
}
