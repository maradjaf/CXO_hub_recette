<?php
namespace App\Core;
class View {
    static function render(string $view, array $data = [], string $layout = 'layout/main'): void {
        $content = self::partial($view, $data);
        echo self::partial($layout, $data + ['content' => $content]);
    }
    static function partial(string $view, array $data = []): string {
        extract($data, EXTR_SKIP);
        ob_start();
        require ROOT . '/app/Views/' . $view . '.php';
        return ob_get_clean();
    }
}
