<?php
namespace App\Core;
/** Identité visuelle des documents (contrats, attestations) : logo, en-tête et pied de page, par société employeuse ou par défaut (réglages). Images converties en JPEG. */
final class Brand {
    const SUB = 'brand';
    /** Enregistre une image envoyée (JPEG, PNG, WebP, GIF) convertie en JPEG sur fond blanc ; retourne [nom|null, erreur|null]. */
    static function store(?array $f, int $maxW = 900): array {
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return [null, null];
        if ($f['error'] !== UPLOAD_ERR_OK || $f['size'] > 4 * 1048576) return [null, 'Image refusée : 4 Mo au plus.'];
        $info = @getimagesize($f['tmp_name']); $t = $info[2] ?? 0;
        $src = match ($t) { IMAGETYPE_JPEG => @imagecreatefromjpeg($f['tmp_name']), IMAGETYPE_PNG => @imagecreatefrompng($f['tmp_name']), IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($f['tmp_name']) : false, IMAGETYPE_GIF => @imagecreatefromgif($f['tmp_name']), default => false };
        if (!$src) return [null, 'Image refusée : JPEG, PNG, WebP ou GIF uniquement.'];
        $w = imagesx($src); $h = imagesy($src); $nw = min($w, $maxW); $nh = (int)round($h * $nw / $w);
        $dst = imagecreatetruecolor($nw, $nh); imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255)); imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
        ob_start(); imagejpeg($dst, null, 88); $b = (string)ob_get_clean();
        $s = Files::put(self::SUB, $b, 'jpg'); return $s ? [$s, null] : [null, 'Image non enregistrée.'];
    }
    /** Adresse publique d'une image (sans extension, pour fonctionner derrière tout serveur web). */
    static function url(string $stored): string { return url('brand/' . preg_replace('/\.jpg$/', '', $stored)); }
    static function path(?string $stored): ?string { if (!$stored || !preg_match('/^[a-f0-9]{32}\.jpg$/', $stored)) return null; $p = Files::dir(self::SUB) . '/' . $stored; return is_file($p) ? $p : null; }
    static function drop(?string $stored, string $exceptTable = '', int $exceptId = 0): void {
        if (!$stored || !self::path($stored)) return;
        foreach ([['employers', 'logo'], ['employers', 'header_img'], ['employers', 'footer_img']] as [$t, $c]) if (DB::val("SELECT 1 FROM $t WHERE $c=? AND NOT (? = '$t' AND id=?)", [$stored, $exceptTable, $exceptId])) return;
        if (in_array($stored, [setting('ct.logo', ''), setting('ct.header_img', ''), setting('ct.footer_img', '')], true)) return;
        @unlink(Files::dir(self::SUB) . '/' . $stored);
    }
    /** Éléments à imprimer pour une société : en-tête image > texte propre à la société > défaut ; à défaut de tout, le logo de la société employeuse. */
    static function forEmployer(?string $code): array {
        $e = $code ? (DB::one('SELECT * FROM employers WHERE code=?', [$code]) ?: []) : [];
        $g = fn($k) => (string)setting($k, '');
        $hImg = ($e['header_img'] ?? '') ?: ''; $hTxt = ($e['doc_header'] ?? '') ?: ''; $fImg = ($e['footer_img'] ?? '') ?: ''; $fTxt = ($e['doc_footer'] ?? '') ?: '';
        if ($hImg === '' && $hTxt === '') { $hImg = $g('ct.header_img'); $hTxt = $g('ct.header_text'); }
        if ($fImg === '' && $fTxt === '') { $fImg = $g('ct.footer_img'); $fTxt = $g('ct.footer_text'); }
        $logo = ($e['logo'] ?? '') ?: $g('ct.logo');
        return ['logo' => $logo, 'header_img' => $hImg, 'header_text' => $hTxt, 'footer_img' => $fImg, 'footer_text' => $fTxt, 'name' => (string)($e['name'] ?? ''), 'slogan' => (string)($e['slogan'] ?? '')];
    }
    /** Variables {{…}} décrivant la société employeuse. */
    static function vars(?string $code): array {
        $e = $code ? (DB::one('SELECT * FROM employers WHERE code=?', [$code]) ?: []) : [];
        $v = fn($k) => (string)($e[$k] ?? '');
        $co = (string)setting('company_name', (string)setting('app.name', 'CXO Excellence Hub'));
        return ['employeur' => $v('name') ?: $co, 'slogan' => $v('slogan'), 'secteur' => $v('sector'), 'forme_juridique' => $v('legal_form'), 'capital' => $v('capital'), 'rccm' => $v('rccm'), 'nif' => $v('nif'), 'cnss' => $v('cnss'),
            'siege' => $v('address'), 'tel_societe' => $v('phone'), 'email_societe' => $v('email'), 'dirigeant_poste' => $v('head_title'), 'dirigeant_nom' => $v('head_name'), 'rh_poste' => $v('hr_title'), 'rh_nom' => $v('hr_name'),
            'representant' => trim($v('head_name') . ($v('head_title') !== '' && $v('head_name') !== '' ? ', ' . $v('head_title') : ''))];
    }
}
