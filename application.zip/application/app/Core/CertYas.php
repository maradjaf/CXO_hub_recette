<?php
namespace App\Core;

/** Modèle « Attestation Yas » : fond jaune, vagues bleues, rosette, étoiles de niveau, QR de vérification. Dessiné à partir du gabarit 1587 x 1123 px (A4 paysage). */
class CertYas {
    const LIGHT = '5B9BD5';
    const LEVELS = "Débutant:0;Intermédiaire:70;Confirmé:80;Avancé:90;Expert:95";
    /** Niveaux saisis « Nom:seuil » séparés par ; ou retour à la ligne, triés par seuil. @return array<int,array{0:string,1:float}> */
    static function levels(?string $s): array {
        $out = []; foreach (preg_split('/[;\n]+/', (string)($s !== null && trim($s) !== '' ? $s : self::LEVELS)) as $p) { $p = trim($p); if ($p === '') continue; $k = strrpos($p, ':'); $out[] = $k === false ? [$p, 0.0] : [trim(substr($p, 0, $k)), (float)str_replace(',', '.', substr($p, $k + 1))]; }
        usort($out, fn($a, $b) => $a[1] <=> $b[1]); return array_slice($out ?: self::levels(self::LEVELS), 0, 7);
    }
    /** @return array{0:int,1:string,2:int} rang (1..n), libellé, nombre de niveaux ; rang 0 si aucun score */
    static function level(string $score, ?string $levels): array {
        $L = self::levels($levels); $n = count($L); if (trim($score) === '' || !is_numeric(str_replace(',', '.', $score))) return [0, '', $n];
        $v = (float)str_replace(',', '.', $score); $r = 1; foreach ($L as $i => [$name, $min]) if ($v >= $min) $r = $i + 1; return [$r, $L[$r - 1][0], $n];
    }
    /** « 8 h » → « 8 heures » pour la phrase ; autres formats inchangés. */
    static function hoursText(string $d): string {
        $d = trim($d); return preg_replace_callback('/^(\d+(?:[.,]\d+)?)\s*h$/u', fn($m) => $m[1] . ((float)str_replace(',', '.', $m[1]) > 1 ? ' heures' : ' heure'), $d);
    }
    private static function px(array $cmds, float $s, float $H, float $ox = 0, float $oy = 0, float $k = 1.0): array {
        return array_map(function ($c) use ($s, $H, $ox, $oy, $k) { $o = [$c[0]]; for ($i = 1; $i < count($c); $i += 2) { $o[] = ($ox + $c[$i] * $k) * $s; $o[] = $H - ($oy + $c[$i + 1] * $k) * $s; } return $o; }, $cmds);
    }

    static function render(array $t, array $d, ?string $code, callable $rep, string $org): string {
        $W = 842.0; $H = 595.0; $s = $W / 1587; $c1 = self::hexc($t['color'] ?? '', '003A84'); $c2 = self::hexc($t['accent'] ?? '', 'FFCE00'); $L = self::LIGHT; $p = new Pdf;
        $X = fn(float $px) => round($px * $s, 2); $Y = fn(float $py) => round($H - $py * $s, 2); $mw = 1250 * $s;
        $p->rect(0, 0, $W, $H, $c2);
        // vague bleue en haut à gauche
        $p->path(self::px([['m', 0, 0], ['l', 945, 0], ['c', 975, 70, 990, 120, 983, 165], ['c', 970, 290, 900, 370, 770, 372], ['c', 480, 372, 160, 330, 0, 290], ['h']], $s, $H), $c1);
        // vague bleue en bas à droite
        $p->path(self::px([['m', 1290, 1123], ['c', 1240, 1000, 1235, 880, 1300, 820], ['c', 1360, 775, 1480, 790, 1587, 835], ['l', 1587, 1123], ['h']], $s, $H), $c1);
        if (!empty($t['show_logo'])) {
            $blob = [['m', 100, 32], ['c', 140, 22, 200, 50, 262, 100], ['c', 292, 124, 292, 146, 258, 170], ['c', 200, 215, 150, 248, 100, 256], ['c', 55, 260, 32, 225, 38, 180], ['c', 42, 120, 52, 48, 100, 32], ['h']];
            $k = 0.66; $ox = 1328 - 38 * $k; $oy = 880 - 22 * $k; $p->path(self::px($blob, $s, $H, $ox, $oy, $k), $c2);
            $in = array_map(function ($c) { $o = [$c[0]]; for ($i = 1; $i < count($c); $i += 2) { $o[] = 165 + ($c[$i] - 165) * 0.96; $o[] = 140 + ($c[$i + 1] - 140) * 0.96; } return $o; }, $blob);
            $p->imageClipped(ROOT . '/public/assets/logo.jpg', $X($ox), $Y($oy + 270 * $k), round(340 * $k * $s, 2), round(270 * $k * $s, 2), self::px($in, $s, $H, $ox, $oy, $k));
        }
        // rosette
        $cx = $X(162); $cy = $Y(157); $r = 62 * $s;
        $p->path(Pdf::star($cx, $cy, $r, $r * 0.88, 16), $L);
        $p->path([['m', $X(112), $Y(205)], ['l', $X(150), $Y(222)], ['l', $X(160), $Y(264)], ['l', $X(138), $Y(244)], ['l', $X(96), $Y(240)], ['h']], $L);
        $p->path([['m', $X(212), $Y(205)], ['l', $X(174), $Y(222)], ['l', $X(164), $Y(264)], ['l', $X(186), $Y(244)], ['l', $X(228), $Y(240)], ['h']], $L);
        $p->path(Pdf::circle($cx, $cy, 36 * $s), $L, $c1, 3.2);
        $p->path([['m', $X(143), $Y(158)], ['l', $X(156), $Y(172)], ['l', $X(184), $Y(142)]], null, $c1, 4.2);
        // titre en deux lignes
        $title = (string)($t['title'] ?: 'Attestation de|fin de formation'); if (str_contains($title, '|')) [$l1, $l2] = array_map('trim', explode('|', $title, 2)); else { $w = preg_split('/\s+/u', trim($title)); $k2 = max(1, (int)ceil(count($w) / 2)); $l1 = implode(' ', array_slice($w, 0, $k2)); $l2 = implode(' ', array_slice($w, $k2)); }
        $l1 = $rep($l1); $l2 = $rep($l2); $tw = 500 * $s; $sz = 40.0; while ($sz > 14 && max(Pdf::width($l1, $sz, true), Pdf::width($l2, $sz, true)) > $tw) $sz -= 1;
        $p->text($l1, $X(270), $Y(172), $sz, $L, true, true); $p->text($l2, $X(270), $Y(234), $sz, $c2, true, true);
        // numéro et date (haut droite)
        $y = 120; foreach ([['show_number', "Numéro d'attestation :", (string)$d['no']], ['show_date', 'Date d’obtention :', (string)$d['date']]] as [$f, $lab, $val]) {
            if (!empty($t[$f])) { $w = Pdf::width($lab, 13, true); $p->text($lab, $X(1328) - $w, $Y($y), 13, $c1, true, true); $p->text($val, $X(1342), $Y($y), 12, $c1, true); } $y += 52; }
        // introduction, nom, filet
        $intro = trim((string)$t['intro']) !== '' ? $rep((string)$t['intro']) : $org . ' atteste par la présente que :';
        $p->center($intro, $Y(440), 13, $c1, false, $W, $mw, true);
        $p->center((string)$d['name'], $Y(512), 22, $c1, true, $W, $mw, true);
        $p->line($X(93), $Y(537), $X(1493), $Y(537), $c1, 0.7);
        // corps
        $body = trim((string)$t['body']) !== '' ? $rep((string)$t['body']) : 'a suivi avec succès la formation sur :';
        $p->center($body, $Y(585), 12.5, $c1, false, $W, $mw);
        foreach (array_slice(Pdf::wrap((string)$d['item'], 15, $mw, true), 0, 2) as $i => $ln) $p->center($ln, $Y(620 + $i * 30), 15, $c1, true, $W, $mw);
        $extra = ((int)(count(Pdf::wrap((string)$d['item'], 15, $mw, true)) > 1)) * 30; $comp = trim($rep(trim((string)($d['competence'] ?? '')) !== '' ? (string)$d['competence'] : (string)($t['competence'] ?? '')));
        $b2 = trim((string)($t['body2'] ?? '')) !== '' ? (string)$t['body2'] : "Cette formation de {duree} lui a permis d'acquérir la compétence suivante :";
        $dur = self::hoursText((string)$d['duration']);
        if ($comp !== '') {
            if ($dur === '') $b2 = str_replace(' de {duree}', '', $b2); $b2 = $rep(strtr($b2, ['{duree}' => $dur]));
            $p->center($b2, $Y(656 + $extra), 12.5, $c1, false, $W, $mw);
            foreach (array_slice(Pdf::wrap($comp, 14, $mw, true), 0, 2) as $i => $ln) $p->center($ln, $Y(692 + $extra + $i * 28), 14, $c1, true, $W, $mw);
        } elseif ($dur !== '') $p->center('Durée de la formation : ' . $dur, $Y(656 + $extra), 12.5, $c1, false, $W, $mw);
        // étoiles et niveau
        if (!empty($t['show_score'])) {
            [$rank, $name, $n] = self::level((string)$d['score'], $t['levels'] ?? null);
            if ($rank > 0) {
                $sizes = []; for ($i = 0; $i < $n; $i++) $sizes[] = $n === 1 ? 70 : 36 + (112 - 36) * $i / ($n - 1); $gap = 8; $tot = array_sum($sizes) + $gap * ($n - 1); $x = 797 - $tot / 2; $cyS = 780 + (!empty($extra) ? 0 : 0);
                foreach ($sizes as $i => $sz2) { $r2 = $sz2 / 2; $pts = Pdf::star($X($x + $r2), $Y($cyS), $r2 * $s, $r2 * $s * 0.46, 5);
                    if ($i < $rank) $p->path($pts, $c1, $c1, 1); else $p->path($pts, null, $L, 2.6); $x += $sz2 + $gap; }
                $lab = 'Niveau de réussite obtenu: '; $w1 = Pdf::width($lab, 12, false); $w2 = Pdf::width($name, 12, true); $x0 = ($W - $w1 - $w2) / 2;
                $p->text($lab, $x0, $Y(868), 12, $c1, false, true); $p->text($name, $x0 + $w1, $Y(868), 12, $c1, true, true);
            }
        }
        // signataires
        $sg = array_values(array_filter([[$t['signer1_name'] ?? '', $t['signer1_title'] ?? ''], [$t['signer2_name'] ?? '', $t['signer2_title'] ?? '']], fn($q) => trim($q[0] . $q[1]) !== ''));
        foreach ($sg as $i => [$nm, $ti]) { $cxs = count($sg) === 1 ? $W / 2 - 4 : ($i === 0 ? $W * 0.4 : $W * 0.62);
            if (trim($ti) !== '') { $w = Pdf::width($ti, 12); $p->text($ti, round($cxs - $w / 2, 2), $Y(938), 12, $c1, false, true); }
            if (trim($nm) !== '') { $w = Pdf::width($nm, 13, true); $p->text($nm, round($cxs - $w / 2, 2), $Y(1050), 13, $c1, true, true); } }
        if (trim((string)$t['footer']) !== '') $p->center($rep((string)$t['footer']), 14, 7.5, $c1, false, $W, 400);
        // QR de vérification
        if (!empty($t['show_qr']) && $code !== null) { $side = 236 * $s; $qx = $X(95); $qy = $Y(1062); Qr::pdf($p, Cert::verifyUrl($code), $qx, $qy, $side); $p->center($code . ' · scanner pour vérifier', $qy - 9, 6.5, $c1, true, 2 * $qx + $side, $side + 20); }
        return $p->output($W, $H);
    }
    private static function hexc(?string $c, string $d): string { return preg_match('/^#?([0-9A-Fa-f]{6})$/', (string)$c, $m) ? strtoupper($m[1]) : $d; }
}
