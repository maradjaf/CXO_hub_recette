<?php
namespace App\Core;

/** Indicateurs de pilotage de la base de connaissances, des cours e-learning et de la satisfaction. */
final class LearnDash {
    /** Semaines (lundi) couvrant la période : ['2026-11-02' => 0, ...]. */
    static function weeks(int $days): array {
        $out = []; $t = strtotime('monday this week') - (int)floor(($days - 1) / 7) * 7 * 86400;
        for ($i = 0; $i <= (int)floor(($days - 1) / 7); $i++) $out[date('Y-m-d', $t + $i * 7 * 86400)] = 0; return $out;
    }
    static function weekOf(string $date): string { return date('Y-m-d', strtotime('monday this week', strtotime(substr($date, 0, 10)))); }
    static function bucket(array $rows, string $col, array $weeks): array { foreach ($rows as $r) { $k = self::weekOf((string)$r[$col]); if (isset($weeks[$k])) $weeks[$k]++; } return $weeks; }
    static function wl(array $weeks): array { return array_map(fn($k) => date('d/m', strtotime($k)), array_keys($weeks)); }
    static function pct($a, $b): ?float { return $b > 0 ? round($a / $b * 100, 1) : null; }

    static function kb(int $days): array {
        $since = date('Y-m-d', strtotime("-$days days")); $sinceT = $since . ' 00:00:00'; $today = date('Y-m-d'); $D = [];
        $D['st'] = array_column(DB::all('SELECT status, COUNT(*) n FROM kb_articles GROUP BY status'), 'n', 'status');
        $D['pub'] = (int)($D['st']['published'] ?? 0); $D['sops'] = (int)DB::val("SELECT COUNT(*) FROM kb_sops WHERE status='published'");
        $log = DB::all("SELECT day, user_id, item_id FROM kb_view_log WHERE kind='article' AND day>=?", [$since]);
        $D['views'] = count($log); $D['readers'] = count(array_unique(array_column($log, 'user_id')));
        $D['weeks'] = self::weeks($days); $D['viewsW'] = self::bucket($log, 'day', $D['weeks']);
        $v = DB::one("SELECT SUM(CASE WHEN useful=1 THEN 1 ELSE 0 END) u, COUNT(*) n FROM kb_votes WHERE created_at>=?", [$sinceT]); $D['votes'] = (int)$v['n']; $D['useful'] = self::pct((int)$v['u'], (int)$v['n']);
        $D['qOpen'] = (int)DB::val("SELECT COUNT(*) FROM kb_questions WHERE status='open'");
        $D['qNew'] = DB::all('SELECT created_at FROM kb_questions WHERE created_at>=?', [$sinceT]); $D['qW'] = self::bucket($D['qNew'], 'created_at', $D['weeks']);
        $h = DB::all("SELECT created_at, handled_at FROM kb_questions WHERE handled_at IS NOT NULL AND created_at>=?", [$sinceT]); $D['qDelay'] = $h ? round(array_sum(array_map(fn($r) => (strtotime($r['handled_at']) - strtotime($r['created_at'])) / 86400, $h)) / count($h), 1) : null;
        $D['overdue'] = DB::all("SELECT id, title, review_due, views FROM kb_articles WHERE status='published' AND review_due IS NOT NULL AND review_due<? ORDER BY review_due LIMIT 15", [$today]);
        $D['nOverdue'] = (int)DB::val("SELECT COUNT(*) FROM kb_articles WHERE status='published' AND review_due IS NOT NULL AND review_due<?", [$today]);
        $D['top'] = DB::all("SELECT a.id, a.title, COUNT(l.id) n FROM kb_view_log l JOIN kb_articles a ON a.id=l.item_id WHERE l.kind='article' AND l.day>=? GROUP BY a.id, a.title ORDER BY n DESC LIMIT 10", [$since]);
        $D['unread'] = DB::all("SELECT a.id, a.title, a.published_at FROM kb_articles a WHERE a.status='published' AND NOT EXISTS (SELECT 1 FROM kb_view_log l WHERE l.kind='article' AND l.item_id=a.id AND l.day>=?) ORDER BY a.published_at LIMIT 15", [$since]);
        $D['nUnread'] = (int)DB::val("SELECT COUNT(*) FROM kb_articles a WHERE a.status='published' AND NOT EXISTS (SELECT 1 FROM kb_view_log l WHERE l.kind='article' AND l.item_id=a.id AND l.day>=?)", [$since]);
        $D['weak'] = DB::all("SELECT id, title, useful, useless FROM kb_articles WHERE status='published' AND useful+useless>=3 AND useless*2>=useful ORDER BY useless*1.0/(useful+useless) DESC LIMIT 10");
        $D['cats'] = DB::all("SELECT c.name, COUNT(a.id) n, SUM(a.useful) u, SUM(a.useless) x FROM kb_categories c LEFT JOIN kb_articles a ON a.category_id=c.id AND a.status='published' GROUP BY c.id, c.name ORDER BY n DESC");
        $D['qOld'] = DB::all("SELECT q.id, q.text, q.created_at FROM kb_questions q WHERE q.status='open' ORDER BY q.created_at LIMIT 10");
        $b = DB::one("SELECT COUNT(*) n, SUM(CASE WHEN found=0 THEN 1 ELSE 0 END) nf FROM bot_messages WHERE role='assistant' AND created_at>=?", [$sinceT]); $D['botN'] = (int)$b['n']; $D['botMiss'] = (int)$b['nf']; $D['botRate'] = self::pct((int)$b['nf'], (int)$b['n']);
        $D['miss'] = DB::all("SELECT m.created_at, (SELECT u.content FROM bot_messages u WHERE u.conversation_id=m.conversation_id AND u.role='user' AND u.id<m.id ORDER BY u.id DESC LIMIT 1) q FROM bot_messages m WHERE m.role='assistant' AND m.found=0 AND m.created_at>=? ORDER BY m.id DESC LIMIT 10", [$sinceT]);
        $D['ack'] = DB::one("SELECT COUNT(*) n, SUM(CASE WHEN read_at IS NOT NULL THEN 1 ELSE 0 END) r FROM kb_acks"); $D['ackRate'] = self::pct((int)$D['ack']['r'], (int)$D['ack']['n']);
        $D['roles'] = DB::all("SELECT COALESCE(NULLIF(role_code,''),'—') r, COUNT(*) n FROM kb_view_log WHERE kind='article' AND day>=? GROUP BY role_code ORDER BY n DESC LIMIT 8", [$since]);
        $D['ttr'] = (int)DB::val("SELECT COUNT(*) FROM kb_articles WHERE status='pending'");
        return $D;
    }

    /** Récapitulatif des inscrits (personnes distinctes) par parcours et par domaine d'activité, dans le périmètre de l'utilisateur. */
    static function enrolRecap(): array {
        [$sc, $sp] = Scope::sql('en.employee_id');
        $path = DB::all("SELECT p.id, p.name, COUNT(DISTINCT en.user_id) people, COUNT(en.id) enrols, SUM(CASE WHEN en.status='passed' THEN 1 ELSE 0 END) passed FROM el_paths p JOIN el_path_courses pc ON pc.path_id=p.id JOIN el_enrollments en ON en.course_id=pc.course_id WHERE $sc GROUP BY p.id, p.name ORDER BY p.name", $sp);
        $dom = DB::all("SELECT COALESCE(NULLIF(c.domain, ''), '') dom, COUNT(DISTINCT en.user_id) people, COUNT(en.id) enrols, SUM(CASE WHEN en.status='passed' THEN 1 ELSE 0 END) passed FROM el_enrollments en JOIN el_courses c ON c.id=en.course_id WHERE $sc GROUP BY COALESCE(NULLIF(c.domain, ''), '') ORDER BY dom", $sp);
        return ['paths' => $path, 'domains' => $dom];
    }
    /** Personnes inscrites à un parcours, un domaine ou un cours : une ligne par personne. */
    static function enrolled(string $kind, string $key): array {
        [$sc, $sp] = Scope::sql('en.employee_id');
        $w = [$sc]; $p = $sp;
        if ($kind === 'path') { $w[] = 'en.course_id IN (SELECT course_id FROM el_path_courses WHERE path_id=?)'; $p[] = (int)$key; }
        elseif ($kind === 'course') { $w[] = 'en.course_id=?'; $p[] = (int)$key; }
        else { $w[] = "COALESCE(NULLIF(c.domain, ''), '')=?"; $p[] = $key; }
        return DB::all("SELECT u.id uid, u.name, t.name team, COUNT(en.id) courses, SUM(CASE WHEN en.status='passed' THEN 1 ELSE 0 END) passed, SUM(CASE WHEN en.status IN ('assigned','in_progress') THEN 1 ELSE 0 END) open_n, MIN(CASE WHEN en.status IN ('assigned','in_progress') THEN en.due_date END) next_due, MAX(en.created_at) last_enrol
            FROM el_enrollments en JOIN el_courses c ON c.id=en.course_id LEFT JOIN users u ON u.id=en.user_id LEFT JOIN employees e ON e.id=en.employee_id LEFT JOIN teams t ON t.id=e.team_id
            WHERE " . implode(' AND ', $w) . ' GROUP BY u.id, u.name, t.name ORDER BY u.name', $p);
    }
    static function el(int $days, ?string $domain, ?int $team): array {
        $since = date('Y-m-d', strtotime("-$days days")); $sinceT = $since . ' 00:00:00'; $today = date('Y-m-d');
        [$sc, $sp] = Scope::sql('en.employee_id'); $w = [$sc, '(en.created_at>=? OR en.completed_at>=?)']; $p = array_merge($sp, [$sinceT, $sinceT]);
        if ($domain !== null && $domain !== '') { $w[] = 'c.domain=?'; $p[] = $domain; } if ($team) { $w[] = 'e.team_id=?'; $p[] = $team; }
        $from = 'el_enrollments en JOIN el_courses c ON c.id=en.course_id LEFT JOIN employees e ON e.id=en.employee_id LEFT JOIN users u ON u.id=en.user_id WHERE ' . implode(' AND ', $w); $D = ['scope' => [$from, $p]];
        $rows = DB::all("SELECT en.id, en.status, en.due_date, en.best_pct, en.attempts, en.started_at, en.completed_at, en.created_at, en.course_id, c.title, c.domain, e.team_id FROM $from", $p); $n = count($rows);
        $cnt = array_count_values(array_column($rows, 'status')); $D['n'] = $n; $D['cnt'] = $cnt;
        $passed = (int)($cnt['passed'] ?? 0); $failed = (int)($cnt['failed'] ?? 0); $prog = (int)($cnt['in_progress'] ?? 0); $ass = (int)($cnt['assigned'] ?? 0);
        $D['passed'] = $passed; $D['failed'] = $failed; $D['rate'] = self::pct($passed, $n); $D['succ'] = self::pct($passed, $passed + $failed);
        $scores = array_filter(array_map(fn($r) => $r['best_pct'] !== null ? (float)$r['best_pct'] : null, array_filter($rows, fn($r) => $r['status'] === 'passed')), fn($x) => $x !== null); $D['avgScore'] = $scores ? round(array_sum($scores) / count($scores), 1) : null;
        $dd = array_filter(array_map(fn($r) => $r['status'] === 'passed' && $r['completed_at'] ? (strtotime($r['completed_at']) - strtotime($r['created_at'])) / 86400 : null, $rows), fn($x) => $x !== null); $D['avgDays'] = $dd ? round(array_sum($dd) / count($dd), 1) : null;
        $late = array_filter($rows, fn($r) => in_array($r['status'], ['assigned', 'in_progress'], true) && $r['due_date'] && $r['due_date'] < $today); $D['late'] = count($late); $D['lateRate'] = self::pct(count($late), $ass + $prog);
        $D['funnel'] = ['Inscrits' => $n, 'Démarrés' => $n - $ass, 'Terminés (réussite ou échec)' => $passed + $failed, 'Réussis' => $passed];
        $D['weeks'] = self::weeks($days); $D['enW'] = self::bucket($rows, 'created_at', $D['weeks']); $D['doneW'] = self::bucket(array_filter($rows, fn($r) => $r['status'] === 'passed' && $r['completed_at']), 'completed_at', $D['weeks']);
        $by = []; foreach ($rows as $r) { $k = $r['course_id']; $by[$k] ??= ['id' => $k, 'title' => $r['title'], 'domain' => $r['domain'], 'n' => 0, 'ok' => 0, 'ko' => 0, 'late' => 0, 'sc' => []]; $by[$k]['n']++; if ($r['status'] === 'passed') { $by[$k]['ok']++; if ($r['best_pct'] !== null) $by[$k]['sc'][] = (float)$r['best_pct']; } if ($r['status'] === 'failed') $by[$k]['ko']++; if (in_array($r['status'], ['assigned', 'in_progress'], true) && $r['due_date'] && $r['due_date'] < $today) $by[$k]['late']++; }
        $sat = array_column(DB::all("SELECT course_id, AVG(avg) a, COUNT(*) n FROM el_surveys WHERE status='done' GROUP BY course_id"), null, 'course_id');
        foreach ($by as &$c) { $c['rate'] = self::pct($c['ok'], $c['n']); $c['score'] = $c['sc'] ? round(array_sum($c['sc']) / count($c['sc']), 1) : null; $c['sat'] = isset($sat[$c['id']]) ? round((float)$sat[$c['id']]['a'], 2) : null; } unset($c);
        usort($by, fn($a, $b) => $b['n'] <=> $a['n']); $D['courses'] = $by;
        $dom = []; foreach ($rows as $r) { $k = $r['domain'] ?: 'Général'; $dom[$k] ??= [0, 0]; $dom[$k][0]++; if ($r['status'] === 'passed') $dom[$k][1]++; } $D['dom'] = array_map(fn($v) => self::pct($v[1], $v[0]) ?? 0, $dom); arsort($D['dom']);
        $tm = []; foreach ($rows as $r) if ($r['team_id']) { $tm[$r['team_id']] ??= [0, 0]; $tm[$r['team_id']][0]++; if ($r['status'] === 'passed') $tm[$r['team_id']][1]++; }
        $names = array_column(DB::all('SELECT id, name FROM teams'), 'name', 'id'); $D['teams'] = []; foreach ($tm as $id => $v) if ($v[0] >= 3) $D['teams'][$names[$id] ?? ('Équipe ' . $id)] = self::pct($v[1], $v[0]); arsort($D['teams']);
        $D['lateList'] = DB::all("SELECT u.name, c.title, en.due_date, en.status, en.id eid, en.course_id FROM $from AND en.status IN ('assigned','in_progress') AND en.due_date IS NOT NULL AND en.due_date<? ORDER BY en.due_date LIMIT 20", array_merge($p, [$today]));
        $D['stuck'] = (int)DB::val("SELECT COUNT(*) FROM $from AND en.status='in_progress' AND COALESCE((SELECT MAX(pr.done_at) FROM el_progress pr WHERE pr.enrollment_id=en.id), en.started_at, en.created_at)<?", array_merge($p, [date('Y-m-d H:i:s', time() - 30 * 86400)]));
        $D['hard'] = DB::all("SELECT q.id, q.text, c.title, COUNT(a.id) n, SUM(a.correct) ok FROM el_answers a JOIN el_questions q ON q.id=a.question_id JOIN el_courses c ON c.id=q.course_id JOIN el_attempts att ON att.id=a.attempt_id WHERE att.submitted_at>=? GROUP BY q.id, q.text, c.title HAVING COUNT(a.id)>=3 ORDER BY SUM(a.correct)*1.0/COUNT(a.id) LIMIT 8", [$sinceT]);
        $D['nCourses'] = (int)DB::val("SELECT COUNT(*) FROM el_courses WHERE status='published'"); $D['nDraft'] = (int)DB::val("SELECT COUNT(*) FROM el_courses WHERE status='draft'");
        $D['noEnroll'] = (int)DB::val("SELECT COUNT(*) FROM el_courses c WHERE c.status='published' AND NOT EXISTS (SELECT 1 FROM el_enrollments en WHERE en.course_id=c.id)");
        $D['reqPending'] = (int)DB::val("SELECT COUNT(*) FROM el_requests WHERE status='pending'");
        return $D;
    }

    static function sat(int $days): array {
        $sinceT = date('Y-m-d', strtotime("-$days days")) . ' 00:00:00'; $D = [];
        $s = DB::one("SELECT COUNT(*) n, SUM(CASE WHEN status='done' THEN 1 ELSE 0 END) d, AVG(CASE WHEN status='done' THEN avg END) a FROM el_surveys WHERE requested_at>=?", [$sinceT]);
        $D['elN'] = (int)$s['n']; $D['elDone'] = (int)$s['d']; $D['elRate'] = self::pct((int)$s['d'], (int)$s['n']); $D['elAvg'] = $s['a'] !== null ? round((float)$s['a'], 2) : null;
        $D['elPending'] = (int)DB::val("SELECT COUNT(*) FROM el_surveys WHERE status='pending'"); $D['elMissing'] = (int)DB::val("SELECT COUNT(*) FROM el_enrollments en WHERE en.status IN ('passed','failed') AND NOT EXISTS (SELECT 1 FROM el_surveys s WHERE s.enrollment_id=en.id)");
        $D['elByCourse'] = array_column(DB::all("SELECT c.title, AVG(s.avg) a, COUNT(*) n FROM el_surveys s JOIN el_courses c ON c.id=s.course_id WHERE s.status='done' AND s.requested_at>=? GROUP BY c.id, c.title HAVING COUNT(*)>=1 ORDER BY AVG(s.avg) DESC LIMIT 12", [$sinceT]), 'a', 'title');
        $dist = array_fill(1, 5, 0); foreach (DB::all("SELECT avg FROM el_surveys WHERE status='done' AND avg IS NOT NULL AND requested_at>=?", [$sinceT]) as $r) $dist[max(1, min(5, (int)round((float)$r['avg'])))]++; $D['dist'] = $dist;
        $D['comments'] = DB::all("SELECT s.comment, s.avg, c.title, s.submitted_at FROM el_surveys s JOIN el_courses c ON c.id=s.course_id WHERE s.status='done' AND s.comment IS NOT NULL AND s.comment<>'' ORDER BY s.submitted_at DESC LIMIT 8");
        $D['sessMissing'] = (int)DB::val("SELECT COUNT(*) FROM training_sessions s WHERE s.status<>'cancelled' AND s.session_date<=? AND NOT EXISTS (SELECT 1 FROM tr_eval_plans p WHERE p.session_id=s.id AND p.kind='hot' AND p.status<>'cancelled')", [date('Y-m-d')]);
        $pl = DB::one("SELECT COUNT(*) n, SUM(CASE WHEN status IN ('open','closed') THEN 1 ELSE 0 END) o FROM tr_eval_plans WHERE kind='hot' AND send_on>=?", [substr($sinceT, 0, 10)]); $D['hotPlans'] = (int)$pl['n'];
        $r = DB::one("SELECT COUNT(*) n, AVG(r.avg) a FROM tr_eval_responses r JOIN tr_eval_plans p ON p.id=r.plan_id WHERE p.kind='hot' AND p.send_on>=?", [substr($sinceT, 0, 10)]); $D['hotN'] = (int)$r['n']; $D['hotAvg'] = $r['a'] !== null ? round((float)$r['a'], 2) : null;
        $exp = (int)DB::val("SELECT COUNT(*) FROM training_enrollments en JOIN tr_eval_plans p ON p.session_id=en.session_id AND p.kind='hot' AND p.status IN ('open','closed') WHERE en.status<>'absent' AND p.send_on>=?", [substr($sinceT, 0, 10)]); $D['hotRate'] = self::pct($D['hotN'], $exp);
        $D['byTrainer'] = []; foreach (DB::all("SELECT e.first_name, e.last_name, AVG(r.avg) a, COUNT(*) n FROM tr_eval_responses r JOIN tr_eval_plans p ON p.id=r.plan_id AND p.kind='hot' JOIN training_sessions s ON s.id=p.session_id JOIN employees e ON e.id=s.trainer_emp_id WHERE p.send_on>=? GROUP BY e.id, e.first_name, e.last_name HAVING COUNT(*)>=1 ORDER BY AVG(r.avg) DESC LIMIT 10", [substr($sinceT, 0, 10)]) as $x) $D['byTrainer'][trim($x['last_name'] . ' ' . $x['first_name'])] = round((float)$x['a'], 2);
        $D['byTraining'] = array_map(fn($v) => round((float)$v, 2), array_column(DB::all("SELECT t.title, AVG(r.avg) a FROM tr_eval_responses r JOIN tr_eval_plans p ON p.id=r.plan_id AND p.kind='hot' JOIN training_sessions s ON s.id=p.session_id JOIN trainings t ON t.id=s.training_id WHERE p.send_on>=? GROUP BY t.id, t.title ORDER BY AVG(r.avg) DESC LIMIT 10", [substr($sinceT, 0, 10)]), 'a', 'title'));
        $D['lowSess'] = DB::all("SELECT p.id pid, t.title, s.session_date, AVG(r.avg) a, COUNT(*) n FROM tr_eval_responses r JOIN tr_eval_plans p ON p.id=r.plan_id AND p.kind='hot' JOIN training_sessions s ON s.id=p.session_id JOIN trainings t ON t.id=s.training_id WHERE p.send_on>=? GROUP BY p.id, t.title, s.session_date HAVING AVG(r.avg)<3.5 ORDER BY AVG(r.avg) LIMIT 8", [substr($sinceT, 0, 10)]);
        return $D;
    }
}
