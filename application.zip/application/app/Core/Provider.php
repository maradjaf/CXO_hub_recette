<?php
namespace App\Core;

/** Responsable prestataire : accès limité au personnel d'une société prestataire (employeur de nature « provider »). */
class Provider {
    static function all(): array { return DB::all("SELECT code, name FROM employers WHERE kind='provider' AND active=1 ORDER BY name"); }
    /** Société verrouillée du compte (responsable prestataire) ou null. */
    static function locked(): ?string { $c = (string)(Auth::user()['employer_code'] ?? ''); return $c !== '' ? $c : null; }
    /** Société affichée : celle du compte, sinon celle choisie (?employer=) par le RH/l'admin, mémorisée en session. */
    static function code(): ?string {
        if ($l = self::locked()) return $l;
        $all = array_column(self::all(), 'code'); $c = (string)($_GET['employer'] ?? $_SESSION['prov_emp'] ?? '');
        if (!in_array($c, $all, true)) $c = $all[0] ?? ''; $_SESSION['prov_emp'] = $c; return $c !== '' ? $c : null;
    }
    static function name(?string $c): string { return $c ? (string)(DB::val('SELECT name FROM employers WHERE code=?', [$c]) ?: $c) : ''; }
    static function owns(int $empId, ?string $c = null): bool { $c = $c ?? self::code(); return $c !== null && (bool)DB::val('SELECT 1 FROM employees WHERE id=? AND employer=?', [$empId, $c]); }
}
