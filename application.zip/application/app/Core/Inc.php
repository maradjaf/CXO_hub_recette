<?php
namespace App\Core;

/**
 * Gestion des incidents (Lot 44) : référentiels, cycle de vie, SLA, impact sur la productivité et indicateurs décisionnels.
 *
 * Principes repris des référentiels publics du secteur : ITIL 4 / ISO 20000 (matrice impact x urgence, priorités P1-P4, MTTA/MTTR,
 * problème et analyse de cause racine), TM Forum (eTOM, Trouble Ticket TMF621), TL 9000 / QuEST (durée de panne x abonnés, disponibilité),
 * suivi réglementaire type FCC NORS / régulateurs africains (seuil de « minutes-utilisateurs »). Les grilles internes des opérateurs ne sont
 * pas publiques : les valeurs par défaut (SLA, seuils) sont réglables dans « Paramétrage ».
 */
class Inc {
    const FAMILIES = [
        'NET' => 'Réseau mobile et cœur de réseau', 'FIX' => 'Réseau fixe, fibre et VoIP', 'MM' => 'Mobile Money', 'IT' => 'Systèmes et outils métier',
        'ENE' => 'Énergie et électricité', 'HW' => 'Matériel et poste de travail', 'SEC' => 'Sécurité', 'FAC' => 'Locaux et environnement',
        'EXT' => 'Tiers et événements externes', 'ORG' => 'Organisation et ressources',
    ];
    const SERVICES = [
        'voice' => 'Voix mobile', 'data' => 'Data / Internet mobile', 'sms' => 'SMS', 'ussd' => 'USSD / STK', 'momo' => 'Mobile Money', 'fixed' => 'Fixe / FTTH / ADSL',
        'bill' => 'Facturation et recharge', 'crm' => 'CRM et outils conseillers', 'cti' => 'Téléphonie centre d\'appels (CTI, IVR)', 'digital' => 'Digital (WhatsApp, réseaux sociaux)',
        'infra' => 'Infrastructure et énergie', 'site' => 'Boutique / site', 'other' => 'Autre',
    ];
    /** Services d'abonnés suivis en permanence dans la disponibilité. */
    const KEY_SERVICES = ['voice', 'data', 'sms', 'ussd', 'momo', 'fixed'];
    const SEV = ['P1' => 'P1 · Critique', 'P2' => 'P2 · Majeur', 'P3' => 'P3 · Modéré', 'P4' => 'P4 · Mineur'];
    const SEV_KIND = ['P1' => 'danger', 'P2' => 'warning', 'P3' => 'primary', 'P4' => 'secondary'];
    const SEV_COLOR = ['P1' => '#D72D32', 'P2' => '#F28C28', 'P3' => '#003A84', 'P4' => '#9AA5B1'];
    const STATUS = ['new' => 'Déclaré', 'ack' => 'Pris en charge', 'diag' => 'En diagnostic', 'mitigated' => 'Contourné', 'resolved' => 'Rétabli', 'closed' => 'Clos', 'cancelled' => 'Annulé'];
    const STATUS_KIND = ['new' => 'danger', 'ack' => 'warning', 'diag' => 'warning', 'mitigated' => 'info', 'resolved' => 'success', 'closed' => 'secondary', 'cancelled' => 'light'];
    /** Statuts pour lesquels le service n'est pas encore rétabli (arriéré). */
    const OPEN = ['new', 'ack', 'diag', 'mitigated'];
    const TRANS = [
        'new' => ['ack', 'diag', 'mitigated', 'resolved', 'cancelled'], 'ack' => ['diag', 'mitigated', 'resolved', 'cancelled'], 'diag' => ['mitigated', 'resolved', 'cancelled'],
        'mitigated' => ['diag', 'resolved'], 'resolved' => ['closed', 'diag'], 'closed' => ['diag'], 'cancelled' => ['new'],
    ];
    const EXTENT = ['individual' => 'Une personne', 'site' => 'Un site / une boutique', 'team' => 'Une équipe', 'region' => 'Une région', 'national' => 'National / plusieurs régions'];
    const DETECT = ['monitoring' => 'Supervision (NMS, alarmes)', 'agent' => 'Conseiller / terrain', 'supervisor' => 'Superviseur', 'customer' => 'Clients (réclamations)', 'vendor' => 'Fournisseur / opérateur tiers', 'social' => 'Réseaux sociaux', 'regulator' => 'Régulateur / autorité'];
    const ROOT = [
        'hardware' => 'Défaillance matérielle', 'software' => 'Défaut logiciel / bug', 'change' => 'Changement ou maintenance mal maîtrisé', 'capacity' => 'Saturation / capacité insuffisante',
        'config' => 'Erreur de configuration', 'human' => 'Erreur humaine', 'vendor' => 'Défaillance d\'un tiers / fournisseur', 'power' => 'Alimentation électrique / énergie', 'fiber' => 'Coupure de fibre / vol / vandalisme',
        'cyber' => 'Cyberattaque / malveillance', 'environment' => 'Environnement (météo, chaleur, inondation…)', 'process' => 'Processus ou organisation', 'unknown' => 'Cause non déterminée',
    ];
    const ACTION_KIND = ['corrective' => 'Corrective', 'preventive' => 'Préventive'];
    const IMPACT = ['high' => 'Élevé (service ou clientèle large)', 'medium' => 'Moyen (une équipe, un site)', 'low' => 'Faible (une personne)'];
    const URGENCY = ['high' => 'Élevée (blocage, pas de contournement)', 'medium' => 'Moyenne (dégradation)', 'low' => 'Faible (gêne, peut attendre)'];
    const MATRIX = ['high|high' => 'P1', 'high|medium' => 'P2', 'medium|high' => 'P2', 'high|low' => 'P3', 'medium|medium' => 'P3', 'low|high' => 'P3', 'medium|low' => 'P4', 'low|medium' => 'P4', 'low|low' => 'P4'];
    /** SLA par défaut (minutes) : prise en charge / rétablissement, usuels des NOC et centres de service télécom. */
    const SLA = ['P1' => ['ack' => 15, 'res' => 240], 'P2' => ['ack' => 30, 'res' => 480], 'P3' => ['ack' => 120, 'res' => 1440], 'P4' => ['ack' => 480, 'res' => 4320]];
    const DEFAULTS = ['inc.open_hour' => '7', 'inc.close_hour' => '20', 'inc.open_days' => '1,2,3,4,5,6', 'inc.shift_hours' => '7.5', 'inc.hourly_cost' => '1500', 'inc.currency' => 'FCFA',
        'inc.avail_target' => '99.5', 'inc.reg_threshold' => '900000', 'inc.rca_days' => '5', 'inc.recur_days' => '30', 'inc.recur_min' => '2'];

    /** [code, famille, libellé, service, gravité par défaut, panne totale du service (1/0), objectif de rétablissement en minutes] */
    const CATS = [
        ['NET_SITE', 'NET', 'Site radio hors service (BTS / NodeB / eNodeB / gNodeB)', 'voice', 'P2', 1, 360], ['NET_SECTOR', 'NET', 'Secteur ou cellule dégradé (qualité, couverture)', 'data', 'P3', 0, 720],
        ['NET_CORE', 'NET', 'Cœur de réseau (MSC, HLR/HSS, SGSN/EPC, IMS)', 'voice', 'P1', 1, 120], ['NET_CONGEST', 'NET', 'Congestion / saturation du réseau', 'data', 'P3', 0, 480],
        ['NET_TRANSMISSION', 'NET', 'Transmission / backhaul (faisceau hertzien, fibre)', 'data', 'P2', 1, 360], ['NET_INTERCO', 'NET', 'Interconnexion ou roaming indisponible', 'voice', 'P1', 1, 120],
        ['NET_DNS', 'NET', 'DNS, DHCP ou routage Internet', 'data', 'P2', 1, 180], ['NET_SMSC', 'NET', 'Centre SMS (SMSC) indisponible ou en retard', 'sms', 'P2', 1, 180],
        ['FIX_CUT', 'FIX', 'Coupure de fibre ou de câble client', 'fixed', 'P3', 1, 1440], ['FIX_OLT', 'FIX', 'OLT / DSLAM / nœud d\'accès en panne', 'fixed', 'P2', 1, 480],
        ['FIX_VOIP', 'FIX', 'VoIP / trunk SIP / téléphonie fixe', 'fixed', 'P2', 1, 240], ['FIX_BNG', 'FIX', 'Authentification ou BNG (accès Internet fixe)', 'fixed', 'P2', 1, 240],
        ['MM_PLATFORM', 'MM', 'Plateforme Mobile Money indisponible', 'momo', 'P1', 1, 60], ['MM_TXFAIL', 'MM', 'Taux d\'échec des transactions anormal', 'momo', 'P2', 0, 120],
        ['MM_USSD', 'MM', 'USSD / STK Mobile Money inaccessible', 'ussd', 'P2', 1, 120], ['MM_API', 'MM', 'API partenaire, banque ou marchand en erreur', 'momo', 'P2', 0, 240],
        ['MM_RECON', 'MM', 'Écart de réconciliation / compte de cantonnement', 'momo', 'P2', 0, 1440], ['MM_NOTIF', 'MM', 'Confirmations SMS non reçues ou tardives', 'momo', 'P3', 0, 240],
        ['MM_LIQUIDITY', 'MM', 'Manque de liquidité chez les agents / distributeurs', 'momo', 'P3', 0, 720], ['MM_FRAUD', 'MM', 'Fraude (SIM swap, usurpation, compte détourné)', 'momo', 'P2', 0, 480],
        ['MM_KYC', 'MM', 'Enregistrement KYC / ouverture de comptes bloqué', 'momo', 'P3', 0, 480],
        ['IT_CRM', 'IT', 'CRM / outil de relation client indisponible', 'crm', 'P2', 1, 120], ['IT_BILLING', 'IT', 'Facturation, recharge ou OCS en erreur', 'bill', 'P2', 1, 180],
        ['IT_CTI', 'IT', 'Téléphonie du centre (CTI / ACD / softphone)', 'cti', 'P1', 1, 90], ['IT_IVR', 'IT', 'Serveur vocal interactif (IVR) en panne', 'cti', 'P2', 1, 120],
        ['IT_SSO', 'IT', 'Annuaire, SSO, VPN ou accès aux applications', 'crm', 'P2', 1, 120], ['IT_TICKET', 'IT', 'Outil de ticketing ou base de connaissances', 'crm', 'P3', 0, 480],
        ['IT_DIGITAL', 'IT', 'Canaux digitaux (WhatsApp, Facebook, e-mail, chat)', 'digital', 'P2', 1, 180], ['IT_RECORD', 'IT', 'Enregistrement des appels / supervision temps réel', 'cti', 'P3', 0, 480],
        ['IT_SLOW', 'IT', 'Lenteur applicative', 'crm', 'P3', 0, 480], ['IT_DB', 'IT', 'Base de données / serveur applicatif', 'crm', 'P2', 1, 180],
        ['ENE_GRID', 'ENE', 'Coupure du secteur (réseau électrique)', 'infra', 'P2', 1, 240], ['ENE_GENSET', 'ENE', 'Groupe électrogène en panne ou sans carburant', 'infra', 'P2', 1, 240],
        ['ENE_UPS', 'ENE', 'Onduleur / batteries défaillants', 'infra', 'P2', 1, 240], ['ENE_COOLING', 'ENE', 'Climatisation / température salle technique', 'infra', 'P3', 0, 360],
        ['ENE_SURGE', 'ENE', 'Surtension, foudre ou instabilité électrique', 'infra', 'P3', 0, 480], ['ENE_SOLAR', 'ENE', 'Énergie solaire / hybride d\'un site en défaut', 'infra', 'P3', 0, 720],
        ['HW_PC', 'HW', 'Poste de travail ou ordinateur en panne', 'crm', 'P4', 0, 480], ['HW_HEADSET', 'HW', 'Casque, téléphone ou poste IP défectueux', 'cti', 'P4', 0, 480],
        ['HW_LAN', 'HW', 'Réseau local, Wi-Fi, switch ou routeur de site', 'crm', 'P3', 1, 240], ['HW_PRINT', 'HW', 'Imprimante, scanner ou lecteur', 'site', 'P4', 0, 1440],
        ['HW_POS', 'HW', 'Terminal de paiement / caisse de boutique', 'site', 'P3', 0, 480],
        ['SEC_CYBER', 'SEC', 'Cyberattaque, malware ou rançongiciel', 'crm', 'P1', 1, 120], ['SEC_LEAK', 'SEC', 'Fuite ou accès non autorisé aux données', 'crm', 'P1', 0, 240],
        ['SEC_ACCESS', 'SEC', 'Compromission de compte / accès physique non autorisé', 'crm', 'P2', 0, 240],
        ['FAC_FIRE', 'FAC', 'Incendie ou évacuation des locaux', 'site', 'P1', 1, 480], ['FAC_FLOOD', 'FAC', 'Inondation / dégât des eaux', 'site', 'P2', 1, 720],
        ['FAC_ACCESS', 'FAC', 'Locaux inaccessibles (travaux, ascenseur, sécurité)', 'site', 'P3', 1, 480],
        ['EXT_VENDOR', 'EXT', 'Défaillance d\'un fournisseur ou prestataire', 'other', 'P3', 0, 720], ['EXT_STRIKE', 'EXT', 'Grève, manifestation ou blocage des transports', 'site', 'P3', 0, 720],
        ['EXT_DISASTER', 'EXT', 'Catastrophe naturelle (inondation, tempête…)', 'infra', 'P1', 1, 1440], ['EXT_VANDAL', 'EXT', 'Vol ou vandalisme (câbles, batteries, carburant)', 'infra', 'P2', 1, 720],
        ['EXT_REG', 'EXT', 'Décision réglementaire ou coupure imposée', 'other', 'P2', 1, 480],
        ['ORG_ABS', 'ORG', 'Absentéisme massif imprévu', 'other', 'P3', 0, 1440], ['ORG_SURGE', 'ORG', 'Pic de trafic non anticipé (campagne, panne en amont)', 'other', 'P3', 0, 480],
        ['ORG_SHORT', 'ORG', 'Pénurie de compétence ou d\'habilitation sur un créneau', 'other', 'P4', 0, 1440],
    ];

    static function sev(?string $impact, ?string $urgency): string { return self::MATRIX[($impact ?? '') . '|' . ($urgency ?? '')] ?? 'P3'; }
    static function sevBadge(?string $s): string { return $s && isset(self::SEV[$s]) ? badge(self::SEV[$s], self::SEV_KIND[$s]) : ''; }
    static function statusBadge(?string $s): string { return $s && isset(self::STATUS[$s]) ? badge(self::STATUS[$s], self::STATUS_KIND[$s]) : ''; }
    static function set(string $k) { return Settings::get($k, self::DEFAULTS[$k] ?? null); }
    static function num(string $k): float { return (float)str_replace(',', '.', (string)self::set($k)); }

    /** SLA en minutes pour une gravité : réglage « inc.sla » (JSON) sinon valeurs par défaut. */
    static function sla(string $sev): array {
        $j = json_decode((string)Settings::get('inc.sla', ''), true); $d = self::SLA[$sev] ?? self::SLA['P3'];
        if (is_array($j) && isset($j[$sev]['ack'], $j[$sev]['res'])) return ['ack' => max(1, (int)$j[$sev]['ack']), 'res' => max(1, (int)$j[$sev]['res'])];
        return $d;
    }
    static function ref(): string {
        $y = date('Y'); $n = (int)DB::val('SELECT COUNT(*) FROM inc_incidents WHERE reference LIKE ?', ["INC-$y-%"]) + 1;
        while (DB::val('SELECT 1 FROM inc_incidents WHERE reference=?', [sprintf('INC-%s-%05d', $y, $n)])) $n++;
        return sprintf('INC-%s-%05d', $y, $n);
    }

    // ------------------------------------------------------------------ Calendrier d'exploitation et heures perdues
    static function window(): array {
        $days = array_values(array_filter(array_map('intval', explode(',', (string)self::set('inc.open_days'))), fn($d) => $d >= 1 && $d <= 7));
        $o = max(0, min(23, (int)self::set('inc.open_hour'))); $c = max($o + 1, min(24, (int)self::set('inc.close_hour')));
        return [$o, $c, $days ?: [1, 2, 3, 4, 5, 6]];
    }
    /** Tranches d'heures ouvrées comprises entre deux instants : liste de [date, jour ISO 1-7, heure, minutes]. */
    static function slices(int $a, int $b): array {
        $out = []; if ($b <= $a) return $out; [$o, $c, $days] = self::window();
        $d = strtotime(date('Y-m-d', $a)); $g = 0;
        while ($d < $b && $g++ < 400) {
            if (in_array((int)date('N', $d), $days, true)) {
                for ($h = $o; $h < $c; $h++) { $s = max($a, $d + $h * 3600); $e = min($b, $d + ($h + 1) * 3600); if ($e > $s) $out[] = [date('Y-m-d', $d), (int)date('N', $d), $h, intdiv($e - $s, 60) + (($e - $s) % 60 >= 30 ? 1 : 0)]; }
            }
            $d = strtotime('+1 day', $d);
        }
        return $out;
    }
    static function workMinutes(int $a, int $b): int { return array_sum(array_column(self::slices($a, $b), 3)); }
    /** Jours ouvrés (dates) d'une période, jusqu'à aujourd'hui. */
    static function workdays(int $from, int $to): array {
        [, , $days] = self::window(); $out = []; $to = min($to, time()); $d = strtotime(date('Y-m-d', $from));
        for ($g = 0; $d <= $to && $g < 800; $g++, $d = strtotime('+1 day', $d)) if (in_array((int)date('N', $d), $days, true)) $out[] = date('Y-m-d', $d);
        return $out;
    }
    /** Fenêtre [début, fin] (timestamps) d'une ligne d'impact : ses propres bornes, sinon celles de l'incident ; fin = maintenant si l'incident est ouvert. */
    static function impactWindow(array $imp, array $inc, ?int $now = null): array {
        $now = $now ?? time();
        $a = strtotime((string)($imp['started_at'] ?: $inc['started_at']));
        $end = $imp['ended_at'] ?: ($inc['resolved_at'] ?: null);
        $b = $end ? strtotime((string)$end) : $now;
        return [$a, max($a, $b)];
    }
    static function impactHours(array $imp, array $inc, ?int $now = null): float {
        [$a, $b] = self::impactWindow($imp, $inc, $now);
        return round(self::workMinutes($a, $b) / 60 * (int)$imp['agents_impacted'] * max(0, min(100, (int)$imp['capacity_loss_pct'])) / 100, 2);
    }

    /** Recalcule les agrégats d'un incident (heures perdues, durée, minutes-utilisateurs). */
    static function refresh(int $id): void {
        $inc = DB::one('SELECT * FROM inc_incidents WHERE id=?', [$id]); if (!$inc) return;
        $lost = 0.0; $ag = 0;
        foreach (DB::all('SELECT * FROM inc_impacts WHERE incident_id=?', [$id]) as $imp) {
            $h = $inc['status'] === 'cancelled' ? 0.0 : self::impactHours($imp, $inc); $lost += $h; $ag += (int)$imp['agents_impacted'];
            if ((float)$imp['lost_hours'] !== $h) DB::update('inc_impacts', ['lost_hours' => $h], 'id=?', [(int)$imp['id']]);
        }
        $a = strtotime((string)$inc['started_at']); $b = $inc['resolved_at'] ? strtotime((string)$inc['resolved_at']) : time();
        $dur = max(0, intdiv($b - $a, 60));
        DB::update('inc_incidents', ['lost_hours' => round($lost, 2), 'agents_impacted' => $ag, 'duration_min' => $dur, 'user_minutes' => (int)$inc['customers_impacted'] * $dur, 'updated_at' => now()], 'id=?', [$id]);
    }
    /** Incidents encore ouverts : leur durée et leurs heures perdues augmentent avec le temps. */
    static function refreshOpen(): void {
        foreach (DB::all("SELECT id FROM inc_incidents WHERE status IN ('new','ack','diag','mitigated') OR (resolved_at IS NULL AND status<>'cancelled')") as $r) self::refresh((int)$r['id']);
    }
    static function event(int $id, string $kind, string $body, ?int $uid = null, ?string $at = null): void {
        $uid = $uid ?? (Auth::id() ?: null);
        DB::insert('inc_events', ['incident_id' => $id, 'user_id' => $uid, 'user_name' => $uid ? (string)DB::val('SELECT name FROM users WHERE id=?', [$uid]) : 'Système', 'kind' => $kind, 'body' => mb_substr($body, 0, 2000), 'created_at' => $at ?? now()]);
    }

    /** Échéances SLA d'un incident : [prise en charge, rétablissement] (timestamps) et état. */
    static function slaState(array $i): array {
        $s = self::sla($i['severity']); $t0 = strtotime((string)($i['detected_at'] ?: $i['created_at'] ?: $i['started_at']));
        $ackDue = $t0 + $s['ack'] * 60; $resDue = $t0 + $s['res'] * 60;
        $ack = $i['acked_at'] ? strtotime((string)$i['acked_at']) : null; $res = $i['resolved_at'] ? strtotime((string)$i['resolved_at']) : null; $now = time();
        $open = in_array($i['status'], self::OPEN, true);
        return ['ack_due' => $ackDue, 'res_due' => $resDue, 'ack_ok' => $ack ? $ack <= $ackDue : null, 'res_ok' => $res ? $res <= $resDue : null,
                'ack_late' => !$ack && $i['status'] === 'new' && $now > $ackDue, 'res_late' => $open && $now > $resDue];
    }
    static function slaBadge(array $i): string {
        $s = self::slaState($i);
        if (in_array($i['status'], ['cancelled'], true)) return '';
        if ($s['res_late']) return badge('Délai dépassé', 'danger');
        if ($s['ack_late']) return badge('Prise en charge en retard', 'warning');
        if (in_array($i['status'], self::OPEN, true)) { $m = intdiv($s['res_due'] - time(), 60); return '<span class="small text-muted">reste ' . self::dur(max(0, $m)) . '</span>'; }
        return $s['res_ok'] === false ? badge('SLA non tenu', 'danger') : ($s['res_ok'] ? badge('SLA tenu', 'success') : '');
    }
    static function dur($min): string {
        if ($min === null) return '—'; $min = (int)round((float)$min); if ($min < 60) return $min . ' min'; $h = intdiv($min, 60); $m = $min % 60;
        if ($h < 48) return $h . ' h' . ($m ? ' ' . sprintf('%02d', $m) : ''); return intdiv($h, 24) . ' j ' . ($h % 24) . ' h';
    }
    static function nf($v, int $dec = 0): string { return number_format((float)$v, $dec, ',', ' '); }

    // ------------------------------------------------------------------ Chargement et agrégation
    static function headcount(): array {
        $o = [];
        foreach (DB::all("SELECT e.team_id, COUNT(*) n FROM employees e WHERE e.status='active' AND e.team_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM employees s WHERE s.manager_id=e.id AND s.status='active') GROUP BY e.team_id") as $r) $o[(int)$r['team_id']] = (int)$r['n'];
        return $o;
    }
    /** Filtre commun (liste, tableau de bord, exports) → [where, params]. */
    static function where(array $f, string $a = 'i'): array {
        $w = ["$a.status<>'cancelled'"]; $p = [];
        if (!empty($f['from'])) { $w[] = "$a.started_at>=?"; $p[] = $f['from'] . ' 00:00:00'; }
        if (!empty($f['to'])) { $w[] = "$a.started_at<=?"; $p[] = $f['to'] . ' 23:59:59'; }
        foreach (['family' => 'family', 'service' => 'service', 'category_id' => 'category_id', 'store_id' => 'store_id'] as $k => $col) if (!empty($f[$k])) { $w[] = "$a.$col=?"; $p[] = $f[$k]; }
        if (!empty($f['severity'])) { if ($f['severity'] === 'P12') $w[] = "$a.severity IN ('P1','P2')"; else { $w[] = "$a.severity=?"; $p[] = $f['severity']; } }
        if (($f['outage'] ?? '') !== '') { $w[] = "$a.outage=?"; $p[] = (int)$f['outage']; }
        if (!empty($f['team_id'])) { $w[] = "EXISTS (SELECT 1 FROM inc_impacts x WHERE x.incident_id=$a.id AND x.team_id=?)"; $p[] = (int)$f['team_id']; }
        if (!empty($f['channel_id'])) { $w[] = "($a.channel_id=? OR EXISTS (SELECT 1 FROM inc_impacts x WHERE x.incident_id=$a.id AND x.channel_id=?))"; $p[] = (int)$f['channel_id']; $p[] = (int)$f['channel_id']; }
        return [implode(' AND ', $w), $p];
    }
    /** Créneau : heure de début de l'incident dans [h1, h2[ (h1 > h2 = créneau de nuit, ex. 20 → 6) et jours de semaine (1 = lundi … 7 = dimanche). */
    static function slotOk(string $startedAt, $h1, $h2, array $dow): bool {
        $t = strtotime($startedAt); if ($dow && !in_array((int)date('N', $t), $dow, true)) return false;
        if ($h1 === '' || $h1 === null || $h2 === '' || $h2 === null || (int)$h1 === (int)$h2) return true;
        $h = (int)date('G', $t); $a = (int)$h1; $b = (int)$h2;
        return $a < $b ? ($h >= $a && $h < $b) : ($h >= $a || $h < $b);
    }
    static function dowList($v): array { return array_values(array_unique(array_filter(array_map('intval', explode(',', (string)$v)), fn($x) => $x >= 1 && $x <= 7))); }
    static function slotLabel(array $f): string {
        $o = []; $d = self::dowList($f['dow'] ?? '');
        if (($f['h1'] ?? '') !== '' && ($f['h2'] ?? '') !== '' && (int)$f['h1'] !== (int)$f['h2']) $o[] = sprintf('%02dh–%02dh', (int)$f['h1'], (int)$f['h2']);
        if ($d && count($d) < 7) { $n = [1 => 'lun', 2 => 'mar', 3 => 'mer', 4 => 'jeu', 5 => 'ven', 6 => 'sam', 7 => 'dim']; $o[] = implode(', ', array_map(fn($x) => $n[$x], $d)); }
        return implode(' · ', $o);
    }
    static function fetch(array $f): array {
        [$w, $p] = self::where($f);
        $rows = DB::all("SELECT i.* FROM inc_incidents i WHERE $w ORDER BY i.started_at", $p); $by = [];
        $dow = self::dowList($f['dow'] ?? ''); if ((($f['h1'] ?? '') !== '' && ($f['h2'] ?? '') !== '') || $dow) $rows = array_values(array_filter($rows, fn($r) => self::slotOk($r['started_at'], $f['h1'] ?? '', $f['h2'] ?? '', $dow)));
        foreach ($rows as &$r) { $r['imps'] = []; $by[(int)$r['id']] = &$r; } unset($r);
        if ($by) foreach (array_chunk(array_keys($by), 400) as $ch) foreach (DB::all('SELECT * FROM inc_impacts WHERE incident_id IN (' . implode(',', array_map('intval', $ch)) . ')') as $imp) $by[(int)$imp['incident_id']]['imps'][] = $imp;
        return $rows;
    }
    static function mean(array $v): ?float { $v = array_values(array_filter($v, fn($x) => $x !== null)); return $v ? array_sum($v) / count($v) : null; }
    static function quantile(array $v, float $q): float {
        if (!$v) return 0.0; sort($v); $n = count($v); $pos = ($n - 1) * $q; $lo = (int)floor($pos); $hi = (int)ceil($pos);
        return (float)($v[$lo] + ($v[$hi] - $v[$lo]) * ($pos - $lo));
    }
    /** Union de plages [début, fin] : minutes distinctes couvertes. */
    static function unionMinutes(array $iv): int {
        usort($iv, fn($x, $y) => $x[0] <=> $y[0]); $tot = 0; $cs = null; $ce = null;
        foreach ($iv as [$s, $e]) { if ($e <= $s) continue; if ($cs === null) { $cs = $s; $ce = $e; } elseif ($s <= $ce) $ce = max($ce, $e); else { $tot += $ce - $cs; $cs = $s; $ce = $e; } }
        if ($cs !== null) $tot += $ce - $cs; return intdiv($tot, 60);
    }

    /** Indicateurs d'une liste d'incidents sur la période [from, to] (timestamps). */
    static function kpis(array $rows, int $from, int $to): array {
        $now = time(); $end = min($to, $now); $hc = self::headcount(); $heads = array_sum($hc);
        $k = ['n' => count($rows), 'p1p2' => 0, 'lost' => 0.0, 'customers' => 0, 'calls' => 0, 'tx' => 0, 'revenue' => 0.0, 'user_min' => 0.0, 'recurring' => 0, 'major' => 0, 'agents' => 0];
        $ack = $det = $res = $ackOk = $ackN = $resOk = $resN = [];
        foreach ($rows as $r) {
            if (in_array($r['severity'], ['P1', 'P2'], true)) $k['p1p2']++;
            $k['lost'] += (float)$r['lost_hours']; $k['customers'] += (int)$r['customers_impacted']; $k['calls'] += (int)$r['calls_lost']; $k['tx'] += (int)$r['tx_failed']; $k['revenue'] += (float)$r['revenue_loss'];
            $k['user_min'] += (float)$r['user_minutes']; $k['recurring'] += (int)$r['recurring']; $k['major'] += (int)$r['major']; $k['agents'] += (int)$r['agents_impacted'];
            $s = self::slaState($r);
            if ($r['acked_at']) { $ack[] = max(0, (strtotime($r['acked_at']) - strtotime($r['detected_at'] ?: $r['started_at'])) / 60); $ackN[] = 1; if ($s['ack_ok']) $ackOk[] = 1; }
            if ($r['detected_at']) $det[] = (strtotime($r['detected_at']) - strtotime($r['started_at'])) / 60;
            if ($r['resolved_at']) { $res[] = (strtotime($r['resolved_at']) - strtotime($r['started_at'])) / 60; $resN[] = 1; if ($s['res_ok']) $resOk[] = 1; }
        }
        $days = max(1, count(self::workdays($from, $to))); $shift = max(1.0, self::num('inc.shift_hours'));
        $k['mtta'] = self::mean($ack); $k['mttd'] = self::mean($det); $k['mttr'] = self::mean($res); $k['mttr_p90'] = $res ? self::quantile($res, .9) : null;
        $k['sla_ack'] = $ackN ? round(count($ackOk) / count($ackN) * 100, 1) : null; $k['sla_res'] = $resN ? round(count($resOk) / count($resN) * 100, 1) : null;
        $k['fte'] = $k['lost'] / ($shift * $days); $k['cost'] = $k['lost'] * self::num('inc.hourly_cost'); $k['days'] = $days; $k['heads'] = $heads;
        $k['per100'] = $heads ? round($k['n'] / $heads * 100, 1) : null; $k['loss_pct'] = $heads ? round($k['lost'] / ($heads * $shift * $days) * 100, 2) : null;
        $k['recur_pct'] = $k['n'] ? round($k['recurring'] / $k['n'] * 100) : null;
        return $k;
    }

    /** Disponibilité et fiabilité par service d'abonnés (24 h / 24) : pannes totales fusionnées, MTBF, MTTR, minutes-utilisateurs. */
    static function availability(array $rows, int $from, int $to): array {
        $end = min($to, time()); $span = max(1, intdiv($end - $from, 60)); $out = [];
        $svcs = self::KEY_SERVICES; foreach ($rows as $r) if (!in_array($r['service'], $svcs, true) && $r['service']) $svcs[] = $r['service'];
        foreach ($svcs as $sv) {
            $iv = []; $n = 0; $deg = 0; $mttr = []; $um = 0.0; $cnt = 0;
            foreach ($rows as $r) { if ($r['service'] !== $sv) continue; $cnt++;
                $a = max($from, strtotime($r['started_at'])); $b = $r['resolved_at'] ? min($end, strtotime($r['resolved_at'])) : $end;
                if ((int)$r['outage']) { $iv[] = [$a, $b]; $n++; if ($r['resolved_at']) $mttr[] = (strtotime($r['resolved_at']) - strtotime($r['started_at'])) / 60; $um += (float)$r['user_minutes']; }
                else $deg += max(0, intdiv($b - $a, 60)); }
            $down = self::unionMinutes($iv);
            $out[$sv] = ['n' => $cnt, 'outages' => $n, 'down' => $down, 'degraded' => $deg, 'avail' => round(max(0, 100 - $down / $span * 100), 3), 'mtbf' => $n ? round(($span - $down) / $n) : null, 'mttr' => self::mean($mttr), 'user_min' => $um];
        }
        return $out;
    }

    /** Heures-agent perdues par équipe et par jour, par créneau (jour x heure) et par canal. */
    static function productivity(array $rows, int $from, int $to): array {
        $now = time(); $teamDay = []; $heat = []; $chan = []; $teamLost = []; $teamInc = [];
        foreach ($rows as $r) foreach ($r['imps'] as $imp) {
            [$a, $b] = self::impactWindow($imp, $r, $now); $a = max($a, $from); $b = min($b, $to, $now); if ($b <= $a) continue;
            $f = (int)$imp['agents_impacted'] * max(0, min(100, (int)$imp['capacity_loss_pct'])) / 100 / 60; $t = (int)($imp['team_id'] ?: 0);
            foreach (self::slices($a, $b) as [$day, $dow, $h, $m]) {
                $x = $m * $f; $teamDay[$t][$day] = ($teamDay[$t][$day] ?? 0) + $x; $heat[$dow][$h] = ($heat[$dow][$h] ?? 0) + $x;
                if (!empty($imp['channel_id'])) $chan[(int)$imp['channel_id']] = ($chan[(int)$imp['channel_id']] ?? 0) + $x;
                $teamLost[$t] = ($teamLost[$t] ?? 0) + $x;
            }
            $teamInc[$t][(int)$r['id']] = 1;
        }
        return ['teamDay' => $teamDay, 'heat' => $heat, 'chan' => $chan, 'teamLost' => $teamLost, 'teamInc' => array_map('count', $teamInc)];
    }

    /** Aide au redimensionnement : par équipe, FTE perdus (moyenne, pic, centile de couverture) et renfort recommandé. */
    static function sizing(array $rows, int $from, int $to, float $cov = 0.9): array {
        $P = self::productivity($rows, $from, $to); $hc = self::headcount(); $shift = max(1.0, self::num('inc.shift_hours')); $days = self::workdays($from, $to); $nd = max(1, count($days));
        $names = []; foreach (DB::all('SELECT t.id, t.name, t.channel_id, c.name AS channel FROM teams t LEFT JOIN channels c ON c.id=t.channel_id') as $t) $names[(int)$t['id']] = $t;
        $out = [];
        foreach ($P['teamDay'] as $tid => $byDay) {
            $series = []; foreach ($days as $d) $series[] = ($byDay[$d] ?? 0) / $shift; $tot = array_sum($byDay); $H = $hc[$tid] ?? 0;
            $q = self::quantile($series, $cov); $avg = $tot / $shift / $nd; $max = $series ? max($series) : 0;
            $out[] = ['team_id' => $tid, 'team' => $tid ? ($names[$tid]['name'] ?? ('Équipe #' . $tid)) : 'Non rattaché', 'channel' => $tid ? ($names[$tid]['channel'] ?? '') : '', 'heads' => $H, 'incidents' => $P['teamInc'][$tid] ?? 0,
                'lost' => $tot, 'loss_pct' => $H ? $tot / ($H * $shift * $nd) * 100 : null, 'avg_fte' => $avg, 'max_fte' => $max, 'q_fte' => $q, 'hit_days' => count(array_filter($series, fn($v) => $v > 0.01)),
                'reco' => (int)ceil($q - 0.05), 'reco_pct' => $H ? ceil($q - 0.05) / $H * 100 : null, 'cost' => $tot * self::num('inc.hourly_cost')];
        }
        usort($out, fn($a, $b) => $b['lost'] <=> $a['lost']);
        return ['rows' => $out, 'days' => $nd, 'heat' => $P['heat'], 'chan' => $P['chan'], 'cov' => $cov];
    }

    /** Tendance hebdomadaire (lundi) : incidents par gravité, heures perdues, MTTR. */
    static function weekly(array $rows, int $from, int $to): array {
        $w = []; $d = strtotime('monday this week', $from); $end = min($to, time());
        for ($g = 0; $d <= $end && $g < 120; $g++, $d = strtotime('+7 days', $d)) $w[date('Y-m-d', $d)] = ['label' => date('d/m', $d), 'sev' => ['P1' => 0, 'P2' => 0, 'P3' => 0, 'P4' => 0], 'lost' => 0.0, 'res' => [], 'ack' => []];
        foreach ($rows as $r) { $k = date('Y-m-d', strtotime('monday this week', strtotime($r['started_at']))); if (!isset($w[$k])) continue;
            $w[$k]['sev'][$r['severity']] = ($w[$k]['sev'][$r['severity']] ?? 0) + 1; $w[$k]['lost'] += (float)$r['lost_hours'];
            if ($r['resolved_at']) $w[$k]['res'][] = (strtotime($r['resolved_at']) - strtotime($r['started_at'])) / 60;
            if ($r['acked_at']) $w[$k]['ack'][] = (strtotime($r['acked_at']) - strtotime($r['detected_at'] ?: $r['started_at'])) / 60; }
        return $w;
    }
    /** Répartition simple : [clé => nombre] triée. */
    static function count(array $rows, callable $key): array { $o = []; foreach ($rows as $r) { $k = $key($r); if ($k === null || $k === '') continue; $o[$k] = ($o[$k] ?? 0) + 1; } arsort($o); return $o; }
    static function sum(array $rows, callable $key, callable $val): array { $o = []; foreach ($rows as $r) { $k = $key($r); if ($k === null || $k === '') continue; $o[$k] = ($o[$k] ?? 0) + $val($r); } arsort($o); return $o; }

    /** Récurrence : un incident est « récurrent » si la même catégorie a déjà été déclarée au moins N fois dans les X jours précédents. */
    static function isRecurring(?int $cat, string $startedAt, ?int $exclude = null): bool {
        if (!$cat) return false; $d = (int)self::num('inc.recur_days'); $min = (int)self::num('inc.recur_min');
        $from = date('Y-m-d H:i:s', strtotime($startedAt) - $d * 86400);
        return (int)DB::val("SELECT COUNT(*) FROM inc_incidents WHERE category_id=? AND status<>'cancelled' AND started_at>=? AND started_at<? AND id<>?", [$cat, $from, $startedAt, (int)$exclude]) >= $min;
    }
    /** Équipes avec effectif (pour les listes déroulantes et le préremplissage du nombre d'agents). */
    static function teams(): array {
        $hc = self::headcount(); $o = [];
        foreach (DB::all('SELECT t.id, t.name, t.channel_id FROM teams t WHERE t.active=1 ORDER BY t.name') as $t) { $t['heads'] = $hc[(int)$t['id']] ?? 0; $o[] = $t; }
        return $o;
    }
}
