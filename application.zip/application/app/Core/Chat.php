<?php
namespace App\Core;
/** Chat in-app rattaché à un incident (module « inc ») ou à un ticket (module « at »). */
class Chat {
    static function enabled(string $module): bool { if ($module === 'el') return Xchg::on('elearn.qna'); return in_array($module, ['inc', 'at'], true) && Xchg::on('chat.enabled_' . $module); }
    static function isManager(string $module): bool { return $module === 'el' ? can('elearn.manage') : ($module === 'inc' ? can('inc.manage') : can('at.handle')); }
    /** Écriture : gestionnaires et intervenants support toujours ; déclarant / demandeur selon le réglage `chat.requester`. */
    static function canWrite(string $module): bool { return $module === 'el' || self::isManager($module) || ($module === 'inc' && can('inc.support')) || Xchg::on('chat.requester'); }
    static function ref(string $module, int $id): string { return (string)(Meet::entity($module, $id)['ref'] ?? ''); }
    /** Utilisateurs à prévenir d'un nouveau message. @return int[] */
    static function participants(string $module, int $id): array {
        $ids = [];
        if ($module === 'el') { $t = DB::one('SELECT user_id, course_id FROM el_threads WHERE id=?', [$id]); $ids = array_merge([(int)($t['user_id'] ?? 0)], $t ? ELearn::trainers((int)$t['course_id']) : []); }
        elseif ($module === 'inc') {
            $i = DB::one('SELECT reporter_id, owner_id FROM inc_incidents WHERE id=?', [$id]); $ids = [(int)($i['reporter_id'] ?? 0), (int)($i['owner_id'] ?? 0)];
            foreach (DB::all("SELECT DISTINCT m.user_id FROM inc_support_members m JOIN inc_escalations e ON e.team_id=m.team_id WHERE e.incident_id=? AND m.active=1 AND m.user_id IS NOT NULL", [$id]) as $r) $ids[] = (int)$r['user_id'];
        } else { $t = DB::one('SELECT requester_id, assignee_id, logged_by FROM at_tickets WHERE id=?', [$id]); $ids = [(int)($t['requester_id'] ?? 0), (int)($t['assignee_id'] ?? 0), (int)($t['logged_by'] ?? 0)]; }
        foreach (DB::all('SELECT DISTINCT user_id FROM chat_messages WHERE module=? AND ref_id=? AND user_id IS NOT NULL', [$module, $id]) as $r) $ids[] = (int)$r['user_id'];
        return array_values(array_unique(array_filter($ids)));
    }
    /** Notifie dans l'outil, en regroupant : pas de nouvelle notification tant que la précédente (même fiche) n'est pas lue. */
    static function notify(string $module, int $id, int $from, string $fromName, string $body, bool $internal): void {
        if (!Xchg::on('chat.notify')) return; $ref = self::ref($module, $id); $title = 'Nouveau message · ' . $ref; $url = ($module === 'el' ? '/elearn/questions/' : ($module === 'inc' ? '/incidents/' : '/at/')) . $id . '#chat';
        foreach (self::participants($module, $id) as $uid) {
            if ($uid === $from || !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$uid])) continue;
            if ($internal && !self::userManages($module, $uid)) continue;
            if (DB::val('SELECT 1 FROM notifications WHERE user_id=? AND title=? AND url=? AND read_at IS NULL', [$uid, $title, $url])) continue;
            $u = $module === 'el' ? (self::userManages('el', $uid) ? $url : '/learn/ask/' . $id . '#chat') : ($module === 'inc' && !self::userManages($module, $uid) && !self::userCan($uid, 'inc.declare') ? '/support/incidents/' . $id . '#chat' : $url);
            Notifier::send($uid, $title, mb_substr($fromName . ' : ' . $body, 0, 200), $u);
        }
    }
    private static function userCan(int $uid, string $perm): bool { return (bool)DB::val("SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id LEFT JOIN role_permissions rp ON rp.role_id=r.id LEFT JOIN permissions p ON p.id=rp.permission_id WHERE ur.user_id=? AND (p.code=? OR p.code='*') LIMIT 1", [$uid, $perm]); }
    static function userManages(string $module, int $uid): bool { return self::userCan($uid, $module === 'el' ? 'elearn.manage' : ($module === 'inc' ? 'inc.manage' : 'at.handle')); }
}
