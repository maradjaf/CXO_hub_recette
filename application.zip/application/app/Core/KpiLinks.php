<?php
namespace App\Core;
/**
 * Cards cliquables : pour chaque tableau de bord, correspondance « libellé de la card » → liste filtrée.
 * Le navigateur (app.js, initKpi) rend cliquable toute card .kpi / .kc dont le libellé correspond à l'expression.
 */
class KpiLinks {
    const MAP = [
        'provider' => [['/effectif/i', 'provider/staff'], ['/départs sur|rotation/i', 'provider/offboarding'], ['/absent/i', 'provider/absences'], ['/échéance/i', 'provider/contracts?soon=1'], ['/intégrations/i', 'provider/onboarding'], ['/départs en cours/i', 'provider/offboarding'], ['/qualité/i', 'provider/quality'], ['/formations/i', 'provider/trainings']],
        'incidents/dashboard' => [['/ouverts actuellement/i', 'incidents?status=open'], ['/p1 \/ p2/i', 'incidents?severity=P12'], ['/majeurs/i', 'incidents?major=1'], ['/récurrence/i', 'incidents?recurring=1'], ['/sla/i', 'incidents?late=1'], ['/post-mortems/i', 'incidents?norca=1'],
            ['/heures-agent|temps plein|capacité de production|coût estimé/i', 'incidents/staffing'], ['/incidents sur la période|pour 100 agents|clients impactés|minutes-utilisateurs|transactions|appels/i', 'incidents'], ['/mttd|mtta|mttr|délai/i', 'incidents?status=resolved']],
        '' => [['/collaborateurs actifs/i', 'employees'], ['/^équipes/i', 'org/teams'], ['/^stores/i', 'org/stores'], ['/utilisateurs actifs/i', 'admin/activity']],
        'at/dashboard' => [['/tickets sur la période/i', 'at?all=1'], ['/ouverts actuellement/i', 'at'], ['/délai dépassé/i', 'at?late=1'], ['/non affectés/i', 'at?assignee=none'],
            ['/résolus dans les délais/i', 'at?all=1&status=resolved'], ['/prise en charge/i', 'at?all=1'], ['/durée moyenne/i', 'at?all=1&status=closed'], ['/satisfaction|satisfaits|enquête/i', 'at?all=1&status=closed'],
            ['/réouverts/i', 'at?all=1'], ['/escaladés/i', 'at?all=1&escalated=1'], ['/n2\/n3/i', 'at?all=1&tier=2'], ['/prestataire/i', 'at?ext=1'], ['/enfants/i', 'at?all=1']],
        'at/stock' => [['/valeur du stock/i', 'at/stock']],
        'absences' => [['/taux d.absent/i', 'absences/stats'], ['/jours d.absence/i', 'absences/stats']],
        'leave' => [['/restant/i', 'leave/new']],
        'ca/dashboard' => [['/contrôles terminés|conformité/i', 'ca/controls'], ['/écarts critiques/i', 'ca/controls'], ['/contrôles en retard/i', 'ca/schedules'], ['/actions en retard/i', 'ca/actions'], ['/actions ouvertes/i', 'ca/actions'], ['/à vérifier|actions vérifiées/i', 'ca/actions']],
        'cx/dashboard' => [['/visites validées|score moyen|attente moyenne/i', 'cx/visits'], ['/écarts critiques/i', 'cx/visits'], ['/tests|réussis|dégradés|échec/i', 'cx/runs'], ['/action/i', 'cx/actions']],
        'pr/dashboard' => [['/publiés|relecture|brouillons|revues|pilote|demandes/i', 'pr']],
        'pj' => [['/projets|planifiés|santé|bloquants|décisions|points hebdo/i', 'pj/projects']],
        'trainings/dashboard' => [['/sessions|heures|formés|présence|réussite|satisfaction/i', 'trainings']],
        'elearn/stats' => [['/tentatives|note moyenne/i', 'elearn/report']],
        'elearn/report' => [['/./', 'elearn']],
        'qa' => [['/évaluations|note moyenne|éliminatoires/i', 'qa']],
        'qa/scoreboard' => [['/évaluations|conseillers|notes|note globale/i', 'qa']],
        'qa/dashboard' => [['/évaluations|score|conformité|coaching|débrief/i', 'qa']],
        'qa/portfolio' => [['/conseillers|avancement/i', 'qa/portfolios']],
        'qa/coachings' => [['/./', 'qa/coachings']],
        'ag/campaigns' => [['/./', 'ag/review']],
        'eoc' => [['/./', 'eoc']],
    ];
    static function forCurrent(): array {
        $path = trim((string)parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/');
        $b = trim(base_path(), '/'); if ($b !== '' && str_starts_with($path, $b)) $path = trim(substr($path, strlen($b)), '/');
        if (str_starts_with($path, 'index.php')) $path = trim(substr($path, 9), '/');
        $key = null; foreach (array_keys(self::MAP) as $k) if ($k === $path || ($k !== '' && preg_match('#^' . preg_quote($k, '#') . '/\d+(/|$)#', $path))) $key = $k;
        if ($key === null && preg_match('#^(ag/campaigns|elearn|eoc)/\d+#', $path, $m)) $key = $m[1] === 'elearn' ? 'elearn/stats' : $m[1];
        if ($key === null) return [];
        $out = []; foreach (self::MAP[$key] as [$re, $to]) $out[] = [substr($re, 1, strrpos($re, '/') - 1), url($to)];
        return $out;
    }
}
