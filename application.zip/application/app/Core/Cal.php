<?php
namespace App\Core;

/** Calibrage des évaluations qualité : cotation indépendante, référence arbitrée, mesures d'alignement. */
class Cal {
    const SEV = ['none' => 'Aucune', 'minor' => 'Mineure', 'major' => 'Majeure', 'critical' => 'Critique'];
    const ST = ['draft' => 'Préparation', 'scoring' => 'Cotation en cours', 'arbitration' => 'Arbitrage', 'closed' => 'Clôturé'];
    const TYPE = ['call' => 'Appel', 'visit' => 'Visite', 'ticket' => 'Dossier support'];
    const VAL = ['keep' => 'Scores maintenus', 'reserve' => 'Scores sous réserve', 'redo' => 'Évaluations à reprendre'];
    const PST = ['todo' => 'Planifié', 'doing' => 'En cours', 'done' => 'Terminé', 'late' => 'En retard'];

    static function nextRef(): string { $y = date('Y'); $n = (int)DB::val("SELECT COUNT(*) FROM cal_sessions WHERE ref LIKE ?", ["CAL-$y-%"]) + 1; return sprintf('CAL-%s-%03d', $y, $n); }
    static function criteria(int $sid): array { return DB::all('SELECT c.* FROM qa_criteria c JOIN cal_sessions s ON s.grid_id=c.grid_id WHERE s.id=? ORDER BY c.position', [$sid]); }
    static function raterName(int $uid): string { return $uid === 0 ? 'Référence (arbitrage)' : (string)(DB::val('SELECT name FROM users WHERE id=?', [$uid]) ?: 'Utilisateur ' . $uid); }
    /** Note en % sur les critères applicables : $scores = [criterion_id => ['points'=>x,'na'=>0|1]]. */
    static function pct(array $crit, array $scores): ?float {
        $got = 0.0; $max = 0.0; foreach ($crit as $c) { $s = $scores[(int)$c['id']] ?? null; if (!$s || !empty($s['na'])) continue; $got += (float)$s['points']; $max += (float)$c['max_points']; }
        return $max > 0 ? round(100 * $got / $max, 1) : null;
    }
    static function ratingScores(int $ratingId): array { $o = []; foreach (DB::all('SELECT * FROM cal_scores WHERE rating_id=?', [$ratingId]) as $s) $o[(int)$s['criterion_id']] = ['points' => $s['points'], 'na' => (int)$s['na']]; return $o; }
    /** Enregistre (ou remplace) la cotation d'un évaluateur (0 = référence) sur un cas. */
    static function saveRating(int $caseId, int $uid, array $post, array $crit): void {
        $r = DB::one('SELECT * FROM cal_ratings WHERE case_id=? AND user_id=?', [$caseId, $uid]); $sc = [];
        foreach ($crit as $c) { $id = (int)$c['id']; $na = !empty($post['na'][$id]); $v = $post['pts'][$id] ?? ''; $sc[$id] = ['points' => $na || $v === '' ? null : max(0, min((float)$c['max_points'], (float)$v)), 'na' => $na ? 1 : 0]; if (!$na && $v === '') $sc[$id]['na'] = 1; }
        $sev = (string)($post['severity'] ?? 'none'); if (!isset(self::SEV[$sev])) $sev = 'none';
        $d = ['severity' => $sev, 'total_pct' => self::pct($crit, $sc), 'comment' => mb_substr(trim((string)($post['comment'] ?? '')), 0, 500) ?: null, 'submitted_at' => now()];
        if ($r) { DB::update('cal_ratings', $d, 'id=?', [(int)$r['id']]); $rid = (int)$r['id']; DB::exec('DELETE FROM cal_scores WHERE rating_id=?', [$rid]); } else $rid = DB::insert('cal_ratings', $d + ['case_id' => $caseId, 'user_id' => $uid]);
        foreach ($sc as $cid => $x) DB::insert('cal_scores', ['rating_id' => $rid, 'criterion_id' => $cid, 'points' => $x['points'], 'na' => $x['na']]);
    }
    /** Mesures d'alignement par rapport à la cotation de référence arbitrée. */
    static function metrics(int $sid): array {
        $crit = self::criteria($sid); $cases = DB::all('SELECT * FROM cal_cases WHERE session_id=? ORDER BY sort, id', [$sid]);
        $m = ['cases' => count($cases), 'ref_cases' => 0, 'raters' => 0, 'cmp' => 0, 'exact' => 0, 'gaps' => [], 'sev_cmp' => 0, 'sev_ok' => 0, 'sev_div_major' => 0, 'na_cmp' => 0, 'na_ok' => 0, 'by_scope' => [], 'by_crit' => [], 'by_rater' => [], 'div' => []];
        $raters = []; $cl = array_column($crit, 'label', 'id');
        foreach ($cases as $c) {
            $rt = []; foreach (DB::all('SELECT * FROM cal_ratings WHERE case_id=?', [(int)$c['id']]) as $r) $rt[(int)$r['user_id']] = $r;
            if (!isset($rt[0])) continue; $ref = $rt[0]; $m['ref_cases']++; $rs = self::ratingScores((int)$ref['id']); $sc = $c['channel'] ?: self::TYPE[$c['case_type']] ?? 'Autre';
            $S = &$m['by_scope'][$sc]; $S = $S ?? ['cases' => 0, 'cmp' => 0, 'exact' => 0, 'gaps' => [], 'sev_div' => 0]; $S['cases']++; unset($S);
            foreach ($rt as $uid => $r) { if ($uid === 0) continue; $raters[$uid] = 1; $ss = self::ratingScores((int)$r['id']);
                $R = &$m['by_rater'][$uid]; $R = $R ?? ['name' => self::raterName($uid), 'cases' => 0, 'cmp' => 0, 'exact' => 0, 'gaps' => []]; $R['cases']++;
                foreach ($crit as $k) { $id = (int)$k['id']; $m['by_crit'][$id] = ($m['by_crit'][$id] ?? []) + ['label' => $cl[$id] ?? '#' . $id, 'cmp' => 0, 'exact' => 0, 'cases' => [], 'seen' => [], 'na_div' => 0]; $a = $ss[$id] ?? null; $b = $rs[$id] ?? null; if (!$a || !$b) continue;
                    if (($a['na'] || $b['na'])) { if ($a['na'] || $b['na']) { $m['na_cmp']++; if ($a['na'] && $b['na']) $m['na_ok']++; } if ($a['na'] !== $b['na']) $m['by_crit'][$id]['na_div'] = ($m['by_crit'][$id]['na_div'] ?? 0) + 1; if ($a['na'] || $b['na']) continue; }
                    $ok = abs((float)$a['points'] - (float)$b['points']) < 0.001; $m['cmp']++; $R['cmp']++; $S = &$m['by_scope'][$sc]; $S['cmp']++; unset($S);
                    $K = &$m['by_crit'][$id]; $K['cmp']++; $K['seen'][(string)(float)$a['points']] = ($K['seen'][(string)(float)$a['points']] ?? 0) + 1;
                    if ($ok) { $m['exact']++; $R['exact']++; $K['exact']++; $m['by_scope'][$sc]['exact']++; } else $K['cases'][$c['ref']] = 1; unset($K); }
                if ($r['total_pct'] !== null && $ref['total_pct'] !== null) { $g = abs((float)$r['total_pct'] - (float)$ref['total_pct']); $m['gaps'][] = $g; $R['gaps'][] = $g; $m['by_scope'][$sc]['gaps'][] = $g; }
                $m['sev_cmp']++; if ($r['severity'] === $ref['severity']) $m['sev_ok']++; elseif (in_array($r['severity'], ['major', 'critical'], true) || in_array($ref['severity'], ['major', 'critical'], true)) { $m['sev_div_major']++; $m['by_scope'][$sc]['sev_div']++; }
                unset($R); }
        }
        $m['raters'] = count($raters); $pc = fn($a, $b) => $b ? round(100 * $a / $b, 1) : null; $av = fn($g) => $g ? round(array_sum($g) / count($g), 1) : null;
        $m['exact_pct'] = $pc($m['exact'], $m['cmp']); $m['gap_avg'] = $av($m['gaps']); $m['sev_pct'] = $pc($m['sev_ok'], $m['sev_cmp']); $m['na_pct'] = $pc($m['na_ok'], $m['na_cmp']);
        foreach ($m['by_scope'] as &$s) { $s['exact_pct'] = $pc($s['exact'], $s['cmp']); $s['gap_avg'] = $av($s['gaps']); } unset($s);
        foreach ($m['by_rater'] as &$s) { $s['exact_pct'] = $pc($s['exact'], $s['cmp']); $s['gap_avg'] = $av($s['gaps']); } unset($s);
        foreach ($m['by_crit'] as &$s) { $s['exact_pct'] = $s['cmp'] ? $pc($s['exact'], $s['cmp']) : null; } unset($s);
        uasort($m['by_crit'], fn($a, $b) => ($a['exact_pct'] ?? 101) <=> ($b['exact_pct'] ?? 101));
        return $m;
    }
}
