<?php
namespace App\Core;
class Request {
    static function method(): string { return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET'); }
    static function path(): string {
        $p = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        $b = base_path();
        if ($b !== '' && str_starts_with($p, $b)) $p = substr($p, strlen($b));
        if (str_starts_with($p, '/index.php')) $p = substr($p, 10);   // mode sans réécriture : /index.php/chemin
        return '/' . trim($p, '/');
    }
    static function ip(): string {
        if (env('TRUST_PROXY') && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    static function ua(): string { return $_SERVER['HTTP_USER_AGENT'] ?? ''; }
    static function in(string $k, $d = null) { return $_POST[$k] ?? $_GET[$k] ?? $d; }
}
