<?php
namespace App\Core;
class Notifier {
    static function send(int $userId, string $title, string $body = '', string $url = ''): void {
        DB::insert('notifications', ['user_id' => $userId, 'title' => $title, 'body' => $body, 'url' => $url, 'created_at' => now()]);
        if (preg_match('#^/at/(\d+)$#', $url, $m)) { try { Mailer::queueTicketNotice($userId, $title, $body, (int)$m[1]); } catch (\Throwable $e) {} }   // copie par e-mail si l'envoi SMTP est configuré
    }
    static function toPermission(string $perm, string $title, string $body = '', string $url = ''): void {
        $ids = DB::all("SELECT DISTINCT ur.user_id FROM user_roles ur JOIN roles r ON r.id=ur.role_id LEFT JOIN role_permissions rp ON rp.role_id=r.id LEFT JOIN permissions p ON p.id=rp.permission_id WHERE r.code='admin' OR p.code=?", [$perm]);
        foreach ($ids as $r) self::send((int)$r['user_id'], $title, $body, $url);
    }
    static function unread(): int { return Auth::id() ? (int)DB::val('SELECT COUNT(*) FROM notifications WHERE user_id=? AND read_at IS NULL', [Auth::id()]) : 0; }
}
