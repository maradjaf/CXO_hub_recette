<?php
namespace App\Core;

/** Mise en page des rapports « diapositives » (format Yas Togo) : page, indicateurs, tableaux, statuts, zones de commentaire. */
class Rp {
    private static int $n = 0;
    const ST = ['ok' => ['Atteint', '#2E8B57'], 'warn' => ['Vigilance', '#E0A800'], 'ko' => ['Écart', '#C0392B'], 'na' => ['—', '#9AA5B5'], 'up' => ['Hausse', '#2E8B57'], 'down' => ['Baisse', '#C0392B'], 'flat' => ['Stable', '#6B7788']];
    static function css(): string {
        return '<style>.kcs{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;margin-top:22px}.kc{background:#E6EEF8;border-radius:8px;padding:16px 18px}.kc b{display:block;font-size:36px;font-weight:800;line-height:1.1;color:#003A84}.kc span{display:block;font-weight:700;margin-top:2px}.kc small{display:block;color:#6B7788;margin-top:3px}
.kc.y{background:#FFF4C2}.kc.y b{color:#172033}.tb{width:100%;border-collapse:separate;border-spacing:6px 5px;margin-top:20px}.tb th{background:#003A84;color:#fff;padding:8px 8px;font-size:12px;text-align:center}.tb td{background:#F1F4F9;padding:8px 10px;vertical-align:middle}.tb td.c{text-align:center}.tb td.n{text-align:right;font-variant-numeric:tabular-nums}
.sp{white-space:nowrap;display:inline-block;border-radius:999px;padding:3px 12px;font-weight:700;font-size:11px;color:#fff}.nb{background:#F1F4F9;border-left:5px solid #FFCE00;border-radius:6px;padding:12px 16px;margin-top:16px;white-space:pre-line;min-height:48px}.nb h4{margin:0 0 4px;font-size:13px;color:#003A84;font-weight:800}
.ns{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:16px}.slide .chart{margin-top:14px}.fn{position:absolute;left:40px;bottom:14px;color:#6B7788;font-size:11px}.ed{margin-top:8px}.ed textarea{width:100%;font-size:12px}@media print{.ed{display:none}}</style>';
    }
    static function open(string $title, string $sub = ''): string { self::$n++; return '<section class="slide"><h1>' . e($title) . '</h1>' . ($sub !== '' ? '<div class="sub">' . e($sub) . '</div>' : '') . '<img class="brand" src="' . asset('logo.png') . '" alt="Logo">'; }
    static function close(): string { return '<div class="fn">Yas Togo • Direction CX &amp; Opérations • Confidentiel</div><div class="pg">' . str_pad((string)self::$n, 2, '0', STR_PAD_LEFT) . '</div></section>'; }
    static function reset(): void { self::$n = 0; }
    static function kpi(string $v, string $l, string $sub = '', bool $y = false): string { return '<div class="kc' . ($y ? ' y' : '') . '"><b>' . e($v) . '</b><span>' . e($l) . '</span>' . ($sub !== '' ? '<small>' . e($sub) . '</small>' : '') . '</div>'; }
    static function status(string $k): string { [$l, $c] = self::ST[$k] ?? self::ST['na']; return '<span class="sp" style="background:' . $c . '">' . $l . '</span>'; }
    /** Tableau ; une cellule peut être ['h' => html brut]. $num = indices de colonnes alignées à droite. */
    static function table(array $head, array $rows, array $num = [], string $empty = 'Aucune donnée sur la période.'): string {
        $o = '<table class="tb"><thead><tr>'; foreach ($head as $h) $o .= '<th>' . e($h) . '</th>'; $o .= '</tr></thead><tbody>';
        foreach ($rows as $r) { $o .= '<tr>'; foreach (array_values($r) as $i => $c) $o .= '<td class="' . (in_array($i, $num, true) ? 'n' : '') . '">' . (is_array($c) ? $c['h'] : e((string)$c)) . '</td>'; $o .= '</tr>'; }
        if (!$rows) $o .= '<tr><td colspan="' . count($head) . '" class="c">' . e($empty) . '</td></tr>';
        return $o . '</tbody></table>';
    }
    static function pct($v, int $dec = 1): string { return $v === null ? '—' : str_replace('.', ',', (string)round((float)$v, $dec)) . ' %'; }
    static function num($v, int $dec = 1): string { return $v === null ? '—' : str_replace('.', ',', (string)round((float)$v, $dec)); }
    static function delta($a, $b, string $unit = ''): string { if ($a === null || $b === null) return '—'; $d = round((float)$a - (float)$b, 1); return ($d > 0 ? '+' : '') . str_replace('.', ',', (string)$d) . $unit; }
    static function trend($a, $b): string { if ($a === null || $b === null) return self::status('na'); $d = (float)$a - (float)$b; return self::status(abs($d) < 0.05 ? 'flat' : ($d > 0 ? 'up' : 'down')); }
    /** Zone de commentaire éditable (texte enregistré par période) + formulaire pour les gestionnaires. */
    static function note(string $scope, string $period, string $k, string $title, bool $edit, string $back, string $hint = ''): string {
        $t = Tr::note($scope, $period, $k); $o = '<div class="nb"><h4>' . e($title) . '</h4>' . ($t !== '' ? e($t) : '<span class="text-muted">' . e($hint ?: '—') . '</span>') . '</div>';
        if ($edit) $o .= '<form class="ed no-print" method="post" action="' . url('reports/note') . '">' . csrf_field() . '<input type="hidden" name="scope" value="' . e($scope) . '"><input type="hidden" name="period" value="' . e($period) . '"><input type="hidden" name="k" value="' . e($k) . '"><input type="hidden" name="back" value="' . e($back) . '"><textarea name="body" rows="2" maxlength="2000" placeholder="Modifier : ' . e($title) . '">' . e($t) . '</textarea><button class="btn btn-sm btn-outline-primary mt-1">Enregistrer</button></form>'; 
        return $o;
    }
    static function bar(string $title, string $back, string $extra = ''): string {
        return '<div class="rp-bar no-print"><a class="btn btn-light btn-sm" href="' . e($back) . '">‹ Retour</a>' . $extra . '<button class="btn btn-primary btn-sm" onclick="window.print()">Imprimer / PDF</button><button class="btn btn-warning btn-sm" type="button" onclick="CXO.exportSlides(' . e(json_encode($title)) . ')">PowerPoint</button></div><script src="' . asset('app.js') . '?v=25"></script>';
    }
}
