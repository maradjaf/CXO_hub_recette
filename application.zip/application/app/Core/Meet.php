<?php
namespace App\Core;
/**
 * Appels et visioconférences planifiés depuis un ticket (module « at ») ou un incident (module « inc »).
 * L'outil ne crée pas la réunion chez Teams / Zoom / Google Meet / WhatsApp (pas de compte ni d'API reliés) : l'organisateur la crée dans l'outil de son choix
 * (boutons de raccourci) et colle le lien ; l'invitation (date, durée, lien, ordre du jour) est ensuite envoyée à chaque participant
 * dans l'outil, par e-mail (avec fichier d'agenda .ics) et par SMS, avec un rappel 15 minutes avant.
 */
class Meet {
    /** code => [libellé, page de création, domaines admis pour le lien] */
    const PLATFORMS = [
        'teams' => ['Microsoft Teams', 'https://teams.microsoft.com/l/meeting/new', ['teams.microsoft.com', 'teams.live.com', 'teams.cloud.microsoft']],
        'zoom' => ['Zoom', 'https://zoom.us/meeting/schedule', ['zoom.us', 'zoom.com']],
        'meet' => ['Google Meet', 'https://meet.google.com/new', ['meet.google.com']],
        'whatsapp' => ['WhatsApp (appel ou visio)', 'https://web.whatsapp.com/', ['call.whatsapp.com', 'wa.me', 'chat.whatsapp.com', 'whatsapp.com']],
        'phone' => ['Appel téléphonique', null, []], 'other' => ['Autre outil', null, []],
    ];
    const STATUS = ['planned' => 'Planifié', 'done' => 'Tenu', 'cancelled' => 'Annulé'];
    const DURATIONS = [15, 30, 45, 60, 90, 120, 180];
    static function label(string $p): string { return self::PLATFORMS[$p][0] ?? $p; }
    static function linkError(string $platform, string $link, string $dial): ?string {
        if (!isset(self::PLATFORMS[$platform])) return 'Outil de réunion invalide.';
        if ($platform === 'phone') return $dial === '' && $link === '' ? 'Indiquez le numéro à appeler ou le pont téléphonique.' : null;
        if ($link === '') return $platform === 'other' && $dial !== '' ? null : 'Collez le lien de la réunion (créée dans ' . self::label($platform) . ').';
        $u = parse_url($link); if (!$u || !in_array(strtolower($u['scheme'] ?? ''), ['https', 'http'], true) || empty($u['host'])) return 'Le lien de la réunion doit commencer par https://.';
        $hosts = self::PLATFORMS[$platform][2]; $h = strtolower($u['host']);
        if ($hosts) { foreach ($hosts as $d) if ($h === $d || str_ends_with($h, '.' . $d)) return null; return 'Ce lien ne correspond pas à ' . self::label($platform) . ' (domaine attendu : ' . $hosts[0] . ').'; }
        return null;
    }
    static function entity(string $module, int $id): ?array {
        if ($module === 'inc') { $r = DB::one('SELECT id, reference, title FROM inc_incidents WHERE id=?', [$id]); return $r ? ['ref' => $r['reference'], 'title' => $r['title'], 'url' => '/incidents/' . $id] : null; }
        if ($module === 'at') { $r = DB::one('SELECT id, reference, title FROM at_tickets WHERE id=?', [$id]); return $r ? ['ref' => $r['reference'], 'title' => $r['title'], 'url' => '/at/' . $id] : null; }
        if ($module === 'el') { $r = DB::one('SELECT t.id, c.title ctitle, u.name FROM el_threads t JOIN el_courses c ON c.id=t.course_id LEFT JOIN users u ON u.id=t.user_id WHERE t.id=?', [$id]); return $r ? ['ref' => 'Question · ' . $r['ctitle'], 'title' => $r['ctitle'], 'url' => '/elearn/questions/' . $id] : null; }
        return null;
    }
    static function enabled(string $module): bool { return Xchg::on('meet.enabled_' . $module); }
    static function canManage(string $module): bool { return self::enabled($module) && ($module === 'inc' ? can('inc.manage') : ($module === 'at' && can('at.handle'))); }
    /** Outils proposés (réglage « meet.platforms ») ; on garde l'outil d'un appel existant même s'il a été retiré ensuite. */
    static function platforms(): array { $on = Xchg::csv('meet.platforms'); return array_filter(self::PLATFORMS, fn($k) => in_array($k, $on, true), ARRAY_FILTER_USE_KEY); }
    /** Outils pour lesquels le lien peut être créé automatiquement par API. */
    static function autoCapable(string $p): bool { return in_array($p, ['zoom', 'teams'], true) && Integ::ready($p); }
    private static function userPhone(int $uid): ?string { return DB::val('SELECT e.phone FROM users u JOIN employees e ON e.id=u.employee_id WHERE u.id=?', [$uid]) ?: null; }
    /** Participants proposés. @return array<int,array{key:string,label:string,name:string,email:?string,phone:?string,user_id:?int,member_id:?int,checked:bool}> */
    static function candidates(string $module, int $id): array {
        $out = []; $add = function (string $key, string $label, array $d, bool $chk) use (&$out) { if (!isset($out[$key])) $out[$key] = ['key' => $key, 'label' => $label, 'checked' => $chk] + $d + ['email' => null, 'phone' => null, 'user_id' => null, 'member_id' => null]; };
        $u = function (?int $uid, string $role, bool $chk) use ($add) { if (!$uid) return; $r = DB::one("SELECT id, name, email FROM users WHERE id=? AND status='active'", [$uid]); if ($r) $add('u:' . $r['id'], $role, ['name' => $r['name'], 'email' => $r['email'], 'phone' => self::userPhone((int)$r['id']), 'user_id' => (int)$r['id']], $chk); };
        if ($module === 'inc') {
            $i = DB::one('SELECT reporter_id, owner_id FROM inc_incidents WHERE id=?', [$id]); if (!$i) return [];
            $u($i['owner_id'] ? (int)$i['owner_id'] : null, 'Responsable de l\'incident', true); $u($i['reporter_id'] ? (int)$i['reporter_id'] : null, 'Déclarant', true);
            foreach (DB::all("SELECT m.*, t.name AS team FROM inc_support_members m JOIN inc_support_teams t ON t.id=m.team_id JOIN inc_escalations e ON e.team_id=m.team_id AND e.incident_id=? WHERE m.active=1 AND e.status IN ('pending','ack','working','done') ORDER BY t.name, m.level, m.name", [$id]) as $m)
                $add('m:' . $m['id'], 'Support · ' . $m['team'] . ($m['level'] > 1 ? ' (niv. ' . $m['level'] . ')' : ''), ['name' => $m['name'], 'email' => $m['email'], 'phone' => $m['phone'], 'user_id' => $m['user_id'] ? (int)$m['user_id'] : null, 'member_id' => (int)$m['id']], (int)$m['level'] === 1 || (int)$m['on_call'] === 1);
        } else {
            $t = DB::one('SELECT requester_id, assignee_id, logged_by FROM at_tickets WHERE id=?', [$id]); if (!$t) return [];
            $u($t['requester_id'] ? (int)$t['requester_id'] : null, 'Demandeur', true); $u($t['assignee_id'] ? (int)$t['assignee_id'] : null, 'Technicien en charge', true); $u($t['logged_by'] ? (int)$t['logged_by'] : null, 'Ticket ouvert par', false);
        }
        return array_values($out);
    }
    /** Interprète les lignes « Nom ; e-mail ; téléphone » (invités externes). @return array{0:array,1:array} invités, erreurs */
    static function parseExtra(string $text): array {
        $g = []; $err = [];
        foreach (preg_split('/\R/', $text) as $line) {
            $line = trim($line); if ($line === '') continue; $p = array_map('trim', preg_split('/[;|\t]/', $line)); $name = $p[0] ?? ''; $em = strtolower($p[1] ?? ''); $ph = $p[2] ?? '';
            if ($name === '' || ($em !== '' && !filter_var($em, FILTER_VALIDATE_EMAIL))) { $err[] = "Invité « $line » : nom ou e-mail invalide."; continue; }
            if ($ph !== '' && !Sms::normalize($ph)) { $err[] = "Invité « $name » : téléphone invalide."; continue; }
            if ($em === '' && $ph === '') { $err[] = "Invité « $name » : indiquez un e-mail ou un téléphone."; continue; }
            $g[] = ['name' => mb_substr($name, 0, 150), 'email' => $em ?: null, 'phone' => $ph ? Sms::normalize($ph) : null, 'user_id' => null, 'member_id' => null];
        }
        return [$g, $err];
    }
    static function forEntity(string $module, int $id): array {
        $ms = DB::all('SELECT m.*, u.name AS organizer FROM meetings m LEFT JOIN users u ON u.id=m.organizer_id WHERE m.module=? AND m.ref_id=? ORDER BY m.start_at DESC', [$module, $id]);
        foreach ($ms as &$m) $m['guests'] = DB::all('SELECT * FROM meeting_guests WHERE meeting_id=? ORDER BY id', [(int)$m['id']]); unset($m); return $ms;
    }
    private static function esc(string $s): string { return str_replace(["\\", ';', ',', "\r\n", "\n"], ['\\\\', '\;', '\,', '\n', '\n'], $s); }
    private static function fold(string $l): string { $o = ''; while (strlen($l) > 73) { $o .= substr($l, 0, 73) . "\r\n "; $l = substr($l, 73); } return $o . $l; }
    static function ics(array $m, array $guests, string $method = 'REQUEST'): string {
        $e = self::entity($m['module'], (int)$m['ref_id']) ?: ['ref' => '', 'title' => '', 'url' => '']; $z = fn($t) => gmdate('Ymd\THis\Z', $t); $s = strtotime($m['start_at']); $from = (string)env('MAIL_FROM', 'noreply@localhost'); $host = substr(strrchr($from, '@') ?: '@localhost', 1) ?: 'localhost';
        $desc = $m['title'] . "\n" . ($e['ref'] ? 'Réf. ' . $e['ref'] . ' : ' . $e['title'] . "\n" : '') . ($m['link'] ? 'Lien : ' . $m['link'] . "\n" : '') . ($m['dial_in'] ? 'Téléphone / pont : ' . $m['dial_in'] . "\n" : '') . ($m['agenda'] ? "Ordre du jour : " . $m['agenda'] : '');
        $L = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//CXO Excellence Hub//Appels//FR', 'CALSCALE:GREGORIAN', 'METHOD:' . $method, 'BEGIN:VEVENT', 'UID:meeting-' . (int)$m['id'] . '@' . $host, 'SEQUENCE:' . (int)$m['seq'], 'DTSTAMP:' . $z(time()),
            'DTSTART:' . $z($s), 'DTEND:' . $z($s + (int)$m['duration_min'] * 60), 'SUMMARY:' . self::esc(self::label($m['platform']) . ' · ' . $m['title']), 'DESCRIPTION:' . self::esc($desc)];
        if ($m['link']) { $L[] = 'LOCATION:' . self::esc($m['link']); $L[] = 'URL:' . $m['link']; } elseif ($m['dial_in']) $L[] = 'LOCATION:' . self::esc($m['dial_in']);
        $L[] = 'ORGANIZER;CN=' . self::esc((string)(DB::val('SELECT name FROM users WHERE id=?', [(int)$m['organizer_id']]) ?: 'Organisateur')) . ':mailto:' . $from;
        foreach ($guests as $g) if ($g['email']) $L[] = 'ATTENDEE;CN=' . self::esc($g['name']) . ';ROLE=REQ-PARTICIPANT;PARTSTAT=NEEDS-ACTION;RSVP=FALSE:mailto:' . $g['email'];
        $L[] = 'STATUS:' . ($method === 'CANCEL' ? 'CANCELLED' : 'CONFIRMED'); if ($method !== 'CANCEL') array_push($L, 'BEGIN:VALARM', 'TRIGGER:-PT15M', 'ACTION:DISPLAY', 'DESCRIPTION:Rappel', 'END:VALARM'); array_push($L, 'END:VEVENT', 'END:VCALENDAR');
        return implode("\r\n", array_map([self::class, 'fold'], $L)) . "\r\n";
    }
    static function when(array $m): string { $s = strtotime($m['start_at']); $j = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'][(int)date('w', $s)]; return $j . ' ' . date('d/m/Y', $s) . ' à ' . date('H\hi', $s) . ' (' . Inc::dur((int)$m['duration_min']) . ')'; }
    /** Envoie l'invitation sur les 3 canaux. $kind : INVITATION | MODIFICATION | ANNULATION | RAPPEL (le rappel n'envoie pas d'e-mail). */
    static function notify(int $mid, string $kind, ?int $onlyGuest = null): int {
        $m = DB::one('SELECT * FROM meetings WHERE id=?', [$mid]); if (!$m) return 0; $e = self::entity($m['module'], (int)$m['ref_id']) ?: ['ref' => '', 'title' => '', 'url' => '']; $n = 0;
        $guests = DB::all('SELECT * FROM meeting_guests WHERE meeting_id=? ORDER BY id', [$mid]); $pl = self::label($m['platform']); $cancel = $kind === 'ANNULATION';
        $head = $kind . ' · ' . $pl . ' · ' . $e['ref']; $when = self::when($m);
        $body = $m['title'] . ($cancel ? ' — ANNULÉ (prévu le ' : ' — le ') . $when . ($cancel ? ')' : '') . ($m['link'] && !$cancel ? ' — Lien : ' . $m['link'] : '') . ($m['dial_in'] && !$cancel ? ' — Tél. : ' . $m['dial_in'] : '') . ($m['agenda'] && !$cancel ? ' — Ordre du jour : ' . $m['agenda'] : '');
        $ics = ($kind !== 'RAPPEL') ? self::ics($m, $guests, $cancel ? 'CANCEL' : 'REQUEST') : null; $inc = $m['module'] === 'inc' ? (int)$m['ref_id'] : null;
        foreach ($guests as $g) {
            if ($onlyGuest && (int)$g['id'] !== $onlyGuest) continue; $n++; $st = ['n_inapp' => 'skipped', 'n_email' => 'skipped', 'n_sms' => 'skipped', 'n_wa' => 'skipped'];
            if (Xchg::on('meet.ch_inapp') && $g['user_id'] && DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [(int)$g['user_id']])) { Notifier::send((int)$g['user_id'], $head, mb_substr($body, 0, 480), '/meetings'); $st['n_inapp'] = 'sent'; }
            if (Xchg::on('meet.ch_email') && $kind !== 'RAPPEL' && $g['email']) {
                $txt = "Bonjour {$g['name']},\n\n$head\n\n" . ($e['ref'] ? 'Sujet : ' . $e['ref'] . ' — ' . $e['title'] . "\n" : '') . 'Objet : ' . $m['title'] . "\nQuand : $when\nOutil : $pl\n" . (!$cancel && $m['link'] ? 'Lien : ' . $m['link'] . "\n" : '') . (!$cancel && $m['dial_in'] ? 'Téléphone / pont : ' . $m['dial_in'] . "\n" : '') . (!$cancel && $m['agenda'] ? "Ordre du jour : {$m['agenda']}\n" : '') . ($cancel ? "\nCette réunion est annulée.\n" : "\nUne invitation d'agenda (.ics) est jointe.\n") . "\nMessage automatique de la gestion des incidents et tickets.";
                $st['n_email'] = Mailer::queue($g['email'], '[' . $e['ref'] . '] ' . $head, $txt, null, $ics) ? 'queued' : 'skipped';
            }
            if (Xchg::on('meet.ch_sms') && $g['phone']) $st['n_sms'] = Sms::queue($g['phone'], ($kind === 'RAPPEL' ? 'RAPPEL ' : ($cancel ? 'ANNULÉ ' : '')) . $pl . ' ' . $e['ref'] . ' ' . date('d/m H:i', strtotime($m['start_at'])) . ' (' . (int)$m['duration_min'] . ' min)' . (!$cancel ? ($m['link'] ? ' : ' . $m['link'] : ($m['dial_in'] ? ' : ' . $m['dial_in'] : '')) : ''), $inc) ? 'queued' : 'skipped';
            if (Xchg::on('meet.ch_wa') && $g['phone']) { $link = $m['link'] ?: $m['dial_in']; $txt = ($cancel ? 'ANNULÉ — ' : ($kind === 'RAPPEL' ? 'RAPPEL — ' : '')) . $pl . ' · ' . $e['ref'] . "\n" . $m['title'] . "\n" . $when . ($link && !$cancel ? "\n" . $link : '');
                $st['n_wa'] = Wa::queue($g['phone'], strtolower($kind), $txt, [$g['name'], ($cancel ? '[ANNULÉ] ' : '') . $m['title'], date('d/m/Y H:i', strtotime($m['start_at'])), $cancel ? 'annulé' : ($link ?: '—')], $mid) ? 'queued' : 'skipped'; }
            DB::update('meeting_guests', $st, 'id=?', [(int)$g['id']]);
        }
        return $n;
    }
    /** Rappels des réunions qui commencent dans moins de 15 minutes (outil + SMS). @return int réunions rappelées */
    static function remind(): int {
        $k = 0; foreach (DB::all("SELECT id FROM meetings WHERE status='planned' AND reminder_sent=0 AND start_at>=? AND start_at<=?", [date('Y-m-d H:i:s', time() - 120), date('Y-m-d H:i:s', time() + Xchg::int('meet.reminder_min', 1, 1440) * 60)]) as $m) { DB::update('meetings', ['reminder_sent' => 1], 'id=?', [(int)$m['id']]); self::notify((int)$m['id'], 'RAPPEL'); $k++; }
        return $k;
    }
}
