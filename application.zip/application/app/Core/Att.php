<?php
namespace App\Core;

/**
 * Lot 56 : pointage sécurisé et statuts de présence (M11).
 * Le serveur est la seule source d'heure. Un pointage n'est accepté que d'un poste enregistré (jeton d'appareil), associé au collaborateur
 * ou à son pool, depuis une plage réseau autorisée ; tout refus est journalisé avec son motif. Le pointage d'origine n'est jamais écrasé :
 * les régularisations approuvées sont appliquées au calcul. Le statut du jour est déduit, jamais saisi.
 */
final class Att {
    /** Les 11 statuts (deux axes : entrée, journée) + deux états transitoires d'affichage. */
    const ST = ['on_time' => 'À l\'heure', 'late' => 'Retard', 'present' => 'Présent', 'early_leave' => 'Départ anticipé', 'incomplete' => 'Pointage incomplet', 'absent' => 'Absent', 'leave' => 'Congé', 'permission' => 'Permission', 'sick' => 'Maladie', 'rest' => 'Repos', 'off_plan' => 'Hors planning',
                'expected' => 'Attendu', 'open' => 'En cours'];
    const ST_C = ['on_time' => 'success', 'late' => 'warning', 'present' => 'success', 'early_leave' => 'warning', 'incomplete' => 'danger', 'absent' => 'danger', 'leave' => 'info', 'permission' => 'info', 'sick' => 'info', 'rest' => 'secondary', 'off_plan' => 'dark', 'expected' => 'light', 'open' => 'primary'];
    const ST_ICON = ['on_time' => 'check-circle', 'late' => 'alarm', 'present' => 'person-check', 'early_leave' => 'box-arrow-left', 'incomplete' => 'exclamation-triangle', 'absent' => 'person-x', 'leave' => 'sun', 'permission' => 'door-open', 'sick' => 'bandaid', 'rest' => 'moon', 'off_plan' => 'question-circle', 'expected' => 'hourglass', 'open' => 'play-circle'];
    const REFUSAL = ['user' => 'Utilisateur ou collaborateur inactif', 'ua' => 'Smartphone ou tablette détecté', 'device' => 'Poste non reconnu', 'assoc' => 'Poste non associé au collaborateur ou à son équipe', 'network' => 'Réseau non autorisé',
                     'too_early' => 'Fenêtre de pointage pas encore ouverte', 'window_over' => 'Shift terminé', 'already_in' => 'Entrée déjà enregistrée', 'no_entry' => 'Aucune entrée à clore'];
    const DEFAULTS = ['late_tol' => 10, 'early_tol' => 10, 'before' => 60, 'dedupe' => 30, 'close_after' => 120, 'ot_after' => 15, 'ot_round' => 15, 'ot_max' => 240, 'vpn_allowed' => 0];

    /** Horloge de test : n'est prise en compte qu'en ligne de commande, jamais depuis une requête web. */
    public static ?int $clock = null;
    static function ts(): int { return (PHP_SAPI === 'cli' && self::$clock !== null) ? self::$clock : time(); }
    static function nowStr(): string { return date('Y-m-d H:i:s', self::ts()); }
    static function cfg(string $k): int { return (int)setting('att.' . $k, self::DEFAULTS[$k] ?? 0); }

    // ------------------------------------------------------------------ réseau
    static function validCidr(string $c): bool {
        [$net, $bits] = array_pad(explode('/', trim($c), 2), 2, null); $a = @inet_pton((string)$net); if ($a === false) return false;
        if ($bits === null) return true; return ctype_digit($bits) && (int)$bits <= strlen($a) * 8;
    }
    static function inCidr(string $ip, string $cidr): bool {
        [$net, $bits] = array_pad(explode('/', trim($cidr), 2), 2, null); $a = @inet_pton($ip); $b = @inet_pton((string)$net);
        if ($a === false || $b === false || strlen($a) !== strlen($b)) return false;
        $max = strlen($a) * 8; $bits = $bits === null ? $max : (int)$bits; if ($bits < 0 || $bits > $max) return false;
        $by = intdiv($bits, 8); if ($by && substr($a, 0, $by) !== substr($b, 0, $by)) return false;
        $rem = $bits % 8; if ($rem) { $m = (0xFF << (8 - $rem)) & 0xFF; if ((ord($a[$by]) & $m) !== (ord($b[$by]) & $m)) return false; }
        return true;
    }
    static function anyNetwork(string $ip): bool { foreach (DB::all('SELECT cidr, vpn FROM att_networks WHERE active=1') as $n) { if ($n['vpn'] && !self::cfg('vpn_allowed')) continue; if (self::inCidr($ip, $n['cidr'])) return true; } return false; }
    static function networkOk(string $ip, ?int $storeId): bool {
        foreach (DB::all('SELECT cidr, store_id, vpn FROM att_networks WHERE active=1') as $n) {
            if ($n['store_id'] && (int)$n['store_id'] !== (int)$storeId) continue; if ($n['vpn'] && !self::cfg('vpn_allowed')) continue;
            if (self::inCidr($ip, $n['cidr'])) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ postes
    static function newToken(): string { return bin2hex(random_bytes(24)); }
    static function hash(string $t): string { return hash('sha256', $t); }
    static function deviceByToken(?string $tok): ?array { if (!$tok || !preg_match('/^[a-f0-9]{48}$/', $tok)) return null; return DB::one('SELECT * FROM att_devices WHERE token_hash=?', [self::hash($tok)]); }
    /** Le poste est-il associé à ce collaborateur (individuel) ou à son équipe (pool) ? */
    static function associated(array $dev, array $emp): bool {
        if ($dev['employee_id']) return (int)$dev['employee_id'] === (int)$emp['id'];
        if ($dev['pool_id']) { $p = DB::one('SELECT team_id, active FROM att_pools WHERE id=?', [(int)$dev['pool_id']]); return $p && $p['active'] && $p['team_id'] && (int)$p['team_id'] === (int)$emp['team_id']; }
        return false;
    }
    /** Diagnostic de l'état du poste courant, pour l'afficher avant le pointage (sans rien enregistrer). */
    static function diagnose(array $emp, array $ctx): array {
        $out = ['ok' => true, 'code' => '', 'reason' => '', 'device' => null];
        if (preg_match('/Android|iPhone|iPad|iPod|Mobile|Tablet/i', (string)($ctx['ua'] ?? ''))) return ['ok' => false, 'code' => 'ua', 'reason' => 'Le pointage est réservé aux ordinateurs professionnels : un smartphone ou une tablette est refusé.', 'device' => null];
        $dev = self::deviceByToken($ctx['token'] ?? null);
        if (!$dev || !$dev['active']) return ['ok' => false, 'code' => 'device', 'reason' => 'Ce poste n\'est pas reconnu. Demandez à l\'assistance technique de l\'enregistrer.', 'device' => $dev];
        if (!self::associated($dev, $emp)) return ['ok' => false, 'code' => 'assoc', 'reason' => 'Ce poste n\'est pas le vôtre ni celui de votre équipe.', 'device' => $dev];
        if (!self::networkOk((string)($ctx['ip'] ?? ''), $dev['store_id'] ? (int)$dev['store_id'] : null)) return ['ok' => false, 'code' => 'network', 'reason' => 'Le réseau actuel n\'est pas autorisé pour le pointage.', 'device' => $dev];
        $out['device'] = $dev; return $out;
    }

    // ------------------------------------------------------------------ shifts et occurrences
    static function tol(int $shiftId): array {
        $r = DB::one('SELECT late_tol, early_tol FROM att_shift_rules WHERE shift_id=?', [$shiftId]);
        return ['late' => $r && $r['late_tol'] !== null ? (int)$r['late_tol'] : self::cfg('late_tol'), 'early' => $r && $r['early_tol'] !== null ? (int)$r['early_tol'] : self::cfg('early_tol')];
    }
    /** Occurrence de shift de travail d'un collaborateur pour une date (rattachée à la date de début, y compris au-delà de minuit). */
    static function occurrence(int $emp, string $day): ?array {
        $a = DB::one("SELECT a.id, a.shift_id, s.code, s.name, s.start_time, s.end_time, s.break_min, s.kind FROM pl_assignments a JOIN pl_shifts s ON s.id=a.shift_id WHERE a.employee_id=? AND a.day=? AND a.status='published'", [$emp, $day]);
        if (!$a) return null;
        if ($a['kind'] !== 'work' || !$a['start_time'] || !$a['end_time']) return ['shift_id' => (int)$a['shift_id'], 'rest' => true, 'code' => $a['code'], 'name' => $a['name']];
        $s = strtotime("$day {$a['start_time']}:00"); $e = strtotime("$day {$a['end_time']}:00"); if ($e <= $s) $e += 86400;
        return ['shift_id' => (int)$a['shift_id'], 'rest' => false, 'code' => $a['code'], 'name' => $a['name'], 'start' => $s, 'end' => $e, 'break' => (int)$a['break_min'], 'night' => $a['end_time'] <= $a['start_time']] + self::tol((int)$a['shift_id']);
    }

    // ------------------------------------------------------------------ pointage
    private static function refuse(array $user, ?array $emp, string $kind, string $code, string $reason, array $ctx, ?array $dev): array {
        DB::insert('att_attempts', ['user_id' => (int)($user['id'] ?? 0) ?: null, 'employee_id' => $emp ? (int)$emp['id'] : null, 'kind' => $kind, 'attempted_at' => self::nowStr(), 'device_id' => $dev ? (int)$dev['id'] : null, 'device_label' => $dev ? mb_substr((string)$dev['label'], 0, 100) : null,
            'ip' => mb_substr((string)($ctx['ip'] ?? ''), 0, 45), 'user_agent' => mb_substr((string)($ctx['ua'] ?? ''), 0, 200), 'code' => $code, 'reason' => mb_substr($reason, 0, 300)]);
        return ['ok' => false, 'code' => $code, 'msg' => $reason];
    }
    /** @param array{id:int,employee_id:?int,status:string} $user  @param array{ip:string,ua:string,token:?string} $ctx */
    static function punch(array $user, string $kind, array $ctx): array {
        if (!in_array($kind, ['in', 'out'], true)) return ['ok' => false, 'code' => 'bad', 'msg' => 'Action inconnue.'];
        $emp = !empty($user['employee_id']) ? DB::one('SELECT id, team_id, status FROM employees WHERE id=?', [(int)$user['employee_id']]) : null;
        if (($user['status'] ?? '') !== 'active' || !$emp || $emp['status'] !== 'active') return self::refuse($user, $emp, $kind, 'user', 'Votre compte n\'est pas rattaché à un collaborateur en poste.', $ctx, null);
        $dg = self::diagnose($emp, $ctx); $dev = $dg['device'];
        if (!$dg['ok']) return self::refuse($user, $emp, $kind, $dg['code'], $dg['reason'], $ctx, $dev);
        $now = self::ts(); $today = date('Y-m-d', $now); $yest = date('Y-m-d', strtotime('-1 day', $now)); $eid = (int)$emp['id'];
        // déduplication des doubles clics
        $last = DB::val('SELECT punched_at FROM att_punches WHERE employee_id=? AND kind=? ORDER BY punched_at DESC, id DESC LIMIT 1', [$eid, $kind]);
        if ($last && $now - strtotime($last) < self::cfg('dedupe') && $now >= strtotime($last)) return ['ok' => true, 'dup' => true, 'code' => 'dup', 'msg' => ($kind === 'in' ? 'Arrivée' : 'Départ') . ' déjà enregistré à ' . date('H:i:s', strtotime($last)) . '.'];
        $day = $today; $shift = null; $off = 0;
        if ($kind === 'in') {
            $pick = null; $early = null; $over = null; $dupIn = false;
            foreach ([$yest, $today] as $d) {
                $o = self::occurrence($eid, $d); if (!$o || $o['rest']) continue;
                if (DB::val("SELECT 1 FROM att_punches WHERE employee_id=? AND day=? AND kind='in'", [$eid, $d])) { if ($now <= $o['end']) $dupIn = true; continue; }
                $from = $o['start'] - self::cfg('before') * 60;
                if ($now >= $from && $now <= $o['end']) { $pick = [$d, $o]; break; }
                if ($now < $from && $d === $today) $early = $o; elseif ($now > $o['end'] && $d === $today) $over = $o;
            }
            if ($pick) { [$day, $o] = $pick; $shift = $o['shift_id']; }
            elseif ($dupIn) return self::refuse($user, $emp, $kind, 'already_in', 'Votre arrivée est déjà enregistrée pour ce shift.', $ctx, $dev);
            elseif ($early) return self::refuse($user, $emp, $kind, 'too_early', 'Votre shift commence à ' . date('H:i', $early['start']) . ' : le pointage ouvre à ' . date('H:i', $early['start'] - self::cfg('before') * 60) . '.', $ctx, $dev);
            elseif ($over) return self::refuse($user, $emp, $kind, 'window_over', 'Votre shift de ' . date('H:i', $over['start']) . ' à ' . date('H:i', $over['end']) . ' est terminé. Faites une demande de régularisation.', $ctx, $dev);
            else $off = 1;   // aucun shift attendu : pointage « hors planning », accepté et signalé
        } else {
            $open = null;
            foreach (DB::all("SELECT day, shift_id, punched_at, off_plan FROM att_punches WHERE employee_id=? AND kind='in' AND day IN (?,?) ORDER BY punched_at DESC", [$eid, $yest, $today]) as $in)
                if (!DB::val("SELECT 1 FROM att_punches WHERE employee_id=? AND day=? AND kind='out'", [$eid, $in['day']])) { $open = $in; break; }
            if (!$open) return self::refuse($user, $emp, $kind, 'no_entry', 'Aucune arrivée à clore : pointez d\'abord votre arrivée ou demandez une régularisation.', $ctx, $dev);
            $day = $open['day']; $shift = $open['shift_id'] ? (int)$open['shift_id'] : null; $off = (int)$open['off_plan'];
        }
        $at = date('Y-m-d H:i:s', $now);
        DB::insert('att_punches', ['employee_id' => $eid, 'day' => $day, 'shift_id' => $shift, 'kind' => $kind, 'punched_at' => $at, 'device_id' => (int)$dev['id'], 'ip' => mb_substr((string)$ctx['ip'], 0, 45), 'off_plan' => $off]);
        DB::update('att_devices', ['last_seen_at' => $at], 'id=?', [(int)$dev['id']]);
        $r = self::computeDay($eid, $day);
        return ['ok' => true, 'code' => 'ok', 'at' => $at, 'day' => $day, 'status' => $r['day_status'] ?? null, 'entry' => $r['entry_status'] ?? null, 'off_plan' => (bool)$off, 'msg' => ($kind === 'in' ? 'Arrivée' : 'Départ') . ' enregistré à ' . date('H:i:s', $now) . ' (heure du serveur)' . ($off ? ', hors planning' : '') . '.'];
    }

    // ------------------------------------------------------------------ statuts
    /** Pointages effectifs d'un jour : entrée = première, sortie = dernière ; les régularisations approuvées remplacent la valeur sans effacer l'original. */
    static function effective(int $emp, string $day): array {
        $in = DB::val("SELECT MIN(punched_at) FROM att_punches WHERE employee_id=? AND day=? AND kind='in'", [$emp, $day]) ?: null; $out = DB::val("SELECT MAX(punched_at) FROM att_punches WHERE employee_id=? AND day=? AND kind='out'", [$emp, $day]) ?: null; $adj = false;
        foreach (DB::all("SELECT new_in, new_out FROM att_adjustments WHERE employee_id=? AND day=? AND status='approved' ORDER BY decided_at, id", [$emp, $day]) as $a) {
            if ($a['new_in']) { $in = $a['new_in']; $adj = true; } if ($a['new_out']) { $out = $a['new_out']; $adj = true; }
        }
        return ['in' => $in, 'out' => $out, 'adjusted' => $adj];
    }
    /** Congé, permission ou maladie couvrant le jour (demande approuvée ou absence justifiée). */
    static function leaveKind(int $emp, string $day): ?string {
        $l = DB::one("SELECT t.name FROM leave_requests r JOIN leave_types t ON t.id=r.leave_type_id WHERE r.employee_id=? AND r.status='approved' AND r.start_date<=? AND r.end_date>=? LIMIT 1", [$emp, $day, $day]);
        if ($l) { $n = mb_strtolower($l['name']); return str_contains($n, 'maladie') ? 'sick' : (str_contains($n, 'permission') ? 'permission' : 'leave'); }
        $a = DB::one('SELECT kind FROM absences WHERE employee_id=? AND start_date<=? AND end_date>=? AND justified=1 LIMIT 1', [$emp, $day, $day]);
        if ($a) return mb_strtoupper((string)$a['kind']) === 'MALADIE' ? 'sick' : 'leave';
        return null;
    }
    /** Calcule, enregistre et retourne le statut du jour ; null quand rien n'est attendu et rien n'a été pointé. */
    static function computeDay(int $emp, string $day): ?array {
        $o = self::occurrence($emp, $day); $eff = self::effective($emp, $day); $now = self::ts();
        $row = ['employee_id' => $emp, 'day' => $day, 'shift_id' => $o['shift_id'] ?? null, 'entry_status' => null, 'day_status' => '', 'late_min' => 0, 'early_min' => 0, 'worked_min' => 0, 'overtime_min' => 0, 'in_at' => $eff['in'], 'out_at' => $eff['out'], 'adjusted' => $eff['adjusted'] ? 1 : 0, 'closed' => 0, 'computed_at' => self::nowStr()];
        $work = $o && !$o['rest'];
        if (!$eff['in'] && !$eff['out']) {
            $lk = self::leaveKind($emp, $day);
            if ($lk) { $row['day_status'] = $lk; $row['closed'] = 1; }
            elseif ($o && $o['rest']) { $row['day_status'] = 'rest'; $row['closed'] = 1; }
            elseif ($work) { $over = $now > $o['end'] + self::cfg('close_after') * 60; $row['day_status'] = $over ? 'absent' : 'expected'; $row['closed'] = $over ? 1 : 0; }
            else { DB::exec('DELETE FROM att_days WHERE employee_id=? AND day=?', [$emp, $day]); return null; }
        } elseif (!$work) {
            $row['day_status'] = 'off_plan'; $row['shift_id'] = null; $row['closed'] = $eff['out'] ? 1 : 0;
            if ($eff['in'] && $eff['out']) $row['worked_min'] = max(0, intdiv(strtotime($eff['out']) - strtotime($eff['in']), 60));
        } else {
            $in = $eff['in'] ? strtotime($eff['in']) : null; $out = $eff['out'] ? strtotime($eff['out']) : null;
            if ($in) { $late = intdiv($in - $o['start'], 60); if ($late > $o['late']) { $row['entry_status'] = 'late'; $row['late_min'] = $late; } else $row['entry_status'] = 'on_time'; }
            $over = $now > $o['end'] + self::cfg('close_after') * 60;
            if (!$out) { $row['day_status'] = $over ? 'incomplete' : 'open'; $row['closed'] = $over ? 1 : 0; }
            else {
                $row['closed'] = 1; $early = intdiv($o['end'] - $out, 60);
                if ($early > $o['early']) { $row['day_status'] = 'early_leave'; $row['early_min'] = $early; } else $row['day_status'] = 'present';
                if ($in) $row['worked_min'] = max(0, intdiv($out - $in, 60) - $o['break']);
                $ot = intdiv($out - $o['end'], 60); $rd = max(1, self::cfg('ot_round'));
                if ($ot > self::cfg('ot_after')) $row['overtime_min'] = min(self::cfg('ot_max'), intdiv($ot, $rd) * $rd);
            }
            if (!$in && $out) { $row['day_status'] = 'incomplete'; }
        }
        $cur = DB::val('SELECT id FROM att_days WHERE employee_id=? AND day=?', [$emp, $day]);
        if ($cur) DB::update('att_days', $row, 'id=?', [(int)$cur]); else DB::insert('att_days', $row);
        return $row;
    }
    /** Job de fin de shift : calcule les statuts définitifs des trois derniers jours et clôt les occurrences sans sortie. */
    static function closeDue(int $days = 3): array {
        $n = 0; $inc = 0; $abs = 0; $today = date('Y-m-d', self::ts());
        for ($i = $days - 1; $i >= 0; $i--) {
            $d = date('Y-m-d', strtotime("-$i day", self::ts())); $ids = [];
            foreach (DB::all("SELECT employee_id FROM pl_assignments WHERE day=? AND status='published'", [$d]) as $r) $ids[(int)$r['employee_id']] = 1;
            foreach (DB::all('SELECT DISTINCT employee_id FROM att_punches WHERE day=?', [$d]) as $r) $ids[(int)$r['employee_id']] = 1;
            foreach (array_keys($ids) as $e) { $r = self::computeDay($e, $d); if (!$r) continue; $n++; if ($r['day_status'] === 'incomplete') $inc++; if ($r['day_status'] === 'absent') $abs++; }
        }
        return ['computed' => $n, 'incomplete' => $inc, 'absent' => $abs];
    }
    static function badge(?string $st): string { return $st && isset(self::ST[$st]) ? '<span class="badge text-bg-' . self::ST_C[$st] . '"><i class="bi bi-' . self::ST_ICON[$st] . ' me-1"></i>' . e(self::ST[$st]) . '</span>' : '<span class="text-muted">—</span>'; }
    static function hm(?int $min): string { if ($min === null) return '—'; return intdiv($min, 60) . ' h ' . str_pad((string)($min % 60), 2, '0', STR_PAD_LEFT); }
}
