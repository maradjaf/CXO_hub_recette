<?php
namespace App\Core;
/** Demandes de formation : scoring pondéré sur 100, classes P1 à P4, SLA, circuit N+1 → équipe formation → formateur. */
class Tq {
    const PRIORITY = ['critique' => ['Critique', 20], 'elevee' => ['Élevée', 15], 'normale' => ['Normale', 10], 'faible' => ['Faible', 5]];
    const IMPACT = ['majeur' => ['Majeur', 20], 'significatif' => ['Significatif', 15], 'modere' => ['Modéré', 10], 'limite' => ['Limité', 5]];
    const REG = ['obligatoire' => ['Oui, obligatoire', 10], 'recommandee' => ['Oui, recommandée', 5], 'non' => ['Non', 0]];
    const RISK = ['critique' => ['Critique', 20], 'eleve' => ['Élevé', 15], 'moyen' => ['Moyen', 10], 'faible' => ['Faible', 5]];
    const CRITERIA = ['sc_priority' => ['Priorité métier', 20], 'sc_impact' => ['Impact client', 20], 'sc_population' => ['Population concernée', 10], 'sc_urgency' => ['Urgence du déploiement', 15], 'sc_risk' => ['Risque en cas de non-formation', 20], 'sc_supports' => ['Disponibilité des supports', 5], 'sc_compliance' => ['Conformité / réglementation', 10]];
    const MGR = ['approuve' => 'Approuvé', 'reserves' => 'Approuvé avec réserves', 'rejete' => 'Rejeté', 'report' => 'Approuvé avec motif report de date'];
    const DEC = ['approuve' => 'Approuvé', 'rejete' => 'Rejeté', 'report' => 'Reporté'];
    const OUTCOME = ['realisee' => 'Réalisée', 'partielle' => 'Partiellement réalisée', 'non_realisee' => 'Non réalisée'];
    const ST = ['draft' => ['Brouillon', 'secondary'], 'pending_n1' => ['À valider par le N+1', 'warning'], 'rejected_n1' => ['Rejetée par le N+1', 'danger'], 'pending_training' => ['À traiter par l\'équipe formation', 'info'],
                'planned' => ['Planifiée', 'primary'], 'rejected' => ['Rejetée', 'danger'], 'done' => ['Terminée', 'success'], 'cancelled' => ['Annulée', 'dark']];
    const CLS = ['P1' => ['P1 Critique', '#c0392b'], 'P2' => ['P2 Haute', '#e67e22'], 'P3' => ['P3 Moyenne', '#f1c40f'], 'P4' => ['P4 Faible', '#7f8c8d']];

    static function admin(): bool { return isset(Auth::permissions()['*']); }
    static function me(): int { return (int)(Auth::user()['employee_id'] ?? 0); }
    static function statusBadge(string $s): string { [$l, $c] = self::ST[$s] ?? [$s, 'secondary']; return '<span class="badge text-bg-' . $c . '">' . e($l) . '</span>'; }
    static function classBadge(?string $c): string { if (!$c) return '—'; [$l, $col] = self::CLS[$c] ?? [$c, '#6c757d']; return '<span class="badge" style="background:' . $col . ';color:#fff">' . e($l) . '</span>'; }
    static function codes(?string $csv): array { return array_values(array_filter(array_map('trim', explode(',', (string)$csv)), 'strlen')); }

    static function popScore(int $n): int { return $n > 300 ? 10 : ($n >= 150 ? 8 : ($n >= 50 ? 5 : 2)); }
    static function urgencyScore(int $days): int { return $days <= 7 ? 15 : ($days <= 15 ? 10 : ($days <= 30 ? 5 : 2)); }
    /** Niveau de risque déduit du nombre de risques cochés (seuils réglables) ; l'équipe formation peut le corriger au traitement. */
    static function riskAuto(array $risks): string {
        $n = count($risks); if ($n >= max(1, (int)setting('tq.risk_critical', 6))) return 'critique'; if ($n >= (int)setting('tq.risk_high', 4)) return 'eleve'; if ($n >= (int)setting('tq.risk_medium', 2)) return 'moyen'; return 'faible';
    }
    static function supportScore(array $codes): int { $real = array_diff($codes, ['indisponibles']); if (!$real || in_array('indisponibles', $codes, true)) return 0; return count($real) >= max(1, (int)setting('tq.supports_full', 4)) ? 5 : 3; }
    static function classOf(int $score): string { return $score >= (int)setting('tq.threshold_p1', 80) ? 'P1' : ($score >= (int)setting('tq.threshold_p2', 60) ? 'P2' : ($score >= (int)setting('tq.threshold_p3', 40) ? 'P3' : 'P4')); }
    /** Calcule les sept critères, le total et la classe. $from = date de la demande (Y-m-d). */
    static function score(array $r, ?string $from = null): array {
        $from = $from ?: date('Y-m-d'); $days = $r['start_wish'] ? (int)floor((strtotime($r['start_wish']) - strtotime($from)) / 86400) : 99;
        $auto = self::riskAuto(self::codes($r['risks'] ?? '')); $lvl = ($r['risk_level'] ?? '') ?: $auto;
        $s = ['sc_priority' => self::PRIORITY[$r['priority_level'] ?? '']['1'] ?? 0, 'sc_impact' => self::IMPACT[$r['customer_impact'] ?? '']['1'] ?? 0, 'sc_population' => self::popScore((int)($r['headcount'] ?? 0)), 'sc_urgency' => self::urgencyScore($days),
              'sc_risk' => self::RISK[$lvl][1] ?? 0, 'sc_supports' => self::supportScore(self::codes($r['supports'] ?? '')), 'sc_compliance' => self::REG[$r['regulatory'] ?? '']['1'] ?? 0];
        $t = array_sum($s); return $s + ['score' => $t, 'pclass' => self::classOf($t), 'risk_level_auto' => $auto, 'risk_level' => $lvl];
    }
    static function addWorkdays(int $ts, int $n): int { while ($n > 0) { $ts += 86400; if ((int)date('N', $ts) < 6) $n--; } return $ts; }
    /** Échéance de prise en charge : P1 en heures, P2/P3 en jours ouvrés (hors jours fériés), P4 = fin du trimestre en cours. */
    static function slaDue(string $class, ?int $from = null): string {
        $from = $from ?: time();
        if ($class === 'P1') return date('Y-m-d H:i:s', $from + 3600 * max(1, (int)setting('tq.sla_p1_hours', 48)));
        if ($class === 'P2') return date('Y-m-d H:i:s', self::addWorkdays($from, max(1, (int)setting('tq.sla_p2_days', 5))));
        if ($class === 'P3') return date('Y-m-d H:i:s', self::addWorkdays($from, max(1, (int)setting('tq.sla_p3_days', 15))));
        $m = (int)date('n', $from); $qEnd = (int)(ceil($m / 3) * 3); return date('Y-m-t 23:59:59', mktime(0, 0, 0, $qEnd, 1, (int)date('Y', $from)));
    }
    static function slaLabel(string $class): string { return ['P1' => (int)setting('tq.sla_p1_hours', 48) . ' h', 'P2' => '≤ ' . (int)setting('tq.sla_p2_days', 5) . ' jours ouvrés', 'P3' => '≤ ' . (int)setting('tq.sla_p3_days', 15) . ' jours ouvrés', 'P4' => 'Planification trimestrielle'][$class] ?? ''; }

    // --- Acteurs et droits ---
    static function userOf(?int $employeeId): int { return $employeeId ? (int)DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [$employeeId]) : 0; }
    static function managerEmployee(?int $employeeId): int { return $employeeId ? (int)DB::val('SELECT manager_id FROM employees WHERE id=?', [$employeeId]) : 0; }
    static function isN1(array $r): bool { $m = self::me(); return $m && (int)$r['manager_employee_id'] === $m; }
    static function canValidate(array $r): bool { return $r['status'] === 'pending_n1' && (int)$r['requester_id'] !== (int)Auth::id() && (self::isN1($r) || ((int)$r['manager_employee_id'] === 0 && can('tq.treat')) || self::admin()); }
    static function canTreat(array $r): bool { return $r['status'] === 'pending_training' && can('tq.treat'); }
    static function canSee(array $r): bool {
        $st = $r['status']; if (can('tq.dashboard') && $st !== 'draft') return true;
        if (can('tq.treat') && (!in_array($st, ['draft', 'pending_n1', 'rejected_n1'], true) || ($st === 'pending_n1' && !(int)$r['manager_employee_id']))) return true;
        return (int)$r['requester_id'] === (int)Auth::id() || self::isN1($r) || ((int)$r['trainer_user_id'] && (int)$r['trainer_user_id'] === (int)Auth::id());
    }
    static function isTrainer(array $r): bool { return (int)$r['trainer_user_id'] === (int)Auth::id() || can('tq.treat'); }
    static function nextRef(): string { $y = date('Y'); $n = (int)DB::val('SELECT COUNT(*) FROM tq_requests WHERE ref LIKE ?', ["DF-$y-%"]) + 1; do { $r = sprintf('DF-%s-%04d', $y, $n++); } while (DB::val('SELECT 1 FROM tq_requests WHERE ref=?', [$r])); return $r; }
    static function log(int $rid, string $action, string $comment = ''): void { DB::insert('tq_events', ['request_id' => $rid, 'user_id' => Auth::id(), 'user_name' => Auth::user()['name'] ?? 'Système', 'action' => $action, 'comment' => $comment !== '' ? mb_substr($comment, 0, 1000) : null, 'created_at' => now()]); }

    // --- Notifications : interne, e-mail si SMTP configuré, Teams si webhook renseigné ---
    static function permUsers(string $perm): array { return array_map('intval', array_column(DB::all("SELECT DISTINCT ur.user_id FROM user_roles ur JOIN roles r ON r.id=ur.role_id LEFT JOIN role_permissions rp ON rp.role_id=r.id LEFT JOIN permissions p ON p.id=rp.permission_id JOIN users u ON u.id=ur.user_id WHERE u.status='active' AND (r.code='admin' OR p.code=?)", [$perm]), 'user_id')); }
    static function notify(array $userIds, string $title, string $body, string $url, bool $mail = false): void {
        foreach (array_unique(array_filter(array_map('intval', $userIds))) as $u) {
            Notifier::send($u, $title, $body, $url);
            if ($mail && Mailer::enabled()) { $em = DB::val('SELECT email FROM users WHERE id=?', [$u]); if ($em) { try { Mailer::queue((string)$em, $title, $body . "\n\n" . rtrim((string)env('APP_URL', ''), '/') . $url); } catch (\Throwable $e) {} } }
        }
    }
    /** Publication d'un message sur un canal Teams via un webhook entrant (réglage tq.teams_webhook, https obligatoire). Silencieux en cas d'échec. */
    static function teams(string $text): bool {
        $u = trim((string)setting('tq.teams_webhook', '')); if ($u === '' || !preg_match('#^https://#i', $u) || !function_exists('curl_init')) return false;
        $c = curl_init($u); curl_setopt_array($c, [CURLOPT_POST => true, CURLOPT_POSTFIELDS => json_encode(['text' => $text], JSON_UNESCAPED_UNICODE), CURLOPT_HTTPHEADER => ['Content-Type: application/json'], CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 5, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_PROTOCOLS => CURLPROTO_HTTPS]);
        $ok = curl_exec($c) !== false && (int)curl_getinfo($c, CURLINFO_HTTP_CODE) < 300; curl_close($c); return $ok;
    }
    /** À la soumission : accusé de réception au demandeur, puis alertes selon la classe (P1/P2 : équipe formation et Head EOP, avec Teams ; P3/P4 : équipe formation). */
    static function announce(array $r): void {
        $url = '/tq/' . $r['id']; $line = $r['ref'] . ' · ' . $r['title'] . ' · ' . ($r['pclass'] ? self::CLS[$r['pclass']][0] : '') . ' (' . (int)$r['score'] . '/100)';
        self::notify([(int)$r['requester_id']], 'Accusé de réception : ' . $r['ref'], 'Votre demande de formation est enregistrée. Échéance de prise en charge : ' . date('d/m/Y H:i', strtotime($r['sla_due'])) . '.', $url, true);
        if (in_array($r['pclass'], ['P1', 'P2'], true)) { self::notify(array_merge(self::permUsers('tq.treat'), self::permUsers('tq.dashboard')), 'Demande de formation ' . $r['pclass'] . ' : ' . $r['ref'], $line, $url, true); self::teams('Nouvelle demande de formation ' . $line . ' — échéance ' . date('d/m/Y H:i', strtotime($r['sla_due']))); }
        else self::notify(self::permUsers('tq.treat'), 'Demande de formation ' . $r['pclass'] . ' : ' . $r['ref'], $line, $url, true);
    }
    static function scopeSql(string $a = 'r'): array {
        if (can('tq.treat') || can('tq.dashboard')) return ['1=1', []];
        $m = self::me(); return ["($a.requester_id=? OR $a.trainer_user_id=?" . ($m ? " OR $a.manager_employee_id=?" : '') . ')', $m ? [Auth::id(), Auth::id(), $m] : [Auth::id(), Auth::id()]];
    }
}
