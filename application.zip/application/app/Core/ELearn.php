<?php
namespace App\Core;
/** Règles de l'e-learning : composition d'un cours, correction des quiz côté serveur, synchronisation avec le catalogue de formations. */
class ELearn {
    const ES = ['assigned' => 'À démarrer', 'in_progress' => 'En cours', 'passed' => 'Réussi', 'failed' => 'Échec'];
    const CS = ['draft' => 'Brouillon', 'published' => 'Publié', 'archived' => 'Archivé'];
    const LEVELS = ['beginner' => 'Débutant', 'intermediate' => 'Intermédiaire', 'advanced' => 'Avancé'];
    const NATURES = ['theory' => 'Théorique', 'practice' => 'Pratique', 'both' => 'Théorie et pratique'];
    const KINDS = ['text' => 'Texte', 'video' => 'Vidéo', 'mixed' => 'Mixte (texte + vidéo)'];
    const ACT = ['case' => 'Étude de cas', 'expose' => 'Exposé'];
    const SUB = ['submitted' => 'À corriger', 'validated' => 'Validé', 'returned' => 'À reprendre'];
    const DEPTH = ['Module', 'Chapitre / partie', 'Sous-chapitre / sous-partie'];
    /** Arborescence du cours en ordre de lecture : chaque ligne reçoit depth (1 à 3), num (« 1.2 »), leaf et nq (nombre de questions de la partie). */
    static function nodes(int $cid): array {
        $rows = DB::all('SELECT * FROM el_lessons WHERE course_id=? ORDER BY position, id', [$cid]); $by = []; $ids = [];
        foreach ($rows as $r) $ids[(int)$r['id']] = 1;
        foreach ($rows as $r) { $p = (int)($r['parent_id'] ?? 0); if (!$p || !isset($ids[$p])) $p = 0; $by[$p][] = $r; }
        $nq = []; foreach (DB::all('SELECT node_id, COUNT(*) n FROM el_questions WHERE course_id=? AND node_id IS NOT NULL GROUP BY node_id', [$cid]) as $x) $nq[(int)$x['node_id']] = (int)$x['n'];
        $out = []; $walk = function (int $p, int $d, string $pre) use (&$walk, &$out, $by, $nq) {
            foreach ($by[$p] ?? [] as $i => $r) { $num = $pre . ($i + 1); $r['depth'] = $d; $r['num'] = $num; $r['leaf'] = empty($by[(int)$r['id']]); $r['nq'] = $nq[(int)$r['id']] ?? 0; $r['parent_id'] = $p ?: null; $out[] = $r; if ($d < 3) $walk((int)$r['id'], $d + 1, $num . '.'); }
        }; $walk(0, 1, ''); return $out;
    }
    /** Parties à suivre (feuilles de l'arborescence), dans l'ordre de lecture. */
    static function lessons(int $cid): array { return array_values(array_filter(self::nodes($cid), fn($n) => $n['leaf'])); }
    /** Étapes du parcours d'apprentissage : leçon, quiz de partie, activité (étude de cas / exposé). required = bloque la suite. */
    static function steps(int $cid): array {
        $nodes = self::nodes($cid); $acts = []; foreach (DB::all('SELECT * FROM el_activities WHERE course_id=? ORDER BY position, id', [$cid]) as $a) $acts[(int)($a['node_id'] ?? 0)][] = $a;
        $steps = []; $kids = []; foreach ($nodes as $n) $kids[(int)($n['parent_id'] ?? 0)][] = $n;
        $emit = function ($n) use (&$emit, &$steps, $kids, $acts) {
            if ($n['leaf']) $steps[] = ['type' => 'lesson', 'key' => 'l' . $n['id'], 'node' => $n, 'title' => $n['title'], 'required' => true];
            else foreach ($kids[(int)$n['id']] ?? [] as $k) $emit($k);
            if ($n['nq'] > 0) $steps[] = ['type' => 'nodequiz', 'key' => 'q' . $n['id'], 'node' => $n, 'title' => 'Quiz : ' . $n['title'], 'required' => (bool)$n['quiz_required']];
            foreach ($acts[(int)$n['id']] ?? [] as $a) $steps[] = ['type' => 'activity', 'key' => 'a' . $a['id'], 'act' => $a, 'node' => $n, 'title' => (self::ACT[$a['type']] ?? 'Activité') . ' : ' . $a['title'], 'required' => (bool)$a['required']];
        };
        foreach ($kids[0] ?? [] as $n) $emit($n);
        foreach ($acts[0] ?? [] as $a) $steps[] = ['type' => 'activity', 'key' => 'a' . $a['id'], 'act' => $a, 'node' => null, 'title' => (self::ACT[$a['type']] ?? 'Activité') . ' : ' . $a['title'], 'required' => (bool)$a['required']];
        return $steps;
    }
    /** Clés des étapes terminées par une inscription. */
    static function doneKeys(int $eid): array {
        $d = []; foreach (DB::all('SELECT lesson_id FROM el_progress WHERE enrollment_id=?', [$eid]) as $r) $d['l' . $r['lesson_id']] = 1;
        foreach (DB::all('SELECT DISTINCT node_id FROM el_attempts WHERE enrollment_id=? AND node_id IS NOT NULL AND passed=1', [$eid]) as $r) $d['q' . $r['node_id']] = 1;
        foreach (DB::all("SELECT s.activity_id, s.status, a.required FROM el_submissions s JOIN el_activities a ON a.id=s.activity_id WHERE s.enrollment_id=?", [$eid]) as $r) if ($r['status'] === 'validated' || (!$r['required'] && $r['status'] === 'submitted')) $d['a' . $r['activity_id']] = 1;
        return $d;
    }
    /** Première étape non terminée qui bloque la suite (null = tout est fait). */
    static function pending(int $eid, int $cid): ?array { $d = self::doneKeys($eid); foreach (self::steps($cid) as $st) if ($st['required'] && !isset($d[$st['key']])) return $st; return null; }
    /** Dans un cours « par étapes », une étape n'est accessible que si toutes les étapes obligatoires précédentes sont terminées. */
    static function canAccess(int $eid, array $course, string $key): bool {
        if (empty($course['sequential'])) return true; $d = self::doneKeys($eid);
        foreach (self::steps((int)$course['id']) as $st) { if ($st['key'] === $key) return true; if ($st['required'] && !isset($d[$st['key']])) return false; } return false;
    }
    /** Clôt automatiquement le cours quand il n'a pas de quiz final et que toutes les étapes obligatoires sont faites. */
    static function maybeComplete(int $eid): bool {
        $e = DB::one('SELECT en.*, c.title, c.created_by, c.training_id, c.id cid, c.pass_pct FROM el_enrollments en JOIN el_courses c ON c.id=en.course_id WHERE en.id=?', [$eid]); if (!$e || $e['status'] === 'passed') return false;
        if (DB::val('SELECT 1 FROM el_questions WHERE course_id=? AND node_id IS NULL', [(int)$e['cid']]) || !self::steps((int)$e['cid']) || self::pending($eid, (int)$e['cid'])) return false;
        $avg = DB::val('SELECT AVG(m) FROM (SELECT MAX(score_pct) m FROM el_attempts WHERE enrollment_id=? AND node_id IS NOT NULL AND passed=1 GROUP BY node_id) x', [$eid]); $pct = $avg !== null && $avg !== false ? round((float)$avg, 2) : 100.0;
        DB::update('el_enrollments', ['status' => 'passed', 'best_pct' => $pct, 'completed_at' => now()], 'id=?', [$eid]); Sat::requestCourse($eid);
        $course = DB::one('SELECT * FROM el_courses WHERE id=?', [(int)$e['cid']]); self::syncTraining($course, $e, $pct);
        Notifier::send((int)$e['user_id'], 'Cours terminé', $e['title'] . ' — félicitations !', '/learn/' . $eid);
        if ($e['assigned_by']) Notifier::send((int)$e['assigned_by'], 'Cours réussi', (string)DB::val('SELECT name FROM users WHERE id=?', [(int)$e['user_id']]) . ' — ' . $e['title'], '/elearn/report'); return true;
    }
    /** Titres (parcours ou cours) à valider avant d'accéder à un cours de niveau intermédiaire / avancé du même domaine. Vide si la règle est désactivée. */
    static function levelMissing(array $course, int $userId): array {
        if (!Xchg::on('elearn.level_gate') || empty($course['level']) || $course['level'] === 'beginner') return [];
        $dom = (string)($course['domain'] ?? ''); $passed = fn(string $col) => "NOT EXISTS (SELECT 1 FROM el_enrollments en WHERE en.course_id=$col AND en.user_id=" . (int)$userId . " AND en.status='passed')";
        $miss = [];
        if ($course['level'] === 'intermediate') {
            $paths = DB::all("SELECT id, name FROM el_paths WHERE active=1 AND level='beginner' AND COALESCE(domain,'')=?", [$dom]);
            if ($paths) { foreach ($paths as $p) if (DB::val("SELECT 1 FROM el_path_courses pc JOIN el_courses c ON c.id=pc.course_id WHERE pc.path_id=? AND c.status='published' AND " . $passed('c.id'), [(int)$p['id']])) $miss[] = 'Parcours « ' . $p['name'] . ' »'; }
            else foreach (DB::all("SELECT c.id, c.title FROM el_courses c WHERE c.status='published' AND c.level='beginner' AND COALESCE(c.domain,'')=? AND " . $passed('c.id'), [$dom]) as $c) $miss[] = $c['title'];
        } else foreach (DB::all("SELECT c.id, c.title FROM el_courses c WHERE c.status='published' AND c.level='intermediate' AND c.id<>? AND COALESCE(c.domain,'')=? AND " . $passed('c.id'), [(int)$course['id'], $dom]) as $c) $miss[] = $c['title'];
        return $miss;
    }
    /** Situation d'un apprenant par domaine : pour chaque niveau, cours publiés / cours réussis. */
    static function levelStatus(int $userId): array {
        $out = []; foreach (DB::all("SELECT COALESCE(c.domain,'') dom, c.level, COUNT(*) n, SUM(CASE WHEN EXISTS (SELECT 1 FROM el_enrollments en WHERE en.course_id=c.id AND en.user_id=? AND en.status='passed') THEN 1 ELSE 0 END) ok FROM el_courses c WHERE c.status='published' AND c.level IS NOT NULL AND c.level<>'' GROUP BY COALESCE(c.domain,''), c.level", [$userId]) as $r) $out[$r['dom']][$r['level']] = ['n' => (int)$r['n'], 'ok' => (int)$r['ok']];
        return $out;
    }
    /** Bloc d'une question au formateur : fil de discussion privé de l'apprenant sur une partie. */
    static function thread(int $cid, ?int $nodeId, int $userId, bool $create = true): ?int {
        $t = DB::val('SELECT id FROM el_threads WHERE course_id=? AND user_id=? AND ' . ($nodeId ? 'node_id=?' : 'node_id IS NULL'), $nodeId ? [$cid, $userId, $nodeId] : [$cid, $userId]);
        if ($t) return (int)$t; if (!$create) return null;
        return DB::insert('el_threads', ['course_id' => $cid, 'node_id' => $nodeId, 'user_id' => $userId, 'status' => 'open', 'created_at' => now(), 'last_at' => now()]);
    }
    /** Destinataires des questions d'un cours : formateur désigné, sinon auteur et gestionnaires e-learning. @return int[] */
    static function trainers(int $cid): array {
        $c = DB::one('SELECT trainer_id, created_by FROM el_courses WHERE id=?', [$cid]); $ids = [];
        if ($c && $c['trainer_id']) $ids[] = (int)$c['trainer_id'];
        else { if ($c && $c['created_by']) $ids[] = (int)$c['created_by']; foreach (DB::all("SELECT DISTINCT ur.user_id FROM user_roles ur JOIN roles r ON r.id=ur.role_id LEFT JOIN role_permissions rp ON rp.role_id=r.id LEFT JOIN permissions p ON p.id=rp.permission_id JOIN users u ON u.id=ur.user_id WHERE u.status='active' AND (p.code IN ('elearn.manage','*'))") as $r) $ids[] = (int)$r['user_id']; }
        return array_values(array_unique($ids));
    }
    /** Questions avec leurs options ; $withCorrect=false retire l'indication des bonnes réponses (affichage avant correction). */
    static function questions(int $cid, bool $withCorrect = true, ?array $only = null, ?int $nodeId = null): array {
        $qs = $nodeId ? DB::all('SELECT * FROM el_questions WHERE course_id=? AND node_id=? ORDER BY position, id', [$cid, $nodeId]) : DB::all('SELECT * FROM el_questions WHERE course_id=? AND node_id IS NULL ORDER BY position, id', [$cid]);
        if ($only !== null && !$nodeId) $qs = DB::all('SELECT * FROM el_questions WHERE course_id=? ORDER BY position, id', [$cid]);
        if ($only !== null) $qs = array_values(array_filter($qs, fn($q) => in_array((int)$q['id'], $only, true)));
        foreach ($qs as &$q) {
            $q['options'] = DB::all('SELECT id, question_id, text' . ($withCorrect ? ', correct' : '') . ' FROM el_options WHERE question_id=? ORDER BY id', [(int)$q['id']]);
        }
        return $qs;
    }
    /** Questions d'une tentative : le tirage mémorisé à son ouverture (toutes les questions pour une ancienne tentative). */
    static function attemptQuestions(array $attempt, int $cid, bool $withCorrect = true): array {
        $ids = !empty($attempt['question_ids']) ? array_map('intval', explode(',', $attempt['question_ids'])) : null;
        return self::questions($cid, $withCorrect, $ids);
    }
    /** Tirage aléatoire (sans remise) de draw_count questions dans la banque, ou toutes si draw_count = 0. @return int[] */
    static function draw(array $course): array {
        $ids = array_map('intval', array_column(DB::all('SELECT id FROM el_questions WHERE course_id=? AND node_id IS NULL ORDER BY id', [(int)$course['id']]), 'id'));
        $n = (int)($course['draw_count'] ?? 0);
        if ($n > 0 && $n < count($ids)) { shuffle($ids); $ids = array_slice($ids, 0, $n); }
        sort($ids); return $ids;
    }
    /** Titres des cours prérequis que l'utilisateur n'a pas encore réussis. */
    static function missingPrereqs(int $cid, int $userId): array {
        return array_column(DB::all("SELECT c.title FROM el_prereqs p JOIN el_courses c ON c.id=p.requires_id WHERE p.course_id=? AND NOT EXISTS (SELECT 1 FROM el_enrollments en WHERE en.course_id=p.requires_id AND en.user_id=? AND en.status='passed') ORDER BY c.title", [$cid, $userId]), 'title');
    }
    /** Vrai si imposer $requires comme prérequis de $cid créerait une boucle (A exige B qui exige A…). */
    static function wouldCycle(int $cid, int $requires): bool {
        if ($cid === $requires) return true;
        $seen = []; $todo = [$requires];
        while ($todo) { $x = array_pop($todo); if ($x === $cid) return true; if (isset($seen[$x])) continue; $seen[$x] = 1; foreach (DB::all('SELECT requires_id FROM el_prereqs WHERE course_id=?', [$x]) as $r) $todo[] = (int)$r['requires_id']; }
        return false;
    }
    /** URL d'intégration pour YouTube / Vimeo uniquement (liste blanche stricte, identifiant validé) ; null pour tout autre lien. */
    static function embedUrl(?string $url): ?string {
        $u = parse_url((string)$url); if (!$u || ($u['scheme'] ?? '') !== 'https' || empty($u['host']) || isset($u['user'])) return null;
        $h = strtolower($u['host']); $path = $u['path'] ?? ''; parse_str($u['query'] ?? '', $q);
        if (in_array($h, ['youtube.com', 'www.youtube.com', 'm.youtube.com', 'youtube-nocookie.com', 'www.youtube-nocookie.com'], true)) {
            $id = ($path === '/watch') ? ($q['v'] ?? '') : (preg_match('#^/(?:embed|shorts|live)/([A-Za-z0-9_-]{11})$#', $path, $m) ? $m[1] : '');
        } elseif ($h === 'youtu.be') { $id = ltrim($path, '/'); }
        elseif (in_array($h, ['vimeo.com', 'www.vimeo.com', 'player.vimeo.com'], true) && preg_match('#^/(?:video/)?(\d{6,12})$#', $path, $m)) return 'https://player.vimeo.com/video/' . $m[1];
        else return null;
        return is_string($id) && preg_match('/^[A-Za-z0-9_-]{11}$/', $id) ? 'https://www.youtube-nocookie.com/embed/' . $id : null;
    }
    /** Numéro de certificat dérivé de l'inscription (unique et reproductible). */
    static function certNo(array $enr): string { return 'CERT-' . date('y', strtotime($enr['completed_at'] ?? 'now')) . '-' . str_pad((string)$enr['id'], 5, '0', STR_PAD_LEFT); }
    /** Mélange reproductible (même ordre à chaque affichage d'une tentative). */
    static function shuffle(array $rows, int $seed): array { usort($rows, fn($a, $b) => crc32($seed . '-' . $a['id']) <=> crc32($seed . '-' . $b['id'])); return $rows; }
    /** Erreurs empêchant la publication. */
    static function publishErrors(int $cid): array {
        $err = [];
        if (!self::lessons($cid)) $err[] = 'Ajoutez au moins une leçon.';
        $qs = self::questions($cid);
        if (!$qs && !DB::val('SELECT 1 FROM el_questions WHERE course_id=? AND node_id IS NOT NULL', [$cid]) && !DB::val('SELECT 1 FROM el_activities WHERE course_id=? AND required=1', [$cid])) $err[] = 'Ajoutez au moins une question au quiz.';
        foreach (self::nodes($cid) as $n) if (!empty($n['leaf'])) { if ($n['kind'] === 'video' && !$n['url'] && !$n['file_stored'] && !RichHtml::hasVideo($n['body'])) $err[] = 'Partie « ' . $n['title'] . ' » : une vidéo est requise (module vidéo).'; if ($n['kind'] === 'text' && trim(RichHtml::text($n['body'])) === '' && !$n['url'] && !$n['file_stored']) $err[] = 'Partie « ' . $n['title'] . ' » : contenu vide.'; }
        foreach (DB::all('SELECT DISTINCT q.node_id FROM el_questions q WHERE q.course_id=? AND q.node_id IS NOT NULL', [$cid]) as $nq) foreach (self::questions($cid, true, null, (int)$nq['node_id']) as $i => $q) { $ok = count(array_filter($q['options'], fn($o) => $o['correct'])); if (count($q['options']) < 2 || $ok < 1) $err[] = 'Quiz de partie : une question est incomplète.'; }
        $c = DB::one('SELECT draw_count FROM el_courses WHERE id=?', [$cid]); if ($c && (int)$c['draw_count'] > count($qs)) $err[] = 'Le tirage (' . (int)$c['draw_count'] . ' questions) dépasse la banque (' . count($qs) . ' questions).';
        foreach ($qs as $i => $q) {
            $n = count($q['options']); $ok = count(array_filter($q['options'], fn($o) => $o['correct']));
            if ($n < 2) $err[] = 'Question ' . ($i + 1) . ' : au moins 2 réponses.';
            elseif ($ok < 1) $err[] = 'Question ' . ($i + 1) . ' : aucune bonne réponse.';
            elseif ($q['kind'] === 'single' && $ok !== 1) $err[] = 'Question ' . ($i + 1) . ' : une seule bonne réponse attendue.';
        }
        return $err;
    }
    static function enroll(int $cid, int $userId, ?int $by, ?string $due): ?int {
        if (DB::val('SELECT 1 FROM el_enrollments WHERE course_id=? AND user_id=?', [$cid, $userId])) return null;
        $emp = DB::val('SELECT employee_id FROM users WHERE id=?', [$userId]);
        $id = DB::insert('el_enrollments', ['course_id' => $cid, 'user_id' => $userId, 'employee_id' => $emp ?: null, 'assigned_by' => $by, 'status' => 'assigned', 'due_date' => $due ?: null, 'attempts' => 0, 'created_at' => now()]);
        $c = DB::one('SELECT title FROM el_courses WHERE id=?', [$cid]);
        Notifier::send($userId, 'Nouveau cours à suivre', ($c['title'] ?? '') . ($due ? ' — à terminer avant le ' . d($due) : ''), '/learn/' . $id);
        return $id;
    }
    /** Rappels affichés sur le tableau de bord de l'apprenant. @return list<array{level:string,text:string,url:string}> */
    static function reminders(int $uid): array {
        $out = []; $soon = date('Y-m-d', strtotime('+' . Xchg::int('elearn.remind_days', 0, 60) . ' days')); $today = date('Y-m-d');
        foreach (DB::all("SELECT en.id, en.due_date, en.status, c.title FROM el_enrollments en JOIN el_courses c ON c.id=en.course_id WHERE en.user_id=? AND c.status='published' AND en.status IN ('assigned','in_progress') AND en.due_date IS NOT NULL AND en.due_date<=? ORDER BY en.due_date", [$uid, $soon]) as $r)
            $out[] = $r['due_date'] < $today ? ['level' => 'danger', 'text' => 'En retard : « ' . $r['title'] . ' » (échéance ' . d($r['due_date']) . ')', 'url' => '/learn/' . $r['id']] : ['level' => 'warning', 'text' => 'À terminer avant le ' . d($r['due_date']) . ' : « ' . $r['title'] . ' »', 'url' => '/learn/' . $r['id']];
        foreach (DB::all("SELECT s.enrollment_id, c.title FROM el_surveys s JOIN el_courses c ON c.id=s.course_id WHERE s.user_id=? AND s.status='pending'", [$uid]) as $r) $out[] = ['level' => 'warning', 'text' => 'Donnez votre avis sur « ' . $r['title'] . ' » (enquête de satisfaction)', 'url' => '/learn/' . $r['enrollment_id'] . '/survey'];
        $lim = date('Y-m-d H:i:s', time() - Xchg::int('elearn.inactive_days', 1, 365) * 86400);
        foreach (DB::all("SELECT en.id, c.title, COALESCE((SELECT MAX(p.done_at) FROM el_progress p WHERE p.enrollment_id=en.id), en.started_at, en.created_at) last FROM el_enrollments en JOIN el_courses c ON c.id=en.course_id WHERE en.user_id=? AND c.status='published' AND en.status='in_progress'", [$uid]) as $r)
            if ($r['last'] && $r['last'] < $lim) $out[] = ['level' => 'info', 'text' => 'Reprenez « ' . $r['title'] . ' » : pas d\'activité depuis le ' . d(substr($r['last'], 0, 10)), 'url' => '/learn/' . $r['id']];
        foreach (DB::all("SELECT s.enrollment_id, a.title FROM el_submissions s JOIN el_activities a ON a.id=s.activity_id JOIN el_enrollments en ON en.id=s.enrollment_id WHERE en.user_id=? AND s.status='returned'", [$uid]) as $r) $out[] = ['level' => 'warning', 'text' => 'Travail à reprendre : « ' . $r['title'] . ' » (retour du formateur)', 'url' => '/learn/' . $r['enrollment_id']];
        foreach (DB::all("SELECT t.id, c.title FROM el_threads t JOIN el_courses c ON c.id=t.course_id WHERE t.user_id=? AND t.status='answered'", [$uid]) as $r) $out[] = ['level' => 'success', 'text' => 'Le formateur a répondu à votre question sur « ' . $r['title'] . ' »', 'url' => '/learn/ask/' . $r['id']];
        foreach (DB::all("SELECT r.id, r.title, r.status FROM el_requests r WHERE r.user_id=? AND r.status<>'pending' AND r.decided_at>=?", [$uid, date('Y-m-d H:i:s', time() - 7 * 86400)]) as $r) $out[] = ['level' => $r['status'] === 'approved' ? 'success' : 'secondary', 'text' => 'Votre demande « ' . $r['title'] . ' » a été ' . ($r['status'] === 'approved' ? 'acceptée' : 'refusée'), 'url' => '/learn/requests'];
        return $out;
    }
    /** Prochaine étape à faire pour une inscription (ou null). */
    static function nextStep(int $eid, int $cid): ?array { return self::pending($eid, $cid); }
    static function progress(int $eid, int $cid): array {
        $leaves = array_map('intval', array_column(self::lessons($cid), 'id')); $total = count($leaves);
        $done = $leaves ? (int)DB::val('SELECT COUNT(DISTINCT lesson_id) FROM el_progress WHERE enrollment_id=? AND lesson_id IN (' . implode(',', $leaves) . ')', [$eid]) : 0;
        $steps = array_values(array_filter(self::steps($cid), fn($s) => $s['required'])); $dk = self::doneKeys($eid); $sd = count(array_filter($steps, fn($s) => isset($dk[$s['key']])));
        return ['total' => $total, 'done' => $done, 'pct' => $total ? (int)round($done / $total * 100) : 100, 'steps' => count($steps), 'steps_done' => $sd, 'steps_pct' => $steps ? (int)round($sd / count($steps) * 100) : 100];
    }
    /**
     * Corrige une tentative (questions tirées) à partir de $_POST['q'][id_question] ; enregistre les réponses.
     * Réponse unique et « tout ou rien » : 1 point si exactement les bonnes options, sinon 0.
     * Réponses multiples en « points partiels » : max(0, (bonnes cochées − mauvaises cochées) / nombre de bonnes).
     * @return array{0:float,1:bool,2:array}
     */
    static function grade(array $course, array $attempt, array $post): array {
        $qs = self::attemptQuestions($attempt, (int)$course['id']); $sum = 0.0; $detail = [];
        foreach ($qs as $q) {
            $valid = array_map('intval', array_column($q['options'], 'id')); $right = array_map('intval', array_column(array_filter($q['options'], fn($o) => $o['correct']), 'id'));
            $sel = $post['q'][$q['id']] ?? []; $sel = array_values(array_unique(array_filter(array_map('intval', (array)$sel), fn($v) => in_array($v, $valid, true)))); sort($sel); sort($right);
            if ($q['kind'] === 'single' && count($sel) > 1) $sel = [];                 // plusieurs cases forcées sur une question unique : non valide
            $frac = 0.0;
            if ($right) {
                if ($sel === $right) $frac = 1.0;
                elseif ($q['kind'] === 'multi' && ($q['scoring'] ?? 'strict') === 'partial') $frac = max(0.0, (count(array_intersect($sel, $right)) - count(array_diff($sel, $right))) / count($right));
            }
            $sum += $frac;
            DB::insert('el_answers', ['attempt_id' => (int)$attempt['id'], 'question_id' => (int)$q['id'], 'selected' => implode(',', $sel), 'correct' => $frac >= 1.0 ? 1 : 0, 'score' => round($frac, 4)]);
            $detail[(int)$q['id']] = $frac;
        }
        $pct = $qs ? round($sum / count($qs) * 100, 2) : 0.0;
        return [$pct, $pct >= (int)$course['pass_pct'], $detail];
    }
    /** Si le cours est relié à une formation du catalogue, enregistre la réussite comme une session « en ligne » validée. */
    static function syncTraining(array $course, array $enr, float $pct): void {
        if (!$course['training_id'] || !$enr['employee_id']) return;
        $t = DB::one('SELECT * FROM trainings WHERE id=?', [(int)$course['training_id']]); if (!$t) return;
        $s = DB::val("SELECT id FROM training_sessions WHERE training_id=? AND location='En ligne (e-learning)' ORDER BY id LIMIT 1", [(int)$t['id']]);
        if (!$s) $s = DB::insert('training_sessions', ['training_id' => (int)$t['id'], 'session_date' => date('Y-m-d'), 'location' => 'En ligne (e-learning)', 'trainer' => 'E-learning', 'status' => 'done', 'created_by' => $course['created_by'], 'created_at' => now()]);
        $valid = $t['validity_months'] ? date('Y-m-d', strtotime('+' . (int)$t['validity_months'] . ' months')) : null;
        $row = ['status' => 'passed', 'score' => $pct, 'valid_until' => $valid, 'note' => 'Cours e-learning : ' . mb_substr($course['title'], 0, 200)];
        $e = DB::val('SELECT id FROM training_enrollments WHERE session_id=? AND employee_id=?', [(int)$s, (int)$enr['employee_id']]);
        if ($e) DB::update('training_enrollments', $row, 'id=?', [(int)$e]); else DB::insert('training_enrollments', $row + ['session_id' => (int)$s, 'employee_id' => (int)$enr['employee_id']]);
    }
}
