<?php
namespace App\Core;
/**
 * Escalades d'incidents vers les équipes support (exploitation des outils, IT matériel, infrastructure, énergie…).
 * Notifications : dans l'outil, par e-mail (file at_outbox) et par SMS (file sms_outbox) ; chaque envoi est tracé dans inc_notif_log.
 * Le personnel support est géré dans inc_support_members : ce ne sont pas des collaborateurs (table employees), ils ne comptent donc dans aucun plan RH.
 */
class IncEsc {
    const ROLES = ['lead' => 'Responsable d\'équipe', 'manager' => 'Manager / direction', 'oncall' => 'Astreinte', 'engineer' => 'Ingénieur / expert', 'tech' => 'Technicien / intervenant', 'dispatcher' => 'Superviseur / dispatcher'];
    const STATUS = ['pending' => 'À prendre en compte', 'ack' => 'Pris en compte', 'working' => 'En traitement', 'done' => 'Retour fourni', 'declined' => 'Hors périmètre', 'closed' => 'Retirée'];
    const STATUS_KIND = ['pending' => 'warning', 'ack' => 'info', 'working' => 'primary', 'done' => 'success', 'declined' => 'secondary', 'closed' => 'secondary'];
    const OPEN = ['pending', 'ack', 'working'];
    const RANK = ['P1' => 1, 'P2' => 2, 'P3' => 3, 'P4' => 4];
    /** Limites par gravité, en minutes : ack = délai de prise en compte, step = délai avant passage au niveau supérieur, fb = délai du retour après prise en compte. */
    const LIMITS = ['P1' => ['ack' => 10, 'step' => 20, 'fb' => 240], 'P2' => ['ack' => 20, 'step' => 45, 'fb' => 480], 'P3' => ['ack' => 120, 'step' => 240, 'fb' => 1440], 'P4' => ['ack' => 480, 'step' => 1440, 'fb' => 4320]];
    const DEFAULTS = ['inc.esc_auto_sev' => 'P2', 'inc.esc_sms_sev' => 'P2', 'inc.esc_max_level' => '3', 'inc.esc_limits' => ''];
    /** [code, libellé, familles d'incident couvertes] */
    const TEAMS = [
        ['EXPLOIT', 'Exploitation des outils (CRM, ACD, téléphonie, applicatifs)', 'IT'], ['ITHW', 'IT matériel (postes, casques, périphériques)', 'HW'],
        ['INFRA', 'Infrastructure réseau et systèmes', 'NET,FIX'], ['ENERGIE', 'Énergie et climatisation', 'ENE'], ['MOMO', 'Support Mobile Money et paiements', 'MM'],
        ['SECU', 'Sécurité des systèmes d\'information', 'SEC'], ['FACIL', 'Moyens généraux et sites', 'FAC'], ['TIERS', 'Relations fournisseurs et prestataires', 'EXT'],
    ];

    static function set(string $k) { return Settings::get($k, self::DEFAULTS[$k] ?? null); }
    static function limits(string $sev): array {
        $d = self::LIMITS[$sev] ?? self::LIMITS['P3']; $j = json_decode((string)self::set('inc.esc_limits'), true); $o = is_array($j) && is_array($j[$sev] ?? null) ? $j[$sev] : [];
        return ['ack' => max(1, (int)($o['ack'] ?? $d['ack'])), 'step' => max(1, (int)($o['step'] ?? $d['step'])), 'fb' => max(1, (int)($o['fb'] ?? $d['fb']))];
    }
    static function maxLevel(): int { return max(1, min(5, (int)self::set('inc.esc_max_level'))); }
    static function within(string $sev, string $key): bool { $a = (string)self::set($key); return $a !== '' && $a !== 'none' && (self::RANK[$sev] ?? 9) <= (self::RANK[$a] ?? 0); }
    static function autoOn(string $sev): bool { return self::within($sev, 'inc.esc_auto_sev'); }
    static function smsOn(string $sev): bool { return self::within($sev, 'inc.esc_sms_sev'); }
    static function statusBadge(?string $s): string { return $s && isset(self::STATUS[$s]) ? badge(self::STATUS[$s], self::STATUS_KIND[$s]) : ''; }
    static function url(string $path): string { return (string)env('APP_URL', '') !== '' ? rtrim((string)env('APP_URL'), '/') . $path : ''; }

    /** Équipes support actives qui couvrent la famille d'un incident. */
    static function teamsFor(string $family): array {
        return array_values(array_filter(DB::all('SELECT * FROM inc_support_teams WHERE active=1 ORDER BY sort_order, name'), fn($t) => in_array($family, array_filter(array_map('trim', explode(',', (string)$t['families']))), true)));
    }
    static function userTeams(int $uid): array { return array_map('intval', array_column(DB::all('SELECT DISTINCT m.team_id FROM inc_support_members m JOIN inc_support_teams t ON t.id=m.team_id WHERE m.user_id=? AND m.active=1 AND t.active=1', [$uid]), 'team_id')); }
    /** Équipes visibles par l'utilisateur courant : toutes pour les gestionnaires d'incidents, sinon les siennes. */
    static function scope(): ?array { return can('inc.manage') ? null : self::userTeams((int)Auth::id()); }
    static function recipients(int $teamId, int $level): array {
        $all = DB::all('SELECT * FROM inc_support_members WHERE team_id=? AND active=1 ORDER BY level, name', [$teamId]);
        $r = array_values(array_filter($all, fn($m) => (int)$m['level'] === $level || ($level === 1 && (int)$m['on_call'] === 1)));
        if (!$r) $r = array_values(array_filter($all, fn($m) => (int)$m['level'] >= $level));
        return $r ?: $all;
    }
    private static function log(int $inc, ?int $esc, ?array $m, string $ch, string $st, string $detail = ''): void {
        DB::insert('inc_notif_log', ['incident_id' => $inc, 'escalation_id' => $esc, 'member_id' => $m ? (int)$m['id'] : null, 'member_name' => $m['name'] ?? null, 'channel' => $ch, 'status' => $st, 'detail' => mb_substr($detail, 0, 300) ?: null, 'created_at' => now()]);
    }
    /** Notifie les membres concernés sur les 3 canaux selon leurs préférences. @return int nombre de destinataires */
    static function notify(int $escId, array $inc, array $team, int $level, string $prefix, string $extra = ''): int {
        $sev = (string)$inc['severity']; $svc = Inc::SERVICES[$inc['service']] ?? (string)$inc['service']; $path = '/support/incidents/' . (int)$inc['id']; $link = self::url($path);
        $head = $prefix . ' ' . $sev . ' · ' . $inc['reference'] . ' · ' . $team['name'];
        $body = $inc['title'] . ' — service : ' . $svc . ' — depuis le ' . dt($inc['started_at']) . ' — niveau ' . $level . ($extra !== '' ? ' — ' . $extra : '');
        $n = 0;
        foreach (self::recipients((int)$team['id'], $level) as $m) {
            $n++; $iid = (int)$inc['id'];
            if ((int)$m['notify_inapp']) { if ($m['user_id'] && DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [(int)$m['user_id']])) { Notifier::send((int)$m['user_id'], $head, $body, $path); self::log($iid, $escId, $m, 'inapp', 'sent'); } else self::log($iid, $escId, $m, 'inapp', 'skipped', 'pas de compte d\'accès à l\'outil'); }
            if ((int)$m['notify_email']) {
                if (!$m['email']) self::log($iid, $escId, $m, 'email', 'skipped', 'pas d\'adresse e-mail');
                else { $txt = "Bonjour {$m['name']},\n\n$head\n\n$body\n\n" . trim((string)$inc['description']) . "\n\n" . ($link ? "Prendre en compte et fournir votre retour : $link\n\n" : '') . 'Message automatique de la gestion des incidents.';
                    self::log($iid, $escId, $m, 'email', Mailer::queue($m['email'], '[' . $inc['reference'] . '] ' . $head, $txt) ? 'queued' : 'skipped', Mailer::enabled() ? '' : 'envoi d\'e-mails non configuré (SMTP_HOST)'); }
            }
            if ((int)$m['notify_sms']) {
                $ph = Sms::normalize($m['phone']);
                if (!self::smsOn($sev)) self::log($iid, $escId, $m, 'sms', 'skipped', 'SMS réservés aux gravités ≥ seuil');
                elseif (!$ph) self::log($iid, $escId, $m, 'sms', 'skipped', 'numéro absent ou invalide');
                else self::log($iid, $escId, $m, 'sms', Sms::queue($ph, $prefix . ' ' . $sev . ' ' . $inc['reference'] . ' ' . $team['name'] . ': ' . mb_substr($inc['title'], 0, 90) . ' (niv.' . $level . '). Accusez réception dans l\'outil.' . ($link ? ' ' . $link : ''), $iid) ? 'queued' : 'skipped', Sms::enabled() ? '' : 'passerelle SMS non configurée (SMS_GATEWAY_URL)');
            }
        }
        return $n;
    }
    /** Ouvre une escalade ; null si l'équipe est inactive ou déjà sollicitée sur cet incident. */
    static function open(array $inc, int $teamId, int $level, string $reason = '', ?int $by = null, bool $auto = false): ?int {
        $team = DB::one('SELECT * FROM inc_support_teams WHERE id=? AND active=1', [$teamId]); if (!$team) return null;
        if (DB::val("SELECT 1 FROM inc_escalations WHERE incident_id=? AND team_id=? AND status IN ('pending','ack','working')", [(int)$inc['id'], $teamId])) return null;
        $level = max(1, min(self::maxLevel(), $level)); $now = now();
        $id = DB::insert('inc_escalations', ['incident_id' => (int)$inc['id'], 'team_id' => $teamId, 'level' => $level, 'status' => 'pending', 'reason' => mb_substr($reason, 0, 500) ?: null, 'auto' => $auto ? 1 : 0, 'escalated_by' => $by, 'escalated_at' => $now, 'level_at' => $now, 'created_at' => $now]);
        Inc::event((int)$inc['id'], 'escalade', 'Escalade vers « ' . $team['name'] . ' » (niveau ' . $level . ($auto ? ', automatique' : '') . ')' . ($reason !== '' ? ' : ' . $reason : ''), $by);
        $n = self::notify($id, $inc, $team, $level, 'ESCALADE');
        if (!$n) Inc::event((int)$inc['id'], 'escalade', 'Attention : l\'équipe « ' . $team['name'] . ' » n\'a aucun membre actif à notifier.', $by);
        return $id;
    }
    /** Escalade automatique à la déclaration (selon la gravité et les familles couvertes par les équipes). */
    static function autoOpen(array $inc): int {
        if (!self::autoOn((string)$inc['severity'])) return 0; $n = 0;
        foreach (self::teamsFor((string)$inc['family']) as $t) if (self::open($inc, (int)$t['id'], 1, 'Escalade automatique (gravité ' . $inc['severity'] . ')', null, true)) $n++;
        return $n;
    }
    /** Passe au niveau supérieur ; false si le niveau maximum est atteint. */
    static function bump(int $escId, bool $auto = false, ?int $by = null): bool {
        $e = DB::one('SELECT * FROM inc_escalations WHERE id=?', [$escId]); if (!$e || !in_array($e['status'], self::OPEN, true)) return false;
        $inc = DB::one('SELECT * FROM inc_incidents WHERE id=?', [(int)$e['incident_id']]); $team = DB::one('SELECT * FROM inc_support_teams WHERE id=?', [(int)$e['team_id']]); if (!$inc || !$team) return false;
        $lvl = (int)$e['level'] + 1; if ($lvl > self::maxLevel()) return false;
        DB::update('inc_escalations', ['level' => $lvl, 'level_at' => now(), 'last_alert_at' => now()], 'id=?', [$escId]);
        Inc::event((int)$inc['id'], 'escalade', 'Escalade de « ' . $team['name'] . ' » au niveau ' . $lvl . ($auto ? ' (automatique : délai dépassé)' : ''), $by);
        self::notify($escId, $inc, $team, $lvl, 'ESCALADE NIVEAU ' . $lvl, $auto ? 'délai de prise en compte dépassé' : '');
        Notifier::toPermission('inc.manage', 'Escalade niveau ' . $lvl . ' · ' . $inc['reference'], $team['name'] . ' — ' . $inc['title'], '/incidents/' . $inc['id']);
        return true;
    }
    static function ack(int $escId, int $uid): void {
        $e = DB::one('SELECT * FROM inc_escalations WHERE id=?', [$escId]); if (!$e || $e['status'] !== 'pending') return;
        DB::update('inc_escalations', ['status' => 'ack', 'acked_at' => now(), 'acked_by' => $uid], 'id=?', [$escId]);
        $inc = DB::one('SELECT * FROM inc_incidents WHERE id=?', [(int)$e['incident_id']]); $team = (string)DB::val('SELECT name FROM inc_support_teams WHERE id=?', [(int)$e['team_id']]);
        Inc::event((int)$inc['id'], 'support', 'Prise en compte par « ' . $team . ' » (' . (string)DB::val('SELECT name FROM users WHERE id=?', [$uid]) . ').', $uid);
        self::tell($inc, 'Prise en compte · ' . $inc['reference'], $team . ' a pris en compte l\'incident.');
    }
    /** Informe le responsable de l'incident, à défaut les gestionnaires d'incidents. */
    static function tell(array $inc, string $title, string $body): void {
        if ($inc['owner_id']) Notifier::send((int)$inc['owner_id'], $title, $body, '/incidents/' . $inc['id']); else Notifier::toPermission('inc.manage', $title, $body, '/incidents/' . $inc['id']);
    }
    /** Tâche planifiée : relances, passage au niveau supérieur, retours manquants. @return array{0:int,1:int,2:int} niveaux, relances prise en compte, relances retour */
    static function cron(): array {
        $b = $r = $f = 0; $now = time();
        foreach (DB::all("SELECT e.*, i.severity, i.status AS istatus FROM inc_escalations e JOIN inc_incidents i ON i.id=e.incident_id WHERE e.status IN ('pending','ack','working') AND i.status IN ('new','ack','diag','mitigated')") as $e) {
            $lim = self::limits((string)$e['severity']); $last = $e['last_alert_at'] ? strtotime($e['last_alert_at']) : 0;
            if ($e['status'] === 'pending') {
                $age = ($now - strtotime($e['level_at'])) / 60;
                if ($age >= $lim['step']) { if ((int)$e['level'] < self::maxLevel()) { if (self::bump((int)$e['id'], true)) $b++; continue; } }
                if ($age >= $lim['ack'] && $now - $last >= 1800) { self::remind($e, 'Prise en compte attendue', 'délai de ' . Inc::dur($lim['ack']) . ' dépassé'); $r++; }
            } elseif (!$e['feedback'] && $e['acked_at'] && ($now - strtotime($e['acked_at'])) / 60 >= $lim['fb'] && $now - $last >= 3600) { self::remind($e, 'Retour attendu', 'aucun retour après ' . Inc::dur($lim['fb'])); $f++; }
        }
        return [$b, $r, $f];
    }
    private static function remind(array $e, string $prefix, string $why): void {
        $inc = DB::one('SELECT * FROM inc_incidents WHERE id=?', [(int)$e['incident_id']]); $team = DB::one('SELECT * FROM inc_support_teams WHERE id=?', [(int)$e['team_id']]); if (!$inc || !$team) return;
        DB::update('inc_escalations', ['last_alert_at' => now()], 'id=?', [(int)$e['id']]);
        self::notify((int)$e['id'], $inc, $team, (int)$e['level'], 'RAPPEL · ' . $prefix, $why);
        Notifier::toPermission('inc.manage', $prefix . ' · ' . $inc['reference'], $team['name'] . ' — ' . $why, '/incidents/' . $inc['id']);
    }
    /** Indicateurs par équipe pour les escalades ouvertes entre deux dates ($teamIds = null : toutes). */
    static function stats(string $from, string $to, ?array $teamIds = null, ?callable $keep = null): array {
        $w = 'e.escalated_at>=? AND e.escalated_at<=?'; $p = [$from . ' 00:00:00', $to . ' 23:59:59'];
        if ($teamIds !== null) { if (!$teamIds) return []; $w .= ' AND e.team_id IN (' . implode(',', array_map('intval', $teamIds)) . ')'; }
        $out = [];
        foreach (DB::all("SELECT e.*, i.severity, i.status AS istatus, i.started_at, t.name AS team_name FROM inc_escalations e JOIN inc_incidents i ON i.id=e.incident_id JOIN inc_support_teams t ON t.id=e.team_id WHERE $w ORDER BY e.escalated_at", $p) as $e) {
            if ($keep && !$keep($e)) continue;
            $o = &$out[(int)$e['team_id']]; $o = $o ?? ['team' => $e['team_name'], 'n' => 0, 'open' => 0, 'late' => 0, 'ack_ok' => 0, 'ack_n' => 0, 'ack' => [], 'fb' => [], 'bumped' => 0, 'declined' => 0, 'no_fb' => 0];
            $lim = self::limits((string)$e['severity']); $o['n']++; if ((int)$e['level'] > 1) $o['bumped']++; if ($e['status'] === 'declined') $o['declined']++;
            if (in_array($e['status'], self::OPEN, true)) { $o['open']++; if ($e['status'] === 'pending' && (time() - strtotime($e['level_at'])) / 60 > $lim['ack']) $o['late']++; }
            if ($e['acked_at']) { $m = (strtotime($e['acked_at']) - strtotime($e['escalated_at'])) / 60; $o['ack'][] = $m; $o['ack_n']++; if ($m <= $lim['ack']) $o['ack_ok']++; }
            if ($e['done_at']) $o['fb'][] = (strtotime($e['done_at']) - strtotime($e['escalated_at'])) / 60;
            if (!$e['feedback'] && in_array($e['istatus'], ['resolved', 'closed'], true)) $o['no_fb']++;
            unset($o);
        }
        foreach ($out as &$o) { $o['ack_avg'] = Inc::mean($o['ack']); $o['fb_avg'] = Inc::mean($o['fb']); $o['ack_pct'] = $o['ack_n'] ? round($o['ack_ok'] / $o['ack_n'] * 100) : null; } unset($o);
        return $out;
    }
}
