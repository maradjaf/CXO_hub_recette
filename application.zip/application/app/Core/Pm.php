<?php
namespace App\Core;

/**
 * Lot 58 : Processus & Méthodes — référentiels communs (directions, criticités, catégories), SLA des MRP, journal des transitions,
 * calculs des états du tableau de bord (flux, backlog, cohorte, SLA, Pareto, exécution des actions, conformité, KPI trimestriels).
 */
final class Pm {
    const CRIT = ['high' => 'Élevée', 'medium' => 'Moyenne', 'low' => 'Faible'];
    const CRIT_C = ['high' => 'danger', 'medium' => 'warning', 'low' => 'secondary'];
    const CAT = ['process' => 'Processus', 'tool' => 'Outil', 'sla' => 'SLA', 'reporting' => 'Reporting', 'procedure' => 'Procédure'];
    const PRIO = ['critical' => 'Critique', 'high' => 'Haute', 'normal' => 'Normale', 'low' => 'Basse'];
    const MRP_ST = ['received' => 'Reçu', 'qualified' => 'Qualifié', 'in_progress' => 'En cours', 'on_hold' => 'En attente', 'to_verify' => 'À vérifier', 'closed' => 'Clôturé', 'cancelled' => 'Annulé'];
    const MRP_C = ['received' => 'info', 'qualified' => 'primary', 'in_progress' => 'warning', 'on_hold' => 'secondary', 'to_verify' => 'warning', 'closed' => 'success', 'cancelled' => 'dark'];
    const ACT_ST = ['open' => 'Ouverte', 'in_progress' => 'En cours', 'to_verify' => 'À vérifier', 'closed' => 'Clôturée', 'cancelled' => 'Annulée'];
    const ACT_C = ['open' => 'info', 'in_progress' => 'warning', 'to_verify' => 'primary', 'closed' => 'success', 'cancelled' => 'dark'];
    const ACT_SRC = ['audit' => 'Audit', 'codir' => 'CODIR', 'claim' => 'Réclamation', 'internal' => 'Contrôle interne', 'rca' => 'RCA', 'sla' => 'SLA', 'mrp' => 'MRP'];
    const AUD_ST = ['planned' => 'Planifié', 'in_progress' => 'En cours', 'reported' => 'Restitué', 'finalized' => 'Finalisé'];
    const AUD_C = ['planned' => 'secondary', 'in_progress' => 'warning', 'reported' => 'primary', 'finalized' => 'success'];
    const RESULT = ['conform' => 'Conforme', 'partial' => 'Partiel', 'nonconform' => 'Non conforme', 'na' => 'Non applicable'];
    const RESULT_PTS = ['conform' => 1.0, 'partial' => 0.5, 'nonconform' => 0.0];
    const FIND = ['nc' => 'Non-conformité', 'obs' => 'Observation', 'reco' => 'Recommandation'];
    const METHOD = ['5p' => '5 pourquoi', 'ishikawa' => 'Ishikawa', 'pareto' => 'Pareto', 'other' => 'Autre'];
    const RISK_ST = ['open' => 'Actif', 'mitigated' => 'Maîtrisé', 'closed' => 'Clos'];
    const PD_ST = ['draft' => 'En rédaction', 'in_validation' => 'En validation', 'approved' => 'Approuvée', 'published' => 'Publiée', 'obsolete' => 'Obsolète'];
    const PD_C = ['draft' => 'secondary', 'in_validation' => 'warning', 'approved' => 'info', 'published' => 'success', 'obsolete' => 'dark'];
    const VER_ST = ['draft' => 'Brouillon', 'submitted' => 'Soumise', 'returned' => 'Retournée', 'approved' => 'Approuvée', 'published' => 'Publiée', 'replaced' => 'Remplacée', 'withdrawn' => 'Retirée'];
    const VIS = ['internal' => 'Interne (tous)', 'direction' => 'Direction propriétaire', 'roles' => 'Rôles désignés'];
    const BANDS = ['late' => 'En retard', 'd30' => 'J à J+30', 'd60' => 'J+31 à J+60', 'd90' => 'J+61 à J+90', 'later' => 'Au-delà de J+90', 'none' => 'Sans échéance'];

    static function badge(array $labels, array $colors, ?string $k): string { return $k && isset($labels[$k]) ? badge($labels[$k], $colors[$k] ?? 'secondary') : badge('—', 'light text-dark border'); }
    /** Directions et départements de l'organisation (unités de niveau direction/département) + valeurs déjà utilisées. */
    static function directions(): array {
        $o = array_column(DB::all("SELECT name FROM org_units WHERE kind IN ('direction','department') AND active=1 ORDER BY kind, name"), 'name');
        foreach (['pr_gov', 'pd_procedures', 'pm_mrp', 'pm_actions', 'pm_audits'] as $t) foreach (DB::all("SELECT DISTINCT direction FROM $t WHERE direction IS NOT NULL AND direction<>''") as $r) $o[] = $r['direction'];
        $o = array_values(array_unique(array_filter($o))); sort($o, SORT_NATURAL | SORT_FLAG_CASE); return $o;
    }
    /** Direction de l'utilisateur courant déduite de son collaborateur (unité la plus haute de type direction/département). */
    static function userDirection(?int $userId = null): ?string {
        $uid = $userId ?? Auth::id(); $e = DB::one('SELECT e.org_unit_id, e.team_id FROM users u JOIN employees e ON e.id=u.employee_id WHERE u.id=?', [$uid]); if (!$e) return null;
        $id = $e['org_unit_id'] ? (int)$e['org_unit_id'] : null; $guard = 0;
        while ($id && $guard++ < 10) { $u = DB::one('SELECT id, name, kind, parent_id FROM org_units WHERE id=?', [$id]); if (!$u) break; if (in_array($u['kind'], ['direction', 'department'], true)) return $u['name']; $id = $u['parent_id'] ? (int)$u['parent_id'] : null; }
        return null;
    }
    static function event(string $entity, int $id, string $action, ?string $from = null, ?string $to = null, ?string $note = null): void {
        $uid = Auth::id(); DB::insert('pm_events', ['entity' => $entity, 'entity_id' => $id, 'user_id' => $uid, 'user_name' => $uid ? (string)DB::val('SELECT name FROM users WHERE id=?', [$uid]) : 'système', 'action' => $action, 'from_status' => $from, 'to_status' => $to, 'note' => $note ? mb_substr($note, 0, 500) : null, 'created_at' => now()]);
    }
    static function events(string $entity, int $id): array { return DB::all('SELECT * FROM pm_events WHERE entity=? AND entity_id=? ORDER BY id DESC', [$entity, $id]); }

    // ------------------------------------------------------------------ SLA
    /** Règle applicable : catégorie × priorité, sinon catégorie seule ('*'), sinon priorité seule, sinon défaut 72 h ouvrées. */
    static function slaRule(string $cat, string $prio): array {
        foreach ([[$cat, $prio], [$cat, '*'], ['*', $prio], ['*', '*']] as [$c, $p]) if ($r = DB::one('SELECT * FROM pm_sla_rules WHERE category=? AND priority=? AND active=1', [$c, $p])) return ['hours' => (int)$r['hours'], 'calendar' => $r['calendar']];
        return ['hours' => 72, 'calendar' => 'business'];
    }
    /** Ajoute des heures à une date : calendrier continu, ou heures ouvrées (lundi–vendredi, 08:00–17:00, 9 h/jour). */
    static function addHours(string $from, int $hours, string $calendar): string {
        $t = strtotime($from); if ($calendar !== 'business') return date('Y-m-d H:i:s', $t + $hours * 3600);
        $rem = $hours * 60; $guard = 0;
        while ($rem > 0 && $guard++ < 5000) {
            $dow = (int)date('N', $t); $h = (int)date('G', $t); $m = (int)date('i', $t);
            if ($dow >= 6 || $h >= 17) { $t = strtotime(date('Y-m-d', $t) . ' +1 day 08:00'); continue; }
            if ($h < 8) { $t = strtotime(date('Y-m-d', $t) . ' 08:00'); continue; }
            $left = (17 - $h) * 60 - $m; $use = min($left, $rem); $t += $use * 60; $rem -= $use;
            if ($rem > 0) $t = strtotime(date('Y-m-d', $t) . ' +1 day 08:00');
        }
        return date('Y-m-d H:i:s', $t);
    }
    static function qualify(array $m, string $prio): array {
        $rule = self::slaRule($m['category'], $prio); $from = $m['received_at'] ?: now();
        return ['sla_hours' => $rule['hours'], 'sla_calendar' => $rule['calendar'], 'sla_due' => self::addHours($from, $rule['hours'], $rule['calendar'])];
    }
    /** Échéance effective (date limite décalée des pauses journalisées). */
    static function slaEffective(array $m): ?string { if (!$m['sla_due']) return null; $paused = (int)$m['paused_min'] + ($m['paused_at'] ? (int)round((time() - strtotime($m['paused_at'])) / 60) : 0); return date('Y-m-d H:i:s', strtotime($m['sla_due']) + $paused * 60); }
    static function slaOk(array $m): ?bool { if (!$m['sla_due'] || !$m['closed_at']) return null; return strtotime($m['closed_at']) <= strtotime($m['sla_due']) + (int)$m['paused_min'] * 60; }

    // ------------------------------------------------------------------ audits
    static function score(int $auditId): array {
        $pts = 0.0; $got = 0.0; $n = 0; $nc = 0;
        foreach (DB::all('SELECT result, weight FROM pm_audit_results WHERE audit_id=?', [$auditId]) as $r) { if (!$r['result'] || $r['result'] === 'na') continue; $n++; $pts += (float)$r['weight']; $got += (float)$r['weight'] * self::RESULT_PTS[$r['result']]; if ($r['result'] === 'nonconform') $nc++; }
        return ['points' => $pts, 'obtained' => $got, 'pct' => $pts > 0 ? round(100 * $got / $pts, 1) : null, 'n' => $n, 'nc' => $nc];
    }

    // ------------------------------------------------------------------ états du tableau de bord
    static function band(?string $due, string $asOf): string {
        if (!$due) return 'none'; $d = (strtotime($due) - strtotime($asOf)) / 86400;
        if ($d < 0) return 'late'; if ($d <= 30) return 'd30'; if ($d <= 60) return 'd60'; if ($d <= 90) return 'd90'; return 'later';
    }
    static function docState(array $p, string $asOf): string { if ($p['status'] !== 'published') return $p['status']; if (!$p['review_due']) return 'nodate'; return $p['review_due'] < $asOf ? 'expired' : 'current'; }
    static function ratio($a, $b): ?float { return $b ? round(100 * $a / $b, 1) : null; }
    static function pct(?float $v): string { return $v === null ? '—' : str_replace('.', ',', (string)$v) . ' %'; }

    /** Tableau de bord complet pour un périmètre (direction ou toutes), une période de flux (mois) et une date d'arrêté. */
    static function dashboard(?string $dir, int $months, string $asOf): array {
        $asEnd = $asOf . ' 23:59:59'; $start = date('Y-m-01', strtotime($asOf . " -" . ($months - 1) . " months")); $w = $dir ? ' AND direction=?' : ''; $p = $dir ? [$dir] : [];
        $out = ['as_of' => $asOf, 'start' => $start, 'months' => []];
        for ($i = 0; $i < $months; $i++) { $m = date('Y-m', strtotime("$start +$i months")); $out['months'][] = ['key' => $m, 'label' => self::monthLabel($m), 'start' => "$m-01 00:00:00", 'end' => date('Y-m-t', strtotime("$m-01")) . ' 23:59:59']; }
        // processus
        $pw = $dir ? ' AND g.direction=?' : ''; $procs = DB::all("SELECT p.id, p.code, p.name, p.status, p.review_due, p.updated_at, p.published_at, u.name owner, g.direction, g.criticality, g.improve FROM pr_processes p LEFT JOIN pr_gov g ON g.process_id=p.id LEFT JOIN users u ON u.id=p.owner_id WHERE p.status<>'archived'$pw", $p);
        $active = array_values(array_filter($procs, fn($r) => $r['status'] === 'published')); $out['processes'] = ['all' => $procs, 'active' => $active, 'late' => array_values(array_filter($active, fn($r) => $r['review_due'] && $r['review_due'] < $asOf)), 'improve' => array_values(array_filter($active, fn($r) => $r['improve']))];
        $out['processes']['by_dir'] = self::group($active, 'direction'); $out['processes']['by_crit'] = self::group($active, 'criticality', array_keys(self::CRIT)); $out['processes']['bands'] = self::bands($active, 'review_due', $asOf);
        // procédures
        $docs = DB::all("SELECT d.*, u.name owner, (SELECT 1 FROM pd_versions v WHERE v.procedure_id=d.id AND v.state IN ('draft','submitted','returned','approved') AND d.status='published' LIMIT 1) revising FROM pd_procedures d LEFT JOIN users u ON u.id=d.owner_id WHERE 1=1" . ($dir ? ' AND d.direction=?' : ''), $p);
        foreach ($docs as &$d) $d['doc_state'] = self::docState($d, $asOf); unset($d);
        $pub = array_values(array_filter($docs, fn($d) => $d['status'] === 'published')); $withDate = array_values(array_filter($pub, fn($d) => $d['review_due']));
        $out['docs'] = ['all' => $docs, 'published' => $pub, 'with_date' => $withDate, 'current' => array_values(array_filter($withDate, fn($d) => $d['doc_state'] === 'current')), 'expired' => array_values(array_filter($withDate, fn($d) => $d['doc_state'] === 'expired')), 'nodate' => array_values(array_filter($pub, fn($d) => !$d['review_due'])),
            'obsolete' => array_values(array_filter($docs, fn($d) => $d['status'] === 'obsolete')), 'by_status' => self::group($docs, 'status', array_keys(self::PD_ST)), 'bands' => self::bands($pub, 'review_due', $asOf), 'revising' => array_values(array_filter($docs, fn($d) => $d['revising']))];
        $bd = []; foreach ($pub as $d) { $k = $d['direction'] ?: '—'; $bd[$k] ??= ['current' => [], 'expired' => [], 'nodate' => []]; $bd[$k][$d['doc_state']][] = $d; } ksort($bd); $out['docs']['by_dir'] = $bd;
        // MRP
        $mrps = DB::all("SELECT m.*, u.name assignee, c.name cause FROM pm_mrp m LEFT JOIN users u ON u.id=m.assignee_id LEFT JOIN pm_causes c ON c.id=m.cause_id WHERE m.received_at<=?" . ($dir ? ' AND m.direction=?' : '') . "", array_merge([$asEnd], $p));
        $recv = array_values(array_filter($mrps, fn($m) => $m['received_at'] >= "$start 00:00:00"));
        $closed = array_values(array_filter($mrps, fn($m) => $m['status'] === 'closed' && $m['closed_at'] && $m['closed_at'] >= "$start 00:00:00" && $m['closed_at'] <= $asEnd));
        $backlog = array_values(array_filter($mrps, fn($m) => self::openAt($m, $asEnd)));
        $cohort = array_values(array_filter($recv, fn($m) => !($m['cancelled_at'] && $m['cancelled_at'] <= $asEnd))); $cohortClosed = array_values(array_filter($cohort, fn($m) => $m['closed_at'] && $m['closed_at'] <= $asEnd && $m['status'] === 'closed'));
        $valid = array_values(array_filter($closed, fn($m) => $m['sla_due'])); $good = array_values(array_filter($valid, fn($m) => self::slaOk($m)));
        $slaLate = array_values(array_filter($backlog, fn($m) => $m['sla_due'] && self::slaEffective($m) < $asEnd));
        $mean = $closed ? round(array_sum(array_map(fn($m) => (strtotime($m['closed_at']) - strtotime($m['received_at'])) / 86400, $closed)) / count($closed), 1) : null;
        $flux = []; foreach ($out['months'] as $mo) $flux[] = ['label' => $mo['label'], 'received' => count(array_filter($mrps, fn($m) => $m['received_at'] >= $mo['start'] && $m['received_at'] <= $mo['end'])), 'closed' => count(array_filter($mrps, fn($m) => $m['status'] === 'closed' && $m['closed_at'] >= $mo['start'] && $m['closed_at'] <= $mo['end'])), 'backlog' => count(array_filter($mrps, fn($m) => self::openAt($m, $mo['end'])))];
        $withCause = array_values(array_filter($closed, fn($m) => $m['cause_id'])); $pareto = self::group($withCause, 'cause'); uasort($pareto, fn($a, $b) => count($b) <=> count($a));
        $out['mrp'] = ['all' => $mrps, 'received' => $recv, 'closed' => $closed, 'backlog' => $backlog, 'cohort' => $cohort, 'cohort_closed' => $cohortClosed, 'sla_valid' => $valid, 'sla_good' => $good, 'sla_late' => $slaLate, 'mean_days' => $mean, 'flux' => $flux, 'pareto' => $pareto, 'with_cause' => $withCause,
            'by_dir' => self::group($recv, 'direction'), 'by_req_dir' => self::group($recv, 'requester_dir'), 'by_status' => self::group($recv, 'status', array_keys(self::MRP_ST))];
        // actions
        $acts = DB::all("SELECT a.*, u.name owner FROM pm_actions a LEFT JOIN users u ON u.id=a.owner_id WHERE a.created_at<=?" . ($dir ? ' AND a.direction=?' : '') . "", array_merge([$asEnd], $p));
        $acts = array_values(array_filter($acts, fn($a) => !($a['cancelled_at'] && $a['cancelled_at'] <= $asEnd)));
        $openA = array_values(array_filter($acts, fn($a) => !self::actClosedAt($a, $asEnd))); $closedA = array_values(array_filter($acts, fn($a) => self::actClosedAt($a, $asEnd)));
        $late = array_values(array_filter($openA, fn($a) => $a['due'] && $a['due'] < $asOf)); $due = array_values(array_filter($acts, fn($a) => $a['due'] && $a['due'] <= $asOf)); $done = array_values(array_filter($due, fn($a) => self::actClosedAt($a, $asEnd)));
        $rates = []; foreach ($out['months'] as $mo) { $d = array_filter($acts, fn($a) => $a['due'] && $a['due'] <= substr($mo['end'], 0, 10) && $a['created_at'] <= $mo['end']); $rates[] = ['label' => $mo['label'], 'value' => self::ratio(count(array_filter($d, fn($a) => self::actClosedAt($a, $mo['end']))), count($d))]; }
        $heat = []; foreach ($late as $a) { $heat[$a['direction'] ?: '—'][$a['criticality'] ?: 'low'][] = $a; }
        $out['actions'] = ['all' => $acts, 'open' => $openA, 'closed' => $closedA, 'late' => $late, 'due' => $due, 'done' => $done, 'critical' => array_values(array_filter($openA, fn($a) => $a['criticality'] === 'high')), 'rates' => $rates, 'heat' => $heat];
        // audits
        $auds = DB::all("SELECT a.*, u.name auditor FROM pm_audits a LEFT JOIN users u ON u.id=a.auditor_id WHERE a.status='finalized' AND a.audit_date<=?" . ($dir ? ' AND a.direction=?' : '') . "", array_merge([$asOf], $p)); $au = array_values(array_filter($auds, fn($a) => $a['audit_date'] >= $start));
        $ids = array_map(fn($a) => (int)$a['id'], $au); $fnd = $ids ? DB::all('SELECT * FROM pm_findings WHERE audit_id IN (' . implode(',', $ids) . ')') : [];
        $recs = DB::all("SELECT f.*, a.direction FROM pm_findings f JOIN pm_audits a ON a.id=f.audit_id WHERE f.type='reco' AND f.status='closed' AND f.closed_at>=? AND f.closed_at<=?" . ($dir ? ' AND a.direction=?' : '') . "", array_merge(["$start 00:00:00", $asEnd], $dir ? [$dir] : []));
        $conf = []; foreach ($out['months'] as $mo) { $s = array_filter($au, fn($a) => $a['audit_date'] >= substr($mo['start'], 0, 10) && $a['audit_date'] <= substr($mo['end'], 0, 10)); $conf[] = ['label' => $mo['label'], 'value' => self::ratio(array_sum(array_column($s, 'obtained')), array_sum(array_column($s, 'points')))]; }
        $byProc = []; foreach ($au as $a) { $k = $a['process_id'] ?: 0; $byProc[$k] ??= ['name' => $a['process_id'] ? (string)DB::val('SELECT name FROM pr_processes WHERE id=?', [(int)$a['process_id']]) : 'Sans processus', 'rows' => [], 'pts' => 0, 'got' => 0]; $byProc[$k]['rows'][] = $a; $byProc[$k]['pts'] += (float)$a['points']; $byProc[$k]['got'] += (float)$a['obtained']; }
        foreach ($byProc as &$b) $b['pct'] = self::ratio($b['got'], $b['pts']); unset($b); uasort($byProc, fn($a, $b) => ($a['pct'] ?? 101) <=> ($b['pct'] ?? 101));
        $ncByDir = []; foreach ($fnd as $f) if ($f['type'] === 'nc') { $a = current(array_filter($au, fn($x) => (int)$x['id'] === (int)$f['audit_id'])); $ncByDir[$a['direction'] ?: '—'][] = $f; }
        $out['audits'] = ['all' => $auds, 'period' => $au, 'points' => array_sum(array_column($au, 'points')), 'obtained' => array_sum(array_column($au, 'obtained')), 'findings' => $fnd, 'nc' => array_values(array_filter($fnd, fn($f) => $f['type'] === 'nc')), 'recs_closed' => $recs, 'conformity' => $conf, 'by_process' => $byProc, 'nc_by_dir' => $ncByDir];
        // KPI trimestriels (4 derniers trimestres jusqu'à la date d'arrêté)
        $q = []; $qEnd = strtotime($asOf); for ($i = 3; $i >= 0; $i--) { $qs = strtotime(date('Y-m-01', $qEnd) . " -" . ($i * 3) . " months"); $qn = (int)ceil((int)date('n', $qs) / 3); $first = date('Y-m-01', strtotime(date('Y', $qs) . '-' . (($qn - 1) * 3 + 1) . '-01')); $last = date('Y-m-t', strtotime("$first +2 months")); if ($last > $asOf) $last = $asOf;
            $q[] = ['label' => 'T' . $qn . ' ' . date('y', $qs) . ($last === $asOf && date('Y-m-t', strtotime("$first +2 months")) > $asOf ? ' (partiel)' : ''), 'min' => "$first 00:00:00", 'max' => "$last 23:59:59", 'd' => $last]; }
        $q = array_values(array_unique($q, SORT_REGULAR));
        $out['quarters'] = array_map(function ($qq) use ($mrps, $acts, $auds, $pub) {
            $s = array_filter($mrps, fn($m) => $m['status'] === 'closed' && $m['sla_due'] && $m['closed_at'] >= $qq['min'] && $m['closed_at'] <= $qq['max']); $sla = self::ratio(count(array_filter($s, fn($m) => self::slaOk($m))), count($s));
            $d = array_filter($acts, fn($a) => $a['due'] && $a['due'] <= $qq['d'] && $a['created_at'] <= $qq['max']); $ex = self::ratio(count(array_filter($d, fn($a) => self::actClosedAt($a, $qq['max']))), count($d));
            $au = array_filter($auds, fn($a) => $a['audit_date'] >= substr($qq['min'], 0, 10) && $a['audit_date'] <= $qq['d']); $cf = self::ratio(array_sum(array_column($au, 'points')) ? array_sum(array_column($au, 'obtained')) : 0, array_sum(array_column($au, 'points')));
            $dd = array_filter($pub, fn($x) => $x['review_due'] && $x['updated_at'] <= $qq['max']); $fr = self::ratio(count(array_filter($dd, fn($x) => $x['review_due'] >= $qq['d'])), count($dd));
            return ['label' => $qq['label'], 'sla' => $sla, 'actions' => $ex, 'conformity' => $cf, 'docs' => $fr];
        }, $q);
        return $out;
    }
    static function openAt(array $m, string $at): bool { return $m['received_at'] <= $at && !($m['closed_at'] && $m['closed_at'] <= $at && $m['status'] === 'closed') && !($m['cancelled_at'] && $m['cancelled_at'] <= $at); }
    static function actClosedAt(array $a, string $at): bool { return $a['status'] === 'closed' && $a['closed_at'] && $a['closed_at'] <= $at; }
    static function group(array $rows, string $key, ?array $order = null): array { $o = $order ? array_fill_keys($order, []) : []; foreach ($rows as $r) { $k = $r[$key] ?? ''; $k = $k === null || $k === '' ? '—' : $k; $o[$k][] = $r; } if (!$order) ksort($o, SORT_NATURAL | SORT_FLAG_CASE); return $o; }
    static function bands(array $rows, string $key, string $asOf): array { $o = array_fill_keys(array_keys(self::BANDS), []); foreach ($rows as $r) $o[self::band($r[$key], $asOf)][] = $r; return $o; }
    static function monthLabel(string $ym): string { $m = ['', 'Janv.', 'Févr.', 'Mars', 'Avr.', 'Mai', 'Juin', 'Juil.', 'Août', 'Sept.', 'Oct.', 'Nov.', 'Déc.']; return $m[(int)substr($ym, 5, 2)] . ' ' . substr($ym, 2, 2); }

    // ------------------------------------------------------------------ graphiques SVG (sans script)
    const COLORS = ['#087568', '#2f5c98', '#91601b', '#8e4d77', '#58719b'];
    static function lineChart(array $labels, array $series, string $unit = '', ?float $limit = null): string {
        $w = 520; $h = 220; $l = 44; $r = 16; $t = 14; $b = 40; $pw = $w - $l - $r; $ph = $h - $t - $b;
        $known = []; foreach ($series as $s) foreach ($s['values'] as $v) if ($v !== null) $known[] = $v;
        if (!$known) return '<p class="text-muted small my-3">Aucune donnée sur ce périmètre.</p>';
        $step = $limit ? $limit / 4 : max(1, (int)ceil(max($known) / 4)); $max = $limit ?: $step * 4; $n = count($labels);
        $x = fn($i) => $l + ($n === 1 ? $pw / 2 : $i * $pw / ($n - 1)); $y = fn($v) => $t + $ph - $v / $max * $ph;
        $out = '<div class="d-flex flex-wrap gap-3 small text-muted mb-1">'; foreach ($series as $i => $s) $out .= '<span><i class="d-inline-block me-1" style="width:9px;height:9px;background:' . self::COLORS[$i % 5] . '"></i>' . e($s['name']) . '</span>'; $out .= '</div>';
        $out .= '<svg viewBox="0 0 ' . $w . ' ' . $h . '" class="w-100" role="img" style="max-height:260px;font:11px sans-serif">';
        for ($i = 0; $i <= 4; $i++) { $v = $i * $step; $out .= '<line x1="' . $l . '" x2="' . ($w - $r) . '" y1="' . $y($v) . '" y2="' . $y($v) . '" stroke="#e3ebf1"/><text x="' . ($l - 6) . '" y="' . ($y($v) + 4) . '" text-anchor="end" fill="#52637b">' . ($limit ? (int)$v : $v) . '</text>'; }
        foreach ($labels as $i => $lb) if ($n <= 7 || $i % 2 === 0 || $i === $n - 1) $out .= '<text x="' . $x($i) . '" y="' . ($h - 22) . '" text-anchor="middle" fill="#52637b">' . e($lb) . '</text>';
        foreach ($series as $si => $s) { $path = ''; $prev = false; $dots = '';
            foreach ($s['values'] as $i => $v) { if ($v === null) { $prev = false; continue; } $path .= ($prev ? 'L' : 'M') . round($x($i), 1) . ' ' . round($y(min($v, $max)), 1) . ' '; $prev = true; $dots .= '<circle cx="' . round($x($i), 1) . '" cy="' . round($y(min($v, $max)), 1) . '" r="3.5" fill="' . self::COLORS[$si % 5] . '"><title>' . e($s['name'] . ' · ' . $labels[$i] . ' · ' . $v . ($unit === '%' ? ' %' : '')) . '</title></circle>'; }
            $out .= '<path d="' . $path . '" fill="none" stroke="' . self::COLORS[$si % 5] . '" stroke-width="2.5" stroke-linejoin="round"/>' . $dots; }
        return $out . '<text x="' . ($l + 2) . '" y="10" fill="#384e67">' . e($unit) . '</text></svg>';
    }
    /** Liste de barres horizontales cliquables : [['label','value','url']]. */
    static function barList(array $rows, int $color = 0): string {
        $max = max(1, ...array_map(fn($r) => $r['value'], $rows ?: [['value' => 0]])); $o = '<div class="d-grid gap-2 my-2">';
        foreach ($rows as $r) { $inner = '<span class="small">' . e($r['label']) . '</span><span class="flex-fill rounded" style="height:9px;background:#eff3f7;overflow:hidden"><span class="d-block h-100 rounded" style="width:' . ($r['value'] / $max * 100) . '%;background:' . self::COLORS[$color % 5] . '"></span></span><strong class="small text-end" style="min-width:28px">' . $r['value'] . '</strong>';
            $o .= !empty($r['url']) ? '<a class="d-flex align-items-center gap-2 text-decoration-none text-body" href="' . $r['url'] . '" style="display:grid">' . $inner . '</a>' : '<div class="d-flex align-items-center gap-2">' . $inner . '</div>'; }
        return $o . '</div>';
    }
    static function gauge(int $ok, int $total, int $target = 90): string {
        $v = self::ratio($ok, $total); $ang = M_PI * (1 - $target / 100); $tx = 86 + 70 * cos($ang); $ty = 90 - 70 * sin($ang);
        return '<div class="d-flex align-items-center gap-3 flex-wrap"><svg viewBox="0 0 172 110" style="width:170px" role="img"><path d="M16 90 A70 70 0 0 1 156 90" fill="none" stroke="#e5edf3" stroke-width="13" stroke-linecap="round" pathLength="100"/>' . ($v === null ? '' : '<path d="M16 90 A70 70 0 0 1 156 90" fill="none" stroke="' . self::COLORS[0] . '" stroke-width="13" stroke-linecap="round" pathLength="100" stroke-dasharray="' . $v . ' 100"/>') . '<circle cx="' . round($tx, 1) . '" cy="' . round($ty, 1) . '" r="6" fill="#91601b" stroke="white" stroke-width="2"/><text x="86" y="79" text-anchor="middle" style="font:700 24px sans-serif" fill="#172942">' . self::pct($v) . '</text></svg><div class="small text-muted"><b class="text-body">Cible ' . $target . ' %</b><br>' . $ok . ' / ' . $total . ' MRP admissibles<br>SLA de résolution</div></div>';
    }
}
