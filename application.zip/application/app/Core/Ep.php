<?php
namespace App\Core;

/** Execution plan : programmes → initiatives → sous-initiatives, avancement de fin de période, relances. */
class Ep {
    static int $mails = 0;
    const ST = ['not_started' => ['Non démarré', '#9AA5B5'], 'in_progress' => ['En cours', '#2F6FDD'], 'at_risk' => ['À risque', '#E0A800'], 'done' => ['Terminé', '#2E8B57'], 'delayed' => ['En retard', '#C0392B']];
    static function label(string $k): string { return self::ST[$k][0] ?? $k; }
    static function chip(string $k): string { [$l, $c] = self::ST[$k] ?? self::ST['not_started']; return '<span class="sp" style="white-space:nowrap;display:inline-block;border-radius:999px;padding:3px 12px;font-weight:700;font-size:11px;color:#fff;background:' . $c . '">' . e($l) . '</span>'; }
    static function myEmployee(): ?int { $u = Auth::user(); return $u && $u['employee_id'] ? (int)$u['employee_id'] : null; }
    static function owner(array $p): string {
        if (!empty($p['owner_label'])) return (string)$p['owner_label'];
        if (!empty($p['owner_employee_id'])) { $e = DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [(int)$p['owner_employee_id']]); if ($e) return trim($e['first_name'] . ' ' . $e['last_name']); }
        return '—';
    }
    /** Un gestionnaire modifie tout ; un éditeur ne modifie que ses programmes (responsable désigné ou créateur). Plan clos : lecture seule. */
    static function canEdit(array $prog, array $plan): bool {
        if ($plan['status'] !== 'open') return false;
        if (can('ep.manage')) return true;
        if (!can('ep.edit')) return false;
        $me = self::myEmployee();
        return ($me && (int)$prog['owner_employee_id'] === $me) || (int)$prog['created_by'] === (int)Auth::id();
    }
    /** Activité d'un collaborateur : unité d'organisation de type activité, à défaut son équipe. */
    static function activityOf(?int $empId): string {
        if (!$empId) return '';
        $n = DB::val('SELECT o.name FROM employees e JOIN org_units o ON o.id=e.org_unit_id WHERE e.id=?', [$empId]); if ($n) return (string)$n;
        return (string)(DB::val('SELECT t.name FROM employees e JOIN teams t ON t.id=e.team_id WHERE e.id=?', [$empId]) ?: '');
    }
    static function empName(?int $id): string { if (!$id) return '—'; $e = DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [$id]); return $e ? trim($e['last_name'] . ' ' . $e['first_name']) : '—'; }
    /** Peut-on saisir l'avancement de cette initiative ? Responsable du programme (ou gestionnaire), ou responsable de l'initiative. */
    static function canEditInitiative(array $ini, array $prog, array $plan): bool {
        if ($plan['status'] !== 'open') return false;
        if (self::canEdit($prog, $plan)) return true;
        $me = self::myEmployee(); return can('ep.edit') && $me && (int)$ini['owner_employee_id'] === $me;
    }
    /** Le statut d'une sous-initiative fixe le taux aux extrémités : Non démarré = 0 %, Terminé = 100 %. */
    static function normalize(string $status, $progress, int $keep = 0): array {
        if (!isset(self::ST[$status])) $status = 'not_started';
        if ($status === 'done') return [$status, 100];
        if ($status === 'not_started') return [$status, 0];
        $p = is_numeric($progress) ? (int)$progress : $keep; return [$status, max(0, min(100, $p))];
    }
    /** Initiatives d'un programme, chacune avec ses sous-initiatives. */
    static function tree(int $progId): array {
        $o = DB::all('SELECT * FROM ep_initiatives WHERE programme_id=? ORDER BY sort_order, id', [$progId]);
        foreach ($o as &$i) $i['subs'] = DB::all('SELECT * FROM ep_subs WHERE initiative_id=? ORDER BY sort_order, id', [(int)$i['id']]); unset($i);
        return $o;
    }
    /** Initiative avec sous-initiatives : taux = moyenne des taux des sous-initiatives ; statut déduit. Sans sous-initiative : saisie directe. */
    static function recalc(int $iniId): void {
        $subs = DB::all('SELECT status, progress FROM ep_subs WHERE initiative_id=?', [$iniId]); if (!$subs) return;
        $avg = (int)round(array_sum(array_column($subs, 'progress')) / count($subs)); $st = array_column($subs, 'status');
        $s = !array_diff($st, ['done']) ? 'done' : (!array_diff($st, ['not_started']) ? 'not_started' : (in_array('delayed', $st, true) ? 'delayed' : (in_array('at_risk', $st, true) ? 'at_risk' : 'in_progress')));
        DB::update('ep_initiatives', ['progress' => $avg, 'status' => $s], 'id=?', [$iniId]);
    }
    /** Moyenne des taux des initiatives du programme (repère pour le taux du programme). */
    static function suggest(int $pid): ?int {
        $v = DB::all('SELECT progress FROM ep_initiatives WHERE programme_id=?', [$pid]); if (!$v) return null;
        return (int)round(array_sum(array_column($v, 'progress')) / count($v));
    }
    static function deleteProgramme(int $pid): void {
        foreach (DB::all('SELECT id FROM ep_initiatives WHERE programme_id=?', [$pid]) as $i) DB::exec('DELETE FROM ep_subs WHERE initiative_id=?', [(int)$i['id']]);
        DB::exec('DELETE FROM ep_initiatives WHERE programme_id=?', [$pid]); DB::exec('DELETE FROM ep_updates WHERE programme_id=?', [$pid]); DB::exec('DELETE FROM ep_programmes WHERE id=?', [$pid]);
    }
    /** Synthèse par activité. */
    static function byActivity(int $planId): array {
        $o = [];
        foreach (DB::all('SELECT activity, status, progress FROM ep_programmes WHERE plan_id=?', [$planId]) as $r) {
            $a = &$o[$r['activity']]; $a = $a ?? ['n' => 0, 'sum' => 0, 'st' => array_fill_keys(array_keys(self::ST), 0)];
            $a['n']++; $a['sum'] += (int)$r['progress']; $a['st'][$r['status']] = ($a['st'][$r['status']] ?? 0) + 1; unset($a);
        }
        foreach ($o as &$a) $a['avg'] = $a['n'] ? (int)round($a['sum'] / $a['n']) : 0; unset($a);
        ksort($o); return $o;
    }
    static function activities(): array { return array_column(DB::all('SELECT DISTINCT activity FROM ep_programmes ORDER BY activity'), 'activity'); }
    /** Photo des initiatives et sous-initiatives, conservée avec chaque avancement saisi. */
    static function snapshot(int $pid): string {
        $o = []; foreach (self::tree($pid) as $i) $o[] = ['l' => $i['label'], 's' => $i['status'], 'p' => (int)$i['progress'], 'c' => $i['comment'], 'subs' => array_map(fn($x) => ['l' => $x['label'], 's' => $x['status'], 'p' => (int)$x['progress'], 'c' => $x['comment']], $i['subs'])];
        return json_encode($o, JSON_UNESCAPED_UNICODE);
    }
    /** Utilisateur à relancer pour un collaborateur désigné : son compte actif. */
    static function userOfEmployee(?int $empId): ?int { return $empId ? ((int)DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [$empId]) ?: null) : null; }
    /** Utilisateur à relancer pour un programme : le responsable désigné, à défaut le créateur. */
    static function ownerUser(array $p): ?int {
        if ($u = self::userOfEmployee(!empty($p['owner_employee_id']) ? (int)$p['owner_employee_id'] : null)) return $u;
        return !empty($p['created_by']) ? ((int)DB::val("SELECT id FROM users WHERE id=? AND status='active'", [(int)$p['created_by']]) ?: null) : null;
    }
    /** Deux relances avant la date du bilan : une notification (et un e-mail si le plan le prévoit) par responsable, pour ses programmes et ses initiatives. Retourne le nombre de notifications. */
    static function sendReminders(?string $today = null): int {
        $today = $today ?? date('Y-m-d'); $sent = 0; self::$mails = 0;
        foreach (DB::all("SELECT * FROM ep_plans WHERE status='open' AND end_date>=?", [$today]) as $plan) {
            $d1 = (int)$plan['remind1_days']; $d2 = (int)$plan['remind2_days']; $w1 = date('Y-m-d', strtotime($plan['end_date'] . " -$d1 day")); $w2 = date('Y-m-d', strtotime($plan['end_date'] . " -$d2 day"));
            $due = function (array $r) use ($today, $w1, $w2) {   // [fenêtre, drapeaux à poser] ou null
                $which = ($today >= $w2 && !$r['reminded2_at']) ? 2 : (($today >= $w1 && $today < $w2 && !$r['reminded1_at']) ? 1 : 0); if (!$which) return null;
                return [$which, $which === 2 ? $w2 : $w1, $which === 2 ? ['reminded1_at' => $r['reminded1_at'] ?: now(), 'reminded2_at' => now()] : ['reminded1_at' => now()]];
            };
            $by = [];
            foreach (DB::all('SELECT * FROM ep_programmes WHERE plan_id=?', [(int)$plan['id']]) as $p) {
                if ($d = $due($p)) { [$which, $win, $flags] = $d; DB::update('ep_programmes', $flags, 'id=?', [(int)$p['id']]);
                    if (!($p['updated_at'] && substr((string)$p['updated_at'], 0, 10) >= $win) && ($u = self::ownerUser($p))) $by[$u][$which]['p'][] = $p['name']; }
                foreach (DB::all('SELECT * FROM ep_initiatives WHERE programme_id=? AND owner_employee_id IS NOT NULL', [(int)$p['id']]) as $i) {
                    if (!($d = $due($i))) continue; [$which, $win, $flags] = $d; DB::update('ep_initiatives', $flags, 'id=?', [(int)$i['id']]);
                    if (!($i['updated_at'] && substr((string)$i['updated_at'], 0, 10) >= $win) && ($u = self::userOfEmployee((int)$i['owner_employee_id']))) $by[$u][$which]['i'][] = $i['label'] . ' (' . $p['name'] . ')';
                }
            }
            foreach ($by as $u => $w) foreach ($w as $which => $x) {
                $left = (int)round((strtotime($plan['end_date']) - strtotime($today)) / 86400); $when = $left > 0 ? "J-$left" : 'aujourd\'hui'; $bilan = date('d/m/Y', strtotime($plan['end_date']));
                $title = 'Execution plan : ' . ($which === 2 ? '2e' : '1re') . ' relance'; $p = $x['p'] ?? []; $i = $x['i'] ?? [];
                $short = []; if ($p) $short[] = count($p) . ' programme(s)'; if ($i) $short[] = count($i) . ' initiative(s)';
                $body = implode(' et ', $short) . ' à mettre à jour avant le bilan du ' . $bilan . " ($when) : " . implode(' ; ', array_slice(array_merge($p, $i), 0, 5)) . (count($p) + count($i) > 5 ? '…' : '');
                Notifier::send($u, $title, $body, '/ep/' . $plan['id'] . '/update'); $sent++;
                if ((int)$plan['remind_email'] === 1 && Mailer::enabled()) {
                    $us = DB::one("SELECT name, email FROM users WHERE id=? AND status='active'", [$u]);
                    if ($us && $us['email']) {
                        $txt = "Bonjour {$us['name']},\n\n" . ($which === 2 ? 'Dernier rappel' : 'Rappel') . " : le bilan du plan « {$plan['name']} » ({$plan['period_label']}) a lieu le $bilan ($when).\nMerci de renseigner l'avancement (statut, taux et commentaire) de :\n";
                        foreach ($p as $n) $txt .= "  - Programme : $n\n"; foreach ($i as $n) $txt .= "  - Initiative : $n\n";
                        $link = (string)env('APP_URL', '') !== '' ? "\nSaisie : " . rtrim((string)env('APP_URL'), '/') . '/ep/' . $plan['id'] . "/update\n" : '';
                        if (Mailer::queue((string)$us['email'], $title . ' : bilan du ' . $bilan, $txt . $link . "\nMessage automatique de CXO Excellence Hub.")) self::$mails++;
                    }
                }
            }
        }
        return $sent;
    }
}
