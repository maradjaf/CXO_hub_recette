<?php
namespace App\Core;

/** Formation : créneaux, formateurs principal/suppléant, évaluations à chaud et à froid, populations, indicateurs des rapports. */
class Tr {
    const SLOT_PRESETS = ['08:00-10:00', '10:00-12:00', '08:00-12:00', '13:00-15:00', '15:00-17:00', '13:00-17:00', '08:00-17:00'];
    const KIND = ['hot' => 'À chaud', 'cold' => 'À froid'];
    const FKIND = ['hot' => 'À chaud', 'cold' => 'À froid', 'elearn' => 'E-learning'];
    const QT = ['rating' => 'Note de 1 à 5', 'yesno' => 'Oui / Non', 'text' => 'Texte libre'];
    const PLAN_ST = ['planned' => 'Planifiée', 'open' => 'Ouverte', 'closed' => 'Clôturée', 'cancelled' => 'Annulée'];
    const FORMED = ['attended', 'passed', 'failed'];

    static function slots(int $sid): array { return DB::all('SELECT * FROM training_slots WHERE session_id=? ORDER BY slot_date, start_time', [$sid]); }
    static function slotHours(array $s): float { [$a, $b] = [self::mins($s['start_time']), self::mins($s['end_time'])]; return max(0, $b - $a) / 60; }
    private static function mins(string $t): int { return (int)substr($t, 0, 2) * 60 + (int)substr($t, 3, 2); }
    static function sessionHours(int $sid, float $default = 0): float { $h = 0.0; foreach (self::slots($sid) as $s) $h += self::slotHours($s); return $h > 0 ? $h : $default; }
    static function hoursLabel(int $sid, float $default = 0): string { return Cert::hours(self::sessionHours($sid, $default)); }
    /** Formateur effectif : le suppléant lorsque le principal est déclaré indisponible. */
    static function trainerId(array $s): ?int { $p = $s['trainer_emp_id'] ? (int)$s['trainer_emp_id'] : null; $b = $s['backup_emp_id'] ? (int)$s['backup_emp_id'] : null; return !empty($s['trainer_unavailable']) && $b ? $b : $p; }
    static function refLabel(string $list, ?string $code): string { if ($code === null || $code === '') return ''; $l = DB::val('SELECT v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code=? AND v.code=?', [$list, $code]); return (string)($l ?: $code); }
    static function name(?int $emp): string { if (!$emp) return ''; $e = DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [$emp]); return $e ? trim($e['first_name'] . ' ' . $e['last_name']) : ''; }
    static function trainerName(array $s): string { $id = self::trainerId($s); return $id ? self::name($id) : (string)($s['trainer'] ?? ''); }
    /** Intitulé lisible d'une session : date(s), libellé. */
    static function when(array $s): string { $sl = self::slots((int)$s['id']); if (!$sl) return d($s['session_date']); $days = array_unique(array_column($sl, 'slot_date')); return count($days) > 1 ? d($days[0]) . ' → ' . d(end($days)) . ' (' . count($days) . ' j)' : d($days[0]); }

    // ───── Populations ─────
    /** Collaborateurs actifs des activités / unités (avec leurs sous-unités) et/ou des canaux choisis. */
    static function people(array $unitIds, array $channelIds = []): array {
        $w = []; $p = [];
        if ($unitIds) { $ids = []; foreach ($unitIds as $u) $ids = array_merge($ids, Org::descendants((int)$u)); $w[] = 'e.org_unit_id IN (' . implode(',', array_map('intval', array_unique($ids))) . ')'; }
        if ($channelIds) $w[] = 'e.channel_id IN (' . implode(',', array_map('intval', $channelIds)) . ')';
        if (!$w) return [];
        return DB::all("SELECT e.id, e.matricule, e.first_name, e.last_name, e.org_level, u.name unit_name, c.name channel_name FROM employees e LEFT JOIN org_units u ON u.id=e.org_unit_id LEFT JOIN channels c ON c.id=e.channel_id WHERE e.status='active' AND (" . implode(' OR ', $w) . ') ORDER BY e.last_name, e.first_name', $p);
    }
    /** Lit le formulaire « inscription en masse » : [cochés, erreurs]. Un collaborateur du périmètre décoché exige une justification. */
    static function parseBulk(array $in): array {
        $units = array_map('intval', (array)($in['units'] ?? [])); $chans = array_map('intval', (array)($in['channels'] ?? []));
        $scope = array_column(self::people($units, $chans), 'id'); $scope = array_map('intval', $scope);
        $sel = array_map('intval', (array)($in['emp'] ?? [])); $extra = array_map('intval', (array)($in['employee_id'] ?? []));
        $err = []; $excl = [];
        if ($scope) foreach ($scope as $id) { if (in_array($id, $sel, true)) continue; $r = trim((string)($in['reason'][$id] ?? '')); if (mb_strlen($r) < 5) $err[] = self::name($id) . ' : justification requise (5 caractères minimum).'; else $excl[$id] = mb_substr($r, 0, 300); }
        $ids = array_values(array_unique(array_merge(array_values(array_intersect($sel, $scope ?: $sel)), $extra)));
        return [$ids, $excl, $err];
    }

    // ───── Évaluations à chaud / à froid ─────
    static function planDefaults(int $sid, string $lastDay): array {
        $hot = (int)DB::val("SELECT id FROM tr_eval_forms WHERE kind='hot' AND active=1 ORDER BY id LIMIT 1"); $cold = (int)DB::val("SELECT id FROM tr_eval_forms WHERE kind='cold' AND active=1 ORDER BY id LIMIT 1");
        return ['hot' => ['form' => $hot, 'send_on' => $lastDay, 'due_on' => date('Y-m-d', strtotime("$lastDay +7 days"))], 'cold' => ['form' => $cold, 'send_on' => date('Y-m-d', strtotime("$lastDay +60 days")), 'due_on' => date('Y-m-d', strtotime("$lastDay +74 days"))]];
    }
    static function participants(int $sid): array { return DB::all("SELECT e.*, u.id uid FROM training_enrollments e LEFT JOIN users u ON u.employee_id=e.employee_id AND u.status='active' WHERE e.session_id=? AND e.status<>'absent'", [$sid]); }
    /** Ouvre les évaluations dont la date d'envoi est arrivée et prévient les participants. Retourne le nombre de plans ouverts. */
    static function openDue(?string $today = null): int {
        $today = $today ?: date('Y-m-d'); $n = 0;
        foreach (DB::all("SELECT p.*, t.title FROM tr_eval_plans p JOIN training_sessions s ON s.id=p.session_id JOIN trainings t ON t.id=s.training_id WHERE p.status='planned' AND p.send_on<=? AND s.status<>'cancelled'", [$today]) as $p) {
            DB::update('tr_eval_plans', ['status' => 'open', 'opened_at' => now()], 'id=?', [(int)$p['id']]); $n++;
            foreach (self::participants((int)$p['session_id']) as $e) if ($e['uid']) Notifier::send((int)$e['uid'], 'Évaluation ' . mb_strtolower(self::KIND[$p['kind']]) . ' : ' . $p['title'], $p['due_on'] ? 'À remplir avant le ' . d($p['due_on']) . '.' : '', '/trainings/eval/' . $p['id']);
        }
        foreach (DB::all("SELECT id FROM tr_eval_plans WHERE status='open' AND due_on IS NOT NULL AND due_on<?", [$today]) as $p) DB::update('tr_eval_plans', ['status' => 'closed'], 'id=?', [(int)$p['id']]);
        return $n;
    }
    static function evalAvg(array $where, array $p = []): ?float { $v = DB::val('SELECT AVG(r.avg) FROM tr_eval_responses r JOIN tr_eval_plans pl ON pl.id=r.plan_id JOIN training_sessions s ON s.id=pl.session_id WHERE r.avg IS NOT NULL AND ' . implode(' AND ', $where), $p); return $v === null || $v === false ? null : round((float)$v, 2); }

    // ───── Indicateurs ─────
    static function entityOf(): string { return "COALESCE(c.name, 'Fonctions support')"; }
    /** Indicateurs de formation sur une période [from, to] (sessions non annulées). */
    static function stats(string $from, string $to): array {
        $ss = DB::all("SELECT s.*, t.title, t.category, t.duration_hours FROM training_sessions s JOIN trainings t ON t.id=s.training_id WHERE s.status<>'cancelled' AND s.session_date BETWEEN ? AND ? ORDER BY s.session_date", [$from, $to]);
        $o = ['sessions' => count($ss), 'done' => 0, 'hours' => 0.0, 'enrolled' => 0, 'attended' => 0, 'passed' => 0, 'failed' => 0, 'formed' => 0, 'prog' => null, 'sat' => null, 'cold' => null, 'by_entity' => [], 'by_type' => [], 'trainers' => [], 'rows' => []];
        $ids = array_map(fn($s) => (int)$s['id'], $ss); $formed = []; $prog = []; $scs = []; $pres = [];
        foreach ($ss as $s) { $h = self::sessionHours((int)$s['id'], (float)$s['duration_hours']); if ($s['status'] === 'done') { $o['done']++; $o['hours'] += $h; } $o['rows'][] = $s + ['h' => $h]; }
        if ($ids) {
            $in = implode(',', $ids);
            foreach (DB::all("SELECT en.*, s.training_id, t.category, s.id sid, " . self::entityOf() . " entity FROM training_enrollments en JOIN training_sessions s ON s.id=en.session_id JOIN trainings t ON t.id=s.training_id JOIN employees e ON e.id=en.employee_id LEFT JOIN channels c ON c.id=e.channel_id WHERE en.session_id IN ($in)") as $en) {
                $o['enrolled']++; if (in_array($en['status'], self::FORMED, true)) { $o['attended']++; $formed[(int)$en['employee_id']] = 1; $o['by_entity'][$en['entity']] = ($o['by_entity'][$en['entity']] ?? 0) + 1; $cat = $en['category'] ?: 'Autre'; $o['by_type'][$cat][$en['entity']] = ($o['by_type'][$cat][$en['entity']] ?? 0) + 1; }
                if ($en['status'] === 'passed') $o['passed']++; if ($en['status'] === 'failed') $o['failed']++;
                if ($en['score'] !== null) $scs[] = (float)$en['score']; if ($en['pre_score'] !== null) $pres[] = (float)$en['pre_score'];
                if ($en['score'] !== null && $en['pre_score'] !== null) $prog[] = (float)$en['score'] - (float)$en['pre_score'];
            }
            foreach ($ss as $s) { $tid = self::trainerId($s); $k = $tid ? self::name($tid) : ((string)$s['trainer'] ?: '—'); $t = &$o['trainers'][$k]; $t = $t ?? ['sessions' => 0, 'hours' => 0.0, 'passed' => 0, 'failed' => 0, 'ids' => []]; $t['sessions']++; $t['hours'] += self::sessionHours((int)$s['id'], (float)$s['duration_hours']); $t['ids'][] = (int)$s['id']; unset($t); }
            foreach ($o['trainers'] as $k => &$t) { $i2 = implode(',', $t['ids']); $t['passed'] = (int)DB::val("SELECT COUNT(*) FROM training_enrollments WHERE status='passed' AND session_id IN ($i2)"); $t['failed'] = (int)DB::val("SELECT COUNT(*) FROM training_enrollments WHERE status='failed' AND session_id IN ($i2)"); $t['sat'] = self::evalAvg(["pl.kind='hot'", "s.id IN ($i2)"]); } unset($t);
        }
        $o['avg_score'] = $scs ? round(array_sum($scs) / count($scs), 1) : null; $o['avg_pre'] = $pres ? round(array_sum($pres) / count($pres), 1) : null; $o['formed'] = count($formed); $o['prog'] = $prog ? round(array_sum($prog) / count($prog), 1) : null;
        $o['presence'] = $o['enrolled'] ? round(100 * $o['attended'] / $o['enrolled'], 1) : null; $o['pass_rate'] = ($o['passed'] + $o['failed']) ? round(100 * $o['passed'] / ($o['passed'] + $o['failed']), 1) : null;
        if ($ids) { $o['sat'] = self::evalAvg(["pl.kind='hot'", 's.id IN (' . implode(',', $ids) . ')']); $o['cold'] = self::evalAvg(["pl.kind='cold'", 's.id IN (' . implode(',', $ids) . ')']); }
        return $o;
    }
    /** Couverture des formations obligatoires par entité : part des actifs ayant une validation en cours pour chacune. */
    static function coverage(): array {
        $must = DB::all('SELECT id FROM trainings WHERE mandatory=1 AND active=1'); $out = [];
        $emps = DB::all("SELECT e.id, " . self::entityOf() . " entity FROM employees e LEFT JOIN channels c ON c.id=e.channel_id WHERE e.status='active'");
        foreach ($emps as $e) { $ok = true; foreach ($must as $m) if (!DB::val("SELECT 1 FROM training_enrollments en JOIN training_sessions s ON s.id=en.session_id WHERE en.employee_id=? AND s.training_id=? AND en.status='passed' AND (en.valid_until IS NULL OR en.valid_until>=?)", [(int)$e['id'], (int)$m['id'], date('Y-m-d')])) { $ok = false; break; }
            $out[$e['entity']]['n'] = ($out[$e['entity']]['n'] ?? 0) + 1; $out[$e['entity']]['ok'] = ($out[$e['entity']]['ok'] ?? 0) + ($ok ? 1 : 0); }
        return $must ? $out : [];
    }
    static function monthRange(string $ym): array { $f = $ym . '-01'; return [$f, date('Y-m-t', strtotime($f))]; }
    static function prevMonth(string $ym): string { return date('Y-m', strtotime($ym . '-01 -1 month')); }
    static function status(?float $v, float $obj, bool $higherBetter = true): string { if ($v === null) return 'na'; $r = $higherBetter ? $v / max(0.0001, $obj) : $obj / max(0.0001, $v); return $r >= 1 ? 'ok' : ($r >= 0.9 ? 'warn' : 'ko'); }
    static function obj(string $k, float $d): float { return (float)(setting('obj.' . $k, '') ?: $d); }
    static function note(string $scope, string $period, string $k): string { return (string)DB::val('SELECT body FROM rep_notes WHERE scope=? AND period=? AND k=?', [$scope, $period, $k]); }
    static function setNote(string $scope, string $period, string $k, string $body): void {
        $id = DB::val('SELECT id FROM rep_notes WHERE scope=? AND period=? AND k=?', [$scope, $period, $k]);
        if ($id) DB::update('rep_notes', ['body' => $body, 'updated_by' => Auth::id(), 'updated_at' => now()], 'id=?', [(int)$id]); else DB::insert('rep_notes', ['scope' => $scope, 'period' => $period, 'k' => $k, 'body' => $body, 'updated_by' => Auth::id(), 'updated_at' => now()]);
    }
}
