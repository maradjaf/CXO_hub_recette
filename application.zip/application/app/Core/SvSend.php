<?php
namespace App\Core;

/** Lot 67 : envoi des enquêtes (WhatsApp, SMS, lien), relances, désinscription. Le fournisseur se paramètre dans le back office (sv_providers). */
class SvSend {
    const STATUS = ['queued' => 'En attente', 'ready' => 'Lien à partager', 'sent' => 'Envoyée', 'answered' => 'Répondue', 'failed' => 'Échec', 'expired' => 'Expirée', 'cancelled' => 'Annulée'];
    const DEFAULTS = ['delay_min' => '30', 'quiet_from' => '20:00', 'quiet_to' => '07:00', 'cooldown_days' => '30', 'max_reminders' => '2', 'expire_days' => '14', 'fallback' => '1', 'order' => 'whatsapp,sms', 'auto' => '0', 'public_url' => '', 'stop_notice' => '1'];
    static function cfg(string $k): string { return (string)setting('sv.send.' . $k, self::DEFAULTS[$k] ?? ''); }
    static function provider(string $channel): ?array { return DB::one("SELECT * FROM sv_providers WHERE channel=? AND active=1 ORDER BY is_default DESC, id LIMIT 1", [$channel]) ?: null; }
    static function link(string $token, string $suffix = ''): string {
        $root = rtrim(self::cfg('public_url'), '/');
        if ($root === '') { $h = $_SERVER['HTTP_HOST'] ?? ''; $root = $h !== '' ? ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https://' : 'http://') . $h . base_path()) : ''; }
        return $root . (env('URL_MODE', 'pretty') === 'index' ? '/index.php/' : '/') . 's/' . $token . $suffix;
    }
    static function inQuietHours(?int $ts = null): bool {
        $now = date('H:i', $ts ?? time()); $a = self::cfg('quiet_from'); $b = self::cfg('quiet_to'); if ($a === $b) return false;
        return $a < $b ? ($now >= $a && $now < $b) : ($now >= $a || $now < $b);
    }
    static function body(array $survey, array $inter, string $token, bool $reminder = false): string {
        $t = trim((string)$survey['invite_text']) ?: 'Bonjour {client}, merci d\'avoir contacté Yas. Donnez votre avis en quelques secondes : {lien}';
        $client = trim(explode(' ', trim((string)($inter['client_name'] ?? '')))[0] ?? ''); $adv = '';
        if (!empty($inter['employee_id'])) $adv = (string)DB::val('SELECT first_name FROM employees WHERE id=?', [(int)$inter['employee_id']]);
        $lien = self::link($token); $out = str_replace(['{client}', '{conseiller}', '{lien}'], [$client !== '' ? $client : 'cher client', $adv !== '' ? $adv : 'notre conseiller', $lien], $t);
        if (!str_contains($t, '{lien}')) $out .= ' ' . $lien;
        if ($reminder) $out = 'Rappel : ' . $out;
        if (self::cfg('stop_notice') === '1') $out .= ' Stop : ' . self::link($token, '/stop');
        return mb_substr($out, 0, 480);
    }
    /** Envoi réel (ou simulé) d'un message par le fournisseur. @return array{0:bool,1:string} */
    static function deliver(array $p, string $to, string $text): array {
        if ($p['kind'] === 'simulation') return [true, 'Simulation : aucun message réel envoyé.'];
        if ((string)$p['url'] === '') return [false, 'Adresse (URL) du fournisseur non renseignée.'];
        $f = [($p['field_to'] ?: 'to') => $to, ($p['field_text'] ?: 'text') => $text]; if ((string)$p['sender'] !== '') $f[$p['field_from'] ?: 'from'] = $p['sender'];
        $x = json_decode((string)$p['extra'], true); if (is_array($x)) foreach ($x as $k => $v) if (is_scalar($k)) $f[$k] = is_string($v) ? str_replace(['{to}', '{text}', '{sender}'], [$to, $text, (string)$p['sender']], $v) : $v;
        $h = []; $sec = (string)$p['auth_secret'] !== '' ? Secret::dec((string)$p['auth_secret']) : '';
        if ($p['auth'] === 'bearer' && $sec !== '') $h[] = 'Authorization: Bearer ' . $sec; elseif ($p['auth'] === 'header' && $sec !== '' && $p['auth_name']) $h[] = $p['auth_name'] . ': ' . $sec; elseif ($p['auth'] === 'basic') $h[] = 'Authorization: Basic ' . base64_encode(($p['auth_name'] ?: '') . ':' . $sec);
        [$st, $b, $err] = Integ::http('POST', (string)$p['url'], $h, $f, $p['format'] !== 'form'); $ok = $st >= 200 && $st < 300;
        return [$ok, $ok ? 'OK (HTTP ' . $st . ')' : ($err ?: 'Réponse HTTP ' . ($st ?: 'aucune') . (is_string($b) ? ' : ' . mb_substr($b, 0, 120) : ''))];
    }
    static function opted(string $phone): bool { return (bool)DB::val('SELECT 1 FROM sv_optouts WHERE phone=?', [$phone]); }
    /** Crée les invitations des interactions en attente (hors désinscrits, sans téléphone, ou déjà sollicitées récemment). */
    static function plan(): array {
        $r = ['created' => 0, 'skipped' => 0, 'nophone' => 0, 'optout' => 0]; $delay = (int)self::cfg('delay_min'); $cool = (int)self::cfg('cooldown_days'); $surveys = DB::all("SELECT * FROM sv_surveys WHERE status='active' ORDER BY id");
        $limit = date('Y-m-d H:i:s', time() - $delay * 60);
        foreach (DB::all("SELECT * FROM sv_interactions WHERE status='pending' AND (occurred_at IS NULL OR occurred_at<=?) ORDER BY id LIMIT 500", [$limit]) as $i) {
            $ph = Sms::normalize((string)$i['client_phone']); if (!$ph) { DB::update('sv_interactions', ['status' => 'nophone'], 'id=?', [$i['id']]); $r['nophone']++; continue; }
            if (self::opted($ph)) { DB::update('sv_interactions', ['status' => 'optout'], 'id=?', [$i['id']]); $r['optout']++; continue; }
            $sv = null; foreach ($surveys as $s) if ($i['survey_id'] ? (int)$s['id'] === (int)$i['survey_id'] : ($s['channel_scope'] === 'all' || $s['channel_scope'] === $i['channel'])) { $sv = $s; break; } if (!$sv) continue;
            if ($cool > 0 && DB::val("SELECT 1 FROM sv_invitations WHERE to_phone=? AND status IN ('sent','answered','queued') AND created_at>=?", [$ph, date('Y-m-d H:i:s', time() - $cool * 86400)])) { DB::update('sv_interactions', ['status' => 'skipped'], 'id=?', [$i['id']]); $r['skipped']++; continue; }
            $ch = 'link'; $prov = null; foreach (array_filter(array_map('trim', explode(',', self::cfg('order')))) as $c) if (in_array($c, ['whatsapp', 'sms'], true) && ($prov = self::provider($c))) { $ch = $c; break; }
            $tok = bin2hex(random_bytes(12)); $body = self::body($sv, $i, $tok);
            DB::insert('sv_invitations', ['survey_id' => (int)$sv['id'], 'interaction_id' => (int)$i['id'], 'token' => $tok, 'channel' => $ch, 'provider_id' => $prov['id'] ?? null, 'to_phone' => $ph, 'client_name' => $i['client_name'], 'body' => $body, 'status' => $ch === 'link' ? 'ready' : 'queued', 'created_at' => now()]);
            DB::update('sv_interactions', ['status' => 'invited'], 'id=?', [$i['id']]); $r['created']++;
        }
        return $r;
    }
    /** Envoie les invitations en attente (pas pendant les heures de silence). Bascule WhatsApp → SMS en cas d'échec si le réglage le permet. */
    static function flush(int $limit = 100, bool $force = false): array {
        $r = ['sent' => 0, 'failed' => 0, 'waiting' => 0]; if (!$force && self::inQuietHours()) { $r['waiting'] = (int)DB::val("SELECT COUNT(*) FROM sv_invitations WHERE status='queued'"); return $r; }
        foreach (DB::all("SELECT * FROM sv_invitations WHERE status='queued' ORDER BY id LIMIT " . (int)$limit) as $v) {
            $p = DB::one('SELECT * FROM sv_providers WHERE id=? AND active=1', [(int)$v['provider_id']]) ?: self::provider($v['channel']);
            if (!$p) { DB::update('sv_invitations', ['status' => 'failed', 'last_error' => 'Aucun fournisseur actif pour ce canal.'], 'id=?', [$v['id']]); $r['failed']++; continue; }
            [$ok, $msg] = self::deliver($p, $v['to_phone'], $v['body']);
            if ($ok) { DB::update('sv_invitations', ['status' => 'sent', 'sent_at' => now(), 'tries' => $v['tries'] + 1, 'last_error' => null, 'provider_id' => $p['id'], 'simulated' => $p['kind'] === 'simulation' ? 1 : 0], 'id=?', [$v['id']]); $r['sent']++; continue; }
            $n = (int)$v['tries'] + 1; $upd = ['tries' => $n, 'last_error' => mb_substr($msg, 0, 300)];
            if ($v['channel'] === 'whatsapp' && self::cfg('fallback') === '1' && ($sp = self::provider('sms'))) { $upd += ['channel' => 'sms', 'provider_id' => $sp['id'], 'last_error' => mb_substr('WhatsApp en échec, bascule SMS : ' . $msg, 0, 300)]; }
            elseif ($n >= 3) $upd['status'] = 'failed';
            DB::update('sv_invitations', $upd, 'id=?', [$v['id']]); if (($upd['status'] ?? '') === 'failed') $r['failed']++;
        }
        return $r;
    }
    /** Relances (espacées de « jours de relance » du modèle, au plus N fois) puis expiration. */
    static function remind(bool $force = false): array {
        $r = ['reminded' => 0, 'expired' => 0]; $max = (int)self::cfg('max_reminders'); $exp = (int)self::cfg('expire_days');
        foreach (DB::all("SELECT v.*, s.reminder_days, s.invite_text, s.id sid FROM sv_invitations v JOIN sv_surveys s ON s.id=v.survey_id WHERE v.status='sent' ORDER BY v.id LIMIT 300") as $v) {
            $last = strtotime($v['last_reminder_at'] ?: $v['sent_at']); $gap = (int)$v['reminder_days'];
            if ($exp > 0 && time() - strtotime($v['sent_at']) >= $exp * 86400) { DB::update('sv_invitations', ['status' => 'expired'], 'id=?', [$v['id']]); $r['expired']++; continue; }
            if ($gap <= 0 || (int)$v['reminders'] >= $max || time() - $last < $gap * 86400 || self::opted($v['to_phone']) || (!$force && self::inQuietHours())) continue;
            $p = DB::one('SELECT * FROM sv_providers WHERE id=? AND active=1', [(int)$v['provider_id']]) ?: self::provider($v['channel']); if (!$p) continue;
            $inter = $v['interaction_id'] ? (DB::one('SELECT * FROM sv_interactions WHERE id=?', [(int)$v['interaction_id']]) ?: []) : []; $sv = DB::one('SELECT * FROM sv_surveys WHERE id=?', [(int)$v['sid']]);
            [$ok, $msg] = self::deliver($p, $v['to_phone'], self::body($sv, $inter + ['client_name' => $v['client_name']], $v['token'], true));
            DB::update('sv_invitations', $ok ? ['reminders' => $v['reminders'] + 1, 'last_reminder_at' => now()] : ['last_error' => mb_substr($msg, 0, 300)], 'id=?', [$v['id']]); if ($ok) $r['reminded']++;
        }
        return $r;
    }
    static function run(): array { return ['plan' => self::plan(), 'flush' => self::flush(), 'remind' => self::remind(), 'followups' => Followup::scan(), 'escalated' => Followup::escalate()]; }
    /** Enregistre la réponse d'un client venue du lien personnel. @return array{0:bool,1:string} */
    static function answer(array $v, array $a, string $comment = ''): array {
        if (in_array($v['status'], ['answered'], true)) return [false, 'Cette enquête a déjà reçu une réponse. Merci !'];
        if (in_array($v['status'], ['expired', 'cancelled', 'failed'], true)) return [false, 'Cette enquête n\'est plus disponible.'];
        $qs = DB::all('SELECT * FROM sv_questions WHERE survey_id=? ORDER BY position, id', [(int)$v['survey_id']]); $met = ['csat' => null, 'nps' => null, 'ces' => null, 'advisor' => null]; $ans = [];
        foreach ($qs as $q) { $raw = trim((string)($a[$q['id']] ?? '')); if ($raw === '') { if ($q['required']) return [false, 'Merci de répondre à toutes les questions obligatoires.']; continue; }
            if ($q['type'] === 'text' || $q['type'] === 'choice') { $ans[] = [(int)$q['id'], null, mb_substr($raw, 0, 600)]; continue; }
            $n = Sv::answerNum($raw, $q['type']); if ($n === null) return [false, 'Une réponse est hors échelle.']; $ans[] = [(int)$q['id'], $n, null];
            if ($q['metric'] !== 'none' && $met[$q['metric']] === null) $met[$q['metric']] = Sv::score((string)$n, $q['metric'], Sv::max($q['type'])); }
        if (!$ans && $comment === '') return [false, 'Merci de renseigner au moins une réponse.'];
        $i = $v['interaction_id'] ? (DB::one('SELECT * FROM sv_interactions WHERE id=?', [(int)$v['interaction_id']]) ?: []) : [];
        $own = !DB::pdo()->inTransaction(); if ($own) DB::pdo()->beginTransaction();
        $rid = DB::insert('sv_responses', ['survey_id' => (int)$v['survey_id'], 'source' => 'lien', 'ext_ref' => 'INV-' . $v['id'], 'interaction_id' => $i['id'] ?? null, 'answered_at' => now(), 'channel' => $i['channel'] ?? null, 'employee_id' => $i['employee_id'] ?? null, 'team_id' => $i['team_id'] ?? null, 'store_id' => $i['store_id'] ?? null, 'client_ref' => $i['client_ref'] ?? null, 'client_name' => $v['client_name'], 'client_phone' => $v['to_phone'],
            'csat' => $met['csat'], 'nps' => $met['nps'], 'ces' => $met['ces'], 'advisor' => $met['advisor'], 'comment' => $comment !== '' ? mb_substr($comment, 0, 2000) : null, 'created_at' => now()]);
        foreach ($ans as [$qid, $n, $t]) DB::insert('sv_answers', ['response_id' => $rid, 'question_id' => $qid, 'num' => $n, 'txt' => $t]);
        DB::update('sv_invitations', ['status' => 'answered', 'answered_at' => now(), 'response_id' => $rid], 'id=?', [$v['id']]); if (!empty($i['id'])) DB::update('sv_interactions', ['status' => 'answered'], 'id=?', [$i['id']]);
        if ($own) DB::pdo()->commit(); Followup::scan(); return [true, 'Merci ! Votre réponse a bien été enregistrée.'];
    }
}
