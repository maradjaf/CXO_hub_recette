<?php
namespace App\Core;

/** Lot 59 — VOC & NPS : périodes, calculs NPS / CSAT / indicateurs CX, seuil d'affichage, composants d'affichage. */
final class Voc {
    const THRESHOLD = 30;                       // un score ne s'affiche qu'à partir de 30 réponses
    const UNKNOWN = 'Non renseigné';
    const BRANDS = ['YAS' => 'Yas', 'MOOV' => 'Moov', 'CANALBOX' => 'CanalBox'];
    const BRAND_COLORS = ['YAS' => '#9a5a04', 'MOOV' => '#205bb0', 'CANALBOX' => '#147964'];
    const CHANNELS = ['SuApp-Andr' => 'Super App Android', 'SuApp-IOS' => 'Super App iOS', 'MixxBu-IOS' => 'MixxBu iOS'];
    const QUESTIONS = ['Marque Mixx', 'Temps de transaction', 'Notifications'];
    const CLASS_LABELS = ['Détracteurs', 'Passifs', 'Promoteurs'];
    const CLASS_COLORS = ['#b64b62', '#899ab2', '#197e67'];
    const NOTE_COLORS = ['#b64b62', '#d89054', '#9aabc0', '#43a58d', '#197e67'];
    const PALETTE = ['#205bb0', '#147964', '#9a5a04', '#925bac', '#ad465b'];
    const PERIOD_MODES = ['week' => 'Semaine', 'month' => 'Mois', 'quarter' => 'Trimestre', 'semester' => 'Semestre', 'year' => 'Année'];
    const METRIC_PERIODS = ['day' => 'Jour'] + self::PERIOD_MODES;
    const DRIVERS = ['Autres' => 'AUTRES', 'Consommation & Paiement' => 'CONSOMMATION_PAIEMENT', 'Distribution & Accessibilité' => 'DISTRIBUTION_ACCESSIBILITE', 'Marque & Communication' => 'MARQUE_COMMUNICATION',
        'Prix (Frais, Promotions)' => 'PRIX_FRAIS_PROMOS', 'Produits & Services' => 'PRODUITS_SERVICES', 'Relation Client & Support' => 'RELATION_CLIENT_SUPPORT', "Qualité du réseau de l'internet mobile" => 'RESEAU_INTERNET_MOBILE',
        'Qualité du réseau de la voix et SMS' => 'RESEAU_VOIX_SMS', 'Service Internet Fixe' => 'SERVICE_INTERNET_FIXE', 'Service Mobile Money' => 'SERVICE_MOBILE_MONEY'];
    // indicateurs CX
    const METRICS = ['CSAT' => ['Satisfaction client', '#1564c3'], 'FCR' => ['Résolution au premier contact', '#0b7965'], 'FVR' => ['Résolution à la première visite', '#915a17'], 'CES' => ['Effort client', '#7652ad']];
    const SCOPES = ['Call Center', 'B2B', 'Mixx', 'CVM', 'Store', 'Digital', 'Fibre', 'Autre'];
    const FORMULAS = ['ratio' => 'Taux · numérateur / base', 'mean5' => 'Moyenne sur 5', 'mean7' => 'Moyenne sur 7', 'csat4' => 'CSAT · notes 4–5 / base', 'ces5' => 'CES · notes 5–7 / base'];
    const RULES = ['CSAT' => 'Réponses satisfaites divisées par les réponses valides.', 'FCR' => 'Résolutions au premier contact divisées par les contacts éligibles. Préciser la fenêtre de contrôle.',
        'FVR' => 'Résolutions lors de la première visite divisées par les visites éligibles.', 'CES' => 'Score d\'effort calculé avec l\'échelle, la convention de codage et le sens indiqués dans la série.'];
    // voix du client
    const STEP_ST = ['À faire', 'En cours', 'Bloqué', 'Terminé', 'Non documenté'];
    const FOCUS_ST = ['Brouillon', 'Planifié', 'Confirmé', 'Réalisé', 'Clôturé', 'Reporté'];
    const ACTION_ST = ['À qualifier', 'À lancer', 'En cours', 'Bloquée', 'À vérifier', 'Clôturée'];
    const PRIORITIES = ['À définir', 'Normale', 'Haute', 'Critique'];
    const PART_ST = ['À inviter', 'Brouillon préparé', 'Contacté', 'Confirmé', 'Présent', 'Absent', 'Décliné', 'Injoignable'];
    const CONTACT_CH = ['E-mail', 'WhatsApp', 'Appel', 'Autre'];
    const FIELD_ST = ['Planifié', 'Confirmé', 'Réalisé', 'CR validé', 'Reporté'];
    const LOOP_ST = ['Nouveau', 'Affecté', 'Tentative de contact', 'En traitement', 'Clôturé'];
    const LOOP_SRC = ['NPS Yas', 'CSAT Mixx', 'Focus group', 'Sortie terrain', 'Autre'];
    const Q_KINDS = ['rating5' => 'Échelle de 1 à 5', 'rating7' => 'Échelle de 1 à 7', 'yesno' => 'Oui / Non', 'choice' => 'Choix unique', 'text' => 'Texte libre'];
    const REPLY_CH = ['qr' => 'QR code', 'email' => 'E-mail', 'lien' => 'Lien direct'];
    const EVENT_STEPS = [['Cadrage et validation', 1], ['Sélection de la cible', 0], ['Invitations et confirmations', 0], ['Logistique et guide d\'animation', 1], ['Tenue du focus group', 1], ['Évaluation à chaud', 0], ['Compte rendu et clôture', 1]];
    const ACTION_STEPS = [['Valider le plan', 0], ['Mettre en œuvre', 1], ['Vérifier l\'efficacité', 0]];
    const MEDIA_TYPES = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif', 'mp4' => 'video/mp4', 'webm' => 'video/webm', 'mov' => 'video/quicktime'];
    const MONTHS = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
    const MONTHS_FULL = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];

    // ───────────────────────── formats ─────────────────────────
    static function isDay(?string $d): bool { return (bool)$d && preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && checkdate((int)substr($d, 5, 2), (int)substr($d, 8, 2), (int)substr($d, 0, 4)); }
    static function num($n): string { return number_format((float)$n, 0, ',', "\u{202f}"); }
    static function dec1(float $v): string { if (abs($v) < .05) $v = 0; return number_format($v, 1, ',', "\u{202f}"); }
    static function signed(float $v): string { return ($v > .049999 ? '+' : '') . self::dec1($v); }
    static function pct(float $v): string { return self::dec1($v) . ' %'; }
    static function n(int $n): string { return 'n = ' . self::num($n); }
    static function day(?string $d): string { return self::isDay($d) ? substr($d, 8, 2) . ' ' . self::MONTHS[(int)substr($d, 5, 2) - 1] : '—'; }
    static function fullDay(?string $d): string { return self::isDay($d) ? (int)substr($d, 8, 2) . ' ' . self::MONTHS_FULL[(int)substr($d, 5, 2) - 1] . ' ' . substr($d, 0, 4) : '—'; }
    static function range(?string $a, ?string $b): string { return self::day($a) . ' – ' . self::day($b); }
    static function brand(string $b): string { return self::BRANDS[$b] ?? $b; }
    static function channel(string $c): string { return self::CHANNELS[$c] ?? $c; }
    static function text(?string $v): string { return ($v ?? '') !== '' ? nl2br(e($v)) : '<span class="text-muted">À renseigner</span>'; }
    static function badge(string $label): string {
        return badge($label, in_array($label, ['Clôturé', 'Clôturée', 'Terminé', 'Présent', 'Confirmé', 'Publié', 'CR validé'], true) ? 'success' : (in_array($label, ['Reporté', 'Bloqué', 'Bloquée', 'Injoignable', 'Absent', 'Décliné'], true) ? 'warning' : 'secondary'));
    }
    /** Minuscules sans accents (comparaison d'en-têtes, codes de série). */
    static function fold(string $t): string {
        return strtr(mb_strtolower(trim($t)), ['à' => 'a', 'â' => 'a', 'ä' => 'a', 'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e', 'î' => 'i', 'ï' => 'i', 'ô' => 'o', 'ö' => 'o', 'ù' => 'u', 'û' => 'u', 'ü' => 'u', 'ç' => 'c', 'œ' => 'oe', 'æ' => 'ae', '’' => "'"]);
    }
    static function monthEnd(string $iso): string { return date('Y-m-t', strtotime(substr($iso, 0, 7) . '-01')); }
    static function uniq(array $v): array { $v = array_values(array_unique(array_filter($v, fn($x) => $x !== null && $x !== ''))); usort($v, fn($a, $b) => strcoll((string)$a, (string)$b) ?: strcmp((string)$a, (string)$b)); return $v; }

    // ───────────────────────── périodes ─────────────────────────
    /** Découpe [from, to] en semaines (lundi), mois, trimestres, semestres, années ou jours ; 105 périodes au plus. */
    static function periods(?string $from, ?string $to, string $mode): array {
        if (!self::isDay($from) || !self::isDay($to) || $from > $to) return [];
        $out = []; $span = ['month' => 1, 'quarter' => 3, 'semester' => 6, 'year' => 12][$mode] ?? 0;
        if ($mode === 'day') { for ($d = $from; $d <= $to && count($out) < 105; $d = date('Y-m-d', strtotime("$d +1 day"))) $out[] = ['id' => $d, 'from' => $d, 'to' => $d, 'label' => self::day($d), 'partial' => false]; return $out; }
        if ($span) { $m = (int)substr($from, 5, 2) - 1; $m = intdiv($m, $span) * $span; $cur = sprintf('%s-%02d-01', substr($from, 0, 4), $m + 1); }
        else $cur = date('Y-m-d', strtotime($from . ' -' . ((int)date('N', strtotime($from)) - 1) . ' days'));
        while ($cur <= $to && count($out) < 105) {
            $next = date('Y-m-d', strtotime($span ? "$cur +$span months" : "$cur +7 days")); $end = date('Y-m-d', strtotime("$next -1 day"));
            $vis = max($cur, $from); $y = substr($cur, 0, 4); $mo = (int)substr($cur, 5, 2) - 1;
            $label = match ($mode) { 'month' => self::MONTHS[$mo] . ' ' . $y, 'quarter' => 'T' . (1 + intdiv($mo, 3)) . ' ' . $y, 'semester' => 'S' . (1 + intdiv($mo, 6)) . ' ' . $y, 'year' => $y, default => self::day($vis) };
            $out[] = ['id' => $cur, 'from' => $vis, 'to' => min($end, $to), 'label' => $label, 'partial' => $cur < $from || $end > $to];
            $cur = $next;
        }
        return $out;
    }
    static function pick(array $periods, array $ids): array { return $ids ? array_values(array_filter($periods, fn($p) => in_array($p['id'], $ids, true))) : $periods; }
    static function plabel(array $p): string { return $p['label'] . ($p['partial'] ? '*' : ''); }
    static function inP(?string $day, array $p): bool { return $day !== null && $day >= $p['from'] && $day <= $p['to']; }
    static function inAny(?string $day, array $periods): bool { foreach ($periods as $p) if (self::inP($day, $p)) return true; return false; }

    // ───────────────────────── données ─────────────────────────
    private static array $cache = [];
    /** Lots actifs d'un type : les lots importés s'il en existe, sinon les lots d'exemple. */
    static function batches(string $type): array {
        if (isset(self::$cache["b$type"])) return self::$cache["b$type"];
        $real = DB::all('SELECT * FROM vn_batches WHERE type=? AND is_demo=0 ORDER BY date_from', [$type]);
        return self::$cache["b$type"] = $real ?: DB::all('SELECT * FROM vn_batches WHERE type=? AND is_demo=1 ORDER BY date_from', [$type]);
    }
    static function flush(): void { self::$cache = []; }
    static function summary(string $type): array {
        $b = self::batches($type); if (!$b) return ['from' => null, 'to' => null, 'name' => 'Aucun lot chargé', 'total' => 0, 'demo' => false, 'note' => null, 'stats' => [], 'count' => 0];
        $stats = []; foreach ($b as $x) foreach ((array)json_decode((string)$x['stats'], true) as $k => $v) if (is_numeric($v)) $stats[$k] = ($stats[$k] ?? 0) + $v;
        $demo = (bool)$b[0]['is_demo'];
        return ['from' => $b[0]['date_from'], 'to' => end($b)['date_to'], 'name' => count($b) === 1 ? $b[0]['name'] : count($b) . ' lots importés', 'total' => array_sum(array_column($b, 'total')), 'demo' => $demo, 'note' => count($b) === 1 ? $b[0]['note'] : null, 'stats' => $stats, 'count' => count($b), 'sheet' => $b[0]['sheet']];
    }
    static function npsRows(): array {
        if (isset(self::$cache['nps'])) return self::$cache['nps'];
        $ids = array_map(fn($b) => (int)$b['id'], self::batches('nps')); if (!$ids) return self::$cache['nps'] = [];
        return self::$cache['nps'] = DB::all('SELECT day, brand, region, band, age, driver, sub, det, pas, pro FROM vn_nps WHERE batch_id IN (' . implode(',', $ids) . ')');
    }
    static function csatRows(): array {
        if (isset(self::$cache['csat'])) return self::$cache['csat'];
        $ids = array_map(fn($b) => (int)$b['id'], self::batches('csat')); if (!$ids) return self::$cache['csat'] = [];
        return self::$cache['csat'] = DB::all('SELECT day, pay_day, channel, segment, question, n1, n2, n3, n4, n5 FROM vn_csat WHERE batch_id IN (' . implode(',', $ids) . ')');
    }
    static function names(array $rows, string $key): array { return self::uniq(array_column($rows, $key)); }

    // ───────────────────────── calculs ─────────────────────────
    static function npsStats(array $rows): array {
        $c = [0, 0, 0]; foreach ($rows as $r) { $c[0] += (int)$r['det']; $c[1] += (int)$r['pas']; $c[2] += (int)$r['pro']; }
        $n = $c[0] + $c[1] + $c[2]; return ['counts' => $c, 'n' => $n, 'signed' => $c[2] - $c[0], 'value' => $n ? 100 * ($c[2] - $c[0]) / $n : null];
    }
    /** $mode : top (part des notes 4 et 5) ou index (moyenne de (note − 1) ÷ 4). */
    static function csatStats(array $rows, string $mode = 'top'): array {
        $c = [0, 0, 0, 0, 0]; foreach ($rows as $r) for ($i = 0; $i < 5; $i++) $c[$i] += (int)$r['n' . ($i + 1)];
        $n = array_sum($c); $num = $mode === 'top' ? $c[3] + $c[4] : ($c[1] + 2 * $c[2] + 3 * $c[3] + 4 * $c[4]) / 4;
        return ['counts' => $c, 'n' => $n, 'numerator' => $num, 'value' => $n ? 100 * $num / $n : null];
    }
    static function npsMatch(array $r, array $f, bool $withDrivers = true): bool {
        return $r['day'] >= $f['from'] && $r['day'] <= $f['to'] && ($f['brand'] !== '' ? $r['brand'] === $f['brand'] : in_array($r['brand'], ['YAS', 'MOOV'], true))
            && ($f['region'] === '' || $r['region'] === $f['region']) && ($f['band'] === '' || $r['band'] === $f['band']) && ($f['age'] === '' || $r['age'] === $f['age'])
            && (!$withDrivers || ((!$f['drivers'] || in_array($r['driver'], $f['drivers'], true)) && ($f['sub'] === '' || $r['sub'] === $f['sub'])));
    }
    static function countsTitle(int $n): string { return self::n($n) . ($n && $n < self::THRESHOLD ? ' · score sous seuil' : ($n >= self::THRESHOLD && $n < 50 ? ' · base faible' : '')); }
    /** Cellule de score : valeur masquée sous le seuil, base toujours visible. */
    static function cell(int $n, ?float $value, callable $fmt, int $min = self::THRESHOLD): string {
        if (!$n) return '<span class="text-muted">—</span>';
        return '<strong>' . ($n >= $min && $value !== null ? e($fmt($value)) : '—') . '</strong><small class="d-block text-muted">' . self::n($n) . ($n < $min ? ' · sous seuil' : ($n < 50 && $min === self::THRESHOLD ? ' · faible' : '')) . '</small>';
    }

    // ───────────────────────── indicateurs CX ─────────────────────────
    static function unit(string $formula): string { return $formula === 'mean5' ? '/5' : ($formula === 'mean7' ? '/7' : '%'); }
    static function seriesMax(string $formula): int { return $formula === 'mean5' ? 5 : ($formula === 'mean7' ? 7 : 100); }
    /** Catalogue : séries Mixx calculées depuis les lots CSAT + séries enregistrées. */
    static function catalog(): array {
        if (isset(self::$cache['cat'])) return self::$cache['cat'];
        $out = []; $src = self::summary('csat');
        foreach (self::QUESTIONS as $i => $q) $out['mixx-q' . ($i + 1)] = ['id' => 'mixx-q' . ($i + 1), 'db' => 0, 'name' => $q, 'metric' => 'CSAT', 'scope' => 'Mixx', 'formula' => 'csat4', 'unit' => '%', 'direction' => 'up', 'target' => null,
            'description' => 'Question Qualtrics Mixx, part des notes 4 et 5 sur les réponses valides. Date de réponse.', 'origin' => 'Lots CSAT Mixx' . ($src['demo'] ? ' (exemple)' : ''), 'builtin' => true, 'demo' => false];
        foreach (DB::all('SELECT * FROM vn_series ORDER BY is_demo, scope, name') as $s) $out[$s['code']] = ['id' => $s['code'], 'db' => (int)$s['id'], 'name' => $s['name'], 'metric' => $s['metric'], 'scope' => $s['scope'], 'formula' => $s['formula'], 'unit' => self::unit($s['formula']),
            'direction' => $s['direction'], 'target' => $s['target'] === null ? null : (float)$s['target'], 'description' => (string)$s['description'], 'origin' => (string)$s['origin'], 'builtin' => false, 'demo' => (bool)$s['is_demo']];
        return self::$cache['cat'] = $out;
    }
    /** Observations par série : ['date','region','segment','channel','numerator','base','grain']. */
    static function observations(): array {
        if (isset(self::$cache['obs'])) return self::$cache['obs'];
        $out = [];
        foreach (self::csatRows() as $r) { $n = $r['n1'] + $r['n2'] + $r['n3'] + $r['n4'] + $r['n5']; $out['mixx-q' . ($r['question'] + 1)][] = ['date' => $r['day'], 'region' => self::UNKNOWN, 'segment' => $r['segment'], 'channel' => self::channel((string)$r['channel']), 'numerator' => $r['n4'] + $r['n5'], 'base' => $n, 'grain' => 'day']; }
        foreach (DB::all('SELECT s.code, m.day, m.region, m.segment, m.channel, m.numerator, m.base, m.grain FROM vn_measures m JOIN vn_series s ON s.id=m.series_id') as $r)
            $out[$r['code']][] = ['date' => $r['day'], 'region' => $r['region'], 'segment' => $r['segment'], 'channel' => $r['channel'], 'numerator' => (int)$r['numerator'], 'base' => (int)$r['base'], 'grain' => $r['grain']];
        return self::$cache['obs'] = $out;
    }
    /** Cumul d'une série sur une période : un agrégat mensuel ne compte que si le mois entier est inclus. */
    static function pool(array $rows, array $s, array $p, array $f): array {
        $base = 0; $num = 0;
        foreach ($rows as $r) {
            if (($f['region'] ?? '') !== '' && $r['region'] !== $f['region']) continue; if (($f['segment'] ?? '') !== '' && $r['segment'] !== $f['segment']) continue; if (($f['channel'] ?? '') !== '' && $r['channel'] !== $f['channel']) continue;
            if ($r['date'] < $p['from'] || ($r['grain'] === 'month' ? self::monthEnd($r['date']) : $r['date']) > $p['to']) continue;
            $base += $r['base']; $num += $r['numerator'];
        }
        return ['base' => $base, 'numerator' => $num, 'value' => $base ? ($s['unit'] === '%' ? 100 : 1) * $num / $base : null];
    }
    static function mnum(array $s, ?float $v): string { return $v === null ? '—' : ($s['unit'] === '%' ? self::pct($v) : self::dec1($v) . ' ' . $s['unit']); }
    static function mdelta(array $s, float $v): string { return self::signed($v) . ($s['unit'] === '%' ? ' pp' : ' pt'); }
    static function slabel(array $s): string { return $s['scope'] . ' · ' . $s['name']; }

    // ───────────────────────── composants ─────────────────────────
    static function card(string $title, string $value, string $meta, string $accent = ''): string {
        return '<div class="col-12 col-md"><div class="cardx h-100 voc-kpi"' . ($accent ? ' style="border-top:3px solid ' . $accent . '"' : '') . '><div class="text-muted small">' . $title . '</div><div class="fs-3 fw-semibold">' . $value . '</div><div class="small text-muted">' . $meta . '</div></div></div>';
    }
    static function legend(array $items): string { return '<div class="d-flex flex-wrap gap-3 small text-muted my-1">' . implode('', array_map(fn($i) => '<span><i class="d-inline-block rounded-circle me-1" style="width:9px;height:9px;background:' . $i[1] . '"></i>' . e($i[0]) . '</span>', $items)) . '</div>'; }
    /** Barre de composition (détracteurs / passifs / promoteurs ou notes 1 à 5). */
    static function mix(string $label, array $counts, array $colors = self::CLASS_COLORS, array $labels = self::CLASS_LABELS): string {
        $n = array_sum($counts); if (!$n) return '';
        $seg = ''; $leg = []; foreach ($counts as $i => $c) { $r = 100 * $c / $n; $seg .= '<span style="width:' . round($r, 2) . '%;background:' . $colors[$i] . '" title="' . e($labels[$i]) . ' · ' . self::pct($r) . '"></span>'; $leg[] = [$labels[$i] . ' ' . self::pct($r), $colors[$i]]; }
        return '<div class="mb-3"><div class="d-flex justify-content-between"><strong>' . e($label) . '</strong><small class="text-muted">' . self::n($n) . '</small></div><div class="voc-mix">' . $seg . '</div>' . self::legend($leg) . '</div>';
    }
    /** Liste à cocher repliable (drivers, périodes, séries) ; soumise avec le formulaire de filtres. */
    static function multi(string $label, string $name, array $options, array $values, string $helper = ''): string {
        $h = ''; foreach ($options as $k => $t) { if (is_int($k)) $k = $t; $h .= '<label class="form-check small"><input class="form-check-input" type="checkbox" name="' . $name . '[]" value="' . e((string)$k) . '"' . (in_array((string)$k, $values, true) ? ' checked' : '') . '> <span class="form-check-label">' . e((string)$t) . '</span></label>'; }
        return '<details class="voc-pop"><summary class="btn btn-sm btn-outline-secondary">' . e($label) . ($values ? ' · ' . count($values) : '') . '</summary><div class="voc-pop-body">' . ($helper ? '<p class="small text-muted mb-2">' . e($helper) . '</p>' : '')
            . '<div class="voc-checks">' . ($h ?: '<span class="text-muted small">Aucune valeur disponible</span>') . '</div><div class="d-flex gap-2 mt-2"><button class="btn btn-sm btn-primary">Appliquer</button><button type="button" class="btn btn-sm btn-link" onclick="this.closest(\'details\').querySelectorAll(\'input\').forEach(function(i){i.checked=false});this.form.submit()">Effacer la sélection</button></div></div></details>';
    }
    static function select(string $label, string $name, array $options, $value, bool $auto = true): string {
        $o = ''; foreach ($options as $k => $t) $o .= '<option value="' . e((string)$k) . '"' . ((string)$k === (string)$value ? ' selected' : '') . '>' . e((string)$t) . '</option>';
        return '<div><label class="form-label small mb-0">' . e($label) . '</label><select class="form-select form-select-sm" name="' . $name . '"' . ($auto ? ' onchange="this.form.submit()"' : '') . '>' . $o . '</select></div>';
    }
    static function dayField(string $label, string $name, ?string $value): string { return '<div><label class="form-label small mb-0">' . e($label) . '</label><input type="date" class="form-control form-control-sm" name="' . $name . '" value="' . e((string)$value) . '" onchange="this.form.submit()"></div>'; }
    static function table(array $head, array $rows, string $class = '', string $empty = 'Aucune donnée pour ces filtres.'): string {
        $h = '<div class="table-responsive"><table class="table table-sm align-middle voc-table ' . $class . '"><thead><tr>' . implode('', array_map(fn($x) => '<th scope="col">' . $x . '</th>', $head)) . '</tr></thead><tbody>';
        foreach ($rows as $r) { $h .= '<tr>'; foreach (array_values($r) as $i => $c) $h .= $i ? '<td>' . $c . '</td>' : '<th scope="row" class="fw-normal">' . $c . '</th>'; $h .= '</tr>'; }
        if (!$rows) $h .= '<tr><td colspan="' . count($head) . '" class="text-muted">' . e($empty) . '</td></tr>';
        return $h . '</tbody></table></div>';
    }
    /**
     * Courbe SVG : $series = [['name','color','dashed'=>bool,'points'=>[null | ['v'=>?float,'n'=>?int]]]].
     * Options : fmt (callable), range ([bas, haut]), percent, min (seuil d'effectif), empty, label.
     */
    static function trend(array $labels, array $series, array $o = []): string {
        if (!$series || !$labels) return '<p class="text-muted small my-3">Aucun point pour cette sélection.</p>';
        $fmt = $o['fmt'] ?? fn($v) => self::dec1($v); $min = $o['min'] ?? self::THRESHOLD;
        $vals = []; foreach ($series as $s) foreach ($s['points'] as $p) if ($p && $p['v'] !== null) $vals[] = $p['v'];
        if (isset($o['range'])) { [$lo, $hi] = $o['range']; $ticks = ($lo == 1 && $hi == 7) ? 6 : 4; }
        else { $lo = max(-100, 20 * floor((min(0, ...($vals ?: [0])) - 2) / 20)); $hi = min(100, 20 * ceil((max(60, ...($vals ?: [60])) + 2) / 20)); $ticks = (int)max(1, min(5, ($hi - $lo) / 20)); }
        if ($hi <= $lo) $hi = $lo + 1;
        $W = 640; $H = 250; $l = 44; $r = $W - 16; $t = 12; $b = $H - 34; $n = count($labels);
        $x = fn($i) => $n === 1 ? ($l + $r) / 2 : $l + $i * ($r - $l) / ($n - 1); $y = fn($v) => $b - (min($hi, max($lo, $v)) - $lo) / ($hi - $lo) * ($b - $t);
        $svg = '<svg viewBox="0 0 ' . $W . ' ' . $H . '" class="w-100 voc-trend" role="img" aria-label="' . e($o['label'] ?? 'Courbe') . '" style="font:11px system-ui,sans-serif">';
        for ($j = 0; $j <= $ticks; $j++) { $v = $lo + ($hi - $lo) * $j / $ticks; $yy = round($y($v), 1); $svg .= '<line x1="' . $l . '" x2="' . $r . '" y1="' . $yy . '" y2="' . $yy . '" stroke="' . (abs($v) < 1e-9 ? '#a0b5cd' : '#e2eaf2') . '"/><text x="' . ($l - 7) . '" y="' . ($yy + 4) . '" text-anchor="end" fill="#536782">' . round($v) . (!empty($o['percent']) ? '%' : '') . '</text>'; }
        $stride = (int)ceil($n / max(2, floor(($r - $l) / 68)));
        foreach ($labels as $i => $lb) { if ($i % $stride && $i !== $n - 1) continue; if ($i !== 0 && $i !== $n - 1 && $n - 1 - $i < $stride * .6) continue;
            $svg .= '<text x="' . round($x($i), 1) . '" y="' . ($b + 18) . '" text-anchor="' . ($n === 1 ? 'middle' : ($i === 0 ? 'start' : ($i === $n - 1 ? 'end' : 'middle'))) . '" fill="#536782">' . e($lb) . '</text>'; }
        $any = false;
        foreach ($series as $k => $s) { $d = ''; $on = false; $dots = '';
            foreach ($s['points'] as $i => $p) { if (!$p || $p['v'] === null) { $on = false; continue; } $any = true; $xx = round($x($i), 1); $yy = round($y($p['v']), 1); $d .= ($on ? 'L' : 'M') . $xx . ' ' . $yy . ' '; $on = true;
                $tip = '<title>' . e($s['name'] . ' · ' . $labels[$i] . ' · ' . $fmt($p['v']) . ($p['n'] === null ? '' : ' · ' . self::n((int)$p['n']))) . '</title>';
                $dots .= $k % 2 ? '<rect x="' . ($xx - 3.4) . '" y="' . ($yy - 3.4) . '" width="6.8" height="6.8" fill="' . $s['color'] . '">' . $tip . '</rect>' : '<circle cx="' . $xx . '" cy="' . $yy . '" r="3.6" fill="' . $s['color'] . '">' . $tip . '</circle>'; }
            $svg .= '<path d="' . $d . '" fill="none" stroke="' . $s['color'] . '" stroke-width="2.5" stroke-linejoin="round"' . (!empty($s['dashed']) ? ' stroke-dasharray="5 4"' : '') . '/>' . $dots; }
        if (!$any) $svg .= '<text x="' . (($l + $r) / 2) . '" y="' . (($t + $b) / 2) . '" text-anchor="middle" fill="#536782">' . e($o['empty'] ?? 'Aucun score au seuil d\'affichage') . '</text>';
        $svg .= '</svg>';
        $rows = []; foreach ($labels as $i => $lb) { $row = [e($lb)]; foreach ($series as $s) { $p = $s['points'][$i] ?? null; $row[] = !$p ? '—' : ($p['v'] === null ? '—' : e($fmt($p['v']))) . ($p['n'] === null ? '' : '<small class="d-block text-muted">' . self::n((int)$p['n']) . ($p['n'] < $min ? ' · sous seuil' : '') . '</small>'); } $rows[] = $row; }
        return $svg . self::legend(array_map(fn($s) => [$s['name'], $s['color']], $series)) . '<details class="voc-disclose"><summary>Valeurs du graphique</summary>' . self::table(array_merge(['Période'], array_map(fn($s) => e($s['name']), $series)), $rows) . '</details>';
    }
    static function bar(string $label, float $value, float $max, string $color, ?string $text = null): string {
        return '<div class="voc-bar"><span>' . e($label) . '</span><span class="voc-bar-track"><i style="width:' . round(100 * $value / max(1e-9, $max), 1) . '%;background:' . $color . '"></i></span><strong>' . e($text ?? self::num($value)) . '</strong></div>';
    }
    /** Protège une cellule CSV contre l'interprétation en formule par le tableur. */
    static function csv($v) { return is_string($v) && preg_match('/^\s*[=+@-]/', $v) ? "'" . $v : $v; }
    static function csvOut(string $name, array $rows): never {
        header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="' . $name . '"');
        $o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF"); foreach ($rows as $r) fputcsv($o, array_map([self::class, 'csv'], $r), ';'); fclose($o); exit;
    }

    // ───────────────────────── voix du client ─────────────────────────
    static function journal(string $entity, int $id, string $note): void {
        $note = trim($note); if ($note === '') return; $u = Auth::user();
        DB::insert('vn_journal', ['entity' => $entity, 'entity_id' => $id, 'user_id' => $u['id'] ?? null, 'user_name' => $u['name'] ?? 'système', 'note' => mb_substr($note, 0, 1500), 'created_at' => now()]);
    }
    static function journalOf(string $entity, int $id): array { return DB::all('SELECT * FROM vn_journal WHERE entity=? AND entity_id=? ORDER BY id DESC', [$entity, $id]); }
    static function steps(string $entity, int $id): array { return DB::all('SELECT * FROM vn_steps WHERE entity=? AND entity_id=? ORDER BY position, id', [$entity, $id]); }
    static function progress(array $steps): array { $s = array_filter($steps, fn($x) => $x['status'] !== 'Non documenté'); return [count(array_filter($s, fn($x) => $x['status'] === 'Terminé')), count($s)]; }
    static function stepBar(array $steps): string { [$d, $t] = self::progress($steps); return $t ? '<div class="d-flex align-items-center gap-2"><progress max="' . $t . '" value="' . $d . '" style="width:90px"></progress><small>' . $d . '/' . $t . ' étapes</small></div>' : '<small class="text-muted">Étapes à définir</small>'; }
    /** Vrai si une étape obligatoire n'est pas terminée. */
    static function pendingMandatory(array $steps): bool { foreach ($steps as $s) if ($s['required'] && $s['status'] !== 'Terminé') return true; return false; }
    /** « Catégorie : nombre », une ligne par catégorie → [['name','count']] ; lève une exception si une ligne est mal formée. */
    static function breakdown(string $text): array {
        $out = []; foreach (preg_split('/\R/', $text) as $line) { if (trim($line) === '') continue;
            if (!preg_match('/^(.+?)\s*[:|]\s*(\d+)\s*$/u', $line, $m)) throw new \InvalidArgumentException('Pour les effectifs par catégorie, utilisez une ligne « Catégorie : nombre ».');
            $out[] = ['name' => mb_substr(trim($m[1]), 0, 80), 'count' => (int)$m[2]]; }
        return $out;
    }
    static function breakdownText(?string $json): string { return implode("\n", array_map(fn($x) => $x['name'] . ' : ' . $x['count'], (array)json_decode((string)$json, true))); }
    static function ref(string $prefix, string $table): string { do { $r = $prefix . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 6)); } while (DB::val("SELECT 1 FROM $table WHERE ref=?", [$r])); return $r; }
    static function qOptions(array $q): array { return match ($q['kind']) { 'rating5' => ['1', '2', '3', '4', '5'], 'rating7' => ['1', '2', '3', '4', '5', '6', '7'], 'yesno' => ['Oui', 'Non'], 'choice' => array_values(array_filter(array_map('trim', preg_split('/\R/', (string)$q['options'])), fn($x) => $x !== '')), default => [] }; }
    static function surveyBadge(array $c): string { return $c['state'] === 'draft' ? 'Brouillon' : ($c['state'] === 'closed' || $c['expires'] < date('Y-m-d') ? 'Collecte clôturée' : 'Publié'); }
    static function surveyOpen(array $c): bool { return $c['state'] === 'open' && $c['expires'] >= date('Y-m-d'); }
    static function surveyUrl(array $c, string $via = 'lien'): string {
        $base = rtrim((string)env('APP_URL', ''), '/');
        if ($base === '') { $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https'; $base = ($https ? 'https' : 'http') . '://' . preg_replace('/[^A-Za-z0-9.:\-\[\]]/', '', (string)($_SERVER['HTTP_HOST'] ?? 'localhost')); }
        return $base . url('q/' . $c['token']) . '?via=' . $via;
    }
    /** Résultats d'une enquête : par question, réponses valides et décomptes par option. */
    static function results(int $surveyId, array $questions, array $f = []): array {
        $w = ['r.survey_id=?']; $p = [$surveyId];
        if (!empty($f['channel'])) { $w[] = 'r.channel=?'; $p[] = $f['channel']; } if (!empty($f['from'])) { $w[] = 'r.submitted_at>=?'; $p[] = $f['from'] . ' 00:00:00'; } if (!empty($f['to'])) { $w[] = 'r.submitted_at<=?'; $p[] = $f['to'] . ' 23:59:59'; }
        $replies = (int)DB::val('SELECT COUNT(*) FROM vn_replies r WHERE ' . implode(' AND ', $w), $p);
        $by = []; foreach (DB::all('SELECT a.question_id, a.value FROM vn_answers a JOIN vn_replies r ON r.id=a.reply_id WHERE ' . implode(' AND ', $w) . ' ORDER BY a.id', $p) as $a) if ($a['value'] !== null && $a['value'] !== '') $by[(int)$a['question_id']][] = $a['value'];
        $rows = []; foreach ($questions as $q) { $v = $by[(int)$q['id']] ?? []; $rows[] = ['q' => $q, 'values' => $v, 'base' => count($v), 'counts' => array_map(fn($k) => [$k, count(array_filter($v, fn($x) => (string)$x === (string)$k))], self::qOptions($q))]; }
        return ['replies' => $replies, 'rows' => $rows];
    }
}
