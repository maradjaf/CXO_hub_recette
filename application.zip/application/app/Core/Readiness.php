<?php
namespace App\Core;

/**
 * Lot 55 : Operational Readiness (M28).
 * Cinq composantes (intégration, formations obligatoires, certifications valides, accès, score minimum), chacune bloquante ou non
 * selon le canal et le poste. Ready = tout est satisfait ; Partially Ready = seules des composantes non bloquantes manquent ;
 * Not Ready = au moins une composante bloquante manque. Le résultat courant est conservé et chaque changement de statut est historisé.
 */
final class Readiness {
    const COMP = ['onboarding' => 'Intégration', 'training' => 'Formations obligatoires', 'cert' => 'Certifications valides', 'access' => 'Accès et habilitations', 'score' => 'Score minimum'];
    const COMP_HELP = [
        'onboarding' => 'Toutes les tâches du parcours d\'intégration sont terminées.',
        'training' => 'Chaque formation obligatoire a une session suivie avec le résultat « Acquis ».',
        'cert' => 'Les certifications requises (formations obligatoires avec durée de validité) sont acquises et non expirées.',
        'access' => 'Les comptes applicatifs requis sont ouverts (liste des applications à renseigner dans la règle).',
        'score' => 'La moyenne des trois dernières évaluations qualité atteint le seuil.',
    ];
    const ST = ['ready' => 'Ready', 'partial' => 'Partially Ready', 'not_ready' => 'Not Ready'];
    const ST_C = ['ready' => 'success', 'partial' => 'warning', 'not_ready' => 'danger'];
    /** Valeurs appliquées quand aucune règle n'existe pour la composante. */
    const DEFAULTS = ['onboarding' => ['blocking' => 1, 'threshold' => null], 'training' => ['blocking' => 1, 'threshold' => null], 'cert' => ['blocking' => 1, 'threshold' => null],
                      'access' => ['blocking' => 1, 'threshold' => null], 'score' => ['blocking' => 0, 'threshold' => 70]];
    const WARN_DAYS = 30;

    private static ?array $rules = null;
    static function resetCache(): void { self::$rules = null; }

    /** Règle applicable à un collaborateur : la plus précise (canal + poste, puis canal, puis poste, puis règle générale). */
    static function rule(array $emp, string $comp): array {
        if (self::$rules === null) { self::$rules = []; foreach (DB::all('SELECT * FROM rd_rules ORDER BY id') as $r) self::$rules[$r['component']][] = $r; }
        $best = null; $bs = -1;
        foreach (self::$rules[$comp] ?? [] as $r) {
            if ($r['channel_id'] && (int)$r['channel_id'] !== (int)($emp['channel_id'] ?? 0)) continue;
            if ($r['position_id'] && (int)$r['position_id'] !== (int)($emp['position_id'] ?? 0)) continue;
            $s = ($r['channel_id'] ? 1 : 0) + ($r['position_id'] ? 1 : 0);
            if ($s > $bs || ($s === $bs && (int)$r['id'] > (int)$best['id'])) { $best = $r; $bs = $s; }
        }
        if ($best) return ['enabled' => (int)$best['enabled'], 'blocking' => (int)$best['blocking'], 'threshold' => $best['threshold'] === null ? null : (float)$best['threshold'], 'apps' => (string)$best['apps'], 'rule_id' => (int)$best['id']];
        return ['enabled' => 1, 'blocking' => self::DEFAULTS[$comp]['blocking'], 'threshold' => self::DEFAULTS[$comp]['threshold'], 'apps' => '', 'rule_id' => 0];
    }

    /** Évalue une composante : ['ok'=>bool, 'msg'=>string, 'items'=>string[], 'warn'=>string[]] */
    private static function check(string $comp, array $emp, array $rule): array {
        $id = (int)$emp['id']; $today = date('Y-m-d');
        switch ($comp) {
            case 'onboarding':
                $case = DB::one("SELECT id, status FROM onboarding_cases WHERE employee_id=? ORDER BY start_date DESC, id DESC LIMIT 1", [$id]);
                if (!$case) return ['ok' => true, 'msg' => 'Aucun parcours d\'intégration.', 'items' => [], 'warn' => []];
                $todo = DB::all("SELECT title, due_date FROM onboarding_tasks WHERE case_id=? AND status<>'done' ORDER BY position, id", [(int)$case['id']]);
                if (!$todo) return ['ok' => true, 'msg' => 'Parcours d\'intégration terminé.', 'items' => [], 'warn' => []];
                return ['ok' => false, 'msg' => count($todo) . ' tâche(s) d\'intégration à terminer.', 'items' => array_map(fn($t) => $t['title'] . ($t['due_date'] ? ' (échéance ' . date('d/m/Y', strtotime($t['due_date'])) . ')' : ''), $todo), 'warn' => [], 'link' => 'onboarding/' . $case['id']];
            case 'training':
                $req = DB::all("SELECT id, title FROM trainings WHERE mandatory=1 AND active=1 ORDER BY title");
                if (!$req) return ['ok' => true, 'msg' => 'Aucune formation obligatoire définie.', 'items' => [], 'warn' => []];
                $done = array_map('intval', array_column(DB::all("SELECT DISTINCT s.training_id FROM training_enrollments en JOIN training_sessions s ON s.id=en.session_id WHERE en.employee_id=? AND en.status='passed'", [$id]), 'training_id'));
                $miss = array_values(array_filter($req, fn($t) => !in_array((int)$t['id'], $done, true)));
                if (!$miss) return ['ok' => true, 'msg' => count($req) . ' formation(s) obligatoire(s) acquise(s).', 'items' => [], 'warn' => []];
                return ['ok' => false, 'msg' => count($miss) . ' formation(s) obligatoire(s) non acquise(s) sur ' . count($req) . '.', 'items' => array_column($miss, 'title'), 'warn' => []];
            case 'cert':
                $req = DB::all("SELECT id, title FROM trainings WHERE mandatory=1 AND active=1 AND validity_months>0 ORDER BY title");
                if (!$req) return ['ok' => true, 'msg' => 'Aucune certification requise.', 'items' => [], 'warn' => []];
                $miss = []; $warn = [];
                foreach ($req as $t) {
                    $vu = DB::val("SELECT MAX(COALESCE(en.valid_until,'9999-12-31')) FROM training_enrollments en JOIN training_sessions s ON s.id=en.session_id WHERE en.employee_id=? AND s.training_id=? AND en.status='passed'", [$id, (int)$t['id']]);
                    if ($vu === null || $vu === false) $miss[] = $t['title'] . ' : non obtenue';
                    elseif ($vu < $today) $miss[] = $t['title'] . ' : expirée le ' . date('d/m/Y', strtotime($vu));
                    elseif ($vu !== '9999-12-31' && $vu <= date('Y-m-d', strtotime('+' . self::WARN_DAYS . ' days'))) $warn[] = $t['title'] . ' : expire le ' . date('d/m/Y', strtotime($vu));
                }
                if (!$miss) return ['ok' => true, 'msg' => 'Toutes les certifications requises sont valides.' . ($warn ? ' ' . count($warn) . ' à renouveler bientôt.' : ''), 'items' => [], 'warn' => $warn];
                return ['ok' => false, 'msg' => count($miss) . ' certification(s) non valide(s).', 'items' => $miss, 'warn' => $warn];
            case 'access':
                $apps = array_values(array_filter(array_map('trim', explode(',', (string)$rule['apps'])), 'strlen'));
                if (!$apps) return ['ok' => true, 'msg' => 'Aucune application requise pour ce profil.', 'items' => [], 'warn' => []];
                $miss = [];
                foreach ($apps as $a) if (!DB::val("SELECT 1 FROM at_app_accounts WHERE employee_id=? AND status='active' AND LOWER(app_name)=LOWER(?)", [$id, $a])) $miss[] = $a;
                if (!$miss) return ['ok' => true, 'msg' => count($apps) . ' compte(s) applicatif(s) ouvert(s).', 'items' => [], 'warn' => []];
                return ['ok' => false, 'msg' => count($miss) . ' compte(s) applicatif(s) manquant(s) sur ' . count($apps) . '.', 'items' => $miss, 'warn' => []];
            case 'score':
                $thr = $rule['threshold'] ?? self::DEFAULTS['score']['threshold'];
                $rows = DB::all("SELECT score_pct FROM qa_evaluations WHERE employee_id=? AND status<>'draft' ORDER BY eval_date DESC, id DESC LIMIT 3", [$id]);
                if (!$rows) return ['ok' => false, 'msg' => 'Aucune évaluation qualité.', 'items' => [], 'warn' => []];
                $avg = round(array_sum(array_map(fn($r) => (float)$r['score_pct'], $rows)) / count($rows), 1);
                return $avg >= (float)$thr ? ['ok' => true, 'msg' => "Moyenne $avg % (seuil $thr %).", 'items' => [], 'warn' => []] : ['ok' => false, 'msg' => "Moyenne $avg % sous le seuil de $thr %.", 'items' => [], 'warn' => []];
        }
        return ['ok' => true, 'msg' => '', 'items' => [], 'warn' => []];
    }

    /** Évalue un collaborateur sans rien enregistrer. */
    static function evaluate(array $emp): array {
        $comps = []; $blk = 0; $oth = 0;
        foreach (self::COMP as $c => $label) {
            $rule = self::rule($emp, $c);
            if (!$rule['enabled']) { $comps[$c] = ['required' => 0, 'ok' => true, 'blocking' => (int)$rule['blocking'], 'msg' => 'Non requise pour ce profil.', 'items' => [], 'warn' => []]; continue; }
            $r = self::check($c, $emp, $rule);
            $comps[$c] = ['required' => 1, 'ok' => $r['ok'], 'blocking' => (int)$rule['blocking'], 'msg' => $r['msg'], 'items' => $r['items'], 'warn' => $r['warn'], 'link' => $r['link'] ?? null];
            if (!$r['ok']) { if ($rule['blocking']) $blk++; else $oth++; }
        }
        return ['status' => $blk ? 'not_ready' : ($oth ? 'partial' : 'ready'), 'blocking_missing' => $blk, 'other_missing' => $oth, 'comps' => $comps];
    }

    /** Calcule et enregistre l'état d'un collaborateur ; ajoute une ligne d'historique quand le statut change (ou la première fois). */
    static function compute(int $employeeId): ?array {
        $emp = DB::one('SELECT id, channel_id, position_id, status FROM employees WHERE id=?', [$employeeId]); if (!$emp) return null;
        $res = self::evaluate($emp); $json = json_encode($res['comps'], JSON_UNESCAPED_UNICODE); $now = now();
        $cur = DB::one('SELECT id, status FROM rd_status WHERE employee_id=?', [$employeeId]);
        $d = ['status' => $res['status'], 'blocking_missing' => $res['blocking_missing'], 'other_missing' => $res['other_missing'], 'detail' => $json, 'computed_at' => $now];
        if ($cur) DB::update('rd_status', $d, 'id=?', [(int)$cur['id']]); else DB::insert('rd_status', $d + ['employee_id' => $employeeId]);
        if (!$cur || $cur['status'] !== $res['status']) DB::insert('rd_history', ['employee_id' => $employeeId, 'status' => $res['status'], 'prev_status' => $cur['status'] ?? null, 'detail' => $json, 'computed_at' => $now]);
        $res['changed'] = !$cur || $cur['status'] !== $res['status']; $res['prev'] = $cur['status'] ?? null; return $res;
    }

    /** Recalcule tous les collaborateurs en poste (ou ceux d'une liste) ; retourne les effectifs par statut. */
    static function recomputeAll(?array $ids = null): array {
        self::resetCache(); $out = ['ready' => 0, 'partial' => 0, 'not_ready' => 0, 'changed' => 0, 'total' => 0];
        $rows = DB::all("SELECT id FROM employees WHERE status<>'left'" . ($ids !== null ? ' AND id IN (' . implode(',', array_map('intval', $ids ?: [0])) . ')' : '') . ' ORDER BY id');
        foreach ($rows as $r) { $x = self::compute((int)$r['id']); if (!$x) continue; $out['total']++; $out[$x['status']]++; if ($x['changed'] && $x['prev'] !== null) $out['changed']++; }
        // un collaborateur sorti n'a plus de statut courant
        DB::exec("DELETE FROM rd_status WHERE employee_id IN (SELECT id FROM employees WHERE status='left')");
        return $out;
    }

    static function badge(?string $st): string { return $st && isset(self::ST[$st]) ? badge(self::ST[$st], self::ST_C[$st]) : badge('Non calculé', 'secondary'); }
}
