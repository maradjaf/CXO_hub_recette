<?php
namespace App\Core;
/** Coordonnées des stores : lien carte et message prêt à envoyer au client (WhatsApp, SMS, chat, e-mail). */
class Stores {
    static function hasGps(array $s): bool { return !empty($s['gps_lat']) && !empty($s['gps_lng']); }
    static function mapUrl(array $s): string { return self::hasGps($s) ? 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($s['gps_lat'] . ',' . $s['gps_lng']) : ''; }
    static function message(array $s): string {
        $l = ['📍 ' . $s['name'] . (!empty($s['city']) ? ' (' . $s['city'] . ')' : '')];
        if (!empty($s['address'])) $l[] = $s['address'];
        if (!empty($s['situation'])) $l[] = 'Repère : ' . $s['situation'];
        if (!empty($s['hours'])) $l[] = 'Horaires : ' . $s['hours'];
        $tel = trim(($s['phone'] ?? '') . (!empty($s['phone2']) ? ' / ' . $s['phone2'] : '')); if ($tel !== '') $l[] = 'Tél. : ' . $tel;
        if (self::hasGps($s)) { $l[] = 'GPS : ' . $s['gps_lat'] . ', ' . $s['gps_lng']; $l[] = 'Itinéraire : ' . self::mapUrl($s); }
        return implode("\n", $l);
    }
}
