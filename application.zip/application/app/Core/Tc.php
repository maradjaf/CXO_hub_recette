<?php
namespace App\Core;
/** Discussions façon Teams : conversations individuelles et groupes choisis par les utilisateurs (interrogation régulière, sans service temps réel). */
class Tc {
    const EMOJI = ['👍', '❤️', '😂', '😮', '🙏', '✅'];
    const FILE_TYPES = ['png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'gif' => 'image/gif', 'webp' => 'image/webp', 'pdf' => 'application/pdf', 'txt' => 'text/plain', 'csv' => 'text/csv',
        'doc' => 'application/msword', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'xls' => 'application/vnd.ms-excel', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'ppt' => 'application/vnd.ms-powerpoint', 'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'zip' => 'application/zip', 'mp3' => 'audio/mpeg', 'm4a' => 'audio/mp4', 'wav' => 'audio/wav', 'mp4' => 'video/mp4'];
    static function on(): bool { return Xchg::on('tc.enabled'); }
    static function fileDir(): string { $d = ROOT . '/storage/uploads/tc'; if (!is_dir($d)) @mkdir($d, 0775, true); return $d; }
    /** Appartenance active de l'utilisateur à la conversation. */
    static function member(int $chat, ?int $uid = null): ?array { return DB::one('SELECT * FROM tc_members WHERE chat_id=? AND user_id=? AND left_at IS NULL', [$chat, $uid ?? (int)Auth::id()]) ?: null; }
    static function sys(int $chat, string $text): void { DB::insert('tc_messages', ['chat_id' => $chat, 'user_id' => null, 'user_name' => '', 'kind' => 'system', 'body' => $text, 'created_at' => now()]); DB::update('tc_chats', ['last_at' => now()], 'id=?', [$chat]); }
    static function direct(int $a, int $b): int {
        $key = min($a, $b) . '-' . max($a, $b); $id = DB::val('SELECT id FROM tc_chats WHERE direct_key=?', [$key]);
        if (!$id) { $id = DB::insert('tc_chats', ['kind' => 'direct', 'direct_key' => $key, 'created_by' => $a, 'last_at' => now(), 'created_at' => now()]); foreach (array_unique([$a, $b]) as $u) DB::insert('tc_members', ['chat_id' => $id, 'user_id' => $u, 'role' => 'member', 'last_read_id' => 0, 'joined_at' => now()]); }
        else foreach ([$a, $b] as $u) { if (!DB::val('SELECT 1 FROM tc_members WHERE chat_id=? AND user_id=?', [$id, $u])) DB::insert('tc_members', ['chat_id' => $id, 'user_id' => $u, 'role' => 'member', 'last_read_id' => 0, 'joined_at' => now()]); else DB::update('tc_members', ['left_at' => null], 'chat_id=? AND user_id=?', [$id, $u]); }
        return (int)$id;
    }
    /** Crée un groupe ; le créateur en est propriétaire. @param int[] $users */
    static function createGroup(string $name, int $by, array $users, ?int $meetingId = null): int {
        $id = DB::insert('tc_chats', ['kind' => 'group', 'name' => mb_substr($name, 0, 150), 'created_by' => $by, 'meeting_id' => $meetingId, 'last_at' => now(), 'created_at' => now()]);
        foreach (array_unique(array_merge([$by], $users)) as $u) if (DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$u])) DB::insert('tc_members', ['chat_id' => $id, 'user_id' => $u, 'role' => $u === $by ? 'owner' : 'member', 'last_read_id' => 0, 'joined_at' => now(), 'added_by' => $by]);
        self::sys((int)$id, 'Groupe créé par ' . DB::val('SELECT name FROM users WHERE id=?', [$by]) . '.'); return (int)$id;
    }
    static function unread(int $uid): int {
        return (int)DB::val("SELECT COUNT(*) FROM tc_messages m JOIN tc_members mb ON mb.chat_id=m.chat_id AND mb.user_id=? AND mb.left_at IS NULL AND mb.muted=0 JOIN tc_chats c ON c.id=m.chat_id AND c.archived=0 WHERE m.id>mb.last_read_id AND m.kind='msg' AND m.user_id<>? AND m.deleted_at IS NULL", [$uid, $uid]);
    }
    static function seen(int $uid): void { $n = DB::exec('UPDATE tc_presence SET seen_at=? WHERE user_id=?', [now(), $uid]); if (!$n && !DB::val('SELECT 1 FROM tc_presence WHERE user_id=?', [$uid])) DB::insert('tc_presence', ['user_id' => $uid, 'seen_at' => now()]); }
    static function online(array $ids): array { if (!$ids) return []; $in = implode(',', array_fill(0, count($ids), '?')); return array_map(fn($r) => (int)$r['user_id'], DB::all("SELECT user_id FROM tc_presence WHERE user_id IN ($in) AND seen_at>=?", array_merge(array_values($ids), [date('Y-m-d H:i:s', time() - 120)]))); }
    static function title(array $c, int $me): string {
        if ($c['kind'] === 'group') return $c['name'] ?: 'Groupe';
        return (string)(DB::val('SELECT u.name FROM tc_members m JOIN users u ON u.id=m.user_id WHERE m.chat_id=? AND m.user_id<>?', [(int)$c['id'], $me]) ?: 'Moi (notes personnelles)');
    }
    /** Notifie les membres ; les mentions @ notifient toujours, les autres messages sont regroupés et ignorent les conversations en sourdine. */
    static function notify(array $chat, int $from, string $fromName, string $body, array $mentioned): void {
        $url = '/tc/' . (int)$chat['id']; $title = $chat['kind'] === 'group' ? 'Discussion · ' . ($chat['name'] ?: 'Groupe') : 'Message de ' . $fromName;
        foreach (DB::all('SELECT user_id, muted FROM tc_members WHERE chat_id=? AND left_at IS NULL AND user_id<>?', [(int)$chat['id'], $from]) as $m) {
            $uid = (int)$m['user_id']; $ment = in_array($uid, $mentioned, true);
            if (!$ment && (!Xchg::on('tc.notify') || $m['muted'])) continue; if (!DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$uid])) continue;
            $t = $ment ? $fromName . ' vous a mentionné · ' . ($chat['name'] ?: 'discussion') : $title;
            if (DB::val('SELECT 1 FROM notifications WHERE user_id=? AND title=? AND url=? AND read_at IS NULL', [$uid, $t, $url])) continue;
            Notifier::send($uid, $t, mb_substr($fromName . ' : ' . $body, 0, 200), $url);
        }
    }
}
