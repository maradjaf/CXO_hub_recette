<?php
namespace App\Core;

/** Lot 54 : problèmes et erreurs connues (M33), changements (M34), interventions terrain (M36), demandes d'accès et comptes (M37). */
final class Itil {
    const PRB = ['open' => 'Ouvert', 'analysis' => 'En analyse', 'cause_found' => 'Cause trouvée', 'resolved' => 'Résolu', 'closed' => 'Clos'];
    const PRB_C = ['open' => 'secondary', 'analysis' => 'primary', 'cause_found' => 'info', 'resolved' => 'success', 'closed' => 'dark'];
    const CHG = ['draft' => 'Brouillon', 'submitted' => 'Soumis', 'coord_ok' => 'Avis favorable', 'approved' => 'Approuvé', 'rejected' => 'Refusé', 'in_progress' => 'En cours', 'done' => 'Réalisé', 'cancelled' => 'Annulé'];
    const CHG_C = ['draft' => 'secondary', 'submitted' => 'warning', 'coord_ok' => 'info', 'approved' => 'primary', 'rejected' => 'danger', 'in_progress' => 'primary', 'done' => 'success', 'cancelled' => 'dark'];
    const CHG_KIND = ['standard' => 'Standard (pré-approuvé)', 'normal' => 'Normal', 'urgent' => 'Urgent'];
    const RISK = ['low' => 'Faible', 'medium' => 'Moyen', 'high' => 'Élevé'];
    const RISK_C = ['low' => 'success', 'medium' => 'warning', 'high' => 'danger'];
    const OUTCOME = ['success' => 'Réussi', 'success_incident' => 'Réussi avec incident', 'failed' => 'Échec', 'rolled_back' => 'Retour arrière'];
    const INT = ['planned' => 'Planifiée', 'on_site' => 'Sur site', 'done' => 'Terminée', 'cancelled' => 'Annulée'];
    const INT_C = ['planned' => 'secondary', 'on_site' => 'primary', 'done' => 'success', 'cancelled' => 'dark'];
    const INT_OUT = ['resolved' => 'Résolu', 'partial' => 'Partiel (nouvelle visite)', 'failed' => 'Non résolu'];
    const ACC = ['submitted' => 'À valider', 'validated' => 'Validée, à exécuter', 'rejected' => 'Refusée', 'done' => 'Réalisée', 'cancelled' => 'Annulée'];
    const ACC_C = ['submitted' => 'warning', 'validated' => 'primary', 'rejected' => 'danger', 'done' => 'success', 'cancelled' => 'dark'];
    const ACC_ACT = ['create' => 'Ouverture', 'modify' => 'Modification du profil', 'suspend' => 'Suspension', 'close' => 'Fermeture'];
    const ACCT = ['active' => 'Actif', 'suspended' => 'Suspendu', 'closed' => 'Fermé'];
    const ACCT_C = ['active' => 'success', 'suspended' => 'warning', 'closed' => 'dark'];
    const CHECK = ['Équipement identifié et sécurisé', 'Diagnostic réalisé', 'Intervention effectuée', 'Test de bon fonctionnement après intervention', 'Zone de travail remise en état'];

    static function ref(string $prefix, string $table): string {
        $y = date('y'); $n = (int)DB::val("SELECT COUNT(*) FROM $table WHERE ref LIKE ?", ["$prefix-$y-%"]) + 1;
        do { $r = sprintf('%s-%s-%04d', $prefix, $y, $n++); } while (DB::val("SELECT 1 FROM $table WHERE ref=?", [$r])); return $r;
    }
    static function users(string $perm = ''): array {
        if ($perm === '') return DB::all("SELECT id, name FROM users WHERE status='active' ORDER BY name LIMIT 2000");
        return DB::all("SELECT DISTINCT u.id, u.name FROM users u JOIN user_roles ur ON ur.user_id=u.id JOIN roles r ON r.id=ur.role_id LEFT JOIN role_permissions rp ON rp.role_id=r.id LEFT JOIN permissions p ON p.id=rp.permission_id WHERE u.status='active' AND (r.code='admin' OR p.code=?) ORDER BY u.name", [$perm]);
    }
    static function name(?int $id): string { return $id ? (string)DB::val('SELECT name FROM users WHERE id=?', [$id]) : ''; }
    static function okDt($v): bool { return is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}$/', $v) && strtotime($v) !== false; }
    static function dtv(string $v): string { return date('Y-m-d H:i:s', strtotime($v)); }

    // ---- M33 Problèmes
    /** Incidents répétés (même catégorie et même store) non encore rattachés à un problème ouvert. */
    static function repeated(): array {
        $n = max(2, (int)setting('prb.threshold', 3)); $days = max(1, (int)setting('prb.days', 7)); $since = date('Y-m-d H:i:s', time() - $days * 86400);
        $rows = DB::all("SELECT t.category, t.store_id, COUNT(*) c, MAX(t.created_at) last_at FROM at_tickets t WHERE t.kind='incident' AND t.category IS NOT NULL AND t.store_id IS NOT NULL AND t.created_at>=? GROUP BY t.category, t.store_id HAVING COUNT(*)>=" . $n . " ORDER BY COUNT(*) DESC", [$since]);
        $out = [];
        foreach ($rows as $r) {
            if (DB::val("SELECT 1 FROM at_problems p WHERE p.category=? AND p.store_id=? AND p.status<>'closed'", [$r['category'], $r['store_id']])) continue;
            $r['store'] = (string)DB::val('SELECT name FROM stores WHERE id=?', [$r['store_id']]); $out[] = $r;
        }
        return $out;
    }
    static function linkTicket(int $pid, int $tid): bool {
        if (DB::val('SELECT 1 FROM at_problem_tickets WHERE problem_id=? AND ticket_id=?', [$pid, $tid])) return false;
        DB::insert('at_problem_tickets', ['problem_id' => $pid, 'ticket_id' => $tid, 'created_at' => now()]);
        $r = (string)DB::val('SELECT ref FROM at_problems WHERE id=?', [$pid]); Tickets::event($tid, 'link', "Rattaché au problème $r.", Auth::id()); return true;
    }
    /** Erreurs connues publiées proches d'un ticket (catégorie ou mots du titre). */
    static function suggest(array $t, int $limit = 3): array {
        $words = array_slice(array_values(array_filter(array_unique(Bot::tokens((string)$t['title'])), fn($w) => mb_strlen($w) >= 4)), 0, 6);
        if (!$words) return [];
        $w = []; $p = []; foreach ($words as $x) { $w[] = '(k.title LIKE ? OR k.symptoms LIKE ?)'; array_push($p, "%$x%", "%$x%"); }
        return DB::all('SELECT k.id, k.title, k.workaround, k.problem_id FROM at_known_errors k WHERE k.published=1 AND (' . implode(' OR ', $w) . ') ORDER BY k.id DESC LIMIT ' . (int)$limit, $p);
    }

    // ---- M34 Changements
    static function clog(int $id, string $act, string $c = ''): void { DB::insert('at_change_log', ['change_id' => $id, 'user_id' => Auth::id(), 'act' => $act, 'comment' => mb_substr($c, 0, 500) ?: null, 'created_at' => now()]); }
    /** Changements qui se chevauchent sur le même store ou la même cible. */
    static function conflicts(array $c, int $ignore = 0): array {
        if (empty($c['win_start']) || empty($c['win_end'])) return [];
        $w = ["x.id<>?", "x.status IN ('submitted','coord_ok','approved','in_progress')", 'x.win_start<? AND x.win_end>?']; $p = [$ignore, $c['win_end'], $c['win_start']]; $or = []; $q = [];
        if (!empty($c['store_id'])) { $or[] = 'x.store_id=?'; $q[] = (int)$c['store_id']; }
        if (trim((string)($c['targets'] ?? '')) !== '') { $or[] = 'LOWER(x.targets)=?'; $q[] = mb_strtolower(trim((string)$c['targets'])); }
        if (!$or) return [];
        return DB::all('SELECT x.id, x.ref, x.title, x.win_start, x.win_end, x.status FROM at_changes x WHERE ' . implode(' AND ', $w) . ' AND (' . implode(' OR ', $or) . ') ORDER BY x.win_start', array_merge($p, $q));
    }
    /** Incidents survenus sur le store dans les 48 h suivant la fenêtre. */
    static function aftermath(array $c): array {
        if (empty($c['store_id']) || empty($c['win_start'])) return [];
        $to = date('Y-m-d H:i:s', strtotime((string)($c['win_end'] ?: $c['win_start'])) + 48 * 3600);
        return DB::all("SELECT id, reference, title, created_at FROM at_tickets WHERE kind='incident' AND store_id=? AND created_at>=? AND created_at<=? ORDER BY created_at", [(int)$c['store_id'], $c['win_start'], $to]);
    }

    // ---- M36 Interventions
    /** Alertes de planification : congé approuvé ou autre intervention proche. */
    static function busy(int $techId, string $at, int $ignore = 0): array {
        $o = []; $day = substr($at, 0, 10); $emp = (int)DB::val('SELECT employee_id FROM users WHERE id=?', [$techId]);
        if ($emp && DB::val("SELECT 1 FROM leave_requests WHERE employee_id=? AND status='approved' AND start_date<=? AND end_date>=?", [$emp, $day, $day])) $o[] = 'Le technicien est en congé ce jour-là.';
        $ts = strtotime($at); $a = date('Y-m-d H:i:s', $ts - 5400); $b = date('Y-m-d H:i:s', $ts + 5400);
        foreach (DB::all("SELECT ref, planned_at FROM at_interventions WHERE technician_id=? AND id<>? AND status IN ('planned','on_site') AND planned_at>=? AND planned_at<=?", [$techId, $ignore, $a, $b]) as $x) $o[] = 'Conflit avec ' . $x['ref'] . ' (' . dt($x['planned_at']) . ').';
        return $o;
    }
    static function useStock(int $item, int $qty, int $ticket, string $note): bool {
        if ($qty < 1 || DB::exec('UPDATE at_stock SET qty=qty-?, updated_at=? WHERE id=? AND qty>=?', [$qty, now(), $item, $qty]) < 1) return false;
        DB::insert('at_stock_moves', ['item_id' => $item, 'kind' => 'out', 'delta' => -$qty, 'qty_after' => (int)DB::val('SELECT qty FROM at_stock WHERE id=?', [$item]), 'ticket_id' => $ticket ?: null, 'user_id' => Auth::id(), 'user_name' => Auth::user()['name'] ?? null, 'note' => mb_substr($note, 0, 300), 'created_at' => now()]);
        return true;
    }
    static function returnStock(int $item, int $qty, int $ticket, string $note): void {
        DB::exec('UPDATE at_stock SET qty=qty+?, updated_at=? WHERE id=?', [$qty, now(), $item]);
        DB::insert('at_stock_moves', ['item_id' => $item, 'kind' => 'in', 'delta' => $qty, 'qty_after' => (int)DB::val('SELECT qty FROM at_stock WHERE id=?', [$item]), 'ticket_id' => $ticket ?: null, 'user_id' => Auth::id(), 'user_name' => Auth::user()['name'] ?? null, 'note' => mb_substr($note, 0, 300), 'created_at' => now()]);
    }
    static function checklist(?array $i = null): array {
        $items = array_values(array_filter(array_map('trim', explode("\n", (string)setting('int.checklist', implode("\n", self::CHECK))))));
        $saved = $i && $i['checklist'] ? (json_decode($i['checklist'], true) ?: []) : []; $o = [];
        foreach ($items as $k => $l) $o[] = ['label' => $l, 'done' => !empty($saved[$k])]; return $o;
    }

    // ---- M37 Comptes
    static function apps(): array {
        $cfg = array_values(array_filter(array_map('trim', explode("\n", (string)setting('acc.apps', "Hermes\nZendesk\nCRM commercial\nMobile Money\nMessagerie\nVPN")))));
        $used = array_column(DB::all('SELECT DISTINCT app_name FROM at_app_accounts ORDER BY app_name'), 'app_name'); return array_values(array_unique(array_merge($cfg, $used)));
    }
    /** Applique une demande réalisée au registre des comptes. */
    static function applyAccount(array $r, string $login): void {
        $cur = DB::one("SELECT * FROM at_app_accounts WHERE employee_id=? AND app_name=? AND status<>'closed' ORDER BY id DESC LIMIT 1", [$r['employee_id'], $r['app_name']]);
        if ($r['act'] === 'create') { if ($cur) DB::update('at_app_accounts', ['account_login' => $login ?: $cur['account_login'], 'profile_name' => $r['profile_name'] ?: $cur['profile_name'], 'status' => 'active'], 'id=?', [$cur['id']]); else DB::insert('at_app_accounts', ['employee_id' => $r['employee_id'], 'app_name' => $r['app_name'], 'account_login' => $login ?: null, 'profile_name' => $r['profile_name'] ?: null, 'status' => 'active', 'request_id' => $r['id'], 'opened_at' => now()]); }
        elseif ($cur) { if ($r['act'] === 'modify') DB::update('at_app_accounts', ['profile_name' => $r['profile_name'] ?: $cur['profile_name']], 'id=?', [$cur['id']]); elseif ($r['act'] === 'suspend') DB::update('at_app_accounts', ['status' => 'suspended'], 'id=?', [$cur['id']]); elseif ($r['act'] === 'close') DB::update('at_app_accounts', ['status' => 'closed', 'closed_at' => now()], 'id=?', [$cur['id']]); }
    }
}
