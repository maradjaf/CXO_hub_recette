<?php
namespace App\Core;
/** Widgets du tableau de bord principal, configurables par rôle puis par utilisateur (l'utilisateur l'emporte sur le rôle). */
class DashConfig {
    const WIDGETS = [
        'kpi_staff' => 'Effectifs (collaborateurs, équipes, stores)',
        'kpi_flags' => 'Demandes à valider, absentéisme, contrats à échéance',
        'ag' => 'Évaluation (mes résultats et mon équipe)',
        'shortcuts' => 'Raccourcis',
        'by_team' => 'Effectif par équipe',
        'notifs' => 'Notifications non lues',
        'recent' => 'Activité récente',
        'advisor' => 'Mon espace conseiller (courbes, cours, tickets, congés, tâches)',
    ];
    /** Widgets visibles pour un utilisateur : [code => bool]. Sans configuration, tout est visible. */
    static function forUser(int $uid): array {
        $out = array_fill_keys(array_keys(self::WIDGETS), true); $out['advisor'] = !can('employees.view');   // espace conseiller : par défaut pour qui ne gère pas d'équipe
        $roles = array_map('intval', array_column(DB::all('SELECT role_id FROM user_roles WHERE user_id=?', [$uid]), 'role_id'));
        if ($roles) {
            $rows = DB::all('SELECT widget, visible FROM dash_config WHERE user_id IS NULL AND role_id IN (' . implode(',', $roles) . ')');
            $seen = [];
            foreach ($rows as $r) { $seen[$r['widget']] = ($seen[$r['widget']] ?? false) || (int)$r['visible'] === 1; }
            foreach ($seen as $w => $v) if (isset($out[$w])) $out[$w] = $v;
        }
        foreach (DB::all('SELECT widget, visible FROM dash_config WHERE user_id=?', [$uid]) as $r) if (isset($out[$r['widget']])) $out[$r['widget']] = (int)$r['visible'] === 1;
        return $out;
    }
    /** Configuration explicite d'une cible (rôle ou utilisateur) : [widget => 0|1]. */
    static function of(string $kind, int $id): array {
        $rows = $kind === 'role' ? DB::all('SELECT widget, visible FROM dash_config WHERE role_id=? AND user_id IS NULL', [$id]) : DB::all('SELECT widget, visible FROM dash_config WHERE user_id=?', [$id]);
        $o = []; foreach ($rows as $r) $o[$r['widget']] = (int)$r['visible']; return $o;
    }
    static function save(string $kind, int $id, array $visible, bool $custom): void {
        $kind === 'role' ? DB::exec('DELETE FROM dash_config WHERE role_id=? AND user_id IS NULL', [$id]) : DB::exec('DELETE FROM dash_config WHERE user_id=?', [$id]);
        if (!$custom) return;
        foreach (array_keys(self::WIDGETS) as $w)
            DB::insert('dash_config', ['role_id' => $kind === 'role' ? $id : null, 'user_id' => $kind === 'user' ? $id : null, 'widget' => $w, 'visible' => in_array($w, $visible, true) ? 1 : 0]);
    }
}
