<?php
namespace App\Core;

/** Organisation du personnel : Direction › Département / sous-direction › Pôle › Activité / store, et niveaux hiérarchiques N à N+6. */
class Org {
    /** Types d'unité, du plus haut au plus bas (rang croissant). */
    const KINDS = ['direction' => ['Direction', 0, 'building'], 'department' => ['Département / sous-direction', 1, 'diagram-2'], 'pole' => ['Pôle', 2, 'grid-3x3-gap'], 'activity' => ['Activité / store', 3, 'shop']];
    /** Niveaux par défaut (renommables dans Organisation › Structure). */
    const LEVELS = [6 => 'Directeur', 5 => 'Directeur de département', 4 => 'Head', 3 => 'Manager', 2 => 'Superviseur / Lead', 1 => "Chef d'équipe / Chef d'agence / Coordinateur", 0 => 'Autres agents'];
    const COLORS = [6 => '#003A84', 5 => '#1A5BB5', 4 => '#2E8B57', 3 => '#C99700', 2 => '#E07B00', 1 => '#8E44AD', 0 => '#6C757D'];

    static function code(int $n): string { return $n === 0 ? 'N' : 'N+' . $n; }
    static function level(int $n): string { $n = max(0, min(6, $n)); return (string)(setting('org.lvl.' . $n, '') ?: self::LEVELS[$n]); }
    static function levelFull(?int $n): string { return $n === null ? '—' : self::level($n) . ' (' . self::code($n) . ')'; }
    static function levels(): array { $o = []; for ($i = 6; $i >= 0; $i--) $o[$i] = self::levelFull($i); return $o; }
    /** Niveau par défaut d'un libellé de poste (utilisé pour la reprise des données existantes). */
    static function guessLevel(string $name): int {
        $n = mb_strtolower($name);
        if (preg_match('/directeur.*d[ée]partement|directrice.*d[ée]partement|sous-?direct/u', $n)) return 5;
        if (preg_match('/directeur|directrice/u', $n)) return 6;
        if (preg_match('/\bhead\b/u', $n)) return 4;
        if (preg_match('/manager|responsable/u', $n)) return 3;
        if (preg_match('/superviseur|\blead\b/u', $n)) return 2;
        if (preg_match('/chef|coordinat/u', $n)) return 1;
        return 0;
    }

    static function units(bool $all = false): array { return DB::all('SELECT * FROM org_units' . ($all ? '' : ' WHERE active=1') . ' ORDER BY sort_order, name'); }
    /** Arbre imbriqué ['unit'=>…, 'children'=>[…]]. */
    static function tree(bool $all = true): array {
        $by = []; foreach (self::units($all) as $u) $by[(int)$u['parent_id']][] = $u;
        $build = function (int $pid, int $d) use (&$build, $by): array { $o = []; if ($d > 8) return $o; foreach ($by[$pid] ?? [] as $u) $o[] = ['unit' => $u, 'children' => $build((int)$u['id'], $d + 1)]; return $o; };
        return $build(0, 0);
    }
    /** Liste à plat avec profondeur, pour les listes déroulantes. */
    static function flat(bool $all = false): array {
        $o = []; $w = function (array $nodes, int $d) use (&$w, &$o): void { foreach ($nodes as $n) { $o[] = $n['unit'] + ['depth' => $d]; $w($n['children'], $d + 1); } }; $w(self::tree($all), 0); return $o;
    }
    static function descendants(int $id): array {
        $ids = [$id]; $todo = [$id];
        for ($i = 0; $i < 10 && $todo; $i++) { $in = implode(',', array_map('intval', $todo)); $todo = []; foreach (DB::all("SELECT id FROM org_units WHERE parent_id IN ($in)") as $r) if (!in_array((int)$r['id'], $ids, true)) { $ids[] = $todo[] = (int)$r['id']; } }
        return $ids;
    }
    static function path(?int $id): string {
        $parts = []; for ($i = 0; $id && $i < 8; $i++) { $u = DB::one('SELECT id, name, parent_id FROM org_units WHERE id=?', [$id]); if (!$u) break; array_unshift($parts, $u['name']); $id = (int)$u['parent_id']; }
        return implode(' › ', $parts);
    }
    /** Le parent choisi est-il cohérent (rang inférieur) et sans boucle ? Retourne un message d'erreur ou ''. */
    static function checkParent(string $kind, ?int $parent, ?int $selfId): string {
        if ($kind === 'direction') return $parent ? 'Une direction est au sommet : pas de rattachement.' : '';
        if (!$parent) return 'Choisissez l\'unité de rattachement.';
        $p = DB::one('SELECT * FROM org_units WHERE id=?', [$parent]); if (!$p) return 'Rattachement inconnu.';
        if ((self::KINDS[$p['kind']][1] ?? 9) >= (self::KINDS[$kind][1] ?? 0)) return 'Une unité « ' . self::KINDS[$kind][0] . ' » se rattache à un niveau supérieur (' . implode(' ou ', array_map(fn($k) => self::KINDS[$k][0], array_keys(array_filter(self::KINDS, fn($x) => $x[1] < self::KINDS[$kind][1])))) . ').';
        if ($selfId && in_array($parent, self::descendants($selfId), true)) return 'Rattachement circulaire impossible.';
        return '';
    }
    static function dir(): string { $d = ROOT . '/storage/uploads/org'; if (!is_dir($d)) @mkdir($d, 0775, true); return $d; }
    static function initials(array $e): string { return mb_strtoupper(mb_substr((string)$e['first_name'], 0, 1) . mb_substr((string)$e['last_name'], 0, 1)); }

    /** Collaborateurs filtrés (unité avec sous-unités, niveau, contrat, statut, recherche). */
    static function people(array $f): array {
        $w = ['1=1']; $p = [];
        $st = (string)($f['status'] ?? 'active'); if ($st !== 'all') { $w[] = 'e.status=?'; $p[] = $st ?: 'active'; }
        if (!empty($f['unit'])) { $ids = self::descendants((int)$f['unit']); $w[] = 'e.org_unit_id IN (' . implode(',', array_map('intval', $ids)) . ')'; }
        if (isset($f['level']) && $f['level'] !== '' && ctype_digit((string)$f['level'])) { $w[] = 'e.org_level=?'; $p[] = (int)$f['level']; }
        if (!empty($f['contract'])) { $w[] = 'e.contract_type=?'; $p[] = (string)$f['contract']; }
        if (($q = trim((string)($f['q'] ?? ''))) !== '') { $w[] = '(e.first_name LIKE ? OR e.last_name LIKE ? OR e.matricule LIKE ? OR po.name LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%", "%$q%"); }
        if (isset($f['level_min']) && (int)$f['level_min'] > 0) { $w[] = 'e.org_level>=?'; $p[] = (int)$f['level_min']; }
        return DB::all('SELECT e.*, po.name position_name, u.name unit_name, m.first_name mfn, m.last_name mln FROM employees e LEFT JOIN positions po ON po.id=e.position_id LEFT JOIN org_units u ON u.id=e.org_unit_id LEFT JOIN employees m ON m.id=e.manager_id WHERE ' . implode(' AND ', $w) . ' ORDER BY COALESCE(e.org_level,0) DESC, e.last_name, e.first_name', $p);
    }

    /** Publie le trombinoscope : instantané figé + notification de tout le personnel du périmètre. */
    static function publish(string $title, ?int $unit, int $levelMin, bool $auto, ?int $by): int {
        $people = self::people(['unit' => $unit, 'status' => 'active', 'level_min' => $levelMin]);
        $id = DB::insert('org_publications', ['title' => $title, 'unit_id' => $unit, 'level_min' => $levelMin, 'auto' => $auto ? 1 : 0, 'recipients' => 0, 'created_by' => $by, 'created_at' => now()]);
        foreach ($people as $e) {
            $photo = null;
            if (!empty($e['photo']) && is_file(self::dir() . '/' . $e['photo'])) { $photo = 'p' . $id . '_' . $e['photo']; @copy(self::dir() . '/' . $e['photo'], self::dir() . '/' . $photo); }
            DB::insert('org_pub_items', ['publication_id' => $id, 'employee_id' => (int)$e['id'], 'full_name' => $e['first_name'] . ' ' . $e['last_name'], 'role' => (string)$e['position_name'], 'unit_path' => self::path($e['org_unit_id'] ? (int)$e['org_unit_id'] : null),
                'org_level' => (int)$e['org_level'], 'contract' => (string)$e['contract_type'], 'photo' => $photo]);
        }
        $n = 0;
        foreach ($people as $e) { $uid = (int)DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [(int)$e['id']]); if ($uid) { Notifier::send($uid, 'Trombinoscope : ' . $title, count($people) . ' collaborateurs du périmètre ' . ($unit ? self::path($unit) : 'de la direction') . '.', '/organigramme/publications/' . $id); $n++; } }
        DB::update('org_publications', ['recipients' => $n], 'id=?', [$id]);
        return $id;
    }
    /** Publication périodique due ? (réglage « org.pub_days », 0 = désactivée). */
    static function dueAuto(): bool {
        $d = (int)setting('org.pub_days', '0'); if ($d <= 0) return false;
        $last = DB::val('SELECT MAX(created_at) FROM org_publications WHERE auto=1'); return !$last || strtotime((string)$last) <= time() - $d * 86400;
    }

    /** Applique une mobilité interne : nouvelle équipe / store / unité / poste / responsable, historique des affectations conservé. */
    static function applyMove(int $id): bool {
        $m = DB::one('SELECT * FROM mobility_moves WHERE id=?', [$id]); if (!$m || $m['status'] !== 'planned') return false;
        $e = DB::one('SELECT * FROM employees WHERE id=?', [(int)$m['employee_id']]); if (!$e) return false;
        $d = ['updated_at' => now(), 'team_id' => $m['to_team_id'] ?: null, 'store_id' => $m['to_store_id'] ?: null, 'position_id' => $m['to_position_id'] ?: $e['position_id']];
        $d['org_unit_id'] = $m['to_unit_id'] ?: ($m['to_team_id'] ? DB::val('SELECT org_unit_id FROM teams WHERE id=?', [(int)$m['to_team_id']]) : null) ?: $e['org_unit_id'];
        if ($m['to_team_id']) { $ch = DB::val('SELECT channel_id FROM teams WHERE id=?', [(int)$m['to_team_id']]); if ($ch) $d['channel_id'] = (int)$ch; }
        if ($m['to_position_id']) { $lv = DB::val('SELECT org_level FROM positions WHERE id=?', [(int)$m['to_position_id']]); if ($lv !== null) $d['org_level'] = (int)$lv; }
        $head = $d['org_unit_id'] ? DB::val('SELECT head_employee_id FROM org_units WHERE id=?', [(int)$d['org_unit_id']]) : null; $d['manager_id'] = $m['to_manager_id'] ?: (($head && (int)$head !== (int)$e['id']) ? (int)$head : $e['manager_id']);
        DB::update('employees', $d, 'id=?', [(int)$e['id']]);
        $today = date('Y-m-d'); DB::exec('UPDATE employee_assignments SET valid_to=? WHERE employee_id=? AND valid_to IS NULL', [$today, (int)$e['id']]);
        DB::insert('employee_assignments', ['employee_id' => (int)$e['id'], 'team_id' => $d['team_id'], 'store_id' => $d['store_id'], 'position_id' => $d['position_id'], 'manager_id' => $d['manager_id'], 'valid_from' => $today, 'created_by' => Auth::id()]);
        DB::update('mobility_moves', ['status' => 'done', 'applied_at' => now()], 'id=?', [$id]);
        if ($u = DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [(int)$e['id']])) Notifier::send((int)$u, 'Mobilité interne', 'Votre nouvelle affectation est effective : ' . self::path($d['org_unit_id'] ? (int)$d['org_unit_id'] : null), '/profile');
        try { Congrats::publish($id); } catch (\Throwable $x) {}   // la mobilité reste valide même si le message ne peut être publié
        return true;
    }
    static function applyDueMoves(): int { $n = 0; foreach (DB::all("SELECT id FROM mobility_moves WHERE status='planned' AND effective_date<=?", [date('Y-m-d')]) as $m) if (self::applyMove((int)$m['id'])) $n++; return $n; }
}
