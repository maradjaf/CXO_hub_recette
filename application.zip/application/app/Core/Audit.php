<?php
namespace App\Core;
/** Journal d'audit : modifications de données, en ajout seul (triggers sur audit_logs). */
class Audit {
    static function log(string $action, string $entity, $id = null, $before = null, $after = null): void {
        $u = Auth::user();
        DB::insert('audit_logs', [
            'created_at' => now(), 'user_id' => $u['id'] ?? null, 'user_name' => $u['name'] ?? 'système', 'action' => $action,
            'entity_type' => $entity, 'entity_id' => $id === null ? null : (string)$id,
            'before_json' => $before === null ? null : json_encode(self::mask($before), JSON_UNESCAPED_UNICODE),
            'after_json' => $after === null ? null : json_encode(self::mask($after), JSON_UNESCAPED_UNICODE), 'ip' => Request::ip(),
        ]);
    }
    private static function mask($v) {
        if (!is_array($v)) return $v;
        foreach (['password', 'password_hash'] as $k) if (isset($v[$k])) $v[$k] = '***';
        return $v;
    }
}
