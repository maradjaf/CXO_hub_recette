<?php
namespace App\Core;
/**
 * Réunions : planification (créer, modifier, reporter, annuler), invitations (outil, e-mail + agenda .ics, SMS, WhatsApp),
 * compte rendu (rédaction, versions, validation, diffusion), décisions et plans d'actions, indicateurs.
 * Distinct des « appels » rattachés à un ticket ou un incident (classe Meet), dont il réutilise les outils de visioconférence et les canaux d'envoi.
 */
class Rn {
    const STATUS = ['planned' => 'Planifiée', 'held' => 'Tenue', 'cancelled' => 'Annulée'];
    const MIN = ['none' => 'Pas de compte rendu', 'draft' => 'Brouillon', 'validated' => 'Validé', 'sent' => 'Diffusé'];
    const ROLES = ['required' => 'Requis', 'optional' => 'Facultatif', 'informed' => 'Pour information'];
    const RSVP = ['pending' => 'Sans réponse', 'yes' => 'Accepte', 'no' => 'Décline', 'maybe' => 'Peut-être'];
    const ACT = ['open' => 'À faire', 'in_progress' => 'En cours', 'to_verify' => 'À vérifier', 'done' => 'Clôturée', 'cancelled' => 'Abandonnée'];
    const PRIO = ['low' => 'Basse', 'normal' => 'Normale', 'high' => 'Haute'];
    const DEC = ['active' => 'Retenue', 'applied' => 'Appliquée', 'revoked' => 'Abandonnée'];
    const OPEN = ['open', 'in_progress', 'to_verify'];

    static function on(): bool { return Xchg::on('rn.enabled'); }
    static function kinds(): array { return array_values(array_filter(array_map('trim', explode(',', Xchg::get('rn.kinds'))))); }
    static function ref(): string {
        $y = date('Y'); $n = (int)DB::val('SELECT COUNT(*) FROM rn_meetings WHERE ref LIKE ?', ["RN-$y-%"]) + 1;
        do { $r = sprintf('RN-%s-%04d', $y, $n++); } while (DB::val('SELECT 1 FROM rn_meetings WHERE ref=?', [$r])); return $r;
    }
    /** Rôle de l'utilisateur courant sur la réunion : organizer, secretary, attendee ou null. */
    static function role(array $m, ?int $uid = null): ?string {
        $uid ??= (int)Auth::id(); if ((int)$m['organizer_id'] === $uid) return 'organizer'; if ($m['secretary_id'] && (int)$m['secretary_id'] === $uid) return 'secretary';
        return DB::val('SELECT 1 FROM rn_attendees WHERE meeting_id=? AND user_id=?', [(int)$m['id'], $uid]) ? 'attendee' : null;
    }
    static function sees(array $m): bool { return can('rn.all') || self::role($m) !== null; }
    static function manages(array $m): bool { return can('rn.all') || in_array(self::role($m), ['organizer', 'secretary'], true); }
    /** Fragment SQL limitant aux réunions de l'utilisateur (tout pour rn.all). @return array{0:string,1:array} */
    static function scope(string $a = 'm'): array {
        if (can('rn.all')) return ['1=1', []]; $me = (int)Auth::id();
        return ["($a.organizer_id=? OR $a.secretary_id=? OR EXISTS (SELECT 1 FROM rn_attendees sa WHERE sa.meeting_id=$a.id AND sa.user_id=?))", [$me, $me, $me]];
    }
    static function event(int $mid, string $kind, string $text): void { DB::insert('rn_events', ['meeting_id' => $mid, 'user_id' => Auth::id(), 'kind' => $kind, 'text' => mb_substr($text, 0, 500), 'created_at' => now()]); }
    static function when(array $m): string { $s = strtotime($m['start_at']); $j = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'][(int)date('w', $s)]; return $j . ' ' . date('d/m/Y', $s) . ' de ' . date('H\hi', $s) . ' à ' . date('H\hi', $s + (int)$m['duration_min'] * 60); }
    static function abs(string $path): string { $b = rtrim((string)env('APP_URL', ''), '/'); return $b !== '' ? $b . '/' . ltrim($path, '/') : ''; }
    /** HTML du compte rendu converti en texte lisible (e-mail). */
    static function mailText(?string $html): string {
        $t = preg_replace('~<li[^>]*>~i', "\n• ", (string)$html); $t = preg_replace('~</(p|h[1-6]|tr|div|ul|ol|table)>|<br\s*/?>~i', "\n", $t); $t = preg_replace('~</t[dh]>~i', ' | ', $t);
        $t = html_entity_decode(strip_tags($t), ENT_QUOTES, 'UTF-8'); return trim(preg_replace(["/[ \t]+/", "/ *\n */", "/\n{3,}/"], [' ', "\n", "\n\n"], $t));
    }
    private static function esc(string $s): string { return str_replace(["\\", ';', ',', "\r\n", "\n"], ['\\\\', '\;', '\,', '\n', '\n'], $s); }
    private static function fold(string $l): string { $o = ''; while (strlen($l) > 73) { $o .= substr($l, 0, 73) . "\r\n "; $l = substr($l, 73); } return $o . $l; }
    static function ics(array $m, array $att, string $method = 'REQUEST'): string {
        $z = fn($t) => gmdate('Ymd\THis\Z', $t); $s = strtotime($m['start_at']); $from = (string)env('MAIL_FROM', 'noreply@localhost'); $host = substr(strrchr($from, '@') ?: '@localhost', 1) ?: 'localhost';
        $desc = $m['title'] . "\n" . ($m['objective'] ? 'Objectif : ' . $m['objective'] . "\n" : '') . ($m['link'] ? 'Lien : ' . $m['link'] . "\n" : '') . ($m['dial_in'] ? 'Téléphone / pont : ' . $m['dial_in'] . "\n" : '') . ($m['agenda'] ? "Ordre du jour :\n" . self::mailText($m['agenda']) : '');
        $loc = $m['place'] ?: ($m['link'] ?: $m['dial_in']);
        $L = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//CXO Excellence Hub//Reunions//FR', 'CALSCALE:GREGORIAN', 'METHOD:' . $method, 'BEGIN:VEVENT', 'UID:reunion-' . (int)$m['id'] . '@' . $host, 'SEQUENCE:' . (int)$m['seq'], 'DTSTAMP:' . $z(time()),
            'DTSTART:' . $z($s), 'DTEND:' . $z($s + (int)$m['duration_min'] * 60), 'SUMMARY:' . self::esc($m['title']), 'DESCRIPTION:' . self::esc($desc)];
        if ($loc) $L[] = 'LOCATION:' . self::esc((string)$loc); if ($m['link']) $L[] = 'URL:' . $m['link'];
        $L[] = 'ORGANIZER;CN=' . self::esc((string)(DB::val('SELECT name FROM users WHERE id=?', [(int)$m['organizer_id']]) ?: 'Organisateur')) . ':mailto:' . $from;
        foreach ($att as $g) if ($g['email']) $L[] = 'ATTENDEE;CN=' . self::esc($g['name']) . ';ROLE=' . ($g['role'] === 'required' ? 'REQ' : 'OPT') . '-PARTICIPANT;PARTSTAT=NEEDS-ACTION;RSVP=FALSE:mailto:' . $g['email'];
        $L[] = 'STATUS:' . ($method === 'CANCEL' ? 'CANCELLED' : 'CONFIRMED'); if ($method !== 'CANCEL') array_push($L, 'BEGIN:VALARM', 'TRIGGER:-PT15M', 'ACTION:DISPLAY', 'DESCRIPTION:Rappel', 'END:VALARM'); array_push($L, 'END:VEVENT', 'END:VCALENDAR');
        return implode("\r\n", array_map([self::class, 'fold'], $L)) . "\r\n";
    }
    /** Informe les participants. $kind : INVITATION | REPORT | MODIFICATION | ANNULATION | RAPPEL. @return int nombre de participants traités */
    static function notify(int $mid, string $kind, ?int $only = null, string $note = ''): int {
        $m = DB::one('SELECT * FROM rn_meetings WHERE id=?', [$mid]); if (!$m) return 0; $n = 0; $cancel = $kind === 'ANNULATION';
        $att = DB::all('SELECT * FROM rn_attendees WHERE meeting_id=? ORDER BY id', [$mid]); $when = self::when($m); $pl = Meet::label($m['platform']);
        $head = ['INVITATION' => 'Invitation', 'REPORT' => 'Réunion reportée', 'MODIFICATION' => 'Réunion modifiée', 'ANNULATION' => 'Réunion annulée', 'RAPPEL' => 'Rappel de réunion'][$kind] ?? $kind; $head .= ' · ' . $m['ref'];
        $where = $m['place'] ? 'Lieu : ' . $m['place'] : ''; $conn = $m['link'] ? 'Lien : ' . $m['link'] : ($m['dial_in'] ? 'Tél. : ' . $m['dial_in'] : '');
        $short = $m['title'] . ($cancel ? ' — ANNULÉE (prévue ' . date('d/m H:i', strtotime($m['start_at'])) . ')' : ' — ' . $when) . (!$cancel && $conn ? ' — ' . $conn : '') . ($note !== '' ? ' — ' . $note : '');
        $ics = $kind === 'RAPPEL' ? null : self::ics($m, $att, $cancel ? 'CANCEL' : 'REQUEST'); $page = self::abs('rn/' . $mid);
        foreach ($att as $g) {
            if ($only && (int)$g['id'] !== $only) continue; $n++; $st = ['n_inapp' => 'skipped', 'n_email' => 'skipped', 'n_sms' => 'skipped', 'n_wa' => 'skipped'];
            if (Xchg::on('rn.ch_inapp') && $g['user_id'] && DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [(int)$g['user_id']])) { Notifier::send((int)$g['user_id'], $head, mb_substr($short, 0, 480), '/rn/' . $mid); $st['n_inapp'] = 'sent'; }
            if (Xchg::on('rn.ch_email') && $kind !== 'RAPPEL' && $g['email']) {
                $txt = "Bonjour {$g['name']},\n\n$head\n\nObjet : {$m['title']}\n" . ($m['objective'] ? 'Objectif : ' . $m['objective'] . "\n" : '') . "Quand : $when" . ($cancel ? " (annulée)\n" : "\n") . (!$cancel ? "Outil : $pl\n" . ($where ? "$where\n" : '') . ($m['link'] ? 'Lien : ' . $m['link'] . "\n" : '') . ($m['dial_in'] ? 'Téléphone / pont : ' . $m['dial_in'] . "\n" : '') : '')
                    . ($note !== '' ? "\nMotif / précision : $note\n" : '') . (!$cancel && $m['agenda'] ? "\nOrdre du jour :\n" . self::mailText($m['agenda']) . "\n" : '') . ($page !== '' ? "\nFiche de la réunion : $page\n" : '') . "\nVotre rôle : " . (self::ROLES[$g['role']] ?? '') . '.';
                $st['n_email'] = Mailer::queue($g['email'], '[' . $m['ref'] . '] ' . $head . ' : ' . $m['title'], $txt, null, $ics) ? 'queued' : 'skipped';
            }
            if (Xchg::on('rn.ch_sms') && $g['phone']) $st['n_sms'] = Sms::queue($g['phone'], mb_substr(($cancel ? 'ANNULÉE ' : ($kind === 'REPORT' ? 'REPORTÉE ' : ($kind === 'RAPPEL' ? 'RAPPEL ' : ''))) . $m['title'] . ' ' . date('d/m H:i', strtotime($m['start_at'])) . ' (' . (int)$m['duration_min'] . ' min)' . (!$cancel ? ($m['place'] ? ' ' . $m['place'] : '') . ($m['link'] ? ' ' . $m['link'] : ($m['dial_in'] ? ' ' . $m['dial_in'] : '')) : ''), 0, 155)) ? 'queued' : 'skipped';
            if (Xchg::on('rn.ch_wa') && $g['phone']) $st['n_wa'] = Wa::queue($g['phone'], strtolower($kind), ($cancel ? 'ANNULÉE — ' : '') . $head . "\n" . $m['title'] . "\n" . $when . ($conn && !$cancel ? "\n" . $conn : ''), [$g['name'], ($cancel ? '[ANNULÉE] ' : '') . $m['title'], date('d/m/Y H:i', strtotime($m['start_at'])), $cancel ? 'annulée' : ($m['link'] ?: ($m['dial_in'] ?: ($m['place'] ?: '—')))], null) ? 'queued' : 'skipped';
            DB::update('rn_attendees', $st, 'id=?', [(int)$g['id']]);
        }
        return $n;
    }
    /** Diffuse le compte rendu validé (outil + e-mail + SMS court) aux participants et destinataires supplémentaires. @return int destinataires */
    static function distribute(int $mid, array $extra = []): int {
        $m = DB::one('SELECT * FROM rn_meetings WHERE id=?', [$mid]); if (!$m) return 0; $page = self::abs('rn/' . $mid . '/minutes'); $n = 0; $seen = [];
        $body = self::mailText($m['minutes_html']) . "\n\n" . self::annexText($mid);
        $recipients = DB::all('SELECT user_id, name, email, phone FROM rn_attendees WHERE meeting_id=?', [$mid]); foreach ($extra as $x) $recipients[] = $x + ['user_id' => null, 'phone' => null];
        foreach ($recipients as $r) {
            $key = $r['user_id'] ? 'u' . $r['user_id'] : strtolower((string)$r['email']) . '|' . $r['phone']; if (isset($seen[$key])) continue; $seen[$key] = 1; $n++;
            if ($r['user_id'] && Xchg::on('rn.ch_inapp') && DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [(int)$r['user_id']])) Notifier::send((int)$r['user_id'], 'Compte rendu · ' . $m['ref'], $m['title'] . ' — le compte rendu (v' . (int)$m['minutes_version'] . ') est disponible.', '/rn/' . $mid . '/minutes');
            if (Xchg::on('rn.ch_email') && $r['email']) Mailer::queue($r['email'], '[' . $m['ref'] . '] Compte rendu : ' . $m['title'], "Bonjour {$r['name']},\n\nCompte rendu de la réunion « {$m['title']} » du " . date('d/m/Y', strtotime($m['start_at'])) . " (version " . (int)$m['minutes_version'] . ").\n\n" . $body . ($page !== '' ? "\n\nConsulter en ligne : $page" : ''));
            elseif (Xchg::on('rn.ch_sms') && !$r['email'] && $r['phone']) Sms::queue($r['phone'], mb_substr('Compte rendu dispo : ' . $m['title'] . ' du ' . date('d/m') . ($page !== '' ? ' ' . $page : ''), 0, 155));
        }
        return $n;
    }
    static function decisions(int $mid): array { return DB::all('SELECT d.*, u.name owner FROM rn_decisions d LEFT JOIN users u ON u.id=d.owner_id WHERE d.meeting_id=? ORDER BY d.position, d.id', [$mid]); }
    static function actions(int $mid): array { return DB::all('SELECT a.*, u.name owner FROM rn_actions a LEFT JOIN users u ON u.id=a.owner_id WHERE a.meeting_id=? ORDER BY a.due_date, a.id', [$mid]); }
    static function overdue(array $a): bool { return in_array($a['status'], self::OPEN, true) && $a['due_date'] < date('Y-m-d'); }
    /** Décisions et actions sous forme de texte (diffusion). */
    static function annexText(int $mid): string {
        $o = ''; $d = self::decisions($mid); $a = self::actions($mid);
        if ($d) { $o .= "DÉCISIONS\n"; foreach ($d as $i => $x) $o .= ($i + 1) . '. ' . $x['text'] . ($x['owner'] ? ' (' . $x['owner'] . ')' : '') . "\n"; $o .= "\n"; }
        if ($a) { $o .= "PLAN D'ACTIONS\n"; foreach ($a as $x) $o .= '• ' . $x['title'] . ' — ' . ($x['owner'] ?: '?') . ' — échéance ' . d($x['due_date']) . ' — ' . self::ACT[$x['status']] . "\n"; }
        return trim($o);
    }
    /** Modèle de départ du compte rendu. */
    static function template(array $m): string {
        $att = DB::all('SELECT * FROM rn_attendees WHERE meeting_id=? ORDER BY role, name', [(int)$m['id']]); $h = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
        $pres = array_filter($att, fn($a) => $a['attended'] === '1' || $a['attended'] === 1); $abs = array_filter($att, fn($a) => ($a['attended'] === '0' || $a['attended'] === 0) && $a['role'] !== 'informed');
        $li = fn($l) => $l ? '<ul>' . implode('', array_map(fn($a) => '<li>' . $h($a['name']) . '</li>', $l)) . '</ul>' : '<p><em>À renseigner</em></p>';
        return '<h2>Compte rendu — ' . $h($m['title']) . '</h2><p>' . $h(self::when($m)) . ($m['place'] ? ' · ' . $h($m['place']) : '') . '</p><h3>Participants présents</h3>' . $li($pres) . '<h3>Absents / excusés</h3>' . $li($abs)
            . '<h3>Ordre du jour</h3>' . ($m['agenda'] ? RichHtml::render($m['agenda']) : '<p><em>À renseigner</em></p>') . '<h3>Points abordés</h3><p><em>Résumé des échanges…</em></p>';
    }
    /** Indicateurs sur un ensemble de réunions. */
    static function kpis(array $ids): array {
        $K = ['n' => 0, 'planned' => 0, 'held' => 0, 'cancelled' => 0, 'postponed' => 0, 'hours' => 0.0, 'avg_dur' => 0, 'att_inv' => 0, 'att_pre' => 0, 'rsvp_inv' => 0, 'rsvp_ans' => 0, 'min_due' => 0, 'min_sent' => 0, 'min_delay_h' => null, 'dec' => 0, 'dec_by' => [], 'act' => 0, 'act_by' => [], 'act_overdue' => 0, 'act_done' => 0, 'act_ontime' => 0, 'act_days' => null, 'act_chg' => 0, 'rows' => [], 'owners' => [], 'months' => []];
        if (!$ids) return $K; $in = implode(',', array_fill(0, count($ids), '?')); $today = date('Y-m-d');
        $ms = DB::all("SELECT m.*, u.name organizer FROM rn_meetings m LEFT JOIN users u ON u.id=m.organizer_id WHERE m.id IN ($in) ORDER BY m.start_at DESC", $ids); $K['n'] = count($ms);
        $att = []; foreach (DB::all("SELECT * FROM rn_attendees WHERE meeting_id IN ($in)", $ids) as $a) $att[$a['meeting_id']][] = $a;
        $dec = []; foreach (DB::all("SELECT * FROM rn_decisions WHERE meeting_id IN ($in)", $ids) as $a) $dec[$a['meeting_id']][] = $a;
        $act = []; foreach (DB::all("SELECT a.*, u.name owner FROM rn_actions a LEFT JOIN users u ON u.id=a.owner_id WHERE a.meeting_id IN ($in)", $ids) as $a) $act[$a['meeting_id']][] = $a;
        $delays = []; $durs = []; $cl = [];
        foreach ($ms as $m) {
            $id = (int)$m['id']; $K[$m['status']]++; if ((int)$m['postponed_count'] > 0) $K['postponed']++; $mo = substr($m['start_at'], 0, 7); $K['months'][$mo]['n'] = ($K['months'][$mo]['n'] ?? 0) + 1;
            $r = ['m' => $m, 'inv' => 0, 'pre' => 0, 'dec' => count($dec[$id] ?? []), 'act' => 0, 'done' => 0, 'late' => 0, 'delay_h' => null];
            if ($m['status'] !== 'cancelled') $durs[] = (int)$m['duration_min'];
            foreach ($att[$id] ?? [] as $a) {
                if ($a['role'] === 'informed') continue;
                if ($m['status'] === 'held') { $r['inv']++; if ((int)($a['attended'] ?? 0) === 1 && $a['attended'] !== null) $r['pre']++; }
                if ($m['status'] !== 'cancelled') { $K['rsvp_inv']++; if ($a['rsvp'] !== 'pending') $K['rsvp_ans']++; }
            }
            $K['att_inv'] += $r['inv']; $K['att_pre'] += $r['pre'];
            if ($m['status'] === 'held') { $K['hours'] += (int)$m['duration_min'] / 60; $K['min_due']++; if ($m['minutes_status'] === 'sent') { $K['min_sent']++; $dl = (strtotime($m['minutes_sent_at']) - strtotime($m['start_at']) - (int)$m['duration_min'] * 60) / 3600; $delays[] = max(0, $dl); $r['delay_h'] = max(0, $dl); } }
            foreach ($dec[$id] ?? [] as $d) { $K['dec']++; $K['dec_by'][$d['status']] = ($K['dec_by'][$d['status']] ?? 0) + 1; }
            foreach ($act[$id] ?? [] as $a) {
                $K['act']++; $r['act']++; $K['act_by'][$a['status']] = ($K['act_by'][$a['status']] ?? 0) + 1; $K['act_chg'] += (int)$a['due_changes']; $o = &$K['owners'][(int)$a['owner_id']];
                $o ??= ['name' => $a['owner'] ?: '—', 'total' => 0, 'done' => 0, 'late' => 0, 'open' => 0]; $o['total']++;
                if ($a['status'] === 'done') { $K['act_done']++; $r['done']++; $o['done']++; if (substr((string)$a['done_at'], 0, 10) <= $a['due_date']) $K['act_ontime']++; $cl[] = (strtotime($a['done_at']) - strtotime($a['created_at'])) / 86400; $mo2 = substr((string)$a['done_at'], 0, 7); $K['months'][$mo2]['closed'] = ($K['months'][$mo2]['closed'] ?? 0) + 1; }
                elseif (in_array($a['status'], self::OPEN, true)) { $o['open']++; if ($a['due_date'] < $today) { $K['act_overdue']++; $r['late']++; $o['late']++; } }
                unset($o);
            }
            $K['rows'][] = $r;
        }
        ksort($K['months']); $K['avg_dur'] = $durs ? (int)round(array_sum($durs) / count($durs)) : 0; $K['min_delay_h'] = $delays ? round(array_sum($delays) / count($delays), 1) : null; $K['act_days'] = $cl ? round(array_sum($cl) / count($cl), 1) : null;
        uasort($K['owners'], fn($a, $b) => $b['late'] <=> $a['late'] ?: $b['open'] <=> $a['open']); return $K;
    }
    static function pct(int|float $a, int|float $b): ?int { return $b > 0 ? (int)round($a * 100 / $b) : null; }
}
