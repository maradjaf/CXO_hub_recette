<?php
namespace App\Core;
class Settings {
    private static ?array $c = null;
    static function all(): array {
        if (self::$c === null) { self::$c = []; try { foreach (DB::all('SELECT k, v FROM settings') as $r) self::$c[$r['k']] = $r['v']; } catch (\Throwable $e) {} }
        return self::$c;
    }
    static function reset(): void { self::$c = null; }
    static function get(string $k, $d = null) { return self::all()[$k] ?? $d; }
    static function set(string $k, ?string $v): void {
        if (DB::val('SELECT 1 FROM settings WHERE k=?', [$k])) DB::update('settings', ['v' => $v, 'updated_at' => now()], 'k=?', [$k]);
        else DB::insert('settings', ['k' => $k, 'v' => $v, 'updated_at' => now()]);
        self::$c = null;
    }
}
