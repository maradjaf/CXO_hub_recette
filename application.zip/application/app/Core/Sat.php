<?php
namespace App\Core;

/**
 * Enquêtes de satisfaction systématiques : une enquête « à chaud » est toujours rattachée à chaque session de
 * formation ; une enquête e-learning est demandée à chaque fin de cours (réussi ou échec définitif).
 */
final class Sat {
    const EL_QUESTIONS = [['Le contenu du cours correspond à mes besoins.', 'rating'], ['Les explications sont claires et faciles à suivre.', 'rating'], ['Le quiz est cohérent avec le contenu.', 'rating'], ['La durée du cours est adaptée.', 'rating'], ['Je pourrai appliquer ce que j\'ai appris dans mon travail.', 'yesno'], ['Que faudrait-il améliorer dans ce cours ?', 'text']];

    /** Formulaire actif par défaut d'un type ('hot' | 'cold' | 'elearn'), créé au besoin. */
    static function form(string $kind): int {
        $id = (int)DB::val('SELECT id FROM tr_eval_forms WHERE kind=? AND active=1 ORDER BY id LIMIT 1', [$kind]); if ($id) return $id;
        $id = (int)DB::insert('tr_eval_forms', ['kind' => $kind, 'name' => $kind === 'elearn' ? 'Enquête de satisfaction e-learning' : 'Évaluation à chaud : satisfaction', 'active' => 1]);
        $qs = $kind === 'elearn' ? self::EL_QUESTIONS : [['Le contenu de la formation répond à mes attentes.', 'rating'], ['Le formateur maîtrise son sujet et explique clairement.', 'rating'], ['L\'organisation (salle, horaires, supports) est satisfaisante.', 'rating'], ['Je recommanderais cette formation à un collègue.', 'yesno'], ['Vos remarques et suggestions', 'text']];
        foreach ($qs as $i => [$l, $t]) DB::insert('tr_eval_questions', ['form_id' => $id, 'position' => $i + 1, 'label' => $l, 'qtype' => $t, 'required' => $t === 'text' ? 0 : 1]);
        return $id;
    }

    // ───── Sessions de formation ─────
    /** Garantit une enquête à chaud (non annulée) pour la session ; l'ouvre si la date d'envoi est atteinte. */
    static function ensureSession(int $sid): bool {
        $s = DB::one('SELECT * FROM training_sessions WHERE id=?', [$sid]); if (!$s || $s['status'] === 'cancelled') return false;
        if (DB::val("SELECT 1 FROM tr_eval_plans WHERE session_id=? AND kind='hot' AND status<>'cancelled'", [$sid])) return false;
        $last = (string)(DB::val('SELECT MAX(slot_date) FROM training_slots WHERE session_id=?', [$sid]) ?: ($s['end_date'] ?: $s['session_date']));
        DB::insert('tr_eval_plans', ['session_id' => $sid, 'kind' => 'hot', 'form_id' => self::form('hot'), 'send_on' => $last, 'due_on' => date('Y-m-d', strtotime("$last +7 days")), 'status' => 'planned', 'created_by' => Auth::id(), 'created_at' => now()]);
        if ($last <= date('Y-m-d')) Tr::openDue(); return true;
    }

    // ───── Cours e-learning ─────
    /** Demande l'enquête de satisfaction à la fin d'un cours (idempotent). */
    static function requestCourse(int $eid): ?int {
        $e = DB::one('SELECT en.*, c.title FROM el_enrollments en JOIN el_courses c ON c.id=en.course_id WHERE en.id=?', [$eid]); if (!$e) return null;
        if (($id = (int)DB::val('SELECT id FROM el_surveys WHERE enrollment_id=?', [$eid]))) return $id;
        $id = (int)DB::insert('el_surveys', ['enrollment_id' => $eid, 'course_id' => (int)$e['course_id'], 'user_id' => (int)$e['user_id'], 'form_id' => self::form('elearn'), 'status' => 'pending', 'requested_at' => now()]);
        Notifier::send((int)$e['user_id'], 'Votre avis sur le cours « ' . $e['title'] . ' »', 'Une enquête de satisfaction de quelques questions vous attend.', '/learn/' . $eid . '/survey');
        return $id;
    }
    static function pending(int $eid): bool { return (bool)DB::val("SELECT 1 FROM el_surveys WHERE enrollment_id=? AND status='pending'", [$eid]); }
    /** Rattrape les cours terminés sans enquête et relance (une fois) celles restées sans réponse depuis 3 jours. */
    static function sweep(): array {
        $n = 0; $r = 0;
        foreach (DB::all("SELECT en.id FROM el_enrollments en WHERE (en.status='passed' OR en.status='failed') AND NOT EXISTS (SELECT 1 FROM el_surveys s WHERE s.enrollment_id=en.id) LIMIT 200") as $x) { if (self::requestCourse((int)$x['id'])) $n++; }
        foreach (DB::all("SELECT s.id, s.enrollment_id, s.user_id, c.title FROM el_surveys s JOIN el_courses c ON c.id=s.course_id WHERE s.status='pending' AND s.reminded_at IS NULL AND s.requested_at<=?", [date('Y-m-d H:i:s', time() - 3 * 86400)]) as $s) {
            DB::update('el_surveys', ['reminded_at' => now()], 'id=?', [(int)$s['id']]); Notifier::send((int)$s['user_id'], 'Rappel : enquête de satisfaction', 'Votre avis sur « ' . $s['title'] . ' » nous intéresse.', '/learn/' . $s['enrollment_id'] . '/survey'); $r++;
        }
        $s = 0; foreach (DB::all("SELECT id FROM training_sessions WHERE status<>'cancelled' AND session_date<=? ORDER BY id DESC LIMIT 300", [date('Y-m-d')]) as $x) if (self::ensureSession((int)$x['id'])) $s++;
        return ['courses' => $n, 'reminders' => $r, 'sessions' => $s];
    }

    /** Filet sans planificateur : balayage au plus toutes les 10 minutes, après l'envoi de la réponse. */
    static function lazyRun(): void {
        if (PHP_SAPI === 'cli' || Request::method() !== 'GET') return;
        if (time() - (int)strtotime((string)setting('sat.last', '2000-01-01')) < 600) return;
        Settings::set('sat.last', now());
        register_shutdown_function(function () {
            if (function_exists('fastcgi_finish_request')) @fastcgi_finish_request(); $t0 = now();
            try { $o = self::sweep(); $o['taches_relancees'] = Pk::sweep(); $st = 'ok'; $txt = json_encode($o, JSON_UNESCAPED_UNICODE); } catch (\Throwable $e) { $st = 'error'; $txt = 'ERREUR : ' . $e->getMessage(); }
            try {
                $d = ['last_start' => $t0, 'last_end' => now(), 'last_status' => $st, 'last_output' => mb_substr($txt, 0, 500)]; if ($st === 'error') $d['last_error_at'] = $d['last_end'];
                $r = DB::one('SELECT id, runs FROM sys_jobs WHERE name=?', ['sat-surveys']);
                if ($r) DB::update('sys_jobs', $d + ['runs' => (int)$r['runs'] + 1], 'id=?', [(int)$r['id']]); else DB::insert('sys_jobs', $d + ['name' => 'sat-surveys', 'runs' => 1]);
            } catch (\Throwable $e) { /* sans gravité */ }
        });
    }
}
