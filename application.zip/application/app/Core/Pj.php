<?php
namespace App\Core;
/** Gestion de projet (PMO) : droits par rôle et suppléant, avancement, santé, alertes, instantanés de roadmap. */
class Pj {
    const STATUS = ['idea' => 'Idée', 'planned' => 'Planifié', 'active' => 'En cours', 'on_hold' => 'En pause', 'done' => 'Terminé', 'cancelled' => 'Abandonné'];
    const STATUS_COLOR = ['idea' => 'secondary', 'planned' => 'info', 'active' => 'primary', 'on_hold' => 'warning', 'done' => 'success', 'cancelled' => 'dark'];
    const PRIORITY = ['low' => 'Basse', 'normal' => 'Normale', 'high' => 'Haute', 'critical' => 'Critique'];
    const NATURE = ['group' => 'Groupe', 'local' => 'Local (pays)'];
    /** Statut des modèles de reporting : [libellé anglais, libellé français, couleur]. */
    const RSTATUS = ['not_started' => ['Not started', 'Non démarré', '#0B1F4B'], 'ongoing' => ['On going', 'En cours', '#FFC400'], 'risk' => ['Risk', 'À risque', '#E30613'], 'done' => ['Done', 'Terminé', '#00A651']];
    static function rstatus(array $p, string $health): string { return $p['status'] === 'done' ? 'done' : (in_array($p['status'], ['idea', 'planned'], true) ? 'not_started' : ($p['status'] === 'on_hold' || $health === 'red' ? 'risk' : 'ongoing')); }
    /** Points clés et prochaine étape d'un projet : champs de la fiche, sinon dernier point hebdo transmis. */
    static function keyInfo(array $p): array {
        $k = trim((string)($p['key_update'] ?? '')); $n = trim((string)($p['next_step'] ?? ''));
        if ($k === '' || $n === '') { $r = DB::one("SELECT achievements, summary, next_steps FROM pj_reports WHERE project_id=? AND status='submitted' ORDER BY week_start DESC LIMIT 1", [$p['id']]);
            if ($r) { if ($k === '') $k = trim((string)($r['achievements'] ?: $r['summary'])); if ($n === '') $n = trim((string)strtok((string)$r['next_steps'], "\n")); } }
        return [array_values(array_filter(array_map(fn($l) => trim(ltrim(trim($l), "-•*· \t")), preg_split('/\r\n|\n/', $k)), 'strlen')), $n];
    }
    static function monthLabel(?string $d, string $lang = 'fr'): string {
        if (!$d) return '—'; $t = strtotime($d); $m = (int)date('n', $t) - 1;
        return $lang === 'en' ? ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][$m] . ' ' . date('y', $t)
            : ['Janv.', 'Févr.', 'Mars', 'Avr.', 'Mai', 'Juin', 'Juil.', 'Août', 'Sept.', 'Oct.', 'Nov.', 'Déc.'][$m] . ' ' . date('Y', $t);
    }
    const HEALTH = ['green' => 'Vert', 'amber' => 'Orange', 'red' => 'Rouge'];
    const HEALTH_COLOR = ['green' => '#2E8B57', 'amber' => '#d97706', 'red' => '#c0392b'];
    const TYPE = ['blocker' => 'Point bloquant', 'risk' => 'Risque', 'decision' => 'Décision', 'action' => 'Action'];
    const ACCESS = ['manage' => 'Gérer (modifier le projet et les rapports)', 'contribute' => 'Contribuer (jalons, points, rapport)', 'view' => 'Consulter'];
    const RANK = ['view' => 1, 'contribute' => 2, 'manage' => 3];

    static function me(): int { return (int)(Auth::user()['employee_id'] ?? 0); }
    static function project(int $id): ?array { return DB::one('SELECT * FROM pj_projects WHERE id=?', [$id]); }
    static function pillars(bool $all = false): array { return DB::all('SELECT * FROM pj_pillars' . ($all ? '' : ' WHERE active=1') . ' ORDER BY sort_order, name'); }
    static function roles(bool $all = false): array { return DB::all('SELECT * FROM pj_roles' . ($all ? '' : ' WHERE active=1') . ' ORDER BY sort_order, name'); }
    static function ref(): string { $n = (int)DB::val('SELECT COUNT(*) FROM pj_projects') + 1; while (DB::val('SELECT 1 FROM pj_projects WHERE ref=?', [sprintf('PRJ-%03d', $n)])) $n++; return sprintf('PRJ-%03d', $n); }
    static function empName(?int $id): string { if (!$id) return '—'; $e = DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [$id]); return $e ? $e['first_name'] . ' ' . $e['last_name'] : '—'; }
    static function userOf(?int $emp): ?int { if (!$emp) return null; $u = DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [$emp]); return $u ? (int)$u : null; }
    static function onLeave(int $emp, ?string $day = null): bool { $day = $day ?: date('Y-m-d'); return (bool)(DB::val("SELECT 1 FROM leave_requests WHERE employee_id=? AND status='approved' AND start_date<=? AND end_date>=?", [$emp, $day, $day]) ?: DB::val('SELECT 1 FROM absences WHERE employee_id=? AND start_date<=? AND end_date>=?', [$emp, $day, $day])); }

    /** Niveau d'accès de l'utilisateur courant : manage | contribute | view | null. Le suppléant a les droits du titulaire. */
    static function level(array $p): ?string {
        if (Auth::can('pj.manage')) return 'manage'; $best = null; $me = self::me();
        if ($me) foreach (DB::all('SELECT r.access FROM pj_members m JOIN pj_roles r ON r.id=m.role_id WHERE m.project_id=? AND (m.employee_id=? OR m.deputy_id=?)', [$p['id'], $me, $me]) as $r) if (($best === null) || self::RANK[$r['access']] > self::RANK[$best]) $best = $r['access'];
        if ($best) return $best; return $p['visibility'] === 'all' && Auth::can('pj.view') ? 'view' : null;
    }
    static function can(array $p, string $need): bool { $l = self::level($p); return $l !== null && self::RANK[$l] >= self::RANK[$need]; }
    /** Projets visibles par l'utilisateur courant. */
    static function visible(array $f = []): array {
        $w = []; $a = []; foreach (['pillar_id', 'status', 'nature'] as $k) if (!empty($f[$k])) { $w[] = "$k=?"; $a[] = $f[$k]; }
        $out = []; foreach (DB::all('SELECT * FROM pj_projects' . ($w ? ' WHERE ' . implode(' AND ', $w) : '') . ' ORDER BY pillar_id, start_date, id', $a) as $p) if (self::level($p)) $out[] = $p; return $out;
    }

    // ---- Avancement et santé ----
    static function progress(array $p): int {
        if ($p['status'] === 'done') return 100; if ($p['progress_mode'] === 'manual') return max(0, min(100, (int)$p['progress_pct']));
        $r = DB::one("SELECT COALESCE(SUM(weight),0) t, COALESCE(SUM(CASE WHEN status='done' THEN weight ELSE 0 END),0) d FROM pj_milestones WHERE project_id=?", [$p['id']]);
        return $r['t'] > 0 ? (int)round(100 * $r['d'] / $r['t']) : max(0, min(100, (int)$p['progress_pct']));
    }
    /** Part du temps écoulé entre début et fin (0-100) ; null si dates absentes. */
    static function timeProgress(array $p): ?int { if (!$p['start_date'] || !$p['end_date'] || $p['end_date'] <= $p['start_date']) return null; $a = strtotime($p['start_date']); $b = strtotime($p['end_date']); return (int)max(0, min(100, round(100 * (time() - $a) / ($b - $a)))); }
    static function slip(array $p): ?int { return $p['baseline_end'] && $p['end_date'] ? (int)round((strtotime($p['end_date']) - strtotime($p['baseline_end'])) / 86400) : null; }
    static function lateMilestones(int $pid): array { return DB::all("SELECT * FROM pj_milestones WHERE project_id=? AND status<>'done' AND due_date<? ORDER BY due_date", [$pid, date('Y-m-d')]); }
    static function openItems(int $pid, ?string $type = null): array { return DB::all("SELECT * FROM pj_items WHERE project_id=? AND status='open'" . ($type ? ' AND type=?' : '') . ' ORDER BY created_at', $type ? [$pid, $type] : [$pid]); }

    /** Alertes calculées d'un projet : [niveau (bad|warn), code, texte]. */
    static function alerts(array $p): array {
        $a = []; if (!in_array($p['status'], ['active', 'planned', 'on_hold'], true)) return $a; $today = date('Y-m-d'); $bd = (int)setting('pj.blocker_days', 7); $drift = (int)setting('pj.drift_pts', 20); $red = (int)setting('pj.late_red_days', 14);
        foreach (self::lateMilestones($p['id']) as $m) { $d = (int)floor((strtotime($today) - strtotime($m['due_date'])) / 86400); $a[] = [$d >= $red ? 'bad' : 'warn', 'milestone_late', 'Jalon « ' . $m['title'] . ' » en retard de ' . $d . ' j']; }
        if ($p['status'] === 'active' && $p['end_date'] && $p['end_date'] < $today) $a[] = ['bad', 'end_passed', 'Date de fin dépassée (' . date('d/m/Y', strtotime($p['end_date'])) . ')'];
        foreach (self::openItems($p['id'], 'blocker') as $b) { $d = (int)floor((time() - strtotime($b['created_at'])) / 86400); if ($d >= $bd || $b['severity'] === 'high') $a[] = [$b['severity'] === 'high' && $d >= $bd ? 'bad' : 'warn', 'blocker', 'Point bloquant « ' . $b['title'] . ' » ouvert depuis ' . $d . ' j' . ($b['solution'] ? '' : ' sans solution')]; }
        foreach (self::openItems($p['id'], 'decision') as $b) if ($b['due_date'] && $b['due_date'] < $today) $a[] = ['warn', 'decision_due', 'Décision « ' . $b['title'] . ' » attendue depuis le ' . date('d/m', strtotime($b['due_date']))];
        if ($p['status'] === 'active') {
            $tp = self::timeProgress($p); $pg = self::progress($p); if ($tp !== null && $tp - $pg >= $drift) $a[] = [$tp - $pg >= 2 * $drift ? 'bad' : 'warn', 'drift', "Avancement ($pg %) en retard sur le temps écoulé ($tp %)"];
            if (self::reportMissing($p)) $a[] = ['warn', 'report_missing', 'Point hebdomadaire de la semaine non transmis'];
            if ($p['health'] === 'red') $a[] = ['bad', 'health_red', 'Santé déclarée au rouge'];
        }
        foreach (DB::all('SELECT d.depends_on_id, q.title, q.end_date, q.status FROM pj_deps d JOIN pj_projects q ON q.id=d.depends_on_id WHERE d.project_id=?', [$p['id']]) as $d) if ($d['status'] !== 'done' && $d['end_date'] && $p['start_date'] && $d['end_date'] > $p['start_date']) $a[] = ['warn', 'dependency', 'Dépend de « ' . $d['title'] . ' » qui se termine après son démarrage'];
        return $a;
    }
    /** Point hebdomadaire manquant : projet en cours, échéance de la semaine passée, aucun rapport transmis. */
    static function reportMissing(array $p): bool {
        if ($p['status'] !== 'active') return false; if ((int)date('N') < (int)setting('pj.report_due_dow', 4)) return false;
        return !DB::val("SELECT 1 FROM pj_reports WHERE project_id=? AND week_start=? AND status='submitted'", [$p['id'], Pl::monday(date('Y-m-d'))]);
    }
    /** Santé calculée à partir des alertes (rouge si une alerte grave, orange sinon). */
    static function computedHealth(array $p): string { $al = self::alerts($p); foreach ($al as $x) if ($x[0] === 'bad') return 'red'; return $al ? 'amber' : 'green'; }

    // ---- Notifications avec suppléance ----
    /** Utilisateurs à prévenir : membres de niveau suffisant ; le suppléant remplace le titulaire en congé ou absent. */
    static function recipients(array $p, string $need = 'contribute'): array {
        $ids = [];
        foreach (DB::all('SELECT m.employee_id, m.deputy_id, r.access FROM pj_members m JOIN pj_roles r ON r.id=m.role_id WHERE m.project_id=?', [$p['id']]) as $m) {
            if (self::RANK[$m['access']] < self::RANK[$need]) continue; $e = (int)$m['employee_id'];
            if ($m['deputy_id'] && self::onLeave($e)) { $u = self::userOf((int)$m['deputy_id']) ?: self::userOf($e); } else $u = self::userOf($e); if ($u) $ids[$u] = true;
        }
        return array_keys($ids);
    }
    static function notify(array $p, string $title, string $body, string $need = 'manage', string $url = ''): int { $n = 0; foreach (self::recipients($p, $need) as $u) { Notifier::send($u, $title, $body, $url ?: '/pj/projects/' . $p['id']); $n++; } return $n; }
    /** Alerte une seule fois par clé (évite les relances quotidiennes). */
    static function once(string $key): bool { if (DB::val('SELECT 1 FROM pj_alert_log WHERE akey=?', [$key])) return false; DB::insert('pj_alert_log', ['akey' => mb_substr($key, 0, 120), 'created_at' => now()]); return true; }

    // ---- Charge ----
    /** Allocation cumulée par collaborateur sur les projets actifs ou planifiés. */
    static function load(): array {
        $o = []; foreach (DB::all("SELECT m.employee_id, m.allocation_pct, p.ref FROM pj_members m JOIN pj_projects p ON p.id=m.project_id WHERE p.status IN ('active','planned') AND m.allocation_pct>0") as $r) { $e = (int)$r['employee_id']; $o[$e]['emp'] = $e; $o[$e]['total'] = ($o[$e]['total'] ?? 0) + (int)$r['allocation_pct']; $o[$e]['projects'][] = $r['ref'] . ' ' . $r['allocation_pct'] . ' %'; }
        uasort($o, fn($a, $b) => $b['total'] <=> $a['total']); return $o;
    }

    // ---- Rapport hebdomadaire ----
    static function report(int $pid, string $week): ?array { return DB::one('SELECT * FROM pj_reports WHERE project_id=? AND week_start=?', [$pid, $week]); }
    /** Pré-remplit (ou retrouve) le brouillon de la semaine : avancement, santé, réalisations et prochaines étapes tirés des jalons. */
    static function draft(array $p, string $week): array {
        if ($r = self::report($p['id'], $week)) return $r;
        $done = DB::all("SELECT title FROM pj_milestones WHERE project_id=? AND status='done' AND done_at>=?", [$p['id'], date('Y-m-d', strtotime($week . ' -7 days'))]);
        $next = DB::all("SELECT title, due_date FROM pj_milestones WHERE project_id=? AND status<>'done' AND due_date<=? ORDER BY due_date LIMIT 6", [$p['id'], date('Y-m-d', strtotime($week . ' +21 days'))]);
        $id = DB::insert('pj_reports', ['project_id' => $p['id'], 'week_start' => $week, 'health' => self::computedHealth($p), 'progress_pct' => self::progress($p), 'summary' => null,
            'achievements' => $done ? implode("\n", array_map(fn($m) => '• ' . $m['title'], $done)) : null, 'next_steps' => $next ? implode("\n", array_map(fn($m) => '• ' . $m['title'] . ' (' . date('d/m', strtotime($m['due_date'])) . ')', $next)) : null, 'status' => 'draft', 'created_at' => now(), 'updated_at' => now()]);
        return DB::one('SELECT * FROM pj_reports WHERE id=?', [$id]);
    }
    /** Fige l'état des points ouverts au moment de la transmission. */
    static function freeze(array $p): string {
        $it = array_map(fn($i) => ['type' => $i['type'], 'title' => $i['title'], 'severity' => $i['severity'], 'solution' => $i['solution'], 'due' => $i['due_date']], self::openItems($p['id']));
        return json_encode(['items' => $it, 'alerts' => array_map(fn($a) => $a[2], self::alerts($p)), 'computed_health' => self::computedHealth($p)], JSON_UNESCAPED_UNICODE);
    }

    // ---- Instantanés de roadmap ----
    static function snapshotData(): array {
        $pn = array_column(DB::all('SELECT id, name FROM pj_pillars'), 'name', 'id'); $o = [];
        foreach (DB::all('SELECT * FROM pj_projects ORDER BY id') as $p) $o[] = ['id' => (int)$p['id'], 'ref' => $p['ref'], 'title' => $p['title'], 'pillar' => $pn[$p['pillar_id']] ?? '—', 'status' => $p['status'], 'health' => self::computedHealth($p), 'progress' => self::progress($p), 'start' => $p['start_date'], 'end' => $p['end_date']];
        return $o;
    }
    static function snapshot(string $label, string $kind, ?int $by = null): int { return DB::insert('pj_snapshots', ['label' => $label, 'kind' => $kind, 'data' => json_encode(self::snapshotData(), JSON_UNESCAPED_UNICODE), 'created_by' => $by, 'created_at' => now()]); }
    /** Écarts entre deux listes de projets. @return string[] */
    static function diff(array $old, array $new): array {
        $o = array_column($old, null, 'id'); $n = array_column($new, null, 'id'); $out = [];
        foreach ($n as $id => $x) {
            $l = $x['ref'] . ' ' . $x['title']; if (!isset($o[$id])) { $out[] = "Nouveau : $l"; continue; } $y = $o[$id];
            if ($x['status'] !== $y['status']) $out[] = "$l : statut « " . (self::STATUS[$y['status']] ?? $y['status']) . ' » → « ' . (self::STATUS[$x['status']] ?? $x['status']) . ' »';
            if (($x['end'] ?? null) !== ($y['end'] ?? null) && $x['end'] && $y['end']) { $d = (int)round((strtotime($x['end']) - strtotime($y['end'])) / 86400); $out[] = "$l : fin " . ($d > 0 ? "repoussée de $d j" : 'avancée de ' . abs($d) . ' j') . ' (' . date('d/m/Y', strtotime($x['end'])) . ')'; }
            if (($x['health'] ?? '') !== ($y['health'] ?? '')) $out[] = "$l : santé " . (self::HEALTH[$y['health']] ?? '?') . ' → ' . (self::HEALTH[$x['health']] ?? '?');
            if (abs($x['progress'] - $y['progress']) >= 10) $out[] = "$l : avancement {$y['progress']} % → {$x['progress']} %";
        }
        foreach ($o as $id => $y) if (!isset($n[$id])) $out[] = 'Supprimé : ' . $y['ref'] . ' ' . $y['title'];
        return $out;
    }
}
