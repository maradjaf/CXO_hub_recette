<?php
namespace App\Core;

/** Performance 360° : cycles d'évaluation, évaluateurs, agrégation anonymisée. */
class Perf {
    const ROLE = ['self' => 'Auto-évaluation', 'manager' => 'Responsable', 'peer' => 'Pair', 'report' => 'Collaborateur (évalue son responsable)'];
    const STATUS = ['draft' => 'Brouillon', 'open' => 'En cours', 'closed' => 'Clôturé'];
    const COLOR = ['draft' => 'secondary', 'open' => 'primary', 'closed' => 'success'];
    const SCALE = [1 => 'À développer', 2 => 'Partiellement atteint', 3 => 'Conforme', 4 => 'Supérieur', 5 => 'Exemplaire'];
    const ACT = ['todo' => 'À faire', 'doing' => 'En cours', 'done' => 'Fait'];

    static function myEmp(): int { return (int)(Auth::user()['employee_id'] ?? 0); }

    /** Crée les évaluations d'un cycle (idempotent) : auto-évaluation, responsable, pairs (même équipe et même responsable) et collaborateurs directs. Retourne le nombre créé. */
    static function generate(int $cycleId): int {
        $c = DB::one('SELECT * FROM perf_cycles WHERE id=?', [$cycleId]); if (!$c) return 0;
        $w = ["status='active'"]; $p = []; if ((int)$c['team_id']) { $w[] = 'team_id=?'; $p[] = (int)$c['team_id']; }
        $emps = DB::all('SELECT id, team_id, manager_id FROM employees WHERE ' . implode(' AND ', $w) . ' ORDER BY id', $p); $n = 0;
        $add = function (int $emp, int $rater, string $role) use ($cycleId, &$n) {
            if (DB::val('SELECT 1 FROM perf_reviews WHERE cycle_id=? AND employee_id=? AND rater_id=? AND role=?', [$cycleId, $emp, $rater, $role])) return;
            DB::insert('perf_reviews', ['cycle_id' => $cycleId, 'employee_id' => $emp, 'rater_id' => $rater, 'role' => $role, 'status' => 'pending', 'created_at' => now()]); $n++;
        };
        $max = max(0, min(10, (int)$c['peers_max']));
        foreach ($emps as $e) {
            $id = (int)$e['id']; $add($id, $id, 'self'); $m = (int)$e['manager_id'];
            if ($m && $m !== $id && DB::val("SELECT 1 FROM employees WHERE id=? AND status='active'", [$m])) { $add($id, $m, 'manager'); $add($m, $id, 'report'); }
            if ($max && $m) foreach (DB::all("SELECT id FROM employees WHERE status='active' AND manager_id=? AND id<>? ORDER BY id LIMIT $max", [$m, $id]) as $q) $add($id, (int)$q['id'], 'peer');
        }
        return $n;
    }

    /** Résultats d'un collaborateur sur un cycle, avec anonymat : pairs et collaborateurs ne sont montrés qu'à partir de min_raters réponses. */
    static function aggregate(int $cycleId, int $empId): array {
        $c = DB::one('SELECT min_raters FROM perf_cycles WHERE id=?', [$cycleId]); $min = max(1, (int)($c['min_raters'] ?? 3));
        $comps = DB::all('SELECT id, name, description FROM perf_competencies WHERE id IN (SELECT a.competency_id FROM perf_answers a JOIN perf_reviews r ON r.id=a.review_id WHERE r.cycle_id=? AND r.employee_id=?) ORDER BY sort_order, name', [$cycleId, $empId]);
        $rows = DB::all("SELECT a.competency_id, r.role, AVG(a.score) avg, COUNT(DISTINCT r.id) n FROM perf_answers a JOIN perf_reviews r ON r.id=a.review_id WHERE r.cycle_id=? AND r.employee_id=? AND r.status='done' GROUP BY a.competency_id, r.role", [$cycleId, $empId]);
        $by = []; foreach ($rows as $r) $by[(int)$r['competency_id']][$r['role']] = ['avg' => round((float)$r['avg'], 2), 'n' => (int)$r['n']];
        $cnt = []; foreach (DB::all("SELECT role, COUNT(*) n FROM perf_reviews WHERE cycle_id=? AND employee_id=? AND status='done' GROUP BY role", [$cycleId, $empId]) as $r) $cnt[$r['role']] = (int)$r['n'];
        $out = []; $sum = ['self' => [], 'others' => []];
        foreach ($comps as $k) {
            $line = ['id' => (int)$k['id'], 'name' => $k['name'], 'description' => $k['description']]; $vis = [];
            foreach (['self', 'manager', 'peer', 'report'] as $role) {
                $v = $by[$k['id']][$role] ?? null; $hidden = $v && in_array($role, ['peer', 'report'], true) && $v['n'] < $min;
                $line[$role] = $v ? ($hidden ? ['avg' => null, 'n' => $v['n'], 'hidden' => true] : $v + ['hidden' => false]) : null;
                if ($v && !$hidden) { if ($role === 'self') $sum['self'][] = $v['avg']; else { $vis[] = $v['avg']; } }
            }
            $line['others'] = $vis ? round(array_sum($vis) / count($vis), 2) : null; if ($line['others'] !== null) $sum['others'][] = $line['others'];
            $line['gap'] = ($line['self'] && $line['others'] !== null) ? round($line['self']['avg'] - $line['others'], 2) : null; $out[] = $line;
        }
        $avg = fn($a) => $a ? round(array_sum($a) / count($a), 2) : null;
        $comments = [];
        foreach (DB::all("SELECT role, comment FROM perf_reviews WHERE cycle_id=? AND employee_id=? AND status='done' AND comment IS NOT NULL AND comment<>'' ORDER BY id", [$cycleId, $empId]) as $r) {
            if (in_array($r['role'], ['peer', 'report'], true) && ($cnt[$r['role']] ?? 0) < $min) continue; $comments[$r['role']][] = $r['comment'];
        }
        $ranked = array_values(array_filter($out, fn($l) => $l['others'] !== null)); usort($ranked, fn($a, $b) => $b['others'] <=> $a['others']);
        return ['comps' => $out, 'self' => $avg($sum['self']), 'others' => $avg($sum['others']), 'count' => $cnt, 'min' => $min, 'comments' => $comments,
            'strengths' => array_slice($ranked, 0, 3), 'devs' => array_slice(array_reverse($ranked), 0, 3)];
    }

    /** Avancement d'un cycle par rôle. */
    static function progress(int $cycleId): array {
        $o = []; foreach (DB::all("SELECT role, COUNT(*) total, SUM(status='done') done FROM perf_reviews WHERE cycle_id=? GROUP BY role", [$cycleId]) as $r) $o[$r['role']] = ['total' => (int)$r['total'], 'done' => (int)$r['done']]; return $o;
    }

    /** Droit de consulter le rapport d'un collaborateur. */
    static function canView(array $cycle, int $emp): bool {
        if (!Auth::can('perf.use') && !Auth::can('perf.manage')) return false;
        if (Auth::can('perf.manage')) return Scope::allows($emp);
        if ($cycle['status'] !== 'closed') return false;
        $me = self::myEmp(); return ($me && $emp === $me) || ($emp !== $me && Scope::allows($emp));
    }
}
