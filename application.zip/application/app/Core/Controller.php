<?php
namespace App\Core;
abstract class Controller {
    protected function view(string $v, array $d = [], string $layout = 'layout/main'): void { View::render($v, $d, $layout); }
    protected function forbidden(): void { http_response_code(403); View::render('errors/403', ['title' => 'Accès refusé']); }
    protected function notFound(): void { http_response_code(404); View::render('errors/404', ['title' => 'Introuvable']); }
    protected function in(string $k, $d = null) { return Request::in($k, $d); }
    protected function page(): int { return max(1, (int)($_GET['page'] ?? 1)); }
    /** Valide un tableau de règles ['champ' => ['label'=>..., 'req'=>true, 'max'=>n, 'email'=>true, 'date'=>true]] */
    protected function validate(array $rules, array $src): array {
        $data = []; $err = [];
        foreach ($rules as $f => $r) {
            $v = isset($src[$f]) ? trim((string)$src[$f]) : '';
            if (!empty($r['req']) && $v === '') $err[$f] = $r['label'] . ' est obligatoire.';
            elseif ($v !== '' && !empty($r['email']) && !filter_var($v, FILTER_VALIDATE_EMAIL)) $err[$f] = $r['label'] . ' n\'est pas une adresse valide.';
            elseif ($v !== '' && !empty($r['date']) && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $v)) $err[$f] = $r['label'] . ' doit être une date (AAAA-MM-JJ).';
            elseif ($v !== '' && !empty($r['max']) && mb_strlen($v) > $r['max']) $err[$f] = $r['label'] . ' est trop long.';
            $data[$f] = $v === '' ? null : $v;
        }
        if ($err) $_SESSION['_ferr'] = $err + ($_SESSION['_ferr'] ?? []);   // repris par la mise en page pour colorer les champs en erreur
        return [$data, $err];
    }
    protected function back(array $err, array $old, string $to): never {
        $_SESSION['_old'] = $old; $_SESSION['_err'] = $err; $_SESSION['_ferr'] = $err; redirect($to);
    }
}
