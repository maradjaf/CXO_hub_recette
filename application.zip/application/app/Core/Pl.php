<?php
namespace App\Core;
/** Planification (shifts, plannings, besoins, échanges) et performance (indicateurs, prévisions, Erlang C). */
class Pl {
    const DOW = [1 => 'Lun', 2 => 'Mar', 3 => 'Mer', 4 => 'Jeu', 5 => 'Ven', 6 => 'Sam', 7 => 'Dim'];
    const SW = ['pending_partner' => 'Attend le collègue', 'pending_manager' => 'Attend le responsable', 'approved' => 'Validé', 'refused' => 'Refusé', 'cancelled' => 'Annulé'];
    const SW_COLOR = ['pending_partner' => 'warning', 'pending_manager' => 'info', 'approved' => 'success', 'refused' => 'danger', 'cancelled' => 'secondary'];
    const KPI = ['sl' => ['Taux de service', '%', true], 'ab' => ['Taux d\'abandon', '%', false], 'aht' => ['Durée moyenne de traitement', 's', false], 'wait' => ['Attente moyenne', 's', false]];

    static function monday(string $d): string { $t = strtotime($d) ?: time(); return date('Y-m-d', strtotime('-' . ((int)date('N', $t) - 1) . ' days', $t)); }
    static function addDays(string $d, int $n): string { return date('Y-m-d', strtotime("$d $n days")); }
    static function validDate(string $d): bool { return (bool)preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) && checkdate((int)substr($d, 5, 2), (int)substr($d, 8, 2), (int)substr($d, 0, 4)); }

    // ---- Unités : équipes (centre d'appels, digital, fonctions support) et boutiques ----
    /** @return array<string,array{key:string,type:string,id:int,name:string,code:string,channel:string}> */
    static function units(): array {
        $o = [];
        foreach (DB::all("SELECT t.id, t.code, t.name, COALESCE(c.code,'') ch FROM teams t LEFT JOIN channels c ON c.id=t.channel_id WHERE t.active=1 ORDER BY t.name") as $t) $o['team:' . $t['id']] = ['key' => 'team:' . $t['id'], 'type' => 'team', 'id' => (int)$t['id'], 'name' => $t['name'], 'code' => $t['code'], 'channel' => $t['ch']];
        foreach (DB::all("SELECT id, code, name FROM stores WHERE active=1 ORDER BY name") as $t) $o['store:' . $t['id']] = ['key' => 'store:' . $t['id'], 'type' => 'store', 'id' => (int)$t['id'], 'name' => $t['name'], 'code' => $t['code'], 'channel' => 'STORE'];
        return $o;
    }
    static function unit(string $key): ?array { return self::units()[$key] ?? null; }
    static function queueUnit(array $u): bool { return in_array($u['channel'], ['CALLCENTER', 'DIGITAL'], true); }
    /** Collaborateurs actifs de l'unité, dans le périmètre de l'utilisateur. */
    static function employees(array $u): array {
        [$w, $p] = Scope::sql('id'); $col = $u['type'] === 'team' ? 'team_id' : 'store_id';
        return DB::all("SELECT id, first_name, last_name, matricule, manager_id FROM employees WHERE status<>'left' AND $col=? AND $w ORDER BY last_name, first_name", array_merge([$u['id']], $p));
    }
    static function myEmployee(): int { return (int)(Auth::user()['employee_id'] ?? 0); }

    // ---- Shifts ----
    static function shifts(bool $active = true): array { $o = []; foreach (DB::all('SELECT * FROM pl_shifts' . ($active ? ' WHERE active=1' : '') . " ORDER BY kind DESC, start_time, name") as $s) $o[(int)$s['id']] = $s; return $o; }
    static function isWork(?array $s): bool { return $s && $s['kind'] === 'work' && $s['start_time'] && $s['end_time']; }
    private static function tm(string $t): int { [$h, $m] = array_map('intval', explode(':', $t)); return $h * 60 + $m; }
    /** Minutes travaillées (pause déduite). */
    static function minutes(array $s): int { if (!self::isWork($s)) return 0; $d = self::tm($s['end_time']) - self::tm($s['start_time']); if ($d <= 0) $d += 1440; return max(0, $d - (int)$s['break_min']); }
    static function startTs(string $day, array $s): int { return strtotime($day . ' ' . $s['start_time']); }
    static function endTs(string $day, array $s): int { $e = strtotime($day . ' ' . $s['end_time']); return $e <= self::startTs($day, $s) ? $e + 86400 : $e; }
    static function label(array $s): string { return $s['name'] . (self::isWork($s) ? ' ' . $s['start_time'] . '–' . $s['end_time'] : ''); }

    // ---- Affectations ----
    static function assignment(int $emp, string $day): ?array { return DB::one('SELECT * FROM pl_assignments WHERE employee_id=? AND day=?', [$emp, $day]); }
    static function published(string $type, int $uid, string $week): bool { return (bool)DB::val('SELECT 1 FROM pl_weeks WHERE unit_type=? AND unit_id=? AND week_start=? AND published_at IS NOT NULL', [$type, $uid, $week]); }
    /** @return array{0:string[],1:string[]} [erreurs bloquantes, avertissements] pour affecter $shift à $emp le $day */
    static function conflicts(int $emp, string $day, ?array $shift): array {
        $err = []; $warn = []; if (!self::isWork($shift)) return [$err, $warn];
        if (DB::val("SELECT 1 FROM leave_requests WHERE employee_id=? AND status='approved' AND start_date<=? AND end_date>=?", [$emp, $day, $day])) $err[] = 'en congé validé';
        if (DB::val('SELECT 1 FROM absences WHERE employee_id=? AND start_date<=? AND end_date>=?', [$emp, $day, $day])) $err[] = 'absence enregistrée';
        $rest = max(0, (int)setting('pl.min_rest_hours', 11)) * 3600; $shifts = self::shifts(false);
        foreach ([-1, 1] as $dir) {
            $o = self::assignment($emp, self::addDays($day, $dir)); $os = $o ? ($shifts[(int)$o['shift_id']] ?? null) : null; if (!self::isWork($os)) continue;
            $gap = $dir < 0 ? self::startTs($day, $shift) - self::endTs(self::addDays($day, -1), $os) : self::startTs(self::addDays($day, 1), $os) - self::endTs($day, $shift);
            if ($gap < $rest) $err[] = 'repos de ' . $rest / 3600 . ' h non respecté (' . ($dir < 0 ? 'veille' : 'lendemain') . ')';
        }
        $mon = self::monday($day); $min = self::minutes($shift); $run = 0;
        foreach (DB::all('SELECT day, shift_id FROM pl_assignments WHERE employee_id=? AND day>=? AND day<=?', [$emp, $mon, self::addDays($mon, 6)]) as $a) if ($a['day'] !== $day && self::isWork($shifts[(int)$a['shift_id']] ?? null)) $min += self::minutes($shifts[(int)$a['shift_id']]);
        $max = (int)setting('pl.max_week_hours', 48); if ($min > $max * 60) $warn[] = 'plus de ' . $max . ' h dans la semaine (' . round($min / 60, 1) . ' h)';
        for ($d = -6; $d <= 6; $d++) { if ($d === 0) { $run++; continue; } $a = self::assignment($emp, self::addDays($day, $d)); if ($a && self::isWork($shifts[(int)$a['shift_id']] ?? null)) $run++; else if ($d < 0) $run = 0; else break; }
        if ($run >= 7) $warn[] = '7 jours travaillés consécutifs';
        return [$err, $warn];
    }
    /** Pose (ou retire si $shiftId null) une affectation ; prévient le collaborateur si le planning est déjà publié. */
    static function assign(int $emp, string $day, ?int $shiftId, array $u, string $note = ''): bool {
        $cur = self::assignment($emp, $day); if (($cur ? (int)$cur['shift_id'] : null) === $shiftId) return false;
        $pub = self::published($u['type'], $u['id'], self::monday($day));
        if ($shiftId === null) { if ($cur) DB::exec('DELETE FROM pl_assignments WHERE id=?', [(int)$cur['id']]); }
        elseif ($cur) DB::update('pl_assignments', ['shift_id' => $shiftId, 'unit_type' => $u['type'], 'unit_id' => $u['id'], 'status' => $pub ? 'published' : 'draft', 'note' => $note ?: null, 'updated_by' => Auth::id(), 'updated_at' => now()], 'id=?', [(int)$cur['id']]);
        else DB::insert('pl_assignments', ['employee_id' => $emp, 'day' => $day, 'shift_id' => $shiftId, 'unit_type' => $u['type'], 'unit_id' => $u['id'], 'status' => $pub ? 'published' : 'draft', 'note' => $note ?: null, 'updated_by' => Auth::id(), 'updated_at' => now()]);
        if ($pub && $day >= date('Y-m-d')) { $uid = DB::val('SELECT id FROM users WHERE employee_id=? AND status=?', [$emp, 'active']); if ($uid) { $s = $shiftId ? (self::shifts(false)[$shiftId] ?? null) : null; Notifier::send((int)$uid, 'Votre planning a changé', date('d/m/Y', strtotime($day)) . ' : ' . ($s ? self::label($s) : 'plus de shift'), '/pl/mine'); } }
        return true;
    }
    static function publish(array $u, string $week): int {
        $w = DB::one('SELECT id FROM pl_weeks WHERE unit_type=? AND unit_id=? AND week_start=?', [$u['type'], $u['id'], $week]);
        if ($w) DB::update('pl_weeks', ['published_at' => now(), 'published_by' => Auth::id()], 'id=?', [(int)$w['id']]); else DB::insert('pl_weeks', ['unit_type' => $u['type'], 'unit_id' => $u['id'], 'week_start' => $week, 'published_at' => now(), 'published_by' => Auth::id()]);
        $ids = array_column(DB::all("SELECT DISTINCT employee_id FROM pl_assignments WHERE unit_type=? AND unit_id=? AND day>=? AND day<=? AND status='draft'", [$u['type'], $u['id'], $week, self::addDays($week, 6)]), 'employee_id');
        DB::exec("UPDATE pl_assignments SET status='published', updated_at=? WHERE unit_type=? AND unit_id=? AND day>=? AND day<=? AND status='draft'", [now(), $u['type'], $u['id'], $week, self::addDays($week, 6)]);
        foreach ($ids as $e) { $uid = DB::val('SELECT id FROM users WHERE employee_id=? AND status=?', [(int)$e, 'active']); if ($uid) Notifier::send((int)$uid, 'Planning publié', 'Semaine du ' . date('d/m/Y', strtotime($week)), '/pl/mine?week=' . $week); }
        return count($ids);
    }

    // ---- Besoins et couverture ----
    /** @return array<int,array<int,int>> [jour 1-7][shift_id] = effectif requis */
    static function needs(array $u): array { $o = []; foreach (DB::all('SELECT weekday, shift_id, required FROM pl_needs WHERE unit_type=? AND unit_id=?', [$u['type'], $u['id']]) as $n) $o[(int)$n['weekday']][(int)$n['shift_id']] = (int)$n['required']; return $o; }
    /** @return array<string,array<int,int>> [date][shift_id] = effectif planifié */
    static function planned(array $u, string $from, string $to): array { $o = []; foreach (DB::all('SELECT day, shift_id, COUNT(*) n FROM pl_assignments WHERE unit_type=? AND unit_id=? AND day>=? AND day<=? AND shift_id IS NOT NULL GROUP BY day, shift_id', [$u['type'], $u['id'], $from, $to]) as $r) $o[$r['day']][(int)$r['shift_id']] = (int)$r['n']; return $o; }
    /** Effectif présent heure par heure (pauses ignorées). @return int[] 24 valeurs */
    static function hourly(array $u, string $day): array {
        $h = array_fill(0, 24, 0); $sh = self::shifts(false);
        foreach (DB::all('SELECT shift_id FROM pl_assignments WHERE unit_type=? AND unit_id=? AND day=? AND shift_id IS NOT NULL', [$u['type'], $u['id'], $day]) as $a) { $s = $sh[(int)$a['shift_id']] ?? null; if (!self::isWork($s)) continue; $st = self::startTs($day, $s); $en = self::endTs($day, $s);
            for ($i = 0; $i < 24; $i++) { $t = strtotime($day) + $i * 3600; if ($t + 3600 > $st && $t < $en) $h[$i]++; } }
        return $h;
    }

    // ---- Indicateurs ----
    /** @param array[] $rows lignes pl_stats */
    static function kpi(array $rows): array {
        $o = $h = $s = $a = 0; $aht = $wait = 0.0;
        foreach ($rows as $r) { $o += (int)$r['offered']; $h += (int)$r['handled']; $s += (int)$r['in_sla']; $a += (int)$r['abandoned']; $aht += (float)$r['aht_sec'] * (int)$r['handled']; $wait += (float)$r['wait_sec'] * (int)$r['handled']; }
        return ['offered' => $o, 'handled' => $h, 'answer' => $o ? 100 * $h / $o : null, 'sl' => $o ? 100 * $s / $o : null, 'ab' => $o ? 100 * $a / $o : null, 'aht' => $h ? $aht / $h : null, 'wait' => $h ? $wait / $h : null];
    }
    static function targets(array $u): array {
        $t = ['sl' => (float)setting('pl.t_sl', '80'), 'ab' => (float)setting('pl.t_ab', '5'), 'aht' => (float)setting('pl.t_aht', '300'), 'wait' => (float)setting('pl.t_wait', '30')];
        foreach (DB::all('SELECT kpi, value FROM pl_targets WHERE unit_type=? AND unit_id=?', [$u['type'], $u['id']]) as $r) if (isset($t[$r['kpi']])) $t[$r['kpi']] = (float)$r['value'];
        return $t;
    }
    /** ok | warn | bad | none */
    static function status(string $k, ?float $v, float $target): string {
        if ($v === null) return 'none'; $higher = self::KPI[$k][2]; $good = $higher ? $v >= $target : $v <= $target; if ($good) return 'ok';
        $gap = $higher ? ($target - $v) / max(1e-9, $target) : ($v - $target) / max(1e-9, $target); return $gap <= 0.1 ? 'warn' : 'bad';
    }

    // ---- Erlang C et prévisions ----
    static function erlangC(float $a, int $n): float { if ($n <= $a) return 1.0; $b = 1.0; for ($i = 1; $i <= $n; $i++) $b = $a * $b / ($i + $a * $b); return $n * $b / ($n - $a * (1 - $b)); }
    static function serviceLevel(float $a, int $n, float $aht, float $thr): float { if ($n <= $a) return 0.0; return 1 - self::erlangC($a, $n) * exp(-($n - $a) * $thr / max(1, $aht)); }
    /** Nombre minimal d'agents simultanés pour atteindre le niveau de service cible. */
    static function agents(float $perHour, float $aht, float $slTarget, float $thr): int {
        if ($perHour <= 0) return 0; $a = $perHour * $aht / 3600; $n = max(1, (int)ceil($a) + 1);
        while (self::serviceLevel($a, $n, $aht, $thr) < $slTarget / 100 && $n < 2000) $n++; return $n;
    }
    /** Prévision jour par jour. @return array[] [date, volume, aht, required, planned, gap, model] */
    static function forecast(array $u, int $days = 28): array {
        $from = date('Y-m-d', strtotime('-56 days')); $by = []; $ahtS = 0.0; $hS = 0;
        foreach (DB::all('SELECT day, offered, handled, aht_sec FROM pl_stats WHERE unit_type=? AND unit_id=? AND day>=? AND day<?', [$u['type'], $u['id'], $from, date('Y-m-d')]) as $r) { $by[(int)date('N', strtotime($r['day']))][] = (int)$r['offered']; $ahtS += (float)$r['aht_sec'] * (int)$r['handled']; $hS += (int)$r['handled']; }
        $aht = $hS ? $ahtS / $hS : 300; $queue = self::queueUnit($u);
        $prod = null; if (!$queue) { $r = DB::one('SELECT COALESCE(SUM(a.handled),0) h, COUNT(*) n FROM pl_agent_stats a JOIN employees e ON e.id=a.employee_id WHERE ' . ($u['type'] === 'team' ? 'e.team_id' : 'e.store_id') . '=? AND a.day>=? AND a.logged_min>0', [$u['id'], $from]); if ($r && $r['n'] > 0 && $r['h'] > 0) $prod = $r['h'] / $r['n']; }
        $shrink = min(0.9, max(0, (float)setting('pl.shrinkage', '25') / 100)); $peak = max(1, (float)setting('pl.peak_share', '12')) / 100; $thr = (float)setting('pl.sl_threshold', '20'); $tgt = self::targets($u)['sl'];
        $start = date('Y-m-d', strtotime('+1 day')); $end = self::addDays($start, $days - 1); $pl = self::planned($u, $start, $end); $out = [];
        for ($i = 0; $i < $days; $i++) {
            $d = self::addDays($start, $i); $s = $by[(int)date('N', strtotime($d))] ?? []; $plan = array_sum($pl[$d] ?? []);
            if (count($s) < 2) { $out[] = ['date' => $d, 'volume' => null, 'aht' => null, 'required' => null, 'planned' => $plan, 'gap' => null]; continue; }
            $vol = array_sum($s) / count($s);
            if ($queue) $req = (int)ceil(self::agents($vol * $peak, $aht, $tgt, $thr) / (1 - $shrink)); elseif ($prod) $req = (int)ceil($vol / $prod / (1 - $shrink)); else $req = null;
            $out[] = ['date' => $d, 'volume' => (int)round($vol), 'aht' => (int)round($aht), 'required' => $req, 'planned' => $plan, 'gap' => $req === null ? null : $plan - $req];
        }
        return $out;
    }
}
