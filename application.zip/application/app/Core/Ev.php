<?php
namespace App\Core;
/** Gestion des événements : audience, inscriptions avec capacité et liste d'attente, présence, rappels, export ICS. */
class Ev {
    const STATUS = ['draft' => 'Brouillon', 'published' => 'Publié', 'cancelled' => 'Annulé'];
    const REG = ['none' => 'Sans inscription', 'optional' => 'Inscription facultative', 'required' => 'Inscription obligatoire'];
    const AUD = ['all' => 'Tout le personnel', 'team' => 'Équipes choisies', 'store' => 'Boutiques choisies', 'invite' => 'Invités nommés'];
    const ATT = ['invited' => 'Invité', 'registered' => 'Inscrit', 'waitlist' => 'Liste d\'attente', 'declined' => 'Décliné', 'attended' => 'Présent', 'absent' => 'Absent'];
    const ATT_COLOR = ['invited' => 'secondary', 'registered' => 'primary', 'waitlist' => 'warning', 'declined' => 'dark', 'attended' => 'success', 'absent' => 'danger'];
    const REPEAT = ['' => 'Aucune', 'weekly' => 'Chaque semaine', 'biweekly' => 'Toutes les 2 semaines', 'monthly' => 'Chaque mois'];

    static function me(): int { return (int)(Auth::user()['employee_id'] ?? 0); }
    static function userOf(int $emp): ?int { $u = DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [$emp]); return $u ? (int)$u : null; }
    static function nextRef(): string {
        $y = date('Y'); $n = (int)DB::val("SELECT COUNT(*) FROM ev_events WHERE ref LIKE ?", ["EV-$y-%"]) + 1;
        do { $r = sprintf('EV-%s-%03d', $y, $n++); } while (DB::val('SELECT 1 FROM ev_events WHERE ref=?', [$r]));
        return $r;
    }
    /** @return int[] collaborateurs visés par l'audience (hors invités nommés, gérés par ev_attendees). */
    static function audienceIds(array $e): array {
        if ($e['audience'] === 'all') return array_map('intval', array_column(DB::all("SELECT id FROM employees WHERE status<>'left'"), 'id'));
        if ($e['audience'] === 'invite') return [];
        $col = $e['audience'] === 'team' ? 'team_id' : 'store_id';
        $ids = array_filter(array_map('intval', array_column(DB::all("SELECT $col v FROM ev_targets WHERE event_id=?", [(int)$e['id']]), 'v')));
        if (!$ids) return [];
        return array_map('intval', array_column(DB::all("SELECT id FROM employees WHERE status<>'left' AND $col IN (" . implode(',', array_fill(0, count($ids), '?')) . ')', array_values($ids)), 'id'));
    }
    static function targets(int $id): array { return ['team' => array_map('intval', array_column(DB::all('SELECT team_id v FROM ev_targets WHERE event_id=? AND team_id IS NOT NULL', [$id]), 'v')), 'store' => array_map('intval', array_column(DB::all('SELECT store_id v FROM ev_targets WHERE event_id=? AND store_id IS NOT NULL', [$id]), 'v'))]; }
    /** L'événement est-il visible de ce collaborateur ? (gestionnaires : tout ; autres : publié et concerné) */
    static function visible(array $e, int $emp): bool {
        if (can('ev.manage')) return true;
        if ($e['status'] === 'draft') return false;
        if ($e['audience'] === 'all') return true;
        if (!$emp) return false;
        if (DB::val('SELECT 1 FROM ev_attendees WHERE event_id=? AND employee_id=?', [(int)$e['id'], $emp])) return true;
        $m = DB::one('SELECT team_id, store_id FROM employees WHERE id=?', [$emp]); if (!$m) return false;
        return (bool)DB::val('SELECT 1 FROM ev_targets WHERE event_id=? AND ((team_id IS NOT NULL AND team_id=?) OR (store_id IS NOT NULL AND store_id=?))', [(int)$e['id'], (int)$m['team_id'], (int)$m['store_id']]);
    }
    static function counts(int $id): array {
        $c = ['registered' => 0, 'waitlist' => 0, 'attended' => 0, 'absent' => 0, 'invited' => 0, 'declined' => 0];
        foreach (DB::all('SELECT status, COUNT(*) n FROM ev_attendees WHERE event_id=? GROUP BY status', [$id]) as $r) $c[$r['status']] = (int)$r['n'];
        return $c;
    }
    static function seats(array $e): ?int { $cap = (int)$e['capacity']; if ($cap <= 0) return null; return max(0, $cap - (int)DB::val("SELECT COUNT(*) FROM ev_attendees WHERE event_id=? AND status IN ('registered','attended')", [(int)$e['id']])); }
    static function open(array $e): bool { return $e['status'] === 'published' && $e['registration'] !== 'none' && $e['end_at'] > now() && (!$e['reg_deadline'] || $e['reg_deadline'] > now()); }
    /** Inscrit le collaborateur : 'registered', 'waitlist' ou 'closed' / 'full'. */
    static function register(array $e, int $emp, string $source = 'self'): string {
        $row = DB::one('SELECT * FROM ev_attendees WHERE event_id=? AND employee_id=?', [(int)$e['id'], $emp]);
        if ($row && in_array($row['status'], ['registered', 'attended'], true)) return 'registered';
        if ($row && $row['status'] === 'waitlist') return 'waitlist';
        if (!self::open($e)) return 'closed';
        $st = 'registered'; $seats = self::seats($e);
        if ($seats !== null && $seats <= 0) { if (!(int)$e['waitlist']) return 'full'; $st = 'waitlist'; }
        $d = ['status' => $st, 'source' => $source, 'registered_at' => now()];
        if ($row) DB::update('ev_attendees', $d, 'id=?', [(int)$row['id']]); else DB::insert('ev_attendees', $d + ['event_id' => (int)$e['id'], 'employee_id' => $emp]);
        return $st;
    }
    static function unregister(array $e, int $emp): void {
        $row = DB::one('SELECT * FROM ev_attendees WHERE event_id=? AND employee_id=?', [(int)$e['id'], $emp]); if (!$row) return;
        $was = $row['status']; DB::update('ev_attendees', ['status' => 'declined'], 'id=?', [(int)$row['id']]);
        if ($was === 'registered') self::promote($e);
    }
    /** Fait passer en tête de liste d'attente tant qu'il reste des places. */
    static function promote(array $e): int {
        $n = 0;
        while (true) {
            $seats = self::seats($e); if ($seats !== null && $seats <= 0) break;
            $w = DB::one("SELECT * FROM ev_attendees WHERE event_id=? AND status='waitlist' ORDER BY registered_at, id LIMIT 1", [(int)$e['id']]); if (!$w) break;
            DB::update('ev_attendees', ['status' => 'registered', 'registered_at' => now()], 'id=?', [(int)$w['id']]); $n++;
            if ($u = self::userOf((int)$w['employee_id'])) Notifier::send($u, 'Une place s\'est libérée', 'Vous êtes inscrit à : ' . $e['title'], '/ev/' . $e['id']);
        }
        return $n;
    }
    /** À la publication : crée les invitations (inscription d'office si l'événement est obligatoire) et prévient les personnes. */
    static function invite(array $e): int {
        $n = 0; $ids = array_unique(array_merge(self::audienceIds($e), array_map('intval', array_column(DB::all('SELECT employee_id v FROM ev_attendees WHERE event_id=?', [(int)$e['id']]), 'v'))));
        foreach ($ids as $emp) {
            $row = DB::one('SELECT * FROM ev_attendees WHERE event_id=? AND employee_id=?', [(int)$e['id'], $emp]);
            if (!$row) { DB::insert('ev_attendees', ['event_id' => (int)$e['id'], 'employee_id' => $emp, 'status' => (int)$e['mandatory'] ? 'registered' : 'invited', 'source' => (int)$e['mandatory'] ? 'auto' : 'invited', 'registered_at' => (int)$e['mandatory'] ? now() : null]); }
            elseif ($row['status'] === 'invited' && (int)$e['mandatory']) DB::update('ev_attendees', ['status' => 'registered', 'source' => 'auto', 'registered_at' => now()], 'id=?', [(int)$row['id']]);
            if ($u = self::userOf($emp)) { Notifier::send($u, ((int)$e['mandatory'] ? 'Événement obligatoire : ' : 'Invitation : ') . $e['title'], d($e['start_at']) . ' à ' . substr($e['start_at'], 11, 5) . ($e['location'] ? ' — ' . $e['location'] : ''), '/ev/' . $e['id']); $n++; }
        }
        return $n;
    }
    static function notifyAttendees(array $e, string $title, string $body, array $statuses = ['invited', 'registered', 'waitlist']): int {
        $n = 0; $in = implode(',', array_fill(0, count($statuses), '?'));
        foreach (DB::all("SELECT employee_id FROM ev_attendees WHERE event_id=? AND status IN ($in)", array_merge([(int)$e['id']], $statuses)) as $a) if ($u = self::userOf((int)$a['employee_id'])) { Notifier::send($u, $title, $body, '/ev/' . $e['id']); $n++; }
        return $n;
    }
    static function checkinOpen(array $e): bool {
        $m = max(0, (int)setting('ev.checkin_open_minutes', 60));
        return $e['status'] === 'published' && now() >= date('Y-m-d H:i:s', strtotime($e['start_at']) - $m * 60) && now() <= $e['end_at'];
    }
    static function ics(array $events, string $name = 'Evenements'): string {
        $esc = fn($s) => str_replace(["\\", ";", ",", "\r\n", "\n", "\r"], ["\\\\", "\;", "\\,", "\\n", "\\n", "\\n"], (string)$s);
        $f = fn($t) => date('Ymd\THis', strtotime($t));
        $o = "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//CXO Excellence Hub//FR\r\nCALSCALE:GREGORIAN\r\nX-WR-CALNAME:" . $esc($name) . "\r\n";
        foreach ($events as $e) {
            $o .= "BEGIN:VEVENT\r\nUID:{$e['ref']}@cxo-hub\r\nDTSTAMP:" . gmdate('Ymd\THis\Z') . "\r\nDTSTART:" . $f($e['start_at']) . "\r\nDTEND:" . $f($e['end_at']) . "\r\nSUMMARY:" . $esc($e['title']) . "\r\n";
            if ($e['location']) $o .= 'LOCATION:' . $esc($e['location']) . "\r\n";
            $desc = trim(($e['description'] ?? '') . ($e['online_url'] ? "\n" . $e['online_url'] : '')); if ($desc !== '') $o .= 'DESCRIPTION:' . $esc($desc) . "\r\n";
            if ($e['status'] === 'cancelled') $o .= "STATUS:CANCELLED\r\n";
            $o .= "END:VEVENT\r\n";
        }
        return $o . "END:VCALENDAR\r\n";
    }
}
