<?php
namespace App\Core;
/** Génération de fichiers iCalendar (.ics) : invitation, mise à jour, annulation et export mensuel. */
class Ics {
    private static function esc(string $s): string { return str_replace(["\\", ";", ",", "\r\n", "\n", "\r"], ["\\\\", "\;", "\\,", "\\n", "\\n", "\\n"], $s); }
    private static function fold(string $l): string {
        $out = ''; while (strlen($l) > 74) { $cut = 74; while ($cut > 0 && (ord($l[$cut]) & 0xC0) === 0x80) $cut--; $out .= substr($l, 0, $cut) . "\r\n "; $l = substr($l, $cut); } return $out . $l;
    }
    private static function utc(string $local): string { return gmdate('Ymd\THis\Z', strtotime($local)); }
    private static function host(): string { $f = (string)env('MAIL_FROM', ''); return substr(strrchr($f, '@') ?: '@cxo-hub.local', 1) ?: 'cxo-hub.local'; }
    /** Bloc VEVENT d'une séance. $attendees : adresses e-mail. */
    static function vevent(string $kind, array $row, array $attendees = [], ?string $title = null): string {
        $id = (int)$row['id']; $seq = (int)DB::val("SELECT COUNT(*) FROM qa_session_log WHERE kind=? AND ref_id=? AND action IN ('postpone','cancel')", [$kind, $id]);
        $title = $title ?? QaSessions::label($kind, $row); $end = date('Y-m-d H:i:s', strtotime($row['planned_at']) + 60 * max(5, (int)$row['duration_min']));
        $url = (string)env('APP_URL', '') !== '' ? rtrim((string)env('APP_URL'), '/') . '/qa/' . ($kind === 'coaching' ? 'coachings' : 'debriefs') . '/' . $id : '';
        $desc = $kind === 'coaching' ? (string)($row['objectives'] ?? '') : (string)($row['agenda'] ?? '');
        $L = ['BEGIN:VEVENT', "UID:cxo-$kind-$id@" . self::host(), 'DTSTAMP:' . gmdate('Ymd\THis\Z'), 'DTSTART:' . self::utc($row['planned_at']), 'DTEND:' . self::utc($end), "SEQUENCE:$seq", 'SUMMARY:' . self::esc($title)];
        if ($desc !== '' || $url) $L[] = 'DESCRIPTION:' . self::esc(trim($desc . ($url ? "\n" . $url : '')));
        if ($url) $L[] = 'URL:' . $url;
        $from = (string)env('MAIL_FROM', ''); if (filter_var($from, FILTER_VALIDATE_EMAIL)) $L[] = 'ORGANIZER;CN=' . self::esc((string)env('MAIL_FROM_NAME', 'Contrôle qualité')) . ':mailto:' . $from;
        foreach ($attendees as $a) if (filter_var($a, FILTER_VALIDATE_EMAIL)) $L[] = 'ATTENDEE;ROLE=REQ-PARTICIPANT;PARTSTAT=NEEDS-ACTION:mailto:' . $a;
        $L[] = 'STATUS:' . ($row['status'] === 'cancelled' ? 'CANCELLED' : 'CONFIRMED');
        if ($row['status'] !== 'cancelled') array_push($L, 'BEGIN:VALARM', 'ACTION:DISPLAY', 'DESCRIPTION:Rappel', 'TRIGGER:-P1D', 'END:VALARM');
        $L[] = 'END:VEVENT'; return implode("\r\n", array_map([self::class, 'fold'], $L));
    }
    /** @param string[] $events blocs VEVENT ; $method REQUEST (invitation/mise à jour), CANCEL ou PUBLISH (export). */
    static function calendar(array $events, string $method = 'PUBLISH', string $name = 'Contrôle qualité'): string {
        return implode("\r\n", ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//CXO Excellence Hub//Controle qualite//FR', 'CALSCALE:GREGORIAN', "METHOD:$method", 'X-WR-CALNAME:' . self::esc($name), implode("\r\n", $events), 'END:VCALENDAR']) . "\r\n";
    }
    static function send(string $kind, array $row, array $userIds, string $subject, string $body): void {
        $emails = []; foreach ($userIds as $u) { $e = DB::val("SELECT email FROM users WHERE id=? AND status='active'", [$u]); if ($e) $emails[(int)$u] = $e; }
        $ics = self::calendar([self::vevent($kind, $row, array_values($emails))], $row['status'] === 'cancelled' ? 'CANCEL' : 'REQUEST');
        foreach ($emails as $u => $e) Mailer::queue($e, $subject, $body, null, $ics);
    }
}
