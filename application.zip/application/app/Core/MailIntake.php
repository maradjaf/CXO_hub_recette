<?php
namespace App\Core;
/** Réception de tickets par e-mail : lit des messages bruts (.eml), crée un ticket ou ajoute un commentaire. */
class MailIntake {
    // ---- Analyse MIME (suffisante pour les messages courants : texte, HTML, pièces jointes)
    static function splitHeaders(string $raw): array {
        $raw = str_replace("\r\n", "\n", $raw); $p = strpos($raw, "\n\n");
        $h = $p === false ? $raw : substr($raw, 0, $p); $b = $p === false ? '' : substr($raw, $p + 2);
        $h = preg_replace("/\n[ \t]+/", ' ', $h); $out = [];
        foreach (explode("\n", $h) as $l) if (($c = strpos($l, ':')) > 0) { $k = strtolower(trim(substr($l, 0, $c))); if (!isset($out[$k])) $out[$k] = trim(substr($l, $c + 1)); }
        return [$out, $b];
    }
    static function param(string $header, string $name): ?string {
        if (preg_match('/(?:^|;)\s*' . preg_quote($name, '/') . '\*?=\s*(?:"([^"]*)"|([^;\s]*))/i', $header, $m)) {
            $v = $m[1] !== '' ? $m[1] : ($m[2] ?? '');
            if (preg_match("/^([\w-]+)'[^']*'(.*)$/", $v, $x)) return self::charset(rawurldecode($x[2]), $x[1]);
            return self::decodeWords($v);
        }
        return null;
    }
    static function charset(string $s, ?string $cs): string {
        $cs = strtoupper(trim((string)$cs, " \"'")); if ($cs === '' || $cs === 'UTF-8' || $cs === 'US-ASCII') return mb_check_encoding($s, 'UTF-8') ? $s : mb_convert_encoding($s, 'UTF-8', 'ISO-8859-1');
        try { return mb_convert_encoding($s, 'UTF-8', $cs); } catch (\Throwable $e) { return mb_convert_encoding($s, 'UTF-8', 'ISO-8859-1'); }
    }
    static function decodeWords(string $s): string {
        return preg_replace_callback('/=\?([^?]+)\?([bqBQ])\?([^?]*)\?=/', function ($m) {
            $t = strtoupper($m[2]) === 'B' ? base64_decode($m[3]) : quoted_printable_decode(str_replace('_', ' ', $m[3]));
            return self::charset($t, $m[1]);
        }, preg_replace('/\?=\s+=\?/', '?==?', $s));
    }
    static function decodeBody(string $b, string $enc): string {
        return match (strtolower(trim($enc))) { 'base64' => (string)base64_decode($b), 'quoted-printable' => quoted_printable_decode($b), default => $b };
    }
    /** @return array{text:string,html:string,files:array} */
    static function walk(string $raw, int $depth = 0): array {
        [$h, $body] = self::splitHeaders($raw); $r = ['text' => '', 'html' => '', 'files' => []]; if ($depth > 6) return $r;
        $ct = $h['content-type'] ?? 'text/plain'; $type = strtolower(trim(explode(';', $ct)[0]));
        if (str_starts_with($type, 'multipart/') && ($bd = self::param($ct, 'boundary'))) {
            foreach (preg_split('/\n--' . preg_quote($bd, '/') . '(?:--)?[ \t]*(?=\n|$)/', "\n" . $body) as $i => $part) {
                if ($i === 0 || trim($part) === '' ) continue;
                $x = self::walk(ltrim($part, "\n"), $depth + 1);
                $r['text'] .= $x['text']; $r['html'] .= $x['html']; $r['files'] = array_merge($r['files'], $x['files']);
            }
            return $r;
        }
        $data = self::decodeBody($body, $h['content-transfer-encoding'] ?? '7bit');
        $disp = $h['content-disposition'] ?? ''; $name = self::param($disp, 'filename') ?? self::param($ct, 'name');
        if ($name !== null || stripos($disp, 'attachment') === 0) { if ($name !== null && $data !== '') $r['files'][] = ['name' => $name, 'data' => $data]; return $r; }
        if ($type === 'text/plain') $r['text'] = self::charset($data, self::param($ct, 'charset'));
        elseif ($type === 'text/html') $r['html'] = self::charset($data, self::param($ct, 'charset'));
        return $r;
    }
    static function parse(string $raw): array {
        [$h] = self::splitHeaders($raw); $m = self::walk($raw);
        $text = trim($m['text']);
        if ($text === '' && $m['html'] !== '') $text = trim(html_entity_decode(strip_tags(preg_replace('#<(br|/p|/div|/tr)[^>]*>#i', "\n", preg_replace('#<(style|script)[^>]*>.*?</\1>#is', '', $m['html']))), ENT_QUOTES, 'UTF-8'));
        $from = ''; if (preg_match('/<([^>]+@[^>]+)>/', $h['from'] ?? '', $x)) $from = $x[1]; elseif (preg_match('/[^\s<>"]+@[^\s<>"]+/', $h['from'] ?? '', $x)) $from = $x[0];
        $mid = trim($h['message-id'] ?? '', ' <>');
        return ['from' => strtolower(trim($from)), 'subject' => trim(self::decodeWords($h['subject'] ?? '')), 'message_id' => $mid !== '' ? $mid : 'sha1-' . sha1($raw), 'text' => $text, 'files' => $m['files'], 'auto' => isset($h['auto-submitted']) && strtolower($h['auto-submitted']) !== 'no'];
    }
    /** Retire les citations d'une réponse (lignes « > » et en-tête « a écrit : »). */
    static function stripQuote(string $t): string {
        $out = [];
        foreach (explode("\n", str_replace("\r\n", "\n", $t)) as $l) {
            if (preg_match('/^\s*>/', $l) || preg_match('/^(Le .+ a écrit\s*:|On .+ wrote:|-{2,}\s*(Message d\'origine|Original Message))/iu', trim($l))) break;
            $out[] = $l;
        }
        return trim(implode("\n", $out));
    }

    // ---- Authentification de l'expéditeur (résultats SPF/DKIM/DMARC posés par NOTRE serveur de réception)
    /** Domaines « alignés » : identiques ou l'un sous-domaine de l'autre. */
    private static function aligned(string $a, string $b): bool {
        $a = strtolower(trim($a, " .@<>\"")); $b = strtolower(trim($b, " .@<>\""));
        return $a !== '' && $b !== '' && ($a === $b || str_ends_with($a, '.' . $b) || str_ends_with($b, '.' . $a));
    }
    /**
     * Vérifie l'en-tête Authentication-Results le plus haut (celui de notre serveur) : MAIL_AUTHSERV_ID doit être son identifiant.
     * Accepté si dmarc=pass, ou dkim=pass / spf=pass avec un domaine aligné sur celui de l'adresse « From ».
     * L'application ne vérifie PAS elle-même les signatures : elle fait confiance au serveur de réception.
     * @return array{0:bool,1:string}
     */
    static function senderAuthenticated(string $raw, string $fromEmail): array {
        $mode = strtolower((string)env('MAIL_AUTH_MODE', 'off'));
        if ($mode !== 'results') return [true, 'contrôle désactivé'];
        $id = strtolower(trim((string)env('MAIL_AUTHSERV_ID', ''))); if ($id === '') return [false, 'MAIL_AUTHSERV_ID non configuré'];
        $raw = str_replace("\r\n", "\n", $raw); $p = strpos($raw, "\n\n"); $h = preg_replace("/\n[ \t]+/", ' ', $p === false ? $raw : substr($raw, 0, $p));
        $dom = strtolower(substr(strrchr($fromEmail, '@') ?: '', 1)); if ($dom === '') return [false, 'adresse expéditeur illisible'];
        foreach (explode("\n", $h) as $l) {
            if (!preg_match('/^authentication-results\s*:\s*(.*)$/i', $l, $m)) continue;
            $parts = array_map('trim', explode(';', $m[1])); $serv = strtolower(preg_replace('/\s+\d+$/', '', array_shift($parts)));
            if ($serv !== $id) continue;                      // en-tête d'un autre serveur : ignoré
            foreach ($parts as $r) {
                if (preg_match('/^dmarc\s*=\s*pass\b/i', $r)) return [true, 'DMARC valide'];
                if (preg_match('/^dkim\s*=\s*pass\b/i', $r) && preg_match('/header\.(?:d|i)\s*=\s*"?([^\s;"]+)/i', $r, $x) && self::aligned(preg_replace('/^.*@/', '', $x[1]), $dom)) return [true, 'DKIM valide'];
                if (preg_match('/^spf\s*=\s*pass\b/i', $r) && preg_match('/smtp\.mailfrom\s*=\s*"?([^\s;"]+)/i', $r, $x) && self::aligned(preg_replace('/^.*@/', '', $x[1]), $dom)) return [true, 'SPF valide'];
            }
            return [false, 'SPF/DKIM/DMARC non validés pour ' . $dom];   // seul l'en-tête le plus haut de notre serveur fait foi
        }
        return [false, 'aucune vérification de notre serveur de réception'];
    }

    // ---- Traitement d'un message
    /** @return array{0:string,1:?int,2:string} statut (created|comment|rejected|duplicate), n° de ticket, note */
    static function process(string $raw): array {
        $m = self::parse($raw); $mid = mb_substr($m['message_id'], 0, 190);
        if (DB::val('SELECT 1 FROM at_mail WHERE message_id=?', [$mid])) return ['duplicate', null, 'Message déjà traité.'];
        $log = function (string $st, ?int $tid, string $note) use ($mid, $m) { DB::insert('at_mail', ['message_id' => $mid, 'from_email' => mb_substr($m['from'], 0, 190), 'subject' => mb_substr($m['subject'], 0, 190), 'status' => $st, 'ticket_id' => $tid, 'note' => mb_substr($note, 0, 300), 'created_at' => now()]); return [$st, $tid, $note]; };
        if ($m['auto']) return $log('rejected', null, 'Message automatique ignoré.');
        [$authOk, $authWhy] = self::senderAuthenticated($raw, $m['from']);
        if (!$authOk) { Notifier::toPermission('at.manage', 'E-mail refusé (expéditeur non authentifié)', ($m['from'] ?: '?') . ' · ' . $m['subject'], '/at/mail'); return $log('rejected', null, 'Expéditeur non authentifié : ' . $authWhy . '.'); }
        $u = $m['from'] ? DB::one("SELECT * FROM users WHERE LOWER(email)=? AND status='active'", [$m['from']]) : null;
        if (!$u) { Notifier::toPermission('at.manage', 'E-mail refusé (expéditeur inconnu)', ($m['from'] ?: '?') . ' · ' . $m['subject'], '/at/mail'); return $log('rejected', null, 'Expéditeur sans compte actif.'); }
        $body = trim($m['text']); if ($m['subject'] === '' && $body === '') return $log('rejected', null, 'Message vide.');
        $uid = (int)$u['id'];
        if (preg_match('/AT-\d{2}-\d{5}/', $m['subject'], $x) && ($t = DB::one('SELECT * FROM at_tickets WHERE reference=?', [$x[0]]))) {
            $can = (int)$t['requester_id'] === $uid || self::userCan($uid, 'at.handle');
            if (!$can) return $log('rejected', (int)$t['id'], 'Expéditeur non autorisé sur ce ticket.');
            $txt = self::stripQuote($body) ?: $body;
            Tickets::event((int)$t['id'], 'comment', mb_substr('(par e-mail) ' . $txt, 0, 1500), $uid);
            if ((int)$t['requester_id'] === $uid && $t['status'] === 'resolved') { DB::update('at_tickets', ['status' => 'in_progress', 'resolved_at' => null], 'id=?', [(int)$t['id']]); Tickets::event((int)$t['id'], 'status', 'Ticket rouvert par e-mail du demandeur.', $uid); }
            if ($t['assignee_id'] && (int)$t['assignee_id'] !== $uid) Notifier::send((int)$t['assignee_id'], 'Nouveau message sur ' . $t['reference'], mb_substr($txt, 0, 120), '/at/' . $t['id']);
            elseif ($t['requester_id'] && (int)$t['requester_id'] !== $uid) Notifier::send((int)$t['requester_id'], 'Réponse sur ' . $t['reference'], mb_substr($txt, 0, 120), '/at/' . $t['id']);
            if ((int)$t['requester_id'] === $uid && $t['status'] === 'waiting') { DB::update('at_tickets', ['status' => 'in_progress'] + Tickets::transition($t, 'in_progress'), 'id=?', [(int)$t['id']]); Tickets::event((int)$t['id'], 'status', 'Réponse du demandeur par e-mail : le ticket reprend.', $uid); }
            foreach ($m['files'] as $f) Tickets::saveBytes((int)$t['id'], $f['name'], $f['data'], $uid, false);
            return $log('comment', (int)$t['id'], 'Commentaire ajouté à ' . $t['reference']);
        }
        $emp = $u['employee_id'] ? DB::one('SELECT store_id, team_id FROM employees WHERE id=?', [(int)$u['employee_id']]) : null;
        $title = preg_replace('/^\s*((re|tr|fwd?)\s*:\s*)+/i', '', $m['subject']); $title = mb_substr($title !== '' ? $title : 'Demande reçue par e-mail', 0, 190);
        $id = Tickets::open(['channel' => 'email', 'kind' => 'incident', 'category' => 'AUTRE', 'priority' => 'normal', 'title' => $title, 'description' => mb_substr($body !== '' ? $body : $title, 0, 5000), 'store_id' => $emp['store_id'] ?? null, 'team_id' => $emp['team_id'] ?? null], $uid);
        Tickets::event($id, 'comment', 'Ticket créé à partir d\'un e-mail de ' . $m['from'] . '. Catégorie et priorité à confirmer par un technicien.', null);
        foreach ($m['files'] as $f) Tickets::saveBytes($id, $f['name'], $f['data'], $uid, false);
        Notifier::send($uid, 'Votre e-mail a créé un ticket', (string)DB::val('SELECT reference FROM at_tickets WHERE id=?', [$id]), '/at/' . $id);
        return $log('created', $id, 'Ticket créé.');
    }
    private static function userCan(int $uid, string $perm): bool {
        return (bool)DB::val("SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id LEFT JOIN role_permissions rp ON rp.role_id=r.id LEFT JOIN permissions p ON p.id=rp.permission_id WHERE ur.user_id=? AND (r.code='admin' OR p.code=?)", [$uid, $perm]);
    }
}
