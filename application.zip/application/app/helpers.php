<?php
declare(strict_types=1);

use App\Core\{Auth, Env, DB};

function env(string $k, $d = null) { return Env::get($k, $d); }
function e($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function now(): string { return date('Y-m-d H:i:s'); }
function base_path(): string {
    $s = $_SERVER['SCRIPT_NAME'] ?? '/index.php';
    $d = str_replace('\\', '/', dirname($s));
    return $d === '/' || $d === '.' ? '' : rtrim($d, '/');
}
/** Adresses : « pretty » (/login, serveur avec réécriture) ou « index » (/index.php/login, sans .htaccess ni réécriture, cas d'un Laragon sans configuration). Réglage URL_MODE du fichier .env. */
function url(string $p = ''): string { return base_path() . (env('URL_MODE', 'pretty') === 'index' ? '/index.php/' : '/') . ltrim($p, '/'); }
function asset(string $p): string { return base_path() . '/assets/' . ltrim($p, '/'); }
function redirect(string $p): never { header('Location: ' . (str_starts_with($p, 'http') ? $p : url($p))); exit; }
function flash(?string $msg = null, string $type = 'success') {
    if ($msg !== null) { $_SESSION['_flash'][] = [$type, $msg]; return null; }
    $f = $_SESSION['_flash'] ?? []; unset($_SESSION['_flash']); return $f;
}
function old(string $k, $d = '') { return $_SESSION['_old'][$k] ?? $d; }
function csrf_field(): string { return '<input type="hidden" name="_csrf" value="' . e(App\Core\Csrf::token()) . '">'; }
function can(string $perm): bool { return Auth::can($perm); }
function setting(string $k, $d = null) { return App\Core\Settings::get($k, $d); }
function dt(?string $s): string { return $s ? date('d/m/Y H:i', strtotime($s)) : ''; }
function d(?string $s): string { return $s ? date('d/m/Y', strtotime($s)) : ''; }
function badge(string $label, string $kind = 'secondary'): string { return '<span class="badge text-bg-' . e($kind) . '">' . e($label) . '</span>'; }
function paginate(string $from, array $p, int $page, int $per = 25, string $select = '*', string $order = 'id DESC'): array {
    $total = (int)DB::val("SELECT COUNT(*) FROM $from", $p);
    // ?per=all charge toute la liste (2 000 lignes au plus) pour que la recherche, le tri et les exports du tableau portent sur l'ensemble
    $g = $_GET['per'] ?? null; if ($g === 'all') $per = max(1, min($total, 2000)); elseif (is_string($g) && ctype_digit($g)) $per = max(5, min(500, (int)$g));
    // jusqu'à 500 lignes, toute la liste est servie : la recherche, les filtres de colonne, le tri et les exports du tableau portent sur l'ensemble
    if ($g === null && !isset($_GET['page']) && $total > 0 && $total <= 500) $per = max($per, $total);
    $pages = max(1, (int)ceil($total / $per));
    $page = max(1, min($page, $pages));
    $rows = DB::all("SELECT $select FROM $from ORDER BY $order LIMIT " . (int)$per . ' OFFSET ' . (int)(($page - 1) * $per), $p);
    return ['rows' => $rows, 'total' => $total, 'page' => $page, 'pages' => $pages, 'per' => $per];
}
function qs(array $over = []): string {
    $q = array_merge($_GET, $over);
    foreach ($q as $k => $v) if ($v === '' || $v === null) unset($q[$k]);
    return $q ? '?' . http_build_query($q) : '';
}
function csv_download(string $name, array $header, array $rows): never {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $name . '"');
    $o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF");
    fputcsv($o, $header, ';');
    foreach ($rows as $r) fputcsv($o, array_values($r), ';');
    fclose($o); exit;
}

/**
 * Graphique SVG rendu par assets/app.js. $type : bar | hbar | line | doughnut.
 * $series : ['Nom de série' => [valeurs…]] (ou une simple liste de valeurs). Options : unit, stacked, h (hauteur), max, colors.
 */
function chart(string $type, array $labels, array $series, array $o = []): string {
    if (!$labels) return '<div class="text-muted small">Aucune donnée.</div>';
    if ($series && array_is_list($series) && !is_array($series[0] ?? null)) $series = ['' => $series];
    $sets = []; $i = 0; foreach ($series as $name => $data) { $s = ['name' => (string)$name, 'data' => array_map(fn($v) => $v === null ? null : round((float)$v, 2), array_values($data))]; if (!empty($o['colors'][$i])) $s['color'] = $o['colors'][$i]; if (!empty($o['meta'][$i])) $s += $o['meta'][$i]; $sets[] = $s; $i++; }
    $cfg = ['type' => $type, 'labels' => array_map('strval', array_values($labels)), 'series' => $sets] + array_intersect_key($o, ['unit' => 1, 'stacked' => 1, 'max' => 1, 'title' => 1, 'pcolors' => 1, 'ref' => 1, 'l_min' => 1, 'l_max' => 1, 'r_min' => 1, 'r_max' => 1, 'r_unit' => 1]);
    return '<div class="chart" data-h="' . (int)($o['h'] ?? 240) . '" data-chart="' . e(json_encode($cfg, JSON_UNESCAPED_UNICODE)) . '"></div>';
}
