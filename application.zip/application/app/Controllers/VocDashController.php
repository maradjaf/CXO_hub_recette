<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Voc};

/** Lot 59 — Tableau de bord VOC & NPS : indicateurs principaux (NPS, CSAT, FCR, FVR, CES) et pilotage de la Voix du Client. */
class VocDashController extends Controller {
    private function g(string $k, string $d = ''): string { return isset($_GET[$k]) && is_string($_GET[$k]) ? trim($_GET[$k]) : $d; }
    private function defaults(): array {
        $dates = array_column(Voc::npsRows(), 'day'); $cat = Voc::catalog();
        foreach (Voc::observations() as $code => $rows) if (empty($cat[$code]['demo'])) foreach ($rows as $r) $dates[] = $r['date'];
        $today = date('Y-m-d'); $latest = $dates ? max($dates) : $today; $anchor = max($latest, $today);
        return ['from' => date('Y-m-01', strtotime(substr($anchor, 0, 7) . '-01 -11 months')), 'to' => $latest > $today ? Voc::monthEnd($latest) : $today];
    }
    function index(): void {
        $def = $this->defaults(); $modes = array_diff_key(Voc::METRIC_PERIODS, ['day' => 1]);
        $f = ['from' => Voc::isDay($this->g('from')) ? $this->g('from') : $def['from'], 'to' => Voc::isDay($this->g('to')) ? $this->g('to') : $def['to'], 'period' => isset($modes[$this->g('period')]) ? $this->g('period') : 'month',
            'periods' => array_values(array_filter((array)($_GET['periods'] ?? []), 'is_string')), 'baseline' => $this->g('baseline'), 'scope' => $this->g('scope'), 'npsRegion' => $this->g('region'), 'sources' => $this->g('sources') === 'real' ? 'real' : 'all',
            'selected' => array_filter((array)($_GET['sel'] ?? []), 'is_string')];
        $options = Voc::periods($f['from'], $f['to'], $f['period']); $f['periods'] = array_values(array_intersect($f['periods'], array_column($options, 'id'))); $periods = Voc::pick($options, $f['periods']); $idx = array_keys($periods);
        $baseIndex = -1; foreach ($periods as $i => $p) if ($p['id'] === $f['baseline']) $baseIndex = $i; $baseIdx = $f['baseline'] === 'none' ? [] : ($baseIndex >= 0 ? [$baseIndex] : $idx);
        $real = fn(array $r) => $f['sources'] === 'all' || !$r['is_demo'];
        // NPS Yas et Moov
        $nrows = array_values(array_filter(Voc::npsRows(), fn($r) => $f['npsRegion'] === '' || $r['region'] === $f['npsRegion'])); $ops = [];
        foreach (['YAS', 'MOOV'] as $b) { $mine = array_values(array_filter($nrows, fn($r) => $r['brand'] === $b)); $st = array_map(fn($p) => Voc::npsStats(array_filter($mine, fn($r) => Voc::inP($r['day'], $p))), $periods); $latest = -1; foreach ($st as $i => $s) if ($s['n'] >= Voc::THRESHOLD) $latest = $i; $ops[$b] = ['rows' => $mine, 'stats' => $st, 'latest' => $latest]; }
        // séries CX par indicateur
        $obs = Voc::observations(); $groups = [];
        foreach (array_keys(Voc::METRICS) as $kind) { $items = [];
            foreach (Voc::catalog() as $s) { if ($s['metric'] !== $kind || ($f['scope'] !== '' && $s['scope'] !== $f['scope']) || ($f['sources'] !== 'all' && $s['demo'])) continue; $rows = $obs[$s['id']] ?? []; $st = array_map(fn($p) => Voc::pool($rows, $s, $p, []), $periods); $latest = -1; foreach ($st as $i => $x) if ($x['base'] > 0) $latest = $i; $items[] = ['s' => $s, 'stats' => $st, 'latest' => $latest, 'rows' => $rows]; }
            usort($items, fn($a, $b) => ((int)$a['s']['demo'] <=> (int)$b['s']['demo']) ?: ((int)($b['latest'] >= 0) <=> (int)($a['latest'] >= 0)) ?: strnatcmp($a['s']['id'], $b['s']['id']));
            $chosen = null; foreach ($items as $it) if ($it['s']['id'] === ($f['selected'][$kind] ?? '')) $chosen = $it; if (!$chosen) foreach ($items as $it) if ($it['latest'] >= 0 && !$it['s']['demo']) { $chosen = $it; break; } if (!$chosen) foreach ($items as $it) if ($it['latest'] >= 0) { $chosen = $it; break; } $chosen ??= $items[0] ?? null;
            $groups[$kind] = ['kind' => $kind, 'options' => $items, 'chosen' => $chosen]; }
        // pilotage
        $tail = $periods ? end($periods)['to'] : date('Y-m-d'); $pil = null;
        if ($periods) {
            $loop = array_values(array_filter(DB::all('SELECT * FROM vn_loop'), $real)); $cd = fn($r) => $r['stage'] === 'Clôturé' && Voc::isDay($r['closed']) ? $r['closed'] : '';
            $atCut = array_filter($loop, fn($r) => $r['opened'] <= $tail && (!$cd($r) || $cd($r) > $tail)); $cohort = array_filter($loop, fn($r) => Voc::inAny($r['opened'], $periods)); $held = array_filter($cohort, fn($r) => $r['due'] && (($cd($r) && $cd($r) <= $tail) || $r['due'] < $tail));
            $acts = array_values(array_filter(DB::all('SELECT * FROM vn_actions'), $real)); $late = array_values(array_filter($acts, fn($a) => $a['status'] !== 'Clôturée' && $a['due'] && $a['due'] < $tail)); usort($late, fn($a, $b) => strcmp($a['due'], $b['due']));
            $events = array_values(array_filter(DB::all('SELECT * FROM vn_events'), $real)); $done = array_values(array_filter($events, fn($e) => Voc::inAny($e['day'], $periods) && in_array($e['status'], ['Réalisé', 'Clôturé'], true)));
            $terrain = array_values(array_filter(DB::all('SELECT * FROM vn_field'), fn($t) => $real($t) && Voc::inAny($t['day'], $periods) && in_array($t['stage'], ['Réalisé', 'CR validé'], true))); $basable = array_filter($done, fn($e) => $e['expected'] > 0);
            $per = fn(array $rows, callable $date) => array_map(fn($p) => ['n' => null, 'v' => (float)count(array_filter($rows, fn($r) => Voc::inP($date($r) ?: null, $p)))], $periods);
            $sv = []; $evById = []; foreach (DB::all('SELECT * FROM vn_events') as $e) $evById[(int)$e['id']] = $e;
            foreach ($evById as $e) if ($e['hot_responded'] !== null && $e['hot_invited'] && Voc::inAny($e['day'], $periods) && $real($e)) $sv[] = ['title' => $e['theme'], 'date' => $e['day'], 'responses' => (int)$e['hot_responded'], 'rated' => (int)$e['hot_responded'], 'base' => (int)$e['hot_invited'], 'satisfied' => (int)$e['hot_very'] + (int)$e['hot_satisfied'], 'event' => (int)$e['id'], 'survey' => 0, 'origin' => 'Rapport source'];
            foreach (DB::all("SELECT * FROM vn_surveys WHERE state<>'draft'") as $c) { $e = $evById[(int)$c['event_id']] ?? null; if (!$e || !Voc::inAny($e['day'], $periods) || !$real($e)) continue; $q = DB::val("SELECT id FROM vn_questions WHERE survey_id=? AND kind='rating5' ORDER BY position, id LIMIT 1", [(int)$c['id']]);
                $vals = $q ? array_column(DB::all('SELECT a.value FROM vn_answers a JOIN vn_replies r ON r.id=a.reply_id WHERE r.survey_id=? AND a.question_id=?', [(int)$c['id'], (int)$q]), 'value') : []; $vals = array_filter($vals, fn($v) => in_array((string)$v, ['1', '2', '3', '4', '5'], true));
                $sv[] = ['title' => $c['title'], 'date' => $e['day'], 'responses' => (int)DB::val('SELECT COUNT(*) FROM vn_replies WHERE survey_id=?', [(int)$c['id']]), 'rated' => count($vals), 'base' => (int)$c['base'], 'satisfied' => count(array_filter($vals, fn($v) => (int)$v >= 4)), 'event' => (int)$e['id'], 'survey' => (int)$c['id'], 'origin' => 'En ligne']; }
            usort($sv, fn($a, $b) => strcmp($b['date'], $a['date']));
            $pil = ['loop' => ['atCut' => count($atCut), 'overdue' => count(array_filter($atCut, fn($r) => $r['due'] && $r['due'] < $tail)), 'cohort' => count($cohort), 'contacted' => count(array_filter($cohort, fn($r) => $r['first_contact'] && $r['first_contact'] >= $r['opened'] && $r['first_contact'] <= $tail)),
                    'resolved' => count(array_filter($cohort, fn($r) => $cd($r) && $cd($r) <= $tail)), 'held' => count($held), 'inSla' => count(array_filter($held, fn($r) => $cd($r) && $cd($r) <= $r['due'] && $cd($r) <= $tail)), 'demo' => (bool)array_filter($loop, fn($r) => $r['is_demo'] && $r['opened'] <= $tail),
                    'lines' => [['name' => 'Dossiers ouverts', 'color' => '#225fb0', 'points' => $per($loop, fn($r) => $r['opened'])], ['name' => 'Dossiers clôturés', 'color' => '#0b7965', 'points' => $per($loop, $cd)]]],
                'plans' => ['total' => count($acts), 'closed' => count(array_filter($acts, fn($a) => $a['status'] === 'Clôturée')), 'late' => $late, 'stages' => array_map(fn($s) => [$s, count(array_filter($acts, fn($a) => $a['status'] === $s))], Voc::ACTION_ST), 'demo' => (bool)array_filter($acts, fn($a) => $a['is_demo'])],
                'focus' => ['events' => count($done), 'terrain' => count($terrain), 'expected' => array_sum(array_column($basable, 'expected')), 'attended' => array_sum(array_column($basable, 'present')), 'demo' => (bool)array_filter(array_merge($done, $terrain), fn($x) => $x['is_demo']),
                    'lines' => [['name' => 'Focus groups réalisés', 'color' => '#225fb0', 'points' => $per($done, fn($e) => $e['day'])], ['name' => 'Sorties terrain réalisées', 'color' => '#0b7965', 'points' => $per($terrain, fn($e) => $e['day'])]]],
                'surveys' => $sv];
        }
        $this->view('voc/dashboard', ['title' => 'Tableau de bord VOC & NPS', 'f' => $f, 'options' => $options, 'periods' => $periods, 'baseIndex' => $baseIndex, 'baseIdx' => $baseIdx, 'ops' => $ops, 'nrows' => $nrows, 'groups' => $groups, 'pil' => $pil, 'tail' => $tail, 'modes' => $modes,
            'scopes' => Voc::uniq(array_column(Voc::catalog(), 'scope')), 'regions' => Voc::names(Voc::npsRows(), 'region'), 'npsSrc' => Voc::summary('nps'), 'hasData' => (bool)(Voc::npsRows() || Voc::observations() || DB::val('SELECT 1 FROM vn_events') || DB::val('SELECT 1 FROM vn_loop') || DB::val('SELECT 1 FROM vn_actions'))]);
    }
}
