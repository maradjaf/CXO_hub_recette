<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Kb, Sop};
class KbController extends Controller {
    // =============== Lecture ===============
    private function cats(): array { return DB::all('SELECT c.*, (SELECT COUNT(*) FROM kb_articles a WHERE a.category_id=c.id AND ' . Kb::visible()[0] . ') n FROM kb_categories c ORDER BY c.sort_order, c.name'); }
    function home(): void {
        [$w] = Kb::visible();
        $this->view('kb/index', ['title' => 'Base de connaissances', 'cats' => $this->cats(),
            'top' => DB::all("SELECT a.id, a.title, a.kind, a.useful, a.views FROM kb_articles a WHERE $w ORDER BY a.useful DESC, a.views DESC LIMIT 6"),
            'sopCount' => (int)DB::val('SELECT COUNT(*) FROM kb_sops a WHERE ' . Sop::visibleSql()), 'toRead' => count(Sop::pendingReads()),
            'recent' => DB::all("SELECT a.id, a.title, a.kind, a.published_at FROM kb_articles a WHERE $w ORDER BY a.published_at DESC, a.id DESC LIMIT 6")]);
    }
    function search(): void {
        $q = trim((string)$this->in('q', '')); $cat = (int)$this->in('cat', 0) ?: null;
        $rows = $q !== '' ? Kb::search($q, 40, $cat) : ($cat ? $this->byCategory($cat) : []);
        $this->view('kb/search', ['title' => 'Recherche', 'q' => $q, 'cat' => $cat, 'rows' => $rows, 'cats' => $this->cats(), 'canAsk' => $q !== '', 'sops' => $q !== '' ? Sop::search($q, 8, $cat) : []]);
    }
    private function byCategory(int $cat): array {
        [$w] = Kb::visible(); return DB::all("SELECT a.id, a.kind, a.title, a.summary, a.useful, a.useless, a.views, a.internal, c.name category FROM kb_articles a LEFT JOIN kb_categories c ON c.id=a.category_id WHERE $w AND a.category_id=? ORDER BY a.title", [$cat]);
    }
    function faq(): void {
        [$w] = Kb::visible(); $rows = DB::all("SELECT a.*, c.name category FROM kb_articles a LEFT JOIN kb_categories c ON c.id=a.category_id WHERE $w AND a.kind='faq' ORDER BY COALESCE(c.sort_order, 999), c.name, a.useful DESC, a.views DESC, a.title");
        $by = []; foreach ($rows as $r) $by[$r['category'] ?: 'Autres questions'][] = $r;
        $this->view('kb/faq', ['title' => 'Questions fréquentes', 'groups' => $by]);
    }
    /** Article lisible par l'utilisateur (publié et visible), ou null. */
    private function readable(string $id): ?array {
        $a = DB::one('SELECT a.*, c.name category FROM kb_articles a LEFT JOIN kb_categories c ON c.id=a.category_id WHERE a.id=?', [(int)$id]); if (!$a) return null;
        if ($a['status'] === 'published') return ($a['internal'] && !Kb::canInternal()) ? null : $a;
        return (can('kb.manage') || (can('kb.write') && (int)$a['author_id'] === Auth::id())) ? $a : null;   // brouillons : auteur et gestionnaires
    }
    function show(string $id): void {
        $a = $this->readable($id); if (!$a) { $this->notFound(); return; }
        if ($a['status'] === 'published') {
            if (empty($_SESSION['_kbv'][$a['id']])) { DB::pdo()->prepare('UPDATE kb_articles SET views=views+1 WHERE id=?')->execute([(int)$a['id']]); $_SESSION['_kbv'][$a['id']] = 1; }   // une vue par session
            try { if (!DB::val("SELECT 1 FROM kb_view_log WHERE kind='article' AND item_id=? AND user_id=? AND day=?", [(int)$a['id'], Auth::id(), date('Y-m-d')])) DB::insert('kb_view_log', ['kind' => 'article', 'item_id' => (int)$a['id'], 'user_id' => Auth::id(), 'day' => date('Y-m-d'), 'role_code' => (string)(Auth::roles()[0]['code'] ?? '')]); } catch (\Throwable $e) {}
        }
        [$w] = Kb::visible();
        $this->view('kb/show', ['title' => $a['title'], 'a' => $a, 'html' => Kb::render($a['body']), 'vote' => DB::val('SELECT useful FROM kb_votes WHERE article_id=? AND user_id=?', [(int)$id, Auth::id()]),
            'related' => $a['category_id'] ? DB::all("SELECT a.id, a.title FROM kb_articles a WHERE $w AND a.category_id=? AND a.id<>? ORDER BY a.useful DESC LIMIT 5", [(int)$a['category_id'], (int)$id]) : [],
            'canEdit' => $this->canEdit($a)]);
    }
    function vote(string $id): void {
        $a = $this->readable($id); if (!$a || $a['status'] !== 'published') { $this->notFound(); return; }
        $useful = $this->in('useful') === '1' ? 1 : 0; $old = DB::one('SELECT * FROM kb_votes WHERE article_id=? AND user_id=?', [(int)$id, Auth::id()]);
        if ($old) { if ((int)$old['useful'] === $useful) redirect("kb/a/$id"); DB::update('kb_votes', ['useful' => $useful, 'created_at' => now()], 'id=?', [(int)$old['id']]); }
        else DB::insert('kb_votes', ['article_id' => (int)$id, 'user_id' => Auth::id(), 'useful' => $useful, 'created_at' => now()]);
        DB::update('kb_articles', ['useful' => (int)DB::val('SELECT COUNT(*) FROM kb_votes WHERE article_id=? AND useful=1', [(int)$id]), 'useless' => (int)DB::val('SELECT COUNT(*) FROM kb_votes WHERE article_id=? AND useful=0', [(int)$id])], 'id=?', [(int)$id]);
        flash('Merci pour votre retour.'); redirect("kb/a/$id");
    }
    /** Suggestions pour un ticket en cours de saisie (JSON : titres et résumés d'articles publiés visibles). */
    function suggest(): void {
        $rows = array_map(fn($r) => ['id' => (int)$r['id'], 'title' => $r['title'], 'summary' => mb_substr((string)$r['summary'], 0, 140), 'url' => url('kb/a/' . $r['id'])], Kb::search((string)$this->in('q', ''), 4));
        header('Content-Type: application/json; charset=utf-8'); header('X-Content-Type-Options: nosniff'); echo json_encode($rows, JSON_UNESCAPED_UNICODE); exit;
    }
    function ask(): void {
        $t = trim((string)$this->in('text', '')); if ($t === '' || mb_strlen($t) > 500) { flash('Saisissez votre question (500 caractères maximum).', 'danger'); redirect('kb'); }
        if ((int)DB::val("SELECT COUNT(*) FROM kb_questions WHERE user_id=? AND status='open'", [Auth::id()]) >= 10) { flash('Vous avez déjà 10 questions en attente.', 'warning'); redirect('kb'); }
        $id = DB::insert('kb_questions', ['user_id' => Auth::id(), 'text' => $t, 'status' => 'open', 'created_at' => now()]);
        Notifier::toPermission('kb.manage', 'Nouvelle question à traiter', mb_substr($t, 0, 120), '/kb/questions'); Audit::log('create', 'kb_question', $id);
        flash('Votre question a été transmise : un article ou une FAQ pourra y répondre.'); redirect('kb');
    }

    // =============== Rédaction ===============
    private function canEdit(array $a): bool {
        if (can('kb.manage')) return true;
        return can('kb.write') && (int)$a['author_id'] === Auth::id() && in_array($a['status'], ['draft', 'rejected'], true);
    }
    private function mine(string $id): ?array {
        $a = DB::one('SELECT * FROM kb_articles WHERE id=?', [(int)$id]);
        if (!$a) { $this->notFound(); return null; } if (!$this->canEdit($a)) { $this->forbidden(); return null; } return $a;
    }
    function manage(): void {
        $w = ['1=1']; $p = [];
        if (!can('kb.manage')) { $w[] = "(a.author_id=? OR a.status='published')"; $p[] = Auth::id(); }
        foreach (['status' => 'a.status', 'kind' => 'a.kind', 'category' => 'a.category_id'] as $k => $col) if ($this->in($k) !== null && $this->in($k) !== '') { $w[] = "$col=?"; $p[] = $this->in($k); }
        if ($q = trim((string)$this->in('q', ''))) { $w[] = "(a.title LIKE ? OR a.tags LIKE ?)"; array_push($p, "%$q%", "%$q%"); }
        if ($this->in('stale') === '1') { $w[] = "a.status='published' AND a.review_due IS NOT NULL AND a.review_due<?"; $p[] = date('Y-m-d'); }
        $from = 'kb_articles a LEFT JOIN kb_categories c ON c.id=a.category_id LEFT JOIN users u ON u.id=a.author_id WHERE ' . implode(' AND ', $w);
        $this->view('kb/manage', ['title' => 'Gérer les articles', 'p' => paginate($from, $p, $this->page(), 25, 'a.*, c.name category, u.name author', 'a.updated_at DESC, a.id DESC'), 'cats' => DB::all('SELECT * FROM kb_categories ORDER BY sort_order, name'),
            'pending' => can('kb.manage') ? (int)DB::val("SELECT COUNT(*) FROM kb_articles WHERE status='pending'") : 0, 'stale' => (int)DB::val("SELECT COUNT(*) FROM kb_articles WHERE status='published' AND review_due IS NOT NULL AND review_due<?", [date('Y-m-d')])]);
    }
    function create(): void {
        $a = ['id' => null, 'kind' => $this->in('kind') === 'faq' ? 'faq' : 'article', 'title' => '', 'summary' => '', 'body' => '', 'category_id' => null, 'tags' => '', 'internal' => 0, 'status' => 'draft', 'review_due' => null, 'source_ticket_id' => null];
        if ($tid = (int)$this->in('from_ticket', 0)) {   // article tiré d'un ticket résolu (réservé au support)
            $t = can('at.handle') ? DB::one('SELECT * FROM at_tickets WHERE id=?', [$tid]) : null;
            if ($t) { $a['title'] = (string)$t['title']; $a['body'] = (string)($t['resolution'] ?? ''); $a['summary'] = ''; $a['internal'] = 1; $a['source_ticket_id'] = $tid; flash('Brouillon pré-rempli depuis le ticket ' . $t['reference'] . ' : relisez, anonymisez (noms, numéros) et reformulez avant de soumettre.', 'info'); }
        }
        if ($qid = (int)$this->in('from_question', 0)) { $q = can('kb.manage') ? DB::one('SELECT * FROM kb_questions WHERE id=?', [$qid]) : null; if ($q) { $a['title'] = (string)$q['text']; $a['kind'] = 'faq'; $a['from_question'] = $qid; } }
        $this->view('kb/edit', ['title' => 'Nouvel article', 'a' => $a, 'cats' => DB::all('SELECT * FROM kb_categories ORDER BY sort_order, name'), 'versions' => []]);
    }
    private function data(): array {
        [$d, $err] = $this->validate(['title' => ['label' => 'Le titre', 'req' => true, 'max' => 190], 'summary' => ['label' => 'Le résumé', 'max' => 300], 'body' => ['label' => 'Le contenu', 'req' => true, 'max' => 100000], 'tags' => ['label' => 'Les étiquettes', 'max' => 200], 'review_due' => ['label' => 'La date de révision', 'date' => true]], $_POST);
        if (!empty($d['body']) && \App\Core\Html::isHtml($d['body'])) { $d['body'] = \App\Core\Html::clean($d['body']); if (\App\Core\Html::text($d['body']) === '') $err['body'] = 'Le contenu est vide.'; }
        $cat = (int)$this->in('category_id', 0); if ($cat && !DB::val('SELECT 1 FROM kb_categories WHERE id=?', [$cat])) $cat = 0;
        return [$d + ['kind' => $this->in('kind') === 'faq' ? 'faq' : 'article', 'category_id' => $cat ?: null, 'internal' => $this->in('internal') === '1' ? 1 : 0, 'updated_at' => now()], $err];
    }
    function store(): void {
        [$d, $err] = $this->data(); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('kb/new'); }
        $src = (int)$this->in('source_ticket_id', 0); $q = (int)$this->in('from_question', 0);
        $id = DB::insert('kb_articles', $d + ['status' => 'draft', 'author_id' => Auth::id(), 'source_ticket_id' => $src ?: null, 'created_at' => now()]); Kb::snapshot($id, 'Création');
        if ($q && can('kb.manage')) DB::update('kb_questions', ['status' => 'answered', 'article_id' => $id, 'handled_by' => Auth::id(), 'handled_at' => now()], 'id=? AND status=\'open\'', [$q]);
        Audit::log('create', 'kb_article', $id, null, ['title' => $d['title']]); flash('Brouillon enregistré. Soumettez-le à la relecture quand il est prêt.'); redirect("kb/a/$id/edit");
    }
    function edit(string $id): void {
        if (!($a = $this->mine($id))) return;
        $this->view('kb/edit', ['title' => 'Modifier : ' . $a['title'], 'a' => $a, 'cats' => DB::all('SELECT * FROM kb_categories ORDER BY sort_order, name'), 'versions' => DB::all('SELECT id, version, user_name, note, created_at FROM kb_versions WHERE article_id=? ORDER BY version DESC', [(int)$id])]);
    }
    function update(string $id): void {
        if (!($a = $this->mine($id))) return; [$d, $err] = $this->data(); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("kb/a/$id/edit"); }
        if ($a['status'] === 'rejected') $d['status'] = 'draft';
        $d['search_norm'] = null; DB::update('kb_articles', $d, 'id=?', [(int)$id]); Kb::snapshot((int)$id, trim((string)$this->in('note', '')) ?: 'Modification'); Audit::log('update', 'kb_article', $id, ['title' => $a['title']], ['title' => $d['title']]);
        flash('Article enregistré' . ($a['status'] === 'published' ? ' (version publiée mise à jour).' : '.')); redirect("kb/a/$id/edit");
    }
    function status(string $id): void {
        $a = DB::one('SELECT * FROM kb_articles WHERE id=?', [(int)$id]); if (!$a) { $this->notFound(); return; }
        $act = (string)$this->in('action'); $mgr = can('kb.manage'); $own = can('kb.write') && (int)$a['author_id'] === Auth::id(); $u = ['updated_at' => now()]; $note = trim((string)$this->in('note', ''));
        if ($act === 'submit' && ($own || $mgr) && in_array($a['status'], ['draft', 'rejected'], true)) {
            $u['status'] = 'pending'; $u['review_note'] = null; Notifier::toPermission('kb.manage', 'Article à relire', $a['title'], '/kb/a/' . $id); $m = 'Soumis à la relecture.';
        } elseif ($act === 'publish' && $mgr && in_array($a['status'], ['pending', 'draft', 'rejected'], true)) {
            if ((int)$a['author_id'] === Auth::id() && $a['status'] === 'pending' && !can('admin.access') && (string)setting('kb_four_eyes', '0') === '1') { flash('La relecture doit être faite par une autre personne que l\'auteur.', 'warning'); redirect("kb/a/$id"); }
            $due = (string)$this->in('review_due', ''); if ($due !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $due)) { flash('Date de révision invalide.', 'danger'); redirect("kb/a/$id"); }
            $u += ['status' => 'published', 'reviewer_id' => Auth::id(), 'review_note' => null, 'published_at' => now(), 'review_due' => $due ?: date('Y-m-d', strtotime('+' . Kb::months() . ' months')), 'review_notified_at' => null];
            if ($a['author_id'] && (int)$a['author_id'] !== Auth::id()) Notifier::send((int)$a['author_id'], 'Article publié', $a['title'], '/kb/a/' . $id); foreach (DB::all("SELECT user_id FROM kb_questions WHERE article_id=? AND status='answered'", [(int)$id]) as $qq) Notifier::send((int)$qq['user_id'], 'Votre question a une réponse', $a['title'], '/kb/a/' . $id); $m = 'Article publié.';
        } elseif ($act === 'reject' && $mgr && $a['status'] === 'pending') {
            if ($note === '') { flash('Indiquez ce qu\'il faut corriger.', 'danger'); redirect("kb/a/$id"); }
            $u += ['status' => 'rejected', 'review_note' => mb_substr($note, 0, 500), 'reviewer_id' => Auth::id()]; if ($a['author_id']) Notifier::send((int)$a['author_id'], 'Article à corriger', $a['title'] . ' : ' . mb_substr($note, 0, 100), '/kb/a/' . $id . '/edit'); $m = 'Renvoyé à l\'auteur.';
        } elseif ($act === 'archive' && $mgr && $a['status'] !== 'archived') { $u['status'] = 'archived'; $m = 'Article archivé (plus visible des lecteurs).'; }
        elseif ($act === 'unpublish' && $mgr && $a['status'] === 'published') { $u['status'] = 'draft'; $m = 'Article dépublié (repassé en brouillon).'; }
        elseif ($act === 'restore' && $mgr && $a['status'] === 'archived') { $u['status'] = 'draft'; $m = 'Article restauré en brouillon.'; }
        else { $this->forbidden(); return; }
        DB::update('kb_articles', $u, 'id=?', [(int)$id]); Audit::log($act, 'kb_article', $id, ['status' => $a['status']], ['status' => $u['status']]); flash($m); redirect("kb/a/$id");
    }
    function versions(string $id): void {
        $a = DB::one('SELECT * FROM kb_articles WHERE id=?', [(int)$id]); if (!$a) { $this->notFound(); return; }
        if (!can('kb.manage') && !(can('kb.write') && (int)$a['author_id'] === Auth::id())) { $this->forbidden(); return; }
        $vs = DB::all('SELECT * FROM kb_versions WHERE article_id=? ORDER BY version DESC', [(int)$id]); $sel = (int)$this->in('v', 0);
        $this->view('kb/versions', ['title' => 'Historique : ' . $a['title'], 'a' => $a, 'vs' => $vs, 'cur' => $sel ? DB::one('SELECT * FROM kb_versions WHERE article_id=? AND version=?', [(int)$id, $sel]) : null, 'html' => '']);
    }
    function restore(string $id, string $v): void {
        if (!($a = $this->mine($id))) return; $x = DB::one('SELECT * FROM kb_versions WHERE article_id=? AND version=?', [(int)$id, (int)$v]); if (!$x) { $this->notFound(); return; }
        DB::update('kb_articles', ['title' => $x['title'], 'summary' => $x['summary'], 'body' => $x['body'], 'search_norm' => null, 'updated_at' => now()], 'id=?', [(int)$id]); Kb::snapshot((int)$id, 'Restauration de la version ' . (int)$v);
        Audit::log('restore', 'kb_article', $id, null, ['version' => (int)$v]); flash('Version ' . (int)$v . ' restaurée.'); redirect("kb/a/$id/edit");
    }

    // =============== Gestion (kb.manage) ===============
    function categories(): void { $this->view('kb/categories', ['title' => 'Catégories', 'rows' => DB::all('SELECT c.*, (SELECT COUNT(*) FROM kb_articles a WHERE a.category_id=c.id) n FROM kb_categories c ORDER BY c.sort_order, c.name')]); }
    function saveCategory(): void {
        $name = trim((string)$this->in('name', '')); $id = (int)$this->in('id', 0); $sort = max(0, min(999, (int)$this->in('sort_order', 0)));
        if ($name === '' || mb_strlen($name) > 100) { flash('Nom obligatoire (100 caractères maximum).', 'danger'); redirect('kb/categories'); }
        if (DB::val('SELECT 1 FROM kb_categories WHERE name=? AND id<>?', [$name, $id])) { flash('Cette catégorie existe déjà.', 'danger'); redirect('kb/categories'); }
        if ($id && DB::val('SELECT 1 FROM kb_categories WHERE id=?', [$id])) DB::update('kb_categories', ['name' => $name, 'sort_order' => $sort], 'id=?', [$id]); else $id = DB::insert('kb_categories', ['name' => $name, 'sort_order' => $sort]);
        Audit::log('save', 'kb_category', $id, null, ['name' => $name]); flash('Catégorie enregistrée.'); redirect('kb/categories');
    }
    function deleteCategory(string $id): void {
        if (DB::val('SELECT 1 FROM kb_articles WHERE category_id=?', [(int)$id])) { flash('Catégorie utilisée par des articles : déplacez-les d\'abord.', 'danger'); redirect('kb/categories'); }
        DB::pdo()->prepare('DELETE FROM kb_categories WHERE id=?')->execute([(int)$id]); Audit::log('delete', 'kb_category', $id); flash('Catégorie supprimée.'); redirect('kb/categories');
    }
    function questions(): void {
        $this->view('kb/questions', ['title' => 'Questions reçues', 'rows' => DB::all("SELECT q.*, u.name uname FROM kb_questions q LEFT JOIN users u ON u.id=q.user_id ORDER BY CASE q.status WHEN 'open' THEN 0 ELSE 1 END, q.id DESC LIMIT 100")]);
    }
    function dismissQuestion(string $id): void {
        $q = DB::one('SELECT * FROM kb_questions WHERE id=?', [(int)$id]); if (!$q) { $this->notFound(); return; }
        DB::update('kb_questions', ['status' => 'dismissed', 'handled_by' => Auth::id(), 'handled_at' => now()], 'id=?', [(int)$id]); Audit::log('dismiss', 'kb_question', $id); flash('Question classée.'); redirect('kb/questions');
    }
}
