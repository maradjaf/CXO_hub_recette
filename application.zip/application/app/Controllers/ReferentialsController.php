<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Importer};
class ReferentialsController extends Controller {
    function index(): void {
        $rows = DB::all('SELECT l.*, (SELECT COUNT(*) FROM ref_values v WHERE v.list_id=l.id) n FROM ref_lists l ORDER BY l.module, l.label');
        $this->view('admin/referentials/index', ['title' => 'Référentiels', 'rows' => $rows]);
    }
    function store(): void {
        [$d, $err] = $this->validate(['code' => ['label' => 'Le code', 'req' => true, 'max' => 80], 'label' => ['label' => 'Le libellé', 'req' => true, 'max' => 150], 'module' => ['label' => 'Le module', 'max' => 60]], $_POST);
        if ($d['code'] && !preg_match('/^[a-z0-9_]+$/', $d['code'])) $err['code'] = 'Code en minuscules, chiffres et _ uniquement.';
        if ($d['code'] && DB::val('SELECT 1 FROM ref_lists WHERE code=?', [$d['code']])) $err['code'] = 'Ce code existe déjà.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('admin/referentials'); }
        $d['active'] = 1; $id = DB::insert('ref_lists', $d); Audit::log('create', 'ref_list', $id, null, $d);
        flash('Liste créée.'); redirect("admin/referentials/$id");
    }
    function show(string $id): void {
        $l = DB::one('SELECT * FROM ref_lists WHERE id=?', [(int)$id]); if (!$l) { $this->notFound(); return; }
        $this->view('admin/referentials/show', ['title' => $l['label'], 'l' => $l, 'values' => DB::all('SELECT * FROM ref_values WHERE list_id=? ORDER BY sort_order, label', [(int)$id])]);
    }
    private function vdata(int $lid, ?int $vid): array {
        [$d, $err] = $this->validate(['code' => ['label' => 'Le code', 'req' => true, 'max' => 80], 'label' => ['label' => 'Le libellé', 'req' => true, 'max' => 190], 'color' => ['label' => 'La couleur', 'max' => 20]], $_POST);
        $d['sort_order'] = (int)$this->in('sort_order', 0); $d['active'] = isset($_POST['active']) ? 1 : 0;
        if ($d['code'] && DB::val('SELECT 1 FROM ref_values WHERE list_id=? AND code=? AND id<>?', [$lid, $d['code'], $vid ?? 0])) $err['code'] = 'Ce code existe déjà dans la liste.';
        return [$d, $err];
    }
    function storeValue(string $id): void {
        [$d, $err] = $this->vdata((int)$id, null);
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("admin/referentials/$id"); }
        $d['list_id'] = (int)$id; $vid = DB::insert('ref_values', $d); Audit::log('create', 'ref_value', $vid, null, $d);
        flash('Valeur ajoutée.'); redirect("admin/referentials/$id");
    }
    function updateValue(string $id, string $vid): void {
        $old = DB::one('SELECT * FROM ref_values WHERE id=? AND list_id=?', [(int)$vid, (int)$id]); if (!$old) { $this->notFound(); return; }
        [$d, $err] = $this->vdata((int)$id, (int)$vid);
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("admin/referentials/$id"); }
        DB::update('ref_values', $d, 'id=?', [(int)$vid]); Audit::log('update', 'ref_value', $vid, $old, $d);
        flash('Valeur modifiée.'); redirect("admin/referentials/$id");
    }
    /** Modèle CSV à remplir pour l'import des valeurs d'un référentiel. */
    function template(string $id): void {
        $l = DB::one('SELECT * FROM ref_lists WHERE id=?', [(int)$id]); if (!$l) { $this->notFound(); return; }
        csv_download('modele-referentiel-' . $l['code'] . '.csv', ['code', 'label', 'sort_order', 'color'], [['CODE_1', 'Libellé de la première valeur', 10, '#003A84'], ['CODE_2', 'Libellé de la deuxième valeur', 20, '']]);
    }
    function importValues(string $id): void {
        $l = DB::one('SELECT * FROM ref_lists WHERE id=?', [(int)$id]); if (!$l) { $this->notFound(); return; }
        $f = $_FILES['file'] ?? null;
        if (!$f || $f['error'] !== UPLOAD_ERR_OK) { flash('Choisissez un fichier CSV (colonnes code, label, sort_order, color).', 'danger'); redirect("admin/referentials/$id"); }
        [$head, $rows] = Importer::parse($f['tmp_name']); $ok = 0; $ko = 0;
        foreach ($rows as $r) {
            $data = $r['data'] + ['list_code' => $l['code']]; $data['list_code'] = $l['code'];
            [$n, $err] = Importer::check('ref_values', $data);
            if ($err) { $ko++; continue; } Importer::save('ref_values', $n); $ok++;
        }
        Audit::log('import', 'ref_list', $id, null, ['file' => $f['name'], 'ok' => $ok, 'rejected' => $ko]);
        flash("Import : $ok valeur(s) intégrée(s), $ko rejetée(s).", $ko ? 'warning' : 'success'); redirect("admin/referentials/$id");
    }
    function export(string $id): void {
        $l = DB::one('SELECT * FROM ref_lists WHERE id=?', [(int)$id]); if (!$l) { $this->notFound(); return; }
        csv_download('referentiel_' . $l['code'] . '.csv', ['code', 'label', 'sort_order', 'color', 'active'], DB::all('SELECT code, label, sort_order, color, active FROM ref_values WHERE list_id=? ORDER BY sort_order, label', [(int)$id]));
    }
}
