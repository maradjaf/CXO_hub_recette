<?php
namespace App\Controllers;
use App\Core\{Controller, DB};
class AdminController extends Controller {
    function index(): void {
        $cards = [
            ['Utilisateurs', '/admin/users', 'users.view', (int)DB::val('SELECT COUNT(*) FROM users') . ' comptes'],
            ['Rôles et droits', '/admin/roles', 'roles.view', (int)DB::val('SELECT COUNT(*) FROM roles') . ' rôles'],
            ['Historique d\'activité', '/admin/activity', 'activity.view', 'Menus, pages, actions, IP, lieu'],
            ['Journal d\'audit', '/admin/audit', 'audit.view', 'Modifications de données'],
            ['Référentiels', '/admin/referentials', 'referentials.view', (int)DB::val('SELECT COUNT(*) FROM ref_lists') . ' listes'],
            ['Menus', '/admin/menus', 'menus.manage', 'Organisation de la navigation'],
            ['Paramètres', '/admin/settings', 'settings.manage', 'Marque, sécurité, conservation'],
            ['Exploitation', '/admin/system', 'sys.view', 'Santé, tâches, sauvegardes, sessions'],
            ['Assistant', '/bot/stats', 'bot.manage', 'Statistiques d\'usage, lacunes, images'],
            ['Imports', '/imports', 'imports.run', 'Fichiers CSV'],
        ];
        $this->view('admin/index', ['title' => 'Administration', 'cards' => array_values(array_filter($cards, fn($c) => can($c[2])))]);
    }
}
