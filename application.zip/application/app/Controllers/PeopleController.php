<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Auth};

/** Recherche de personnes pour les sélecteurs de participants (réunions, discussions). Renvoie uniquement nom et fonction/e-mail des utilisateurs actifs. */
class PeopleController extends Controller {
    private function json($d): never { header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store'); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
    private function row(array $r): array { return ['id' => (int)$r['id'], 'name' => $r['name'], 'sub' => (string)($r['sub'] ?? '')]; }
    function search(): void {
        $q = trim((string)($_GET['q'] ?? '')); if (mb_strlen($q) < 2) $this->json([]); $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], $q) . '%';
        $rows = DB::all("SELECT u.id, u.name, COALESCE(NULLIF(e.job_function,''), u.email) sub FROM users u LEFT JOIN employees e ON e.id=u.employee_id WHERE u.status='active' AND (u.name LIKE ? ESCAPE '\\' OR u.email LIKE ? ESCAPE '\\') ORDER BY u.name LIMIT 15", [$like, $like]);
        $this->json(array_map([$this, 'row'], $rows));
    }
    function groups(): void {
        $this->json(['teams' => array_map(fn($r) => ['id' => (int)$r['id'], 'name' => $r['name']], DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name')),
                     'stores' => array_map(fn($r) => ['id' => (int)$r['id'], 'name' => $r['name']], DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name'))]);
    }
    function group(string $kind, string $id): void {
        $col = $kind === 'store' ? 'e.store_id' : ($kind === 'team' ? 'e.team_id' : null); if (!$col) $this->json([]);
        $rows = DB::all("SELECT u.id, u.name, u.email sub FROM users u JOIN employees e ON e.id=u.employee_id WHERE u.status='active' AND $col=? ORDER BY u.name LIMIT 300", [(int)$id]);
        $this->json(array_map([$this, 'row'], $rows));
    }
}
