<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Bulk};
/** Départ d'un collaborateur : liste de tâches (restitution, accès, solde, entretien…), puis clôture qui marque le collaborateur « Sorti » et désactive son compte. */
class OffboardingController extends Controller {
    const TYPES = ['resignation' => 'Démission', 'dismissal' => 'Licenciement', 'end_contract' => 'Fin de contrat', 'retirement' => 'Retraite', 'mutual' => 'Rupture conventionnelle', 'other' => 'Autre'];
    const STATUS = ['open' => 'En cours', 'closed' => 'Clôturé', 'cancelled' => 'Annulé'];
    const TASKS = [['Entretien de sortie', 'hr', -3], ['Passation et transfert des dossiers en cours', 'manager', -3], ['Restitution du matériel, badge et équipements', 'tech', 0], ['Retrait des plannings et des équipes', 'manager', 0], ['Désactivation des accès et des comptes', 'admin', 0], ['Solde de tout compte et attestations', 'hr', 2], ['Certificat de travail remis', 'hr', 2]];
    private function mayWork(array $t): bool { return can('offboarding.manage') || ($t['owner_role'] && in_array($t['owner_role'], array_column(Auth::roles(), 'code'), true)); }
    private function where(): array {
        $w = ['1=1']; $p = [];
        $st = (string)$this->in('status', 'open'); if (isset(self::STATUS[$st])) { $w[] = 'c.status=?'; $p[] = $st; }
        if (isset(self::TYPES[(string)$this->in('type', '')])) { $w[] = 'c.exit_type=?'; $p[] = $this->in('type'); }
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(e.first_name LIKE ? OR e.last_name LIKE ? OR e.matricule LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        if ($this->in('from')) { $w[] = 'c.exit_date>=?'; $p[] = $this->in('from'); } if ($this->in('to')) { $w[] = 'c.exit_date<=?'; $p[] = $this->in('to'); }
        return [implode(' AND ', $w), $p];
    }
    private const FROM = 'offboarding_cases c JOIN employees e ON e.id=c.employee_id';
    function index(): void {
        [$w, $p] = $this->where();
        $pg = paginate(self::FROM . " WHERE $w", $p, $this->page(), 25, "c.*, e.first_name, e.last_name, e.matricule, (SELECT COUNT(*) FROM offboarding_tasks t WHERE t.case_id=c.id) total, (SELECT COUNT(*) FROM offboarding_tasks t WHERE t.case_id=c.id AND t.status='done') done", 'c.exit_date DESC, c.id DESC');
        $this->view('offboarding/index', ['title' => 'Départs', 'p' => $pg, 'types' => self::TYPES, 'statuses' => self::STATUS,
            'employees' => can('offboarding.manage') ? DB::all("SELECT id, first_name, last_name, matricule FROM employees WHERE status<>'left' ORDER BY last_name, first_name") : []]);
    }
    function export(): void {
        [$w, $p] = $this->where();
        $rows = DB::all("SELECT e.matricule, e.last_name, e.first_name, c.exit_type, c.exit_date, c.reason, c.status, (SELECT COUNT(*) FROM offboarding_tasks t WHERE t.case_id=c.id AND t.status='done') done, (SELECT COUNT(*) FROM offboarding_tasks t WHERE t.case_id=c.id) total FROM " . self::FROM . " WHERE $w ORDER BY c.exit_date DESC LIMIT 20000", $p);
        foreach ($rows as &$r) { $r['exit_type'] = self::TYPES[$r['exit_type']] ?? $r['exit_type']; $r['status'] = self::STATUS[$r['status']] ?? $r['status']; $r['done'] = $r['done'] . '/' . $r['total']; unset($r['total']); } unset($r);
        Audit::log('export', 'offboarding', null, null, ['rows' => count($rows)]);
        csv_download('departs_' . date('Ymd') . '.csv', ['Matricule', 'Nom', 'Prénom', 'Type', 'Date de départ', 'Motif', 'Statut', 'Tâches faites'], $rows);
    }
    /** Ouvre un départ (null si le collaborateur en a déjà un ouvert ou n'existe plus). */
    static function open(int $empId, string $type, string $date, ?string $reason, array &$roles): ?int {
        $emp = DB::one("SELECT * FROM employees WHERE id=? AND status<>'left'", [$empId]); if (!$emp || DB::val("SELECT 1 FROM offboarding_cases WHERE employee_id=? AND status='open'", [$empId])) return null;
        $case = DB::insert('offboarding_cases', ['employee_id' => $empId, 'exit_type' => $type, 'exit_date' => $date, 'reason' => $reason ? mb_substr($reason, 0, 300) : null, 'status' => 'open', 'created_by' => Auth::id(), 'created_at' => now()]);
        foreach (self::TASKS as $i => [$title, $role, $off]) { DB::insert('offboarding_tasks', ['case_id' => $case, 'position' => $i + 1, 'title' => $title, 'owner_role' => $role, 'due_date' => date('Y-m-d', strtotime("$date $off days")), 'status' => 'todo']); $roles[$role] = true; }
        Audit::log('create', 'offboarding_case', $case, null, ['employee_id' => $empId, 'type' => $type, 'date' => $date]);
        return $case;
    }
    static function tell(array $roles, string $body, string $url): void {
        foreach (array_keys($roles) as $role) foreach (DB::all('SELECT ur.user_id FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE r.code=?', [$role]) as $u) Notifier::send((int)$u['user_id'], 'Départ à préparer', $body, $url);
    }
    function start(): void {
        $emp = DB::one("SELECT * FROM employees WHERE id=? AND status<>'left'", [(int)$this->in('employee_id')]); $type = (string)$this->in('exit_type'); $date = (string)$this->in('exit_date');
        if (!$emp || !isset(self::TYPES[$type]) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) { flash('Collaborateur, type et date de départ valides requis.', 'danger'); redirect('offboarding'); }
        $roles = []; $case = self::open((int)$emp['id'], $type, $date, trim((string)$this->in('reason', '')) ?: null, $roles);
        if (!$case) { flash('Un départ est déjà en cours pour ce collaborateur.', 'warning'); redirect('offboarding'); }
        self::tell($roles, $emp['first_name'] . ' ' . $emp['last_name'] . ' quitte l\'entreprise le ' . date('d/m/Y', strtotime($date)) . '.', '/offboarding/' . $case);
        flash('Départ lancé : la liste des tâches est créée.'); redirect("offboarding/$case");
    }
    function bulkForm(): void {
        $this->view('bulk/launch', ['title' => 'Lancer des départs en masse', 'kind' => 'offboarding', 'action' => 'offboarding/bulk', 'back' => 'offboarding', 'templates' => [], 'types' => self::TYPES,
            'employees' => Bulk::candidates("e.status<>'left' AND NOT EXISTS (SELECT 1 FROM offboarding_cases c WHERE c.employee_id=e.id AND c.status='open')")]);
    }
    function bulk(): void {
        $type = (string)$this->in('exit_type'); $date = (string)$this->in('exit_date');
        if (!isset(self::TYPES[$type]) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) { flash('Type et date de départ valides requis.', 'danger'); redirect('offboarding/bulk'); }
        [$ids, $unknown] = Bulk::ids($_POST); $roles = []; $ok = 0; $skip = 0; $why = trim((string)$this->in('reason', '')) ?: null;
        foreach ($ids as $emp) { if (self::open($emp, $type, $date, $why, $roles)) $ok++; else $skip++; }
        self::tell($roles, $ok . ' départ(s) à préparer pour le ' . date('d/m/Y', strtotime($date)) . '.', '/offboarding');
        Audit::log('bulk', 'offboarding_case', null, null, ['created' => $ok, 'skipped' => $skip, 'unknown' => count($unknown)]);
        flash(Bulk::report($ok, $skip, $unknown, 'départ(s) lancé(s)'), $ok ? 'success' : 'warning'); redirect('offboarding');
    }
    function show(string $id): void {
        $c = DB::one('SELECT c.*, e.first_name, e.last_name, e.matricule, u.name by_name FROM ' . self::FROM . ' LEFT JOIN users u ON u.id=c.created_by WHERE c.id=?', [(int)$id]); if (!$c) { $this->notFound(); return; }
        $tasks = DB::all('SELECT t.*, u.name done_name FROM offboarding_tasks t LEFT JOIN users u ON u.id=t.done_by WHERE t.case_id=? ORDER BY t.position', [(int)$id]);
        foreach ($tasks as &$t) $t['may'] = $c['status'] === 'open' && $this->mayWork($t); unset($t);
        $this->view('offboarding/show', ['title' => 'Départ · ' . $c['first_name'] . ' ' . $c['last_name'], 'c' => $c, 'tasks' => $tasks, 'types' => self::TYPES, 'statuses' => self::STATUS, 'roleNames' => array_column(DB::all('SELECT code, name FROM roles'), 'name', 'code')]);
    }
    function completeTask(string $id, string $tid): void {
        $c = DB::one('SELECT * FROM offboarding_cases WHERE id=?', [(int)$id]); $t = DB::one('SELECT * FROM offboarding_tasks WHERE id=? AND case_id=?', [(int)$tid, (int)$id]); if (!$c || !$t) { $this->notFound(); return; }
        if ($c['status'] !== 'open' || !$this->mayWork($t)) { $this->forbidden(); return; }
        $undo = $t['status'] === 'done';
        DB::update('offboarding_tasks', $undo ? ['status' => 'todo', 'done_at' => null, 'done_by' => null, 'note' => null] : ['status' => 'done', 'done_at' => now(), 'done_by' => Auth::id(), 'note' => mb_substr(trim((string)$this->in('note', '')), 0, 500) ?: null], 'id=?', [(int)$tid]);
        Audit::log($undo ? 'reopen_task' : 'complete_task', 'offboarding_task', $tid, ['status' => $t['status']]);
        flash($undo ? 'Tâche rouverte.' : 'Tâche terminée.'); redirect("offboarding/$id");
    }
    /** Clôture : toutes les tâches faites, le collaborateur passe à « Sorti » et son compte est désactivé. */
    function close(string $id): void {
        $c = DB::one('SELECT * FROM offboarding_cases WHERE id=?', [(int)$id]); if (!$c) { $this->notFound(); return; }
        if ($c['status'] !== 'open') { redirect("offboarding/$id"); }
        if ((int)DB::val("SELECT COUNT(*) FROM offboarding_tasks WHERE case_id=? AND status='todo'", [(int)$id])) { flash('Terminez d\'abord toutes les tâches du départ.', 'danger'); redirect("offboarding/$id"); }
        DB::update('offboarding_cases', ['status' => 'closed', 'closed_at' => now(), 'closed_by' => Auth::id()], 'id=?', [(int)$id]);
        DB::update('employees', ['status' => 'left', 'updated_at' => now()], 'id=?', [(int)$c['employee_id']]);
        DB::exec('UPDATE users SET status=? WHERE employee_id=? AND status<>?', ['inactive', (int)$c['employee_id'], 'blocked']);
        DB::exec('UPDATE employee_assignments SET valid_to=? WHERE employee_id=? AND valid_to IS NULL', [$c['exit_date'], (int)$c['employee_id']]);
        Audit::log('close', 'offboarding_case', $id, $c, ['status' => 'closed']); flash('Départ clôturé : collaborateur marqué « Sorti », compte désactivé.'); redirect("offboarding/$id");
    }
    function cancel(string $id): void {
        $c = DB::one('SELECT * FROM offboarding_cases WHERE id=?', [(int)$id]); if (!$c) { $this->notFound(); return; }
        if ($c['status'] === 'open') { DB::update('offboarding_cases', ['status' => 'cancelled', 'closed_at' => now(), 'closed_by' => Auth::id()], 'id=?', [(int)$id]); Audit::log('cancel', 'offboarding_case', $id, $c); flash('Départ annulé.'); }
        redirect("offboarding/$id");
    }
}
