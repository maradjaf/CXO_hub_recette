<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Tc, Xchg};

/** Discussions : conversations individuelles et groupes. */
class TcController extends Controller {
    private function json($d, int $code = 200): never { http_response_code($code); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store'); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
    private function gate(): int { if (!Tc::on()) $this->json(['error' => 'Les discussions sont désactivées.'], 404); return (int)Auth::id(); }
    /** @return array{0:array,1:array} conversation, mon appartenance */
    private function chat(string $id, bool $write = false): array {
        $me = $this->gate(); $c = DB::one('SELECT * FROM tc_chats WHERE id=?', [(int)$id]); $mb = $c ? Tc::member((int)$id, $me) : null; if (!$c || !$mb) $this->json(['error' => 'Conversation introuvable.'], 404);
        if ($write && $c['archived']) $this->json(['error' => 'Cette conversation est archivée.'], 403); return [$c, $mb];
    }
    function home(?string $id = null): void {
        if (!Tc::on()) { $this->notFound(); return; } $me = (int)Auth::id(); $cur = 0; if ($id !== null) { if (!Tc::member((int)$id, $me)) { $this->notFound(); return; } $cur = (int)$id; }
        $this->view('tc/index', ['title' => 'Discussions', 'cur' => $cur, 'me' => $me, 'cfg' => ['poll' => Xchg::int('tc.poll_sec', 2, 120), 'wait' => Xchg::int('tc.longpoll', 0, 30), 'max' => Xchg::int('tc.max_len', 100, 10000), 'groups' => Xchg::on('tc.allow_groups'), 'files' => Xchg::on('tc.files'), 'react' => Xchg::on('tc.reactions'), 'filemb' => Xchg::int('tc.file_max_mb', 1, 100)]]);
    }
    function unread(): void { $me = $this->gate(); Tc::seen($me); $this->json(['n' => Tc::unread($me)]); }
    function list(): void {
        $me = $this->gate(); Tc::seen($me); $q = mb_strtolower(trim((string)($_GET['q'] ?? ''))); $out = [];
        $rows = DB::all("SELECT c.*, mb.pinned, mb.muted, mb.last_read_id, (SELECT COUNT(*) FROM tc_messages m WHERE m.chat_id=c.id AND m.id>mb.last_read_id AND m.kind='msg' AND m.user_id<>? AND m.deleted_at IS NULL) unread,
            (SELECT MAX(id) FROM tc_messages x WHERE x.chat_id=c.id AND x.deleted_at IS NULL) last_id FROM tc_chats c JOIN tc_members mb ON mb.chat_id=c.id AND mb.user_id=? AND mb.left_at IS NULL WHERE c.archived=0 ORDER BY mb.pinned DESC, c.last_at DESC LIMIT 300", [$me, $me]);
        $peers = []; foreach ($rows as $c) if ($c['kind'] === 'direct') { $p = (int)DB::val('SELECT user_id FROM tc_members WHERE chat_id=? AND user_id<>?', [(int)$c['id'], $me]); if ($p) $peers[(int)$c['id']] = $p; } $on = Tc::online(array_values($peers));
        foreach ($rows as $c) {
            $t = Tc::title($c, $me); if ($q !== '' && !str_contains(mb_strtolower($t), $q)) continue; $last = $c['last_id'] ? DB::one('SELECT user_id, user_name, body, kind, file_name FROM tc_messages WHERE id=?', [(int)$c['last_id']]) : null;
            $pv = $last ? ($last['kind'] === 'system' ? $last['body'] : (($last['user_id'] == $me ? 'Vous : ' : ($c['kind'] === 'group' ? $last['user_name'] . ' : ' : '')) . ($last['body'] !== '' && $last['body'] !== null ? $last['body'] : '📎 ' . $last['file_name']))) : 'Aucun message';
            $out[] = ['id' => (int)$c['id'], 'kind' => $c['kind'], 'title' => $t, 'unread' => $c['muted'] ? 0 : (int)$c['unread'], 'has_unread' => (int)$c['unread'] > 0, 'preview' => mb_substr(preg_replace('/\s+/', ' ', (string)$pv), 0, 70), 'at' => $this->when($c['last_at']), 'pinned' => (bool)$c['pinned'], 'muted' => (bool)$c['muted'], 'online' => isset($peers[(int)$c['id']]) && in_array($peers[(int)$c['id']], $on, true)];
        }
        $this->json(['chats' => $out, 'unread' => Tc::unread($me)]);
    }
    private function when(?string $t): string { if (!$t) return ''; $s = strtotime($t); return date('Y-m-d', $s) === date('Y-m-d') ? date('H:i', $s) : (date('Y-m-d', $s) === date('Y-m-d', strtotime('-1 day')) ? 'Hier' : date('d/m', $s)); }
    private function shape(array $m, array $reacts, array $chat, array $mb, int $me): array {
        $age = (time() - strtotime($m['created_at'])) / 60; $del = !empty($m['deleted_at']); $own = (int)$m['user_id'] === $me; $win = $age <= Xchg::int('tc.edit_min', 0, 1440); $adm = in_array($mb['role'], ['owner', 'admin'], true) && $chat['kind'] === 'group';
        $rp = null; if ($m['reply_to']) { $r = DB::one('SELECT user_name, body, deleted_at, file_name FROM tc_messages WHERE id=?', [(int)$m['reply_to']]); if ($r) $rp = ['id' => (int)$m['reply_to'], 'user' => $r['user_name'], 'body' => $r['deleted_at'] ? 'Message supprimé' : mb_substr((string)($r['body'] !== '' && $r['body'] !== null ? $r['body'] : '📎 ' . $r['file_name']), 0, 100)]; }
        $img = $m['file_mime'] && str_starts_with((string)$m['file_mime'], 'image/');
        return ['id' => (int)$m['id'], 'uid' => (int)$m['user_id'], 'user' => $m['user_name'], 'mine' => $own, 'kind' => $m['kind'], 'body' => $del ? '' : (string)$m['body'], 'deleted' => $del, 'edited' => !empty($m['edited_at']), 'at' => date('H:i', strtotime($m['created_at'])), 'day' => date('Y-m-d', strtotime($m['created_at'])), 'reply' => $rp,
            'file' => !$del && $m['file_stored'] ? ['name' => $m['file_name'], 'size' => (int)$m['file_size'], 'image' => $img, 'url' => url('tc/file/' . $m['id'])] : null, 'reactions' => $reacts[(int)$m['id']] ?? [],
            'can_edit' => $own && !$del && $m['kind'] === 'msg' && $win && $m['body'] !== null && $m['body'] !== '', 'can_del' => !$del && $m['kind'] === 'msg' && (($own && $win) || $adm)];
    }
    private function reactions(array $ids, int $me): array {
        if (!$ids) return []; $in = implode(',', array_fill(0, count($ids), '?')); $o = [];
        foreach (DB::all("SELECT r.message_id, r.emoji, r.user_id, u.name FROM tc_reactions r JOIN users u ON u.id=r.user_id WHERE r.message_id IN ($in) ORDER BY r.id", $ids) as $r) { $e = &$o[(int)$r['message_id']][$r['emoji']]; $e ??= ['emoji' => $r['emoji'], 'n' => 0, 'mine' => false, 'names' => []]; $e['n']++; $e['names'][] = $r['name']; if ((int)$r['user_id'] === $me) $e['mine'] = true; unset($e); }
        foreach ($o as &$l) $l = array_values($l); unset($l); return $o;
    }
    /** Attente longue : la réponse part dès qu'il y a du nouveau (message, modification, réaction, lecture) ou au bout de $wait secondes. La session est libérée pour ne pas bloquer les autres requêtes de l'utilisateur. */
    private function hold(int $id, int $after, int $wait): void {
        if (session_status() === PHP_SESSION_ACTIVE) session_write_close(); @set_time_limit($wait + 20);
        $sig = fn() => (int)DB::val('SELECT MAX(id) FROM tc_messages WHERE chat_id=?', [$id]) . '|' . DB::val('SELECT MAX(edited_at) FROM tc_messages WHERE chat_id=?', [$id]) . '|' . DB::val('SELECT MAX(deleted_at) FROM tc_messages WHERE chat_id=?', [$id])
            . '|' . DB::val('SELECT COUNT(*) FROM tc_reactions r JOIN tc_messages m ON m.id=r.message_id WHERE m.chat_id=?', [$id]) . '|' . DB::val('SELECT SUM(last_read_id) FROM tc_members WHERE chat_id=?', [$id]);
        if ((int)DB::val('SELECT MAX(id) FROM tc_messages WHERE chat_id=?', [$id]) > $after) return;
        $s0 = $sig(); $end = microtime(true) + $wait;
        while (microtime(true) < $end) { usleep(700000); if ($sig() !== $s0) return; }
    }
    function poll(string $id): void {
        [$c, $mb] = $this->chat($id); $me = (int)Auth::id(); Tc::seen($me); $after = max(0, (int)($_GET['after'] ?? 0)); $before = max(0, (int)($_GET['before'] ?? 0));
        $wait = min(Xchg::int('tc.longpoll', 0, 30), max(0, (int)($_GET['wait'] ?? 0)));
        if ($wait > 0 && $after > 0 && !$before) $this->hold((int)$id, $after, $wait);
        if ($before) { $rows = array_reverse(DB::all('SELECT * FROM tc_messages WHERE chat_id=? AND id<? ORDER BY id DESC LIMIT 50', [(int)$id, $before])); $new = $rows; $recent = []; }
        elseif ($after === 0) { $new = array_reverse(DB::all('SELECT * FROM tc_messages WHERE chat_id=? ORDER BY id DESC LIMIT 80', [(int)$id])); $recent = []; }
        else { $new = DB::all('SELECT * FROM tc_messages WHERE chat_id=? AND id>? ORDER BY id LIMIT 200', [(int)$id, $after]); $recent = array_reverse(DB::all('SELECT * FROM tc_messages WHERE chat_id=? AND id<=? ORDER BY id DESC LIMIT 40', [(int)$id, $after])); }
        $ids = array_map(fn($m) => (int)$m['id'], array_merge($new, $recent)); $re = $this->reactions($ids, $me); $sh = fn($m) => $this->shape($m, $re, $c, $mb, $me);
        if (!$before && (string)($_GET['read'] ?? '') === '1') { $mx = (int)DB::val('SELECT MAX(id) FROM tc_messages WHERE chat_id=?', [(int)$id]); if ($mx > (int)$mb['last_read_id']) DB::update('tc_members', ['last_read_id' => $mx], 'chat_id=? AND user_id=?', [(int)$id, $me]); }
        $mem = DB::all('SELECT m.user_id, m.role, m.last_read_id, u.name FROM tc_members m JOIN users u ON u.id=m.user_id WHERE m.chat_id=? AND m.left_at IS NULL ORDER BY u.name', [(int)$id]); $on = Tc::online(array_map(fn($m) => (int)$m['user_id'], $mem));
        $peerRead = 0; foreach ($mem as $m) if ((int)$m['user_id'] !== $me) $peerRead = max($peerRead, (int)$m['last_read_id']);
        $this->json(['chat' => ['id' => (int)$c['id'], 'kind' => $c['kind'], 'title' => Tc::title($c, $me), 'topic' => $c['topic'], 'role' => $mb['role'], 'archived' => (bool)$c['archived'], 'pinned' => (bool)$mb['pinned'], 'muted' => (bool)$mb['muted'], 'meeting_id' => $c['meeting_id'] ? (int)$c['meeting_id'] : null],
            'members' => array_map(fn($m) => ['id' => (int)$m['user_id'], 'name' => $m['name'], 'role' => $m['role'], 'online' => in_array((int)$m['user_id'], $on, true)], $mem), 'peer_read' => $peerRead, 'new' => array_map($sh, $new), 'recent' => array_map($sh, $recent), 'more' => $before || $after === 0 ? count($new) >= ($before ? 50 : 80) : false]);
    }
    function post(string $id): void {
        [$c, $mb] = $this->chat($id, true); $me = (int)Auth::id(); $body = trim((string)$this->in('body')); $f = $_FILES['file'] ?? null; $hasFile = $f && ($f['error'] ?? 4) !== UPLOAD_ERR_NO_FILE; $max = Xchg::int('tc.max_len', 100, 10000);
        if ($body === '' && !$hasFile) $this->json(['error' => 'Message vide.'], 422); if (mb_strlen($body) > $max) $this->json(['error' => "Message trop long ($max caractères maximum)."], 422);
        if ((int)DB::val('SELECT COUNT(*) FROM tc_messages WHERE user_id=? AND created_at>=?', [$me, date('Y-m-d H:i:s', time() - 60)]) >= Xchg::int('tc.rate_per_min', 5, 600)) $this->json(['error' => 'Trop de messages en peu de temps : patientez une minute.'], 429);
        $fs = $fn = $fm = null; $fz = null;
        if ($hasFile) {
            if (!Xchg::on('tc.files')) $this->json(['error' => 'Les pièces jointes sont désactivées.'], 403); if ($f['error'] !== UPLOAD_ERR_OK) $this->json(['error' => 'Fichier non reçu (limite PHP : upload_max_filesize / post_max_size).'], 422);
            if ($f['size'] > Xchg::int('tc.file_max_mb', 1, 100) * 1048576) $this->json(['error' => 'Fichier trop volumineux (' . Xchg::int('tc.file_max_mb', 1, 100) . ' Mo maximum).'], 422);
            $fn = trim(preg_replace('#[\x00-\x1f\\\\/]+#', '_', (string)$f['name'])); $ext = strtolower(pathinfo($fn, PATHINFO_EXTENSION)); if (!isset(Tc::FILE_TYPES[$ext])) $this->json(['error' => 'Type de fichier non autorisé.'], 422);
            $mime = function_exists('mime_content_type') ? (string)@mime_content_type($f['tmp_name']) : ''; if (str_starts_with(Tc::FILE_TYPES[$ext], 'image/') && $mime !== '' && !str_starts_with($mime, 'image/')) $this->json(['error' => 'Le contenu du fichier ne correspond pas à son type.'], 422);
            $fs = bin2hex(random_bytes(16)) . '.' . $ext; if (!@move_uploaded_file($f['tmp_name'], Tc::fileDir() . '/' . $fs)) $this->json(['error' => 'Enregistrement impossible.'], 500); $fm = Tc::FILE_TYPES[$ext]; $fz = (int)$f['size'];
        }
        $rt = (int)$this->in('reply_to', 0); if ($rt && !DB::val('SELECT 1 FROM tc_messages WHERE id=? AND chat_id=?', [$rt, (int)$id])) $rt = 0; $name = (string)DB::val('SELECT name FROM users WHERE id=?', [$me]);
        $mid = DB::insert('tc_messages', ['chat_id' => (int)$id, 'user_id' => $me, 'user_name' => $name, 'kind' => 'msg', 'body' => $body, 'reply_to' => $rt ?: null, 'file_stored' => $fs, 'file_name' => $fn ? mb_substr($fn, 0, 190) : null, 'file_mime' => $fm, 'file_size' => $fz, 'created_at' => now()]);
        DB::update('tc_chats', ['last_at' => now()], 'id=?', [(int)$id]); DB::update('tc_members', ['last_read_id' => (int)$mid], 'chat_id=? AND user_id=?', [(int)$id, $me]);
        $ment = []; if (str_contains($body, '@')) foreach (DB::all('SELECT m.user_id, u.name FROM tc_members m JOIN users u ON u.id=m.user_id WHERE m.chat_id=? AND m.left_at IS NULL', [(int)$id]) as $m) if (stripos($body, '@' . $m['name']) !== false) $ment[] = (int)$m['user_id'];
        Tc::notify($c, $me, $name, $body !== '' ? $body : '📎 ' . $fn, $ment); $this->json(['ok' => true, 'id' => (int)$mid]);
    }
    private function msg(string $mid): array { $this->gate(); $m = DB::one('SELECT * FROM tc_messages WHERE id=?', [(int)$mid]); if (!$m) $this->json(['error' => 'Introuvable.'], 404); [$c, $mb] = $this->chat((string)$m['chat_id'], true); return [$m, $c, $mb]; }
    function edit(string $mid): void {
        [$m, $c, $mb] = $this->msg($mid); $s = $this->shape($m, [], $c, $mb, (int)Auth::id()); if (!$s['can_edit']) $this->json(['error' => 'Modification impossible (délai dépassé).'], 403);
        $b = trim((string)$this->in('body')); if ($b === '' || mb_strlen($b) > Xchg::int('tc.max_len', 100, 10000)) $this->json(['error' => 'Texte invalide.'], 422); DB::update('tc_messages', ['body' => $b, 'edited_at' => now()], 'id=?', [(int)$mid]); $this->json(['ok' => true]);
    }
    function delete(string $mid): void {
        [$m, $c, $mb] = $this->msg($mid); $s = $this->shape($m, [], $c, $mb, (int)Auth::id()); if (!$s['can_del']) $this->json(['error' => 'Suppression impossible.'], 403);
        DB::update('tc_messages', ['deleted_at' => now()], 'id=?', [(int)$mid]); if (!$s['mine']) Audit::log('delete', 'tc_message', $mid, null, ['chat' => $m['chat_id']]); $this->json(['ok' => true]);
    }
    function react(string $mid): void {
        if (!Xchg::on('tc.reactions')) $this->json(['error' => 'Réactions désactivées.'], 403); [$m] = $this->msg($mid); $e = (string)$this->in('emoji'); if (!in_array($e, Tc::EMOJI, true) || $m['deleted_at']) $this->json(['error' => 'Réaction invalide.'], 422); $me = (int)Auth::id();
        $r = DB::one('SELECT id FROM tc_reactions WHERE message_id=? AND user_id=? AND emoji=?', [(int)$mid, $me, $e]); if ($r) DB::exec('DELETE FROM tc_reactions WHERE id=?', [(int)$r['id']]); else DB::insert('tc_reactions', ['message_id' => (int)$mid, 'user_id' => $me, 'emoji' => $e]); $this->json(['ok' => true]);
    }
    function file(string $mid): void {
        $this->gate(); $m = DB::one('SELECT * FROM tc_messages WHERE id=?', [(int)$mid]); if (!$m || !$m['file_stored'] || $m['deleted_at'] || !Tc::member((int)$m['chat_id'])) { http_response_code(404); exit('Introuvable.'); }
        $path = Tc::fileDir() . '/' . $m['file_stored']; if (!preg_match('/^[a-f0-9]{32}\.[a-z0-9]{2,4}$/', (string)$m['file_stored']) || !is_file($path)) { http_response_code(404); exit('Introuvable.'); }
        $img = str_starts_with((string)$m['file_mime'], 'image/') && $m['file_mime'] !== 'image/svg+xml'; header('Content-Type: ' . $m['file_mime']); header('X-Content-Type-Options: nosniff'); header('Content-Length: ' . filesize($path)); header("Content-Security-Policy: sandbox; default-src 'none'; img-src 'self'");
        header('Content-Disposition: ' . ($img ? 'inline' : 'attachment') . '; filename="' . rawurlencode((string)$m['file_name']) . '"; filename*=UTF-8\'\'' . rawurlencode((string)$m['file_name'])); readfile($path); exit;
    }
    function newDirect(): void {
        $me = $this->gate(); $u = (int)$this->in('user_id', 0); if (!$u || !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$u])) $this->json(['error' => 'Utilisateur introuvable.'], 422); $this->json(['id' => Tc::direct($me, $u)]);
    }
    function newGroup(): void {
        $me = $this->gate(); if (!Xchg::on('tc.allow_groups')) $this->json(['error' => 'La création de groupes est désactivée.'], 403); $name = trim((string)$this->in('name')); $ids = array_values(array_unique(array_filter(array_map('intval', (array)$this->in('members', [])))));
        if ($name === '' || mb_strlen($name) > 150) $this->json(['error' => 'Donnez un nom au groupe (150 caractères maximum).'], 422); if (!$ids) $this->json(['error' => 'Choisissez au moins un membre.'], 422); if (count($ids) + 1 > Xchg::int('tc.group_max', 3, 500)) $this->json(['error' => 'Maximum ' . Xchg::int('tc.group_max', 3, 500) . ' membres.'], 422);
        $id = Tc::createGroup($name, $me, $ids); Audit::log('create', 'tc_group', (string)$id, null, ['members' => count($ids) + 1]); $this->json(['id' => $id]);
    }
    /** Gestion d'un groupe : rename | add | remove | leave | role. */
    function group(string $id): void {
        [$c, $mb] = $this->chat($id, true); $me = (int)Auth::id(); if ($c['kind'] !== 'group') $this->json(['error' => 'Opération réservée aux groupes.'], 422); $act = (string)$this->in('act'); $adm = in_array($mb['role'], ['owner', 'admin'], true); $uname = fn($u) => (string)DB::val('SELECT name FROM users WHERE id=?', [$u]);
        if ($act === 'leave') {
            DB::update('tc_members', ['left_at' => now()], 'id=?', [(int)$mb['id']]); Tc::sys((int)$id, $uname($me) . ' a quitté le groupe.');
            if ($mb['role'] === 'owner') { $n = DB::one('SELECT id, user_id FROM tc_members WHERE chat_id=? AND left_at IS NULL ORDER BY (role=\'admin\') DESC, id LIMIT 1', [(int)$id]); if ($n) DB::update('tc_members', ['role' => 'owner'], 'id=?', [(int)$n['id']]); else DB::update('tc_chats', ['archived' => 1], 'id=?', [(int)$id]); } $this->json(['ok' => true, 'left' => true]);
        }
        if (!$adm) $this->json(['error' => 'Réservé aux administrateurs du groupe.'], 403);
        if ($act === 'rename') { $n = trim((string)$this->in('name')); if ($n === '' || mb_strlen($n) > 150) $this->json(['error' => 'Nom invalide.'], 422); DB::update('tc_chats', ['name' => $n, 'topic' => mb_substr(trim((string)$this->in('topic')), 0, 300) ?: null], 'id=?', [(int)$id]); Tc::sys((int)$id, $uname($me) . ' a renommé le groupe « ' . $n . ' ».'); }
        elseif ($act === 'add') {
            $cur = (int)DB::val('SELECT COUNT(*) FROM tc_members WHERE chat_id=? AND left_at IS NULL', [(int)$id]); $add = [];
            foreach (array_unique(array_map('intval', (array)$this->in('members', []))) as $u) { if (!$u || !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$u])) continue; $ex = DB::one('SELECT id, left_at FROM tc_members WHERE chat_id=? AND user_id=?', [(int)$id, $u]); if ($ex && !$ex['left_at']) continue; if ($cur + count($add) + 1 > Xchg::int('tc.group_max', 3, 500)) $this->json(['error' => 'Limite de membres atteinte.'], 422);
                if ($ex) DB::update('tc_members', ['left_at' => null, 'role' => 'member', 'last_read_id' => (int)DB::val('SELECT COALESCE(MAX(id),0) FROM tc_messages WHERE chat_id=?', [(int)$id])], 'id=?', [(int)$ex['id']]); else DB::insert('tc_members', ['chat_id' => (int)$id, 'user_id' => $u, 'role' => 'member', 'last_read_id' => 0, 'joined_at' => now(), 'added_by' => $me]); $add[] = $uname($u); }
            if (!$add) $this->json(['error' => 'Aucun nouveau membre.'], 422); Tc::sys((int)$id, $uname($me) . ' a ajouté ' . implode(', ', $add) . '.');
        } elseif ($act === 'remove') {
            $u = (int)$this->in('user_id', 0); $t = Tc::member((int)$id, $u); if (!$t || $t['role'] === 'owner' || $u === $me) $this->json(['error' => 'Retrait impossible.'], 422); if ($t['role'] === 'admin' && $mb['role'] !== 'owner') $this->json(['error' => 'Seul le propriétaire retire un administrateur.'], 403);
            DB::update('tc_members', ['left_at' => now()], 'id=?', [(int)$t['id']]); Tc::sys((int)$id, $uname($me) . ' a retiré ' . $uname($u) . ' du groupe.');
        } elseif ($act === 'role') {
            if ($mb['role'] !== 'owner') $this->json(['error' => 'Réservé au propriétaire.'], 403); $u = (int)$this->in('user_id', 0); $r = (string)$this->in('role'); $t = Tc::member((int)$id, $u); if (!$t || $t['role'] === 'owner' || !in_array($r, ['admin', 'member'], true)) $this->json(['error' => 'Opération impossible.'], 422);
            DB::update('tc_members', ['role' => $r], 'id=?', [(int)$t['id']]); Tc::sys((int)$id, $uname($u) . ($r === 'admin' ? ' est maintenant administrateur du groupe.' : ' n\'est plus administrateur.'));
        } else $this->json(['error' => 'Opération inconnue.'], 422);
        $this->json(['ok' => true]);
    }
    function prefs(string $id): void { [$c, $mb] = $this->chat($id); $k = (string)$this->in('k'); if (!in_array($k, ['pinned', 'muted'], true)) $this->json(['error' => 'Option inconnue.'], 422); DB::update('tc_members', [$k => $mb[$k] ? 0 : 1], 'id=?', [(int)$mb['id']]); $this->json(['ok' => true]); }
    // --- administration ---
    function admin(): void {
        $this->view('tc/admin', ['title' => 'Administration des discussions', 'groups' => DB::all("SELECT c.*, u.name creator, (SELECT COUNT(*) FROM tc_members m WHERE m.chat_id=c.id AND m.left_at IS NULL) n_mem, (SELECT COUNT(*) FROM tc_messages x WHERE x.chat_id=c.id AND x.kind='msg') n_msg FROM tc_chats c LEFT JOIN users u ON u.id=c.created_by WHERE c.kind='group' ORDER BY c.last_at DESC LIMIT 300"),
            'stats' => ['direct' => (int)DB::val("SELECT COUNT(*) FROM tc_chats WHERE kind='direct'"), 'msgs7' => (int)DB::val("SELECT COUNT(*) FROM tc_messages WHERE kind='msg' AND created_at>=?", [date('Y-m-d H:i:s', strtotime('-7 days'))]), 'users7' => (int)DB::val("SELECT COUNT(DISTINCT user_id) FROM tc_messages WHERE kind='msg' AND created_at>=?", [date('Y-m-d H:i:s', strtotime('-7 days'))])]]);
    }
    function adminAct(string $id): void {
        $c = DB::one('SELECT * FROM tc_chats WHERE id=? AND kind=\'group\'', [(int)$id]); if (!$c) { $this->notFound(); return; } $a = (string)$this->in('act');
        if ($a === 'archive' || $a === 'restore') { DB::update('tc_chats', ['archived' => $a === 'archive' ? 1 : 0], 'id=?', [(int)$id]); Audit::log($a, 'tc_group', $id); flash($a === 'archive' ? 'Groupe archivé (lecture seule, masqué des listes).' : 'Groupe restauré.'); }
        elseif ($a === 'delete') { foreach (DB::all('SELECT file_stored FROM tc_messages WHERE chat_id=? AND file_stored IS NOT NULL', [(int)$id]) as $f) @unlink(Tc::fileDir() . '/' . basename((string)$f['file_stored'])); DB::exec('DELETE FROM tc_reactions WHERE message_id IN (SELECT id FROM tc_messages WHERE chat_id=?)', [(int)$id]); DB::exec('DELETE FROM tc_messages WHERE chat_id=?', [(int)$id]); DB::exec('DELETE FROM tc_members WHERE chat_id=?', [(int)$id]); DB::exec('DELETE FROM tc_chats WHERE id=?', [(int)$id]); DB::update('rn_meetings', ['chat_id' => null], 'chat_id=?', [(int)$id]); Audit::log('delete', 'tc_group', $id, ['name' => $c['name']]); flash('Groupe supprimé définitivement.'); }
        redirect('tc/admin');
    }
}
