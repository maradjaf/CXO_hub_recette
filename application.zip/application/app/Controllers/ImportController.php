<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, ImportDoc, ELearn, RichHtml, Html, Kb, Xchg};

/** Import de documents (Word, PowerPoint, PDF) vers un cours e-learning ou la base de connaissances. */
class ImportController extends Controller {
    private function upload(string $to): ?array {
        $f = $_FILES['doc'] ?? null; if (!$f || ($f['error'] ?? 4) === UPLOAD_ERR_NO_FILE) { flash('Choisissez un fichier .docx, .pptx ou .pdf.', 'danger'); redirect($to); }
        if ($f['error'] !== UPLOAD_ERR_OK) { flash('Fichier non reçu (limite PHP : upload_max_filesize / post_max_size = ' . ini_get('upload_max_filesize') . ' / ' . ini_get('post_max_size') . ').', 'danger'); redirect($to); }
        $max = Xchg::int('elearn.import_max_mb', 1, 200) * 1048576; if ($f['size'] > $max) { flash('Fichier trop volumineux (' . round($max / 1048576) . ' Mo maximum).', 'danger'); redirect($to); }
        if (!is_uploaded_file($f['tmp_name'])) { flash('Envoi invalide.', 'danger'); redirect($to); }
        [$r, $err] = ImportDoc::parse($f['tmp_name'], (string)$f['name']); if ($err) { flash($err, 'danger'); redirect($to); } return $r + ['file' => (string)$f['name']];
    }
    // ---------- cours ----------
    function courseForm(): void { $this->view('elearn/import', ['title' => 'Importer un cours', 'drafts' => DB::all("SELECT id, title FROM el_courses WHERE status='draft' ORDER BY title"), 'sel' => (int)$this->in('course'), 'max' => Xchg::int('elearn.import_max_mb', 1, 200)]); }
    function course(): void {
        $to = 'elearn/import'; $r = $this->upload($to); $cid = (int)$this->in('course_id', 0);
        if ($cid) { $c = DB::one("SELECT * FROM el_courses WHERE id=? AND status='draft'", [$cid]); if (!$c) { flash('Le cours choisi doit être en brouillon.', 'danger'); redirect($to); } }
        else { $t = trim((string)$this->in('title')) ?: $r['title']; $cid = DB::insert('el_courses', ['title' => mb_substr($t, 0, 190), 'status' => 'draft', 'created_by' => Auth::id(), 'created_at' => now(), 'pass_pct' => 80, 'nature' => 'both', 'sequential' => Xchg::on('elearn.sequential_default') ? 1 : 0, 'description' => mb_substr('Importé depuis ' . $r['file'], 0, 1000)]); }
        $stack = [0 => null]; $n = 0; $pos = []; $existing = (int)DB::val('SELECT COALESCE(MAX(position),0) FROM el_lessons WHERE course_id=? AND parent_id IS NULL', [$cid]);
        foreach ($r['sections'] as $s) {
            $d = max(1, min(3, (int)$s['depth'])); $par = $d === 1 ? null : ($stack[$d - 1] ?? null); if ($d > 1 && $par === null) { $d = 1; }
            $pk = (int)$par; $pos[$pk] = ($pos[$pk] ?? ($pk === 0 ? $existing : 0)) + 1;
            $id = DB::insert('el_lessons', ['course_id' => $cid, 'parent_id' => $par, 'position' => $pos[$pk], 'title' => mb_substr($s['title'], 0, 190), 'body' => $s['html'], 'kind' => 'text']); $stack[$d] = $id; foreach (array_keys($stack) as $k) if ($k > $d) unset($stack[$k]); $n++;
        }
        Audit::log('import', 'el_course', $cid, null, ['file' => $r['file'], 'parts' => $n]);
        flash("Document importé : $n partie(s) créée(s) en brouillon. Relisez, complétez (quiz, vidéos) puis publiez." . ($r['warnings'] ? ' ' . implode(' ', $r['warnings']) : ''), 'success'); redirect("elearn/$cid/structure");
    }
    // ---------- base de connaissances ----------
    function kbForm(): void { $this->view('kb/import', ['title' => 'Importer dans la base de connaissances', 'cats' => DB::all('SELECT * FROM kb_categories ORDER BY sort_order, name'), 'max' => Xchg::int('elearn.import_max_mb', 1, 200)]); }
    function kb(): void {
        $to = 'kb/import'; $r = $this->upload($to); $cat = (int)$this->in('category_id', 0); if ($cat && !DB::val('SELECT 1 FROM kb_categories WHERE id=?', [$cat])) $cat = 0;
        $split = $this->in('split') === 'sections'; $internal = $this->in('internal') === '1' ? 1 : 0; $tags = mb_substr(trim((string)$this->in('tags')), 0, 200);
        $arts = [];
        if ($split) { $cur = null; foreach ($r['sections'] as $s) { if ((int)$s['depth'] === 1 && ($cur === null || true)) { if ($cur) $arts[] = $cur; $cur = ['title' => $s['title'], 'html' => $s['html']]; } elseif ($cur) $cur['html'] .= '<h2>' . htmlspecialchars($s['title'], ENT_QUOTES, 'UTF-8') . '</h2>' . $s['html']; } if ($cur) $arts[] = $cur; }
        else { $h = ''; foreach ($r['sections'] as $i => $s) $h .= ($i ? '<h' . min(4, 1 + max(1, (int)$s['depth'])) . '>' . htmlspecialchars($s['title'], ENT_QUOTES, 'UTF-8') . '</h' . min(4, 1 + max(1, (int)$s['depth'])) . '>' : '') . $s['html']; $arts[] = ['title' => $r['sections'][0]['title'] ?? $r['title'], 'html' => $h]; }
        $arts = array_slice($arts, 0, 60); $ids = [];
        foreach ($arts as $a) { $body = Html::clean($a['html']); if (Html::text($body) === '') continue;
            $id = DB::insert('kb_articles', ['title' => mb_substr($a['title'], 0, 190), 'summary' => Html::text($body, 280), 'body' => $body, 'tags' => $tags ?: null, 'kind' => 'article', 'category_id' => $cat ?: null, 'internal' => $internal, 'status' => 'draft', 'author_id' => Auth::id(), 'created_at' => now(), 'updated_at' => now()]); Kb::snapshot($id, 'Import de ' . $r['file']); $ids[] = $id; }
        if (!$ids) { flash('Aucun contenu exploitable dans ce document.', 'danger'); redirect($to); }
        Audit::log('import', 'kb_article', $ids[0], null, ['file' => $r['file'], 'articles' => count($ids)]);
        flash(count($ids) . ' article(s) créé(s) en brouillon : relisez-les puis soumettez-les à la relecture.' . ($r['warnings'] ? ' ' . implode(' ', $r['warnings']) : ''), 'success'); redirect(count($ids) === 1 ? 'kb/a/' . $ids[0] . '/edit' : 'kb/manage');
    }
}
