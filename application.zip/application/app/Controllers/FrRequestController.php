<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Fr, FrStats};

/** Lot 60 — Franchises : file des dossiers, création, fiche (données sensibles masquées), actions du circuit, opérations confirmées. */
class FrRequestController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    private function guard(): void { if (!can('fr.view') && !can('fr.own') && !can('fr.handle')) { $this->forbidden(); exit; } }

    /** Clause WHERE commune à la file et à l'export. */
    private function where(): array {
        [$sc] = Fr::sqlScope('r.franchise_id'); $w = '1=1' . $sc; $p = []; $g = $_GET;
        if (!empty($g['fr'])) { $ids = array_filter(array_map('intval', (array)$g['fr'])); if ($ids) $w .= ' AND r.franchise_id IN (' . implode(',', $ids) . ')'; }
        foreach (['service', 'typology', 'team', 'priority', 'channel'] as $k) if (!empty($g[$k]) && is_string($g[$k])) { $w .= " AND r.$k=?"; $p[] = $g[$k]; }
        if (!empty($g['status']) && is_string($g['status'])) { if ($g['status'] === 'open') $w .= " AND r.status IN ('new','assigned','in_progress','waiting')"; elseif ($g['status'] === 'term') $w .= " AND r.status IN ('executed','rejected','cancelled','not_executed')"; elseif (isset(Fr::ST[$g['status']])) { $w .= ' AND r.status=?'; $p[] = $g['status']; } }
        if (!empty($g['overdue'])) { $w .= " AND r.status IN ('new','assigned','in_progress','waiting') AND r.due_at IS NOT NULL AND r.due_at<?"; $p[] = now(); }
        if (!empty($g['mine'])) { $w .= ' AND r.assignee_id=?'; $p[] = (int)\App\Core\Auth::id(); }
        if (Fr::isDay($g['from'] ?? null)) { $w .= ' AND SUBSTR(r.created_at,1,10)>=?'; $p[] = $g['from']; } if (Fr::isDay($g['to'] ?? null)) { $w .= ' AND SUBSTR(r.created_at,1,10)<=?'; $p[] = $g['to']; }
        $q = trim((string)($g['q'] ?? '')); if ($q !== '') { $w .= " AND (r.ref LIKE ? ESCAPE '|' OR r.source_ref LIKE ? ESCAPE '|' OR r.bt_ref LIKE ? ESCAPE '|')"; $l = '%' . str_replace(['|', '%', '_'], ['||', '|%', '|_'], $q) . '%'; array_push($p, $l, $l, $l); }
        return [$w, $p];
    }
    function index(): void {
        $this->guard(); [$w, $p] = $this->where(); $page = max(1, (int)$this->in('page', 1));
        $from = 'fr_requests r JOIN fr_franchises f ON f.id=r.franchise_id LEFT JOIN users u ON u.id=r.assignee_id';
        $sel = 'r.id, r.ref, r.created_at, r.service, r.typology, r.priority, r.status, r.team, r.due_at, r.closed_at, r.wait_owner, f.name franchise, f.zone, u.name assignee';
        if ($this->in('export') === 'csv' && can('fr.export')) { $rows = DB::all("SELECT $sel FROM $from WHERE $w ORDER BY r.created_at DESC LIMIT 20000", $p); Audit::log('fr.export', 'fr_requests', 0, null, ['n' => count($rows)]);
            csv_download('dossiers_franchises_' . date('Ymd') . '.csv', ['Référence', 'Créé le', 'Franchise', 'Zone', 'Service', 'Typologie', 'Priorité', 'Statut', 'Équipe', 'Agent', 'Échéance SLA', 'Clôturé le'], array_map(fn($r) => [$r['ref'], $r['created_at'], $r['franchise'], $r['zone'], $r['service'], $r['typology'], Fr::PRIO[$r['priority']] ?? '', Fr::ST[$r['status']] ?? '', $r['team'], $r['assignee'], $r['due_at'], $r['closed_at']], $rows)); }
        $pg = paginate($from . ' WHERE ' . $w, $p, $page, 25, $sel, 'r.created_at DESC, r.id DESC');
        $kpi = DB::one("SELECT COUNT(*) n, SUM(CASE WHEN r.status IN ('new','assigned','in_progress','waiting') THEN 1 ELSE 0 END) open_n, SUM(CASE WHEN r.status IN ('new','assigned','in_progress','waiting') AND r.due_at IS NOT NULL AND r.due_at<? THEN 1 ELSE 0 END) late_n, SUM(CASE WHEN r.status='waiting' THEN 1 ELSE 0 END) wait_n FROM $from WHERE $w", array_merge([now()], $p));
        $this->view('fr/requests', ['title' => 'Dossiers franchises', 'pg' => $pg, 'kpi' => $kpi, 'o' => FrController::opts(), 'g' => $_GET]);
    }
    function create(): void { if (!can('fr.handle') && !can('fr.own')) { $this->forbidden(); return; } $this->view('fr/request_new', ['title' => 'Nouvelle demande', 'o' => FrController::opts(), 'cat' => DB::all('SELECT * FROM fr_catalog WHERE active=1 ORDER BY service, typology, subtype'), 'users' => DB::all("SELECT id, name FROM users WHERE status='active' ORDER BY name"), 'old' => $_GET]); }
    function store(): void {
        if (!can('fr.handle') && !can('fr.own')) { $this->forbidden(); return; } $in = $_POST; if (!can('fr.handle')) { unset($in['assignee_id'], $in['team'], $in['created_at']); }
        if (!can('fr.handle') && Fr::franchiseUser()) { $sc = Fr::scope(); if ($sc && count($sc) === 1 && empty($in['franchise_id'])) $in['franchise_id'] = $sc[0]; }
        [$id, $err] = Fr::create($in); if ($err) { $this->back(['_' => $err], $_POST, 'fr/requests/new'); return; }
        Audit::log('fr.request.create', 'fr_requests', $id, null, ['franchise' => $in['franchise_id'] ?? null]); $this->go("fr/requests/$id", 'Demande créée.');
    }
    function show(string $id): void {
        $this->guard(); $r = DB::one('SELECT r.*, f.name franchise, f.zone, f.code fcode, u.name assignee, rs.label reason FROM fr_requests r JOIN fr_franchises f ON f.id=r.franchise_id LEFT JOIN users u ON u.id=r.assignee_id LEFT JOIN fr_reasons rs ON rs.id=r.reason_id WHERE r.id=?', [$id]);
        if (!$r || !Fr::sees((int)$r['franchise_id'])) { $this->notFound(); return; }
        $reveal = $this->in('reveal') === '1' && Fr::canReveal((int)$r['franchise_id']); if ($reveal) Fr::revealLog($r); $v = Fr::view($r, $reveal);
        $this->view('fr/request_show', ['title' => $r['ref'], 'r' => $v, 'raw' => $r, 'reveal' => $reveal, 'canReveal' => Fr::canReveal((int)$r['franchise_id']), 'ev' => DB::all('SELECT * FROM fr_events WHERE request_id=? ORDER BY at, id', [$id]), 'ops' => DB::all('SELECT * FROM fr_ops WHERE request_id=? ORDER BY effective_at', [$id]),
            'opdict' => DB::all('SELECT label FROM fr_opdict ORDER BY label'), 'reasons' => ['hold' => Fr::reasons('hold'), 'reject' => Fr::reasons('reject'), 'cancel' => Fr::reasons('cancel'), 'noexec' => Fr::reasons('noexec')],
            'users' => DB::all("SELECT id, name FROM users WHERE status='active' ORDER BY name"), 'teams' => FrController::opts()['teams'], 'handle' => can('fr.handle'), 'late' => in_array($r['status'], Fr::OPEN, true) && $r['due_at'] && $r['due_at'] < now()]);
    }
    function act(string $id): void {
        $this->guard(); $act = (string)$this->in('action', ''); $err = Fr::act((int)$id, $act, $_POST);
        if ($err) $this->go("fr/requests/$id", $err, 'danger'); Audit::log('fr.request.' . $act, 'fr_requests', $id); $this->go("fr/requests/$id", 'Action enregistrée : ' . (Fr::EVT[$act] ?? $act) . '.');
    }
    /** Liste des opérations CRM confirmées (filtrable, exportable). */
    function operations(): void {
        $this->guard(); $cov = FrStats::coverage('ops'); $end = $cov['to'] ?? date('Y-m-d'); $f = FrStats::filters($_GET, Fr::addDays($end, -29), $end); $ids = FrStats::ids($f, $f['to']); $w = 'o.day>=? AND o.day<=?'; $p = [$f['from'], $f['to']];
        if ($ids !== null) $w .= $ids ? ' AND o.franchise_id IN (' . implode(',', array_map('intval', $ids)) . ')' : ' AND 1=0'; if ($f['service'] !== '') { $w .= ' AND o.service=?'; $p[] = $f['service']; } $t = trim((string)$this->in('type', '')); if ($t !== '') { $w .= ' AND o.op_type=?'; $p[] = $t; } if ($this->in('counted') !== null && $this->in('counted') !== '') { $w .= ' AND o.counted=?'; $p[] = (int)$this->in('counted'); }
        $from = 'fr_ops o JOIN fr_franchises f ON f.id=o.franchise_id LEFT JOIN fr_requests r ON r.id=o.request_id'; $sel = 'o.id, o.op_ref, o.op_type, o.service, o.subtype, o.effective_at, o.day, o.counted, o.source, f.name franchise, f.zone, r.ref request_ref, o.request_id';
        if ($this->in('export') === 'csv' && can('fr.export')) { $rows = DB::all("SELECT $sel FROM $from WHERE $w ORDER BY o.effective_at DESC LIMIT 50000", $p); Audit::log('fr.export', 'fr_ops', 0, null, ['n' => count($rows)]); csv_download('operations_franchises_' . date('Ymd') . '.csv', ['Référence opération', 'Type', 'Service', 'Franchise', 'Zone', 'Date effective', 'Comptée', 'Dossier', 'Source'], array_map(fn($r) => [$r['op_ref'], $r['op_type'], $r['service'], $r['franchise'], $r['zone'], $r['effective_at'], $r['counted'] ? 'oui' : 'non', $r['request_ref'], $r['source']], $rows)); }
        $pg = paginate("$from WHERE $w", $p, max(1, (int)$this->in('page', 1)), 30, $sel, 'o.effective_at DESC, o.id DESC'); $tot = DB::one("SELECT COUNT(*) n, SUM(o.counted) c FROM $from WHERE $w", $p);
        $this->view('fr/operations', ['title' => 'Opérations confirmées', 'pg' => $pg, 'f' => $f, 'o' => FrController::opts(), 'types' => array_column(DB::all('SELECT label FROM fr_opdict ORDER BY label'), 'label'), 'type' => $t, 'tot' => $tot, 'cov' => $cov]);
    }
}
