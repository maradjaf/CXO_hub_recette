<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Tr};

/** Rapports qualité au format « diapositives » : rapport mensuel / de fin de contrôle (période libre) et rapport mensuel du coach qualité. */
class QaReportController extends Controller {
    private function period(): array {
        $ym = (string)$this->in('month', date('Y-m')); if (!preg_match('/^\d{4}-\d{2}$/', $ym)) $ym = date('Y-m'); [$f, $t] = Tr::monthRange($ym);
        $f2 = (string)$this->in('from'); $t2 = (string)$this->in('to'); $custom = preg_match('/^\d{4}-\d{2}-\d{2}$/', $f2) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $t2) && $f2 <= $t2;
        if ($custom) { $f = $f2; $t = $t2; $ym = substr($f2, 0, 7); }
        return [$ym, $f, $t, $custom];
    }
    /** Agrégats qualité sur une période. */
    static function agg(string $f, string $t, string $where = '1=1', array $p = []): array {
        $b = [$f, $t, ...$p];
        $r = DB::one("SELECT COUNT(*) n, AVG(v.score_pct) avg, SUM(v.critical_fail) crit, COUNT(DISTINCT v.employee_id) agents FROM qa_evaluations v WHERE v.eval_date BETWEEN ? AND ? AND $where", $b);
        $n = (int)$r['n'];
        return ['n' => $n, 'avg' => $n ? round((float)$r['avg'], 1) : null, 'crit' => (int)$r['crit'], 'crit_rate' => $n ? round(100 * (int)$r['crit'] / $n, 1) : null, 'agents' => (int)$r['agents']];
    }
    function monthly(): void {
        [$ym, $f, $t, $custom] = $this->period(); $obj = Tr::obj('qa', 85); $pm = Tr::prevMonth($ym); [$pf, $pt] = Tr::monthRange($pm);
        $cur = self::agg($f, $t); $prev = self::agg($pf, $pt);
        $byCh = DB::all("SELECT COALESCE(v.channel,'Non précisé') ch, COUNT(*) n, AVG(v.score_pct) avg, SUM(v.critical_fail) crit FROM qa_evaluations v WHERE v.eval_date BETWEEN ? AND ? GROUP BY ch ORDER BY avg DESC", [$f, $t]);
        $byCrit = DB::all("SELECT c.label, c.critical, AVG(s.points*100.0/c.max_points) pc, COUNT(*) n FROM qa_scores s JOIN qa_criteria c ON c.id=s.criterion_id JOIN qa_evaluations v ON v.id=s.evaluation_id WHERE v.eval_date BETWEEN ? AND ? GROUP BY c.id, c.label, c.critical ORDER BY pc ASC LIMIT 8", [$f, $t]);
        $recur = DB::all("SELECT e.first_name, e.last_name, e.matricule, COUNT(*) n, AVG(v.score_pct) avg FROM qa_evaluations v JOIN employees e ON e.id=v.employee_id WHERE v.eval_date BETWEEN ? AND ? AND (v.critical_fail=1 OR v.score_pct<?) GROUP BY e.id, e.first_name, e.last_name, e.matricule HAVING COUNT(*)>=2 ORDER BY n DESC, avg ASC LIMIT 10", [$f, $t, $obj]);
        $acts = DB::one("SELECT COUNT(*) n, SUM(CASE WHEN a.status='done' THEN 1 ELSE 0 END) done, SUM(CASE WHEN a.status<>'done' AND a.due_date<? THEN 1 ELSE 0 END) late FROM qa_actions a JOIN qa_evaluations v ON v.id=a.evaluation_id WHERE v.eval_date BETWEEN ? AND ?", [date('Y-m-d'), $f, $t]);
        $labels = []; $series = ['Score moyen' => [], 'Objectif' => []]; for ($i = 11; $i >= 0; $i--) { $m = date('Y-m', strtotime($ym . "-01 -$i month")); [$a, $b] = Tr::monthRange($m); $x = self::agg($a, $b); $labels[] = date('m/y', strtotime("$m-01")); $series['Score moyen'][] = $x['avg'] ?? 0; $series['Objectif'][] = $obj; }
        $this->view('qa/report', ['title' => $custom ? 'Rapport de fin de contrôle qualité' : 'Rapport mensuel de contrôle qualité', 'ym' => $ym, 'f' => $f, 't' => $t, 'custom' => $custom, 'obj' => $obj, 'cur' => $cur, 'prev' => $prev, 'byCh' => $byCh, 'byCrit' => $byCrit, 'recur' => $recur, 'acts' => $acts, 'labels' => $labels, 'series' => $series, 'edit' => can('qa.manage'),
            'cal' => DB::one("SELECT * FROM cal_sessions WHERE status='closed' ORDER BY held_on DESC LIMIT 1")], 'layout/public');
    }
    function coach(): void {
        [$ym, $f, $t] = $this->period(); $obj = Tr::obj('qa', 85);
        $coaches = DB::all("SELECT DISTINCT u.id, u.name FROM qa_evaluations v JOIN users u ON u.id=v.evaluator_id ORDER BY u.name");
        $cid = (int)$this->in('coach', 0); if (!$cid) { $cid = (int)\App\Core\Auth::id(); if (!array_filter($coaches, fn($c) => (int)$c['id'] === $cid) && $coaches) $cid = (int)$coaches[0]['id']; }
        $cur = self::agg($f, $t, 'v.evaluator_id=?', [$cid]); [$pf, $pt] = Tr::monthRange(Tr::prevMonth($ym)); $prev = self::agg($pf, $pt, 'v.evaluator_id=?', [$cid]);
        $agents = DB::all("SELECT e.first_name, e.last_name, e.matricule, COUNT(*) n, AVG(v.score_pct) avg, SUM(v.critical_fail) crit FROM qa_evaluations v JOIN employees e ON e.id=v.employee_id WHERE v.eval_date BETWEEN ? AND ? AND v.evaluator_id=? GROUP BY e.id, e.first_name, e.last_name, e.matricule ORDER BY avg ASC", [$f, $t, $cid]);
        $acts = DB::one("SELECT COUNT(*) n, SUM(CASE WHEN a.status='done' THEN 1 ELSE 0 END) done FROM qa_actions a JOIN qa_evaluations v ON v.id=a.evaluation_id WHERE v.eval_date BETWEEN ? AND ? AND v.evaluator_id=?", [$f, $t, $cid]);
        $ack = DB::one("SELECT COUNT(*) n, SUM(CASE WHEN v.acknowledged_at IS NOT NULL THEN 1 ELSE 0 END) ok FROM qa_evaluations v WHERE v.eval_date BETWEEN ? AND ? AND v.evaluator_id=?", [$f, $t, $cid]);
        $cal = DB::all("SELECT s.ref, s.title, s.held_on FROM cal_sessions s JOIN cal_parts p ON p.session_id=s.id WHERE p.user_id=? AND s.held_on BETWEEN ? AND ? ORDER BY s.held_on", [$cid, $f, $t]);
        $this->view('qa/coach', ['title' => 'Rapport mensuel du coach qualité', 'ym' => $ym, 'f' => $f, 't' => $t, 'obj' => $obj, 'coaches' => $coaches, 'cid' => $cid, 'cname' => (string)(DB::val('SELECT name FROM users WHERE id=?', [$cid]) ?: '—'), 'cur' => $cur, 'prev' => $prev, 'agents' => $agents, 'acts' => $acts, 'ack' => $ack, 'cal' => $cal, 'edit' => can('qa.manage')], 'layout/public');
    }
}
