<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Followup, Sms, Settings, Sv};

/** Lot 68 — File d'appels de rappel des clients détracteurs ou très insatisfaits. */
class FollowupController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    private function row(string $id): ?array { $f = DB::one('SELECT * FROM sv_followups WHERE id=?', [(int)$id]); return $f && Followup::visible($f) ? $f : null; }
    function index(): void {
        $tab = (string)$this->in('tab') ?: 'open'; $mine = (string)$this->in('mine') === '1'; $w = ['1=1']; $p = [];
        if ($tab === 'open') $w[] = Followup::open('f.'); elseif ($tab === 'late') { $w[] = Followup::open('f.') . ' AND f.due_at<?'; $p[] = now(); } elseif ($tab === 'closed') $w[] = "f.status IN ('done','unreachable','cancelled')";
        if ($mine) { $w[] = 'f.assigned_user_id=?'; $p[] = Auth::id(); } $k = (string)$this->in('kind'); if (isset(Followup::KIND[$k])) { $w[] = 'f.kind=?'; $p[] = $k; }
        $rows = array_values(array_filter(DB::all('SELECT f.*, e.last_name el, e.first_name ef, u.name uname, st.name store_name FROM sv_followups f LEFT JOIN employees e ON e.id=f.employee_id LEFT JOIN users u ON u.id=f.assigned_user_id LEFT JOIN stores st ON st.id=f.store_id WHERE ' . implode(' AND ', $w) . ' ORDER BY f.priority, f.due_at LIMIT 300', $p), fn($f) => Followup::visible($f)));
        $all = array_values(array_filter(DB::all('SELECT id, status, due_at, assigned_user_id, employee_id, outcome, created_at, closed_at FROM sv_followups'), fn($f) => Followup::visible($f))); $open = array_filter($all, fn($f) => in_array($f['status'], ['todo', 'doing'], true)); $closed = array_filter($all, fn($f) => $f['status'] === 'done');
        $dur = array_map(fn($f) => (strtotime($f['closed_at']) - strtotime($f['created_at'])) / 3600, array_filter($closed, fn($f) => $f['closed_at']));
        $this->view('survey/followup', ['title' => 'Rappels clients', 'rows' => $rows, 'tab' => $tab, 'mine' => $mine, 'kind' => $k, 'k' => ['open' => count($open), 'late' => count(array_filter($open, fn($f) => $f['due_at'] < now())), 'done' => count($closed), 'avgh' => $dur ? round(array_sum($dur) / count($dur), 1) : null, 'unreach' => count(array_filter($all, fn($f) => $f['status'] === 'unreachable')), 'resolved' => count(array_filter($closed, fn($f) => $f['outcome'] === 'resolved'))],
            'cfg' => array_combine(array_keys(Followup::DEFAULTS), array_map(fn($x) => (string)Followup::cfg($x), array_keys(Followup::DEFAULTS))), 'dm' => Sv::cfg('detractor_max'), 'canCfg' => \can('survey.manage'), 'users' => DB::all("SELECT id, name FROM users WHERE status='active' ORDER BY name")]);
    }
    function show(string $id): void {
        $f = $this->row($id); if (!$f) { $this->notFound(); return; } $resp = $f['response_id'] ? DB::one('SELECT r.*, s.name survey_name FROM sv_responses r LEFT JOIN sv_surveys s ON s.id=r.survey_id WHERE r.id=?', [$f['response_id']]) : null;
        $ans = $resp ? DB::all('SELECT q.label, q.type, a.num, a.txt FROM sv_answers a JOIN sv_questions q ON q.id=a.question_id WHERE a.response_id=? ORDER BY q.position', [$resp['id']]) : [];
        Audit::log('view', 'sv_followup', $id); $emp = $f['employee_id'] ? DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [$f['employee_id']]) : null;
        $this->view('survey/followup_show', ['title' => 'Rappel client', 'f' => $f, 'resp' => $resp, 'ans' => $ans, 'logs' => DB::all('SELECT * FROM sv_followup_logs WHERE followup_id=? ORDER BY id DESC', [(int)$id]), 'emp' => $emp, 'users' => DB::all("SELECT id, name FROM users WHERE status='active' ORDER BY name"), 'assignee' => $f['assigned_user_id'] ? DB::val('SELECT name FROM users WHERE id=?', [$f['assigned_user_id']]) : null]);
    }
    /** Prend le rappel le plus urgent (affecté à moi ou non affecté) et l'ouvre. */
    function next(): void {
        foreach (DB::all("SELECT * FROM sv_followups WHERE " . Followup::open() . " AND (next_call_at IS NULL OR next_call_at<=?) AND (assigned_user_id=? OR assigned_user_id IS NULL) ORDER BY priority, due_at LIMIT 100", [now(), Auth::id()]) as $f) if (Followup::visible($f) || !$f['assigned_user_id']) {
            if (!$f['assigned_user_id']) { DB::update('sv_followups', ['assigned_user_id' => Auth::id()], 'id=?', [$f['id']]); Followup::log((int)$f['id'], 'assign', null, 'Pris en charge'); } $this->go('surveys/followup/' . $f['id']); }
        $this->go('surveys/followup', 'Aucun rappel à passer pour le moment.', 'info');
    }
    function assign(string $id): void {
        $f = $this->row($id); if (!$f) { $this->notFound(); return; } $u = (int)($_POST['user_id'] ?? 0) ?: (int)Auth::id(); if (!DB::val('SELECT 1 FROM users WHERE id=?', [$u])) $this->go("surveys/followup/$id", 'Utilisateur inconnu.', 'danger');
        DB::update('sv_followups', ['assigned_user_id' => $u, 'status' => $f['status'] === 'todo' ? 'todo' : $f['status']], 'id=?', [$f['id']]); Followup::log((int)$f['id'], 'assign', null, 'Affecté à ' . DB::val('SELECT name FROM users WHERE id=?', [$u]));
        if ($u !== (int)Auth::id()) \App\Core\Notifier::send($u, 'Client à rappeler', ($f['client_name'] ?: 'Client') . ' — ' . $f['reason'], '/surveys/followup/' . $f['id']); $this->go("surveys/followup/$id", 'Rappel affecté.');
    }
    function call(string $id): void {
        $f = $this->row($id); if (!$f || !in_array($f['status'], ['todo', 'doing'], true)) { $this->notFound(); return; } $r = (string)($_POST['result'] ?? ''); if (!isset(Followup::RESULT[$r])) $this->go("surveys/followup/$id", 'Choisissez le résultat de l\'appel.', 'danger');
        if (!$f['assigned_user_id']) DB::update('sv_followups', ['assigned_user_id' => Auth::id()], 'id=?', [$f['id']]);
        $st = Followup::attempt($f, $r, trim((string)($_POST['note'] ?? '')), (int)($_POST['retry_min'] ?? 60)); Audit::log('call', 'sv_followup', $id, null, ['result' => $r]);
        $this->go("surveys/followup/$id", $st === 'unreachable' ? 'Tentative enregistrée : client déclaré injoignable.' : 'Tentative enregistrée.');
    }
    function close(string $id): void {
        $f = $this->row($id); if (!$f || !in_array($f['status'], ['todo', 'doing'], true)) { $this->notFound(); return; } $o = (string)($_POST['outcome'] ?? ''); $note = trim((string)($_POST['note'] ?? ''));
        if (!isset(Followup::OUTCOME[$o])) $this->go("surveys/followup/$id", 'Choisissez l\'issue du rappel.', 'danger'); if ($o !== 'refused' && $o !== 'noaction' && $note === '') $this->go("surveys/followup/$id", 'Décrivez en une phrase ce qui a été dit ou fait.', 'danger');
        if (!$f['attempts'] && !in_array($o, ['noaction'], true)) $this->go("surveys/followup/$id", 'Enregistrez d\'abord une tentative d\'appel.', 'danger');
        Followup::close($f, $o, $note); Audit::log('close', 'sv_followup', $id, null, ['outcome' => $o]); $this->go('surveys/followup', 'Rappel clos.');
    }
    function reopen(string $id): void {
        $f = $this->row($id); if (!$f || in_array($f['status'], ['todo', 'doing'], true)) { $this->notFound(); return; }
        DB::update('sv_followups', ['status' => 'todo', 'closed_at' => null, 'outcome' => null, 'attempts' => 0, 'escalated' => 0, 'due_at' => date('Y-m-d H:i:s', time() + Followup::cfg('sla_hours') * 3600)], 'id=?', [$f['id']]); Followup::log((int)$f['id'], 'reopen', null, 'Rappel rouvert'); $this->go("surveys/followup/$id", 'Rappel rouvert.');
    }
    function create(): void {
        $ph = Sms::normalize((string)($_POST['phone'] ?? '')); $name = trim((string)($_POST['name'] ?? '')); $why = trim((string)($_POST['reason'] ?? ''));
        if (!$ph || $name === '' || $why === '') $this->go('surveys/followup', 'Nom, numéro valide et motif sont obligatoires.', 'danger');
        $id = Followup::create(['kind' => 'manual', 'priority' => max(1, min(3, (int)($_POST['priority'] ?? 2))), 'client_name' => mb_substr($name, 0, 160), 'client_phone' => $ph, 'reason' => mb_substr($why, 0, 300)]); Audit::log('create', 'sv_followup', (string)$id); $this->go("surveys/followup/$id", 'Rappel ajouté.');
    }
    function settingsSave(): void {
        $in = $_POST; $err = []; foreach (['csat_max' => [0, 5], 'adv_max' => [0, 5], 'sla_hours' => [1, 720], 'max_attempts' => [1, 10], 'retry_hours' => [1, 72]] as $k => [$a, $b]) { $v = (string)($in[$k] ?? ''); if (!ctype_digit($v) || (int)$v < $a || (int)$v > $b) $err[] = "« $k » doit être entre $a et $b."; }
        $dm = (string)($in['detractor_max'] ?? ''); if (!ctype_digit($dm) || (int)$dm > 9) $err[] = 'Le seuil de détracteur doit être entre 0 et 9.'; if ($err) $this->go('surveys/followup', implode(' ', $err), 'danger');
        foreach (['csat_max', 'adv_max', 'sla_hours', 'max_attempts', 'retry_hours'] as $k) Settings::set('sv.fu.' . $k, (string)$in[$k]); Settings::set('sv.fu.auto', empty($in['auto']) ? '0' : '1'); Settings::set('sv.detractor_max', $dm);
        Audit::log('save', 'sv_followup_settings'); $this->go('surveys/followup', 'Règles de rappel enregistrées.');
    }
    function scan(): void { $n = Followup::scan(); $e = Followup::escalate(); $this->go('surveys/followup', "$n rappel(s) créé(s), $e escalade(s)."); }
}
