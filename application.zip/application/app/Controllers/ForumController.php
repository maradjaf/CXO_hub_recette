<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Html};

/** Forum du personnel : catégories, sujets, réponses, modération (épingler, verrouiller, supprimer). */
class ForumController extends Controller {
    private function cat(string $id): ?array { return DB::one('SELECT * FROM fo_categories WHERE id=?', [(int)$id]); }
    private function topic(string $id): ?array { return DB::one('SELECT * FROM fo_topics WHERE id=?', [(int)$id]); }
    private function mod(): bool { return can('fo.moderate'); }
    private function canStart(array $c): bool { return (bool)$c['active'] && (!$c['staff_only'] || $this->mod()); }
    function index(): void {
        $cats = DB::all('SELECT * FROM fo_categories' . ($this->mod() ? '' : ' WHERE active=1') . ' ORDER BY sort_order, name');
        foreach ($cats as &$c) { $c['topics'] = (int)DB::val('SELECT COUNT(*) FROM fo_topics WHERE category_id=?', [(int)$c['id']]); $c['posts'] = (int)DB::val('SELECT COUNT(*) FROM fo_posts p JOIN fo_topics t ON t.id=p.topic_id WHERE t.category_id=?', [(int)$c['id']]);
            $c['last'] = DB::one('SELECT t.id, t.title, t.last_post_at FROM fo_topics t WHERE t.category_id=? ORDER BY t.last_post_at DESC LIMIT 1', [(int)$c['id']]); } unset($c);
        $recent = DB::all('SELECT t.*, c.name cname, u.name author FROM fo_topics t JOIN fo_categories c ON c.id=t.category_id LEFT JOIN users u ON u.id=t.user_id WHERE c.active=1 ORDER BY t.last_post_at DESC LIMIT 8');
        $this->view('forum/index', ['title' => 'Forum', 'cats' => $cats, 'recent' => $recent]);
    }
    function category(string $id): void {
        $c = $this->cat($id); if (!$c || (!$c['active'] && !$this->mod())) { $this->notFound(); return; } $q = trim((string)$this->in('q', '')); $p = [(int)$id]; $w = 't.category_id=?';
        if ($q !== '') { $w .= ' AND (t.title LIKE ? OR t.id IN (SELECT topic_id FROM fo_posts WHERE body LIKE ?))'; array_push($p, "%$q%", "%$q%"); }
        $pg = paginate("fo_topics t LEFT JOIN users u ON u.id=t.user_id WHERE $w", $p, $this->page(), 20, 't.*, u.name author', 't.pinned DESC, t.last_post_at DESC');
        $this->view('forum/category', ['title' => $c['name'], 'c' => $c, 'p' => $pg, 'canStart' => $this->canStart($c)]);
    }
    function search(): void {
        $q = trim((string)$this->in('q', '')); $pg = ['rows' => [], 'total' => 0, 'page' => 1, 'pages' => 1, 'per' => 20];
        if (mb_strlen($q) >= 2) $pg = paginate('fo_topics t JOIN fo_categories c ON c.id=t.category_id LEFT JOIN users u ON u.id=t.user_id WHERE c.active=1 AND (t.title LIKE ? OR t.id IN (SELECT topic_id FROM fo_posts WHERE body LIKE ?))', ["%$q%", "%$q%"], $this->page(), 20, 't.*, c.name cname, u.name author', 't.last_post_at DESC');
        $this->view('forum/search', ['title' => 'Recherche dans le forum', 'p' => $pg, 'q' => $q]);
    }
    function newTopic(): void {
        $c = $this->cat((string)$this->in('c', 0)); if (!$c || !$this->canStart($c)) { $c ? $this->forbidden() : $this->notFound(); return; }
        $this->view('forum/topic_form', ['title' => 'Nouveau sujet', 'c' => $c]);
    }
    function storeTopic(): void {
        $c = $this->cat((string)$this->in('category_id', 0)); if (!$c) { $this->notFound(); return; } if (!$this->canStart($c)) { $this->forbidden(); return; }
        [$d, $err] = $this->validate(['title' => ['label' => 'Le titre', 'req' => true, 'max' => 190], 'body' => ['label' => 'Le message', 'req' => true]], $_POST); if (!empty($d['body'])) { $d['body'] = Html::clean($d['body']); if (Html::text($d['body']) === '') $err['body'] = 'Le message est vide.'; elseif (mb_strlen($d['body']) > 60000) $err['body'] = 'Message trop long.'; }
        if ($err) $this->back($err, $_POST, 'forum/new?c=' . (int)$c['id']);
        $t = DB::insert('fo_topics', ['category_id' => (int)$c['id'], 'user_id' => Auth::id(), 'title' => $d['title'], 'created_at' => now(), 'last_post_at' => now()]);
        DB::insert('fo_posts', ['topic_id' => $t, 'user_id' => Auth::id(), 'body' => $d['body'], 'created_at' => now()]); Audit::log('create', 'fo_topics', $t, null, ['title' => $d['title']]); flash('Sujet publié.'); redirect("forum/t/$t");
    }
    function show(string $id): void {
        $t = $this->topic($id); if (!$t) { $this->notFound(); return; } $c = $this->cat((string)$t['category_id']); if (!$c['active'] && !$this->mod()) { $this->notFound(); return; }
        DB::exec('UPDATE fo_topics SET views=views+1 WHERE id=?', [(int)$id]);
        $pg = paginate('fo_posts p LEFT JOIN users u ON u.id=p.user_id WHERE p.topic_id=?', [(int)$id], $this->page(), 15, 'p.*, u.name author', 'p.id');
        $this->view('forum/topic', ['title' => $t['title'], 't' => $t, 'c' => $c, 'p' => $pg, 'mod' => $this->mod()]);
    }
    function reply(string $id): void {
        $t = $this->topic($id); if (!$t) { $this->notFound(); return; } $c = $this->cat((string)$t['category_id']); if (!$c['active'] || ($t['locked'] && !$this->mod()) || ($c['staff_only'] && !$this->mod())) { $this->forbidden(); return; }
        $b = Html::clean((string)$this->in('body', '')); if (Html::text($b) === '' || mb_strlen($b) > 60000) { flash('Écrivez votre réponse.', 'danger'); redirect("forum/t/$id"); }
        $pid = DB::insert('fo_posts', ['topic_id' => (int)$id, 'user_id' => Auth::id(), 'body' => $b, 'created_at' => now()]); DB::exec('UPDATE fo_topics SET replies=replies+1, last_post_at=? WHERE id=?', [now(), (int)$id]);
        if ((int)$t['user_id'] !== Auth::id() && $t['user_id']) Notifier::send((int)$t['user_id'], 'Réponse à votre sujet', Auth::user()['name'] . ' a répondu à « ' . mb_substr($t['title'], 0, 100) . ' ».', '/forum/t/' . $id);
        $last = (int)ceil(((int)$t['replies'] + 2) / 15); Audit::log('reply', 'fo_posts', $pid); flash('Réponse publiée.'); redirect("forum/t/$id?page=$last#p$pid");
    }
    function editPost(string $pid): void {
        $p = DB::one('SELECT * FROM fo_posts WHERE id=?', [(int)$pid]); if (!$p) { $this->notFound(); return; } $t = $this->topic((string)$p['topic_id']);
        if (((int)$p['user_id'] !== Auth::id() || ($t['locked'] && !$this->mod())) && !$this->mod()) { $this->forbidden(); return; }
        $b = Html::clean((string)$this->in('body', '')); if (Html::text($b) === '' || mb_strlen($b) > 60000) { flash('Message vide ou trop long.', 'danger'); redirect('forum/t/' . $t['id']); }
        DB::update('fo_posts', ['body' => $b, 'edited_at' => now()], 'id=?', [(int)$pid]); Audit::log('update', 'fo_posts', $pid, $p['body'], $b); flash('Message modifié.'); redirect('forum/t/' . $t['id'] . '#p' . $pid);
    }
    function deletePost(string $pid): void {
        $p = DB::one('SELECT * FROM fo_posts WHERE id=?', [(int)$pid]); if (!$p) { $this->notFound(); return; } $t = $this->topic((string)$p['topic_id']);
        if ((int)$p['user_id'] !== Auth::id() && !$this->mod()) { $this->forbidden(); return; }
        $first = (int)DB::val('SELECT MIN(id) FROM fo_posts WHERE topic_id=?', [(int)$t['id']]);
        if ((int)$pid === $first) { DB::exec('DELETE FROM fo_posts WHERE topic_id=?', [(int)$t['id']]); DB::exec('DELETE FROM fo_topics WHERE id=?', [(int)$t['id']]); Audit::log('delete', 'fo_topics', $t['id'], $t); flash('Sujet supprimé.'); redirect('forum/c/' . $t['category_id']); }
        DB::exec('DELETE FROM fo_posts WHERE id=?', [(int)$pid]); DB::exec('UPDATE fo_topics SET replies=CASE WHEN replies>0 THEN replies-1 ELSE 0 END WHERE id=?', [(int)$t['id']]); Audit::log('delete', 'fo_posts', $pid, $p); flash('Message supprimé.'); redirect('forum/t/' . $t['id']);
    }
    function moderate(string $id): void {
        $t = $this->topic($id); if (!$t) { $this->notFound(); return; } $a = (string)$this->in('act', '');
        if ($a === 'pin') DB::update('fo_topics', ['pinned' => $t['pinned'] ? 0 : 1], 'id=?', [(int)$id]); elseif ($a === 'lock') DB::update('fo_topics', ['locked' => $t['locked'] ? 0 : 1], 'id=?', [(int)$id]);
        elseif ($a === 'move' && ($c = $this->cat((string)$this->in('category_id', 0)))) DB::update('fo_topics', ['category_id' => (int)$c['id']], 'id=?', [(int)$id]);
        Audit::log('moderate', 'fo_topics', $id, null, ['act' => $a]); flash('Sujet mis à jour.'); redirect("forum/t/$id");
    }
    // ---- Catégories (modérateurs)
    function categories(): void { $this->view('forum/categories', ['title' => 'Catégories du forum', 'cats' => DB::all('SELECT c.*, (SELECT COUNT(*) FROM fo_topics WHERE category_id=c.id) n FROM fo_categories c ORDER BY sort_order, name')]); }
    function saveCategory(): void {
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 120], 'description' => ['label' => 'La description', 'max' => 300]], $_POST); $id = (int)$this->in('id', 0);
        if (!$err && DB::val('SELECT 1 FROM fo_categories WHERE name=? AND id<>?', [$d['name'], $id])) $err['name'] = 'Une catégorie porte déjà ce nom.';
        if ($err) $this->back($err, $_POST, 'forum/categories');
        $d += ['sort_order' => (int)$this->in('sort_order', 0), 'staff_only' => isset($_POST['staff_only']) ? 1 : 0, 'active' => isset($_POST['active']) || !$id ? 1 : 0];
        if ($id && $this->cat((string)$id)) { DB::update('fo_categories', $d, 'id=?', [$id]); Audit::log('update', 'fo_categories', $id, null, $d); } else { $id = DB::insert('fo_categories', $d); Audit::log('create', 'fo_categories', $id, null, $d); }
        flash('Catégorie enregistrée.'); redirect('forum/categories');
    }
}
