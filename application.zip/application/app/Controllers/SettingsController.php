<?php
namespace App\Controllers;
use App\Core\{Controller, Settings, Audit, DB};
class SettingsController extends Controller {
    const DEFS = [
        'Marque' => ['app.name' => ['Nom de l\'application', 'CXO Excellence Hub'], 'brand.primary' => ['Couleur principale (bleu)', '#003A84'], 'brand.accent' => ['Couleur d\'accent (jaune)', '#FFCE00'], 'brand.sky' => ['Troisième couleur : bleu ciel (boutons secondaires)', '#7CC8FF']],
        'Sécurité' => ['security.max_attempts' => ['Échecs de connexion avant verrouillage', '5'], 'security.lock_minutes' => ['Durée de verrouillage (minutes)', '15']],
        'Processus' => ['pr_four_eyes' => ['Double validation des versions de processus (1 = oui, 0 = non)', '1']],
        'Exploitation' => ['sys.maintenance' => ['Mode maintenance (1 = actif : seuls les administrateurs se connectent)', '0'], 'sys.maintenance_msg' => ['Message affiché pendant la maintenance', ''], 'sys.banner' => ['Bandeau d\'annonce affiché à tous (vide = aucun)', ''], 'sys.backup_keep' => ['Sauvegardes conservées', '7'], 'sys.purge_notif_days' => ['Conservation des notifications lues (jours)', '90'], 'sys.purge_login_days' => ['Conservation des tentatives de connexion (jours)', '90']],
        'Assistant' => ['bot.llm' => ['Rédaction des réponses par un modèle Claude (1 = oui, 0 = recherche seule ; nécessite ANTHROPIC_API_KEY dans .env)', '0'], 'bot.model' => ['Modèle utilisé', 'claude-sonnet-5-5'], 'bot.rate_per_hour' => ['Questions par utilisateur et par heure', '30'], 'bot.images' => ['Analyse d\'images (captures, photos) par le modèle (1 = oui, 0 = non ; exige le mode IA)', '0'], 'bot.images_per_day' => ['Images par utilisateur et par jour', '20'], 'bot.price_in' => ['Prix du modèle : par million de tokens en entrée (pour estimer le coût ; 0 = ne pas estimer)', '0'], 'bot.price_out' => ['Prix du modèle : par million de tokens en sortie', '0'], 'bot.retention_days' => ['Conservation des conversations (jours)', '180']],
        'Planification' => ['pl.min_rest_hours' => ['Repos minimal entre deux shifts (heures)', '11'], 'pl.max_week_hours' => ['Alerte au-delà de (heures par semaine)', '48'], 'pl.t_sl' => ['Objectif par défaut : taux de service (%)', '80'], 'pl.t_ab' => ['Objectif par défaut : abandon maximal (%)', '5'], 'pl.t_aht' => ['Objectif par défaut : durée moyenne de traitement (s)', '300'], 'pl.t_wait' => ['Objectif par défaut : attente moyenne (s)', '30'], 'pl.sl_threshold' => ['Seuil du taux de service (secondes)', '20'], 'pl.peak_share' => ['Part du volume journalier à l\'heure de pointe (%)', '12'], 'pl.shrinkage' => ['Perte de capacité : pauses, formation, absences (%)', '25']],
        'Projets' => ['pj.blocker_days' => ['Alerte sur un point bloquant ouvert depuis (jours)', '7'], 'pj.report_due_dow' => ['Jour limite du point hebdomadaire (1 = lundi … 5 = vendredi)', '4'], 'pj.drift_pts' => ['Alerte si l\'avancement est en retard sur le temps écoulé de (points)', '20'], 'pj.late_red_days' => ['Jalon en retard de (jours) : alerte grave', '14']],
        'Événements' => ['ev.default_capacity' => ['Capacité par défaut d\'un événement (0 = illimitée)', '0'], 'ev.remind_hours' => ['Rappel envoyé aux inscrits (heures avant le début)', '24'], 'ev.checkin_open_minutes' => ['Ouverture du pointage de présence (minutes avant le début)', '60'], 'ev.feedback_days' => ['Demande d\'avis après l\'événement (jours, 0 = jamais)', '1']],
        'Connaissances' => ['kb_review_months' => ['Revue des articles (mois)', '12'], 'kb.sop_review_months' => ['Revue des modes opératoires (mois)', '12'], 'kb.sop_four_eyes' => ['Modes opératoires : relecture par une autre personne que l\'auteur (1 = oui, 0 = non)', '1'], 'kb.reread_days' => ['Relance des lectures obligatoires non confirmées (jours, 0 = jamais)', '7']],
        'Scripts et fins d\'appel' => ['cs.review_months' => ['Revue des scripts (mois)', '6'], 'cs.four_eyes' => ['Scripts : relecture par une autre personne que l\'auteur (1 = oui, 0 = non)', '1'], 'cs.adherence_target' => ['Objectif d\'adhérence aux scripts (%)', '85'], 'cs.check_min_per_agent' => ['Contrôles minimum par conseiller et par mois (0 = pas d\'alerte)', '4']],
        'Études de cas' => ['cc.pass_pct' => ['Seuil de réussite par défaut (%)', '70'], 'cc.max_attempts' => ['Tentatives maximum par défaut (0 = illimité)', '3'], 'cc.reminder_days' => ['Rappel avant l\'échéance (jours, 0 = jamais)', '2']],
        'Demandes de formation' => ['tq.threshold_p1' => ['Score minimum P1 Critique', '80'], 'tq.threshold_p2' => ['Score minimum P2 Haute', '60'], 'tq.threshold_p3' => ['Score minimum P3 Moyenne', '40'], 'tq.sla_p1_hours' => ['Délai P1 (heures)', '48'], 'tq.sla_p2_days' => ['Délai P2 (jours ouvrés)', '5'], 'tq.sla_p3_days' => ['Délai P3 (jours ouvrés)', '15'],
            'tq.risk_critical' => ['Risques cochés pour un niveau « Critique » (au moins)', '6'], 'tq.risk_high' => ['Risques cochés pour un niveau « Élevé » (au moins)', '4'], 'tq.risk_medium' => ['Risques cochés pour un niveau « Moyen » (au moins)', '2'], 'tq.supports_full' => ['Types de supports pour « supports complets » (au moins)', '4'], 'tq.teams_webhook' => ['Webhook Teams des alertes P1/P2 (https, vide = désactivé)', '']],
        'Historique d\'activité' => ['activity.retention_months' => ['Conservation en ligne (mois)', '12']],
    ];
    /** Règle de validation par réglage : color | bool | int:min:max | num:max | text:max | model | money. Sans règle : texte de 200 caractères au plus. */
    const RULES = [
        'brand.primary' => 'color', 'brand.accent' => 'color', 'brand.sky' => 'color', 'app.name' => 'text:100', 'security.max_attempts' => 'int:1:1000', 'security.lock_minutes' => 'int:1:100000', 'pr_four_eyes' => 'bool',
        'sys.maintenance' => 'bool', 'sys.maintenance_msg' => 'text:300', 'sys.banner' => 'text:300', 'sys.backup_keep' => 'int:1:3650', 'sys.purge_notif_days' => 'int:1:3650', 'sys.purge_login_days' => 'int:1:3650',
        'bot.llm' => 'bool', 'bot.images' => 'bool', 'bot.model' => 'model', 'bot.rate_per_hour' => 'int:1:3650', 'bot.images_per_day' => 'int:1:3650', 'bot.retention_days' => 'int:1:3650', 'bot.price_in' => 'money', 'bot.price_out' => 'money',
        'pl.t_sl' => 'num:100', 'pl.t_ab' => 'num:100', 'pl.peak_share' => 'num:100', 'pl.shrinkage' => 'num:100', 'pl.min_rest_hours' => 'num:10000', 'pl.max_week_hours' => 'num:10000', 'pl.t_aht' => 'num:10000', 'pl.t_wait' => 'num:10000', 'pl.sl_threshold' => 'num:10000',
        'pj.blocker_days' => 'int:1:365', 'pj.report_due_dow' => 'int:1:5', 'pj.drift_pts' => 'int:1:365', 'pj.late_red_days' => 'int:1:365', 'activity.retention_months' => 'int:1:1000000',
        'ev.default_capacity' => 'int:0:100000', 'ev.remind_hours' => 'int:1:720', 'ev.checkin_open_minutes' => 'int:0:1440', 'ev.feedback_days' => 'int:0:60',
        'kb_review_months' => 'int:1:60', 'kb.sop_review_months' => 'int:1:60', 'kb.sop_four_eyes' => 'bool', 'kb.reread_days' => 'int:0:90',
        'cs.review_months' => 'int:1:60', 'cs.four_eyes' => 'bool', 'cs.adherence_target' => 'int:1:100', 'cs.check_min_per_agent' => 'int:0:100',
        'tq.threshold_p1' => 'int:1:100', 'tq.threshold_p2' => 'int:1:100', 'tq.threshold_p3' => 'int:1:100', 'tq.sla_p1_hours' => 'int:1:720', 'tq.sla_p2_days' => 'int:1:60', 'tq.sla_p3_days' => 'int:1:90', 'tq.risk_critical' => 'int:1:30', 'tq.risk_high' => 'int:1:30', 'tq.risk_medium' => 'int:1:30', 'tq.supports_full' => 'int:1:20', 'tq.teams_webhook' => 'https:300',
        'cc.pass_pct' => 'int:1:100', 'cc.max_attempts' => 'int:0:50', 'cc.reminder_days' => 'int:0:30',
    ];
    static function rule(string $k): string { return self::RULES[$k] ?? 'text:200'; }
    /** Valide une valeur selon la règle ; renvoie [valeur normalisée, message d'erreur ou null]. */
    static function check(string $k, string $label, string $v): array {
        $v = trim($v); [$t, $a, $b] = array_pad(explode(':', self::rule($k)), 3, null);
        switch ($t) {
            case 'color': return preg_match('/^#[0-9A-Fa-f]{6}$/', $v) ? [$v, null] : [$v, "$label : code couleur invalide (ex. #003A84)."];
            case 'bool': return in_array($v, ['0', '1'], true) ? [$v, null] : [$v, "$label : 0 ou 1 attendu."];
            case 'int': return ctype_digit($v) && (int)$v >= (int)$a && (int)$v <= (int)$b ? [$v, null] : [$v, "$label : nombre entier de $a à $b attendu."];
            case 'num': $n = str_replace(',', '.', $v); return is_numeric($n) && (float)$n > 0 && (float)$n <= (float)$a ? [$n, null] : [$v, "$label : nombre positif attendu."];
            case 'money': return preg_match('/^\d{1,6}([.,]\d{1,4})?$/', $v) ? [str_replace(',', '.', $v), null] : [$v, "$label : montant positif attendu."];
            case 'https': return $v === '' || preg_match('#^https://[^\s]{4,}$#i', $v) ? [mb_substr($v, 0, (int)$a), null] : [$v, "$label : adresse https attendue (ou vide)."];
            case 'model': return preg_match('/^[A-Za-z0-9._-]{3,60}$/', $v) ? [$v, null] : [$v, "$label : nom de modèle invalide."];
            default: return [mb_substr($v, 0, (int)($a ?: 200)), null];
        }
    }
    static function known(): array { $o = []; foreach (self::DEFS as $g => $items) foreach ($items as $k => [$l, $d]) $o[$k] = [$l, $d, $g]; return $o; }
    function index(): void {
        $this->view('admin/settings', ['title' => 'Paramètres', 'defs' => self::DEFS]);
    }
    function update(): void {
        $before = Settings::all(); $after = []; $err = [];
        foreach (self::DEFS as $grp) foreach ($grp as $k => [$label, $def]) {
            $key = str_replace('.', '_', $k); if (!array_key_exists($key, $_POST)) continue;   // champ absent : le réglage reste inchangé
            [$v, $e] = self::check($k, $label, (string)$_POST[$key]); if ($e) $err[] = $e; else $after[$k] = $v;
        }
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('admin/settings'); }   // rien n'est enregistré tant que tout n'est pas valide
        foreach ($after as $k => $v) Settings::set($k, $v);
        Audit::log('update', 'settings', null, array_intersect_key($before, $after), $after);
        flash('Paramètres enregistrés.'); redirect('admin/settings');
    }
    /** Rétablit les valeurs par défaut d'un groupe de réglages. */
    function reset(): void {
        $g = (string)($_POST['group'] ?? ''); if (!isset(self::DEFS[$g])) { flash('Groupe inconnu.', 'danger'); redirect('admin/settings'); }
        $old = []; foreach (array_keys(self::DEFS[$g]) as $k) { $old[$k] = Settings::get($k); DB::exec('DELETE FROM settings WHERE k=?', [$k]); }
        Settings::reset(); Audit::log('reset', 'settings', null, $old, ['group' => $g]); flash("Valeurs par défaut rétablies pour « $g »."); redirect('admin/settings');
    }
}
