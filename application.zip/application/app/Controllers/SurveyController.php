<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Files, Settings, Sv};

/** Lot 65 : enquêtes de satisfaction. Paramétrage réservé aux coachs qualité et à l'admin (survey.manage). */
class SurveyController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    private function filters(): array {
        [$a, $b] = Sv::periodDefault(); $f = ['from' => (string)$this->in('from', $a), 'to' => (string)$this->in('to', $b), 'scope' => 1];
        foreach (['survey_id', 'team_id', 'store_id', 'employee_id'] as $k) if ((int)$this->in($k)) $f[$k] = (int)$this->in($k);
        if (isset(Sv::CHAN[(string)$this->in('channel')])) $f['channel'] = (string)$this->in('channel'); return $f;
    }
    private function names(): array {
        return ['emp' => array_column(array_map(fn($e) => ['id' => $e['id'], 'n' => trim($e['last_name'] . ' ' . $e['first_name'])], DB::all('SELECT id, last_name, first_name FROM employees')), 'n', 'id'), 'team' => array_column(DB::all('SELECT id, name FROM teams'), 'name', 'id'), 'store' => array_column(DB::all('SELECT id, name FROM stores'), 'name', 'id')];
    }

    // ------------------------------------------------------------------ indicateurs
    function index(): void {
        $f = $this->filters(); $by = (string)$this->in('by', 'employee_id'); if (!in_array($by, ['employee_id', 'team_id', 'store_id', 'channel', 'month'], true)) $by = 'employee_id';
        $all = Sv::stats($f)['all'] ?? null; $rows = Sv::stats($f, $by); $lab = $this->labels($by, array_keys($rows));
        if ($by === 'month') krsort($rows); else uasort($rows, fn($a, $b) => ($b['csat_pct'] ?? -1) <=> ($a['csat_pct'] ?? -1));
        if ($this->in('export') === 'csv') { Audit::log('export', 'survey_stats', null, null, ['by' => $by]);
            csv_download('indicateurs_enquetes_' . date('Ymd_His') . '.csv', ['Regroupement', 'Réponses', 'CSAT %', 'CSAT moyen', 'NPS', 'Promoteurs', 'Passifs', 'Détracteurs', 'Effort moyen', 'Note conseiller'], array_map(fn($k, $r) => [$lab[$k] ?? $k, $r['n'], $r['csat_pct'], $r['csat_avg'], $r['nps'], $r['prom'], $r['pas'], $r['det'], $r['ces'], $r['adv']], array_keys($rows), $rows)); }
        $this->view('survey/index', ['title' => 'Enquêtes — Indicateurs', 'f' => $f, 'by' => $by, 'all' => $all, 'rows' => $rows, 'lab' => $lab, 'dims' => Sv::dimensions($f), 'month' => Sv::stats($f, 'month'), 'surveys' => DB::all('SELECT id, name FROM sv_surveys ORDER BY name'),
            'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'), 'stores' => DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name'), 'min' => Sv::cfg('min_responses'), 'detr' => (int)DB::val('SELECT COUNT(*) FROM sv_responses r WHERE ' . Sv::where($f)[0] . ' AND r.nps IS NOT NULL AND r.nps<=?', array_merge(Sv::where($f)[1], [Sv::cfg('detractor_max')]))]);
    }
    private function labels(string $by, array $keys): array {
        $n = $this->names(); $o = [];
        foreach ($keys as $k) $o[$k] = match ($by) { 'employee_id' => $k === '' ? 'Sans conseiller' : ($n['emp'][$k] ?? "#$k"), 'team_id' => $n['team'][$k] ?? 'Sans équipe', 'store_id' => $n['store'][$k] ?? 'Sans store', 'channel' => Sv::CHAN[$k] ?? 'Non précisé', default => $k };
        return $o;
    }
    function mine(): void {
        $me = (int)(Auth::user()['employee_id'] ?? 0); $f = $this->filters(); unset($f['scope']); $f['employee_id'] = $me ?: -1; $all = Sv::stats($f)['all'] ?? null; $min = Sv::cfg('min_responses'); $ok = $all && !$all['low'];
        $this->view('survey/mine', ['title' => 'Mes résultats d\'enquêtes', 'f' => $f, 'all' => $all, 'ok' => $ok, 'min' => $min, 'months' => $ok ? Sv::stats($f, 'month') : [], 'dims' => $ok ? Sv::dimensions($f) : [],
            'comments' => $ok ? DB::all('SELECT answered_at, csat, nps, channel, comment FROM sv_responses r WHERE ' . Sv::where($f)[0] . " AND r.comment IS NOT NULL AND r.comment<>'' ORDER BY r.answered_at DESC LIMIT 20", Sv::where($f)[1]) : []]);
    }
    function responses(): void {
        $f = $this->filters(); [$w, $p] = Sv::where($f); $q = trim((string)$this->in('q', '')); if ($q !== '') { $w .= ' AND (r.comment LIKE ? OR r.client_ref LIKE ? OR r.ext_ref LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        if ($this->in('detractors')) { $w .= ' AND r.nps IS NOT NULL AND r.nps<=?'; $p[] = Sv::cfg('detractor_max'); }
        $pg = paginate("sv_responses r LEFT JOIN employees e ON e.id=r.employee_id LEFT JOIN sv_surveys s ON s.id=r.survey_id WHERE $w", $p, $this->page(), 25, "r.*, e.last_name, e.first_name, s.name survey_name", 'r.answered_at DESC, r.id DESC');
        $this->view('survey/responses', ['title' => 'Enquêtes — Réponses', 'f' => $f, 'q' => $q, 'p' => $pg, 'surveys' => DB::all('SELECT id, name FROM sv_surveys ORDER BY name'), 'detr' => (bool)$this->in('detractors')]);
    }
    function response(string $id): void {
        $r = DB::one('SELECT r.*, e.last_name, e.first_name, e.matricule, s.name survey_name FROM sv_responses r LEFT JOIN employees e ON e.id=r.employee_id LEFT JOIN sv_surveys s ON s.id=r.survey_id WHERE r.id=?', [(int)$id]);
        if (!$r || ($r['employee_id'] ? !\App\Core\Scope::allows((int)$r['employee_id']) : !can('scope.all'))) { $this->notFound(); return; }
        Audit::log('view', 'survey_response', $id);
        $this->view('survey/response', ['title' => 'Réponse d\'enquête', 'r' => $r, 'answers' => DB::all('SELECT a.num, a.txt, q.label, q.dimension, q.type FROM sv_answers a JOIN sv_questions q ON q.id=a.question_id WHERE a.response_id=? ORDER BY q.position', [(int)$id]), 'inter' => $r['interaction_id'] ? DB::one('SELECT * FROM sv_interactions WHERE id=?', [(int)$r['interaction_id']]) : null]);
    }

    // ------------------------------------------------------------------ modèles d'enquête
    function templates(): void {
        $this->view('survey/templates', ['title' => 'Modèles d\'enquête', 'list' => DB::all('SELECT s.*, (SELECT COUNT(*) FROM sv_questions q WHERE q.survey_id=s.id) nq, (SELECT COUNT(*) FROM sv_responses r WHERE r.survey_id=s.id) nr FROM sv_surveys s ORDER BY s.name'),
            'cfg' => ['satisfied_min' => Sv::cfg('satisfied_min'), 'min_responses' => Sv::cfg('min_responses'), 'promoter_min' => Sv::cfg('promoter_min'), 'detractor_max' => Sv::cfg('detractor_max')]]);
    }
    function templateCreate(): void {
        [$v, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => 1, 'max' => 180]], $_POST); $kind = isset(Sv::KIND[$_POST['kind'] ?? '']) ? $_POST['kind'] : 'csat'; $sc = in_array($_POST['channel_scope'] ?? '', ['all', 'call', 'store', 'digital'], true) ? $_POST['channel_scope'] : 'all';
        if ($err) $this->go('surveys/templates', implode(' ', $err), 'danger');
        $code = strtoupper(substr(preg_replace('/[^A-Za-z0-9]+/', '-', iconv('UTF-8', 'ASCII//TRANSLIT', $v['name']) ?: $v['name']), 0, 30)); $code = trim($code, '-') ?: 'ENQ'; $base = $code; $i = 1; while (DB::val('SELECT 1 FROM sv_surveys WHERE code=?', [$code])) $code = $base . '-' . ++$i;
        $id = DB::insert('sv_surveys', ['code' => $code, 'name' => $v['name'], 'kind' => $kind, 'channel_scope' => $sc, 'status' => 'active', 'created_by' => Auth::id(), 'created_at' => now()]);
        Audit::log('create', 'sv_survey', (string)$id, null, ['name' => $v['name']]); $this->go('surveys/templates/' . $id, 'Modèle créé : ajoutez les questions.');
    }
    function template(string $id): void {
        $s = DB::one('SELECT * FROM sv_surveys WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; }
        $this->view('survey/template', ['title' => $s['name'], 's' => $s, 'qs' => DB::all('SELECT q.*, (SELECT COUNT(*) FROM sv_answers a WHERE a.question_id=q.id) used FROM sv_questions q WHERE survey_id=? ORDER BY position, id', [(int)$id])]);
    }
    function templateSave(string $id): void {
        $s = DB::one('SELECT * FROM sv_surveys WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; }
        [$v, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => 1, 'max' => 180], 'description' => ['label' => 'La description', 'max' => 600]], $_POST); if ($err) $this->go('surveys/templates/' . $id, implode(' ', $err), 'danger');
        DB::update('sv_surveys', ['name' => $v['name'], 'description' => $v['description'], 'kind' => isset(Sv::KIND[$_POST['kind'] ?? '']) ? $_POST['kind'] : $s['kind'], 'channel_scope' => in_array($_POST['channel_scope'] ?? '', ['all', 'call', 'store', 'digital'], true) ? $_POST['channel_scope'] : $s['channel_scope'],
            'status' => ($_POST['status'] ?? '') === 'archived' ? 'archived' : 'active', 'invite_text' => trim((string)($_POST['invite_text'] ?? '')) ?: null, 'reminder_days' => max(0, min(30, (int)($_POST['reminder_days'] ?? 0)))], 'id=?', [(int)$id]);
        Audit::log('save', 'sv_survey', $id); $this->go('surveys/templates/' . $id, 'Modèle enregistré.');
    }
    function questionSave(string $id): void {
        $s = DB::one('SELECT * FROM sv_surveys WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; }
        [$v, $err] = $this->validate(['code' => ['label' => 'Le code', 'req' => 1, 'max' => 40], 'label' => ['label' => 'La question', 'req' => 1, 'max' => 300]], $_POST); $code = strtoupper(preg_replace('/[^A-Za-z0-9_]/', '', (string)($v['code'] ?? '')));
        if (!$err && $code === '') $err['code'] = 'Le code ne peut contenir que des lettres, chiffres et _.'; $qid = (int)($_POST['qid'] ?? 0);
        if (!$err && DB::val('SELECT 1 FROM sv_questions WHERE survey_id=? AND code=? AND id<>?', [(int)$id, $code, $qid])) $err['code'] = 'Ce code est déjà utilisé dans ce modèle.';
        $type = isset(Sv::QTYPE[$_POST['type'] ?? '']) ? $_POST['type'] : 'scale5'; $metric = isset(Sv::METRIC[$_POST['metric'] ?? '']) ? $_POST['metric'] : 'none';
        if (!$err && $metric !== 'none' && !in_array($type, ['scale5', 'scale10'], true)) $err['metric'] = 'Une note (CSAT, NPS, effort, conseiller) exige une échelle.';
        if ($err) $this->go('surveys/templates/' . $id, implode(' ', $err), 'danger');
        $row = ['code' => $code, 'label' => $v['label'], 'type' => $type, 'dimension' => isset(Sv::DIM[$_POST['dimension'] ?? '']) ? $_POST['dimension'] : 'global', 'metric' => $metric, 'required' => empty($_POST['optional']) ? 1 : 0, 'options' => $type === 'choice' ? mb_substr(trim((string)($_POST['options'] ?? '')), 0, 500) : null, 'position' => (int)($_POST['position'] ?? 0) ?: ((int)DB::val('SELECT COALESCE(MAX(position),0) FROM sv_questions WHERE survey_id=?', [(int)$id]) + 1)];
        if ($qid && DB::val('SELECT 1 FROM sv_questions WHERE id=? AND survey_id=?', [$qid, (int)$id])) DB::update('sv_questions', $row, 'id=?', [$qid]); else DB::insert('sv_questions', $row + ['survey_id' => (int)$id]);
        Audit::log('save', 'sv_question', $id, null, ['code' => $code]); $this->go('surveys/templates/' . $id, 'Question enregistrée.');
    }
    function questionDelete(string $id): void {
        $q = DB::one('SELECT * FROM sv_questions WHERE id=?', [(int)$id]); if (!$q) { $this->notFound(); return; }
        if (DB::val('SELECT 1 FROM sv_answers WHERE question_id=?', [(int)$id])) $this->go('surveys/templates/' . $q['survey_id'], 'Cette question a des réponses : elle ne peut pas être supprimée.', 'danger');
        DB::exec('DELETE FROM sv_questions WHERE id=?', [(int)$id]); $this->go('surveys/templates/' . $q['survey_id'], 'Question supprimée.');
    }
    function settingsSave(): void {
        $sat = (int)($_POST['satisfied_min'] ?? 4); $min = (int)($_POST['min_responses'] ?? 5); $pm = (int)($_POST['promoter_min'] ?? 9); $dm = (int)($_POST['detractor_max'] ?? 6);
        if ($sat < 1 || $sat > 5 || $min < 1 || $min > 200 || $pm < 1 || $pm > 10 || $dm < 0 || $dm >= $pm) $this->go('surveys/templates', 'Valeurs invalides : satisfait 1 à 5, réponses minimales 1 à 200, promoteur 1 à 10, détracteur strictement inférieur au promoteur.', 'danger');
        foreach (['satisfied_min' => $sat, 'min_responses' => $min, 'promoter_min' => $pm, 'detractor_max' => $dm] as $k => $v) Settings::set('sv.' . $k, (string)$v);
        Audit::log('save', 'sv_settings', null, null, compact('sat', 'min', 'pm', 'dm')); $this->go('surveys/templates', 'Règles de calcul enregistrées.');
    }

    // ------------------------------------------------------------------ correspondances de colonnes
    function mappings(): void {
        $this->view('survey/mappings', ['title' => 'Correspondances de colonnes', 'list' => DB::all('SELECT m.*, s.name survey_name FROM sv_mappings m LEFT JOIN sv_surveys s ON s.id=m.survey_id ORDER BY m.kind, m.name'), 'surveys' => DB::all('SELECT id, name FROM sv_surveys ORDER BY name')]);
    }
    function mappingSave(string $id = ''): void {
        [$v, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => 1, 'max' => 150]], $_POST); $kind = ($_POST['kind'] ?? '') === 'dump' ? 'dump' : 'results'; $cols = Sv::lines($_POST['columns'] ?? '');
        foreach ($kind === 'dump' ? ['ref', 'occurred_at'] : ['answered_at'] as $req) if (!isset($cols[$req])) $err['columns'] = "La colonne obligatoire « $req » doit être renseignée (ligne champ=colonne).";
        $allowed = array_keys($kind === 'dump' ? Sv::DUMP_FIELDS : Sv::RES_FIELDS); foreach (array_keys($cols) as $k) if (!in_array($k, $allowed, true)) $err['columns'] = "Champ inconnu « $k » : " . implode(', ', $allowed) . '.';
        $sv = (int)($_POST['survey_id'] ?? 0); if ($sv && !DB::val('SELECT 1 FROM sv_surveys WHERE id=?', [$sv])) $err['survey_id'] = 'Modèle d\'enquête inconnu.';
        if ($err) $this->go('surveys/mappings', implode(' ', $err), 'danger');
        $row = ['name' => $v['name'], 'source' => isset(Sv::SOURCE[$_POST['source'] ?? '']) ? $_POST['source'] : 'autre', 'kind' => $kind, 'survey_id' => $sv ?: null, 'columns' => trim((string)$_POST['columns']), 'questions' => trim((string)($_POST['questions'] ?? '')) ?: null, 'scales' => mb_substr(trim((string)($_POST['scales'] ?? '')), 0, 120) ?: null, 'date_format' => mb_substr(trim((string)($_POST['date_format'] ?? '')), 0, 20) ?: null];
        if ((int)$id) { if (!DB::val('SELECT 1 FROM sv_mappings WHERE id=?', [(int)$id])) { $this->notFound(); return; } DB::update('sv_mappings', $row, 'id=?', [(int)$id]); } else $id = (string)DB::insert('sv_mappings', $row + ['created_at' => now()]);
        Audit::log('save', 'sv_mapping', (string)$id); $this->go('surveys/mappings', 'Correspondance enregistrée.');
    }
    function mappingDelete(string $id): void {
        if (DB::val('SELECT 1 FROM sv_sources WHERE mapping_id=?', [(int)$id])) $this->go('surveys/mappings', 'Cette correspondance est utilisée par un dossier surveillé.', 'danger');
        DB::exec('DELETE FROM sv_mappings WHERE id=?', [(int)$id]); $this->go('surveys/mappings', 'Correspondance supprimée.');
    }
    function mappingTemplate(string $id): void {
        $m = DB::one('SELECT * FROM sv_mappings WHERE id=?', [(int)$id]); if (!$m) { $this->notFound(); return; }
        $h = array_values(array_unique(array_merge(array_values(Sv::lines($m['columns'])), array_values(Sv::lines($m['questions'])))));
        csv_download('modele_' . preg_replace('/[^a-z0-9]+/', '_', strtolower($m['name'])) . '.csv', $h, [array_map(fn($c) => 'exemple', $h)]);
    }

    // ------------------------------------------------------------------ dossiers surveillés
    function sources(): void {
        $this->view('survey/sources', ['title' => 'Dossiers surveillés', 'list' => DB::all('SELECT s.*, m.name mapping_name, m.kind FROM sv_sources s LEFT JOIN sv_mappings m ON m.id=s.mapping_id ORDER BY s.name'), 'mappings' => DB::all('SELECT id, name, kind FROM sv_mappings ORDER BY name'), 'surveys' => DB::all('SELECT id, name FROM sv_surveys ORDER BY name'), 'root' => 'storage/surveys/inbox']);
    }
    function sourceSave(string $id = ''): void {
        [$v, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => 1, 'max' => 150]], $_POST); $folder = strtolower(trim((string)($_POST['folder'] ?? '')));
        if (!preg_match('/^[a-z0-9_-]{2,40}$/', $folder)) $err['folder'] = 'Nom de dossier : 2 à 40 caractères (lettres minuscules, chiffres, - et _).';
        if (!DB::val('SELECT 1 FROM sv_mappings WHERE id=?', [(int)($_POST['mapping_id'] ?? 0)])) $err['mapping_id'] = 'Choisissez une correspondance.';
        if (!$err && DB::val('SELECT 1 FROM sv_sources WHERE folder=? AND id<>?', [$folder, (int)$id])) $err['folder'] = 'Ce dossier est déjà surveillé.'; if ($err) $this->go('surveys/sources', implode(' ', $err), 'danger');
        $row = ['name' => $v['name'], 'folder' => $folder, 'mapping_id' => (int)$_POST['mapping_id'], 'survey_id' => (int)($_POST['survey_id'] ?? 0) ?: null, 'frequency' => isset(Sv::FREQ[$_POST['frequency'] ?? '']) ? $_POST['frequency'] : 'daily', 'active' => empty($_POST['inactive']) ? 1 : 0];
        if ((int)$id) { if (!DB::val('SELECT 1 FROM sv_sources WHERE id=?', [(int)$id])) { $this->notFound(); return; } DB::update('sv_sources', $row, 'id=?', [(int)$id]); } else DB::insert('sv_sources', $row + ['created_at' => now()]);
        @mkdir(ROOT . '/storage/surveys/inbox/' . $folder . '/processed', 0775, true); Audit::log('save', 'sv_source', (string)$id, null, ['folder' => $folder]); $this->go('surveys/sources', 'Dossier surveillé enregistré.');
    }
    function sourceRun(string $id): void { $s = DB::one('SELECT * FROM sv_sources WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; } $this->go('surveys/sources', Sv::runSource($s)); }
    function sourceDelete(string $id): void { DB::exec('DELETE FROM sv_sources WHERE id=?', [(int)$id]); $this->go('surveys/sources', 'Dossier surveillé retiré (les fichiers restent sur le serveur).'); }

    // ------------------------------------------------------------------ import manuel
    function importForm(): void {
        $this->view('survey/import', ['title' => 'Importer des données d\'enquête', 'mappings' => DB::all('SELECT id, name, kind, survey_id FROM sv_mappings ORDER BY kind, name'), 'surveys' => DB::all('SELECT id, name FROM sv_surveys ORDER BY name'),
            'batches' => DB::all('SELECT b.*, u.name user_name FROM sv_batches b LEFT JOIN users u ON u.id=b.user_id ORDER BY b.id DESC LIMIT 30'), 'report' => $_SESSION['_svreport'] ?? null]);
    }
    function importRun(): void {
        unset($_SESSION['_svreport']); $m = DB::one('SELECT * FROM sv_mappings WHERE id=?', [(int)($_POST['mapping_id'] ?? 0)]); if (!$m) $this->go('surveys/import', 'Choisissez une correspondance de colonnes.', 'danger');
        [$files, $ferr] = Files::uploads('files'); if (!$files) $this->go('surveys/import', $ferr ? implode(' ', $ferr) : 'Joignez un fichier CSV ou Excel.', 'danger');
        $sid = (int)($_POST['survey_id'] ?? 0) ?: (int)$m['survey_id']; $dry = !empty($_POST['dry']);
        [$bid, $bil] = Sv::run($m['kind'], $m, $files[0], $sid ?: null, $dry, ($dry ? 'Analyse : ' : '') . $files[0]['name']); Audit::log($dry ? 'dry-run' : 'import', 'survey_import', $bid ? (string)$bid : null, null, ['file' => $files[0]['name']] + array_diff_key($bil, ['lines' => 1]));
        $_SESSION['_svreport'] = $bil + ['dry' => $dry, 'file' => $files[0]['name']]; $this->go('surveys/import');
    }
    function batch(string $id): void {
        $b = DB::one('SELECT b.*, u.name user_name FROM sv_batches b LEFT JOIN users u ON u.id=b.user_id WHERE b.id=?', [(int)$id]); if (!$b) { $this->notFound(); return; }
        $this->view('survey/batch', ['title' => 'Lot d\'import', 'b' => $b]);
    }
}
