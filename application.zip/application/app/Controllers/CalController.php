<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Cal};

/** Module « Calibrage » : sessions de calibrage des évaluateurs qualité, cotation indépendante, arbitrage, mesures d'alignement, rapport. */
class CalController extends Controller {
    private function sess(string $id): ?array { return DB::one('SELECT s.*, g.name grid_name FROM cal_sessions s LEFT JOIN qa_grids g ON g.id=s.grid_id WHERE s.id=?', [(int)$id]) ?: null; }
    private function isArb(array $s): bool { return can('cal.manage') || (int)$s['arbiter_user_id'] === (int)Auth::id(); }
    function index(): void {
        $this->view('cal/index', ['title' => 'Calibrage des évaluations qualité', 'rows' => DB::all('SELECT s.*, g.name grid_name, (SELECT COUNT(*) FROM cal_cases c WHERE c.session_id=s.id) nc, (SELECT COUNT(DISTINCT user_id) FROM cal_parts p WHERE p.session_id=s.id) np FROM cal_sessions s LEFT JOIN qa_grids g ON g.id=s.grid_id ORDER BY s.held_on DESC, s.id DESC'),
            'mine' => DB::all("SELECT s.id, s.ref, s.title FROM cal_sessions s JOIN cal_parts p ON p.session_id=s.id AND p.user_id=? WHERE s.status='scoring'", [(int)Auth::id()])]);
    }
    function create(): void { $this->view('cal/form', ['title' => 'Nouvelle session de calibrage', 's' => ['ref' => Cal::nextRef(), 'held_on' => date('Y-m-d')], 'grids' => DB::all('SELECT id, name FROM qa_grids WHERE active=1 ORDER BY name'), 'users' => $this->users()]); }
    private function users(): array { return DB::all("SELECT id, name FROM users WHERE status='active' ORDER BY name"); }
    function store(): void {
        [$d, $err] = $this->validate(['title' => ['label' => 'L\'intitulé', 'req' => true, 'max' => 190], 'held_on' => ['label' => 'La date', 'req' => true, 'date' => true], 'scope' => ['label' => 'Le périmètre', 'max' => 300], 'objective' => ['label' => 'L\'objectif', 'max' => 300], 'grid_version' => ['label' => 'La version de la grille', 'max' => 30]], $_POST);
        $g = (int)($_POST['grid_id'] ?? 0); if (!DB::val('SELECT 1 FROM qa_grids WHERE id=?', [$g])) $err['grid_id'] = 'Choisissez la grille.';
        $arb = (int)($_POST['arbiter_user_id'] ?? 0); if (!$arb || !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$arb])) $err['arbiter_user_id'] = 'Désignez l\'arbitre.';
        if ($err) { $_SESSION['_old'] = $_POST; $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('cal/new'); }
        $id = DB::insert('cal_sessions', $d + ['ref' => Cal::nextRef(), 'grid_id' => $g, 'arbiter_user_id' => $arb, 'status' => 'draft', 'created_by' => Auth::id(), 'created_at' => now()]);
        DB::insert('cal_parts', ['session_id' => $id, 'user_id' => $arb, 'role' => 'arbiter', 'present' => 1]); Audit::log('create', 'cal_session', $id); flash('Session créée : ajoutez les cas et les évaluateurs.'); redirect("cal/$id");
    }
    function show(string $id): void {
        $s = $this->sess($id); if (!$s) { $this->notFound(); return; } $me = (int)Auth::id();
        $parts = DB::all('SELECT p.*, u.name FROM cal_parts p JOIN users u ON u.id=p.user_id WHERE p.session_id=? ORDER BY p.role, u.name', [(int)$id]);
        $cases = DB::all('SELECT c.*, (SELECT COUNT(*) FROM cal_ratings r WHERE r.case_id=c.id AND r.user_id>0) nr, (SELECT COUNT(*) FROM cal_ratings r WHERE r.case_id=c.id AND r.user_id=0) has_ref, (SELECT COUNT(*) FROM cal_ratings r WHERE r.case_id=c.id AND r.user_id=?) mine FROM cal_cases c WHERE c.session_id=? ORDER BY c.sort, c.id', [$me, (int)$id]);
        $this->view('cal/show', ['title' => $s['ref'] . ' · ' . $s['title'], 's' => $s, 'parts' => $parts, 'cases' => $cases, 'users' => $this->users(), 'arb' => $this->isArb($s), 'isPart' => (bool)array_filter($parts, fn($p) => (int)$p['user_id'] === $me), 'nrate' => count(Cal::criteria((int)$id)),
            'decisions' => DB::all('SELECT * FROM cal_decisions WHERE session_id=? ORDER BY id', [(int)$id]), 'plans' => DB::all('SELECT * FROM cal_plans WHERE session_id=? ORDER BY due_on', [(int)$id])]);
    }
    function update(string $id): void {
        $s = $this->sess($id); if (!$s) { $this->notFound(); return; }
        [$d, $err] = $this->validate(['title' => ['label' => 'L\'intitulé', 'req' => true, 'max' => 190], 'held_on' => ['label' => 'La date', 'req' => true, 'date' => true], 'scope' => ['max' => 300], 'objective' => ['max' => 300], 'grid_version' => ['max' => 30], 'validity_note' => ['max' => 500], 'diffusion' => ['max' => 500], 'next_note' => ['max' => 500], 'next_session' => ['date' => true]], $_POST);
        $v = (string)($_POST['validity'] ?? ''); $d['validity'] = isset(Cal::VAL[$v]) ? $v : null; $arb = (int)($_POST['arbiter_user_id'] ?? 0); if ($arb && DB::val('SELECT 1 FROM users WHERE id=?', [$arb])) $d['arbiter_user_id'] = $arb;
        if ($err) { flash(implode(' ', $err), 'danger'); redirect("cal/$id"); } DB::update('cal_sessions', $d, 'id=?', [(int)$id]); Audit::log('update', 'cal_session', $id); flash('Session enregistrée.'); redirect("cal/$id");
    }
    function status(string $id): void {
        $s = $this->sess($id); if (!$s) { $this->notFound(); return; } $to = (string)$this->in('to'); $flow = ['draft' => 'scoring', 'scoring' => 'arbitration', 'arbitration' => 'closed'];
        if (($flow[$s['status']] ?? null) !== $to && !($to === 'scoring' && $s['status'] === 'arbitration')) { flash('Changement d\'étape impossible.', 'danger'); redirect("cal/$id"); }
        if ($to === 'scoring' && $s['status'] === 'draft') { if (!DB::val('SELECT 1 FROM cal_cases WHERE session_id=?', [(int)$id]) || (int)DB::val("SELECT COUNT(*) FROM cal_parts WHERE session_id=? AND role='evaluator'", [(int)$id]) < 1) { flash('Ajoutez au moins un cas et un évaluateur avant de lancer la cotation.', 'danger'); redirect("cal/$id"); } }
        if ($to === 'closed' && (int)DB::val('SELECT COUNT(*) FROM cal_cases c WHERE c.session_id=? AND NOT EXISTS (SELECT 1 FROM cal_ratings r WHERE r.case_id=c.id AND r.user_id=0)', [(int)$id])) { flash('Chaque cas doit avoir une cotation de référence (arbitrage) avant la clôture.', 'danger'); redirect("cal/$id"); }
        DB::update('cal_sessions', ['status' => $to], 'id=?', [(int)$id]);
        if ($to === 'scoring') foreach (DB::all("SELECT user_id FROM cal_parts WHERE session_id=? AND role='evaluator'", [(int)$id]) as $p) Notifier::send((int)$p['user_id'], 'Calibrage : cotation à réaliser', $s['title'], '/cal/' . $id);
        Audit::log('status', 'cal_session', $id, null, ['to' => $to]); flash('Étape : ' . Cal::ST[$to] . '.'); redirect("cal/$id");
    }
    function addCase(string $id): void {
        $s = $this->sess($id); if (!$s) { $this->notFound(); return; } if ($s['status'] !== 'draft') { flash('Les cas ne se modifient qu\'en préparation.', 'warning'); redirect("cal/$id"); }
        $ref = trim((string)$this->in('ref')); $ty = (string)$this->in('case_type', 'call'); if ($ref === '' || !isset(Cal::TYPE[$ty])) { flash('Référence et type obligatoires.', 'danger'); redirect("cal/$id"); }
        if (DB::val('SELECT 1 FROM cal_cases WHERE session_id=? AND ref=?', [(int)$id, $ref])) { flash('Cette référence existe déjà dans la session.', 'danger'); redirect("cal/$id"); }
        $fd = (string)$this->in('fact_date'); DB::insert('cal_cases', ['session_id' => (int)$id, 'ref' => mb_substr($ref, 0, 30), 'case_type' => $ty, 'channel' => mb_substr(trim((string)$this->in('channel')), 0, 60) ?: null, 'fact_date' => preg_match('/^\d{4}-\d{2}-\d{2}$/', $fd) ? $fd : null,
            'description' => mb_substr(trim((string)$this->in('description')), 0, 500) ?: null, 'sort' => (int)DB::val('SELECT COUNT(*) FROM cal_cases WHERE session_id=?', [(int)$id])]); flash('Cas ajouté (aucune donnée client ni personnelle dans la description).'); redirect("cal/$id");
    }
    function delCase(string $id, string $cid): void {
        $s = $this->sess($id); if (!$s || $s['status'] !== 'draft') { flash('Suppression possible uniquement en préparation.', 'warning'); redirect("cal/$id"); }
        DB::exec('DELETE FROM cal_cases WHERE id=? AND session_id=?', [(int)$cid, (int)$id]); redirect("cal/$id");
    }
    function addPart(string $id): void {
        $s = $this->sess($id); if (!$s) { $this->notFound(); return; } $u = (int)$this->in('user_id'); $r = (string)$this->in('role', 'evaluator'); if (!in_array($r, ['evaluator', 'observer'], true) || !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$u])) { flash('Participant invalide.', 'danger'); redirect("cal/$id"); }
        if (DB::val('SELECT 1 FROM cal_parts WHERE session_id=? AND user_id=?', [(int)$id, $u])) { flash('Déjà participant.', 'warning'); redirect("cal/$id"); } DB::insert('cal_parts', ['session_id' => (int)$id, 'user_id' => $u, 'role' => $r, 'present' => 1]); flash('Participant ajouté.'); redirect("cal/$id");
    }
    function delPart(string $id, string $pid): void { DB::exec("DELETE FROM cal_parts WHERE id=? AND session_id=? AND role<>'arbiter'", [(int)$pid, (int)$id]); redirect("cal/$id"); }
    function present(string $id, string $pid): void { DB::exec('UPDATE cal_parts SET present=1-present WHERE id=? AND session_id=?', [(int)$pid, (int)$id]); redirect("cal/$id"); }

    function score(string $id, string $cid): void {
        $s = $this->sess($id); $c = DB::one('SELECT * FROM cal_cases WHERE id=? AND session_id=?', [(int)$cid, (int)$id]); if (!$s || !$c) { $this->notFound(); return; }
        $ref = (bool)$this->in('ref') && $this->isArb($s); $uid = $ref ? 0 : (int)Auth::id();
        $isPart = (bool)DB::val("SELECT 1 FROM cal_parts p WHERE p.session_id=? AND p.user_id=? AND p.role IN ('evaluator','arbiter')", [(int)$id, (int)Auth::id()]);
        if (!$ref && !$isPart) { $this->forbidden(); return; }
        $open = $ref ? in_array($s['status'], ['scoring', 'arbitration'], true) : $s['status'] === 'scoring';
        $r = DB::one('SELECT * FROM cal_ratings WHERE case_id=? AND user_id=?', [(int)$cid, $uid]);
        $this->view('cal/score', ['title' => ($ref ? 'Référence : ' : 'Cotation : ') . $s['ref'] . ' · ' . $c['ref'], 's' => $s, 'c' => $c, 'crit' => Cal::criteria((int)$id), 'r' => $r, 'sc' => $r ? Cal::ratingScores((int)$r['id']) : [], 'ref' => $ref, 'open' => $open,
            'others' => $ref ? DB::all('SELECT r.*, u.name FROM cal_ratings r JOIN users u ON u.id=r.user_id WHERE r.case_id=? AND r.user_id>0', [(int)$cid]) : []]);
    }
    function saveScore(string $id, string $cid): void {
        $s = $this->sess($id); $c = DB::one('SELECT * FROM cal_cases WHERE id=? AND session_id=?', [(int)$cid, (int)$id]); if (!$s || !$c) { $this->notFound(); return; }
        $ref = !empty($_POST['ref']) && $this->isArb($s); $uid = $ref ? 0 : (int)Auth::id();
        if (!$ref && (!DB::val("SELECT 1 FROM cal_parts p WHERE p.session_id=? AND p.user_id=? AND p.role IN ('evaluator','arbiter')", [(int)$id, (int)Auth::id()]) || $s['status'] !== 'scoring')) { $this->forbidden(); return; }
        if ($ref && !in_array($s['status'], ['scoring', 'arbitration'], true)) { flash('La référence se saisit pendant la cotation ou l\'arbitrage.', 'warning'); redirect("cal/$id"); }
        Cal::saveRating((int)$cid, $uid, $_POST, Cal::criteria((int)$id)); Audit::log($ref ? 'reference' : 'score', 'cal_case', $cid); flash($ref ? 'Référence arbitrée enregistrée.' : 'Cotation enregistrée.'); redirect("cal/$id");
    }
    function addDecision(string $id): void {
        if (!$this->sess($id)) { $this->notFound(); return; } $r = trim((string)$this->in('rule')); if ($r === '') { flash('La règle clarifiée est obligatoire.', 'danger'); redirect("cal/$id"); } $ed = (string)$this->in('effect_date');
        DB::insert('cal_decisions', ['session_id' => (int)$id, 'rule' => mb_substr($r, 0, 300), 'case_ref' => mb_substr(trim((string)$this->in('case_ref')), 0, 60) ?: null, 'grid_effect' => mb_substr(trim((string)$this->in('grid_effect')), 0, 300) ?: null, 'validator' => mb_substr(trim((string)$this->in('validator')), 0, 100) ?: null, 'effect_date' => preg_match('/^\d{4}-\d{2}-\d{2}$/', $ed) ? $ed : null, 'created_at' => now()]); flash('Décision ajoutée.'); redirect("cal/$id");
    }
    function delDecision(string $id, string $did): void { DB::exec('DELETE FROM cal_decisions WHERE id=? AND session_id=?', [(int)$did, (int)$id]); redirect("cal/$id"); }
    function addPlan(string $id): void {
        if (!$this->sess($id)) { $this->notFound(); return; } $a = trim((string)$this->in('action')); if ($a === '') { flash('L\'action est obligatoire.', 'danger'); redirect("cal/$id"); } $du = (string)$this->in('due_on');
        DB::insert('cal_plans', ['session_id' => (int)$id, 'who' => mb_substr(trim((string)$this->in('who')), 0, 150) ?: null, 'gap' => mb_substr(trim((string)$this->in('gap')), 0, 200) ?: null, 'action' => mb_substr($a, 0, 300), 'owner' => mb_substr(trim((string)$this->in('owner')), 0, 100) ?: null, 'due_on' => preg_match('/^\d{4}-\d{2}-\d{2}$/', $du) ? $du : null, 'verification' => mb_substr(trim((string)$this->in('verification')), 0, 200) ?: null, 'status' => 'todo']); flash('Action ajoutée.'); redirect("cal/$id");
    }
    function planStatus(string $id, string $pid): void { $st = (string)$this->in('status'); if (isset(Cal::PST[$st])) DB::update('cal_plans', ['status' => $st], 'id=? AND session_id=?', [(int)$pid, (int)$id]); redirect("cal/$id"); }
    function report(string $id): void {
        $s = $this->sess($id); if (!$s) { $this->notFound(); return; }
        $this->view('cal/report', ['title' => 'Rapport de calibrage ' . $s['ref'], 's' => $s, 'm' => Cal::metrics((int)$id), 'parts' => DB::all('SELECT p.*, u.name FROM cal_parts p JOIN users u ON u.id=p.user_id WHERE p.session_id=? ORDER BY p.role, u.name', [(int)$id]),
            'cases' => DB::all('SELECT c.*, (SELECT COUNT(*) FROM cal_ratings r WHERE r.case_id=c.id AND r.user_id>0) nr FROM cal_cases c WHERE c.session_id=? ORDER BY c.sort, c.id', [(int)$id]), 'decisions' => DB::all('SELECT * FROM cal_decisions WHERE session_id=? ORDER BY id', [(int)$id]), 'plans' => DB::all('SELECT * FROM cal_plans WHERE session_id=? ORDER BY due_on', [(int)$id]),
            'crit' => DB::all('SELECT r.user_id, c.ref, r.severity FROM cal_ratings r JOIN cal_cases c ON c.id=r.case_id WHERE c.session_id=? ORDER BY c.sort, r.user_id', [(int)$id]), 'edit' => can('qa.manage')], 'layout/public');
    }
}
