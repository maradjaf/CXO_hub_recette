<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Tickets, Svc};
/** Lot 38 : tickets enfants, liens entre tickets, satisfaction (CSAT) et modèles de réponse. */
class ATServiceController extends Controller {
    private function ticket(string $id): ?array { $t = DB::one('SELECT * FROM at_tickets WHERE id=?', [(int)$id]); if (!$t) $this->notFound(); return $t ?: null; }

    /** Création d'un ticket enfant (sous-tâche) à partir d'un ticket parent ouvert. Un seul niveau d'imbrication. */
    function child(string $id): void {
        if (!($p = $this->ticket($id))) return;
        if (!in_array($p['status'], Tickets::OPEN, true) || $p['status'] === 'approval') { flash('Le ticket parent doit être ouvert au traitement.', 'warning'); redirect("at/$id"); }
        if ($p['parent_id']) { flash('Un ticket enfant ne peut pas avoir lui-même d\'enfant.', 'warning'); redirect("at/$id"); }
        $title = mb_substr(trim((string)$this->in('title', '')), 0, 190); if (mb_strlen($title) < 3) { flash('Donnez un titre au ticket enfant (3 caractères minimum).', 'danger'); redirect("at/$id"); }
        $a = (int)$this->in('assignee_id') ?: null; if ($a && !in_array($a, array_map('intval', array_column(Tickets::handlers(), 'id')), true)) $a = null;
        $gid = (int)$this->in('group_id') ?: null; if ($gid && !DB::val('SELECT 1 FROM at_groups WHERE id=? AND active=1', [$gid])) $gid = null;
        $cid = Tickets::create(['title' => $title, 'description' => mb_substr(trim((string)$this->in('description', '')), 0, 3000) ?: ('Sous-tâche de ' . $p['reference'] . ' — ' . $p['title']), 'kind' => $p['kind'], 'category' => $p['category'], 'priority' => $p['priority'],
            'requester_id' => $p['requester_id'], 'store_id' => $p['store_id'], 'team_id' => $p['team_id'], 'asset_id' => $p['asset_id'], 'assignee_id' => $a, 'channel' => 'system', 'logged_by' => Auth::id()] + ($gid ? ['group_id' => $gid] : []));
        DB::update('at_tickets', ['parent_id' => (int)$id], 'id=?', [$cid]); $ref = (string)DB::val('SELECT reference FROM at_tickets WHERE id=?', [$cid]);
        Tickets::event($cid, 'child', 'Ticket enfant de ' . $p['reference'] . '.', Auth::id()); Tickets::event((int)$id, 'child', 'Ticket enfant créé : ' . $ref . ' — ' . $title . '.', Auth::id());
        if ($a && $a !== Auth::id()) Notifier::send($a, 'Ticket affecté : ' . $ref, $title, '/at/' . $cid);
        Audit::log('create_child', 'at_ticket', $id, null, ['child' => $cid]); flash("Ticket enfant $ref créé."); redirect("at/$cid");
    }
    function link(string $id): void {
        if (!($t = $this->ticket($id))) return; $kind = (string)$this->in('kind');
        if (!isset(Svc::LINK[$kind])) { flash('Type de lien invalide.', 'danger'); redirect("at/$id"); }
        $o = DB::one('SELECT * FROM at_tickets WHERE UPPER(reference)=UPPER(?)', [trim((string)$this->in('reference', ''))]);
        if (!$o || (int)$o['id'] === (int)$id) { flash('Référence de ticket introuvable.', 'danger'); redirect("at/$id"); }
        if (DB::val('SELECT 1 FROM at_links WHERE (ticket_id=? AND other_id=?) OR (ticket_id=? AND other_id=?)', [(int)$id, (int)$o['id'], (int)$o['id'], (int)$id])) { flash('Ces tickets sont déjà liés.', 'warning'); redirect("at/$id"); }
        DB::insert('at_links', ['ticket_id' => (int)$id, 'other_id' => (int)$o['id'], 'kind' => $kind, 'created_by' => Auth::id(), 'created_at' => now()]);
        Tickets::event((int)$id, 'link', Svc::LINK[$kind] . ' ' . $o['reference'] . '.', Auth::id()); Tickets::event((int)$o['id'], 'link', $t['reference'] . ' : ' . ['related' => 'lié à ce ticket', 'duplicate' => 'déclaré doublon de ce ticket', 'caused_by' => 'a ce ticket pour cause'][$kind] . '.', Auth::id());
        if ($kind === 'duplicate' && in_array($o['status'], ['resolved', 'closed'], true)) Svc::afterStatus($o, $o['status'], Auth::id());
        Audit::log('link', 'at_ticket', $id, null, ['other' => $o['id'], 'kind' => $kind]); flash('Lien ajouté.'); redirect("at/$id");
    }
    function unlink(string $id, string $lid): void {
        $l = DB::one('SELECT * FROM at_links WHERE id=? AND (ticket_id=? OR other_id=?)', [(int)$lid, (int)$id, (int)$id]); if (!$l) { $this->notFound(); return; }
        DB::exec('DELETE FROM at_links WHERE id=?', [(int)$lid]); Tickets::event((int)$id, 'link', 'Lien supprimé.', Auth::id()); Audit::log('unlink', 'at_ticket', $id, $l, null); flash('Lien supprimé.'); redirect("at/$id");
    }
    /** Enquête de satisfaction : le demandeur note la résolution (une seule fois). */
    function csat(string $id): void {
        if (!($t = $this->ticket($id))) return;
        if ((int)$t['requester_id'] !== Auth::id()) { $this->forbidden(); return; }
        if (!in_array($t['status'], ['resolved', 'closed'], true) || $t['csat_score'] !== null) { flash('Ce ticket ne peut pas être noté (non résolu ou déjà noté).', 'warning'); redirect("at/$id"); }
        $s = (int)$this->in('score'); if (!isset(Svc::CSAT[$s])) { flash('Choisissez une note de 1 à 5.', 'danger'); redirect("at/$id"); }
        $c = mb_substr(trim((string)$this->in('comment', '')), 0, 1000);
        DB::update('at_tickets', ['csat_score' => $s, 'csat_comment' => $c ?: null, 'csat_at' => now()], 'id=?', [(int)$id]);
        Tickets::event((int)$id, 'csat', 'Satisfaction : ' . $s . '/5 — ' . Svc::CSAT[$s] . ($c !== '' ? ' — ' . $c : ''), Auth::id());
        if ($s <= 2) { $m = $t['reference'] . ' · ' . $t['title'] . ' — ' . $s . '/5'; Notifier::toPermission('at.manage', 'Insatisfaction : ' . $t['reference'], $m, '/at/' . $id); if ($t['assignee_id']) Notifier::send((int)$t['assignee_id'], 'Insatisfaction : ' . $t['reference'], $m, '/at/' . $id); }
        Audit::log('csat', 'at_ticket', $id, null, ['score' => $s]); flash('Merci pour votre avis.'); redirect("at/$id");
    }
    // ---- Modèles de réponse
    function templates(): void {
        $this->view('at/templates', ['title' => 'Modèles de réponse', 'rows' => DB::all('SELECT * FROM at_templates ORDER BY active DESC, kind, title'),
            'cats' => DB::all("SELECT v.code, v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='at_categories' AND v.active=1 ORDER BY v.sort_order")]);
    }
    private function tplData(): ?array {
        $title = mb_substr(trim((string)$this->in('title', '')), 0, 150); $body = trim((string)$this->in('body', '')); $kind = $this->in('kind') === 'solution' ? 'solution' : 'reply';
        if ($title === '' || mb_strlen($body) < 5 || mb_strlen($body) > 1500) return null;
        return ['title' => $title, 'kind' => $kind, 'category' => preg_replace('/[^A-Za-z0-9_-]/', '', (string)$this->in('category', '')) ?: null, 'body' => $body, 'active' => $this->in('active') ? 1 : 0];
    }
    function storeTemplate(): void {
        $d = $this->tplData(); if (!$d) { flash('Titre et texte (5 à 1500 caractères) obligatoires.', 'danger'); redirect('at/templates'); }
        $d['active'] = 1; $id = DB::insert('at_templates', $d + ['created_by' => Auth::id(), 'created_at' => now()]); Audit::log('create', 'at_template', $id, null, $d); flash('Modèle créé.'); redirect('at/templates');
    }
    function updateTemplate(string $id): void {
        $o = DB::one('SELECT * FROM at_templates WHERE id=?', [(int)$id]); if (!$o) { $this->notFound(); return; }
        $d = $this->tplData(); if (!$d) { flash('Titre et texte (5 à 1500 caractères) obligatoires.', 'danger'); redirect('at/templates'); }
        DB::update('at_templates', $d, 'id=?', [(int)$id]); Audit::log('update', 'at_template', $id, $o, $d); flash('Modèle enregistré.'); redirect('at/templates');
    }
}
