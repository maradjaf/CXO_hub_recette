<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Brand, Settings};

/** Fiche complète des sociétés employeuses (identité légale, responsables, logo, en-tête et pied de page des documents) et mise en page par défaut. */
class EmployersController extends Controller {
    const FIELDS = ['slogan' => ['Le slogan', 190], 'sector' => ['Le secteur d\'activité', 150], 'legal_form' => ['La forme juridique', 80], 'capital' => ['Le capital', 60], 'rccm' => ['Le numéro RCCM', 60], 'nif' => ['Le numéro NIF', 60], 'cnss' => ['Le numéro CNSS', 60],
        'address' => ['L\'adresse du siège social', 300], 'phone' => ['Le contact téléphonique', 60], 'head_title' => ['Le poste du premier responsable', 100], 'head_name' => ['Le nom et prénoms du premier responsable', 150],
        'hr_title' => ['Le poste du responsable RH', 100], 'hr_name' => ['Le nom et prénoms du responsable RH', 150], 'doc_header' => ['Le texte d\'en-tête', 600], 'doc_footer' => ['Le texte de pied de page', 600]];
    function index(): void {
        $rows = DB::all("SELECT e.*, (SELECT COUNT(*) FROM employees x WHERE x.employer=e.code AND x.status<>'left') staff FROM employers e ORDER BY CASE WHEN e.kind='own' THEN 0 ELSE 1 END, e.name");
        $this->view('employers/index', ['title' => 'Sociétés employeuses', 'rows' => $rows]);
    }
    function edit(string $id): void {
        $e = DB::one('SELECT * FROM employers WHERE id=?', [(int)$id]); if (!$e) { $this->notFound(); return; }
        $this->view('employers/form', ['title' => 'Fiche : ' . $e['name'], 'e' => $e]);
    }
    private function img(string $slot, array $e, array &$upd, array &$err): void {
        [$st, $er] = Brand::store($_FILES[$slot] ?? null, $slot === 'logo' ? 600 : 1400); if ($er) { $err[$slot] = $er; return; }
        if ($st) { $upd[$slot] = $st; return; }
        if ($this->in('drop_' . $slot) === '1') $upd[$slot] = null;
    }
    function save(string $id): void {
        $e = DB::one('SELECT * FROM employers WHERE id=?', [(int)$id]); if (!$e) { $this->notFound(); return; }
        $rules = []; foreach (self::FIELDS as $k => [$l, $m]) $rules[$k] = ['label' => $l, 'max' => $m];
        foreach (['email' => 'L\'e-mail de la société', 'head_email' => 'L\'e-mail du premier responsable', 'hr_email' => 'L\'e-mail du responsable RH'] as $k => $l) $rules[$k] = ['label' => $l, 'email' => true, 'max' => 190];
        [$d, $err] = $this->validate($rules, $_POST); $upd = [];
        foreach (['logo', 'header_img', 'footer_img'] as $slot) $this->img($slot, $e, $upd, $err);
        if ($err) $this->back($err, $_POST, "admin/employers/$id");
        $d = array_map(fn($v) => $v === null ? null : $v, $d); DB::update('employers', $d + $upd, 'id=?', [(int)$id]);
        foreach ($upd as $slot => $new) if ($e[$slot] && $e[$slot] !== $new) Brand::drop($e[$slot]);
        Audit::log('update', 'employer', $id, ['name' => $e['name']], array_keys($d + $upd)); flash('Fiche de la société enregistrée.'); redirect("admin/employers/$id");
    }
    /** Mise en page par défaut des documents (société sans en-tête propre). */
    function layout(): void {
        $this->view('employers/layout', ['title' => 'Mise en page des documents', 'v' => ['logo' => setting('ct.logo', ''), 'header_img' => setting('ct.header_img', ''), 'footer_img' => setting('ct.footer_img', ''), 'header_text' => setting('ct.header_text', ''), 'footer_text' => setting('ct.footer_text', '')]]);
    }
    function layoutSave(): void {
        $err = []; $new = [];
        foreach (['logo', 'header_img', 'footer_img'] as $slot) {
            [$st, $er] = Brand::store($_FILES[$slot] ?? null, $slot === 'logo' ? 600 : 1400); if ($er) { $err[$slot] = $er; continue; }
            if ($st) $new["ct.$slot"] = $st; elseif ($this->in('drop_' . $slot) === '1') $new["ct.$slot"] = '';
        }
        $ht = mb_substr(trim((string)$this->in('header_text', '')), 0, 600); $ft = mb_substr(trim((string)$this->in('footer_text', '')), 0, 600);
        if ($err) $this->back($err, $_POST, 'contracts/layout');
        foreach ($new as $k => $v) { $old = (string)setting($k, ''); Settings::set($k, $v); if ($old !== '' && $old !== $v) Brand::drop($old); }
        Settings::set('ct.header_text', $ht); Settings::set('ct.footer_text', $ft);
        Audit::log('update', 'ct_layout', null, null, array_keys($new)); flash('Mise en page enregistrée.'); redirect('contracts/layout');
    }
    /** Aperçu PDF de la mise en page (société ou défaut). */
    function preview(): void {
        $code = (string)$this->in('employer', ''); $pd = new \App\Core\PdfDoc(595, 842, 54, 'Aperçu', ''); $pd->brand(\App\Core\Ct::brandPaths($code !== '' ? $code : null));
        $pd->title('Aperçu de la mise en page', 14); $pd->para('Ce texte illustre le contenu d\'un contrat. Le logo, l\'en-tête et le pied de page sont ceux qui seront imprimés sur chaque page des contrats et attestations.', 10);
        header('Content-Type: application/pdf'); header('Content-Disposition: inline; filename="apercu.pdf"'); header('X-Content-Type-Options: nosniff'); echo $pd->output(); exit;
    }
    /** Image d'identité visuelle (logo, en-tête, pied de page) : non confidentielle, servie aussi sur les pages de signature. */
    function file(string $f): void {
        \App\Core\Activity::skipRequest(); $p = preg_match('/^[a-f0-9]{32}$/', $f) ? Brand::path($f . '.jpg') : null; if (!$p) { http_response_code(404); echo 'Introuvable'; return; }
        header('Content-Type: image/jpeg'); header('X-Content-Type-Options: nosniff'); header('Cache-Control: public, max-age=3600'); readfile($p); exit;
    }
}
