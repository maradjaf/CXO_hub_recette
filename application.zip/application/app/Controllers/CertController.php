<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Cert, Scope};

/** Modèles de certificats et d'attestations : plusieurs modèles, informations affichées configurables, aperçu PDF. */
class CertController extends Controller {
    private const FLAGS = ['show_logo', 'show_score', 'show_date', 'show_duration', 'show_trainer', 'show_number', 'show_border', 'show_qr'];
    function index(): void {
        $rows = DB::all('SELECT t.*, (SELECT COUNT(*) FROM el_courses c WHERE c.cert_template_id=t.id) nc, (SELECT COUNT(*) FROM el_paths p WHERE p.cert_template_id=t.id) np, (SELECT COUNT(*) FROM trainings x WHERE x.cert_template_id=t.id) nt FROM cert_templates t ORDER BY t.kind, t.name');
        $this->view('cert/index', ['title' => 'Certificats et attestations', 'rows' => $rows]);
    }
    function create(): void { $this->view('cert/form', ['title' => 'Nouveau modèle', 't' => Cert::builtin('any') + ['name' => '', 'active' => 1, 'is_default' => 0]]); }
    function edit(string $id): void { $t = DB::one('SELECT * FROM cert_templates WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return; } $this->view('cert/form', ['title' => 'Modèle : ' . $t['name'], 't' => $t]); }
    function save(?string $id = null): void {
        $old = $id ? DB::one('SELECT * FROM cert_templates WHERE id=?', [(int)$id]) : null; if ($id && !$old) { $this->notFound(); return; }
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom du modèle', 'req' => true, 'max' => 150], 'title' => ['label' => 'Le titre', 'req' => true, 'max' => 150], 'intro' => ['label' => 'La phrase d\'introduction', 'max' => 200], 'body' => ['label' => 'Le texte principal', 'req' => true, 'max' => 600], 'footer' => ['label' => 'Le pied de page', 'max' => 300],
            'org_name' => ['label' => 'L\'organisation', 'max' => 120], 'signer1_name' => ['label' => 'Le signataire 1', 'max' => 100], 'signer1_title' => ['label' => 'La fonction 1', 'max' => 100], 'signer2_name' => ['label' => 'Le signataire 2', 'max' => 100], 'signer2_title' => ['label' => 'La fonction 2', 'max' => 100], 'competence' => ['label' => 'La compétence', 'max' => 300], 'body2' => ['label' => 'La seconde phrase', 'max' => 300], 'levels' => ['label' => 'Les niveaux', 'max' => 300]], $_POST);
        $k = (string)($_POST['kind'] ?? 'any'); if (!isset(Cert::KINDS[$k])) $err['kind'] = 'Type inconnu.'; $d['kind'] = $k;
        foreach (['color', 'accent'] as $c) { $v = trim((string)($_POST[$c] ?? '')); if (!preg_match('/^#[0-9A-Fa-f]{6}$/', $v)) $err[$c] = 'Couleur invalide (ex. #003A84).'; $d[$c] = $v; }
        $d['layout'] = ($_POST['layout'] ?? '') === 'yas' ? 'yas' : 'classic'; $d['orientation'] = $d['layout'] === 'yas' ? 'landscape' : (($_POST['orientation'] ?? '') === 'portrait' ? 'portrait' : 'landscape'); foreach (self::FLAGS as $f) $d[$f] = !empty($_POST[$f]) ? 1 : 0; $d['active'] = $old ? (!empty($_POST['active']) ? 1 : 0) : 1; $d['is_default'] = !empty($_POST['is_default']) ? 1 : 0; $d['updated_at'] = now();
        if ($err) { $_SESSION['_old'] = $_POST; $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect($id ? "certificates/$id" : 'certificates/new'); }
        if ($old) { DB::update('cert_templates', $d, 'id=?', [(int)$id]); Audit::log('update', 'cert_template', $id, $old, $d); $nid = (int)$id; } else { $d['created_at'] = now(); $nid = DB::insert('cert_templates', $d); Audit::log('create', 'cert_template', $nid, null, $d); }
        if ($d['is_default'] && $d['kind'] !== 'any') DB::exec('UPDATE cert_templates SET is_default=0 WHERE kind=? AND id<>?', [$d['kind'], $nid]);
        flash('Modèle enregistré.'); redirect("certificates/$nid");
    }
    function preview(string $id): void { $t = DB::one('SELECT * FROM cert_templates WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return; } Cert::send(Cert::sample($t), 'apercu-' . $t['id']); }
    function duplicate(string $id): void {
        $t = DB::one('SELECT * FROM cert_templates WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return; } unset($t['id']); $t['name'] = mb_substr($t['name'], 0, 138) . ' (copie)'; $t['is_default'] = 0; $t['created_at'] = $t['updated_at'] = now();
        $n = DB::insert('cert_templates', $t); Audit::log('duplicate', 'cert_template', $n); flash('Modèle dupliqué.'); redirect("certificates/$n");
    }
    function delete(string $id): void {
        $t = DB::one('SELECT * FROM cert_templates WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return; }
        if ((int)DB::val('SELECT (SELECT COUNT(*) FROM el_courses WHERE cert_template_id=?) + (SELECT COUNT(*) FROM el_paths WHERE cert_template_id=?) + (SELECT COUNT(*) FROM trainings WHERE cert_template_id=?)', [(int)$id, (int)$id, (int)$id])) { flash('Ce modèle est utilisé : désactivez-le plutôt.', 'danger'); redirect('certificates'); }
        DB::exec('DELETE FROM cert_templates WHERE id=?', [(int)$id]); Audit::log('delete', 'cert_template', $id, $t); flash('Modèle supprimé.'); redirect('certificates');
    }

    // ---- Registre des documents émis, révocation, attestations RH ----
    function register(): void {
        $w = ['1=1']; $p = [];
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(i.code LIKE ? OR i.holder_name LIKE ? OR i.item LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $st = (string)$this->in('status', ''); if ($st === 'valid') $w[] = 'i.revoked=0'; elseif ($st === 'revoked') $w[] = 'i.revoked=1';
        $pg = paginate('cert_issued i LEFT JOIN users u ON u.id=i.issued_by WHERE ' . implode(' AND ', $w), $p, $this->page(), 25, 'i.*, u.name by_name', 'i.id DESC');
        $this->view('cert/register', ['title' => 'Registre des documents émis', 'p' => $pg, 'q' => $q, 'status' => $st]);
    }
    function revoke(string $id): void {
        $r = DB::one('SELECT * FROM cert_issued WHERE id=?', [(int)$id]); if (!$r) { $this->notFound(); return; }
        if ($r['revoked']) { DB::update('cert_issued', ['revoked' => 0, 'revoked_at' => null, 'revoked_reason' => null], 'id=?', [(int)$id]); Audit::log('restore', 'cert_issued', $id, $r); flash('Document de nouveau valide.'); redirect('certificates/register'); }
        $why = trim((string)$this->in('reason', '')); if (mb_strlen($why) < 3) { flash('Indiquez le motif de l\'annulation.', 'danger'); redirect('certificates/register'); }
        DB::update('cert_issued', ['revoked' => 1, 'revoked_at' => now(), 'revoked_reason' => mb_substr($why, 0, 300)], 'id=?', [(int)$id]); Audit::log('revoke', 'cert_issued', $id, $r, ['reason' => $why]);
        flash('Document annulé : la vérification affichera « annulé ».'); redirect('certificates/register');
    }
    function issueForm(): void {
        $this->view('cert/issue', ['title' => 'Délivrer une attestation RH', 'templates' => DB::all("SELECT id, name, is_default FROM cert_templates WHERE active=1 AND kind IN ('hr','any') ORDER BY is_default DESC, name"),
            'employees' => DB::all("SELECT id, first_name, last_name, matricule FROM employees WHERE status<>'left' ORDER BY last_name, first_name")]);
    }
    function issue(): void {
        $emp = (int)$this->in('employee_id', 0); if (!$emp || !Scope::allows($emp)) { flash('Choisissez un collaborateur de votre périmètre.', 'danger'); redirect('certificates/issue'); }
        $tpl = (int)$this->in('template_id', 0) ?: null; $x = Cert::forEmployee($emp, $tpl); if (!$x) { $this->notFound(); return; }
        // Une attestation RH est datée du jour : un nouvel enregistrement par délivrance.
        $refId = (int)DB::val("SELECT COALESCE(MAX(ref_id),0)+1 FROM cert_issued WHERE ref_type='hr'");
        Audit::log('certificate', 'employee', $emp, null, ['template' => $x[0]['id']]); Cert::deliver($x[0], $x[1], 'hr', $refId, 'attestation-' . $x[1]['matricule'], $emp);
    }
}
