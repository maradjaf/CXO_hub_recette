<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Scope, Notifier, ELearn, Xchg};
class ELearnController extends Controller {
    // =============== Apprenant ===============
    private function mine(string $eid, bool $needPublished = true): ?array {
        $e = DB::one('SELECT en.*, c.title, c.description, c.pass_pct, c.max_attempts, c.show_answers, c.status course_status, c.training_id, c.created_by, c.id cid, c.time_limit_min, c.draw_count, c.certificate, c.sequential, c.level, c.domain, c.trainer_id FROM el_enrollments en JOIN el_courses c ON c.id=en.course_id WHERE en.id=?', [(int)$eid]);
        if (!$e || (int)$e['user_id'] !== Auth::id()) { $this->notFound(); return null; }
        if ($needPublished && $e['course_status'] !== 'published') { flash('Ce cours n\'est pas disponible pour le moment.', 'warning'); redirect('learn'); }
        return $e;
    }
    /** Bloque l'accès aux leçons et au quiz tant que les cours prérequis ne sont pas réussis. */
    private function gate(array $e): void {
        $m = ELearn::missingPrereqs((int)$e['cid'], Auth::id());
        if ($m) { flash('Ce cours exige d\'abord la réussite de : ' . implode(', ', $m) . '.', 'warning'); redirect('learn/' . $e['id']); }
        $lv = ELearn::levelMissing(['id' => $e['cid'], 'level' => $e['level'], 'domain' => $e['domain']], Auth::id());
        if ($lv) { flash('Niveau verrouillé : validez d\'abord ' . implode(', ', $lv) . '.', 'warning'); redirect('learn/' . $e['id']); }
    }
    const FILE_TYPES = ['mp4' => ['video/mp4'], 'webm' => ['video/webm'], 'mp3' => ['audio/mpeg', 'application/octet-stream'], 'pdf' => ['application/pdf'], 'png' => ['image/png'], 'jpg' => ['image/jpeg'], 'jpeg' => ['image/jpeg']];
    const FILE_MAX = 150 * 1024 * 1024;
    public static function fileDir(): string { $d = ROOT . '/storage/uploads/el'; if (!is_dir($d)) @mkdir($d, 0775, true); return $d; }
    /** Enregistre le fichier téléversé d'une leçon. @return array{0:?array,1:?string} champs de la leçon, erreur */
    private function takeFile(): array {
        $f = $_FILES['lesson_file'] ?? null; if (!$f || ($f['error'] ?? 4) === UPLOAD_ERR_NO_FILE) return [null, null];
        if ($f['error'] !== UPLOAD_ERR_OK) return [null, 'Fichier non reçu (taille limitée par la configuration PHP : upload_max_filesize / post_max_size).'];
        if ($f['size'] > self::FILE_MAX) return [null, 'Fichier trop volumineux (150 Mo maximum).'];
        $name = trim(preg_replace('#[\x00-\x1f\\\\/]+#', '_', (string)$f['name'])); $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if (!isset(self::FILE_TYPES[$ext])) return [null, 'Type de fichier non autorisé (mp4, webm, mp3, pdf, png, jpg).'];
        $mime = function_exists('mime_content_type') ? (string)@mime_content_type($f['tmp_name']) : '';
        if ($mime !== '' && !in_array($mime, self::FILE_TYPES[$ext], true)) return [null, 'Le contenu du fichier ne correspond pas à son extension.'];
        $stored = bin2hex(random_bytes(16)) . '.' . $ext;
        if (!@move_uploaded_file($f['tmp_name'], self::fileDir() . '/' . $stored)) return [null, 'Enregistrement du fichier impossible.'];
        $std = ['mp4' => 'video/mp4', 'webm' => 'video/webm', 'mp3' => 'audio/mpeg', 'pdf' => 'application/pdf', 'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg'][$ext];
        return [['file_stored' => $stored, 'file_name' => mb_substr($name, 0, 190), 'file_mime' => $std, 'file_size' => (int)$f['size']], null];
    }
    private function dropFile(?string $stored): void { if ($stored && preg_match('/^[a-f0-9]{32}\.[a-z0-9]{2,4}$/', $stored)) @unlink(self::fileDir() . '/' . $stored); }
    /** Envoie un fichier avec prise en charge des requêtes partielles (lecture/avance rapide des vidéos). */
    public static function stream(array $l): never {
        $path = self::fileDir() . '/' . $l['file_stored'];
        if (!preg_match('/^[a-f0-9]{32}\.[a-z0-9]{2,4}$/', (string)$l['file_stored']) || !is_file($path)) { http_response_code(404); exit('Fichier introuvable.'); }
        $size = filesize($path); $start = 0; $end = $size - 1;
        header('Content-Type: ' . $l['file_mime']); header('X-Content-Type-Options: nosniff'); header('Accept-Ranges: bytes'); header('Cache-Control: private, max-age=0');
        header("Content-Security-Policy: sandbox; default-src 'none'; media-src 'self'; img-src 'self'; style-src 'unsafe-inline'");
        header('Content-Disposition: inline; filename="' . rawurlencode($l['file_name'] ?: 'fichier') . '"; filename*=UTF-8\'\'' . rawurlencode($l['file_name'] ?: 'fichier'));
        if (!empty($_SERVER['HTTP_RANGE']) && preg_match('/^bytes=(\d*)-(\d*)$/', trim($_SERVER['HTTP_RANGE']), $m) && ($m[1] !== '' || $m[2] !== '')) {
            if ($m[1] === '') { $start = max(0, $size - (int)$m[2]); } else { $start = (int)$m[1]; if ($m[2] !== '') $end = min($end, (int)$m[2]); }
            if ($start > $end || $start >= $size) { http_response_code(416); header("Content-Range: bytes */$size"); exit; }
            http_response_code(206); header("Content-Range: bytes $start-$end/$size");
        }
        header('Content-Length: ' . ($end - $start + 1)); $fp = fopen($path, 'rb'); fseek($fp, $start); $left = $end - $start + 1;
        while ($left > 0 && !feof($fp)) { $chunk = fread($fp, min(8192 * 8, $left)); if ($chunk === false) break; echo $chunk; $left -= strlen($chunk); }
        fclose($fp); exit;
    }
    function lessonFile(string $eid, string $lid): void {
        if (!($e = $this->mine($eid))) return; $this->gate($e);
        $l = DB::one('SELECT * FROM el_lessons WHERE id=? AND course_id=? AND file_stored IS NOT NULL', [(int)$lid, (int)$e['cid']]); if (!$l) { $this->notFound(); return; }
        $this->stream($l);
    }
    function lessonFileAdmin(string $id, string $lid): void {
        $l = DB::one('SELECT * FROM el_lessons WHERE id=? AND course_id=? AND file_stored IS NOT NULL', [(int)$lid, (int)$id]); if (!$l) { $this->notFound(); return; }
        $this->stream($l);
    }
    private function certificatePdf(array $e): never {
        $x = \App\Core\Cert::forCourse($e); if (!$x) { $this->notFound(); exit; }
        Audit::log('certificate', 'el_enrollment', $e['id']); \App\Core\Cert::deliver($x[0], $x[1], 'el_enrollment', (int)$e['id'], 'certificat-' . ELearn::certNo($e), $e['employee_id'] ? (int)$e['employee_id'] : null);
    }
    function certificate(string $eid): void { if (!($e = $this->mine($eid, false))) return; $this->certificatePdf($e); }
    function certificateFor(string $eid): void {
        $e = DB::one('SELECT * FROM el_enrollments WHERE id=?', [(int)$eid]); if (!$e) { $this->notFound(); return; }
        if (!$e['employee_id'] || !Scope::allows((int)$e['employee_id'])) { $this->forbidden(); return; }
        $this->certificatePdf($e);
    }
    function index(): void {
        $rows = DB::all('SELECT en.*, c.title, c.category, c.duration_min, c.domain, c.level, c.status course_status FROM el_enrollments en JOIN el_courses c ON c.id=en.course_id WHERE en.user_id=? ORDER BY CASE en.status WHEN \'in_progress\' THEN 0 WHEN \'assigned\' THEN 1 WHEN \'failed\' THEN 2 ELSE 3 END, en.due_date', [Auth::id()]);
        foreach ($rows as &$r) $r['prog'] = ELearn::progress((int)$r['id'], (int)$r['course_id']);
        $open = DB::all("SELECT c.* FROM el_courses c WHERE c.status='published' AND c.open_enroll=1 AND NOT EXISTS (SELECT 1 FROM el_enrollments en WHERE en.course_id=c.id AND en.user_id=?) ORDER BY c.title", [Auth::id()]);
        $paths = DB::all("SELECT DISTINCT p.id, p.name FROM el_paths p JOIN el_path_courses pc ON pc.path_id=p.id JOIN el_enrollments en ON en.course_id=pc.course_id AND en.user_id=? WHERE p.active=1 ORDER BY p.name", [Auth::id()]);
        foreach ($paths as &$pa) { $pa['total'] = (int)DB::val('SELECT COUNT(*) FROM el_path_courses WHERE path_id=?', [(int)$pa['id']]); $pa['done'] = (int)DB::val("SELECT COUNT(*) FROM el_path_courses pc JOIN el_enrollments en ON en.course_id=pc.course_id AND en.user_id=? AND en.status='passed' WHERE pc.path_id=?", [Auth::id(), (int)$pa['id']]); }
        $resume = null; foreach ($rows as $r) if ($r['status'] === 'in_progress' && $r['course_status'] === 'published') { $st = ELearn::pending((int)$r['id'], (int)$r['course_id']); if ($st && !ELearn::missingPrereqs((int)$r['course_id'], Auth::id())) { $resume = ['id' => $r['id'], 'title' => $r['title'], 'step' => $st]; break; } }
        $this->view('learn/index', ['title' => 'Mes cours', 'rows' => $rows, 'open' => $open, 'paths' => $paths, 'reminders' => ELearn::reminders(Auth::id()), 'resume' => $resume, 'levels' => ELearn::levelStatus(Auth::id())]);
    }
    function enroll(string $cid): void {
        $c = DB::one("SELECT * FROM el_courses WHERE id=? AND status='published' AND open_enroll=1", [(int)$cid]); if (!$c) { $this->notFound(); return; }
        $id = ELearn::enroll((int)$cid, Auth::id(), null, null); if ($id) Audit::log('enroll', 'el_enrollment', $id, null, ['course' => $c['title'], 'self' => true]);
        redirect('learn/' . ($id ?: DB::val('SELECT id FROM el_enrollments WHERE course_id=? AND user_id=?', [(int)$cid, Auth::id()])));
    }
    /** URL d'une étape du parcours. */
    public static function stepUrl($eid, array $st): string {
        return match ($st['type']) { 'lesson' => "learn/$eid/lesson/{$st['node']['id']}", 'nodequiz' => "learn/$eid/node/{$st['node']['id']}/quiz", default => "learn/$eid/activity/{$st['act']['id']}" };
    }
    private function courseRow(array $e): array { return ['id' => $e['cid'], 'sequential' => $e['sequential']]; }
    function course(string $eid): void {
        if (!($e = $this->mine($eid, false))) return; $cid = (int)$e['cid'];
        $steps = ELearn::steps($cid); $dk = ELearn::doneKeys((int)$eid); $pend = ELearn::pending((int)$eid, $cid);
        $locked = []; $seqOk = true; foreach ($steps as $st) { $locked[$st['key']] = !empty($e['sequential']) && !$seqOk; if ($st['required'] && !isset($dk[$st['key']])) $seqOk = false; }
        $this->view('learn/course', ['title' => $e['title'], 'e' => $e, 'nodes' => ELearn::nodes($cid), 'steps' => $steps, 'dk' => $dk, 'locked' => $locked, 'pend' => $pend, 'prog' => ELearn::progress((int)$eid, $cid),
            'nq' => (int)DB::val('SELECT COUNT(*) FROM el_questions WHERE course_id=? AND node_id IS NULL', [$cid]),
            'missing' => ELearn::missingPrereqs($cid, Auth::id()), 'levelMissing' => ELearn::levelMissing(['id' => $cid, 'level' => $e['level'], 'domain' => $e['domain']], Auth::id()),
            'attempts' => DB::all('SELECT * FROM el_attempts WHERE enrollment_id=? AND node_id IS NULL AND submitted_at IS NOT NULL ORDER BY id DESC', [(int)$eid]), 'open' => DB::one('SELECT id FROM el_attempts WHERE enrollment_id=? AND node_id IS NULL AND submitted_at IS NULL', [(int)$eid]),
            'thread' => Xchg::on('elearn.qna') ? ELearn::thread($cid, null, Auth::id(), false) : null]);
    }
    function lesson(string $eid, string $lid): void {
        if (!($e = $this->mine($eid))) return; $this->gate($e);
        $l = DB::one('SELECT * FROM el_lessons WHERE id=? AND course_id=?', [(int)$lid, (int)$e['cid']]); if (!$l) { $this->notFound(); return; }
        if (!ELearn::canAccess((int)$eid, $this->courseRow($e), 'l' . $l['id'])) { flash('Cette partie se débloque après avoir terminé les étapes précédentes.', 'warning'); redirect("learn/$eid"); }
        $steps = ELearn::steps((int)$e['cid']); $idx = null; foreach ($steps as $k => $st) if ($st['key'] === 'l' . $l['id']) $idx = $k;
        $prev = $idx !== null && $idx > 0 ? $steps[$idx - 1] : null; $next = $idx !== null && $idx < count($steps) - 1 ? $steps[$idx + 1] : null;
        $me = null; foreach (ELearn::nodes((int)$e['cid']) as $x) if ((int)$x['id'] === (int)$l['id']) $me = $x;
        $hasQuiz = (int)DB::val('SELECT COUNT(*) FROM el_questions WHERE node_id=?', [(int)$lid]) > 0;
        $this->view('learn/lesson', ['title' => $l['title'], 'e' => $e, 'l' => $l, 'me' => $me, 'prevUrl' => $prev ? self::stepUrl($eid, $prev) : null, 'nextUrl' => $next ? self::stepUrl($eid, $next) : null, 'hasQuiz' => $hasQuiz && $me && $me['leaf'],
            'qna' => Xchg::on('elearn.qna'), 'thread' => Xchg::on('elearn.qna') ? ELearn::thread((int)$e['cid'], (int)$lid, Auth::id(), false) : null, 'isDone' => (bool)DB::val('SELECT 1 FROM el_progress WHERE enrollment_id=? AND lesson_id=?', [(int)$eid, (int)$lid])]);
    }
    function lessonDone(string $eid, string $lid): void {
        if (!($e = $this->mine($eid))) return; $this->gate($e);
        if (!DB::val('SELECT 1 FROM el_lessons WHERE id=? AND course_id=?', [(int)$lid, (int)$e['cid']])) { $this->notFound(); return; }
        if (!ELearn::canAccess((int)$eid, $this->courseRow($e), 'l' . $lid)) { flash('Étape verrouillée.', 'warning'); redirect("learn/$eid"); }
        if (!DB::val('SELECT 1 FROM el_progress WHERE enrollment_id=? AND lesson_id=?', [(int)$eid, (int)$lid])) DB::insert('el_progress', ['enrollment_id' => (int)$eid, 'lesson_id' => (int)$lid, 'done_at' => now()]);
        if ($e['status'] === 'assigned') DB::update('el_enrollments', ['status' => 'in_progress', 'started_at' => now()], 'id=?', [(int)$eid]);
        if (ELearn::maybeComplete((int)$eid)) { flash('Cours terminé : félicitations !'); redirect("learn/$eid"); }
        $steps = ELearn::steps((int)$e['cid']); foreach ($steps as $k => $st) if ($st['key'] === 'l' . $lid && isset($steps[$k + 1])) redirect(self::stepUrl($eid, $steps[$k + 1]));
        flash(DB::val('SELECT 1 FROM el_questions WHERE course_id=? AND node_id IS NULL', [(int)$e['cid']]) ? 'Toutes les étapes sont terminées : vous pouvez passer le quiz final.' : 'Parcours terminé.'); redirect("learn/$eid");
    }
    function startQuiz(string $eid): void {
        if (!($e = $this->mine($eid))) return; $this->gate($e);
        if ($e['status'] === 'passed') { flash('Vous avez déjà réussi ce cours.', 'info'); redirect("learn/$eid"); }
        if (ELearn::pending((int)$eid, (int)$e['cid'])) { flash('Terminez d\'abord toutes les étapes obligatoires.', 'warning'); redirect("learn/$eid"); }
        if (!DB::val('SELECT 1 FROM el_questions WHERE course_id=? AND node_id IS NULL', [(int)$e['cid']])) { flash('Ce cours n\'a pas de quiz.', 'warning'); redirect("learn/$eid"); }
        if ($open = DB::one('SELECT * FROM el_attempts WHERE enrollment_id=? AND node_id IS NULL AND submitted_at IS NULL', [(int)$eid])) {
            if ($this->expired($open)) { $this->timeout($e, $open); redirect("learn/$eid/attempt/{$open['id']}"); }
            redirect("learn/$eid/attempt/{$open['id']}");
        }
        $n = (int)$e['attempts'];   // compteur remis à zéro par une réinitialisation
        if ((int)$e['max_attempts'] > 0 && $n >= (int)$e['max_attempts']) { flash('Nombre maximal de tentatives atteint. Contactez votre responsable.', 'danger'); redirect("learn/$eid"); }
        $course = DB::one('SELECT * FROM el_courses WHERE id=?', [(int)$e['cid']]); $tl = (int)$e['time_limit_min'];
        $a = DB::insert('el_attempts', ['enrollment_id' => (int)$eid, 'passed' => 0, 'started_at' => now(), 'question_ids' => implode(',', ELearn::draw($course)), 'deadline' => $tl > 0 ? date('Y-m-d H:i:s', time() + $tl * 60) : null]);
        if ($e['status'] === 'assigned') DB::update('el_enrollments', ['status' => 'in_progress', 'started_at' => now()], 'id=?', [(int)$eid]);
        redirect("learn/$eid/attempt/$a");
    }
    private const GRACE = 60;   // secondes de tolérance (latence réseau) après l'échéance du chronomètre
    private function expired(array $a): bool { return !$a['submitted_at'] && !empty($a['deadline']) && time() > strtotime($a['deadline']) + self::GRACE; }
    /** Clôt une tentative dont le temps est écoulé : score nul, tentative comptée. */
    private function timeout(array $e, array $a): void {
        DB::update('el_attempts', ['score_pct' => 0, 'passed' => 0, 'submitted_at' => now(), 'timed_out' => 1], 'id=?', [(int)$a['id']]);
        $n = (int)$e['attempts'] + 1; $u = ['attempts' => $n, 'status' => ((int)$e['max_attempts'] > 0 && $n >= (int)$e['max_attempts']) ? 'failed' : 'in_progress'];
        DB::update('el_enrollments', $u, 'id=?', [(int)$e['id']]); Audit::log('quiz_timeout', 'el_attempt', $a['id'], null, ['course' => $e['title']]);
        flash('Temps écoulé : la tentative est comptée avec un score nul.', 'danger');
    }
    private function attemptOf(array $e, string $aid): ?array { $a = DB::one('SELECT * FROM el_attempts WHERE id=? AND enrollment_id=?', [(int)$aid, (int)$e['id']]); if (!$a) { $this->notFound(); return null; } return $a; }
    function attempt(string $eid, string $aid): void {
        if (!($e = $this->mine($eid, false)) || !($a = $this->attemptOf($e, $aid))) return;
        if ($a['submitted_at']) {   // résultat
            $ans = []; foreach (DB::all('SELECT * FROM el_answers WHERE attempt_id=?', [(int)$aid]) as $x) $ans[(int)$x['question_id']] = $x;
            $qs = ELearn::attemptQuestions($a, (int)$e['cid']);
            $this->view('learn/result', ['title' => 'Résultat du quiz', 'e' => $e, 'a' => $a, 'qs' => $qs, 'ans' => $ans, 'left' => (int)$e['max_attempts'] > 0 ? max(0, (int)$e['max_attempts'] - (int)$e['attempts']) : null]); return;
        }
        if ($this->expired($a)) { $this->timeout($e, $a); redirect("learn/$eid/attempt/$aid"); }
        if ($e['course_status'] !== 'published') { flash('Ce cours n\'est pas disponible pour le moment.', 'warning'); redirect('learn'); }
        $qs = ELearn::shuffle(ELearn::attemptQuestions($a, (int)$e['cid'], false), (int)$aid); foreach ($qs as &$q) $q['options'] = ELearn::shuffle($q['options'], (int)$aid + (int)$q['id']);
        $this->view('learn/quiz', ['title' => 'Quiz : ' . $e['title'], 'e' => $e, 'a' => $a, 'qs' => $qs]);
    }
    function submit(string $eid, string $aid): void {
        if (!($e = $this->mine($eid)) || !($a = $this->attemptOf($e, $aid))) return;
        if ($a['submitted_at']) redirect("learn/$eid/attempt/$aid");
        $course = DB::one('SELECT * FROM el_courses WHERE id=?', [(int)$e['cid']]);
        if ($this->expired($a)) { $this->timeout($e, $a); redirect("learn/$eid/attempt/$aid"); }
        [$pct, $passed] = ELearn::grade($course, $a, $_POST);
        DB::update('el_attempts', ['score_pct' => $pct, 'passed' => $passed ? 1 : 0, 'submitted_at' => now()], 'id=?', [(int)$aid]);
        $n = (int)$e['attempts'] + 1;
        $best = max((float)$e['best_pct'], $pct);
        $u = ['attempts' => $n, 'best_pct' => $best];
        if ($passed) { $u += ['status' => 'passed', 'completed_at' => now()]; }
        elseif ((int)$e['max_attempts'] > 0 && $n >= (int)$e['max_attempts']) $u['status'] = 'failed';
        else $u['status'] = 'in_progress';
        DB::update('el_enrollments', $u, 'id=?', [(int)$eid]);
        if ($passed || ($u['status'] ?? '') === 'failed') \App\Core\Sat::requestCourse((int)$eid);
        if ($passed) {
            ELearn::syncTraining($course, $e, $pct);
            if ($e['assigned_by']) Notifier::send((int)$e['assigned_by'], 'Cours réussi', (Auth::user()['name'] ?? '') . ' — ' . $e['title'] . ' (' . $pct . ' %)', '/elearn/report');
        } elseif (($u['status'] ?? '') === 'failed' && $e['assigned_by']) Notifier::send((int)$e['assigned_by'], 'Cours non validé', (Auth::user()['name'] ?? '') . ' — ' . $e['title'] . ' : tentatives épuisées', '/elearn/report');
        Audit::log('quiz', 'el_attempt', $aid, null, ['course' => $e['title'], 'score' => $pct, 'passed' => $passed]);
        redirect("learn/$eid/attempt/$aid");
    }

    // =============== Auteur ===============
    function catalog(): void {
        $this->view('elearn/index', ['title' => 'Cours et quiz', 'rows' => DB::all("SELECT c.*, (SELECT COUNT(*) FROM el_lessons l WHERE l.course_id=c.id) nl, (SELECT COUNT(*) FROM el_questions q WHERE q.course_id=c.id) nq,
            (SELECT COUNT(*) FROM el_enrollments en WHERE en.course_id=c.id) ne, (SELECT COUNT(*) FROM el_enrollments en WHERE en.course_id=c.id AND en.status='passed') np FROM el_courses c ORDER BY c.status='archived', c.title"), 'trainings' => DB::all('SELECT id, title FROM trainings WHERE active=1 ORDER BY title')]);
    }
    private function courseData(): array {   // Lot 48 : domaine, nature, niveau, parcours par étapes, formateur
        [$d, $err] = $this->validate(['title' => ['label' => 'Le titre', 'req' => true, 'max' => 190], 'category' => ['label' => 'La catégorie', 'max' => 80], 'description' => ['label' => 'La description', 'max' => 1000]], $_POST);
        $pass = (int)$this->in('pass_pct', 80); if ($pass < 1 || $pass > 100) $err['pass'] = 'Le seuil de réussite doit être compris entre 1 et 100 %.';
        $att = (int)$this->in('max_attempts', 0); if ($att < 0 || $att > 20) $err['att'] = 'Nombre de tentatives invalide (0 = illimité).';
        $tl = (int)$this->in('time_limit_min', 0); if ($tl < 0 || $tl > 480) $err['tl'] = 'Le chronomètre doit être compris entre 1 et 480 minutes (0 = sans limite).';
        $dr = (int)$this->in('draw_count', 0); if ($dr < 0 || $dr > 500) $err['dr'] = 'Le nombre de questions tirées est invalide (0 = toutes).';
        $dur = (int)$this->in('duration_min', 0); $tr = (int)$this->in('training_id', 0); if ($tr && !DB::val('SELECT 1 FROM trainings WHERE id=?', [$tr])) $tr = 0;
        return [$d + ['pass_pct' => $pass, 'max_attempts' => $att, 'duration_min' => $dur > 0 ? min($dur, 9999) : null, 'training_id' => $tr ?: null, 'time_limit_min' => $tl > 0 ? $tl : null, 'draw_count' => $dr, 'certificate' => $this->in('certificate') === '1' ? 1 : 0, 'cert_template_id' => (($ct = (int)$this->in('cert_template_id', 0)) && DB::val('SELECT 1 FROM cert_templates WHERE id=?', [$ct])) ? $ct : null, 'show_answers' => $this->in('show_answers') === '1' ? 1 : 0, 'open_enroll' => $this->in('open_enroll') === '1' ? 1 : 0, 'updated_at' => now(),
            'domain' => (($dm = trim((string)$this->in('domain'))) !== '' ? mb_substr($dm, 0, 80) : null), 'nature' => isset(ELearn::NATURES[(string)$this->in('nature')]) ? (string)$this->in('nature') : 'both', 'level' => isset(ELearn::LEVELS[(string)$this->in('level')]) ? (string)$this->in('level') : null,
            'sequential' => $this->in('sequential') === '1' ? 1 : 0, 'trainer_id' => (($tid = (int)$this->in('trainer_id', 0)) && DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$tid])) ? $tid : null], $err];
    }
    function store(): void {
        [$d, $err] = $this->courseData(); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('elearn'); }
        $id = DB::insert('el_courses', $d + ['status' => 'draft', 'created_by' => Auth::id(), 'created_at' => now()]); Audit::log('create', 'el_course', $id, null, $d); flash('Cours créé en brouillon : ajoutez les leçons et le quiz.'); redirect("elearn/$id");
    }
    private function course_(string $id): ?array { $c = DB::one('SELECT * FROM el_courses WHERE id=?', [(int)$id]); if (!$c) $this->notFound(); return $c; }
    function edit(string $id): void {
        if (!($c = $this->course_($id))) return;
        $this->view('elearn/edit', ['title' => $c['title'], 'c' => $c, 'nodes' => ELearn::nodes((int)$id), 'qs' => ELearn::questions((int)$id), 'errors' => $c['status'] === 'draft' ? ELearn::publishErrors((int)$id) : [],
            'trainings' => DB::all('SELECT id, title FROM trainings WHERE active=1 ORDER BY title'), 'ne' => (int)DB::val('SELECT COUNT(*) FROM el_enrollments WHERE course_id=?', [(int)$id]),
            'others' => DB::all('SELECT id, title FROM el_courses WHERE id<>? ORDER BY title', [(int)$id]), 'reqs' => array_map('intval', array_column(DB::all('SELECT requires_id FROM el_prereqs WHERE course_id=?', [(int)$id]), 'requires_id'))]);
    }
    function update(string $id): void {
        if (!($c = $this->course_($id))) return; [$d, $err] = $this->courseData(); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("elearn/$id"); }
        DB::update('el_courses', $d, 'id=?', [(int)$id]); Audit::log('update', 'el_course', $id, $c, $d); flash('Cours enregistré.'); redirect("elearn/$id");
    }
    /** Page de retour après une action (champ « back » : chemin interne elearn/…), sinon la fiche du cours. */
    private function backTo(string $id): string { $b = (string)$this->in('back'); return preg_match('#^elearn/\d+(/[a-z]+(/\d+)?)?(\#[a-z]+)?$#', $b) ? $b : "elearn/$id"; }
    private function needDraft(array $c): void { if ($c['status'] === 'published') { flash('Dépubliez le cours avant de modifier sa structure (leçons ou questions) : les participants en cours ne doivent pas voir le quiz changer.', 'warning'); redirect('elearn/' . $c['id']); } }
    function storeLesson(string $id): void {
        if (!($c = $this->course_($id))) return; $this->needDraft($c);
        [$d, $err] = $this->validate(['title' => ['label' => 'Le titre', 'req' => true, 'max' => 190], 'body' => ['label' => 'Le contenu', 'max' => 20000], 'url' => ['label' => 'Le lien', 'max' => 500]], $_POST); $d['body'] = \App\Core\RichHtml::clean((string)$d['body']);
        if (!$err && $d['url'] && !preg_match('#^https://[^\s<>"]+$#i', $d['url'])) $err['url'] = 'Le lien doit commencer par https://.';
        [$file, $ferr] = $this->takeFile(); if ($ferr) $err['file'] = $ferr;
        if (!$err && !$d['body'] && !$d['url'] && !$file) $err['body'] = 'Renseignez un contenu, un lien ou un fichier.';
        if ($err) { if ($file) $this->dropFile($file['file_stored']); $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("elearn/$id"); }
        $pos = (int)DB::val('SELECT COALESCE(MAX(position),0) FROM el_lessons WHERE course_id=?', [(int)$id]) + 1;
        $lid = DB::insert('el_lessons', $d + ($file ?? []) + ['course_id' => (int)$id, 'position' => $pos]); Audit::log('create', 'el_lesson', $lid, null, ['course' => $id, 'title' => $d['title']]); flash('Leçon ajoutée.'); redirect("elearn/$id");
    }
    function updateLesson(string $id, string $lid): void {
        if (!($c = $this->course_($id))) return; $l = DB::one('SELECT * FROM el_lessons WHERE id=? AND course_id=?', [(int)$lid, (int)$id]); if (!$l) { $this->notFound(); return; }
        [$d, $err] = $this->validate(['title' => ['label' => 'Le titre', 'req' => true, 'max' => 190], 'body' => ['label' => 'Le contenu', 'max' => 20000], 'url' => ['label' => 'Le lien', 'max' => 500]], $_POST);
        if (!$err) $d['body'] = \App\Core\RichHtml::clean((string)$d['body']);
        if (!$err && $d['url'] && !preg_match('#^https://[^\s<>"]+$#i', $d['url'])) $err['url'] = 'Le lien doit commencer par https://.';
        [$file, $ferr] = $this->takeFile(); if ($ferr) $err['file'] = $ferr; $removeFile = $this->in('remove_file') === '1';
        $keepsFile = $l['file_stored'] && !$removeFile || $file;
        if (!$err && !$d['body'] && !$d['url'] && !$keepsFile) $err['body'] = 'Renseignez un contenu, un lien ou un fichier.';
        if ($err) { if ($file) $this->dropFile($file['file_stored']); $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("elearn/$id"); }
        $pos = (int)$this->in('position', $l['position']); if ($pos < 1 || $pos > 999) $pos = (int)$l['position'];
        $fileCols = [];
        if ($file) { $this->dropFile($l['file_stored']); $fileCols = $file; }
        elseif ($removeFile && $l['file_stored']) { $this->dropFile($l['file_stored']); $fileCols = ['file_stored' => null, 'file_name' => null, 'file_mime' => null, 'file_size' => null]; }
        DB::update('el_lessons', $d + $fileCols + ['position' => $pos], 'id=?', [(int)$lid]); Audit::log('update', 'el_lesson', $lid, $l, $d); flash('Leçon enregistrée.'); redirect("elearn/$id");
    }
    function deleteLesson(string $id, string $lid): void {
        if (!($c = $this->course_($id))) return; $this->needDraft($c);
        if ($old = DB::val('SELECT file_stored FROM el_lessons WHERE id=? AND course_id=?', [(int)$lid, (int)$id])) $this->dropFile($old);
        DB::pdo()->prepare('DELETE FROM el_progress WHERE lesson_id=?')->execute([(int)$lid]); DB::pdo()->prepare('DELETE FROM el_lessons WHERE id=? AND course_id=?')->execute([(int)$lid, (int)$id]);
        Audit::log('delete', 'el_lesson', $lid, ['course' => $id]); flash('Leçon supprimée.'); redirect("elearn/$id");
    }
    function storeQuestion(string $id): void {
        if (!($c = $this->course_($id))) return; $this->needDraft($c);
        [$d, $err] = $this->validate(['text' => ['label' => 'La question', 'req' => true, 'max' => 500], 'explanation' => ['label' => 'L\'explication', 'max' => 500]], $_POST);
        $kind = $this->in('kind') === 'multi' ? 'multi' : 'single'; $scoring = ($kind === 'multi' && $this->in('scoring') === 'partial') ? 'partial' : 'strict'; $opts = []; $correct = array_map('intval', (array)($_POST['correct'] ?? []));
        foreach ((array)($_POST['options'] ?? []) as $i => $t) { $t = trim((string)$t); if ($t === '') continue; if (mb_strlen($t) > 300) $err['o'] = 'Une réponse est trop longue (300 caractères).'; $opts[] = [mb_substr($t, 0, 300), in_array((int)$i, $correct, true) ? 1 : 0]; }
        if (count($opts) < 2) $err['o2'] = 'Saisissez au moins 2 réponses.'; elseif (count($opts) > 8) $err['o3'] = '8 réponses au maximum.';
        else { $ok = array_sum(array_column($opts, 1)); if ($ok < 1) $err['o4'] = 'Cochez au moins une bonne réponse.'; elseif ($kind === 'single' && $ok !== 1) $err['o5'] = 'Une question à réponse unique doit avoir exactement une bonne réponse.'; }
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect($this->backTo($id)); }
        $pos = (int)DB::val('SELECT COALESCE(MAX(position),0) FROM el_questions WHERE course_id=?', [(int)$id]) + 1;
        $nid = (int)$this->in('node_id', 0); if ($nid && !DB::val('SELECT 1 FROM el_lessons WHERE id=? AND course_id=?', [$nid, (int)$id])) $nid = 0;
        $q = DB::insert('el_questions', $d + ['course_id' => (int)$id, 'position' => $pos, 'kind' => $kind, 'scoring' => $scoring, 'node_id' => $nid ?: null]);
        foreach ($opts as [$t, $ok]) DB::insert('el_options', ['question_id' => $q, 'text' => $t, 'correct' => $ok]);
        Audit::log('create', 'el_question', $q, null, ['course' => $id]); flash('Question ajoutée.'); redirect($this->backTo($id));
    }
    function deleteQuestion(string $id, string $qid): void {
        if (!($c = $this->course_($id))) return; $this->needDraft($c);
        if (DB::val('SELECT 1 FROM el_questions WHERE id=? AND course_id=?', [(int)$qid, (int)$id])) { DB::pdo()->prepare('DELETE FROM el_options WHERE question_id=?')->execute([(int)$qid]); DB::pdo()->prepare('DELETE FROM el_questions WHERE id=?')->execute([(int)$qid]); }
        Audit::log('delete', 'el_question', $qid, ['course' => $id]); flash('Question supprimée.'); redirect($this->backTo($id));
    }
    function setStatus(string $id): void {
        if (!($c = $this->course_($id))) return; $a = (string)$this->in('action');
        if ($a === 'publish') { $err = ELearn::publishErrors((int)$id); if ($err) { flash('Publication impossible : ' . implode(' ', $err), 'danger'); redirect("elearn/$id"); } $st = 'published'; }
        elseif ($a === 'unpublish') $st = 'draft'; elseif ($a === 'archive') $st = 'archived'; else { flash('Action inconnue.', 'danger'); redirect("elearn/$id"); }
        DB::update('el_courses', ['status' => $st, 'updated_at' => now()], 'id=?', [(int)$id]); Audit::log($a, 'el_course', $id, ['status' => $c['status']], ['status' => $st]);
        flash(['published' => 'Cours publié : il est visible des participants inscrits.', 'draft' => 'Cours repassé en brouillon.', 'archived' => 'Cours archivé.'][$st]); redirect("elearn/$id");
    }
    function savePrereqs(string $id): void {
        if (!($c = $this->course_($id))) return; $want = array_unique(array_map('intval', (array)($_POST['requires'] ?? []))); $err = [];
        DB::pdo()->prepare('DELETE FROM el_prereqs WHERE course_id=?')->execute([(int)$id]);
        foreach ($want as $r) {
            if (!DB::val('SELECT 1 FROM el_courses WHERE id=?', [$r])) continue;
            if (ELearn::wouldCycle((int)$id, $r)) { $err[] = DB::val('SELECT title FROM el_courses WHERE id=?', [$r]); continue; }
            DB::insert('el_prereqs', ['course_id' => (int)$id, 'requires_id' => $r]);
        }
        Audit::log('update', 'el_prereqs', $id, null, ['requires' => $want]);
        flash($err ? 'Prérequis enregistrés, sauf (boucle) : ' . implode(', ', $err) . '.' : 'Prérequis enregistrés.', $err ? 'warning' : 'success'); redirect("elearn/$id");
    }

    // =============== Parcours (suites de cours) ===============
    function paths(): void {
        $this->view('elearn/paths', ['title' => 'Parcours de formation', 'rows' => DB::all('SELECT p.*, (SELECT COUNT(*) FROM el_path_courses pc WHERE pc.path_id=p.id) nc FROM el_paths p ORDER BY p.name')]);
    }
    function storePath(): void {
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'description' => ['label' => 'La description', 'max' => 500]], $_POST);
        if (!$err && DB::val('SELECT 1 FROM el_paths WHERE name=?', [$d['name']])) $err['n'] = 'Ce parcours existe déjà.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('elearn/paths'); }
        $id = DB::insert('el_paths', $d + ['active' => 1, 'created_at' => now()]); Audit::log('create', 'el_path', $id, null, $d); flash('Parcours créé : ajoutez les cours dans l\'ordre.'); redirect("elearn/paths/$id");
    }
    private function path_(string $id): ?array { $p = DB::one('SELECT * FROM el_paths WHERE id=?', [(int)$id]); if (!$p) $this->notFound(); return $p; }
    function path(string $id): void {
        if (!($p = $this->path_($id))) return;
        $this->view('elearn/path', ['title' => $p['name'], 'p' => $p, 'courses' => DB::all('SELECT c.id, c.title, c.status, pc.position FROM el_path_courses pc JOIN el_courses c ON c.id=pc.course_id WHERE pc.path_id=? ORDER BY pc.position, pc.id', [(int)$id]),
            'all' => DB::all("SELECT id, title FROM el_courses WHERE status<>'archived' AND id NOT IN (SELECT course_id FROM el_path_courses WHERE path_id=?) ORDER BY title", [(int)$id]), 'employees' => Scope::employees(), 'templates' => DB::all("SELECT id, name FROM cert_templates WHERE active=1 AND kind IN ('path','any') ORDER BY name")]);
    }
    function updatePath(string $id): void {
        if (!($p = $this->path_($id))) return; $a = (string)$this->in('action');
        if ($a === 'add') {
            $c = (int)$this->in('course_id'); if (DB::val('SELECT 1 FROM el_courses WHERE id=?', [$c]) && !DB::val('SELECT 1 FROM el_path_courses WHERE path_id=? AND course_id=?', [(int)$id, $c]))
                DB::insert('el_path_courses', ['path_id' => (int)$id, 'course_id' => $c, 'position' => (int)DB::val('SELECT COALESCE(MAX(position),0) FROM el_path_courses WHERE path_id=?', [(int)$id]) + 1]);
        } elseif ($a === 'remove') {
            DB::pdo()->prepare('DELETE FROM el_path_courses WHERE path_id=? AND course_id=?')->execute([(int)$id, (int)$this->in('course_id')]);
        } elseif ($a === 'chain') {   // chaque cours exige la réussite du précédent du parcours
            $ids = array_map('intval', array_column(DB::all('SELECT course_id FROM el_path_courses WHERE path_id=? ORDER BY position, id', [(int)$id]), 'course_id')); $n = 0; $skip = 0;
            for ($i = 1; $i < count($ids); $i++) {
                if (DB::val('SELECT 1 FROM el_prereqs WHERE course_id=? AND requires_id=?', [$ids[$i], $ids[$i - 1]])) continue;
                if (ELearn::wouldCycle($ids[$i], $ids[$i - 1])) { $skip++; continue; } DB::insert('el_prereqs', ['course_id' => $ids[$i], 'requires_id' => $ids[$i - 1]]); $n++;
            }
            flash("$n prérequis ajouté(s) : chaque cours exige la réussite du précédent." . ($skip ? " $skip ignoré(s) (boucle)." : '') . ' Ces prérequis valent aussi hors du parcours.', 'success');
        } elseif ($a === 'meta') {
            $dm = trim((string)$this->in('domain')); DB::update('el_paths', ['domain' => $dm !== '' ? mb_substr($dm, 0, 80) : null, 'level' => isset(ELearn::LEVELS[(string)$this->in('level')]) ? (string)$this->in('level') : null, 'open_enroll' => $this->in('open_enroll') === '1' ? 1 : 0], 'id=?', [(int)$id]); flash('Parcours enregistré.');
        } elseif ($a === 'toggle') { DB::update('el_paths', ['active' => $p['active'] ? 0 : 1], 'id=?', [(int)$id]); }
        elseif ($a === 'cert') { $ct = (int)$this->in('cert_template_id', 0); DB::update('el_paths', ['cert_template_id' => $ct && DB::val('SELECT 1 FROM cert_templates WHERE id=?', [$ct]) ? $ct : null], 'id=?', [(int)$id]); flash('Modèle d\'attestation du parcours enregistré.'); }
        elseif ($a === 'move') {
            $c = (int)$this->in('course_id'); $dir = $this->in('dir') === 'up' ? -1 : 1; $rows = DB::all('SELECT id, course_id FROM el_path_courses WHERE path_id=? ORDER BY position, id', [(int)$id]); $i = null;
            foreach ($rows as $k => $r) if ((int)$r['course_id'] === $c) $i = $k;
            if ($i !== null && isset($rows[$i + $dir])) { $t = $rows[$i]; $rows[$i] = $rows[$i + $dir]; $rows[$i + $dir] = $t; foreach ($rows as $k => $r) DB::update('el_path_courses', ['position' => $k + 1], 'id=?', [(int)$r['id']]); }
        }
        Audit::log('update', 'el_path', $id, null, ['action' => $a]); redirect("elearn/paths/$id");
    }
    function assignPath(string $id): void {
        if (!($p = $this->path_($id))) return;
        $cs = DB::all("SELECT c.* FROM el_path_courses pc JOIN el_courses c ON c.id=pc.course_id WHERE pc.path_id=? AND c.status='published' ORDER BY pc.position", [(int)$id]);
        $skipped = (int)DB::val("SELECT COUNT(*) FROM el_path_courses pc JOIN el_courses c ON c.id=pc.course_id WHERE pc.path_id=? AND c.status<>'published'", [(int)$id]);
        if (!$cs) { flash('Aucun cours publié dans ce parcours.', 'danger'); redirect("elearn/paths/$id"); }
        $due = (string)$this->in('due_date', ''); if ($due !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $due)) { flash('Date limite invalide.', 'danger'); redirect("elearn/paths/$id"); }
        $ok = 0; $noacc = 0; $out = 0;
        [$bulk, $excl, $berr] = \App\Core\Tr::parseBulk($_POST); if ($berr) { flash(implode(' ', array_slice($berr, 0, 4)), 'danger'); redirect("elearn/paths/$id"); }
        foreach ($excl as $xe => $why) { DB::exec("DELETE FROM enroll_exclusions WHERE ref_type='path' AND ref_id=? AND employee_id=?", [(int)$id, $xe]); DB::insert('enroll_exclusions', ['ref_type' => 'path', 'ref_id' => (int)$id, 'employee_id' => $xe, 'reason' => $why, 'by_user' => Auth::id(), 'created_at' => now()]); }
        foreach (array_unique(array_merge($bulk, array_map('intval', (array)($_POST['employee_id'] ?? [])))) as $emp) {
            if (!Scope::allows($emp)) { $out++; continue; }
            $u = DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [$emp]); if (!$u) { $noacc++; continue; }
            foreach ($cs as $c) if (ELearn::enroll((int)$c['id'], (int)$u, Auth::id(), $due ?: null)) $ok++;
        }
        Audit::log('assign', 'el_path', $id, null, ['enrolled' => $ok]);
        flash("$ok inscription(s) créée(s) sur le parcours." . ($skipped ? " $skipped cours non publié(s) ignoré(s)." : '') . ($noacc ? " $noacc collaborateur(s) sans compte." : '') . ($out ? " $out hors de votre périmètre." : ''), $ok ? 'success' : 'warning'); redirect('elearn/report');
    }
    function pathAttestation(string $id): void {
        $x = \App\Core\Cert::forPath((int)$id, (int)Auth::id()); if (!$x) { flash('L\'attestation est disponible quand tous les cours publiés du parcours sont réussis.', 'warning'); redirect('learn'); }
        Audit::log('certificate', 'el_path', $id); \App\Core\Cert::deliver($x[0], $x[1], 'el_path_user', (int)$id * 100000 + (int)Auth::id(), 'attestation-parcours-' . (int)$id, ($em = DB::val('SELECT employee_id FROM users WHERE id=?', [Auth::id()])) ? (int)$em : null);
    }
    function pathAttestationFor(string $id, string $uid): void {
        $emp = DB::val('SELECT employee_id FROM users WHERE id=?', [(int)$uid]); if (!$emp || !Scope::allows((int)$emp)) { $this->forbidden(); return; }
        $x = \App\Core\Cert::forPath((int)$id, (int)$uid); if (!$x) { flash('Parcours non terminé par ce collaborateur.', 'warning'); redirect("elearn/paths/$id"); }
        Audit::log('certificate', 'el_path', $id, null, ['user' => (int)$uid]); \App\Core\Cert::deliver($x[0], $x[1], 'el_path_user', (int)$id * 100000 + (int)$uid, 'attestation-parcours-' . (int)$id . '-' . (int)$uid, (int)$emp);
    }
    function stats(string $id): void {
        if (!($c = $this->course_($id))) return;
        $rows = DB::all('SELECT q.id, q.text, COUNT(a.id) n, COALESCE(SUM(a.correct),0) ok FROM el_questions q LEFT JOIN el_answers a ON a.question_id=q.id WHERE q.course_id=? GROUP BY q.id, q.text, q.position ORDER BY q.position', [(int)$id]);
        $this->view('elearn/stats', ['title' => 'Statistiques : ' . $c['title'], 'c' => $c, 'rows' => $rows, 'agg' => DB::one('SELECT COUNT(*) n, AVG(score_pct) avg, SUM(passed) ok FROM el_attempts a JOIN el_enrollments en ON en.id=a.enrollment_id WHERE en.course_id=? AND a.node_id IS NULL AND a.submitted_at IS NOT NULL', [(int)$id])]);
    }

    // =============== Inscription et suivi ===============
    function assignPage(): void {
        $this->view('elearn/assign', ['title' => 'Inscrire des collaborateurs', 'courses' => DB::all("SELECT id, title FROM el_courses WHERE status='published' ORDER BY title"), 'paths' => DB::all('SELECT id, name FROM el_paths WHERE active=1 ORDER BY name'),
            'employees' => Scope::employees(), 'teams' => DB::all('SELECT t.id, t.name, (SELECT COUNT(*) FROM employees e WHERE e.team_id=t.id AND e.status=\'active\') n FROM teams t WHERE t.active=1 ORDER BY t.name'), 'sel' => (int)$this->in('course'), 'selPath' => (int)$this->in('path')]);
    }
    /** Collaborateurs visés : sélection individuelle, équipes, liste collée (matricules ou e-mails). @return array{0:int[],1:string[]} identifiants, lignes non reconnues */
    private function targets(): array {
        $ids = array_map('intval', (array)($_POST['employee_id'] ?? [])); $bad = [];
        foreach (array_map('intval', (array)($_POST['team_id'] ?? [])) as $t) foreach (DB::all("SELECT id FROM employees WHERE team_id=? AND status='active'", [$t]) as $r) $ids[] = (int)$r['id'];
        foreach (preg_split('/[\s,;]+/', (string)($_POST['list'] ?? ''), -1, PREG_SPLIT_NO_EMPTY) as $tok) {
            $id = str_contains($tok, '@') ? DB::val("SELECT e.id FROM employees e WHERE LOWER(e.email)=LOWER(?) AND e.status='active' UNION SELECT u.employee_id FROM users u WHERE LOWER(u.email)=LOWER(?) AND u.employee_id IS NOT NULL", [$tok, $tok]) : DB::val("SELECT id FROM employees WHERE matricule=? AND status='active'", [$tok]);
            if ($id) $ids[] = (int)$id; else $bad[] = $tok;
        }
        return [array_values(array_unique(array_filter($ids))), $bad];
    }
    function assign(): void {
        $tg = (string)$this->in('target'); if ($tg === '' && $this->in('course_id')) $tg = 'c' . (int)$this->in('course_id');
        $isPath = str_starts_with($tg, 'p'); $tid = (int)substr($tg, 1);
        $courses = $isPath ? DB::all("SELECT c.* FROM el_path_courses pc JOIN el_courses c ON c.id=pc.course_id WHERE pc.path_id=? AND c.status='published' ORDER BY pc.position", [$tid]) : array_filter([DB::one("SELECT * FROM el_courses WHERE id=? AND status='published'", [$tid])]);
        if (!$courses) { flash('Choisissez un cours ou un parcours publié.', 'danger'); redirect('elearn/assign'); }
        $due = (string)$this->in('due_date', ''); if ($due !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $due)) { flash('Date limite invalide.', 'danger'); redirect('elearn/assign'); }
        [$emps, $bad] = $this->targets(); if (!$emps) { flash('Aucun collaborateur sélectionné' . ($bad ? ' (non reconnus : ' . implode(', ', array_slice($bad, 0, 5)) . ')' : '') . '.', 'danger'); redirect('elearn/assign'); }
        $ok = 0; $dup = 0; $noacc = 0; $out = 0;
        foreach ($emps as $emp) {
            if (!Scope::allows($emp)) { $out++; continue; }
            $u = DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [$emp]); if (!$u) { $noacc++; continue; }
            foreach ($courses as $c) if (ELearn::enroll((int)$c['id'], (int)$u, Auth::id(), $due ?: null)) $ok++; else $dup++;
        }
        Audit::log('assign', $isPath ? 'el_path' : 'el_course', $tid, null, ['enrolled' => $ok, 'already' => $dup, 'no_account' => $noacc, 'people' => count($emps)]);
        flash("$ok inscription(s) créée(s) pour " . count($emps) . ' collaborateur(s).' . ($dup ? " $dup déjà inscrit(s)." : '') . ($noacc ? " $noacc collaborateur(s) sans compte utilisateur (non inscrits)." : '') . ($out ? " $out hors de votre périmètre." : '') . ($bad ? ' Non reconnus : ' . implode(', ', array_slice($bad, 0, 5)) . (count($bad) > 5 ? '…' : '') . '.' : ''), $ok ? 'success' : 'warning'); redirect('elearn/report');
    }
    function reset(string $eid): void {
        $e = DB::one('SELECT * FROM el_enrollments WHERE id=?', [(int)$eid]); if (!$e) { $this->notFound(); return; }
        if (!$e['employee_id'] || !Scope::allows((int)$e['employee_id'])) { $this->forbidden(); return; }
        DB::update('el_enrollments', ['status' => 'in_progress', 'attempts' => 0, 'completed_at' => null], 'id=?', [(int)$eid]);
        DB::pdo()->prepare('DELETE FROM el_attempts WHERE enrollment_id=? AND submitted_at IS NULL')->execute([(int)$eid]);
        Notifier::send((int)$e['user_id'], 'Nouvelle chance pour votre cours', 'Vos tentatives ont été réinitialisées.', '/learn/' . $eid); Audit::log('reset', 'el_enrollment', $eid); flash('Tentatives réinitialisées.'); redirect('elearn/report');
    }
    function report(): void {
        [$w, $p] = Scope::sql('en.employee_id'); $w = [$w];
        foreach (['course_id' => 'en.course_id', 'status' => 'en.status'] as $k => $col) if ($this->in($k)) { $w[] = "$col=?"; $p[] = $this->in($k); }
        if ($this->in('overdue') === '1') { $w[] = "en.status IN ('assigned','in_progress') AND en.due_date IS NOT NULL AND en.due_date<?"; $p[] = date('Y-m-d'); }
        $cond = implode(' AND ', $w);
        $from = "el_enrollments en JOIN el_courses c ON c.id=en.course_id JOIN users u ON u.id=en.user_id LEFT JOIN employees e ON e.id=en.employee_id WHERE $cond";
        if ($this->in('export') === 'csv') {
            $rows = DB::all("SELECT e.matricule, u.name, c.title, en.status, en.due_date, en.attempts, en.best_pct, en.completed_at FROM $from ORDER BY c.title, u.name", $p); Audit::log('export', 'el_report', null, null, ['rows' => count($rows)]);
            csv_download('suivi_elearning.csv', ['Matricule', 'Nom', 'Cours', 'Statut', 'Échéance', 'Tentatives', 'Meilleur score %', 'Terminé le'], array_map(fn($r) => [$r['matricule'], $r['name'], $r['title'], ELearn::ES[$r['status']] ?? $r['status'], $r['due_date'], $r['attempts'], $r['best_pct'], $r['completed_at']], $rows));
        }
        $agg = DB::one("SELECT COUNT(*) n, SUM(CASE WHEN en.status='passed' THEN 1 ELSE 0 END) ok, SUM(CASE WHEN en.status='failed' THEN 1 ELSE 0 END) ko, AVG(CASE WHEN en.status='passed' THEN en.best_pct END) avg, SUM(CASE WHEN en.status IN ('assigned','in_progress') AND en.due_date IS NOT NULL AND en.due_date<? THEN 1 ELSE 0 END) late FROM $from", array_merge([date('Y-m-d')], $p));
        $pg = paginate($from, $p, $this->page(), 25, 'en.*, c.title, c.certificate, u.name uname, e.matricule', 'c.title, u.name');
        $this->view('elearn/report', ['title' => 'Suivi et résultats', 'p' => $pg, 'agg' => $agg, 'courses' => DB::all('SELECT id, title FROM el_courses ORDER BY title')]);
    }
}
