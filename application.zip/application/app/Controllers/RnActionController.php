<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Mailer, Notifier, Rn, Xchg};

/** Plans d'actions issus des réunions, et tableau de bord. */
class RnActionController extends Controller {
    private function meeting(int $id): ?array { $m = DB::one('SELECT * FROM rn_meetings WHERE id=?', [$id]); return $m && Rn::sees($m) ? $m : null; }
    private function action(string $aid): ?array {
        if (!Rn::on()) { $this->notFound(); return null; } $a = DB::one('SELECT * FROM rn_actions WHERE id=?', [(int)$aid]); $m = $a ? DB::one('SELECT * FROM rn_meetings WHERE id=?', [(int)$a['meeting_id']]) : null;
        if (!$a || !$m || !(Rn::sees($m) || (int)$a['owner_id'] === (int)Auth::id())) { $this->notFound(); return null; } return $a;
    }
    private function canEdit(array $a): bool { $m = DB::one('SELECT * FROM rn_meetings WHERE id=?', [(int)$a['meeting_id']]); return (bool)$m && (Rn::manages($m) || (int)$a['owner_id'] === (int)Auth::id()); }
    private function isMgr(array $a): bool { $m = DB::one('SELECT * FROM rn_meetings WHERE id=?', [(int)$a['meeting_id']]); return (bool)$m && Rn::manages($m); }
    private function tell(int $uid, string $title, string $body, string $url): void {
        if (!$uid || $uid === (int)Auth::id()) return; Notifier::send($uid, $title, mb_substr($body, 0, 400), $url);
        if (Xchg::on('rn.action_email') && ($em = DB::val("SELECT email FROM users WHERE id=? AND status='active'", [$uid]))) Mailer::queue($em, $title, $body . (Rn::abs(ltrim($url, '/')) ? "\n\n" . Rn::abs(ltrim($url, '/')) : ''));
    }
    private function log(int $aid, string $kind, string $comment, ?int $progress = null): void { DB::insert('rn_action_updates', ['action_id' => $aid, 'user_id' => Auth::id(), 'kind' => $kind, 'progress' => $progress, 'comment' => mb_substr($comment, 0, 500), 'created_at' => now()]); }
    function index(): void {
        if (!Rn::on()) { $this->notFound(); return; } $me = (int)Auth::id(); [$sc, $p] = Rn::scope('m'); $view = (string)($_GET['view'] ?? 'mine'); $w = [];
        if ($view === 'all' && (can('rn.all') || true)) { $w[] = "($sc OR a.owner_id=?)"; $p[] = $me; } else { $view = 'mine'; $w[] = 'a.owner_id=?'; $p = [$me]; }
        $st = (string)($_GET['status'] ?? 'open'); if ($st === 'open') { $w[] = "a.status IN ('open','in_progress','to_verify')"; } elseif (isset(Rn::ACT[$st])) { $w[] = 'a.status=?'; $p[] = $st; } else $st = 'any';
        if (($_GET['late'] ?? '') === '1') { $w[] = "a.status IN ('open','in_progress','to_verify') AND a.due_date<?"; $p[] = date('Y-m-d'); }
        if ((int)($_GET['meeting'] ?? 0)) { $w[] = 'a.meeting_id=?'; $p[] = (int)$_GET['meeting']; } if ((int)($_GET['owner'] ?? 0)) { $w[] = 'a.owner_id=?'; $p[] = (int)$_GET['owner']; }
        if (($q = trim((string)($_GET['q'] ?? ''))) !== '') { $w[] = '(a.title LIKE ? OR m.title LIKE ?)'; array_push($p, "%$q%", "%$q%"); }
        $from = 'rn_actions a JOIN rn_meetings m ON m.id=a.meeting_id LEFT JOIN users u ON u.id=a.owner_id WHERE ' . implode(' AND ', $w);
        if (($_GET['export'] ?? '') === 'csv') { $rows = array_map(fn($r) => [$r['ref'], $r['mtitle'], $r['title'], $r['owner'], $r['due_date'], Rn::ACT[$r['status']], $r['progress'] . '%', Rn::PRIO[$r['priority']], $r['done_at']], DB::all("SELECT a.*, m.ref, m.title mtitle, u.name owner FROM $from ORDER BY a.due_date", $p));
            csv_download('actions_reunions_' . date('Ymd_His') . '.csv', ['Réunion', 'Intitulé réunion', 'Action', 'Responsable', 'Échéance', 'Statut', 'Avancement', 'Priorité', 'Clôturée le'], $rows); }
        $pg = paginate($from, $p, $this->page(), 25, 'a.*, m.ref, m.title mtitle, u.name owner', 'a.due_date, a.id');
        $this->view('rn/actions', ['title' => 'Actions issues des réunions', 'p' => $pg, 'view' => $view, 'st' => $st, 'meetings' => DB::all("SELECT m.id, m.ref, m.title FROM rn_meetings m WHERE " . Rn::scope('m')[0] . ' ORDER BY m.start_at DESC LIMIT 200', Rn::scope('m')[1]), 'users' => DB::all("SELECT id, name FROM users WHERE status='active' ORDER BY name LIMIT 1000"),
            'sum' => ['late' => (int)DB::val("SELECT COUNT(*) FROM rn_actions WHERE owner_id=? AND status IN ('open','in_progress','to_verify') AND due_date<?", [$me, date('Y-m-d')]), 'open' => (int)DB::val("SELECT COUNT(*) FROM rn_actions WHERE owner_id=? AND status IN ('open','in_progress','to_verify')", [$me])]]);
    }
    function add(string $mid): void {
        if (!Rn::on()) { $this->notFound(); return; } $m = $this->meeting((int)$mid); if (!$m || !Rn::manages($m)) { $this->forbidden(); return; }
        $t = trim((string)$this->in('title')); $o = (int)$this->in('owner_id', 0); $due = (string)$this->in('due_date'); $pr = (string)$this->in('priority', 'normal'); $dec = (int)$this->in('decision_id', 0);
        if ($t === '' || mb_strlen($t) > 300 || !$o || !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$o]) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $due)) { flash('Action : intitulé, responsable et échéance obligatoires.', 'danger'); redirect('rn/' . $mid . '#actions'); }
        if (!isset(Rn::PRIO[$pr])) $pr = 'normal'; if ($dec && !DB::val('SELECT 1 FROM rn_decisions WHERE id=? AND meeting_id=?', [$dec, (int)$mid])) $dec = 0;
        $aid = DB::insert('rn_actions', ['meeting_id' => (int)$mid, 'decision_id' => $dec ?: null, 'title' => $t, 'description' => mb_substr(trim((string)$this->in('description')), 0, 1000) ?: null, 'owner_id' => $o, 'due_date' => $due, 'priority' => $pr, 'status' => 'open', 'progress' => 0, 'due_changes' => 0, 'created_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()]);
        $this->log((int)$aid, 'create', 'Action créée'); Rn::event((int)$mid, 'action', 'Action créée : ' . mb_substr($t, 0, 100) . ' → ' . DB::val('SELECT name FROM users WHERE id=?', [$o]));
        $this->tell($o, 'Nouvelle action · ' . $m['ref'], $t . ' — échéance ' . d($due) . ' (réunion : ' . $m['title'] . ')', '/rn/actions/' . $aid); Audit::log('create', 'rn_action', (string)$aid); flash('Action créée et responsable informé.'); redirect('rn/' . $mid . '#actions');
    }
    function show(string $aid): void {
        $a = $this->action($aid); if (!$a) return; $m = DB::one('SELECT * FROM rn_meetings WHERE id=?', [(int)$a['meeting_id']]);
        $this->view('rn/action', ['title' => 'Action · ' . $m['ref'], 'a' => $a, 'm' => $m, 'owner' => DB::val('SELECT name FROM users WHERE id=?', [(int)$a['owner_id']]), 'upd' => DB::all('SELECT x.*, u.name uname FROM rn_action_updates x LEFT JOIN users u ON u.id=x.user_id WHERE x.action_id=? ORDER BY x.id DESC', [(int)$aid]),
            'edit' => $this->canEdit($a), 'mgr' => $this->isMgr($a), 'dec' => $a['decision_id'] ? DB::val('SELECT text FROM rn_decisions WHERE id=?', [(int)$a['decision_id']]) : null, 'users' => DB::all("SELECT id, name FROM users WHERE status='active' ORDER BY name LIMIT 1000")]);
    }
    function update(string $aid): void {
        $a = $this->action($aid); if (!$a) return; if (!$this->canEdit($a)) { $this->forbidden(); return; } $mgr = $this->isMgr($a); $m = DB::one('SELECT * FROM rn_meetings WHERE id=?', [(int)$a['meeting_id']]); $act = (string)$this->in('act'); $c = trim((string)$this->in('comment')); $back = 'rn/actions/' . $aid; $url = '/rn/actions/' . $aid;
        $closed = in_array($a['status'], ['done', 'cancelled'], true); $me = (int)Auth::id();
        if ($closed && $act !== 'reopen') { flash('Action déjà close.', 'warning'); redirect($back); }
        switch ($act) {
            case 'progress':
                $pr = max(0, min(100, (int)$this->in('progress', (int)$a['progress']))); $st = $a['status'] === 'to_verify' ? 'to_verify' : ($pr > 0 ? 'in_progress' : 'open'); DB::update('rn_actions', ['progress' => $pr, 'status' => $st, 'updated_at' => now()], 'id=?', [(int)$aid]); $this->log((int)$aid, 'progress', $c, $pr); flash('Avancement enregistré.'); break;
            case 'due':
                $due = (string)$this->in('due_date'); if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $due) || $c === '') { flash('Nouvelle échéance et motif obligatoires.', 'danger'); break; }
                DB::update('rn_actions', ['due_date' => $due, 'due_changes' => (int)$a['due_changes'] + 1, 'reminded_at' => null, 'updated_at' => now()], 'id=?', [(int)$aid]); $this->log((int)$aid, 'due', 'Échéance ' . d($a['due_date']) . ' → ' . d($due) . ' : ' . $c); $this->tell((int)$m['organizer_id'], 'Échéance modifiée · ' . $m['ref'], $a['title'] . ' : ' . d($a['due_date']) . ' → ' . d($due) . ' (' . $c . ')', $url); flash('Échéance modifiée.'); break;
            case 'close':
                if ($mgr || Xchg::on('rn.action_owner_close')) { DB::update('rn_actions', ['status' => 'done', 'progress' => 100, 'done_at' => now(), 'closed_by' => $me, 'closure_comment' => mb_substr($c, 0, 500) ?: null, 'updated_at' => now()], 'id=?', [(int)$aid]); $this->log((int)$aid, 'close', $c ?: 'Action clôturée', 100); $this->tell((int)$m['organizer_id'], 'Action clôturée · ' . $m['ref'], $a['title'], $url); flash('Action clôturée.'); }
                else { DB::update('rn_actions', ['status' => 'to_verify', 'progress' => 100, 'updated_at' => now()], 'id=?', [(int)$aid]); $this->log((int)$aid, 'verify', $c ?: 'Soumise à vérification', 100); $this->tell((int)$m['organizer_id'], 'Action à vérifier · ' . $m['ref'], $a['title'] . ' — réalisée selon son responsable.', $url); flash('Action soumise à l\'organisateur pour clôture.'); } break;
            case 'reopen': if (!$mgr) { $this->forbidden(); return; } DB::update('rn_actions', ['status' => 'in_progress', 'done_at' => null, 'closed_by' => null, 'updated_at' => now()], 'id=?', [(int)$aid]); $this->log((int)$aid, 'reopen', $c ?: 'Action rouverte'); $this->tell((int)$a['owner_id'], 'Action rouverte · ' . $m['ref'], $a['title'], $url); flash('Action rouverte.'); break;
            case 'cancel': if (!$mgr) { $this->forbidden(); return; } if ($c === '') { flash('Motif obligatoire.', 'danger'); break; } DB::update('rn_actions', ['status' => 'cancelled', 'closed_by' => $me, 'closure_comment' => mb_substr($c, 0, 500), 'updated_at' => now()], 'id=?', [(int)$aid]); $this->log((int)$aid, 'cancel', $c); flash('Action abandonnée.'); break;
            case 'reassign': if (!$mgr) { $this->forbidden(); return; } $o = (int)$this->in('owner_id', 0); if (!$o || !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$o])) { flash('Responsable invalide.', 'danger'); break; }
                DB::update('rn_actions', ['owner_id' => $o, 'reminded_at' => null, 'updated_at' => now()], 'id=?', [(int)$aid]); $this->log((int)$aid, 'owner', 'Réaffectée à ' . DB::val('SELECT name FROM users WHERE id=?', [$o])); $this->tell($o, 'Action réaffectée · ' . $m['ref'], $a['title'] . ' — échéance ' . d($a['due_date']), $url); flash('Responsable modifié.'); break;
            default: flash('Opération inconnue.', 'danger');
        }
        Audit::log('update', 'rn_action', $aid, null, ['act' => $act]); redirect($back);
    }
    function dashboard(): void {
        if (!Rn::on()) { $this->notFound(); return; } [$sc, $p] = Rn::scope('m'); $w = [$sc]; $from = (string)($_GET['from'] ?? date('Y-m-d', strtotime('-90 days'))); $to = (string)($_GET['to'] ?? date('Y-m-d', strtotime('+30 days')));
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) $from = date('Y-m-d', strtotime('-90 days')); if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) $to = date('Y-m-d', strtotime('+30 days'));
        $w[] = 'm.start_at>=? AND m.start_at<=?'; array_push($p, $from . ' 00:00:00', $to . ' 23:59:59');
        if ((int)($_GET['organizer'] ?? 0)) { $w[] = 'm.organizer_id=?'; $p[] = (int)$_GET['organizer']; } if (($k = (string)($_GET['kind'] ?? '')) !== '') { $w[] = 'm.kind=?'; $p[] = $k; } if (isset(Rn::STATUS[(string)($_GET['status'] ?? '')])) { $w[] = 'm.status=?'; $p[] = $_GET['status']; }
        $all = DB::all('SELECT m.id, m.ref, m.title, m.start_at FROM rn_meetings m WHERE ' . implode(' AND ', $w) . ' ORDER BY m.start_at DESC LIMIT 500', $p); $allIds = array_map(fn($r) => (int)$r['id'], $all);
        $sel = array_values(array_intersect(array_map('intval', (array)($_GET['ids'] ?? [])), $allIds)); $ids = $sel ?: $allIds; $K = Rn::kpis($ids);
        if (($_GET['export'] ?? '') === 'csv') { csv_download('tableau_bord_reunions_' . date('Ymd_His') . '.csv', ['Réf.', 'Réunion', 'Date', 'Statut', 'Organisateur', 'Report(s)', 'Invités', 'Présents', 'Compte rendu', 'Délai diffusion (h)', 'Décisions', 'Actions', 'Clôturées', 'En retard'],
            array_map(fn($r) => [$r['m']['ref'], $r['m']['title'], $r['m']['start_at'], Rn::STATUS[$r['m']['status']], $r['m']['organizer'], $r['m']['postponed_count'], $r['inv'], $r['pre'], Rn::MIN[$r['m']['minutes_status']], $r['delay_h'] === null ? '' : round($r['delay_h'], 1), $r['dec'], $r['act'], $r['done'], $r['late']], $K['rows'])); }
        $this->view('rn/dashboard', ['title' => 'Tableau de bord des réunions', 'K' => $K, 'all' => $all, 'sel' => $sel, 'from' => $from, 'to' => $to, 'kinds' => Rn::kinds(), 'orgs' => DB::all('SELECT DISTINCT u.id, u.name FROM rn_meetings m JOIN users u ON u.id=m.organizer_id ORDER BY u.name'),
            'late' => DB::all("SELECT a.*, m.ref, m.title mtitle, u.name owner FROM rn_actions a JOIN rn_meetings m ON m.id=a.meeting_id LEFT JOIN users u ON u.id=a.owner_id WHERE a.meeting_id IN (" . ($ids ? implode(',', array_map('intval', $ids)) : '0') . ") AND a.status IN ('open','in_progress','to_verify') AND a.due_date<? ORDER BY a.due_date LIMIT 30", [date('Y-m-d')])]);
    }
}
