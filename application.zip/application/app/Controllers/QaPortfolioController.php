<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Scope, Notifier, Ca};
/** Portefeuilles : conseillers à évaluer par coach qualité sur une période, avec suivi réalisé / non réalisé. */
class QaPortfolioController extends Controller {
    const DONE = '(SELECT COUNT(*) FROM qa_evaluations v WHERE v.employee_id=p.employee_id AND v.evaluator_id=p.coach_user_id AND v.eval_date BETWEEN p.period_start AND p.period_end)';
    private const COLS = 'p.*, e.first_name, e.last_name, e.matricule, e.qa_ref, u.name coach_name, ' . self::DONE . ' done_n, (SELECT MAX(v.id) FROM qa_evaluations v WHERE v.employee_id=p.employee_id AND v.evaluator_id=p.coach_user_id AND v.eval_date BETWEEN p.period_start AND p.period_end) last_eval';
    private function range(): array {
        $f = $this->in('from') ?: date('Y-m-01'); $t = $this->in('to') ?: date('Y-m-t');
        return [preg_match('/^\d{4}-\d{2}-\d{2}$/', $f) ? $f : date('Y-m-01'), preg_match('/^\d{4}-\d{2}-\d{2}$/', $t) ? $t : date('Y-m-t')];
    }
    /** Mon portefeuille : mes conseillers à évaluer, réalisés / à faire. */
    function mine(): void {
        [$f, $t] = $this->range(); $state = $this->in('state');
        $w = ['p.coach_user_id=?', 'p.period_end>=?', 'p.period_start<=?']; $par = [Auth::id(), $f, $t];
        $rows = DB::all('SELECT ' . self::COLS . ' FROM qa_portfolios p JOIN employees e ON e.id=p.employee_id JOIN users u ON u.id=p.coach_user_id WHERE ' . implode(' AND ', $w) . ' ORDER BY e.last_name, e.first_name', $par);
        $all = $rows; if ($state === 'done') $rows = array_filter($rows, fn($r) => $r['done_n'] >= $r['target']); elseif ($state === 'todo') $rows = array_filter($rows, fn($r) => $r['done_n'] < $r['target']);
        $this->view('qa/portfolio_mine', ['title' => 'Mon portefeuille qualité', 'rows' => array_values($rows), 'total' => count($all), 'done' => count(array_filter($all, fn($r) => $r['done_n'] >= $r['target'])), 'from' => $f, 'to' => $t]);
    }
    function index(): void {
        [$f, $t] = $this->range(); [$sc, $sp] = Scope::sql('p.employee_id');
        $w = [$sc, 'p.period_end>=?', 'p.period_start<=?']; $par = array_merge($sp, [$f, $t]);
        if ($this->in('coach_id')) { $w[] = 'p.coach_user_id=?'; $par[] = (int)$this->in('coach_id'); }
        $state = $this->in('state'); if ($state === 'done') $w[] = self::DONE . ' >= p.target'; elseif ($state === 'todo') $w[] = self::DONE . ' < p.target';
        $from = 'qa_portfolios p JOIN employees e ON e.id=p.employee_id JOIN users u ON u.id=p.coach_user_id WHERE ' . implode(' AND ', $w);
        if ($this->in('export') === 'csv') {
            csv_download('portefeuilles-qualite.csv', ['Coach', 'Matricule', 'Conseiller', 'Réf. qualité', 'Du', 'Au', 'Objectif', 'Réalisées', 'Statut', 'Commentaire'],
                array_map(fn($r) => [$r['coach_name'], $r['matricule'], $r['last_name'] . ' ' . $r['first_name'], $r['qa_ref'], d($r['period_start']), d($r['period_end']), $r['target'], $r['done_n'], $r['done_n'] >= $r['target'] ? 'Réalisée' : 'Non réalisée', $r['comment']], DB::all('SELECT ' . self::COLS . " FROM $from ORDER BY u.name, e.last_name", $par)));
        }
        $this->view('qa/portfolios', ['title' => 'Portefeuilles des coachs', 'p' => paginate($from, $par, $this->page(), 30, self::COLS, 'u.name, e.last_name, e.first_name'), 'coaches' => Ca::usersWith('qa.evaluate'), 'employees' => Scope::employees(),
            'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'), 'from' => $f, 'to' => $t]);
    }
    function store(): void {
        $coach = (int)$this->in('coach_id'); $s = (string)$this->in('period_start'); $e = (string)$this->in('period_end'); $target = max(1, min(50, (int)$this->in('target', 1)));
        $ids = array_map('intval', (array)($_POST['employees'] ?? []));
        if ($tid = (int)$this->in('team_id')) { [$w, $p] = Scope::sql('id'); $ids = array_merge($ids, array_map('intval', array_column(DB::all("SELECT id FROM employees WHERE team_id=? AND status<>'left' AND $w", array_merge([$tid], $p)), 'id'))); }
        $ids = array_values(array_unique(array_filter($ids, fn($i) => $i > 0 && Scope::allows($i))));
        $okDate = fn($x) => preg_match('/^\d{4}-\d{2}-\d{2}$/', $x) && strtotime($x);
        if (!in_array($coach, array_map('intval', array_column(Ca::usersWith('qa.evaluate'), 'id')), true) || !$okDate($s) || !$okDate($e) || $e < $s || !$ids) { flash('Choisissez un coach, une période valide et au moins un conseiller (ou une équipe).', 'danger'); redirect('qa/portfolios'); }
        $n = 0; $comment = mb_substr(trim((string)$this->in('comment', '')), 0, 500) ?: null;
        foreach ($ids as $i) {
            if (DB::val('SELECT 1 FROM qa_portfolios WHERE coach_user_id=? AND employee_id=? AND period_start=? AND period_end=?', [$coach, $i, $s, $e])) continue;
            DB::insert('qa_portfolios', ['coach_user_id' => $coach, 'employee_id' => $i, 'period_start' => $s, 'period_end' => $e, 'target' => $target, 'comment' => null, 'created_by' => Auth::id(), 'created_at' => now()]); $n++;
        }
        if ($n && $coach !== (int)Auth::id()) Notifier::send($coach, 'Portefeuille qualité attribué', "$n conseiller(s) à évaluer du " . d($s) . ' au ' . d($e) . ($comment ? ' — ' . $comment : ''), '/qa/portfolio');
        Audit::log('create', 'qa_portfolio', null, null, ['coach' => $coach, 'employees' => $n, 'from' => $s, 'to' => $e]); flash("$n conseiller(s) ajouté(s) au portefeuille." . (count($ids) > $n ? ' Les doublons ont été ignorés.' : '')); redirect('qa/portfolios');
    }
    function comment(string $id): void {
        $p = DB::one('SELECT * FROM qa_portfolios WHERE id=?', [(int)$id]); if (!$p) { $this->notFound(); return; }
        if ((int)$p['coach_user_id'] !== (int)Auth::id() && !can('qa.manage')) { $this->forbidden(); return; }
        $c = mb_substr(trim((string)$this->in('comment', '')), 0, 500) ?: null; DB::update('qa_portfolios', ['comment' => $c], 'id=?', [(int)$id]); Audit::log('update', 'qa_portfolio', $id, ['comment' => $p['comment']], ['comment' => $c]);
        flash('Commentaire enregistré.'); redirect((int)$p['coach_user_id'] === (int)Auth::id() && !can('qa.manage') ? 'qa/portfolio' : ($this->in('back') === 'mine' ? 'qa/portfolio' : 'qa/portfolios'));
    }
    function delete(string $id): void {
        $p = DB::one('SELECT * FROM qa_portfolios WHERE id=?', [(int)$id]); if (!$p) { $this->notFound(); return; }
        DB::exec('DELETE FROM qa_portfolios WHERE id=?', [(int)$id]); Audit::log('delete', 'qa_portfolio', $id, $p); flash('Conseiller retiré du portefeuille.'); redirect('qa/portfolios');
    }
}
