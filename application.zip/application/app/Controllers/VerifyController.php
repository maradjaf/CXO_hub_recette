<?php
namespace App\Controllers;
use App\Core\{Controller, Cert};

/** Vérification publique (sans connexion) d'un document émis, par son code ou en scannant son QR code. */
class VerifyController extends Controller {
    function form(): void {
        $c = trim((string)$this->in('code', '')); if ($c !== '') redirect('verify/' . rawurlencode(strtoupper($c)));
        $this->view('verify/show', ['title' => 'Vérifier un document', 'r' => null, 'code' => '', 'searched' => false], 'layout/public');
    }
    function show(string $code): void {
        $r = Cert::lookup($code); if (!$r) http_response_code(404);
        $this->view('verify/show', ['title' => 'Vérification de document', 'r' => $r, 'code' => $code, 'searched' => true], 'layout/public');
    }
}
