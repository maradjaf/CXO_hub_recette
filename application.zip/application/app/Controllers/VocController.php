<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Voc};

/** Lot 59 — VOC & NPS : analyses NPS Consumer, CSAT Mixx, historique publié, projections, import des lots. */
class VocController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    private function g(string $k, string $d = ''): string { return isset($_GET[$k]) && is_string($_GET[$k]) ? trim($_GET[$k]) : $d; }
    private function arr(string $k): array { $v = $_GET[$k] ?? []; return is_array($v) ? array_values(array_unique(array_filter(array_map(fn($x) => is_string($x) ? $x : '', $v), fn($x) => $x !== ''))) : []; }
    private function dayOr(string $k, ?string $d): ?string { $v = $this->g($k); return Voc::isDay($v) ? $v : $d; }

    // ───────────────────────── NPS Consumer ─────────────────────────
    function nps(): void {
        $src = Voc::summary('nps'); $all = Voc::npsRows();
        $f = ['from' => $this->dayOr('from', $src['from']), 'to' => $this->dayOr('to', $src['to']), 'period' => isset(Voc::PERIOD_MODES[$this->g('period')]) ? $this->g('period') : 'week', 'periods' => $this->arr('periods'), 'baseline' => $this->g('baseline'),
            'brand' => $this->g('brand'), 'region' => $this->g('region'), 'band' => $this->g('band'), 'age' => $this->g('age'), 'drivers' => $this->arr('drivers'), 'sub' => $this->g('sub'), 'metric' => in_array($this->g('metric'), ['share', 'subgroup'], true) ? $this->g('metric') : 'contribution'];
        if (!$all) { $this->view('voc/empty', ['title' => 'NPS Consumer', 'what' => 'NPS Consumer']); return; }
        $periods = Voc::periods($f['from'], $f['to'], $f['period']); $f['periods'] = array_values(array_intersect($f['periods'], array_column($periods, 'id'))); $compare = Voc::pick($periods, $f['periods']);
        $auto = $f['baseline'] === 'available'; $baseIdx = -1;
        if (!$auto && $f['baseline'] !== 'none' && $compare) { $baseIdx = 0; foreach ($compare as $i => $p) if ($p['id'] === $f['baseline']) $baseIdx = $i; }
        $pidx = []; $idx = function (string $day) use (&$pidx, $compare) { if (!array_key_exists($day, $pidx)) { $pidx[$day] = -1; foreach ($compare as $i => $p) if ($day >= $p['from'] && $day <= $p['to']) { $pidx[$day] = $i; break; } } return $pidx[$day]; };
        $parent = array_values(array_filter($all, fn($r) => Voc::npsMatch($r, $f, false) && (!$f['periods'] || $idx($r['day']) >= 0)));
        $themes = Voc::names($parent, 'driver'); $f['drivers'] = array_values(array_intersect($f['drivers'], $themes));
        $subs = $f['drivers'] ? Voc::names(array_filter($parent, fn($r) => in_array($r['driver'], $f['drivers'], true)), 'sub') : []; if (!in_array($f['sub'], $subs, true)) $f['sub'] = '';
        $rows = array_values(array_filter($parent, fn($r) => Voc::npsMatch($r, $f)));
        $brands = $f['brand'] !== '' ? [$f['brand']] : ['YAS', 'MOOV'];
        // agrégats en une passe : par marque, par marque × période, par marque × driver, par marque × driver × période
        $z = fn() => ['det' => 0, 'pas' => 0, 'pro' => 0]; $add = function (array &$a, array $r) { $a['det'] += $r['det']; $a['pas'] += $r['pas']; $a['pro'] += $r['pro']; };
        $uni = []; $uniP = []; foreach ($parent as $r) { $b = $r['brand']; $uni[$b] ??= $z(); $add($uni[$b], $r); $i = $idx($r['day']); if ($i >= 0) { $uniP[$b][$i] ??= $z(); $add($uniP[$b][$i], $r); } }
        $tot = []; $totP = []; $drv = []; $drvP = []; foreach ($rows as $r) { $b = $r['brand']; $d = $r['driver']; $tot[$b] ??= $z(); $add($tot[$b], $r); $drv[$d][$b] ??= $z(); $add($drv[$d][$b], $r);
            $i = $idx($r['day']); if ($i >= 0) { $totP[$b][$i] ??= $z(); $add($totP[$b][$i], $r); $drvP[$d][$b][$i] ??= $z(); $add($drvP[$d][$b][$i], $r); } }
        $st = fn(?array $a) => Voc::npsStats($a ? [$a] : []);
        $kpis = []; foreach ($brands as $b) $kpis[$b] = $st($tot[$b] ?? null);
        $gap = null; if (count($brands) === 2 && $kpis['YAS']['n'] >= Voc::THRESHOLD && $kpis['MOOV']['n'] >= Voc::THRESHOLD) $gap = $kpis['YAS']['value'] - $kpis['MOOV']['value'];
        $lines = []; foreach ($brands as $k => $b) $lines[] = ['name' => Voc::brand($b), 'color' => Voc::BRAND_COLORS[$b] ?? Voc::PALETTE[$k % 5], 'points' => array_map(function ($i) use ($totP, $b, $st) { $s = $st($totP[$b][$i] ?? null); return $s['n'] ? ['n' => $s['n'], 'v' => $s['n'] >= Voc::THRESHOLD ? $s['value'] : null] : null; }, array_keys($compare))];
        $mval = function (array $s, array $total) use ($f) { if (!$s['n'] || !$total['n']) return null; return $f['metric'] === 'share' ? 100 * $s['n'] / $total['n'] : ($f['metric'] === 'subgroup' ? $s['value'] : 100 * $s['signed'] / $total['n']); };
        $drivers = $f['drivers'] ? array_values(array_intersect($themes, $f['drivers'])) : $themes;
        $dn = fn($d) => array_sum(array_map(fn($b) => $st($drv[$d][$b] ?? null)['n'], $brands)); usort($drivers, fn($a, $b) => $dn($b) <=> $dn($a) ?: strcmp($a, $b));
        $overview = []; foreach ($drivers as $d) { $c = []; foreach ($brands as $b) { $s = $st($drv[$d][$b] ?? null); $c[] = ['stat' => $s, 'value' => $mval($s, $st($uni[$b] ?? null))]; } $overview[] = ['driver' => $d, 'counts' => $c]; }
        $matrix = [];
        foreach ($drivers as $d) foreach ($brands as $b) {
            $res = []; foreach (array_keys($compare) as $i) { $s = $st($drvP[$d][$b][$i] ?? null); $res[] = ['stat' => $s, 'value' => $mval($s, $st($uniP[$b][$i] ?? null))]; }
            $ref = $baseIdx; if ($auto) { $ref = -1; foreach ($res as $i => $x) if ($x['stat']['n'] >= Voc::THRESHOLD) { $ref = $i; break; } }
            $refOk = $ref >= 0 && $res[$ref]['stat']['n'] >= Voc::THRESHOLD;
            foreach ($res as $i => &$x) $x['delta'] = ($i !== $ref && $refOk && $x['stat']['n'] >= Voc::THRESHOLD) ? $x['value'] - $res[$ref]['value'] : null; unset($x);
            $matrix[] = ['driver' => $d, 'brand' => $b, 'cells' => $res];
        }
        $mname = ['contribution' => 'Contribution au NPS', 'share' => 'Part des citations', 'subgroup' => 'NPS du sous-groupe'][$f['metric']];
        if ($this->g('export') === 'csv') {
            Audit::log('export', 'voc_nps', null, null, ['rows' => count($matrix)]);
            $out = [['Mesure', $mname], ['Source', $src['name']], ['Période sélectionnée', $f['from'], $f['to']], ['Région', $f['region'] ?: 'Toutes', 'Segment', $f['band'] ?: 'Tous', 'Âge', $f['age'] ?: 'Tous', 'Sous-driver', $f['sub'] ?: 'Tous'],
                array_merge(['Driver', 'Opérateur'], ...array_map(fn($p) => [$p['from'] . ' au ' . $p['to'], 'Base n', 'Écart vs référence'], $compare))];
            foreach ($matrix as $m) $out[] = array_merge([$m['driver'], Voc::brand($m['brand'])], ...array_map(fn($x) => [$x['stat']['n'] >= Voc::THRESHOLD ? round($x['value'], 2) : '', $x['stat']['n'], $x['delta'] === null ? '' : round($x['delta'], 2)], $m['cells']));
            Voc::csvOut('CXO_NPS_comparaison.csv', $out);
        }
        $this->view('voc/nps', ['title' => 'NPS Consumer', 'f' => $f, 'src' => $src, 'all' => $all, 'periods' => $periods, 'compare' => $compare, 'baseIdx' => $baseIdx, 'auto' => $auto, 'brands' => $brands, 'kpis' => $kpis, 'gap' => $gap, 'lines' => $lines,
            'themes' => Voc::names($all, 'driver'), 'subs' => $subs, 'overview' => $overview, 'matrix' => $matrix, 'mname' => $mname]);
    }

    // ───────────────────────── CSAT Mixx ─────────────────────────
    function csat(): void {
        $src = Voc::summary('csat'); $all = Voc::csatRows();
        $f = ['from' => $this->dayOr('from', $src['from']), 'to' => $this->dayOr('to', $src['to']), 'period' => isset(Voc::PERIOD_MODES[$this->g('period')]) ? $this->g('period') : 'week', 'periods' => $this->arr('periods'), 'baseline' => $this->g('baseline'),
            'channel' => $this->g('channel'), 'segment' => $this->g('segment'), 'dateMode' => $this->g('dateMode') === 'payment' ? 'payment' : 'response', 'metric' => $this->g('metric') === 'index' ? 'index' : 'top'];
        if (!$all) { $this->view('voc/empty', ['title' => 'CSAT Mixx', 'what' => 'CSAT Mixx']); return; }
        $periods = Voc::periods($f['from'], $f['to'], $f['period']); $f['periods'] = array_values(array_intersect($f['periods'], array_column($periods, 'id'))); $compare = Voc::pick($periods, $f['periods']);
        $baseIdx = $compare ? 0 : -1; foreach ($compare as $i => $p) if ($p['id'] === $f['baseline']) $baseIdx = $i;
        $dk = $f['dateMode'] === 'response' ? 'day' : 'pay_day';
        $rows = array_values(array_filter($all, fn($r) => $r[$dk] && $r[$dk] >= $f['from'] && $r[$dk] <= $f['to'] && ($f['channel'] === '' || $r['channel'] === $f['channel']) && ($f['segment'] === '' || $r['segment'] === $f['segment']) && (!$f['periods'] || Voc::inAny($r[$dk], $compare))));
        $byQ = [[], [], []]; foreach ($rows as $r) if (isset($byQ[$r['question']])) $byQ[$r['question']][] = $r;
        $stats = array_map(fn($q) => Voc::csatStats($q, $f['metric']), $byQ);
        $matrix = []; foreach (Voc::QUESTIONS as $i => $q) { $by = array_map(fn($p) => Voc::csatStats(array_filter($byQ[$i], fn($r) => Voc::inP($r[$dk], $p)), $f['metric']), $compare); $ref = $baseIdx >= 0 ? $by[$baseIdx] : null;
            $cells = []; foreach ($by as $k => $s) $cells[] = ['stat' => $s, 'delta' => ($k !== $baseIdx && $ref && $s['n'] >= Voc::THRESHOLD && $ref['n'] >= Voc::THRESHOLD) ? $s['value'] - $ref['value'] : null]; $matrix[] = ['question' => $q, 'cells' => $cells]; }
        $lines = []; foreach ($matrix as $i => $m) $lines[] = ['name' => $m['question'], 'color' => Voc::PALETTE[$i], 'points' => array_map(fn($c) => $c['stat']['n'] ? ['n' => $c['stat']['n'], 'v' => $c['stat']['n'] >= Voc::THRESHOLD ? $c['stat']['value'] : null] : null, $m['cells'])];
        $byChannel = []; foreach (Voc::names($rows, 'channel') as $ch) $byChannel[$ch] = array_map(fn($i) => Voc::csatStats(array_filter($byQ[$i], fn($r) => $r['channel'] === $ch), $f['metric']), [0, 1, 2]);
        $mname = $f['metric'] === 'top' ? 'Part des notes 4 et 5' : 'Indice normalisé Qualtrics';
        if ($this->g('export') === 'csv') {
            Audit::log('export', 'voc_csat', null, null, ['rows' => count($matrix)]);
            $out = [['Mesure', $mname], ['Source', $src['name']], ['Mode de date', $f['dateMode'] === 'response' ? 'Réponse' : 'Paiement'], ['Période sélectionnée', $f['from'], $f['to']], ['Canal', $f['channel'] ?: 'Tous', 'Segment', $f['segment'] ?: 'Tous'],
                array_merge(['Question'], ...array_map(fn($p) => [$p['from'] . ' au ' . $p['to'], 'Base n', 'Écart vs référence'], $compare))];
            foreach ($matrix as $m) $out[] = array_merge([$m['question']], ...array_map(fn($c) => [$c['stat']['n'] >= Voc::THRESHOLD ? round($c['stat']['value'], 2) : '', $c['stat']['n'], $c['delta'] === null ? '' : round($c['delta'], 2)], $m['cells']));
            Voc::csvOut('CXO_CSAT_comparaison.csv', $out);
        }
        $this->view('voc/csat', ['title' => 'CSAT Mixx', 'f' => $f, 'src' => $src, 'all' => $all, 'periods' => $periods, 'compare' => $compare, 'baseIdx' => $baseIdx, 'stats' => $stats, 'matrix' => $matrix, 'lines' => $lines, 'byChannel' => $byChannel, 'mname' => $mname]);
    }

    // ───────────────────────── Historique publié ─────────────────────────
    function history(): void {
        $rows = DB::all('SELECT * FROM vn_published ORDER BY period, method');
        $methods = Voc::uniq(array_column($rows, 'method')); $count = array_count_values(array_column($rows, 'method')); arsort($count);
        $method = in_array($this->g('meth'), $methods, true) ? $this->g('meth') : (array_key_first($count) ?? '');
        $serie = array_values(array_filter($rows, fn($r) => $r['method'] === $method));
        $period = $this->g('period'); if (!in_array($period, array_column($serie, 'period'), true)) $period = $serie ? end($serie)['period'] : '';
        $this->view('voc/history', ['title' => 'Historique NPS', 'rows' => $rows, 'methods' => $methods, 'method' => $method, 'serie' => $serie, 'period' => $period]);
    }
    function historySave(): void {
        if ($this->in('act') === 'delete') { DB::exec('DELETE FROM vn_published WHERE id=?', [(int)$this->in('id')]); $this->go('voc/history', 'Résultat publié retiré.'); }
        $period = trim((string)$this->in('period', '')); $method = mb_substr(trim((string)$this->in('meth', '')), 0, 80);
        $num = function (string $k, float $lo, float $hi) { $v = str_replace(',', '.', trim((string)$this->in($k, ''))); if ($v === '') return null; if (!is_numeric($v) || (float)$v < $lo || (float)$v > $hi) $this->go('voc/history', 'Valeur hors plage : ' . $k . '.', 'danger'); return (float)$v; };
        if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $period) || $method === '') $this->go('voc/history', 'Indiquez le mois (AAAA-MM) et la méthode.', 'danger');
        $d = ['period' => $period, 'method' => $method, 'yas' => $num('yas', -100, 100), 'moov' => $num('moov', -100, 100), 'yas_n' => ($x = $num('yas_n', 0, 10000000)) === null ? null : (int)$x, 'moov_n' => ($x = $num('moov_n', 0, 10000000)) === null ? null : (int)$x, 'source' => mb_substr(trim((string)$this->in('source', '')), 0, 200) ?: null];
        if ($d['yas'] === null && $d['moov'] === null) $this->go('voc/history', 'Saisissez au moins un score.', 'danger');
        if ($cur = DB::val('SELECT id FROM vn_published WHERE period=? AND method=?', [$period, $method])) DB::update('vn_published', $d, 'id=?', [(int)$cur]); else DB::insert('vn_published', $d + ['created_at' => now()]);
        Audit::log('update', 'vn_published', null, null, ['period' => $period, 'method' => $method]); $this->go('voc/history' . '?meth=' . rawurlencode($method) . '&period=' . $period, 'Résultat publié enregistré.');
    }

    // ───────────────────────── Projections ─────────────────────────
    function projection(): void {
        $rows = array_values(array_filter(Voc::npsRows(), fn($r) => $r['brand'] === 'YAS')); $themes = Voc::names($rows, 'driver');
        $num = function (string $k, float $def, float $lo, float $hi, bool $int = true) { $v = str_replace(',', '.', $this->g($k)); $v = is_numeric($v) ? (float)$v : $def; $v = min($hi, max($lo, $v)); return $int ? (int)round($v) : $v; };
        $drivers = isset($_GET['set']) ? array_values(array_intersect($this->arr('drivers'), $themes)) : array_values(array_intersect(['Consommation & Paiement'], $themes));
        $sel = array_filter($rows, fn($r) => !$drivers || in_array($r['driver'], $drivers, true)); $stats = Voc::npsStats($rows); $scope = Voc::npsStats($sel);
        $toPas = min($num('passive', 10, 0, 1e9), $scope['counts'][0]); $toPro = min($num('promoter', 0, 0, 1e9), $scope['counts'][0] - $toPas); $up = min($num('up', 0, 0, 1e9), $scope['counts'][1]);
        $change = $stats['n'] ? 100 * ($toPas + 2 * $toPro + $up) / $stats['n'] : 0;
        $target = $num('target', 45, -100, 100, false); $ct = $num('collectTarget', 1500, 1, 1000000); $cr = $num('collectRate', 27, .1, 100, false); $buf = $num('buffer', 10, 0, 100, false);
        $q = $num('question', 0, 0, 2); $cs = Voc::csatStats(array_filter(Voc::csatRows(), fn($r) => (int)$r['question'] === $q), 'top'); $csUp = (int)min($cs['n'] - $cs['numerator'], $num('csatUp', 10, 0, 1e9));
        $this->view('voc/projection', ['title' => 'Projections et scénarios', 'src' => Voc::summary('nps'), 'themes' => $themes, 'drivers' => $drivers, 'stats' => $stats, 'scope' => $scope, 'toPas' => $toPas, 'toPro' => $toPro, 'up' => $up, 'change' => $change,
            'simulated' => $stats['value'] === null ? null : $stats['value'] + $change, 'target' => $target, 'collectTarget' => $ct, 'collectRate' => $cr, 'buffer' => $buf, 'required' => (int)ceil($ct * (1 + $buf / 100) / ($cr / 100)), 'question' => $q, 'cs' => $cs, 'csUp' => $csUp,
            'csSim' => $cs['n'] ? 100 * ($cs['numerator'] + $csUp) / $cs['n'] : null]);
    }

    // ───────────────────────── Importations ─────────────────────────
    function import(): void {
        $type = $this->g('type') === 'csat' ? 'csat' : 'nps';
        $this->view('voc/import', ['title' => 'Importer des enquêtes', 'type' => $type, 'active' => Voc::batches($type), 'real' => DB::all('SELECT id, date_from, date_to, name FROM vn_batches WHERE type=? AND is_demo=0 ORDER BY date_from', [$type]),
            'hasDemo' => (bool)DB::val('SELECT 1 FROM vn_batches WHERE type=? AND is_demo=1', [$type])]);
    }
    /** Reçoit le lot agrégé dans le navigateur (lignes + contrôles), le vérifie et l'enregistre. Mêmes dates = révision ; chevauchement = refus. */
    function importStore(): void {
        $type = $this->in('type') === 'csat' ? 'csat' : 'nps'; $back = 'voc/import?type=' . $type;
        $data = json_decode((string)$this->in('payload', ''), true); if (!is_array($data) || !is_array($data['rows'] ?? null) || !is_array($data['summary'] ?? null)) $this->go($back, 'Lot illisible : vérifiez d\'abord la feuille.', 'danger');
        $rows = $data['rows']; $sum = $data['summary']; if (!$rows || count($rows) > 250000) $this->go($back, 'Le lot est vide ou trop volumineux.', 'danger');
        $clean = []; $min = null; $max = null; $s = fn($v, $n) => mb_substr(trim((string)$v), 0, $n) ?: Voc::UNKNOWN; $cnt = fn($v) => is_int($v) && $v >= 0 && $v < 100000000;
        foreach ($rows as $i => $r) {
            if (!is_array($r) || count($r) !== 10 || !Voc::isDay((string)$r[0])) $this->go($back, 'Ligne ' . ($i + 1) . ' du lot invalide.', 'danger');
            if ($type === 'nps') { if (!$cnt($r[7]) || !$cnt($r[8]) || !$cnt($r[9]) || trim((string)$r[1]) === '') $this->go($back, 'Ligne ' . ($i + 1) . ' du lot invalide.', 'danger');
                $clean[] = [$r[0], mb_substr(mb_strtoupper(trim((string)$r[1])), 0, 40), $s($r[2], 80), $s($r[3], 60), $s($r[4], 60), $s($r[5], 120), $s($r[6], 160), $r[7], $r[8], $r[9]]; }
            else { if (!is_int($r[4]) || $r[4] < 0 || $r[4] > 2 || !$cnt($r[5]) || !$cnt($r[6]) || !$cnt($r[7]) || !$cnt($r[8]) || !$cnt($r[9]) || ($r[1] !== '' && $r[1] !== null && !Voc::isDay((string)$r[1]))) $this->go($back, 'Ligne ' . ($i + 1) . ' du lot invalide.', 'danger');
                $clean[] = [$r[0], $r[1] ?: null, $s($r[2], 80), $s($r[3], 80), $r[4], $r[5], $r[6], $r[7], $r[8], $r[9]]; }
            $min = $min === null || $r[0] < $min ? $r[0] : $min; $max = $max === null || $r[0] > $max ? $r[0] : $max;
        }
        $from = Voc::isDay((string)($sum['from'] ?? '')) && $sum['from'] <= $min ? $sum['from'] : $min; $to = Voc::isDay((string)($sum['to'] ?? '')) && $sum['to'] >= $max ? $sum['to'] : $max;
        $same = DB::one('SELECT id FROM vn_batches WHERE type=? AND is_demo=0 AND date_from=? AND date_to=?', [$type, $from, $to]);
        if (!$same && DB::val('SELECT 1 FROM vn_batches WHERE type=? AND is_demo=0 AND date_from<=? AND date_to>=?', [$type, $to, $from])) $this->go($back, 'Ce lot chevauche une période déjà chargée. Utilisez les mêmes bornes pour créer une révision ou des périodes disjointes pour comparer plusieurs lots.', 'danger');
        $stats = []; foreach (['total', 'contacts', 'answered', 'valid', 'qualified', 'duplicateResponses', 'duplicates', 'invalidScore', 'rejected'] as $k) if (isset($sum[$k]) && is_int($sum[$k]) && $sum[$k] >= 0) $stats[$k] = $sum[$k];
        if ($type === 'csat' && is_array($sum['bases'] ?? null)) foreach ([0, 1, 2] as $k) if (is_int($sum['bases'][$k] ?? null)) $stats['base' . ($k + 1)] = $sum['bases'][$k];
        $pdo = DB::pdo(); $pdo->beginTransaction();
        try {
            if ($same) { DB::exec("DELETE FROM vn_$type WHERE batch_id=?", [(int)$same['id']]); DB::exec('DELETE FROM vn_batches WHERE id=?', [(int)$same['id']]); }
            $bid = DB::insert('vn_batches', ['type' => $type, 'name' => mb_substr(trim((string)($sum['name'] ?? 'Lot importé')), 0, 190) ?: 'Lot importé', 'sheet' => mb_substr(trim((string)($sum['sheet'] ?? '')), 0, 100) ?: null, 'date_from' => $from, 'date_to' => $to, 'total' => (int)($stats['total'] ?? count($clean)), 'stats' => json_encode($stats), 'is_demo' => 0, 'user_id' => Auth::id(), 'created_at' => now()]);
            $sql = $type === 'nps' ? 'INSERT INTO vn_nps (batch_id, day, brand, region, band, age, driver, sub, det, pas, pro) VALUES (?,?,?,?,?,?,?,?,?,?,?)' : 'INSERT INTO vn_csat (batch_id, day, pay_day, channel, segment, question, n1, n2, n3, n4, n5) VALUES (?,?,?,?,?,?,?,?,?,?,?)';
            $st = $pdo->prepare($sql); foreach ($clean as $r) $st->execute(array_merge([$bid], $r));
            $pdo->commit();
        } catch (\Throwable $e) { $pdo->rollBack(); $this->go($back, 'Enregistrement du lot impossible.', 'danger'); }
        Audit::log('import', 'vn_batch', $bid, null, ['type' => $type, 'rows' => count($clean), 'from' => $from, 'to' => $to]); Voc::flush();
        $this->go('voc/' . $type, ($same ? 'Lot remplacé.' : 'Lot chargé.') . ' Les indicateurs ont été recalculés.');
    }
    function importDelete(): void {
        $type = $this->in('type') === 'csat' ? 'csat' : 'nps'; $id = (int)$this->in('id');
        $ids = $id ? array_column(DB::all('SELECT id FROM vn_batches WHERE id=? AND type=? AND is_demo=0', [$id, $type]), 'id') : array_column(DB::all('SELECT id FROM vn_batches WHERE type=? AND is_demo=0', [$type]), 'id');
        foreach ($ids as $b) { DB::exec("DELETE FROM vn_$type WHERE batch_id=?", [(int)$b]); DB::exec('DELETE FROM vn_batches WHERE id=?', [(int)$b]); }
        if ($ids) Audit::log('delete', 'vn_batch', null, null, ['type' => $type, 'batches' => count($ids)]); Voc::flush();
        $this->go('voc/import?type=' . $type, $ids ? ($id ? 'Lot retiré.' : 'Lots importés retirés.') : 'Aucun lot à retirer.', $ids ? 'success' : 'warning');
    }
    /** Charge ou retire les données d'exemple reprises de la maquette (lots d'octobre 2026, focus group de mars 2026, séries de démonstration). */
    function demo(): void {
        if ($this->in('act') === 'remove') { \App\Core\VocDemo::remove(); Audit::log('delete', 'voc_demo', null, null, []); $this->go('voc/import', 'Données d\'exemple retirées.'); }
        $ok = \App\Core\VocDemo::load(); if ($ok) Audit::log('create', 'voc_demo', null, null, []); $this->go('voc', $ok ? 'Données d\'exemple chargées.' : 'Les données d\'exemple sont déjà présentes.', $ok ? 'success' : 'warning');
    }
}
