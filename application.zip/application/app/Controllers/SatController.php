<?php
namespace App\Controllers;

use App\Core\{Audit, Auth, Controller, DB, Sat};

/** Enquête de satisfaction demandée à la fin de chaque cours e-learning. */
final class SatController extends Controller {
    private function ctx(string $eid): ?array {
        $e = DB::one('SELECT en.*, c.title FROM el_enrollments en JOIN el_courses c ON c.id=en.course_id WHERE en.id=?', [(int)$eid]);
        if (!$e || (int)$e['user_id'] !== Auth::id()) { $this->notFound(); return null; }
        $sv = DB::one('SELECT * FROM el_surveys WHERE enrollment_id=?', [(int)$eid]);
        if (!$sv) { if (!in_array($e['status'], ['passed', 'failed'], true)) { flash('L\'enquête est proposée à la fin du cours.', 'info'); redirect('learn/' . $eid); } Sat::requestCourse((int)$eid); $sv = DB::one('SELECT * FROM el_surveys WHERE enrollment_id=?', [(int)$eid]); }
        return ['e' => $e, 'sv' => $sv, 'qs' => DB::all('SELECT * FROM tr_eval_questions WHERE form_id=? ORDER BY position', [(int)$sv['form_id']])];
    }
    function show(string $eid): void {
        if (!($c = $this->ctx($eid))) return;
        $this->view('learn/survey', $c + ['title' => 'Votre avis : ' . $c['e']['title'], 'done' => $c['sv']['status'] === 'done', 'old' => json_decode((string)$c['sv']['answers'], true) ?: []]);
    }
    function submit(string $eid): void {
        if (!($c = $this->ctx($eid))) return;
        if ($c['sv']['status'] === 'done') { flash('Vous avez déjà répondu. Merci !', 'info'); redirect('learn'); }
        $ans = []; $err = []; $sum = 0; $n = 0;
        foreach ($c['qs'] as $q) { $v = trim((string)($_POST['q'][$q['id']] ?? ''));
            if ($v === '') { if ($q['required']) $err['q' . $q['id']] = 'Réponse obligatoire : ' . mb_substr($q['label'], 0, 60); continue; }
            if ($q['qtype'] === 'rating') { $i = (int)$v; if ($i < 1 || $i > 5) { $err['q' . $q['id']] = 'Note invalide.'; continue; } $ans[$q['id']] = $i; $sum += $i; $n++; }
            elseif ($q['qtype'] === 'yesno') $ans[$q['id']] = $v === 'yes' ? 'yes' : 'no'; else $ans[$q['id']] = mb_substr($v, 0, 1000); }
        if ($err) { $_SESSION['_old'] = $_POST; $_SESSION['_ferr'] = $err; flash(implode(' ', array_slice($err, 0, 3)), 'danger'); redirect('learn/' . $eid . '/survey'); }
        DB::update('el_surveys', ['status' => 'done', 'avg' => $n ? round($sum / $n, 2) : null, 'answers' => json_encode($ans, JSON_UNESCAPED_UNICODE), 'comment' => mb_substr(trim((string)($_POST['comment'] ?? '')), 0, 1500) ?: null, 'submitted_at' => now()], 'id=?', [(int)$c['sv']['id']]);
        Audit::log('survey', 'el_survey', $c['sv']['id'], null, ['course' => $c['e']['title']]); flash('Merci, votre avis est enregistré.'); redirect('learn');
    }
}
