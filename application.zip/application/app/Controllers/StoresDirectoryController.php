<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Stores};
/** Annuaire des stores pour tout le personnel : coordonnées, GPS et message prêt à envoyer au client. */
class StoresDirectoryController extends Controller {
    private function where(): array {
        $w = ['s.active=1']; $p = [];
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(s.name LIKE ? OR s.code LIKE ? OR s.city LIKE ? OR s.locality LIKE ? OR s.address LIKE ? OR s.situation LIKE ?)'; array_push($p, ...array_fill(0, 6, "%$q%")); }
        if ($this->in('zone_id')) { $w[] = 's.zone_id=?'; $p[] = (int)$this->in('zone_id'); }
        if ($this->in('city')) { $w[] = 's.city=?'; $p[] = $this->in('city'); }
        if ($this->in('gps') === 'yes') $w[] = "s.gps_lat IS NOT NULL AND s.gps_lat<>''"; elseif ($this->in('gps') === 'no') $w[] = "(s.gps_lat IS NULL OR s.gps_lat='')";
        return [implode(' AND ', $w), $p];
    }
    function index(): void {
        [$w, $p] = $this->where();
        $pg = paginate("stores s LEFT JOIN zones z ON z.id=s.zone_id WHERE $w", $p, $this->page(), 25, 's.*, z.name zone_name', 's.name');
        foreach ($pg['rows'] as &$r) { $r['msg'] = Stores::message($r); $r['map'] = Stores::mapUrl($r); } unset($r);
        $this->view('stores/directory', ['title' => 'Annuaire des stores', 'p' => $pg, 'zones' => DB::all('SELECT id, name FROM zones WHERE active=1 ORDER BY name'), 'cities' => array_column(DB::all("SELECT DISTINCT city FROM stores WHERE city IS NOT NULL AND city<>'' ORDER BY city"), 'city')]);
    }
    function export(): void {
        [$w, $p] = $this->where();
        $rows = DB::all("SELECT s.code, s.name, s.city, s.locality, z.name zone, s.address, s.situation, s.phone, s.phone2, s.email, s.hours, s.gps_lat, s.gps_lng FROM stores s LEFT JOIN zones z ON z.id=s.zone_id WHERE $w ORDER BY s.name LIMIT 5000", $p);
        csv_download('stores_' . date('Ymd') . '.csv', ['Code', 'Store', 'Ville', 'Localité', 'Zone', 'Adresse', 'Situation géographique', 'Téléphone', 'Téléphone 2', 'E-mail', 'Horaires', 'Latitude', 'Longitude'], $rows);
    }
}
