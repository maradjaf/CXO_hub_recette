<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Chat, Xchg};

/** Chat in-app d'un incident ou d'un ticket (échange par interrogation régulière, sans service temps réel à installer). */
class ChatController extends Controller {
    private function json($d, int $code = 200): never { http_response_code($code); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store'); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
    private function gate(string $module, string $id): int {
        if (!Chat::enabled($module) || !MeetingsController::access($module, (int)$id)) $this->json(['error' => 'Chat indisponible.'], 404); return (int)$id;
    }
    private function shape(array $m, string $module): array {
        $me = (int)Auth::id(); $mgr = Chat::isManager($module); $own = (int)$m['user_id'] === $me; $age = (time() - strtotime($m['created_at'])) / 60; $del = !empty($m['deleted_at']);
        $win = $age <= Xchg::int('chat.edit_min', 0, 1440);
        return ['id' => (int)$m['id'], 'user' => $m['user_name'] ?: 'Utilisateur', 'mine' => $own, 'body' => $del ? '' : $m['body'], 'deleted' => $del, 'internal' => (bool)$m['internal'], 'edited' => !empty($m['edited_at']), 'at' => date('d/m H:i', strtotime($m['created_at'])), 'can_edit' => $own && $win && !$del, 'can_del' => !$del && (($own && $win) || $mgr)];
    }
    function poll(string $module, string $id): void {
        $rid = $this->gate($module, $id); $after = max(0, (int)($_GET['after'] ?? 0)); $mgr = Chat::isManager($module);
        $sql = 'SELECT * FROM chat_messages WHERE module=? AND ref_id=? AND id>?' . ($mgr ? '' : ' AND internal=0') . ' ORDER BY id'; $rows = DB::all($sql, [$module, $rid, $after]);
        if ($after === 0 && count($rows) > 150) $rows = array_slice($rows, -150);
        // modifications / suppressions de messages déjà reçus
        $upd = []; if ($after > 0) { $since = date('Y-m-d H:i:s', time() - 3600); foreach (DB::all('SELECT * FROM chat_messages WHERE module=? AND ref_id=? AND id<=? AND (edited_at>=? OR deleted_at>=?)' . ($mgr ? '' : ' AND internal=0'), [$module, $rid, $after, $since, $since]) as $m) $upd[] = $this->shape($m, $module); }
        $this->json(['messages' => array_map(fn($m) => $this->shape($m, $module), $rows), 'updated' => $upd, 'can_write' => Chat::canWrite($module), 'poll' => Xchg::int('chat.poll_sec', 2, 120)]);
    }
    function post(string $module, string $id): void {
        $rid = $this->gate($module, $id); if (!Chat::canWrite($module)) $this->json(['error' => 'Écriture non autorisée.'], 403);
        $body = trim((string)$this->in('body')); $max = Xchg::int('chat.max_len', 50, 2000);
        if ($body === '') $this->json(['error' => 'Message vide.'], 422); if (mb_strlen($body) > $max) $this->json(['error' => "Message trop long ($max caractères maximum)."], 422);
        $me = (int)Auth::id(); if ((int)DB::val('SELECT COUNT(*) FROM chat_messages WHERE user_id=? AND created_at>=?', [$me, date('Y-m-d H:i:s', time() - 60)]) >= Xchg::int('chat.rate_per_min', 1, 600)) $this->json(['error' => 'Trop de messages : patientez une minute.'], 429);
        $internal = Chat::isManager($module) && Xchg::on('chat.internal') && (string)$this->in('internal') === '1'; $name = (string)DB::val('SELECT name FROM users WHERE id=?', [$me]);
        $mid = DB::insert('chat_messages', ['module' => $module, 'ref_id' => $rid, 'user_id' => $me, 'user_name' => $name, 'body' => $body, 'internal' => $internal ? 1 : 0, 'created_at' => now()]);
        if ($module === 'el') DB::update('el_threads', ['last_at' => now(), 'status' => Chat::isManager('el') ? 'answered' : 'open'], 'id=?', [$rid]);
        Chat::notify($module, $rid, $me, $name, $body, $internal);
        $this->json(['ok' => true, 'id' => (int)$mid]);
    }
    private function msg(string $mid): array {
        $m = DB::one('SELECT * FROM chat_messages WHERE id=?', [(int)$mid]); if (!$m) $this->json(['error' => 'Introuvable.'], 404); $this->gate($m['module'], (string)$m['ref_id']);
        if ($m['internal'] && !Chat::isManager($m['module'])) $this->json(['error' => 'Introuvable.'], 404); return $m;
    }
    function edit(string $mid): void {
        $m = $this->msg($mid); $s = $this->shape($m, $m['module']); if (!$s['can_edit']) $this->json(['error' => 'Modification impossible (délai dépassé).'], 403);
        $body = trim((string)$this->in('body')); if ($body === '' || mb_strlen($body) > Xchg::int('chat.max_len', 50, 2000)) $this->json(['error' => 'Texte invalide.'], 422);
        DB::update('chat_messages', ['body' => $body, 'edited_at' => now()], 'id=?', [(int)$mid]); $this->json(['ok' => true]);
    }
    function delete(string $mid): void {
        $m = $this->msg($mid); $s = $this->shape($m, $m['module']); if (!$s['can_del']) $this->json(['error' => 'Suppression impossible.'], 403);
        DB::update('chat_messages', ['deleted_at' => now()], 'id=?', [(int)$mid]); if (!$s['mine']) Audit::log('delete', 'chat_message', $mid, null, ['module' => $m['module'], 'ref' => $m['ref_id']]); $this->json(['ok' => true]);
    }
}
