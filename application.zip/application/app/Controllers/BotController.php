<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Auth, Bot, Audit};
/** Assistant conversationnel : réponses sourcées à partir des contenus lisibles par l'utilisateur. */
class BotController extends Controller {
    private function conv(string $id): ?array { $c = DB::one('SELECT * FROM bot_conversations WHERE id=? AND user_id=?', [(int)$id, Auth::id()]); if (!$c) $this->notFound(); return $c; }
    function index(): void {
        $uid = Auth::id(); $list = DB::all('SELECT id, title, updated_at FROM bot_conversations WHERE user_id=? ORDER BY updated_at DESC, id DESC LIMIT 30', [$uid]);
        $cid = (int)$this->in('c', 0); $cur = null; $msgs = [];
        if ($cid) { $cur = DB::one('SELECT * FROM bot_conversations WHERE id=? AND user_id=?', [$cid, $uid]); if (!$cur) { $this->notFound(); return; } $msgs = DB::all('SELECT * FROM bot_messages WHERE conversation_id=? ORDER BY id', [$cid]); }
        $this->view('bot/index', ['title' => 'Assistant', 'list' => $list, 'cur' => $cur, 'msgs' => $msgs, 'llm' => Bot::llmEnabled(), 'images' => Bot::imagesEnabled(), 'ticket' => can('at.request'), 'kbAsk' => can('kb.read')]);
    }
    private function botJson(array $d): never { header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store'); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
    function send(): void {
        $uid = Auth::id(); $q = trim((string)$this->in('q', '')); $cid = (int)$this->in('c', 0); $t0 = microtime(true);
        $hasImg = isset($_FILES['img']) && ($_FILES['img']['error'] ?? 4) !== UPLOAD_ERR_NO_FILE; $back = $cid ? "bot?c=$cid" : 'bot'; $ajax = (string)$this->in('ajax', '') === '1';
        $fail = function (string $m, string $t) use ($ajax, $back): void { if ($ajax) $this->botJson(['ok' => false, 'error' => $m]); flash($m, $t); redirect($back); };
        if ($hasImg && !Bot::imagesEnabled()) { $fail('L\'analyse d\'image n\'est pas activée.', 'warning'); }
        if (($q === '' && !$hasImg) || mb_strlen($q) > 500) { $fail('Posez une question de 1 à 500 caractères.', 'danger'); }
        $rate = max(1, (int)setting('bot.rate_per_hour', 30));
        if ((int)DB::val("SELECT COUNT(*) FROM bot_messages m JOIN bot_conversations c ON c.id=m.conversation_id WHERE c.user_id=? AND m.role='user' AND m.created_at>=?", [$uid, date('Y-m-d H:i:s', time() - 3600)]) >= $rate) { $fail("Limite atteinte ($rate questions par heure). Réessayez plus tard.", 'warning'); }
        $img = null;
        if ($hasImg) {
            $per = max(1, (int)setting('bot.images_per_day', 20));
            if ((int)DB::val("SELECT COUNT(*) FROM bot_messages m JOIN bot_conversations c ON c.id=m.conversation_id WHERE c.user_id=? AND m.img_file IS NOT NULL AND m.created_at>=?", [$uid, date('Y-m-d H:i:s', time() - 86400)]) >= $per) { $fail("Limite atteinte ($per images par jour).", 'warning'); }
            [$img, $err] = Bot::storeImage($_FILES['img']); if (!$img) { $fail($err, 'danger'); }
        }
        if ($cid) { if (!DB::val('SELECT 1 FROM bot_conversations WHERE id=? AND user_id=?', [$cid, $uid])) { if ($ajax) $this->botJson(['ok' => false, 'error' => 'Conversation introuvable.']); $this->notFound(); return; } }
        else $cid = DB::insert('bot_conversations', ['user_id' => $uid, 'title' => mb_substr($q !== '' ? $q : 'Image', 0, 100), 'created_at' => now(), 'updated_at' => now()]);
        $history = array_reverse(DB::all('SELECT role, content FROM bot_messages WHERE conversation_id=? ORDER BY id DESC LIMIT 4', [$cid]));
        $tin = 0; $tout = 0; $llmErr = 0; $vis = null; $imgDesc = null; $question = $q !== '' ? $q : 'Que montre cette image et que dois-je faire ?';
        if ($img) { $vis = Bot::vision($img[0], $img[1], $question); if ($vis) { $tin += $vis['in']; $tout += $vis['out']; $imgDesc = $vis['desc'] ?: null; } else $llmErr = 1; }
        $search = $q . ($vis ? ' ' . implode(' ', $vis['kw']) . ' ' . $vis['text'] : '');
        $only = isset($_POST['src']) ? array_values(array_map('strval', (array)$_POST['src'])) : null; $r = Bot::retrieve($search, $uid, 4, $only); $mode = 'retrieval'; $src = Bot::sources($r['hits']); $imgCtx = $vis ? trim($vis['desc'] . ($vis['text'] !== '' ? "\nTexte visible : " . $vis['text'] : '')) : '';
        if (!Bot::tokens($search)) { $mode = 'help'; $found = 1; $text = $img && !$vis ? "Je n'ai pas pu analyser l'image. Décrivez le problème par écrit et je chercherai." : "Bonjour, je suis l'assistant virtuel. En quoi puis je vous aider aujourd'hui ?\n\nPosez-moi une question précise (par exemple « comment réinitialiser un mot de passe ? » ou « quelles sont les étapes du processus de remboursement ? »). Je cherche dans la base de connaissances, les processus et vos cours. Si l'analyse d'image est activée, vous pouvez aussi joindre une capture d'écran."; }
        elseif (!$r['found']) { $mode = 'none'; $found = 0; $text = ($imgCtx !== '' ? "J'ai analysé l'image : " . $vis['desc'] . "\n\n" : ($img ? "Je n'ai pas pu analyser l'image.\n\n" : '')) . "Je n'ai rien trouvé de fiable à ce sujet dans les contenus auxquels vous avez accès. Essayez avec d'autres mots, ou posez la question à l'équipe."; }
        else {
            $found = 1; $ans = Bot::llmEnabled() ? Bot::llm($question, $r['hits'], $history, $imgCtx) : null;
            if ($ans !== null) { $mode = 'llm'; $text = $ans['text']; $tin += $ans['in']; $tout += $ans['out']; } else { $text = ($imgCtx !== '' ? "Analyse de l'image : " . $vis['desc'] . "\n\n" : '') . Bot::extractive($r['hits']); if (Bot::llmEnabled()) $llmErr = 1; }
        }
        $now = now(); $ms = (int)round((microtime(true) - $t0) * 1000);
        DB::insert('bot_messages', ['conversation_id' => $cid, 'role' => 'user', 'content' => $q !== '' ? $q : '(image)', 'mode' => $mode, 'found' => $found, 'img_file' => $img[0] ?? null, 'img_mime' => $img[1] ?? null, 'img_desc' => $imgDesc, 'created_at' => $now]);
        $mid = DB::insert('bot_messages', ['conversation_id' => $cid, 'role' => 'assistant', 'content' => $text, 'sources' => $src ? json_encode($src, JSON_UNESCAPED_UNICODE) : null, 'mode' => $mode, 'found' => $found, 'tok_in' => $tin ?: null, 'tok_out' => $tout ?: null, 'ms' => $ms, 'llm_err' => $llmErr, 'top_src' => $src[0]['type'] ?? null, 'created_at' => now()]);
        DB::update('bot_conversations', ['updated_at' => now()], 'id=?', [$cid]);
        if ($ajax) $this->botJson(['ok' => true, 'c' => $cid, 'm' => (int)$mid, 'text' => $text, 'mode' => $mode, 'sources' => array_map(fn($x) => ['title' => $x['title'], 'url' => url($x['url']), 'type' => Bot::TYPES[$x['type']] ?? ''], $src), 'ticket' => $mode === 'none' && can('at.request') ? url('at/new?channel=chatbot') : null, 'kb' => $mode === 'none' && can('kb.read') ? url('kb') : null]);
        redirect("bot?c=$cid");
    }
    function image(string $id): void {
        $m = DB::one("SELECT m.img_file, m.img_mime FROM bot_messages m JOIN bot_conversations c ON c.id=m.conversation_id WHERE m.id=? AND c.user_id=? AND m.img_file IS NOT NULL", [(int)$id, Auth::id()]);
        $f = $m ? Bot::imgDir() . '/' . basename($m['img_file']) : ''; if (!$m || !is_file($f) || !in_array($m['img_mime'], ['image/jpeg', 'image/png', 'image/webp', 'image/gif'], true)) { $this->notFound(); return; }
        header('Content-Type: ' . $m['img_mime']); header('X-Content-Type-Options: nosniff'); header("Content-Security-Policy: sandbox; default-src 'none'"); header('Cache-Control: private, max-age=3600'); header('Content-Length: ' . filesize($f)); readfile($f); exit;
    }
    function feedback(string $id): void {
        $m = DB::one("SELECT m.id, m.conversation_id FROM bot_messages m JOIN bot_conversations c ON c.id=m.conversation_id WHERE m.id=? AND c.user_id=? AND m.role='assistant'", [(int)$id, Auth::id()]); if (!$m) { $this->notFound(); return; }
        $v = (string)$this->in('v') === 'up' ? 1 : -1; DB::update('bot_messages', ['feedback' => $v], 'id=?', [(int)$id]); redirect('bot?c=' . $m['conversation_id']);
    }
    function delete(string $id): void { if (!$this->conv($id)) return; foreach (DB::all('SELECT img_file FROM bot_messages WHERE conversation_id=? AND img_file IS NOT NULL', [(int)$id]) as $x) @unlink(Bot::imgDir() . '/' . basename($x['img_file'])); DB::exec('DELETE FROM bot_messages WHERE conversation_id=?', [(int)$id]); DB::exec('DELETE FROM bot_conversations WHERE id=?', [(int)$id]); flash('Conversation supprimée.'); redirect('bot'); }
    function gaps(): void {
        $since = date('Y-m-d H:i:s', strtotime('-30 days')); $a = fn($w) => (int)DB::val("SELECT COUNT(*) FROM bot_messages WHERE role='assistant' AND mode<>'help' AND created_at>=? $w", [$since]);
        $this->view('bot/gaps', ['title' => 'Questions sans réponse', 'tot' => $a(''), 'found' => $a('AND found=1'), 'llm' => $a("AND mode='llm'"), 'up' => $a('AND feedback=1'), 'down' => $a('AND feedback=-1'),
            'gaps' => DB::all("SELECT LOWER(content) q, COUNT(*) n, MAX(created_at) last, MAX(SUBSTR(img_desc,1,150)) d FROM bot_messages WHERE role='user' AND found=0 AND mode='none' AND created_at>=? GROUP BY LOWER(content) ORDER BY n DESC, last DESC LIMIT 40", [date('Y-m-d H:i:s', strtotime('-60 days'))]),
            'bad' => DB::all("SELECT m.created_at, (SELECT q.content FROM bot_messages q WHERE q.conversation_id=m.conversation_id AND q.role='user' AND q.id<m.id ORDER BY q.id DESC LIMIT 1) q, m.sources FROM bot_messages m WHERE m.role='assistant' AND m.feedback=-1 ORDER BY m.id DESC LIMIT 15")]);
    }
    function forward(): void {
        $t = mb_substr(trim((string)$this->in('q', '')), 0, 500); if ($t === '') { redirect('bot/gaps'); }
        if (!DB::val("SELECT 1 FROM kb_questions WHERE text=? AND status='open'", [$t])) DB::insert('kb_questions', ['user_id' => Auth::id(), 'text' => $t, 'status' => 'open', 'created_at' => now()]);
        Audit::log('forward', 'bot_gap'); flash('Question transmise à l\'équipe de la base de connaissances.'); redirect('bot/gaps');
    }

    // ---- Statistiques (administration) ----
    private function period(): array { $d = (int)$this->in('days', 30); if (!in_array($d, [7, 30, 90], true)) $d = 30; return [$d, date('Y-m-d 00:00:00', strtotime('-' . ($d - 1) . ' days'))]; }
    private function daily(string $since): array {
        $rows = []; foreach (DB::all("SELECT SUBSTR(m.created_at,1,10) d, SUM(CASE WHEN m.role='assistant' AND m.mode<>'help' THEN 1 ELSE 0 END) q, SUM(CASE WHEN m.role='assistant' AND m.mode<>'help' AND m.found=1 THEN 1 ELSE 0 END) f, SUM(CASE WHEN m.role='assistant' AND m.mode='llm' THEN 1 ELSE 0 END) ia, SUM(CASE WHEN m.role='user' AND m.img_file IS NOT NULL THEN 1 ELSE 0 END) img, COALESCE(SUM(m.tok_in),0) ti, COALESCE(SUM(m.tok_out),0) tout FROM bot_messages m WHERE m.created_at>=? GROUP BY SUBSTR(m.created_at,1,10)", [$since]) as $r) $rows[$r['d']] = $r;
        $out = []; for ($t = strtotime($since); $t <= time(); $t += 86400) { $d = date('Y-m-d', $t); $r = $rows[$d] ?? []; $out[] = ['d' => $d, 'q' => (int)($r['q'] ?? 0), 'f' => (int)($r['f'] ?? 0), 'ia' => (int)($r['ia'] ?? 0), 'img' => (int)($r['img'] ?? 0), 'ti' => (int)($r['ti'] ?? 0), 'tout' => (int)($r['tout'] ?? 0)]; }
        return $out;
    }
    function stats(): void {
        [$days, $since] = $this->period(); $a = "role='assistant' AND mode<>'help' AND created_at>=?"; $n = fn($w = '') => (int)DB::val("SELECT COUNT(*) FROM bot_messages WHERE $a $w", [$since]);
        $tot = $n(); $tok = DB::one("SELECT COALESCE(SUM(tok_in),0) i, COALESCE(SUM(tok_out),0) o, AVG(ms) ms FROM bot_messages WHERE role='assistant' AND created_at>=?", [$since]);
        $pi = (float)str_replace(',', '.', (string)setting('bot.price_in', '0')); $po = (float)str_replace(',', '.', (string)setting('bot.price_out', '0'));
        $kw = []; foreach (DB::all("SELECT content FROM bot_messages WHERE role='user' AND content<>'(image)' AND created_at>=?", [$since]) as $m) foreach (array_unique(\App\Core\Bot::tokens($m['content'])) as $t) $kw[$t] = ($kw[$t] ?? 0) + 1;
        arsort($kw); $words = []; foreach (array_slice($kw, 0, 15, true) as $t => $c) { $words[] = ['t' => $t, 'n' => $c]; }
        $this->view('bot/stats', ['title' => 'Statistiques de l\'assistant', 'tab' => 'stats', 'days' => $days, 'tot' => $tot, 'found' => $n('AND found=1'), 'llm' => $n("AND mode='llm'"), 'llmErr' => $n('AND llm_err=1'), 'images' => (int)DB::val("SELECT COUNT(*) FROM bot_messages WHERE role='user' AND img_file IS NOT NULL AND created_at>=?", [$since]),
            'users' => (int)DB::val("SELECT COUNT(DISTINCT c.user_id) FROM bot_messages m JOIN bot_conversations c ON c.id=m.conversation_id WHERE m.role='user' AND m.created_at>=?", [$since]), 'up' => $n('AND feedback=1'), 'down' => $n('AND feedback=-1'), 'ms' => (int)($tok['ms'] ?? 0), 'tin' => (int)$tok['i'], 'tout' => (int)$tok['o'], 'cost' => ($pi || $po) ? ($tok['i'] * $pi + $tok['o'] * $po) / 1e6 : null,
            'daily' => $this->daily($since), 'bySrc' => DB::all("SELECT COALESCE(top_src,'—') k, COUNT(*) n FROM bot_messages WHERE $a GROUP BY COALESCE(top_src,'—') ORDER BY n DESC", [$since]),
            'byHour' => DB::all("SELECT SUBSTR(created_at,12,2) h, COUNT(*) n FROM bot_messages WHERE $a GROUP BY SUBSTR(created_at,12,2) ORDER BY h", [$since]),
            'byRole' => DB::all("SELECT COALESCE(r.name,'Sans rôle') k, COUNT(*) n FROM bot_messages m JOIN bot_conversations c ON c.id=m.conversation_id LEFT JOIN roles r ON r.id=(SELECT MIN(ur.role_id) FROM user_roles ur WHERE ur.user_id=c.user_id) WHERE m.role='user' AND m.created_at>=? GROUP BY COALESCE(r.name,'Sans rôle') ORDER BY n DESC", [$since]), 'words' => $words, 'llmOn' => Bot::llmEnabled(), 'imgOn' => Bot::imagesEnabled()]);
    }
    function statsExport(): void {
        [$days, $since] = $this->period(); Audit::log('export', 'bot_stats');
        csv_download('assistant-statistiques.csv', ['Date', 'Questions', 'Réponses trouvées', 'Réponses IA', 'Images analysées', 'Tokens en entrée', 'Tokens en sortie'], array_map(fn($r) => [$r['d'], $r['q'], $r['f'], $r['ia'], $r['img'], $r['ti'], $r['tout']], $this->daily($since)));
    }
}
