<?php
namespace App\Controllers;
use App\Core\{Svc, Controller, DB, Audit, Auth, Scope, Notifier, Tickets, Esc};
class ATController extends Controller {
    private function listRef(string $code): array { return DB::all('SELECT v.code, v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code=? AND v.active=1 ORDER BY v.sort_order', [$code]); }
    private function common(): array { return ['stores' => DB::all('SELECT id, name FROM stores ORDER BY name'), 'teams' => DB::all('SELECT id, name FROM teams ORDER BY name'), 'cats' => $this->listRef('at_categories')]; }
    private function visible(string $a = 't'): array {
        if (can('at.handle') || can('scope.all')) return ['1=1', []];
        $ids = Scope::ids() ?? [];
        if (!can('at.view') || !$ids) return ["$a.requester_id=?", [Auth::id()]];
        return ["($a.requester_id=? OR $a.requester_id IN (SELECT id FROM users WHERE employee_id IN (" . implode(',', array_fill(0, count($ids), '?')) . ')))', array_merge([Auth::id()], $ids)];
    }
    private function canSee(array $t): bool {
        if ((int)$t['requester_id'] === Auth::id() || can('at.handle') || can('scope.all')) return true;
        if (!can('at.view')) return false;
        $e = (int)DB::val('SELECT employee_id FROM users WHERE id=?', [(int)$t['requester_id']]); return $e && Scope::allows($e);
    }
    private const SELECT = 't.*, ru.name requester, au.name assignee, s.name store_name, a.tag asset_tag';
    private const JOINS = 'at_tickets t LEFT JOIN users ru ON ru.id=t.requester_id LEFT JOIN users au ON au.id=t.assignee_id LEFT JOIN stores s ON s.id=t.store_id LEFT JOIN at_assets a ON a.id=t.asset_id';

    function mine(): void {
        $pg = paginate(self::JOINS . ' WHERE t.requester_id=?', [Auth::id()], $this->page(), 25, self::SELECT, 't.id DESC');
        $this->view('at/mine', ['title' => 'Mes tickets', 'p' => $pg]);
    }
    function index(): void {
        [$w, $p] = $this->visible(); $w = [$w];
        foreach (['status', 'priority', 'category', 'kind', 'channel', 'tier', 'group_id'] as $f) if ($this->in($f)) { $w[] = "t.$f=?"; $p[] = $this->in($f); }
        if ($this->in('escalated') === '1') $w[] = 't.esc_level>0'; if ($this->in('ext') === '1') $w[] = "t.ext_status='open'";
        if (!$this->in('status') && $this->in('all') !== '1') $w[] = "t.status IN ('new','assigned','in_progress','waiting')";
        if ($this->in('assignee') === 'me') { $w[] = 't.assignee_id=?'; $p[] = Auth::id(); } elseif ($this->in('assignee') === 'none') $w[] = 't.assignee_id IS NULL';
        if ($this->in('late') === '1') { $w[] = "t.status IN ('new','assigned','in_progress') AND t.due_at < ?"; $p[] = now(); }
        if ($q = trim((string)$this->in('q', ''))) { $w[] = '(t.title LIKE ? OR t.reference LIKE ?)'; $p[] = "%$q%"; $p[] = "%$q%"; }
        $pg = paginate(self::JOINS . ' WHERE ' . implode(' AND ', $w), $p, $this->page(), 25, self::SELECT, "CASE t.priority WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END, t.due_at");
        $this->view('at/index', ['title' => 'File d\'attente', 'p' => $pg, 'groups' => DB::all('SELECT id, name FROM at_groups WHERE active=1 ORDER BY tier, name')] + $this->common());
    }
    function create(): void {
        $emp = Auth::user()['employee_id'] ?? null; $e = $emp ? DB::one('SELECT store_id, team_id FROM employees WHERE id=?', [(int)$emp]) : null;
        $ch = (string)$this->in('channel', 'portal'); if (!isset(Esc::CHANNEL[$ch]) || $ch === 'system' || (!can('at.handle') && !in_array($ch, Esc::SELF_CHANNELS, true))) $ch = 'portal';
        $this->view('at/form', ['title' => 'Nouveau ticket', 'channel' => $ch, 'onBehalf' => can('at.handle') ? DB::all("SELECT id, name, email FROM users WHERE status='active' ORDER BY name") : [], 'mine' => $e ?: [], 'assets' => DB::all("SELECT id, tag, label FROM at_assets WHERE status<>'retired' ORDER BY tag")] + $this->common());
    }
    function store(): void {
        [$d, $err] = $this->validate(['title' => ['label' => 'Le titre', 'req' => true, 'max' => 190], 'description' => ['label' => 'La description', 'req' => true, 'max' => 5000], 'category' => ['label' => 'La catégorie', 'req' => true, 'max' => 60]], $_POST);
        $kind = $this->in('kind', 'incident'); $prio = $this->in('priority', 'normal');
        if (!isset(Tickets::KIND[$kind]) || $kind === 'maintenance') $kind = 'incident'; if (!isset(Tickets::PRIO[$prio])) $prio = 'normal';
        $store = (int)$this->in('store_id') ?: null; $team = (int)$this->in('team_id') ?: null; $asset = (int)$this->in('asset_id') ?: null;
        if ($store && !DB::val('SELECT 1 FROM stores WHERE id=?', [$store])) $store = null; if ($team && !DB::val('SELECT 1 FROM teams WHERE id=?', [$team])) $team = null; if ($asset && !DB::val('SELECT 1 FROM at_assets WHERE id=?', [$asset])) $asset = null;
        $ch = (string)$this->in('channel', 'portal'); if (!isset(Esc::CHANNEL[$ch]) || $ch === 'system' || (!can('at.handle') && !in_array($ch, Esc::SELF_CHANNELS, true))) $ch = 'portal';
        $impact = isset(Esc::IMPACT[$this->in('impact')]) ? $this->in('impact') : null; $urg = isset(Esc::URGENCY[$this->in('urgency')]) ? $this->in('urgency') : null;
        $req = Auth::id(); $by = null;
        if (can('at.handle') && (int)$this->in('requester_id') && (int)$this->in('requester_id') !== Auth::id()) {
            if (DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [(int)$this->in('requester_id')])) { $req = (int)$this->in('requester_id'); $by = Auth::id(); } else $err['req'] = 'Demandeur inconnu.';
        }
        if ($err) $this->back($err, $_POST, 'at/new');
        $id = Tickets::open(['channel' => $ch, 'impact' => $impact, 'urgency' => $urg, 'logged_by' => $by, 'kind' => $kind, 'category' => $d['category'], 'priority' => $prio, 'title' => $d['title'], 'description' => $d['description'], 'store_id' => $store, 'team_id' => $team, 'asset_id' => $asset], $req);
        $row = DB::one('SELECT reference, status, priority FROM at_tickets WHERE id=?', [$id]); $prio = $row['priority']; if ($by) Notifier::send($req, 'Un ticket a été ouvert pour vous : ' . $row['reference'], $d['title'], '/at/' . $id); $fe = Tickets::saveUploads($id, 'files', Auth::id());
        Audit::log('create', 'at_ticket', $id, null, ['reference' => $row['reference'], 'priority' => $prio]);
        if (can('ns.use') && $this->in('want_note') && \App\Core\Ns::motif($d['category'])) { \App\Core\Ns::request(['title' => $d['title'], 'context' => $d['description'], 'template_id' => \App\Core\Ns::motif($d['category'])['template_id'], 'ticket_id' => $id], (int)$req); }
        flash("Ticket {$row['reference']} créé. " . ($row['status'] === 'approval' ? 'Votre demande d\'accès est envoyée pour validation.' : 'Les techniciens en ont été informés.') . ($fe ? ' ' . implode(' ', $fe) : ''), $fe ? 'warning' : 'success'); redirect("at/$id");
    }
    function show(string $id): void {
        $t = DB::one('SELECT ' . self::SELECT . ', ru.email requester_email FROM ' . self::JOINS . ' WHERE t.id=?', [(int)$id]);
        if (!$t) { $this->notFound(); return; } if (!$this->canSee($t)) { $this->forbidden(); return; }
        $ev = DB::all('SELECT * FROM at_events WHERE ticket_id=? ORDER BY id', [(int)$id]);
        if (!can('at.handle')) $ev = array_values(array_filter($ev, fn($x) => $x['kind'] !== 'note'));
        $this->view('at/show', ['title' => $t['reference'], 't' => $t, 'events' => $ev, 'esc' => can('at.handle') ? $this->escData($t) : null, 'children' => Svc::children((int)$id), 'links' => can('at.handle') ? Svc::links((int)$id) : [], 'parent' => $t['parent_id'] && can('at.handle') ? DB::one('SELECT id, reference, title FROM at_tickets WHERE id=?', [(int)$t['parent_id']]) : null, 'tpl' => can('at.handle') ? Svc::templatesFor($t) : null, 'own' => (int)$t['requester_id'] === Auth::id(), 'handlers' => can('at.handle') ? Tickets::handlers() : [],
            'asset' => $t['asset_id'] ? DB::one('SELECT * FROM at_assets WHERE id=?', [(int)$t['asset_id']]) : null,
            'files' => DB::all('SELECT * FROM at_files WHERE ticket_id=?' . (can('at.handle') ? '' : ' AND internal=0') . ' ORDER BY id', [(int)$id]),
            'parts' => can('at.handle') || (int)$t['requester_id'] === Auth::id() ? DB::all('SELECT m.*, i.label, i.sku, i.unit FROM at_stock_moves m JOIN at_stock i ON i.id=m.item_id WHERE m.ticket_id=? ORDER BY m.id', [(int)$id]) : [],
            'stock' => can('at.handle') ? DB::all('SELECT id, sku, label, qty, unit FROM at_stock WHERE active=1 ORDER BY label') : [],
            'acct' => $this->canCreateAccount($t) ? ['employees' => DB::all("SELECT e.id, e.first_name, e.last_name, e.matricule, e.email FROM employees e WHERE e.status<>'left' AND NOT EXISTS (SELECT 1 FROM users u WHERE u.employee_id=e.id) ORDER BY e.last_name, e.first_name"), 'roles' => $this->grantableRoles()] : null]);
    }
    private function isAdmin(): bool { return (bool)DB::val("SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id=? AND r.code='admin'", [Auth::id()]); }
    /** Rôles attribuables depuis un ticket : jamais « admin » ; « security_admin » seulement par un administrateur. */
    private function grantableRoles(): array { return DB::all('SELECT id, code, name FROM roles WHERE code<>? ' . ($this->isAdmin() ? '' : "AND code<>'security_admin' ") . 'ORDER BY name', ['admin']); }
    private function canCreateAccount(array $t): bool { return can('users.manage') && $t['kind'] === 'request' && $t['category'] === 'COMPTE' && in_array($t['status'], ['new', 'assigned', 'in_progress', 'waiting'], true); }
    function createAccount(string $id): void {
        if (!($t = $this->load($id))) return; if (!$this->canCreateAccount($t)) { flash('Ce ticket ne permet pas de créer un compte (demande d\'accès validée et en cours de traitement requise).', 'danger'); redirect("at/$id"); }
        $emp = DB::one("SELECT * FROM employees WHERE id=? AND status<>'left'", [(int)$this->in('employee_id')]); $role = DB::one('SELECT * FROM roles WHERE id=?', [(int)$this->in('role_id')]);
        $email = strtolower(trim((string)$this->in('email', '')));
        $err = [];
        if (!$emp) $err[] = 'Choisissez le collaborateur.'; elseif (DB::val('SELECT 1 FROM users WHERE employee_id=?', [(int)$emp['id']])) $err[] = 'Ce collaborateur a déjà un compte.';
        if (!$role || !in_array((int)$role['id'], array_map('intval', array_column($this->grantableRoles(), 'id')), true)) $err[] = 'Rôle non autorisé.';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 190) $err[] = 'Adresse e-mail invalide.'; elseif (DB::val('SELECT 1 FROM users WHERE email=?', [$email])) $err[] = 'Cette adresse est déjà utilisée par un compte.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("at/$id"); }
        $pw = UsersController::tempPassword(); $name = trim($emp['first_name'] . ' ' . $emp['last_name']);
        $uid = DB::insert('users', ['email' => $email, 'name' => $name, 'password_hash' => password_hash($pw, PASSWORD_DEFAULT), 'status' => 'active', 'must_change_password' => 1, 'employee_id' => (int)$emp['id'], 'created_at' => now(), 'updated_at' => now()]);
        DB::insert('user_roles', ['user_id' => $uid, 'role_id' => (int)$role['id']]);
        Audit::log('create', 'user', $uid, null, ['email' => $email, 'employee_id' => (int)$emp['id'], 'role' => $role['code'], 'via_ticket' => $t['reference']]);
        $res = "Compte créé pour $name ($email), rôle « {$role['name']} ». Mot de passe provisoire transmis séparément par le technicien.";
        DB::update('at_tickets', ['status' => 'resolved', 'resolution' => $res, 'resolved_at' => now(), 'assignee_id' => $t['assignee_id'] ?: Auth::id()] + $this->touch($t) + Tickets::transition($t, 'resolved'), 'id=?', [(int)$id]);
        Tickets::event((int)$id, 'status', 'Compte utilisateur créé : ' . $email . ' (rôle ' . $role['name'] . '). Ticket résolu.', Auth::id());
        if ($t['requester_id']) Notifier::send((int)$t['requester_id'], 'Compte créé : ' . $t['reference'], "Le compte de $name est prêt ; les identifiants lui seront remis.", '/at/' . $id);
        flash("Compte créé pour <b>" . e($name) . "</b>. Mot de passe provisoire (affiché une seule fois, à remettre à l'intéressé) : <code>$pw</code>", 'success'); redirect("at/$id");
    }
    private function load(string $id): ?array { $t = DB::one('SELECT * FROM at_tickets WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return null; } if (!$this->canSee($t)) { $this->forbidden(); return null; } return $t; }
    private function touch(array $t): array {   // première prise en charge : horodate le premier retour
        $u = []; if (!$t['first_response_at']) $u['first_response_at'] = now(); return $u;
    }
    function comment(string $id): void {
        if (!($t = $this->load($id))) return;
        $body = trim((string)$this->in('body', '')); $note = $this->in('internal') === '1' && can('at.handle');
        if ($body === '' && !empty($_FILES['files']['name'][0])) $body = '(pièce jointe)';
        if ($body === '' || mb_strlen($body) > 1500) { flash('Écrivez un commentaire (1500 caractères maximum).', 'danger'); redirect("at/$id"); }
        $own = (int)$t['requester_id'] === Auth::id();
        if (!$own && !can('at.handle')) { $this->forbidden(); return; }
        Tickets::event((int)$id, $note ? 'note' : 'comment', $body, Auth::id());
        if (can('at.handle') && !$own && !$note) { $u = $this->touch($t); if ($u) DB::update('at_tickets', $u, 'id=?', [(int)$id]); if ($t['requester_id']) Notifier::send((int)$t['requester_id'], 'Réponse sur ' . $t['reference'], mb_substr($body, 0, 120), '/at/' . $id); }
        if ($own && $t['status'] === 'resolved') { DB::update('at_tickets', ['status' => 'in_progress', 'resolved_at' => null], 'id=?', [(int)$id]); Tickets::event((int)$id, 'status', 'Ticket rouvert par le demandeur.', Auth::id()); }
        if ($own && $t['status'] === 'waiting') { DB::update('at_tickets', ['status' => 'in_progress'] + Tickets::transition($t, 'in_progress'), 'id=?', [(int)$id]); Tickets::event((int)$id, 'status', 'Réponse du demandeur : le ticket reprend et les délais repartent.', Auth::id()); }
        if ($own && $t['assignee_id']) Notifier::send((int)$t['assignee_id'], 'Nouveau message sur ' . $t['reference'], mb_substr($body, 0, 120), '/at/' . $id);
        $fe = Tickets::saveUploads((int)$id, 'files', Auth::id(), $note);
        flash(($note ? 'Note interne ajoutée.' : 'Commentaire ajouté.') . ($fe ? ' ' . implode(' ', $fe) : ''), $fe ? 'warning' : 'success'); redirect("at/$id");
    }
    function assign(string $id): void {
        if (!($t = $this->load($id))) return;
        if ($t['status'] === 'approval') { flash('Ticket en attente de validation de la demande d\'accès.', 'warning'); redirect("at/$id"); }
        $a = (int)$this->in('assignee_id'); if ($this->in('take') === '1') $a = Auth::id();
        if ($a && !in_array($a, array_map('intval', array_column(Tickets::handlers(), 'id')), true)) { flash('Ce technicien n\'est pas valide.', 'danger'); redirect("at/$id"); }
        if ($a && !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$a])) { flash('Utilisateur invalide.', 'danger'); redirect("at/$id"); }
        $u = ['assignee_id' => $a ?: null] + $this->touch($t); if ($a && $t['status'] === 'new') $u['status'] = 'assigned'; if (!$a && $t['status'] === 'assigned') $u['status'] = 'new';
        DB::update('at_tickets', $u, 'id=?', [(int)$id]);
        $n = $a ? (string)DB::val('SELECT name FROM users WHERE id=?', [$a]) : 'personne'; Tickets::event((int)$id, 'assign', 'Affecté à : ' . $n . '.', Auth::id());
        if ($a && $a !== Auth::id()) Notifier::send($a, 'Ticket affecté : ' . $t['reference'], $t['title'], '/at/' . $id);
        Audit::log('assign', 'at_ticket', $id, null, ['assignee' => $a]); flash('Affectation enregistrée.'); redirect("at/$id");
    }
    function status(string $id): void {
        if (!($t = $this->load($id))) return;
        $own = (int)$t['requester_id'] === Auth::id(); $s = (string)$this->in('status');
        if (!isset(Tickets::STATUS[$s])) { flash('Statut invalide.', 'danger'); redirect("at/$id"); }
        if (!can('at.handle')) {   // le demandeur peut seulement clore un ticket résolu ou le rouvrir
            if (!($own && (($t['status'] === 'resolved' && in_array($s, ['closed', 'in_progress'], true))))) { $this->forbidden(); return; }
        }
        if ($t['status'] === 'approval') { flash('Ce ticket attend la validation de la demande d\'accès : il ne peut pas être traité avant la fin du circuit.', 'warning'); redirect("at/$id"); }
        if ($s === 'approval') { flash('Statut invalide.', 'danger'); redirect("at/$id"); }
        $res = trim((string)$this->in('resolution', ''));
        if ($s === 'resolved' && $res === '' && !$t['resolution']) { flash('Décrivez la solution apportée pour résoudre le ticket.', 'danger'); redirect("at/$id"); }
        if (mb_strlen($res) > 5000) { flash('Solution trop longue.', 'danger'); redirect("at/$id"); }
        $oc = in_array($s, ['resolved', 'closed'], true) ? Svc::openChildren((int)$id) : [];
        if ($oc) {
            if (!(can('at.handle') && $this->in('with_children') === '1')) { flash('Ce ticket a ' . count($oc) . ' ticket(s) enfant(s) encore ouvert(s) : terminez-les d\'abord ou cochez « résoudre aussi les enfants ».', 'warning'); redirect("at/$id"); }
            $cres = $res !== '' ? $res : (string)$t['resolution'];
            foreach ($oc as $c) { $co = DB::one('SELECT * FROM at_tickets WHERE id=?', [(int)$c['id']]); DB::update('at_tickets', ['status' => 'resolved', 'resolved_at' => now(), 'resolution' => $cres] + Tickets::transition($co, 'resolved'), 'id=?', [(int)$c['id']]); Tickets::event((int)$c['id'], 'status', 'Résolu avec le ticket parent ' . $t['reference'] . '.', Auth::id()); }
        }
        $u = ['status' => $s] + (can('at.handle') ? $this->touch($t) : []) + Tickets::transition($t, $s);
        if ($res !== '') $u['resolution'] = $res;
        if ($s === 'resolved') { $u['resolved_at'] = now(); if (!$t['assignee_id'] && can('at.handle')) $u['assignee_id'] = Auth::id(); }
        elseif ($s === 'closed') { $u['closed_at'] = now(); if (!$t['resolved_at']) $u['resolved_at'] = now(); }
        else { $u['resolved_at'] = null; $u['closed_at'] = null; }
        DB::update('at_tickets', $u, 'id=?', [(int)$id]);
        if ($t['asset_id'] && $s === 'resolved' && DB::val('SELECT status FROM at_assets WHERE id=?', [(int)$t['asset_id']]) === 'repair') DB::update('at_assets', ['status' => 'in_service'], 'id=?', [(int)$t['asset_id']]);
        if (!in_array($t['status'], ['resolved', 'closed'], true)) Svc::afterStatus($t, $s, Auth::id());
        Tickets::event((int)$id, 'status', 'Statut : ' . Tickets::STATUS[$s] . ($res !== '' ? ' — ' . $res : ''), Auth::id());
        if ($s === 'resolved' && $t['requester_id'] && !$own) Notifier::send((int)$t['requester_id'], 'Ticket résolu : ' . $t['reference'], 'Confirmez ou rouvrez si le problème persiste, et donnez votre avis sur le traitement.', '/at/' . $id);
        if ($own && $t['assignee_id']) Notifier::send((int)$t['assignee_id'], ($s === 'closed' ? 'Ticket clos : ' : 'Ticket rouvert : ') . $t['reference'], $t['title'], '/at/' . $id);
        Audit::log('status', 'at_ticket', $id, ['status' => $t['status']], ['status' => $s]); flash('Statut mis à jour : ' . Tickets::STATUS[$s] . '.'); redirect("at/$id");
    }
    function priority(string $id): void {
        $t = DB::one('SELECT * FROM at_tickets WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return; }
        $p = (string)$this->in('priority'); if (!isset(Tickets::PRIO[$p])) { flash('Priorité invalide.', 'danger'); redirect("at/$id"); }
        DB::update('at_tickets', ['priority' => $p] + Tickets::due($t['created_at'], $p, $t['team_id'] ? (int)$t['team_id'] : null, (int)$t['paused_secs']), 'id=?', [(int)$id]);
        Tickets::event((int)$id, 'priority', 'Priorité : ' . Tickets::PRIO[$p] . ' (échéances recalculées).', Auth::id());
        Audit::log('priority', 'at_ticket', $id, ['priority' => $t['priority']], ['priority' => $p]); flash('Priorité modifiée, échéances recalculées.'); redirect("at/$id");
    }

    function dashboard(): void {
        [$w, $p] = $this->visible(); $from = $this->in('from') ?: date('Y-m-01'); $to = $this->in('to') ?: date('Y-m-d');
        $base = "FROM at_tickets t WHERE $w AND t.created_at>=? AND t.created_at<=?"; $pp = array_merge($p, [$from . ' 00:00:00', $to . ' 23:59:59']);
        $open = "t.status IN ('new','assigned','in_progress','waiting')";
        $k = [
            'total' => (int)DB::val("SELECT COUNT(*) $base", $pp),
            'open' => (int)DB::val("SELECT COUNT(*) FROM at_tickets t WHERE $w AND $open", $p),
            'late' => (int)DB::val("SELECT COUNT(*) FROM at_tickets t WHERE $w AND t.status IN ('new','assigned','in_progress') AND t.due_at<?", array_merge($p, [now()])),
            'unassigned' => (int)DB::val("SELECT COUNT(*) FROM at_tickets t WHERE $w AND t.status='new'", $p),
            'resolved' => (int)DB::val("SELECT COUNT(*) $base AND t.resolved_at IS NOT NULL", $pp),
            'ontime' => (int)DB::val("SELECT COUNT(*) $base AND t.resolved_at IS NOT NULL AND t.resolved_at<=t.due_at", $pp),
            'resp_ok' => (int)DB::val("SELECT COUNT(*) $base AND t.first_response_at IS NOT NULL AND t.first_response_at<=t.response_due", $pp),
            'resp_n' => (int)DB::val("SELECT COUNT(*) $base AND t.first_response_at IS NOT NULL", $pp),
        ];
        $rs = DB::all("SELECT t.created_at, t.resolved_at $base AND t.resolved_at IS NOT NULL", $pp); $sum = 0; foreach ($rs as $r) $sum += max(0, strtotime($r['resolved_at']) - strtotime($r['created_at']));
        $k['avg_hours'] = $rs ? round($sum / count($rs) / 3600, 1) : null;
        $ageB = ['< 1 jour' => 0, '1 à 3 jours' => 0, '3 à 7 jours' => 0, '> 7 jours' => 0];
        foreach (DB::all("SELECT t.created_at FROM at_tickets t WHERE $w AND $open", $p) as $r) { $d = (time() - strtotime($r['created_at'])) / 86400; $ageB[$d < 1 ? '< 1 jour' : ($d < 3 ? '1 à 3 jours' : ($d < 7 ? '3 à 7 jours' : '> 7 jours'))]++; }
        $x = ['csat' => Svc::csatStats("$w AND t.created_at>=? AND t.created_at<=?", $pp), 'aging' => $ageB,
            'byChannel' => DB::all("SELECT t.channel k, COUNT(*) n $base GROUP BY t.channel ORDER BY n DESC", $pp), 'byTier' => DB::all("SELECT t.tier k, COUNT(*) n $base GROUP BY t.tier ORDER BY t.tier", $pp),
            'escalated' => (int)DB::val("SELECT COUNT(*) $base AND t.esc_level>0", $pp), 'functional' => (int)DB::val("SELECT COUNT(*) $base AND t.tier>1", $pp), 'ext' => (int)DB::val("SELECT COUNT(*) FROM at_tickets t WHERE $w AND t.ext_status='open'", $p),
            'children' => (int)DB::val("SELECT COUNT(*) $base AND t.parent_id IS NOT NULL", $pp), 'reopened' => (int)DB::val("SELECT COUNT(DISTINCT e.ticket_id) FROM at_events e JOIN at_tickets t ON t.id=e.ticket_id WHERE $w AND t.created_at>=? AND t.created_at<=? AND e.body LIKE 'Ticket rouvert%'", $pp),
            'worst' => DB::all("SELECT t.id, t.reference, t.title, t.csat_score, t.csat_comment FROM at_tickets t WHERE $w AND t.created_at>=? AND t.created_at<=? AND t.csat_score IS NOT NULL AND t.csat_score<=2 ORDER BY t.csat_at DESC LIMIT 5", $pp)];
        $x['byTier'] = array_map(fn($r) => ['k' => 'N' . (int)$r['k'], 'n' => $r['n']], $x['byTier']);
        if ($this->in('export') === 'csv' && can('at.manage')) {
            $rows = DB::all("SELECT t.reference, t.created_at, t.channel, t.category, t.priority, t.status, t.tier, t.esc_level, t.resolved_at, t.csat_score FROM at_tickets t WHERE $w AND t.created_at>=? AND t.created_at<=? ORDER BY t.id", $pp);
            csv_download('tickets_' . $from . '_' . $to . '.csv', ['Référence', 'Créé le', 'Canal', 'Catégorie', 'Priorité', 'Statut', 'Niveau', 'Escalade', 'Résolu le', 'Satisfaction'], array_map('array_values', $rows)); return;
        }
        $this->view('at/dashboard', ['title' => 'Tableau de bord ticketing', 'x' => $x, 'k' => $k, 'from' => $from, 'to' => $to,
            'byStatus' => DB::all("SELECT t.status k, COUNT(*) n $base GROUP BY t.status", $pp), 'byCat' => DB::all("SELECT COALESCE(t.category,'—') k, COUNT(*) n $base GROUP BY t.category ORDER BY n DESC", $pp),
            'byPrio' => DB::all("SELECT t.priority k, COUNT(*) n $base GROUP BY t.priority", $pp),
            'byStore' => DB::all("SELECT COALESCE(s.name,'—') k, COUNT(*) n FROM at_tickets t LEFT JOIN stores s ON s.id=t.store_id WHERE $w AND t.created_at>=? AND t.created_at<=? GROUP BY s.name ORDER BY n DESC", $pp),
            'byTech' => DB::all("SELECT COALESCE(u.name,'Non affecté') k, COUNT(*) n, SUM(CASE WHEN $open THEN 1 ELSE 0 END) open_n FROM at_tickets t LEFT JOIN users u ON u.id=t.assignee_id WHERE $w AND t.created_at>=? AND t.created_at<=? GROUP BY u.name ORDER BY n DESC", $pp)]);
    }

    // ---- Parc matériel
    function assets(): void {
        $w = ['1=1']; $p = [];
        foreach (['type', 'status', 'store_id'] as $f) if ($this->in($f)) { $w[] = "a.$f=?"; $p[] = $this->in($f); }
        if ($q = trim((string)$this->in('q', ''))) { $w[] = '(a.tag LIKE ? OR a.label LIKE ? OR a.serial LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $from = 'at_assets a LEFT JOIN stores s ON s.id=a.store_id LEFT JOIN teams m ON m.id=a.team_id WHERE ' . implode(' AND ', $w);
        if ($this->in('export') === 'csv' && can('at.manage')) {
            $rows = DB::all("SELECT a.tag, a.type, a.label, a.serial, s.name store, m.name team, a.status, a.purchase_date FROM $from ORDER BY a.tag", $p);
            Audit::log('export', 'at_assets', null, null, ['rows' => count($rows)]);
            csv_download('parc_materiel.csv', ['Étiquette', 'Type', 'Désignation', 'N° de série', 'Boutique', 'Équipe', 'Statut', 'Achat'], array_map(fn($r) => array_values($r), $rows));
        }
        $pg = paginate($from, $p, $this->page(), 25, 'a.*, s.name store_name, m.name team_name', 'a.tag');
        $this->view('at/assets', ['title' => 'Parc matériel', 'p' => $pg, 'types' => $this->listRef('at_asset_types')] + $this->common());
    }
    function storeAsset(): void {
        [$d, $err] = $this->validate(['tag' => ['label' => 'L\'étiquette', 'req' => true, 'max' => 60], 'type' => ['label' => 'Le type', 'req' => true, 'max' => 60], 'label' => ['label' => 'La désignation', 'req' => true, 'max' => 190], 'serial' => ['label' => 'Le numéro de série', 'max' => 100], 'purchase_date' => ['label' => 'La date d\'achat', 'date' => true], 'notes' => ['label' => 'Les notes', 'max' => 500]], $_POST);
        if (!$err && DB::val('SELECT 1 FROM at_assets WHERE tag=?', [$d['tag']])) $err['tag'] = 'Cette étiquette existe déjà.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('at/assets'); }
        $st = (string)$this->in('status', 'in_service'); $d['status'] = isset(Tickets::ASSET_STATUS[$st]) ? $st : 'in_service';
        $d['store_id'] = (int)$this->in('store_id') ?: null; $d['team_id'] = (int)$this->in('team_id') ?: null; $d['created_at'] = now();
        $id = DB::insert('at_assets', $d); Audit::log('create', 'at_asset', $id, null, $d); flash('Équipement ajouté au parc.'); redirect("at/assets/$id");
    }
    function asset(string $id): void {
        $a = DB::one('SELECT a.*, s.name store_name, m.name team_name FROM at_assets a LEFT JOIN stores s ON s.id=a.store_id LEFT JOIN teams m ON m.id=a.team_id WHERE a.id=?', [(int)$id]); if (!$a) { $this->notFound(); return; }
        $this->view('at/asset', ['title' => $a['tag'], 'a' => $a, 'types' => $this->listRef('at_asset_types'), 'tickets' => DB::all('SELECT t.id, t.reference, t.title, t.status, t.priority, t.created_at, t.kind FROM at_tickets t WHERE t.asset_id=? ORDER BY t.id DESC LIMIT 50', [(int)$id])] + $this->common());
    }
    function updateAsset(string $id): void {
        $a = DB::one('SELECT * FROM at_assets WHERE id=?', [(int)$id]); if (!$a) { $this->notFound(); return; }
        [$d, $err] = $this->validate(['type' => ['label' => 'Le type', 'req' => true, 'max' => 60], 'label' => ['label' => 'La désignation', 'req' => true, 'max' => 190], 'serial' => ['label' => 'Le numéro de série', 'max' => 100], 'purchase_date' => ['label' => 'La date d\'achat', 'date' => true], 'notes' => ['label' => 'Les notes', 'max' => 500]], $_POST);
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("at/assets/$id"); }
        $st = (string)$this->in('status'); $d['status'] = isset(Tickets::ASSET_STATUS[$st]) ? $st : $a['status'];
        $d['store_id'] = (int)$this->in('store_id') ?: null; $d['team_id'] = (int)$this->in('team_id') ?: null;
        DB::update('at_assets', $d, 'id=?', [(int)$id]); Audit::log('update', 'at_asset', $id, $a, $d); flash('Équipement mis à jour.'); redirect("at/assets/$id");
    }

    // ---- Maintenance préventive
    function plans(): void {
        $this->view('at/plans', ['title' => 'Maintenance préventive', 'plans' => DB::all('SELECT p.*, s.name store_name, m.name team_name, u.name assignee FROM at_plans p LEFT JOIN stores s ON s.id=p.store_id LEFT JOIN teams m ON m.id=p.team_id LEFT JOIN users u ON u.id=p.assignee_id ORDER BY p.next_due'), 'handlers' => Tickets::handlers()] + $this->common());
    }
    function storePlan(): void {
        [$d, $err] = $this->validate(['title' => ['label' => 'Le titre', 'req' => true, 'max' => 190], 'next_due' => ['label' => 'La prochaine échéance', 'req' => true, 'date' => true]], $_POST);
        $f = (int)$this->in('frequency_days'); if ($f < 1 || $f > 730) $err['f'] = 'La fréquence doit être comprise entre 1 et 730 jours.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('at/plans'); }
        $d += ['frequency_days' => $f, 'store_id' => (int)$this->in('store_id') ?: null, 'team_id' => (int)$this->in('team_id') ?: null, 'assignee_id' => (int)$this->in('assignee_id') ?: null, 'active' => 1];
        $id = DB::insert('at_plans', $d); Audit::log('create', 'at_plan', $id, null, $d); flash('Plan de maintenance créé.'); redirect('at/plans');
    }
    function togglePlan(string $id): void {
        $p = DB::one('SELECT * FROM at_plans WHERE id=?', [(int)$id]); if (!$p) { $this->notFound(); return; }
        DB::update('at_plans', ['active' => $p['active'] ? 0 : 1], 'id=?', [(int)$id]); Audit::log('update', 'at_plan', $id, ['active' => $p['active']], ['active' => $p['active'] ? 0 : 1]); redirect('at/plans');
    }
    /** Génère le ticket de maintenance d'un plan et avance l'échéance. */
    static function runPlan(array $p): int {
        $id = Tickets::create(['channel' => 'system', 'kind' => 'maintenance', 'category' => 'MATERIEL', 'priority' => 'low', 'title' => 'Maintenance préventive : ' . $p['title'], 'description' => 'Ticket généré par le plan de maintenance (tous les ' . $p['frequency_days'] . ' jours).', 'store_id' => $p['store_id'], 'team_id' => $p['team_id'], 'assignee_id' => $p['assignee_id'] ?: null]);
        $next = date('Y-m-d', strtotime($p['next_due'] . ' +' . (int)$p['frequency_days'] . ' days')); while ($next <= date('Y-m-d')) $next = date('Y-m-d', strtotime($next . ' +' . (int)$p['frequency_days'] . ' days'));
        DB::update('at_plans', ['next_due' => $next], 'id=?', [(int)$p['id']]);
        if ($p['assignee_id']) Notifier::send((int)$p['assignee_id'], 'Maintenance à réaliser', $p['title'], '/at/' . $id);
        return $id;
    }
    function runPlanNow(string $id): void {
        $p = DB::one('SELECT * FROM at_plans WHERE id=?', [(int)$id]); if (!$p) { $this->notFound(); return; }
        $t = self::runPlan($p); Audit::log('run', 'at_plan', $id, null, ['ticket' => $t]); flash('Ticket de maintenance créé.'); redirect("at/$t");
    }

    // ---- Délais (SLA) et calendrier
    function settings(): void {
        $this->view('at/settings', ['title' => 'Délais et calendrier', 'sla' => DB::all("SELECT * FROM at_sla ORDER BY CASE priority WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'normal' THEN 2 ELSE 3 END"),
            'cal' => Tickets::cal(), 'calendars' => DB::all('SELECT c.*, (SELECT COUNT(*) FROM at_team_cal t WHERE t.calendar_id=c.id) nteams FROM at_calendars c ORDER BY c.name'),
            'teams' => DB::all('SELECT t.id, t.name, tc.calendar_id FROM teams t LEFT JOIN at_team_cal tc ON tc.team_id=t.id ORDER BY t.name'), 'holidays' => DB::all('SELECT * FROM at_holidays ORDER BY day DESC LIMIT 200')]);
    }
    function saveSettings(): void {
        foreach (DB::all('SELECT * FROM at_sla') as $s) {
            $r = (int)($_POST['response'][$s['id']] ?? 0); $v = (int)($_POST['resolve'][$s['id']] ?? 0);
            if ($r < 1 || $v < 1 || $r > 720 || $v > 2160 || $r > $v) { flash('Délais invalides pour « ' . (Tickets::PRIO[$s['priority']] ?? $s['priority']) . ' » : indiquez des heures (1 à 2160), la prise en charge ne pouvant dépasser la résolution.', 'danger'); redirect('at/settings'); }
        }
        foreach (DB::all('SELECT * FROM at_sla') as $s) {
            $cal = ($_POST['calendar'][$s['id']] ?? '24x7') === 'business' ? 'business' : '24x7';
            DB::update('at_sla', ['response_hours' => (int)$_POST['response'][$s['id']], 'resolve_hours' => (int)$_POST['resolve'][$s['id']], 'calendar' => $cal], 'id=?', [(int)$s['id']]);
        }
        Audit::log('update', 'at_sla', null, null, ['response' => $_POST['response'] ?? [], 'resolve' => $_POST['resolve'] ?? [], 'calendar' => $_POST['calendar'] ?? []]); flash('Délais enregistrés. Ils s\'appliquent aux nouveaux tickets (et à un changement de priorité).'); redirect('at/settings');
    }
    function saveCalendar(): void {
        $days = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['days'] ?? [])), fn($d) => $d >= 1 && $d <= 7)));
        $st = (string)$this->in('start', ''); $en = (string)$this->in('end', '');
        if (!$days || !preg_match('/^\d{2}:\d{2}$/', $st) || !preg_match('/^\d{2}:\d{2}$/', $en) || $st >= $en || $en > '23:59') { flash('Calendrier invalide : choisissez au moins un jour et une plage horaire dont le début précède la fin.', 'danger'); redirect('at/settings'); }
        sort($days); \App\Core\Settings::set('at_cal_days', implode(',', $days)); \App\Core\Settings::set('at_cal_start', $st); \App\Core\Settings::set('at_cal_end', $en);
        Audit::log('update', 'at_calendar', null, null, ['days' => $days, 'start' => $st, 'end' => $en]); flash('Calendrier d\'heures ouvrées enregistré (pour les nouveaux tickets).'); redirect('at/settings');
    }
    private function calData(): array {
        $days = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['days'] ?? [])), fn($d) => $d >= 1 && $d <= 7))); sort($days);
        $st = (string)$this->in('start', ''); $en = (string)$this->in('end', ''); $name = trim((string)$this->in('name', ''));
        $err = [];
        if ($name === '' || mb_strlen($name) > 100) $err[] = 'Le nom du calendrier est obligatoire (100 caractères maximum).';
        if (!$days || !preg_match('/^\d{2}:\d{2}$/', $st) || !preg_match('/^\d{2}:\d{2}$/', $en) || $st >= $en || $en > '23:59') $err[] = 'Choisissez au moins un jour et une plage horaire dont le début précède la fin.';
        return [['name' => $name, 'days' => implode(',', $days), 'start_time' => $st, 'end_time' => $en], $err];
    }
    function storeCalendar(): void {
        [$d, $err] = $this->calData(); if (!$err && DB::val('SELECT 1 FROM at_calendars WHERE name=?', [$d['name']])) $err[] = 'Ce nom existe déjà.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('at/settings'); }
        $id = DB::insert('at_calendars', $d); Audit::log('create', 'at_calendar', $id, null, $d); flash('Calendrier créé : affectez-le aux équipes concernées.'); redirect('at/settings');
    }
    function updateCalendar(string $id): void {
        $o = DB::one('SELECT * FROM at_calendars WHERE id=?', [(int)$id]); if (!$o) { $this->notFound(); return; }
        [$d, $err] = $this->calData(); if (!$err && DB::val('SELECT 1 FROM at_calendars WHERE name=? AND id<>?', [$d['name'], (int)$id])) $err[] = 'Ce nom existe déjà.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('at/settings'); }
        DB::update('at_calendars', $d, 'id=?', [(int)$id]); Audit::log('update', 'at_calendar', $id, $o, $d); flash('Calendrier enregistré (pour les nouveaux tickets).'); redirect('at/settings');
    }
    function deleteCalendar(string $id): void {
        DB::pdo()->prepare('DELETE FROM at_team_cal WHERE calendar_id=?')->execute([(int)$id]); DB::pdo()->prepare('DELETE FROM at_calendars WHERE id=?')->execute([(int)$id]);
        Audit::log('delete', 'at_calendar', $id); flash('Calendrier supprimé ; ses équipes reviennent au calendrier par défaut.'); redirect('at/settings');
    }
    function saveTeamCalendars(): void {
        foreach (DB::all('SELECT id FROM teams') as $t) {
            $c = (int)($_POST['team'][$t['id']] ?? 0); DB::pdo()->prepare('DELETE FROM at_team_cal WHERE team_id=?')->execute([(int)$t['id']]);
            if ($c && DB::val('SELECT 1 FROM at_calendars WHERE id=?', [$c])) DB::insert('at_team_cal', ['team_id' => (int)$t['id'], 'calendar_id' => $c]);
        }
        Audit::log('update', 'at_team_cal', null, null, ['teams' => $_POST['team'] ?? []]); flash('Calendriers des équipes enregistrés.'); redirect('at/settings');
    }
    function addHoliday(): void {
        [$d, $err] = $this->validate(['day' => ['label' => 'La date', 'req' => true, 'date' => true], 'label' => ['label' => 'Le libellé', 'req' => true, 'max' => 150]], $_POST);
        if (!$err && DB::val('SELECT 1 FROM at_holidays WHERE day=?', [$d['day']])) $err['day'] = 'Ce jour férié existe déjà.';
        if (!$err && !checkdate((int)substr($d['day'], 5, 2), (int)substr($d['day'], 8, 2), (int)substr($d['day'], 0, 4))) $err['day'] = 'Date invalide.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('at/settings'); }
        $id = DB::insert('at_holidays', $d); Audit::log('create', 'at_holiday', $id, null, $d); flash('Jour férié ajouté.'); redirect('at/settings');
    }
    function deleteHoliday(string $id): void { DB::pdo()->prepare('DELETE FROM at_holidays WHERE id=?')->execute([(int)$id]); Audit::log('delete', 'at_holiday', $id); flash('Jour férié supprimé.'); redirect('at/settings'); }

    // ---- Pièces jointes
    function file(string $id): void {
        $f = DB::one('SELECT * FROM at_files WHERE id=?', [(int)$id]); if (!$f) { $this->notFound(); return; }
        $t = DB::one('SELECT * FROM at_tickets WHERE id=?', [(int)$f['ticket_id']]); if (!$t || !$this->canSee($t) || ($f['internal'] && !can('at.handle'))) { $this->forbidden(); return; }
        $path = Tickets::fileDir() . '/' . $f['stored_name']; if (!is_file($path)) { $this->notFound(); return; }
        Audit::log('download', 'at_file', $id, null, ['ticket' => $t['reference'], 'name' => $f['original_name']]);
        header('Content-Type: ' . $f['mime']); header('X-Content-Type-Options: nosniff'); header('Content-Length: ' . filesize($path));
        header('Content-Disposition: attachment; filename="' . rawurlencode($f['original_name']) . '"; filename*=UTF-8\'\'' . rawurlencode($f['original_name'])); readfile($path); exit;
    }
    function mailLog(): void { $this->view('at/mail', ['title' => 'E-mails', 'mx' => ['smtp' => \App\Core\Mailer::enabled(), 'imap' => (string)env('IMAP_HOST', '') !== '', 'auth' => strtolower((string)env('MAIL_AUTH_MODE', 'off')) === 'results', 'pending' => (int)DB::val("SELECT COUNT(*) FROM at_outbox WHERE status='pending'"), 'failed' => (int)DB::val("SELECT COUNT(*) FROM at_outbox WHERE status='failed'"), 'last' => DB::val("SELECT last_error FROM at_outbox WHERE last_error IS NOT NULL ORDER BY id DESC LIMIT 1")], 'p' => paginate('at_mail m LEFT JOIN at_tickets t ON t.id=m.ticket_id', [], $this->page(), 30, 'm.*, t.reference', 'm.id DESC')]); }

    // ---- Stock de pièces
    function stock(): void {
        $w = ['1=1']; $p = [];
        if ($q = trim((string)$this->in('q', ''))) { $w[] = '(i.sku LIKE ? OR i.label LIKE ?)'; array_push($p, "%$q%", "%$q%"); }
        if ($this->in('low') === '1') $w[] = 'i.qty<=i.min_qty AND i.min_qty>0';
        $from = 'at_stock i LEFT JOIN stores s ON s.id=i.store_id LEFT JOIN at_suppliers sp ON sp.id=i.supplier_id WHERE ' . implode(' AND ', $w);
        if ($this->in('export') === 'csv' && can('at.manage')) { $rows = DB::all("SELECT i.sku, i.label, i.category, i.qty, i.unit, i.min_qty, s.name, sp.name sup, i.unit_cost, (i.qty*i.unit_cost) val FROM $from ORDER BY i.label", $p); Audit::log('export', 'at_stock', null, null, ['rows' => count($rows)]); csv_download('stock_pieces.csv', ['Référence', 'Désignation', 'Catégorie', 'Quantité', 'Unité', 'Seuil', 'Lieu', 'Fournisseur', 'Coût unitaire', 'Valeur'], array_map('array_values', $rows)); }
        $val = can('at.manage') ? (float)DB::val('SELECT COALESCE(SUM(qty*unit_cost),0) FROM at_stock WHERE active=1') : null;
        $this->view('at/stock', ['title' => 'Stock de pièces', 'val' => $val, 'nocost' => (int)DB::val('SELECT COUNT(*) FROM at_stock WHERE active=1 AND qty>0 AND unit_cost IS NULL'), 'suppliers' => DB::all('SELECT id, name FROM at_suppliers WHERE active=1 ORDER BY name'), 'p' => paginate($from, $p, $this->page(), 30, 'i.*, s.name store_name, sp.name supplier_name', 'i.label'), 'low' => (int)DB::val('SELECT COUNT(*) FROM at_stock WHERE active=1 AND min_qty>0 AND qty<=min_qty')] + $this->common());
    }
    private function costIn(string $k): ?float { $v = str_replace(',', '.', trim((string)$this->in($k, ''))); return $v !== '' && is_numeric($v) && $v >= 0 && $v < 1e9 ? round((float)$v, 2) : null; }
    private function supplierIn(): ?int { $s = (int)$this->in('supplier_id'); return $s && DB::val('SELECT 1 FROM at_suppliers WHERE id=?', [$s]) ? $s : null; }
    function storeItem(): void {
        [$d, $err] = $this->validate(['sku' => ['label' => 'La référence', 'req' => true, 'max' => 60], 'label' => ['label' => 'La désignation', 'req' => true, 'max' => 190], 'category' => ['label' => 'La catégorie', 'max' => 60], 'unit' => ['label' => 'L\'unité', 'max' => 20]], $_POST);
        if (!$err && DB::val('SELECT 1 FROM at_stock WHERE sku=?', [$d['sku']])) $err['sku'] = 'Cette référence existe déjà.';
        $q = (int)$this->in('qty', 0); $mn = (int)$this->in('min_qty', 0); if ($q < 0 || $mn < 0 || $q > 1000000 || $mn > 1000000) $err['q'] = 'Quantités invalides.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('at/stock'); }
        $id = DB::insert('at_stock', ['sku' => $d['sku'], 'label' => $d['label'], 'category' => $d['category'], 'unit' => $d['unit'] ?: 'pièce', 'qty' => 0, 'min_qty' => $mn, 'store_id' => (int)$this->in('store_id') ?: null, 'unit_cost' => $this->costIn('unit_cost'), 'supplier_id' => $this->supplierIn(), 'active' => 1, 'updated_at' => now()]);
        if ($q > 0) Tickets::stockMove($id, 'in', $q, null, Auth::id(), 'Stock initial');
        Audit::log('create', 'at_stock', $id, null, $d + ['qty' => $q, 'min_qty' => $mn]); flash('Article créé.'); redirect("at/stock/$id");
    }
    function item(string $id): void {
        $i = DB::one('SELECT i.*, s.name store_name FROM at_stock i LEFT JOIN stores s ON s.id=i.store_id WHERE i.id=?', [(int)$id]); if (!$i) { $this->notFound(); return; }
        $this->view('at/item', ['title' => $i['sku'], 'i' => $i, 'suppliers' => DB::all('SELECT id, name FROM at_suppliers WHERE active=1 ORDER BY name'), 'moves' => DB::all('SELECT m.*, t.reference FROM at_stock_moves m LEFT JOIN at_tickets t ON t.id=m.ticket_id WHERE m.item_id=? ORDER BY m.id DESC LIMIT 100', [(int)$id])] + $this->common());
    }
    function updateItem(string $id): void {
        $i = DB::one('SELECT * FROM at_stock WHERE id=?', [(int)$id]); if (!$i) { $this->notFound(); return; }
        [$d, $err] = $this->validate(['label' => ['label' => 'La désignation', 'req' => true, 'max' => 190], 'category' => ['label' => 'La catégorie', 'max' => 60], 'unit' => ['label' => 'L\'unité', 'max' => 20]], $_POST);
        $mn = (int)$this->in('min_qty', 0); if ($mn < 0 || $mn > 1000000) $err['m'] = 'Seuil invalide.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("at/stock/$id"); }
        $u = $d + ['unit_cost' => $this->costIn('unit_cost'), 'supplier_id' => $this->supplierIn(), 'min_qty' => $mn, 'store_id' => (int)$this->in('store_id') ?: null, 'active' => $this->in('active') === '1' ? 1 : 0, 'updated_at' => now()]; if (!$u['unit']) $u['unit'] = 'pièce';
        DB::update('at_stock', $u, 'id=?', [(int)$id]); Audit::log('update', 'at_stock', $id, $i, $u); flash('Article mis à jour.'); redirect("at/stock/$id");
    }
    function moveItem(string $id): void {
        $kind = (string)$this->in('kind'); if (!in_array($kind, ['in', 'out', 'adjust'], true) || ($kind === 'adjust' && !can('at.manage'))) { $this->forbidden(); return; }
        $tid = null; if ($ref = trim((string)$this->in('ticket', ''))) { $tid = DB::val('SELECT id FROM at_tickets WHERE reference=?', [strtoupper($ref)]); if (!$tid) { flash('Ticket introuvable : ' . $ref, 'danger'); redirect("at/stock/$id"); } }
        $err = Tickets::stockMove((int)$id, $kind, (int)$this->in('qty', 0), $tid ? (int)$tid : null, Auth::id(), trim((string)$this->in('note', '')), can('at.manage') ? $this->costIn('cost') : null);
        if ($err) flash($err, 'danger'); else { Audit::log('move', 'at_stock', $id, null, ['kind' => $kind, 'qty' => (int)$this->in('qty')]); flash('Mouvement enregistré.'); }
        redirect("at/stock/$id");
    }
    /** Consommation d'une pièce depuis un ticket. */
    function useParts(string $id): void {
        $t = DB::one('SELECT * FROM at_tickets WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return; }
        $err = Tickets::stockMove((int)$this->in('item_id'), 'out', (int)$this->in('qty', 0), (int)$id, Auth::id(), 'Utilisé sur ' . $t['reference']);
        if ($err) flash($err, 'danger'); else { Tickets::event((int)$id, 'part', 'Pièce utilisée : ' . (int)$this->in('qty') . ' × ' . DB::val('SELECT label FROM at_stock WHERE id=?', [(int)$this->in('item_id')]), Auth::id()); flash('Pièce enregistrée sur le ticket.'); }
        redirect("at/$id");
    }

    // ---- Fournisseurs et commandes
    function suppliers(): void { $this->view('at/suppliers', ['title' => 'Fournisseurs', 'rows' => DB::all('SELECT s.*, (SELECT COUNT(*) FROM at_orders o WHERE o.supplier_id=s.id) no FROM at_suppliers s ORDER BY s.active DESC, s.name')]); }
    private function supplierData(): array {
        return $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'contact' => ['label' => 'Le contact', 'max' => 150], 'phone' => ['label' => 'Le téléphone', 'max' => 40], 'email' => ['label' => 'L\'e-mail', 'max' => 190, 'email' => true]], $_POST);
    }
    function storeSupplier(): void {
        [$d, $err] = $this->supplierData(); if (!$err && DB::val('SELECT 1 FROM at_suppliers WHERE name=?', [$d['name']])) $err['n'] = 'Ce fournisseur existe déjà.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('at/suppliers'); }
        $id = DB::insert('at_suppliers', $d + ['active' => 1]); Audit::log('create', 'at_supplier', $id, null, $d); flash('Fournisseur ajouté.'); redirect('at/suppliers');
    }
    function updateSupplier(string $id): void {
        $o = DB::one('SELECT * FROM at_suppliers WHERE id=?', [(int)$id]); if (!$o) { $this->notFound(); return; }
        [$d, $err] = $this->supplierData(); if (!$err && DB::val('SELECT 1 FROM at_suppliers WHERE name=? AND id<>?', [$d['name'], (int)$id])) $err['n'] = 'Ce nom existe déjà.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('at/suppliers'); }
        $d['active'] = $this->in('active') === '1' ? 1 : 0; DB::update('at_suppliers', $d, 'id=?', [(int)$id]); Audit::log('update', 'at_supplier', $id, $o, $d); flash('Fournisseur enregistré.'); redirect('at/suppliers');
    }
    function orders(): void {
        $this->view('at/orders', ['title' => 'Commandes', 'suppliers' => DB::all('SELECT id, name FROM at_suppliers WHERE active=1 ORDER BY name'),
            'p' => paginate('at_orders o JOIN at_suppliers s ON s.id=o.supplier_id', [], $this->page(), 25, 'o.*, s.name supplier, (SELECT COUNT(*) FROM at_order_lines l WHERE l.order_id=o.id) nl, (SELECT COALESCE(SUM(l.qty*l.unit_cost),0) FROM at_order_lines l WHERE l.order_id=o.id) total', 'o.id DESC')]);
    }
    function storeOrder(): void {
        $sup = (int)$this->in('supplier_id'); if (!DB::val('SELECT 1 FROM at_suppliers WHERE id=? AND active=1', [$sup])) { flash('Choisissez un fournisseur actif.', 'danger'); redirect('at/orders'); }
        $last = DB::val('SELECT reference FROM at_orders WHERE reference LIKE ? ORDER BY id DESC LIMIT 1', ['CMD-' . date('y') . '-%']); $n = $last ? (int)substr($last, -5) + 1 : 1;
        $id = DB::insert('at_orders', ['reference' => 'CMD-' . date('y') . '-' . str_pad((string)$n, 5, '0', STR_PAD_LEFT), 'supplier_id' => $sup, 'status' => 'draft', 'note' => mb_substr(trim((string)$this->in('note', '')), 0, 300) ?: null, 'created_by' => Auth::id(), 'created_at' => now()]);
        Audit::log('create', 'at_order', $id, null, ['supplier' => $sup]); flash('Commande créée en brouillon : ajoutez les lignes.'); redirect("at/orders/$id");
    }
    function order(string $id): void {
        $o = DB::one('SELECT o.*, s.name supplier, u.name creator FROM at_orders o JOIN at_suppliers s ON s.id=o.supplier_id LEFT JOIN users u ON u.id=o.created_by WHERE o.id=?', [(int)$id]); if (!$o) { $this->notFound(); return; }
        $this->view('at/order', ['title' => $o['reference'], 'o' => $o, 'lines' => DB::all('SELECT l.*, i.sku, i.label, i.unit, i.qty stock FROM at_order_lines l JOIN at_stock i ON i.id=l.item_id WHERE l.order_id=? ORDER BY l.id', [(int)$id]),
            'items' => DB::all('SELECT id, sku, label, unit_cost FROM at_stock WHERE active=1 ORDER BY label')]);
    }
    private function draftOrder(string $id): ?array { $o = DB::one('SELECT * FROM at_orders WHERE id=?', [(int)$id]); if (!$o) { $this->notFound(); return null; } if ($o['status'] !== 'draft') { flash('Seule une commande en brouillon peut être modifiée.', 'warning'); redirect("at/orders/$id"); } return $o; }
    function addLine(string $id): void {
        if (!($o = $this->draftOrder($id))) return;
        $it = DB::one('SELECT * FROM at_stock WHERE id=? AND active=1', [(int)$this->in('item_id')]); $q = (int)$this->in('qty', 0); $c = $this->costIn('unit_cost');
        if (!$it || $q < 1 || $q > 1000000) { flash('Choisissez un article et une quantité valide.', 'danger'); redirect("at/orders/$id"); }
        if (DB::val('SELECT 1 FROM at_order_lines WHERE order_id=? AND item_id=?', [(int)$id, (int)$it['id']])) { flash('Cet article figure déjà dans la commande.', 'warning'); redirect("at/orders/$id"); }
        DB::insert('at_order_lines', ['order_id' => (int)$id, 'item_id' => (int)$it['id'], 'qty' => $q, 'unit_cost' => $c ?? ($it['unit_cost'] !== null ? (float)$it['unit_cost'] : null), 'received_qty' => 0]); flash('Ligne ajoutée.'); redirect("at/orders/$id");
    }
    function deleteLine(string $id, string $lid): void { if (!$this->draftOrder($id)) return; DB::pdo()->prepare('DELETE FROM at_order_lines WHERE id=? AND order_id=?')->execute([(int)$lid, (int)$id]); flash('Ligne supprimée.'); redirect("at/orders/$id"); }
    /** Ajoute les articles au niveau d'alerte (du fournisseur de la commande ou sans fournisseur) avec une quantité proposée, à ajuster. */
    function suggest(string $id): void {
        if (!($o = $this->draftOrder($id))) return; $n = 0;
        foreach (DB::all('SELECT * FROM at_stock WHERE active=1 AND min_qty>0 AND qty<=min_qty AND (supplier_id=? OR supplier_id IS NULL)', [(int)$o['supplier_id']]) as $it) {
            if (DB::val('SELECT 1 FROM at_order_lines WHERE order_id=? AND item_id=?', [(int)$id, (int)$it['id']])) continue;
            DB::insert('at_order_lines', ['order_id' => (int)$id, 'item_id' => (int)$it['id'], 'qty' => max(1, 2 * (int)$it['min_qty'] - (int)$it['qty']), 'unit_cost' => $it['unit_cost'], 'received_qty' => 0]); $n++;
        }
        flash($n ? "$n ligne(s) proposée(s) (de quoi atteindre deux fois le seuil) : ajustez-les si besoin." : 'Aucun article sous le seuil pour ce fournisseur.', $n ? 'success' : 'info'); redirect("at/orders/$id");
    }
    function orderStatus(string $id): void {
        $o = DB::one('SELECT * FROM at_orders WHERE id=?', [(int)$id]); if (!$o) { $this->notFound(); return; } $a = (string)$this->in('action');
        if ($a === 'order' && $o['status'] === 'draft') {
            if (!DB::val('SELECT 1 FROM at_order_lines WHERE order_id=?', [(int)$id])) { flash('Ajoutez au moins une ligne.', 'danger'); redirect("at/orders/$id"); }
            DB::update('at_orders', ['status' => 'ordered', 'ordered_at' => now()], 'id=?', [(int)$id]); $m = 'Commande marquée comme passée.';
        } elseif ($a === 'cancel' && in_array($o['status'], ['draft', 'ordered'], true)) {
            if (DB::val('SELECT 1 FROM at_order_lines WHERE order_id=? AND received_qty>0', [(int)$id])) { flash('Des articles ont déjà été reçus : la commande ne peut plus être annulée.', 'danger'); redirect("at/orders/$id"); }
            DB::update('at_orders', ['status' => 'cancelled', 'closed_at' => now()], 'id=?', [(int)$id]); $m = 'Commande annulée.';
        } else { flash('Action impossible dans l\'état actuel.', 'danger'); redirect("at/orders/$id"); }
        Audit::log($a, 'at_order', $id, ['status' => $o['status']]); flash($m); redirect("at/orders/$id");
    }
    function receive(string $id): void {
        $o = DB::one('SELECT * FROM at_orders WHERE id=?', [(int)$id]); if (!$o) { $this->notFound(); return; } if ($o['status'] !== 'ordered') { flash('Seule une commande passée peut être réceptionnée.', 'warning'); redirect("at/orders/$id"); }
        $n = 0; $err = [];
        foreach (DB::all('SELECT * FROM at_order_lines WHERE order_id=?', [(int)$id]) as $l) {
            $q = (int)($_POST['recv'][$l['id']] ?? 0); if ($q <= 0) continue; $left = (int)$l['qty'] - (int)$l['received_qty'];
            if ($q > $left) { $err[] = "Quantité reçue supérieure au reste à recevoir ($left)."; continue; }
            if ($e = Tickets::stockMove((int)$l['item_id'], 'in', $q, null, Auth::id(), 'Réception ' . $o['reference'], $l['unit_cost'] !== null ? (float)$l['unit_cost'] : null)) { $err[] = $e; continue; }
            DB::update('at_order_lines', ['received_qty' => (int)$l['received_qty'] + $q], 'id=?', [(int)$l['id']]); $n++;
        }
        if (!DB::val('SELECT 1 FROM at_order_lines WHERE order_id=? AND received_qty<qty', [(int)$id])) DB::update('at_orders', ['status' => 'received', 'closed_at' => now()], 'id=?', [(int)$id]);
        Audit::log('receive', 'at_order', $id, null, ['lines' => $n]);
        flash(($n ? "$n ligne(s) réceptionnée(s), stock mis à jour." : 'Aucune quantité saisie.') . ($err ? ' ' . implode(' ', $err) : ''), $err || !$n ? 'warning' : 'success'); redirect("at/orders/$id");
    }
    /** Données du panneau d'escalade de la fiche ticket (agents seulement). */
    private function escData(array $t): array {
        return ['groups' => DB::all('SELECT g.*, (SELECT COUNT(*) FROM at_group_members m WHERE m.group_id=g.id) n FROM at_groups g WHERE g.active=1 ORDER BY g.tier, g.name'),
            'members' => DB::all('SELECT m.group_id, u.id, u.name FROM at_group_members m JOIN users u ON u.id=m.user_id WHERE u.status=\'active\' ORDER BY u.name'),
            'suppliers' => DB::all('SELECT id, name, email FROM at_suppliers WHERE active=1 ORDER BY name'),
            'contacts' => DB::all('SELECT * FROM at_contacts WHERE active=1 ORDER BY (category=?) DESC, kind, level, name', [(string)$t['category']]),
            'log' => DB::all('SELECT e.*, u.name by_name, g.name group_name, s.name supplier_name, c.name contact_name, tu.name target_name FROM at_escalations e LEFT JOIN users u ON u.id=e.created_by LEFT JOIN at_groups g ON g.id=e.group_id LEFT JOIN at_suppliers s ON s.id=e.supplier_id LEFT JOIN at_contacts c ON c.id=e.contact_id LEFT JOIN users tu ON tu.id=e.target_user_id WHERE e.ticket_id=? ORDER BY e.id', [(int)$t['id']]),
            'group' => $t['group_id'] ? DB::val('SELECT name FROM at_groups WHERE id=?', [(int)$t['group_id']]) : null, 'supplier' => $t['ext_supplier_id'] ? DB::val('SELECT name FROM at_suppliers WHERE id=?', [(int)$t['ext_supplier_id']]) : null];
    }
}
