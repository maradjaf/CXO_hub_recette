<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Meet, Notifier, RichHtml, Rn};

/** Compte rendu de réunion (rédaction, versions, validation, diffusion) et décisions. */
class RnMinutesController extends Controller {
    private function meeting(string $id, bool $manage = false): ?array {
        if (!Rn::on()) { $this->notFound(); return null; } $m = DB::one('SELECT * FROM rn_meetings WHERE id=?', [(int)$id]);
        if (!$m || !Rn::sees($m)) { $this->notFound(); return null; } if ($manage && !Rn::manages($m)) { $this->forbidden(); return null; } return $m;
    }
    function show(string $id): void {
        $m = $this->meeting($id); if (!$m) return; $mgr = Rn::manages($m);
        if (!$mgr && $m['minutes_status'] !== 'sent') { flash('Le compte rendu n\'est pas encore diffusé.', 'info'); redirect('rn/' . $id); }
        $ver = (int)($_GET['v'] ?? 0); $v = $ver && $mgr ? DB::one('SELECT * FROM rn_minutes_versions WHERE meeting_id=? AND version=?', [(int)$id, $ver]) : null;
        $this->view('rn/minutes', ['title' => 'Compte rendu · ' . $m['ref'], 'm' => $m, 'html' => $v ? $v['html'] : $m['minutes_html'], 'ver' => $v, 'manage' => $mgr, 'dec' => Rn::decisions((int)$id), 'act' => Rn::actions((int)$id),
            'versions' => $mgr ? DB::all('SELECT v.version, v.created_at, v.note, u.name uname FROM rn_minutes_versions v LEFT JOIN users u ON u.id=v.user_id WHERE v.meeting_id=? ORDER BY v.version DESC', [(int)$id]) : [],
            'validator' => $m['minutes_validated_by'] ? DB::val('SELECT name FROM users WHERE id=?', [(int)$m['minutes_validated_by']]) : null, 'author' => $m['minutes_by'] ? DB::val('SELECT name FROM users WHERE id=?', [(int)$m['minutes_by']]) : null]);
    }
    function edit(string $id): void {
        $m = $this->meeting($id, true); if (!$m) return;
        if ($m['status'] === 'cancelled') { flash('Réunion annulée : pas de compte rendu.', 'warning'); redirect('rn/' . $id); }
        if ($m['status'] === 'planned') { flash('Marquez d\'abord la réunion comme tenue (et enregistrez les présences).', 'warning'); redirect('rn/' . $id . '#tenue'); }
        $this->view('rn/minutes_edit', ['title' => 'Rédiger le compte rendu · ' . $m['ref'], 'm' => $m, 'html' => $m['minutes_html'] ?: Rn::template($m), 'dec' => Rn::decisions((int)$id), 'act' => Rn::actions((int)$id)]);
    }
    function save(string $id): void {
        $m = $this->meeting($id, true); if (!$m || $m['status'] !== 'held') { if ($m) { flash('Réunion non tenue.', 'warning'); redirect('rn/' . $id); } return; }
        $html = RichHtml::clean((string)$this->in('minutes'), 200000); if (RichHtml::text($html) === '') { flash('Le compte rendu est vide.', 'danger'); redirect('rn/' . $id . '/minutes/edit'); }
        if ($html === (string)$m['minutes_html'] && $m['minutes_status'] !== 'none') { flash('Aucune modification.', 'info'); redirect('rn/' . $id . '/minutes'); }
        $v = (int)$m['minutes_version'] + 1; $was = $m['minutes_status'];
        DB::insert('rn_minutes_versions', ['meeting_id' => (int)$id, 'version' => $v, 'html' => $html, 'user_id' => Auth::id(), 'note' => mb_substr(trim((string)$this->in('note')), 0, 200) ?: null, 'created_at' => now()]);
        DB::update('rn_meetings', ['minutes_html' => $html, 'minutes_version' => $v, 'minutes_status' => 'draft', 'minutes_by' => Auth::id(), 'minutes_validated_by' => null, 'minutes_validated_at' => null, 'updated_at' => now()], 'id=?', [(int)$id]);
        Rn::event((int)$id, 'minutes', 'Compte rendu enregistré (version ' . $v . ')' . ($was === 'validated' || $was === 'sent' ? ' — validation à refaire' : '') . '.'); Audit::log('update', 'rn_minutes', $id, null, ['version' => $v]);
        flash('Compte rendu enregistré (version ' . $v . ', brouillon).' . ($was === 'sent' ? ' Il devra être validé puis rediffusé.' : '')); redirect('rn/' . $id . '/minutes');
    }
    function approve(string $id): void {
        $m = $this->meeting($id, true); if (!$m) return; if ($m['minutes_status'] !== 'draft') { flash('Seul un brouillon peut être validé.', 'warning'); redirect('rn/' . $id . '/minutes'); }
        if (\App\Core\Xchg::on('rn.four_eyes') && (int)$m['minutes_by'] === (int)Auth::id()) { flash('Réglage actif : le compte rendu doit être validé par une autre personne que son rédacteur.', 'warning'); redirect('rn/' . $id . '/minutes'); }
        DB::update('rn_meetings', ['minutes_status' => 'validated', 'minutes_validated_by' => Auth::id(), 'minutes_validated_at' => now(), 'updated_at' => now()], 'id=?', [(int)$id]); Rn::event((int)$id, 'minutes', 'Compte rendu validé (version ' . (int)$m['minutes_version'] . ').'); Audit::log('validate', 'rn_minutes', $id);
        flash('Compte rendu validé. Vous pouvez le diffuser.'); redirect('rn/' . $id . '/minutes');
    }
    function send(string $id): void {
        $m = $this->meeting($id, true); if (!$m) return; if (!in_array($m['minutes_status'], ['validated', 'sent'], true)) { flash('Validez le compte rendu avant de le diffuser.', 'warning'); redirect('rn/' . $id . '/minutes'); }
        [$extra, $err] = Meet::parseExtra((string)$this->in('extra')); if ($err) { flash(implode(' ', $err), 'danger'); redirect('rn/' . $id . '/minutes'); } $extra = array_filter($extra, fn($x) => $x['email'] || $x['phone']);
        DB::update('rn_meetings', ['minutes_status' => 'sent', 'minutes_sent_at' => now(), 'updated_at' => now()], 'id=?', [(int)$id]); $n = Rn::distribute((int)$id, $extra);
        Rn::event((int)$id, 'minutes', 'Compte rendu diffusé (version ' . (int)$m['minutes_version'] . ') à ' . $n . ' destinataire(s).'); Audit::log('send', 'rn_minutes', $id, null, ['to' => $n]); flash("Compte rendu diffusé à $n destinataire(s)."); redirect('rn/' . $id . '/minutes');
    }
    function reopen(string $id): void {
        $m = $this->meeting($id, true); if (!$m) return; if (!in_array($m['minutes_status'], ['validated', 'sent'], true)) { redirect('rn/' . $id . '/minutes'); }
        DB::update('rn_meetings', ['minutes_status' => 'draft', 'minutes_validated_by' => null, 'minutes_validated_at' => null, 'updated_at' => now()], 'id=?', [(int)$id]); Rn::event((int)$id, 'minutes', 'Compte rendu rouvert pour modification.'); redirect('rn/' . $id . '/minutes/edit');
    }
    // --- décisions ---
    function decisionAdd(string $id): void {
        $m = $this->meeting($id, true); if (!$m) return; $t = trim((string)$this->in('text')); if ($t === '' || mb_strlen($t) > 600) { flash('Décision : 1 à 600 caractères.', 'danger'); redirect('rn/' . $id . '#decisions'); }
        $o = (int)$this->in('owner_id', 0) ?: null; DB::insert('rn_decisions', ['meeting_id' => (int)$id, 'position' => (int)DB::val('SELECT COALESCE(MAX(position),0)+1 FROM rn_decisions WHERE meeting_id=?', [(int)$id]), 'text' => $t, 'owner_id' => $o, 'status' => 'active', 'created_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()]);
        Rn::event((int)$id, 'decision', 'Décision ajoutée : ' . mb_substr($t, 0, 120)); flash('Décision ajoutée.'); redirect('rn/' . $id . '#decisions');
    }
    private function dec(string $did): ?array { $d = DB::one('SELECT * FROM rn_decisions WHERE id=?', [(int)$did]); if (!$d || !$this->meeting((string)$d['meeting_id'], true)) return null; return $d; }
    function decisionUpdate(string $did): void {
        $d = $this->dec($did); if (!$d) return; $st = (string)$this->in('status'); $t = trim((string)$this->in('text', $d['text'])); if (!isset(Rn::DEC[$st])) $st = $d['status']; if ($t === '' || mb_strlen($t) > 600) $t = $d['text'];
        DB::update('rn_decisions', ['status' => $st, 'text' => $t, 'owner_id' => (int)$this->in('owner_id', (int)$d['owner_id']) ?: null, 'updated_at' => now()], 'id=?', [(int)$did]); Rn::event((int)$d['meeting_id'], 'decision', 'Décision mise à jour (' . Rn::DEC[$st] . ') : ' . mb_substr($t, 0, 100)); redirect('rn/' . $d['meeting_id'] . '#decisions');
    }
    function decisionDelete(string $did): void {
        $d = $this->dec($did); if (!$d) return; DB::update('rn_actions', ['decision_id' => null], 'decision_id=?', [(int)$did]); DB::exec('DELETE FROM rn_decisions WHERE id=?', [(int)$did]); Rn::event((int)$d['meeting_id'], 'decision', 'Décision supprimée.'); redirect('rn/' . $d['meeting_id'] . '#decisions');
    }
}
