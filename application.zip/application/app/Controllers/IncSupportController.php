<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Mailer, Sms, Inc, IncEsc};

/**
 * Administration des équipes support (annuaire, rôles, coordonnées, canaux de notification, accès à l'outil),
 * vue d'ensemble des escalades et pilotage des escalades depuis la fiche d'un incident.
 * Le personnel support n'est pas dans la table des collaborateurs : il n'entre dans aucun plan RH.
 */
class IncSupportController extends Controller {
    private function period(): array {
        $to = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($_GET['to'] ?? '')) ? $_GET['to'] : date('Y-m-d');
        $from = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($_GET['from'] ?? '')) ? $_GET['from'] : date('Y-m-d', strtotime($to . ' -89 days'));
        return $from > $to ? [$to, $from] : [$from, $to];
    }
    // ------------------------------------------------------------------ Vue d'ensemble des escalades
    function escalations(): void {
        [$from, $to] = $this->period(); $team = (int)($_GET['team_id'] ?? 0); $status = (string)($_GET['status'] ?? '');
        $stats = IncEsc::stats($from, $to, $team ? [$team] : null);
        $w = 'e.escalated_at>=? AND e.escalated_at<=?'; $p = [$from . ' 00:00:00', $to . ' 23:59:59'];
        if ($team) { $w .= ' AND e.team_id=?'; $p[] = $team; }
        if ($status === 'open') $w .= " AND e.status IN ('pending','ack','working')"; elseif (isset(IncEsc::STATUS[$status])) { $w .= ' AND e.status=?'; $p[] = $status; }
        $rows = DB::all("SELECT e.*, i.reference, i.title, i.severity, i.status AS istatus, i.started_at, t.name AS team_name, u.name AS by_name FROM inc_escalations e JOIN inc_incidents i ON i.id=e.incident_id JOIN inc_support_teams t ON t.id=e.team_id LEFT JOIN users u ON u.id=e.acked_by WHERE $w ORDER BY CASE WHEN e.status IN ('pending','ack','working') THEN 0 ELSE 1 END, e.escalated_at DESC LIMIT 300", $p);
        $logs = DB::all('SELECT l.*, i.reference FROM inc_notif_log l LEFT JOIN inc_incidents i ON i.id=l.incident_id ORDER BY l.id DESC LIMIT 40');
        $chan = DB::all("SELECT channel, status, COUNT(*) AS n FROM inc_notif_log WHERE created_at>=? AND created_at<=? GROUP BY channel, status", [$from . ' 00:00:00', $to . ' 23:59:59']);
        $this->view('incidents/escalations', ['title' => 'Escalades vers les équipes support', 'from' => $from, 'to' => $to, 'team' => $team, 'status' => $status, 'stats' => $stats, 'rows' => $rows, 'logs' => $logs, 'chan' => $chan,
            'teams' => DB::all('SELECT id, name FROM inc_support_teams ORDER BY sort_order, name'), 'mail' => Mailer::enabled(), 'sms' => Sms::enabled(),
            'queued' => ['mail' => (int)DB::val("SELECT COUNT(*) FROM at_outbox WHERE status='pending'"), 'sms' => (int)DB::val("SELECT COUNT(*) FROM sms_outbox WHERE status='pending'")]]);
    }

    // ------------------------------------------------------------------ Annuaire des équipes support
    function teams(): void {
        $teams = DB::all('SELECT t.*, (SELECT COUNT(*) FROM inc_escalations e WHERE e.team_id=t.id) AS used FROM inc_support_teams t ORDER BY t.sort_order, t.name');
        $mem = []; foreach (DB::all('SELECT m.*, u.status AS ustatus, u.email AS uemail FROM inc_support_members m LEFT JOIN users u ON u.id=m.user_id ORDER BY m.active DESC, m.level, m.name') as $m) $mem[(int)$m['team_id']][] = $m;
        $this->view('incidents/support_teams', ['title' => 'Équipes support', 'teams' => $teams, 'mem' => $mem, 'mail' => Mailer::enabled(), 'sms' => Sms::enabled()]);
    }
    function teamSave(?string $id = null): void {
        $old = $id ? DB::one('SELECT * FROM inc_support_teams WHERE id=?', [(int)$id]) : null; if ($id && !$old) { $this->notFound(); return; }
        $code = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string)$this->in('code'))); $name = trim((string)$this->in('name')); $fam = array_values(array_intersect(array_keys(Inc::FAMILIES), (array)($_POST['families'] ?? [])));
        $err = []; if ($code === '' || strlen($code) > 40) $err[] = 'Code obligatoire (lettres, chiffres, tiret, 40 caractères maximum).'; if ($name === '') $err[] = 'Le nom de l\'équipe est obligatoire.';
        if ($code !== '' && DB::val('SELECT 1 FROM inc_support_teams WHERE code=? AND id<>?', [$code, (int)$id])) $err[] = 'Ce code est déjà utilisé.';
        $email = trim((string)$this->in('email')); if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $err[] = 'Adresse e-mail de l\'équipe invalide.';
        $ph = trim((string)$this->in('phone')); if ($ph !== '' && !Sms::normalize($ph)) $err[] = 'Numéro de téléphone de l\'équipe invalide.';
        if ($err) { flash(implode(' ', $err), 'danger'); redirect('incidents/support-teams'); }
        $d = ['code' => $code, 'name' => mb_substr($name, 0, 150), 'families' => implode(',', $fam) ?: null, 'description' => mb_substr(trim((string)$this->in('description')), 0, 300) ?: null, 'email' => $email ?: null, 'phone' => $ph ?: null, 'sort_order' => (int)$this->in('sort_order', 0), 'updated_at' => now()];
        if ($old) { DB::update('inc_support_teams', $d, 'id=?', [(int)$id]); Audit::log('update', 'inc_support_team', $id, $old, $d); }
        else { $nid = DB::insert('inc_support_teams', $d + ['active' => 1, 'created_at' => now()]); Audit::log('create', 'inc_support_team', $nid, null, $d); }
        flash($old ? 'Équipe mise à jour.' : 'Équipe créée.'); redirect('incidents/support-teams');
    }
    function teamToggle(string $id): void {
        $t = DB::one('SELECT * FROM inc_support_teams WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return; }
        DB::update('inc_support_teams', ['active' => $t['active'] ? 0 : 1, 'updated_at' => now()], 'id=?', [(int)$id]); Audit::log('update', 'inc_support_team', $id, ['active' => $t['active']], ['active' => $t['active'] ? 0 : 1]);
        flash($t['active'] ? 'Équipe désactivée : elle ne reçoit plus d\'escalade.' : 'Équipe réactivée.'); redirect('incidents/support-teams');
    }
    function teamDelete(string $id): void {
        $t = DB::one('SELECT * FROM inc_support_teams WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return; }
        if (DB::val('SELECT 1 FROM inc_escalations WHERE team_id=?', [(int)$id]) || DB::val('SELECT 1 FROM inc_support_members WHERE team_id=?', [(int)$id])) { flash('Suppression impossible : l\'équipe a des membres ou un historique d\'escalades. Désactivez-la.', 'danger'); redirect('incidents/support-teams'); }
        DB::exec('DELETE FROM inc_support_teams WHERE id=?', [(int)$id]); Audit::log('delete', 'inc_support_team', $id, $t, null); flash('Équipe supprimée.'); redirect('incidents/support-teams');
    }

    // ------------------------------------------------------------------ Membres
    private function memberData(?array $old): array {
        $err = []; $name = trim((string)$this->in('name')); $role = (string)$this->in('role', 'member'); $level = (int)$this->in('level', 1);
        if ($name === '') $err[] = 'Le nom est obligatoire.'; if (!isset(IncEsc::ROLES[$role])) $err[] = 'Rôle invalide.'; if ($level < 1 || $level > IncEsc::maxLevel()) $err[] = 'Niveau d\'escalade invalide (1 à ' . IncEsc::maxLevel() . ').';
        $email = strtolower(trim((string)$this->in('email'))); if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $err[] = 'Adresse e-mail invalide.';
        $phRaw = trim((string)$this->in('phone')); $ph = $phRaw === '' ? null : Sms::normalize($phRaw); if ($phRaw !== '' && !$ph) $err[] = 'Numéro de téléphone invalide (8 à 15 chiffres, format international conseillé : +228…).';
        $d = ['name' => mb_substr($name, 0, 150), 'role' => $role, 'title' => mb_substr(trim((string)$this->in('title')), 0, 120) ?: null, 'level' => $level, 'email' => $email ?: null, 'phone' => $ph, 'on_call' => $this->in('on_call') === '1' ? 1 : 0,
              'notify_inapp' => $this->in('notify_inapp') === '1' ? 1 : 0, 'notify_email' => $this->in('notify_email') === '1' ? 1 : 0, 'notify_sms' => $this->in('notify_sms') === '1' ? 1 : 0, 'note' => mb_substr(trim((string)$this->in('note')), 0, 300) ?: null, 'updated_at' => now()];
        if ($d['notify_email'] && !$d['email']) $err[] = 'Une adresse e-mail est nécessaire pour recevoir les e-mails.'; if ($d['notify_sms'] && !$d['phone']) $err[] = 'Un numéro de téléphone est nécessaire pour recevoir les SMS.';
        return [$d, $err];
    }
    private function syncUser(?int $uid): void {
        if (!$uid) return; $u = DB::one('SELECT * FROM users WHERE id=?', [$uid]); if (!$u || $u['employee_id']) return;
        if (!DB::val("SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id=? AND r.code='support_member'", [$uid]) || DB::val("SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id=? AND r.code<>'support_member'", [$uid])) return;   // jamais un compte à rôles multiples
        $act = (bool)DB::val('SELECT 1 FROM inc_support_members WHERE user_id=? AND active=1', [$uid]);
        if (($u['status'] === 'active') !== $act) DB::update('users', ['status' => $act ? 'active' : 'inactive', 'updated_at' => now()], 'id=?', [$uid]);
    }
    /** Crée (ou rattache) le compte d'accès limité d'un membre. @return array{0:bool,1:string} succès, message */
    private function grant(array $m): array {
        $email = strtolower((string)$m['email']); if ($email === '') return [false, 'Renseignez l\'adresse e-mail du membre pour lui créer un accès.'];
        $rid = (int)DB::val("SELECT id FROM roles WHERE code='support_member'"); if (!$rid) return [false, 'Rôle « Intervenant support » introuvable (lancez bin/upgrade.php).'];
        $u = DB::one('SELECT * FROM users WHERE email=?', [$email]);
        if ($u) {
            if ($u['employee_id'] || DB::val("SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id=? AND r.code<>'support_member'", [(int)$u['id']])) return [false, 'Cette adresse correspond déjà à un compte de la direction : utilisez une autre adresse pour l\'accès support.'];
            DB::update('inc_support_members', ['user_id' => (int)$u['id']], 'id=?', [(int)$m['id']]); $this->syncUser((int)$u['id']); return [true, 'Compte existant rattaché au membre.'];
        }
        $pw = UsersController::tempPassword();
        $uid = DB::insert('users', ['email' => $email, 'name' => $m['name'], 'password_hash' => password_hash($pw, PASSWORD_DEFAULT), 'status' => 'active', 'must_change_password' => 1, 'created_at' => now(), 'updated_at' => now()]);
        DB::insert('user_roles', ['user_id' => $uid, 'role_id' => $rid]); DB::update('inc_support_members', ['user_id' => $uid], 'id=?', [(int)$m['id']]);
        Audit::log('create', 'user', $uid, null, ['email' => $email, 'role' => 'support_member', 'source' => 'inc_support_member']);
        return [true, "Accès créé pour {$m['name']} ($email). Mot de passe provisoire (à transmettre, affiché une seule fois) : <code>$pw</code>"];
    }
    function memberAdd(string $id): void { $this->memberSave($id, null); }
    function memberUpdate(string $mid): void { $m = DB::one('SELECT team_id FROM inc_support_members WHERE id=?', [(int)$mid]); if (!$m) { $this->notFound(); return; } $this->memberSave((string)$m['team_id'], $mid); }
    private function memberSave(string $id, ?string $mid): void {
        $team = DB::one('SELECT * FROM inc_support_teams WHERE id=?', [(int)$id]); $old = $mid ? DB::one('SELECT * FROM inc_support_members WHERE id=?', [(int)$mid]) : null;
        if (!$team || ($mid && !$old)) { $this->notFound(); return; }
        [$d, $err] = $this->memberData($old);
        if (!$err && $d['email']) { $ex = DB::one('SELECT id FROM users WHERE email=? AND id<>?', [$d['email'], (int)($old['user_id'] ?? 0)]); if ($old && $old['user_id'] && $ex) $err[] = 'Cette adresse est déjà utilisée par un autre compte.'; }
        if ($err) { flash(implode(' ', $err), 'danger'); redirect('incidents/support-teams#t' . $id); }
        if ($old) {
            DB::update('inc_support_members', $d, 'id=?', [(int)$mid]); Audit::log('update', 'inc_support_member', $mid, $old, $d);
            if ($old['user_id'] && !DB::val('SELECT employee_id FROM users WHERE id=?', [(int)$old['user_id']])) DB::update('users', ['name' => $d['name']] + ($d['email'] ? ['email' => $d['email']] : []) + ['updated_at' => now()], 'id=?', [(int)$old['user_id']]);
            flash('Membre mis à jour.');
        } else {
            $nid = DB::insert('inc_support_members', $d + ['team_id' => (int)$id, 'active' => 1, 'created_at' => now()]); Audit::log('create', 'inc_support_member', $nid, null, $d);
            $msg = 'Membre ajouté.'; if ($this->in('create_access') === '1') { [$ok, $m2] = $this->grant(DB::one('SELECT * FROM inc_support_members WHERE id=?', [$nid])); $msg .= ' ' . $m2; flash($msg, $ok ? 'success' : 'warning'); redirect('incidents/support-teams#t' . $id); }
            flash($msg);
        }
        redirect('incidents/support-teams#t' . $id);
    }
    function memberToggle(string $mid): void {
        $m = DB::one('SELECT * FROM inc_support_members WHERE id=?', [(int)$mid]); if (!$m) { $this->notFound(); return; }
        DB::update('inc_support_members', ['active' => $m['active'] ? 0 : 1, 'updated_at' => now()], 'id=?', [(int)$mid]); $this->syncUser($m['user_id'] ? (int)$m['user_id'] : null);
        Audit::log('update', 'inc_support_member', $mid, ['active' => $m['active']], ['active' => $m['active'] ? 0 : 1]);
        flash($m['active'] ? 'Membre désactivé : plus de notification, accès à l\'outil suspendu.' : 'Membre réactivé.'); redirect('incidents/support-teams#t' . $m['team_id']);
    }
    function memberDelete(string $mid): void {
        $m = DB::one('SELECT * FROM inc_support_members WHERE id=?', [(int)$mid]); if (!$m) { $this->notFound(); return; }
        if (DB::val('SELECT 1 FROM inc_notif_log WHERE member_id=?', [(int)$mid])) { flash('Suppression impossible : ce membre a déjà reçu des notifications (traçabilité). Désactivez-le.', 'danger'); redirect('incidents/support-teams#t' . $m['team_id']); }
        DB::exec('DELETE FROM inc_support_members WHERE id=?', [(int)$mid]); $this->syncUser($m['user_id'] ? (int)$m['user_id'] : null); Audit::log('delete', 'inc_support_member', $mid, $m, null);
        flash('Membre supprimé.'); redirect('incidents/support-teams#t' . $m['team_id']);
    }
    function memberAccess(string $mid): void {
        $m = DB::one('SELECT * FROM inc_support_members WHERE id=?', [(int)$mid]); if (!$m) { $this->notFound(); return; }
        if ($m['user_id'] && $this->in('act') === 'reset') {
            $u = DB::one('SELECT * FROM users WHERE id=?', [(int)$m['user_id']]); if (!$u || $u['employee_id']) { flash('Réinitialisation impossible pour ce compte.', 'danger'); redirect('incidents/support-teams#t' . $m['team_id']); }
            $pw = UsersController::tempPassword(); DB::update('users', ['password_hash' => password_hash($pw, PASSWORD_DEFAULT), 'must_change_password' => 1, 'failed_attempts' => 0, 'locked_until' => null, 'updated_at' => now()], 'id=?', [(int)$u['id']]);
            Audit::log('update', 'user', $u['id'], null, ['reset_password' => true]); flash("Nouveau mot de passe provisoire pour {$m['name']} (affiché une seule fois) : <code>$pw</code>", 'success');
        } elseif ($m['user_id']) flash('Ce membre a déjà un accès.', 'warning');
        else { [$ok, $msg] = $this->grant($m); flash($msg, $ok ? 'success' : 'danger'); }
        redirect('incidents/support-teams#t' . $m['team_id']);
    }
    /** Envoie un message de test sur les canaux choisis par le membre. */
    function memberTest(string $mid): void {
        $m = DB::one('SELECT * FROM inc_support_members WHERE id=?', [(int)$mid]); if (!$m) { $this->notFound(); return; }
        $t = 'Test de notification · gestion des incidents'; $b = 'Ceci est un test envoyé par ' . Auth::user()['name'] . '. Aucune action n\'est attendue.'; $o = [];
        if ($m['notify_inapp']) { if ($m['user_id']) { Notifier::send((int)$m['user_id'], $t, $b, '/support'); $o[] = 'dans l\'outil : envoyé'; } else $o[] = 'dans l\'outil : pas de compte d\'accès'; }
        if ($m['notify_email']) $o[] = 'e-mail : ' . (!$m['email'] ? 'pas d\'adresse' : (Mailer::queue($m['email'], $t, $b) ? 'en file d\'envoi' : 'non configuré (SMTP_HOST)'));
        if ($m['notify_sms']) $o[] = 'SMS : ' . (!Sms::normalize($m['phone']) ? 'numéro invalide' : (Sms::queue((string)$m['phone'], 'TEST ' . $t) ? 'en file d\'envoi' : 'non configuré (SMS_GATEWAY_URL)'));
        flash('Test pour ' . e($m['name']) . ' — ' . ($o ? implode(' ; ', $o) : 'aucun canal activé pour ce membre.'), 'info'); redirect('incidents/support-teams#t' . $m['team_id']);
    }

    // ------------------------------------------------------------------ Escalade depuis la fiche d'un incident
    function escalate(string $id): void {
        $i = DB::one('SELECT * FROM inc_incidents WHERE id=?', [(int)$id]); if (!$i) { $this->notFound(); return; }
        $teams = array_map('intval', (array)($_POST['team_ids'] ?? [])); $lvl = max(1, (int)$this->in('level', 1)); $reason = trim((string)$this->in('reason'));
        if (!$teams) { flash('Choisissez au moins une équipe support.', 'danger'); redirect('incidents/' . $id . '#escalade'); }
        if (in_array($i['status'], ['closed', 'cancelled'], true)) { flash('Incident clos ou annulé : escalade impossible.', 'danger'); redirect('incidents/' . $id); }
        $ok = 0; foreach ($teams as $t) if (IncEsc::open($i, $t, $lvl, $reason, (int)Auth::id())) $ok++;
        Audit::log('escalate', 'incident', $id, null, ['teams' => $teams, 'level' => $lvl]);
        flash($ok ? "$ok équipe(s) sollicitée(s) — notifications envoyées selon les préférences de chaque membre." : 'Aucune escalade créée (équipe inactive ou déjà sollicitée sur cet incident).', $ok ? 'success' : 'warning'); redirect('incidents/' . $id . '#escalade');
    }
    function escNext(string $id, string $eid): void {
        $e = DB::one('SELECT * FROM inc_escalations WHERE id=? AND incident_id=?', [(int)$eid, (int)$id]); if (!$e) { $this->notFound(); return; }
        flash(IncEsc::bump((int)$eid, false, (int)Auth::id()) ? 'Escalade portée au niveau supérieur.' : 'Niveau maximum atteint ou escalade déjà terminée.', 'info'); redirect('incidents/' . $id . '#escalade');
    }
    function escClose(string $id, string $eid): void {
        $e = DB::one('SELECT * FROM inc_escalations WHERE id=? AND incident_id=?', [(int)$eid, (int)$id]); if (!$e) { $this->notFound(); return; }
        if (in_array($e['status'], IncEsc::OPEN, true)) { DB::update('inc_escalations', ['status' => 'closed', 'done_at' => now()], 'id=?', [(int)$eid]); Inc::event((int)$id, 'escalade', 'Escalade retirée (équipe « ' . (string)DB::val('SELECT name FROM inc_support_teams WHERE id=?', [(int)$e['team_id']]) . ' »).'); }
        flash('Escalade retirée.'); redirect('incidents/' . $id . '#escalade');
    }
}
