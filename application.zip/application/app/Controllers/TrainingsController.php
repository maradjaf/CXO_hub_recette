<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier};
class TrainingsController extends Controller {
    const ES = ['registered' => 'Inscrit', 'attended' => 'Présent', 'absent' => 'Absent', 'passed' => 'Validé', 'failed' => 'Non validé'];
    function index(): void {
        $pg = paginate('trainings t', [], $this->page(), 25, "t.*, (SELECT COUNT(*) FROM training_sessions s WHERE s.training_id=t.id AND s.status='planned') planned", 't.active DESC, t.title');
        $this->view('training/index', ['title' => 'Formations', 'rows' => $pg['rows'], 'p' => $pg,
            'upcoming' => DB::all("SELECT s.*, t.title, (SELECT COUNT(*) FROM training_enrollments e WHERE e.session_id=s.id) enrolled FROM training_sessions s JOIN trainings t ON t.id=s.training_id WHERE s.status='planned' AND s.session_date>=? ORDER BY s.session_date LIMIT 12", [date('Y-m-d')])]);
    }
    private function data(?int $id): array {
        [$d, $err] = $this->validate(['code' => ['label' => 'Le code', 'req' => true, 'max' => 40], 'title' => ['label' => 'L\'intitulé', 'req' => true, 'max' => 190], 'category' => ['label' => 'La catégorie', 'max' => 80], 'description' => ['label' => 'La description', 'max' => 1000], 'competence' => ['label' => 'La compétence acquise', 'max' => 300]], $_POST);
        if ($d['code'] && DB::val('SELECT 1 FROM trainings WHERE code=? AND id<>?', [$d['code'], $id ?? 0])) $err['code'] = 'Ce code existe déjà.';
        $d['duration_hours'] = max(0, (float)$this->in('duration_hours', 0)); $d['mandatory'] = isset($_POST['mandatory']) ? 1 : 0; $d['active'] = isset($_POST['active']) || !$id ? 1 : 0;
        $v = (int)$this->in('validity_months', 0); $d['validity_months'] = $v > 0 ? $v : null;
        return [$d, $err];
    }
    function store(): void {
        [$d, $err] = $this->data(null); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('trainings'); }
        $id = DB::insert('trainings', $d); Audit::log('create', 'training', $id, null, $d); flash('Formation ajoutée au catalogue.'); redirect("trainings/$id");
    }
    function show(string $id): void {
        $t = DB::one('SELECT * FROM trainings WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return; }
        $this->view('training/show', ['title' => $t['title'], 't' => $t, 'sessions' => DB::all('SELECT s.*, (SELECT COUNT(*) FROM training_enrollments e WHERE e.session_id=s.id) enrolled, (SELECT COUNT(*) FROM training_enrollments e WHERE e.session_id=s.id AND e.status=\'passed\') passed FROM training_sessions s WHERE s.training_id=? ORDER BY s.session_date DESC', [(int)$id])]);
    }
    function update(string $id): void {
        $o = DB::one('SELECT * FROM trainings WHERE id=?', [(int)$id]); if (!$o) { $this->notFound(); return; }
        [$d, $err] = $this->data((int)$id); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("trainings/$id"); }
        DB::update('trainings', $d, 'id=?', [(int)$id]); Audit::log('update', 'training', $id, $o, $d); flash('Formation enregistrée.'); redirect("trainings/$id");
    }
    function storeSession(string $id): void {
        if (!DB::val('SELECT 1 FROM trainings WHERE id=?', [(int)$id])) { $this->notFound(); return; }
        [$d, $err] = $this->validate(['session_date' => ['label' => 'La date', 'req' => true, 'date' => true], 'location' => ['label' => 'Le lieu', 'max' => 150], 'trainer' => ['label' => 'Le formateur', 'max' => 150]], $_POST);
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("trainings/$id"); }
        $d += ['training_id' => (int)$id, 'capacity' => max(0, (int)$this->in('capacity', 0)) ?: null, 'status' => 'planned', 'created_by' => Auth::id(), 'created_at' => now()];
        $sid = DB::insert('training_sessions', $d); Audit::log('create', 'training_session', $sid, null, $d); flash('Session planifiée.'); redirect("trainings/sessions/$sid");
    }
    function session(string $sid): void {
        $s = DB::one('SELECT s.*, t.title, t.validity_months, t.mandatory, t.duration_hours FROM training_sessions s JOIN trainings t ON t.id=s.training_id WHERE s.id=?', [(int)$sid]); if (!$s) { $this->notFound(); return; }
        $mine = (int)(Auth::user()['employee_id'] ?? 0);
        $enr = DB::all('SELECT en.*, e.first_name, e.last_name, e.matricule FROM training_enrollments en JOIN employees e ON e.id=en.employee_id WHERE en.session_id=? ORDER BY e.last_name', [(int)$sid]);
        if (!can('training.manage')) $enr = array_values(array_filter($enr, fn($x) => (int)$x['employee_id'] === $mine));
        $this->view('training/session', ['title' => $s['title'] . ' · ' . d($s['session_date']), 's' => $s, 'enr' => $enr, 'count' => (int)DB::val('SELECT COUNT(*) FROM training_enrollments WHERE session_id=?', [(int)$sid]),
            'employees' => can('training.manage') ? DB::all("SELECT id, first_name, last_name, matricule FROM employees WHERE status='active' AND id NOT IN (SELECT employee_id FROM training_enrollments WHERE session_id=?) ORDER BY last_name, first_name", [(int)$sid]) : []]);
    }
    function enroll(string $sid): void {
        $s = DB::one('SELECT * FROM training_sessions WHERE id=?', [(int)$sid]); if (!$s) { $this->notFound(); return; }
        if ($s['status'] !== 'planned') { flash('Cette session n\'accepte plus d\'inscriptions.', 'warning'); redirect("trainings/sessions/$sid"); }
        $n = 0; $full = false;
        foreach (array_unique(array_map('intval', (array)($_POST['employee_id'] ?? []))) as $emp) {
            if (!DB::val("SELECT 1 FROM employees WHERE id=? AND status='active'", [$emp]) || DB::val('SELECT 1 FROM training_enrollments WHERE session_id=? AND employee_id=?', [(int)$sid, $emp])) continue;
            if ($s['capacity'] && (int)DB::val('SELECT COUNT(*) FROM training_enrollments WHERE session_id=?', [(int)$sid]) >= (int)$s['capacity']) { $full = true; break; }
            DB::insert('training_enrollments', ['session_id' => (int)$sid, 'employee_id' => $emp, 'status' => 'registered']); $n++;
            if ($u = DB::val('SELECT id FROM users WHERE employee_id=? AND status=?', [$emp, 'active'])) Notifier::send((int)$u, 'Inscription à une formation', DB::val('SELECT title FROM trainings WHERE id=?', [$s['training_id']]) . ' le ' . d($s['session_date']), '/trainings/sessions/' . $sid);
        }
        Audit::log('enroll', 'training_session', $sid, null, ['added' => $n]);
        flash("$n inscription(s) ajoutée(s)." . ($full ? ' Capacité atteinte.' : ''), $full ? 'warning' : 'success'); redirect("trainings/sessions/$sid");
    }
    function results(string $sid): void {
        $s = DB::one('SELECT s.*, t.validity_months FROM training_sessions s JOIN trainings t ON t.id=s.training_id WHERE s.id=?', [(int)$sid]); if (!$s) { $this->notFound(); return; }
        if ($s['status'] === 'cancelled') { flash('Session annulée.', 'warning'); redirect("trainings/sessions/$sid"); }
        foreach (DB::all('SELECT * FROM training_enrollments WHERE session_id=?', [(int)$sid]) as $en) {
            $st = (string)($_POST['status'][$en['id']] ?? $en['status']); if (!isset(self::ES[$st])) continue;
            $score = ($_POST['score'][$en['id']] ?? '') !== '' ? max(0, min(100, (float)$_POST['score'][$en['id']])) : null;
            $valid = $st === 'passed' && $s['validity_months'] ? date('Y-m-d', strtotime($s['session_date'] . ' +' . (int)$s['validity_months'] . ' months')) : null;
            DB::update('training_enrollments', ['status' => $st, 'score' => $score, 'valid_until' => $valid], 'id=?', [$en['id']]);
            if ($st === 'passed') $nProp = ($nProp ?? 0) + \App\Core\Skill::proposeFromEnrollment((int)$en['id']);   // Lot 57 : un résultat Acquis propose le niveau de compétence, à valider
        }
        if (!empty($nProp)) \App\Core\Notifier::toPermission('skills.assess', 'Propositions de niveau de compétence', $nProp . ' proposition(s) issue(s) de la session du ' . d($s['session_date']) . ' à valider', 'skills/proposals');
        $open = (int)DB::val("SELECT COUNT(*) FROM training_enrollments WHERE session_id=? AND status='registered'", [(int)$sid]);
        DB::update('training_sessions', ['status' => $open ? 'planned' : 'done'], 'id=?', [(int)$sid]); \App\Core\Sat::ensureSession((int)$sid);
        Audit::log('results', 'training_session', $sid); flash($open ? 'Résultats enregistrés ; certains inscrits n\'ont pas encore de résultat.' : 'Résultats enregistrés ; session clôturée.'); redirect("trainings/sessions/$sid");
    }
    function cancelSession(string $sid): void {
        $s = DB::one('SELECT * FROM training_sessions WHERE id=?', [(int)$sid]); if (!$s) { $this->notFound(); return; }
        DB::update('training_sessions', ['status' => 'cancelled'], 'id=?', [(int)$sid]); Audit::log('cancel', 'training_session', $sid, $s);
        foreach (DB::all('SELECT u.id FROM training_enrollments en JOIN users u ON u.employee_id=en.employee_id WHERE en.session_id=?', [(int)$sid]) as $u) Notifier::send((int)$u['id'], 'Session de formation annulée', 'La session du ' . d($s['session_date']) . ' est annulée.', '/trainings/sessions/' . $sid);
        flash('Session annulée ; les inscrits sont prévenus.'); redirect("trainings/sessions/$sid");
    }
    /** Collaborateurs actifs sans validation en cours pour une formation obligatoire, ou dont la validation expire sous 60 jours. */
    function needs(): void {
        $today = date('Y-m-d'); $soon = date('Y-m-d', strtotime('+60 days')); $out = [];
        foreach (DB::all('SELECT * FROM trainings WHERE mandatory=1 AND active=1 ORDER BY title') as $t) {
            $ok = "SELECT 1 FROM training_enrollments en WHERE en.employee_id=e.id AND en.status='passed' AND en.session_id IN (SELECT id FROM training_sessions WHERE training_id=?)";
            $missing = DB::all("SELECT e.id, e.first_name, e.last_name, e.matricule, tm.name team_name FROM employees e LEFT JOIN teams tm ON tm.id=e.team_id WHERE e.status='active' AND NOT EXISTS ($ok AND (en.valid_until IS NULL OR en.valid_until>=?)) ORDER BY e.last_name", [$t['id'], $today]);
            $expiring = DB::all("SELECT e.id, e.first_name, e.last_name, e.matricule, MAX(en.valid_until) vu FROM employees e JOIN training_enrollments en ON en.employee_id=e.id AND en.status='passed' AND en.session_id IN (SELECT id FROM training_sessions WHERE training_id=?) WHERE e.status='active' GROUP BY e.id, e.first_name, e.last_name, e.matricule HAVING MAX(en.valid_until)>=? AND MAX(en.valid_until)<=? ORDER BY vu", [$t['id'], $today, $soon]);
            $out[] = ['t' => $t, 'missing' => $missing, 'expiring' => $expiring];
        }
        $this->view('training/needs', ['title' => 'Besoins de formation', 'groups' => $out]);
    }
}
