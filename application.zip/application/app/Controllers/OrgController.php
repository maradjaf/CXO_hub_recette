<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit};
/** Équipes, stores, canaux, postes : une seule logique pour les quatre listes de l'organisation. */
class OrgController extends Controller {
    const ENT = [
        'teams' => ['label' => 'Équipes', 'one' => 'équipe', 'fields' => ['code' => ['Code', 'text', 40], 'name' => ['Nom', 'text', 150], 'channel_id' => ['Canal', 'select:channels', null], 'lead_employee_id' => ['Responsable de l\'équipe', 'select:employees', null], 'office' => ['Type d\'activité (tableau de bord qualité)', 'select:offices', null]], 'use' => 'employees.team_id'],
        'stores' => ['label' => 'Stores', 'one' => 'store', 'fields' => ['code' => ['Code', 'text', 40], 'name' => ['Nom', 'text', 150], 'city' => ['Ville', 'text', 120], 'locality' => ['Localité', 'text', 120], 'zone_id' => ['Zone géographique', 'select:zones', null], 'region' => ['Région', 'text', 120], 'address' => ['Adresse', 'text', 255], 'situation' => ['Situation géographique (repère, quartier, en face de…)', 'text', 300], 'email' => ['E-mail du store', 'text', 190], 'phone' => ['Téléphone', 'text', 40], 'phone2' => ['Téléphone secondaire', 'text', 40], 'gps_lat' => ['Latitude GPS (ex. 6.131900)', 'text', 20], 'gps_lng' => ['Longitude GPS (ex. 1.222800)', 'text', 20], 'hours' => ['Horaires d\'ouverture (texte généré par la grille « Horaires » du store)', 'text', 200], 'lead_employee_id' => ['Responsable du store', 'select:employees', null]], 'use' => 'employees.store_id'],
        'channels' => ['label' => 'Canaux', 'one' => 'canal', 'fields' => ['code' => ['Code', 'text', 40], 'name' => ['Nom', 'text', 120], 'kind' => ['Type de canal (détermine le champ Store des formulaires)', 'select:chkinds', null], 'lead_employee_id' => ['Responsable du canal', 'select:employees', null]], 'use' => 'employees.channel_id'],
        'positions' => ['label' => 'Postes', 'one' => 'poste', 'fields' => ['code' => ['Code', 'text', 40], 'name' => ['Nom', 'text', 150], 'grade_id' => ['Grade (un seul par poste)', 'select:grades', null]], 'use' => 'employees.position_id'],
        'zones' => ['label' => 'Zones de stores', 'one' => 'zone', 'fields' => ['code' => ['Code', 'text', 40], 'name' => ['Nom', 'text', 150], 'lead_employee_id' => ['Superviseur store de zone', 'select:employees', null]], 'use' => 'stores.zone_id'],
        'grades' => ['label' => 'Grades', 'one' => 'grade', 'fields' => ['code' => ['Code', 'text', 40], 'name' => ['Nom', 'text', 150], 'rank_no' => ['Rang hiérarchique (1 = le plus élevé)', 'text', 3]], 'use' => 'positions.grade_id'],
        'employers' => ['label' => 'Sociétés employeuses', 'one' => 'société employeuse', 'fields' => ['code' => ['Code', 'text', 60], 'name' => ['Raison sociale', 'text', 150], 'kind' => ['Nature', 'select:kinds', null], 'contact' => ['Contact', 'text', 190], 'prefix' => ['Préfixe des matricules (vide = initiales de la raison sociale)', 'text', 10]], 'use' => 'employees.employer', 'by_code' => true],
    ];
    private function cfg(string $e): ?array { return self::ENT[$e] ?? null; }
    function index(string $entity): void {
        $c = $this->cfg($entity); if (!$c) { $this->notFound(); return; }
        $join = ($entity === 'teams' ? 'LEFT JOIN channels c ON c.id=t.channel_id ' : '') . ($entity === 'stores' ? 'LEFT JOIN zones zn ON zn.id=t.zone_id ' : '') . ($entity === 'positions' ? 'LEFT JOIN grades gr ON gr.id=t.grade_id ' : '') . (isset($c['fields']['lead_employee_id']) ? 'LEFT JOIN employees ld ON ld.id=t.lead_employee_id' : '');
        $sel = ($entity === 'teams' ? 't.*, c.name channel_name' : ($entity === 'stores' ? 't.*, zn.name zone_name' : ($entity === 'positions' ? 't.*, gr.name grade_name' : 't.*'))) . (isset($c['fields']['lead_employee_id']) ? ", ld.last_name lead_last, ld.first_name lead_first" : '');
        $q = trim((string)$this->in('q', '')); $w = '1=1'; $p = [];
        if ($q !== '') { $w = '(t.code LIKE ? OR t.name LIKE ?)'; $p = ["%$q%", "%$q%"]; }
        [$tbl, $col] = explode('.', $c['use']);
        $pg = paginate("$entity t $join WHERE $w", $p, $this->page(), 25, "$sel, (SELECT COUNT(*) FROM $tbl x WHERE x.$col=t.".(empty($c['by_code']) ? 'id' : 'code').") used", 't.name');
        $this->view('org/index', ['title' => $c['label'], 'entity' => $entity, 'c' => $c, 'p' => $pg]);
    }
    private function options(): array { return ['zones' => DB::all('SELECT id, name FROM zones WHERE active=1 ORDER BY name'), 'grades' => DB::all('SELECT id, name FROM grades WHERE active=1 ORDER BY rank_no, name'), 'offices' => [['id' => 'FO', 'name' => 'Front office (FO)'], ['id' => 'BO', 'name' => 'Back office (BO)'], ['id' => 'SUP', 'name' => 'Support']], 'chkinds' => [['id' => 'store', 'name' => 'Point de vente (boutique, franchise, express) : le champ Store est actif'], ['id' => 'callcenter', 'name' => 'Centre d\'appels : le champ Store est masqué'], ['id' => 'other', 'name' => 'Autre (digital…) : le champ Store reste désactivé']], 'kinds' => [['id' => 'own', 'name' => 'Employeur direct (Yas Togo)'], ['id' => 'interim', 'name' => 'Société d\'intérim'], ['id' => 'provider', 'name' => 'Prestataire (société sous-traitante)']], 'channels' => DB::all('SELECT id, name FROM channels WHERE active=1 ORDER BY name'), 'employees' => DB::all("SELECT id, CONCAT(last_name, ' ', first_name, ' (', matricule, ')') name FROM employees WHERE status='active' ORDER BY last_name, first_name")]; }
    function create(string $entity): void {
        $c = $this->cfg($entity); if (!$c) { $this->notFound(); return; }
        $this->view('org/form', ['title' => 'Nouvelle ' . $c['one'], 'entity' => $entity, 'c' => $c, 'row' => [], 'action' => url("org/$entity")] + $this->options());
    }
    function edit(string $entity, string $id): void {
        $c = $this->cfg($entity); $row = $c ? DB::one("SELECT * FROM $entity WHERE id=?", [(int)$id]) : null;
        if (!$row) { $this->notFound(); return; }
        $this->view('org/form', ['title' => 'Modifier ' . $c['one'], 'entity' => $entity, 'c' => $c, 'row' => $row, 'action' => url("org/$entity/$id")] + $this->options());
    }
    private function data(string $entity, array $c, ?int $id): array {
        $rules = [];
        foreach ($c['fields'] as $f => [$label, $type, $max]) $rules[$f] = ['label' => $label, 'req' => in_array($f, ['code', 'name']), 'max' => $max ?? 0];
        if (isset($rules['email'])) $rules['email']['email'] = true;
        [$d, $err] = $this->validate($rules, $_POST);
        if ($entity === 'stores') {
            foreach (['phone', 'phone2'] as $f) if (!empty($d[$f]) && !preg_match('/^[+0-9][0-9 .()\-]{5,}$/', $d[$f])) $err[$f] = 'Numéro invalide (chiffres, espaces, « + » autorisés).';
            foreach (['gps_lat' => 90, 'gps_lng' => 180] as $f => $lim) if (!empty($d[$f])) { $v = str_replace(',', '.', $d[$f]); if (!is_numeric($v) || abs((float)$v) > $lim) $err[$f] = 'Coordonnée invalide (entre -' . $lim . ' et ' . $lim . ').'; else $d[$f] = number_format((float)$v, 6, '.', ''); }
            if (empty($err['gps_lat']) && empty($err['gps_lng']) && (!empty($d['gps_lat']) xor !empty($d['gps_lng']))) $err['gps_lat'] = 'Renseignez la latitude et la longitude ensemble.';
        }
        if ($entity === 'employers' && array_key_exists('prefix', $d)) { $d['prefix'] = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)$d['prefix'])) ?: null; if ($d['prefix'] && DB::val('SELECT 1 FROM employers WHERE prefix=? AND id<>?', [$d['prefix'], $id ?? 0])) $err['prefix'] = 'Ce préfixe est déjà utilisé par une autre société.'; }
        if (array_key_exists('office', $d)) $d['office'] = in_array($d['office'], ['FO', 'BO', 'SUP'], true) ? $d['office'] : null;
        if (isset($d['channel_id'])) $d['channel_id'] = $d['channel_id'] ? (int)$d['channel_id'] : null;
        if (array_key_exists('lead_employee_id', $d)) { $d['lead_employee_id'] = $d['lead_employee_id'] ? (int)$d['lead_employee_id'] : null; if ($d['lead_employee_id'] && !DB::val('SELECT 1 FROM employees WHERE id=?', [$d['lead_employee_id']])) $err['lead_employee_id'] = 'Responsable inconnu.'; }
        foreach (['zone_id' => 'zones', 'grade_id' => 'grades'] as $f => $tb) if (array_key_exists($f, $d)) { $d[$f] = $d[$f] ? (int)$d[$f] : null; if ($d[$f] && !DB::val("SELECT 1 FROM $tb WHERE id=?", [$d[$f]])) $err[$f] = 'Valeur inconnue.'; }
        if ($entity === 'positions' && empty($d['grade_id'])) $err['grade_id'] = 'Choisissez le grade du poste : chaque poste a un et un seul grade.';
        if ($entity === 'grades') { $d['rank_no'] = (int)($d['rank_no'] ?? 99) ?: 99; }
        if ($entity === 'channels' && !in_array($d['kind'] ?? '', ['store', 'callcenter', 'other'], true)) $err['kind'] = 'Choisissez le type du canal.';
        if ($entity === 'teams' && empty($d['channel_id'])) $err['channel_id'] = 'Chaque équipe est rattachée à un et un seul canal : choisissez-le.';
        if ($entity === 'employers' && !in_array($d['kind'] ?? '', ['own', 'interim', 'provider'], true)) $err['kind'] = 'Choisissez la nature de la société.';
        $d['active'] = isset($_POST['active']) ? 1 : 0;
        if (empty($err['code']) && DB::val("SELECT 1 FROM $entity WHERE code=? AND id<>?", [$d['code'], $id ?? 0])) $err['code'] = 'Ce code existe déjà.';
        return [$d, $err];
    }
    function store(string $entity): void {
        $c = $this->cfg($entity); if (!$c) { $this->notFound(); return; }
        [$d, $err] = $this->data($entity, $c, null);
        if ($err) $this->back($err, $_POST, "org/$entity/new");
        $id = DB::insert($entity, $d); Audit::log('create', $entity, $id, null, $d);
        flash(ucfirst($c['one']) . ' créé(e).'); redirect("org/$entity");
    }
    function update(string $entity, string $id): void {
        $c = $this->cfg($entity); $old = $c ? DB::one("SELECT * FROM $entity WHERE id=?", [(int)$id]) : null;
        if (!$old) { $this->notFound(); return; }
        [$d, $err] = $this->data($entity, $c, (int)$id);
        if ($err) $this->back($err, $_POST, "org/$entity/$id/edit");
        DB::update($entity, $d, 'id=?', [(int)$id]); Audit::log('update', $entity, $id, $old, $d);
        flash('Modifications enregistrées.'); redirect("org/$entity");
    }
    function delete(string $entity, string $id): void {
        $c = $this->cfg($entity); $old = $c ? DB::one("SELECT * FROM $entity WHERE id=?", [(int)$id]) : null;
        if (!$old) { $this->notFound(); return; }
        [$tbl, $col] = explode('.', $c['use']);
        if ((int)DB::val("SELECT COUNT(*) FROM $tbl WHERE $col=?", [empty($c['by_code']) ? (int)$id : $old['code']]) > 0) {
            DB::update($entity, ['active' => 0], 'id=?', [(int)$id]); Audit::log('deactivate', $entity, $id, $old, ['active' => 0]);
            flash('Utilisé par des collaborateurs : désactivé plutôt que supprimé.', 'warning');
        } else { DB::exec("DELETE FROM $entity WHERE id=?", [(int)$id]); Audit::log('delete', $entity, $id, $old); flash('Supprimé.'); }
        redirect("org/$entity");
    }
}
