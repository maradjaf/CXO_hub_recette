<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Scope};
class AbsencesController extends Controller {
    private function kinds(): array { return DB::all("SELECT v.code, v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='absence_kinds' AND v.active=1 ORDER BY v.sort_order, v.label"); }
    private function filter(): array {
        [$w, $p] = Scope::sql('a.employee_id'); $w = [$w];
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(e.first_name LIKE ? OR e.last_name LIKE ? OR e.matricule LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        if ($this->in('kind')) { $w[] = 'a.kind=?'; $p[] = $this->in('kind'); }
        if ($this->in('team_id')) { $w[] = 'e.team_id=?'; $p[] = (int)$this->in('team_id'); }
        if ($this->in('from')) { $w[] = 'a.end_date>=?'; $p[] = $this->in('from'); }
        if ($this->in('to')) { $w[] = 'a.start_date<=?'; $p[] = $this->in('to'); }
        return [implode(' AND ', $w), $p];
    }
    /** Taux d'absentéisme d'une période : jours d'absence non planifiés / (effectif actif × jours ouvrés). */
    static function rate(string $from, string $to, ?int $team = null): array {
        [$sw, $sp] = Scope::sql('e.id'); $tw = $team ? ' AND e.team_id=?' : ''; $tp = $team ? [$team] : [];
        $head = (int)DB::val("SELECT COUNT(*) FROM employees e WHERE e.status='active' AND $sw$tw", array_merge($sp, $tp));
        [$sa, $spa] = Scope::sql('a.employee_id');
        $days = (float)DB::val("SELECT COALESCE(SUM(a.days),0) FROM absences a JOIN employees e ON e.id=a.employee_id WHERE a.start_date>=? AND a.start_date<=? AND $sa$tw", array_merge([$from, $to], $spa, $tp));
        $wd = LeaveController::workingDays($from, min($to, date('Y-m-d')) >= $from ? min($to, date('Y-m-d')) : $from);
        $den = $head * max(1, $wd);
        return ['days' => $days, 'head' => $head, 'rate' => $den ? round($days / $den * 100, 2) : 0.0];
    }
    function index(): void {
        [$w, $p] = $this->filter();
        $pg = paginate("absences a JOIN employees e ON e.id=a.employee_id LEFT JOIN teams t ON t.id=e.team_id WHERE $w", $p, $this->page(), 25, 'a.*, e.first_name, e.last_name, e.matricule, t.name team_name', 'a.start_date DESC, a.id DESC');
        [$sw, $sp] = Scope::sql('a.employee_id');
        $rec = DB::all("SELECT e.id, e.first_name, e.last_name, COUNT(*) n, SUM(a.days) d FROM absences a JOIN employees e ON e.id=a.employee_id WHERE a.start_date>=? AND $sw GROUP BY e.id, e.first_name, e.last_name HAVING COUNT(*)>=3 ORDER BY n DESC LIMIT 8", array_merge([date('Y-m-d', strtotime('-90 days'))], $sp));
        $m = self::rate(date('Y-m-01'), date('Y-m-t'));
        $this->view('absences/index', ['title' => 'Absentéisme', 'p' => $pg, 'kinds' => $this->kinds(), 'rec' => $rec, 'month' => $m, 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'),
            'employees' => can('absence.manage') ? Scope::employees() : [], 'labels' => array_column($this->kinds(), 'label', 'code')]);
    }
    function stats(): void {
        $months = []; for ($i = 5; $i >= 0; $i--) { $f = date('Y-m-01', strtotime("-$i months")); $months[] = ['label' => date('m/Y', strtotime($f))] + self::rate($f, date('Y-m-t', strtotime($f))); }
        $teams = []; foreach (DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name') as $t) { $r = self::rate(date('Y-m-01'), date('Y-m-t'), (int)$t['id']); if ($r['head']) $teams[] = ['name' => $t['name']] + $r; }
        usort($teams, fn($a, $b) => $b['rate'] <=> $a['rate']);
        [$sa, $sp] = Scope::sql('a.employee_id');
        $kinds = DB::all("SELECT a.kind, COUNT(*) n, SUM(a.days) d FROM absences a WHERE a.start_date>=? AND $sa GROUP BY a.kind ORDER BY d DESC", array_merge([date('Y-m-d', strtotime('-90 days'))], $sp));
        $this->view('absences/stats', ['title' => 'Taux d\'absentéisme', 'months' => $months, 'teams' => $teams, 'kinds' => $kinds, 'labels' => array_column($this->kinds(), 'label', 'code')]);
    }
    function store(): void {
        [$d, $err] = $this->validate(['start_date' => ['label' => 'La date de début', 'req' => true, 'date' => true], 'end_date' => ['label' => 'La date de fin', 'date' => true], 'note' => ['label' => 'La note', 'max' => 500]], $_POST);
        $emp = (int)$this->in('employee_id'); $kind = (string)$this->in('kind');
        if (!Scope::allows($emp) || !DB::val('SELECT 1 FROM employees WHERE id=?', [$emp])) $err['emp'] = 'Choisissez un collaborateur de votre périmètre.';
        if (!DB::val("SELECT 1 FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='absence_kinds' AND v.code=?", [$kind])) $err['kind'] = 'Choisissez un type d\'absence.';
        $end = $d['end_date'] ?: $d['start_date'];
        if ($d['start_date'] && $end < $d['start_date']) $err['end'] = 'La fin est antérieure au début.';
        if (!$err && DB::val("SELECT 1 FROM leave_requests WHERE employee_id=? AND status='approved' AND start_date<=? AND end_date>=?", [$emp, $end, $d['start_date']])) $err['leave'] = 'Un congé approuvé couvre cette période : ce n\'est pas une absence.';
        if (!$err && DB::val('SELECT 1 FROM absences WHERE employee_id=? AND start_date<=? AND end_date>=?', [$emp, $end, $d['start_date']])) $err['dup'] = 'Une absence est déjà saisie sur cette période.';
        $days = $this->in('days') !== null && $this->in('days') !== '' ? (float)$this->in('days') : ($err ? 0 : LeaveController::workingDays($d['start_date'], $end));
        if (!$err && $days <= 0 && $kind !== 'RETARD') $err['days'] = 'La période ne contient aucun jour ouvré.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('absences'); }
        $row = ['employee_id' => $emp, 'start_date' => $d['start_date'], 'end_date' => $end, 'days' => $days, 'kind' => $kind, 'justified' => isset($_POST['justified']) ? 1 : 0, 'note' => $d['note'], 'recorded_by' => Auth::id(), 'created_at' => now()];
        $id = DB::insert('absences', $row); Audit::log('create', 'absence', $id, null, $row); flash('Absence enregistrée.'); redirect('absences');
    }
    function delete(string $id): void {
        $a = DB::one('SELECT * FROM absences WHERE id=?', [(int)$id]); if (!$a) { $this->notFound(); return; }
        if (!Scope::allows((int)$a['employee_id'])) { $this->forbidden(); return; }
        DB::exec('DELETE FROM absences WHERE id=?', [(int)$id]); Audit::log('delete', 'absence', $id, $a); flash('Absence supprimée.'); redirect('absences');
    }
    function export(): void {
        [$w, $p] = $this->filter();
        $rows = DB::all("SELECT e.matricule, e.last_name, e.first_name, t.name team, a.start_date, a.end_date, a.days, a.kind, a.justified FROM absences a JOIN employees e ON e.id=a.employee_id LEFT JOIN teams t ON t.id=e.team_id WHERE $w ORDER BY a.start_date DESC", $p);
        Audit::log('export', 'absences', null, null, ['rows' => count($rows)]);
        csv_download('absences_' . date('Ymd_His') . '.csv', ['Matricule', 'Nom', 'Prénom', 'Équipe', 'Début', 'Fin', 'Jours', 'Type', 'Justifiée'], $rows);
    }
}
