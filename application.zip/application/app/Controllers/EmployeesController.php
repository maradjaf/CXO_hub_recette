<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Notifier, Activity};
class EmployeesController extends Controller {
    const STATUS = ['active' => 'Actif', 'inactive' => 'Inactif', 'left' => 'Sorti'];
    private function lists(): array {
        return [
            'teams' => DB::all('SELECT id, name, channel_id FROM teams WHERE active=1 ORDER BY name'), 'stores' => DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name'),
            'channels' => DB::all('SELECT id, name, kind FROM channels WHERE active=1 ORDER BY name'), 'positions' => DB::all('SELECT id, name FROM positions WHERE active=1 ORDER BY name'),
            'managers' => DB::all("SELECT id, first_name, last_name FROM employees WHERE status='active' ORDER BY last_name, first_name"),
            'units' => \App\Core\Org::flat(), 'levels' => \App\Core\Org::levels(),
            'contracts' => DB::all("SELECT v.code, v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='contract_types' AND v.active=1 ORDER BY v.sort_order, v.label"),
            'qaTypes' => \App\Core\Ref::items('qa_ref_types'),
            'functions' => array_column(DB::all("SELECT DISTINCT job_function FROM employees WHERE job_function IS NOT NULL AND job_function<>'' ORDER BY job_function"), 'job_function'),
            'employers' => DB::all("SELECT code, name label, kind FROM employers WHERE active=1 ORDER BY CASE WHEN kind='own' THEN 0 ELSE 1 END, name"),
        ];
    }
    private function filter(): array {
        $w = [\App\Core\Scope::hideOther()]; $p = [];
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(e.first_name LIKE ? OR e.last_name LIKE ? OR e.matricule LIKE ? OR e.email LIKE ? OR e.qa_ref LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%", "%$q%", "%$q%"); }
        foreach (['team_id', 'store_id', 'channel_id'] as $f) if ($this->in($f)) { $w[] = "e.$f=?"; $p[] = (int)$this->in($f); }
        if ($this->in('unit')) $w[] = 'e.org_unit_id IN (' . implode(',', \App\Core\Org::descendants((int)$this->in('unit'))) . ')';
        if (($lv = (string)$this->in('level', '')) !== '' && ctype_digit($lv)) { $w[] = 'e.org_level=?'; $p[] = (int)$lv; }
        if ($this->in('qa') === 'missing') $w[] = "(e.qa_ref IS NULL OR e.qa_ref='')";
        if ($this->in('contract')) { $w[] = 'e.contract_type=?'; $p[] = (string)$this->in('contract'); }
        $w[] = $this->in('status') ? 'e.status=?' : "e.status<>'left'"; if ($this->in('status')) $p[] = $this->in('status');
        return [implode(' AND ', $w), $p];
    }
    function index(): void {
        [$w, $p] = $this->filter();
        $from = "employees e LEFT JOIN teams t ON t.id=e.team_id LEFT JOIN stores s ON s.id=e.store_id LEFT JOIN positions po ON po.id=e.position_id LEFT JOIN org_units ou ON ou.id=e.org_unit_id WHERE $w";
        $pg = paginate($from, $p, $this->page(), 20, 'e.*, t.name team_name, s.name store_name, po.name position_name, ou.name unit_name', 'e.last_name, e.first_name');
        $this->view('employees/index', ['title' => 'Collaborateurs', 'p' => $pg, 'status' => self::STATUS] + $this->lists());
    }
    function export(): void {
        [$w, $p] = $this->filter();
        $rows = DB::all("SELECT e.matricule, e.last_name, e.first_name, e.email, e.phone, t.name team, s.name store, po.name position, e.hire_date, e.contract_type, e.employer, e.qa_ref_type, e.qa_ref, e.status FROM employees e LEFT JOIN teams t ON t.id=e.team_id LEFT JOIN stores s ON s.id=e.store_id LEFT JOIN positions po ON po.id=e.position_id WHERE $w ORDER BY e.last_name", $p);
        Audit::log('export', 'employees', null, null, ['rows' => count($rows), 'filters' => $_GET]);
        csv_download('collaborateurs_' . date('Ymd_His') . '.csv', ['Matricule', 'Nom', 'Prénom', 'Email', 'Téléphone', 'Équipe', 'Store', 'Poste', 'Date d\'embauche', 'Contrat', 'Employeur', 'Type réf. qualité', 'Réf. qualité', 'Statut'], $rows);
    }
    function show(string $id): void {
        $e = DB::one('SELECT e.*, t.name team_name, s.name store_name, c.name channel_name, po.name position_name, m.first_name mf, m.last_name ml FROM employees e LEFT JOIN teams t ON t.id=e.team_id LEFT JOIN stores s ON s.id=e.store_id LEFT JOIN channels c ON c.id=e.channel_id LEFT JOIN positions po ON po.id=e.position_id LEFT JOIN employees m ON m.id=e.manager_id WHERE e.id=?', [(int)$id]);
        if (!$e || \App\Core\Scope::hidden($e)) { $this->notFound(); return; }
        $hist = DB::all('SELECT a.*, t.name team_name, s.name store_name, po.name position_name FROM employee_assignments a LEFT JOIN teams t ON t.id=a.team_id LEFT JOIN stores s ON s.id=a.store_id LEFT JOIN positions po ON po.id=a.position_id WHERE a.employee_id=? ORDER BY a.valid_from DESC, a.id DESC', [(int)$id]);
        $team = DB::all("SELECT id, first_name, last_name, position_id FROM employees WHERE manager_id=? AND status='active' ORDER BY last_name", [(int)$id]);
        $user = DB::one('SELECT id, email, status FROM users WHERE employee_id=?', [(int)$id]);
        $x = ['employer' => $e['employer'] ? (string)(DB::val('SELECT name FROM employers WHERE code=?', [$e['employer']]) ?: $e['employer']) : '',
            'grade' => (string)(DB::val('SELECT g.name FROM positions p JOIN grades g ON g.id=p.grade_id WHERE p.id=?', [(int)$e['position_id']]) ?: ''),
            'zone' => (string)(DB::val('SELECT z.name FROM stores s JOIN zones z ON z.id=s.zone_id WHERE s.id=?', [(int)$e['store_id']]) ?: ''),
            'interims' => DB::all("SELECT i.start_date, i.end_date, po.name position_name FROM interims i JOIN positions po ON po.id=i.position_id WHERE i.interim_employee_id=? AND i.status='active' ORDER BY i.start_date DESC", [(int)$id])];
        $this->view('employees/show', ['title' => $e['first_name'] . ' ' . $e['last_name'], 'e' => $e, 'x' => $x, 'hist' => $hist, 'team' => $team, 'acct' => $user, 'status' => self::STATUS,
            'contracts' => can('contracts.view') ? DB::all('SELECT * FROM contracts WHERE employee_id=? ORDER BY start_date DESC', [(int)$id]) : [],
            'moves' => can('mobility.manage') ? array_map(function ($m) { $m['from'] = \App\Core\Org::path($m['from_unit_id'] ? (int)$m['from_unit_id'] : null); $m['to'] = \App\Core\Org::path($m['to_unit_id'] ? (int)$m['to_unit_id'] : null); return $m; }, DB::all('SELECT m.*, ft.name from_team, tt.name to_team, fs.name from_store, ts.name to_store, fp.name from_pos, tp.name to_pos FROM mobility_moves m LEFT JOIN teams ft ON ft.id=m.from_team_id LEFT JOIN teams tt ON tt.id=m.to_team_id LEFT JOIN stores fs ON fs.id=m.from_store_id LEFT JOIN stores ts ON ts.id=m.to_store_id LEFT JOIN positions fp ON fp.id=m.from_position_id LEFT JOIN positions tp ON tp.id=m.to_position_id WHERE m.employee_id=? ORDER BY m.effective_date DESC, m.id DESC', [(int)$id])) : [],
            'exits' => can('offboarding.view') ? DB::all('SELECT id, exit_type, exit_date, status FROM offboarding_cases WHERE employee_id=? ORDER BY id DESC', [(int)$id]) : [],
            'cases' => can('onboarding.view') ? DB::all('SELECT id, start_date, status FROM onboarding_cases WHERE employee_id=? ORDER BY id DESC', [(int)$id]) : []]);
    }
    function create(): void { $this->view('employees/form', ['title' => 'Nouveau collaborateur', 'e' => ['matricule' => self::nextMatricule()], 'auto' => true, 'action' => url('employees'), 'status' => self::STATUS] + $this->lists()); }
    function edit(string $id): void {
        $e = DB::one('SELECT * FROM employees WHERE id=?', [(int)$id]);
        if (!$e) { $this->notFound(); return; }
        $this->view('employees/form', ['title' => 'Modifier ' . $e['first_name'] . ' ' . $e['last_name'], 'e' => $e, 'action' => url('employees/' . $id), 'status' => self::STATUS] + $this->lists());
    }
    /** Préfixe de matricule d'une société : préfixe saisi, sinon initiales de la raison sociale (mots vides ignorés). Null si pas de société. */
    static function employerPrefix(?string $code): ?string {
        if (!$code || \App\Core\Settings::get('hr.matricule_by_employer', '1') === '0') return null; $e = DB::one('SELECT name, prefix FROM employers WHERE code=?', [$code]); if (!$e) return null;
        if (!empty($e['prefix'])) return strtoupper($e['prefix']);
        $n = strtr(mb_strtolower((string)$e['name']), ['à' => 'a', 'â' => 'a', 'ä' => 'a', 'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e', 'î' => 'i', 'ï' => 'i', 'ô' => 'o', 'ö' => 'o', 'ù' => 'u', 'û' => 'u', 'ü' => 'u', 'ç' => 'c']); $in = '';
        foreach (preg_split('/[^a-z0-9]+/', $n, -1, PREG_SPLIT_NO_EMPTY) as $w) if (!in_array($w, ['de', 'du', 'des', 'la', 'le', 'les', 'et', 'd', 'l', 'au', 'aux'], true)) $in .= $w[0];
        return $in !== '' ? strtoupper(substr($in, 0, 6)) : null;
    }
    /** Prochain matricule libre : préfixe de la société employeuse (initiales) ou préfixe global, puis numéro séquentiel. */
    static function nextMatricule(?string $employer = null): string {
        $pre = self::employerPrefix($employer) ?? (string)\App\Core\Settings::get('hr.matricule_prefix', 'MAT'); $dg = max(3, min(10, (int)\App\Core\Settings::get('hr.matricule_digits', 5)));
        $max = 0; foreach (DB::all('SELECT matricule FROM employees WHERE matricule LIKE ?', [$pre . '%']) as $r) { $t = substr($r['matricule'], strlen($pre)); if (ctype_digit($t)) $max = max($max, (int)$t); }
        do { $max++; $m = $pre . str_pad((string)$max, $dg, '0', STR_PAD_LEFT); } while (DB::val('SELECT 1 FROM employees WHERE matricule=?', [$m]));
        return $m;
    }
    function nextAjax(): void { header('Content-Type: application/json'); echo json_encode(['matricule' => self::nextMatricule((string)$this->in('employer', '') ?: null)]); exit; }
    private function data(?int $id): array {
        [$d, $err] = $this->validate([
            'matricule' => ['label' => 'Le matricule', 'max' => 40], 'first_name' => ['label' => 'Le prénom', 'req' => true, 'max' => 100], 'last_name' => ['label' => 'Le nom', 'req' => true, 'max' => 100],
            'email' => ['label' => 'L\'email', 'email' => true, 'max' => 190], 'phone' => ['label' => 'Le téléphone', 'max' => 40], 'hire_date' => ['label' => 'La date d\'embauche', 'date' => true],
            'contract_type' => ['label' => 'Le contrat', 'max' => 60], 'employer' => ['label' => 'L\'employeur', 'max' => 60], 'placement' => ['label' => 'L\'affectation', 'max' => 6], 'host_company' => ['label' => 'La société d\'affectation', 'max' => 150], 'job_function' => ['label' => 'La fonction', 'max' => 120], 'qa_ref_type' => ['label' => 'Le type de référence qualité', 'req' => true, 'max' => 40], 'qa_ref' => ['label' => 'La référence contrôle qualité', 'req' => true, 'max' => 80], 'status' => ['label' => 'Le statut', 'req' => true],
            'team_id' => [], 'store_id' => [], 'channel_id' => [], 'position_id' => [], 'manager_id' => [], 'org_unit_id' => [], 'org_level' => [],
        ], $_POST);
        if (!isset(self::STATUS[$d['status'] ?? ''])) $err['status'] = 'Statut inconnu.';
        if (!empty($d['qa_ref_type']) && !\App\Core\Ref::has('qa_ref_types', $d['qa_ref_type'])) $err['qa_ref_type'] = 'Type de référence inconnu (référentiel Contrôle qualité).';
        if (!empty($d['qa_ref']) && DB::val('SELECT 1 FROM employees WHERE qa_ref_type=? AND qa_ref=? AND id<>?', [$d['qa_ref_type'], $d['qa_ref'], $id ?? 0])) $err['qa_ref'] = 'Cette référence qualité est déjà attribuée à un autre collaborateur.';
        foreach (['employer' => 'employers', 'contract_type' => 'contract_types'] as $f => $lst) { if (($d[$f] ?? '') === '') { $d[$f] = null; continue; } if (!($f === 'employer' ? DB::val('SELECT 1 FROM employers WHERE code=? AND active=1', [$d[$f]]) : DB::val('SELECT 1 FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code=? AND v.code=?', [$lst, $d[$f]]))) $err[$f] = ($f === 'employer' ? 'Employeur' : 'Type de contrat') . ' inconnu.'; }
        // Affectation : un collaborateur d'une société autre que le groupe est soit en intérim chez Yas Togo, soit affecté dans une autre société.
        $own = !$d['employer'] || (bool)DB::val("SELECT 1 FROM employers WHERE code=? AND kind='own'", [$d['employer']]);
        if ($own || !in_array($d['placement'] ?? '', ['yas', 'other'], true)) { $d['placement'] = $own ? null : 'yas'; $d['host_company'] = null; }
        elseif ($d['placement'] === 'other' && ($d['host_company'] ?? '') === '') $err['host_company'] = 'Indiquez la société dans laquelle il travaille.';
        elseif ($d['placement'] === 'yas') $d['host_company'] = null;
        if (($d['matricule'] ?? '') === '' && !$id) { $d['matricule'] = self::nextMatricule($d['employer'] ?? null); $d['matricule_confirmed'] = 0; }
        if (($d['matricule'] ?? '') === '') $err['matricule'] = 'Le matricule est obligatoire.';
        if ($d['matricule'] && DB::val('SELECT 1 FROM employees WHERE matricule=? AND id<>?', [$d['matricule'], $id ?? 0])) $err['matricule'] = 'Ce matricule existe déjà.';
        if ($id && (int)$d['manager_id'] === $id) $err['manager_id'] = 'Un collaborateur ne peut pas être son propre responsable.';
        foreach (['team_id', 'store_id', 'channel_id', 'position_id', 'manager_id', 'org_unit_id'] as $f) $d[$f] = $d[$f] ? (int)$d[$f] : null;
        // Cohérence canal ↔ équipe ↔ store : l'équipe impose son canal ; seul un canal « point de vente » porte un store
        if ($d['team_id']) { $tc = DB::val('SELECT channel_id FROM teams WHERE id=?', [$d['team_id']]); if ($tc) { if ($d['channel_id'] && (int)$d['channel_id'] !== (int)$tc) $err['team_id'] = 'Cette équipe n\'appartient pas au canal choisi.'; $d['channel_id'] = (int)$tc; } }
        if ($d['channel_id']) { $kind = DB::val('SELECT kind FROM channels WHERE id=?', [$d['channel_id']]); if ($kind === null) $err['channel_id'] = 'Canal inconnu.'; elseif ($kind === 'store') { if (!$d['store_id']) $err['store_id'] = 'Choisissez le store : ce canal est un point de vente.'; } else $d['store_id'] = null; }
        if ($d['org_unit_id'] && !DB::val('SELECT 1 FROM org_units WHERE id=?', [$d['org_unit_id']])) $err['org_unit_id'] = 'Unité inconnue.';
        if ($d['org_unit_id'] === null) { $d['org_unit_id'] = ($d['team_id'] ? DB::val('SELECT org_unit_id FROM teams WHERE id=?', [$d['team_id']]) : null) ?: ($d['store_id'] ? DB::val('SELECT org_unit_id FROM stores WHERE id=?', [$d['store_id']]) : null) ?: null; }
        $lv = (string)($d['org_level'] ?? ''); if ($lv !== '' && (!ctype_digit($lv) || (int)$lv > 6)) $err['org_level'] = 'Niveau inconnu.';
        $d['org_level'] = $lv !== '' ? (int)$lv : ($d['position_id'] ? (int)DB::val('SELECT org_level FROM positions WHERE id=?', [$d['position_id']]) : 0);
        return [$d, $err];
    }
    function store(): void {
        [$d, $err] = $this->data(null);
        if ($err) $this->back($err, $_POST, 'employees/new');
        $d['created_at'] = $d['updated_at'] = now();
        $id = DB::insert('employees', $d);
        $this->assign($id, null, $d);
        Audit::log('create', 'employee', $id, null, $d);
        flash('Collaborateur créé.');
        redirect('employees/' . $id);
    }
    function update(string $id): void {
        $old = DB::one('SELECT * FROM employees WHERE id=?', [(int)$id]);
        if (!$old) { $this->notFound(); return; }
        [$d, $err] = $this->data((int)$id);
        if ($err) $this->back($err, $_POST, "employees/$id/edit");
        $d['updated_at'] = now();
        DB::update('employees', $d, 'id=?', [(int)$id]);
        $this->assign((int)$id, $old, $d);
        Audit::log('update', 'employee', $id, $old, $d);
        flash('Modifications enregistrées.');
        redirect('employees/' . $id);
    }
    function delete(string $id): void {
        $old = DB::one('SELECT * FROM employees WHERE id=?', [(int)$id]);
        if (!$old) { $this->notFound(); return; }
        DB::update('employees', ['status' => 'left', 'updated_at' => now()], 'id=?', [(int)$id]);
        DB::exec('UPDATE users SET status=? WHERE employee_id=?', ['inactive', (int)$id]);
        Audit::log('delete', 'employee', $id, $old, ['status' => 'left']);
        flash('Collaborateur marqué comme sorti ; son compte utilisateur est désactivé.');
        redirect('employees');
    }
    /** Historique daté des affectations : toute modification d'équipe, store, poste ou responsable ouvre une nouvelle ligne. */
    private function assign(int $id, ?array $old, array $new): void {
        $keys = ['team_id', 'store_id', 'position_id', 'manager_id'];
        if ($old) { $same = true; foreach ($keys as $k) if (($old[$k] ?? null) != ($new[$k] ?? null)) $same = false; if ($same) return; }
        $today = date('Y-m-d');
        DB::exec('UPDATE employee_assignments SET valid_to=? WHERE employee_id=? AND valid_to IS NULL', [$today, $id]);
        $row = ['employee_id' => $id, 'valid_from' => $today, 'created_by' => \App\Core\Auth::id()];
        foreach ($keys as $k) $row[$k] = $new[$k] ?? null;
        DB::insert('employee_assignments', $row);
    }
}
