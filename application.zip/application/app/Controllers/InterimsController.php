<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth};

/** Intérims : un collaborateur assure temporairement un poste (souvent en remplacement du titulaire). */
class InterimsController extends Controller {
    function index(): void {
        $st = (string)$this->in('status', 'active'); $w = ['1=1']; $p = [];
        if ($st === 'active' || $st === 'ended') { $w[] = 'i.status=?'; $p[] = $st; }
        $pg = paginate('interims i JOIN positions po ON po.id=i.position_id LEFT JOIN grades g ON g.id=po.grade_id JOIN employees a ON a.id=i.interim_employee_id LEFT JOIN employees r ON r.id=i.replaced_employee_id WHERE ' . implode(' AND ', $w), $p, $this->page(), 25, 'i.*, po.name position_name, g.name grade_name, a.first_name a_first, a.last_name a_last, a.matricule a_mat, r.first_name r_first, r.last_name r_last', 'i.start_date DESC, i.id DESC'); $rows = $pg['rows'];
        $this->view('interims/index', ['title' => 'Intérims sur postes', 'rows' => $rows, 'p' => $pg, 'status' => $st]);
    }
    private function lists(): array {
        return ['positions' => DB::all('SELECT p.id, p.name, g.name grade FROM positions p LEFT JOIN grades g ON g.id=p.grade_id WHERE p.active=1 ORDER BY g.rank_no, p.name'), 'emps' => DB::all("SELECT id, first_name, last_name, matricule FROM employees WHERE status='active' ORDER BY last_name, first_name")];
    }
    function create(): void { $this->view('interims/form', ['title' => 'Nouvel intérim', 'pre' => (int)$this->in('employee', 0)] + $this->lists()); }
    function store(): void {
        $err = []; $pos = (int)$this->in('position_id', 0); $emp = (int)$this->in('interim_employee_id', 0); $rep = (int)$this->in('replaced_employee_id', 0) ?: null;
        $from = (string)$this->in('start_date', date('Y-m-d')); $to = trim((string)$this->in('end_date', '')) ?: null;
        if (!DB::val('SELECT 1 FROM positions WHERE id=?', [$pos])) $err['position_id'] = 'Choisissez le poste.';
        if (!DB::val("SELECT 1 FROM employees WHERE id=? AND status='active'", [$emp])) $err['interim_employee_id'] = 'Choisissez la personne qui assure l\'intérim.';
        if ($rep && !DB::val('SELECT 1 FROM employees WHERE id=?', [$rep])) $err['replaced_employee_id'] = 'Titulaire inconnu.';
        if ($rep && $rep === $emp) $err['replaced_employee_id'] = 'Le remplaçant ne peut pas être le titulaire.';
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) $err['start_date'] = 'Date de début invalide.';
        if ($to !== null && (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to) || $to < $from)) $err['end_date'] = 'La date de fin doit être postérieure ou égale au début.';
        if (!$err && DB::val("SELECT 1 FROM interims WHERE status='active' AND position_id=? AND interim_employee_id=?", [$pos, $emp])) $err['position_id'] = 'Cet intérim est déjà en cours pour cette personne.';
        if ($err) { $_SESSION['_old'] = $_POST; $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('interims/new'); }
        $id = DB::insert('interims', ['position_id' => $pos, 'interim_employee_id' => $emp, 'replaced_employee_id' => $rep, 'start_date' => $from, 'end_date' => $to, 'reason' => mb_substr(trim((string)$this->in('reason', '')), 0, 300), 'status' => 'active', 'created_by' => Auth::id(), 'created_at' => now()]);
        Audit::log('create', 'interims', $id, null, ['position' => $pos, 'employee' => $emp]);
        flash('Intérim enregistré.'); redirect('interims');
    }
    function end(string $id): void {
        $i = DB::one("SELECT * FROM interims WHERE id=? AND status='active'", [(int)$id]); if (!$i) { $this->notFound(); return; }
        $to = $i['end_date'] && $i['end_date'] < date('Y-m-d') ? $i['end_date'] : date('Y-m-d');
        DB::update('interims', ['status' => 'ended', 'end_date' => $to], 'id=?', [(int)$id]); Audit::log('update', 'interims', $id, $i, ['status' => 'ended']);
        flash('Intérim terminé.'); redirect('interims');
    }
}
