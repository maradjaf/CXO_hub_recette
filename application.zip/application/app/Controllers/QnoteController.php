<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Qn, Scope, Settings};

/** Lot 66 : note qualité composée. Paramétrage réservé aux coachs qualité et à l'admin (qnote.manage). */
class QnoteController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    private function weighted(): bool { return Settings::get('qn.team_weighted', '0') === '1'; }
    function index(): void {
        [$from, $to] = Qn::period($_GET); $f = []; foreach (['team_id', 'store_id'] as $k) if ((int)$this->in($k)) $f[$k] = (int)$this->in($k); $k = (string)$this->in('kind'); if (isset(Qn::KIND[$k])) $f['kind'] = $k;
        $rows = Qn::scopeRows($from, $to, $f); $w = $this->weighted(); $names = array_column(DB::all('SELECT id, last_name, first_name FROM employees'), null, 'id');
        $teams = DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'); $stores = DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name');
        $tl = array_column($teams, 'name', 'id'); $sl = array_column($stores, 'name', 'id'); $rated = array_values(array_filter(array_column($rows, 'score'), fn($s) => $s !== null));
        if ($this->in('export') === 'csv') { Audit::log('export', 'qnote', null, null, ['from' => $from, 'to' => $to]);
            csv_download('notes_qualite_' . date('Ymd_His') . '.csv', ['Conseiller', 'Profil', 'Note qualité /100', 'Statut', 'Évaluation qualité', 'CSAT individuel', 'CSAT agence', 'CSAT équipe'], array_map(fn($r) => [trim(($names[$r['employee_id']]['last_name'] ?? '') . ' ' . ($names[$r['employee_id']]['first_name'] ?? '')), $r['profile']['name'] ?? '', $r['score'], Qn::STATUS[$r['status']], $r['comps']['qc']['v'] ?? '', $r['comps']['self']['v'] ?? '', $r['comps']['store']['v'] ?? '', $r['comps']['team']['v'] ?? ''], $rows)); return; }
        $page = $this->page(); $per = 50;
        $this->view('qnote/index', ['title' => 'Note qualité', 'from' => $from, 'to' => $to, 'f' => $f, 'rows' => array_slice($rows, ($page - 1) * $per, $per), 'total' => count($rows), 'page' => $page, 'per' => $per, 'names' => $names, 'avg' => $rated ? round(array_sum($rated) / count($rated), 1) : null, 'rated' => count($rated),
            'byTeam' => Qn::groupAvg($rows, 'team_id', $w), 'byStore' => Qn::groupAvg($rows, 'store_id', $w), 'tl' => $tl, 'sl' => $sl, 'teams' => $teams, 'stores' => $stores, 'weighted' => $w, 'canManage' => Auth::can('qnote.manage')]);
    }
    function mine(): void {
        $me = (int)(Auth::user()['employee_id'] ?? 0); [$from, $to] = Qn::period($_GET); $r = $me ? Qn::compute($me, $from, $to) : null;
        $this->view('qnote/mine', ['title' => 'Ma note qualité', 'from' => $from, 'to' => $to, 'r' => $r, 'hist' => $me ? DB::all('SELECT * FROM qn_snapshots WHERE employee_id=? ORDER BY period_to DESC, id DESC LIMIT 12', [$me]) : []]);
    }
    function employee(string $id): void {
        $id = (int)$id; $e = Qn::employee($id); if (!$e || !Scope::allows($id)) { $this->notFound(); return; } [$from, $to] = Qn::period($_GET); Audit::log('view', 'qnote', (string)$id);
        $this->view('qnote/employee', ['title' => 'Note qualité — ' . $e['last_name'], 'e' => $e, 'from' => $from, 'to' => $to, 'r' => Qn::compute($id, $from, $to), 'hist' => DB::all('SELECT * FROM qn_snapshots WHERE employee_id=? ORDER BY period_to DESC, id DESC LIMIT 12', [$id])]);
    }
    function snapshot(): void {
        [$from, $to] = Qn::period($_POST); $n = 0; $by = Auth::id();
        DB::pdo()->beginTransaction();
        foreach (Qn::scopeRows($from, $to) as $r) { if (!$r['profile']) continue; DB::exec('DELETE FROM qn_snapshots WHERE employee_id=? AND period_from=? AND period_to=?', [$r['employee_id'], $from, $to]);
            DB::insert('qn_snapshots', ['employee_id' => $r['employee_id'], 'period_from' => $from, 'period_to' => $to, 'profile_id' => $r['profile']['id'], 'profile_label' => $r['profile']['name'] . ' v' . $r['profile']['version'], 'score' => $r['score'], 'qc' => $r['comps']['qc']['v'] ?? null, 'csat_self' => $r['comps']['self']['v'] ?? null, 'csat_store' => $r['comps']['store']['v'] ?? null, 'csat_team' => $r['comps']['team']['v'] ?? null, 'status' => $r['status'], 'detail' => json_encode($r['comps']), 'created_by' => $by, 'created_at' => now()]); $n++; }
        DB::pdo()->commit(); Audit::log('snapshot', 'qnote', null, null, ['from' => $from, 'to' => $to, 'n' => $n]); $this->go('quality-note?from=' . $from . '&to=' . $to, "$n note(s) enregistrée(s) dans l'historique.");
    }
    // ------------------------------------------------------------------ paramétrage
    function profiles(): void {
        $all = DB::all('SELECT * FROM qn_profiles ORDER BY code, effective_from DESC, version DESC'); $g = []; foreach ($all as $r) $g[$r['code']][] = $r;
        $this->view('qnote/profiles', ['title' => 'Note qualité — Profils', 'groups' => $g, 'positions' => DB::all('SELECT id, name FROM positions ORDER BY name'), 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'), 'weighted' => $this->weighted(), 'today' => date('Y-m-d')]);
    }
    private function parse(): array {
        $d = []; $err = []; foreach (['qc', 'self', 'store', 'team'] as $c) { $v = str_replace(',', '.', trim((string)($_POST['w_' . $c] ?? '0'))); if (!is_numeric($v) || $v < 0 || $v > 100) $err[] = 'Les poids doivent être compris entre 0 et 100.'; $d['w_' . $c] = (float)$v; }
        if (!$err && abs(array_sum([$d['w_qc'], $d['w_self'], $d['w_store'], $d['w_team']]) - 100) > 0.01) $err[] = 'Le total des poids doit faire 100 % (actuellement ' . rtrim(rtrim(number_format($d['w_qc'] + $d['w_self'] + $d['w_store'] + $d['w_team'], 2, ',', ''), '0'), ',') . ' %).';
        $d['csat_mode'] = isset(Qn::CSATMODE[$_POST['csat_mode'] ?? '']) ? $_POST['csat_mode'] : 'pct'; $d['agg_mode'] = isset(Qn::AGG[$_POST['agg_mode'] ?? '']) ? $_POST['agg_mode'] : 'all'; $d['missing'] = isset(Qn::MISSING[$_POST['missing'] ?? '']) ? $_POST['missing'] : 'redistribute';
        $d['min_qc'] = max(0, (int)($_POST['min_qc'] ?? 1)); $d['min_csat'] = (int)($_POST['min_csat'] ?? 0) ?: null; $d['priority'] = (int)($_POST['priority'] ?? 10); $d['channel_kind'] = isset(Qn::KIND[$_POST['channel_kind'] ?? '']) ? $_POST['channel_kind'] : null;
        $d['function_like'] = mb_substr(trim((string)($_POST['function_like'] ?? '')), 0, 120) ?: null; $d['position_id'] = (int)($_POST['position_id'] ?? 0) ?: null; $d['team_id'] = (int)($_POST['team_id'] ?? 0) ?: null; $d['note'] = mb_substr(trim((string)($_POST['note'] ?? '')), 0, 500) ?: null; $d['active'] = empty($_POST['inactive']) ? 1 : 0;
        return [$d, $err];
    }
    /** Enregistrer = créer une nouvelle version (l'ancienne reste dans l'historique et s'applique avant la date d'effet). */
    function profileSave(string $id = ''): void {
        [$v, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => 1, 'max' => 150]], $_POST); [$d, $e2] = $this->parse(); $err = array_merge((array)$err, $e2);
        $from = (string)($_POST['effective_from'] ?? date('Y-m-d')); if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) $err[] = 'Date d\'effet invalide.';
        $old = (int)$id ? DB::one('SELECT * FROM qn_profiles WHERE id=?', [(int)$id]) : null; if ((int)$id && !$old) { $this->notFound(); return; }
        $code = $old['code'] ?? strtoupper(trim(preg_replace('/[^A-Za-z0-9]+/', '-', iconv('UTF-8', 'ASCII//TRANSLIT', (string)($_POST['name'] ?? ''))), '-')); if (!$old && ($code === '' || DB::val('SELECT 1 FROM qn_profiles WHERE code=?', [$code]))) $err[] = 'Un profil de ce nom existe déjà.';
        if ($err) $this->go('quality-note/profiles', implode(' ', $err), 'danger');
        $ver = $old ? 1 + (int)DB::val('SELECT MAX(version) FROM qn_profiles WHERE code=?', [$code]) : 1;
        $nid = DB::insert('qn_profiles', $d + ['code' => $code, 'name' => $v['name'], 'version' => $ver, 'effective_from' => $from, 'created_by' => Auth::id(), 'created_at' => now()]);
        Audit::log('save', 'qn_profile', (string)$nid, null, ['code' => $code, 'version' => $ver]); $this->go('quality-note/profiles', "Profil enregistré (version $ver, effective le " . date('d/m/Y', strtotime($from)) . ').');
    }
    function settingsSave(): void { Settings::set('qn.team_weighted', empty($_POST['team_weighted']) ? '0' : '1'); Audit::log('save', 'qn_settings'); $this->go('quality-note/profiles', 'Réglage enregistré.'); }
    /** Simulation : compare la règle en vigueur à la règle saisie, sans rien enregistrer. */
    function simulate(string $id): void {
        $cur = DB::one('SELECT * FROM qn_profiles WHERE id=?', [(int)$id]); if (!$cur) { $this->notFound(); return; } [$d, $err] = $this->parse(); [$from, $to] = Qn::period($_POST);
        if ($err) $this->go('quality-note/profiles', implode(' ', $err), 'danger'); $new = $d + $cur; $new['name'] = $cur['name'] . ' (simulation)'; $out = []; $sa = 0; $sb = 0; $n = 0;
        foreach (DB::all("SELECT id FROM employees WHERE status<>'left'") as $r) { $e = Qn::employee((int)$r['id']); $p = Qn::profileFor($e, $to); if (!$p || $p['code'] !== $cur['code'] || !Scope::allows((int)$e['id'])) continue;
            $a = Qn::compute((int)$e['id'], $from, $to, $p); $b = Qn::compute((int)$e['id'], $from, $to, $new); $out[] = ['e' => $e, 'a' => $a['score'], 'b' => $b['score'], 'sa' => $a['status'], 'sb' => $b['status']]; if ($a['score'] !== null && $b['score'] !== null) { $sa += $a['score']; $sb += $b['score']; $n++; } }
        usort($out, fn($x, $y) => abs(($y['b'] ?? 0) - ($y['a'] ?? 0)) <=> abs(($x['b'] ?? 0) - ($x['a'] ?? 0)));
        $this->view('qnote/simulate', ['title' => 'Simulation — ' . $cur['name'], 'cur' => $cur, 'new' => $new, 'rows' => array_slice($out, 0, 60), 'count' => count($out), 'avgA' => $n ? round($sa / $n, 1) : null, 'avgB' => $n ? round($sb / $n, 1) : null, 'n' => $n, 'from' => $from, 'to' => $to]);
    }
}
