<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Itil, Notifier, Tickets};

/** Lot 54 : pilotage, problèmes et erreurs connues (M33), changements (M34). */
class ItilController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    // ------------------------------------------------------------------ pilotage
    function home(): void {
        $now = date('Y-m-d H:i:s'); $m0 = date('Y-m-01 00:00:00');
        $chg = DB::all("SELECT outcome, COUNT(*) c FROM at_changes WHERE status='done' GROUP BY outcome"); $tot = array_sum(array_column($chg, 'c')); $ok = 0; foreach ($chg as $r) if ($r['outcome'] === 'success') $ok += (int)$r['c'];
        $ints = (int)DB::val("SELECT COUNT(*) FROM at_interventions WHERE status='done'"); $first = (int)DB::val("SELECT COUNT(*) FROM at_interventions WHERE status='done' AND outcome='resolved'");
        $k = ['prb_open' => (int)DB::val("SELECT COUNT(*) FROM at_problems WHERE status<>'closed'"), 'ke' => (int)DB::val('SELECT COUNT(*) FROM at_known_errors WHERE published=1'), 'repeated' => count(Itil::repeated()),
              'chg_pending' => (int)DB::val("SELECT COUNT(*) FROM at_changes WHERE status IN ('submitted','coord_ok')"), 'chg_next' => (int)DB::val("SELECT COUNT(*) FROM at_changes WHERE status IN ('approved','in_progress') AND win_start>=?", [$now]),
              'chg_rate' => $tot ? round(100 * $ok / $tot) : null, 'int_week' => (int)DB::val("SELECT COUNT(*) FROM at_interventions WHERE status IN ('planned','on_site') AND planned_at>=? AND planned_at<=?", [date('Y-m-d 00:00:00'), date('Y-m-d 23:59:59', strtotime('+7 days'))]),
              'int_first' => $ints ? round(100 * $first / $ints) : null, 'acc_wait' => (int)DB::val("SELECT COUNT(*) FROM at_access_requests WHERE status IN ('submitted','validated')"),
              'accounts' => (int)DB::val("SELECT COUNT(*) FROM at_app_accounts WHERE status='active'"), 'stock_low' => (int)DB::val('SELECT COUNT(*) FROM at_stock WHERE active=1 AND qty<=min_qty AND min_qty>0')];
        $this->view('itil/home', ['title' => 'Pilotage ITSM', 'k' => $k, 'rep' => Itil::repeated(), 'chgs' => $chg,
            'prb' => DB::all("SELECT p.*, (SELECT COUNT(*) FROM at_problem_tickets x WHERE x.problem_id=p.id) n FROM at_problems p WHERE p.status<>'closed' ORDER BY p.created_at DESC LIMIT 6"),
            'next' => DB::all("SELECT * FROM at_changes WHERE status IN ('approved','in_progress') AND win_start>=? ORDER BY win_start LIMIT 6", [$m0])]);
    }
    // ------------------------------------------------------------------ problèmes
    private function prb(string $id): ?array { $p = DB::one('SELECT * FROM at_problems WHERE id=?', [(int)$id]); if (!$p) $this->notFound(); return $p; }
    function prbIndex(): void {
        $w = ['1=1']; $p = []; $st = (string)($_GET['status'] ?? 'open');
        if ($st === 'open') $w[] = "p.status<>'closed'"; elseif (isset(Itil::PRB[$st])) { $w[] = 'p.status=?'; $p[] = $st; }
        if (($q = trim((string)($_GET['q'] ?? ''))) !== '') { $w[] = '(p.title LIKE ? OR p.ref LIKE ? OR p.category LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $from = 'at_problems p LEFT JOIN stores s ON s.id=p.store_id LEFT JOIN users o ON o.id=p.owner_id WHERE ' . implode(' AND ', $w);
        $this->view('itil/prb_index', ['title' => 'Problèmes et erreurs connues', 'p' => paginate($from, $p, $this->page(), 25, 'p.*, s.name store, o.name owner, (SELECT COUNT(*) FROM at_problem_tickets x WHERE x.problem_id=p.id) n', 'p.id DESC'), 'st' => $st, 'rep' => Itil::repeated()]);
    }
    function prbNew(): void { $tk = (int)($_GET['ticket'] ?? 0) ? DB::one('SELECT id, reference, title, category, store_id FROM at_tickets WHERE id=?', [(int)$_GET['ticket']]) : null; $this->view('itil/prb_form', ['title' => 'Nouveau problème', 'tk' => $tk, 'v' => ['title' => $tk['title'] ?? '', 'category' => $tk['category'] ?? (string)($_GET['category'] ?? ''), 'store_id' => (int)($tk['store_id'] ?? ($_GET['store_id'] ?? 0))], 'stores' => DB::all('SELECT id, name FROM stores ORDER BY name'), 'users' => Itil::users('at.handle')]); }
    function prbStore(): void {
        $t = trim((string)$this->in('title')); if ($t === '' || mb_strlen($t) > 250) $this->go('prb/new', 'L\'intitulé est obligatoire (250 caractères au plus).', 'danger');
        $cat = mb_substr(trim((string)$this->in('category')), 0, 60) ?: null; $sid = (int)$this->in('store_id', 0) ?: null; if ($sid && !DB::val('SELECT 1 FROM stores WHERE id=?', [$sid])) $sid = null;
        $id = DB::insert('at_problems', ['ref' => Itil::ref('PRB', 'at_problems'), 'title' => $t, 'description' => mb_substr(trim((string)$this->in('description')), 0, 5000) ?: null, 'category' => $cat, 'store_id' => $sid, 'status' => 'open', 'owner_id' => (int)$this->in('owner_id', 0) ?: Auth::id(), 'created_by' => Auth::id(), 'created_at' => now()]);
        $n = 0; if ($cat && $sid) foreach (DB::all("SELECT id FROM at_tickets WHERE kind='incident' AND category=? AND store_id=? AND created_at>=? ORDER BY id", [$cat, $sid, date('Y-m-d H:i:s', time() - max(1, (int)setting('prb.days', 7)) * 86400)]) as $x) if (Itil::linkTicket($id, (int)$x['id'])) $n++;
        if ((int)$this->in('ticket_id', 0) && DB::val('SELECT 1 FROM at_tickets WHERE id=?', [(int)$this->in('ticket_id')]) && Itil::linkTicket($id, (int)$this->in('ticket_id'))) $n++;
        Audit::log('create', 'at_problem', $id); $this->go("prb/$id", "Problème ouvert" . ($n ? " ; $n incident(s) rattaché(s)." : '.'));
    }
    function prbShow(string $id): void {
        if (!($p = $this->prb($id))) return;
        $this->view('itil/prb_show', ['title' => $p['ref'], 'p' => $p, 'tickets' => DB::all('SELECT t.id, t.reference, t.title, t.status, t.created_at FROM at_problem_tickets x JOIN at_tickets t ON t.id=x.ticket_id WHERE x.problem_id=? ORDER BY t.created_at DESC', [$p['id']]),
            'ke' => DB::one('SELECT * FROM at_known_errors WHERE problem_id=? ORDER BY id DESC LIMIT 1', [$p['id']]), 'chg' => $p['change_id'] ? DB::one('SELECT id, ref, title, status FROM at_changes WHERE id=?', [$p['change_id']]) : null,
            'chgs' => DB::all("SELECT id, ref, title FROM at_changes WHERE status NOT IN ('rejected','cancelled') ORDER BY id DESC LIMIT 100"), 'store' => $p['store_id'] ? (string)DB::val('SELECT name FROM stores WHERE id=?', [$p['store_id']]) : '', 'owner' => Itil::name($p['owner_id'] ? (int)$p['owner_id'] : null), 'users' => Itil::users('at.handle')]);
    }
    function prbUpdate(string $id): void {
        if (!($p = $this->prb($id))) return; $act = (string)$this->in('act'); $to = "prb/{$p['id']}";
        if ($act === 'analysis') { DB::update('at_problems', ['analysis' => mb_substr((string)$this->in('analysis'), 0, 8000) ?: null, 'cause' => mb_substr((string)$this->in('cause'), 0, 3000) ?: null, 'workaround' => mb_substr((string)$this->in('workaround'), 0, 3000) ?: null] + ($p['status'] === 'open' ? ['status' => 'analysis'] : []), 'id=?', [$p['id']]); $this->go($to, 'Analyse enregistrée.'); }
        if ($act === 'edit') { $t = trim((string)$this->in('title')); if ($t === '') $this->go($to, 'L\'intitulé est obligatoire.', 'danger'); DB::update('at_problems', ['title' => mb_substr($t, 0, 250), 'description' => mb_substr((string)$this->in('description'), 0, 5000) ?: null, 'owner_id' => (int)$this->in('owner_id', 0) ?: $p['owner_id']], 'id=?', [$p['id']]); $this->go($to, 'Problème modifié.'); }
        if ($act === 'status') {
            $new = (string)$this->in('to'); if (!isset(Itil::PRB[$new]) || $new === $p['status']) $this->go($to, 'Statut inchangé.', 'warning');
            if (in_array($new, ['cause_found', 'resolved', 'closed'], true) && trim((string)($p['cause'] ?? '')) === '' && trim((string)$this->in('cause')) === '') $this->go($to, 'Renseignez la cause avant de passer à ce statut.', 'danger');
            $d = ['status' => $new]; if (trim((string)$this->in('cause')) !== '') $d['cause'] = mb_substr(trim((string)$this->in('cause')), 0, 3000);
            if ($new === 'resolved' || $new === 'closed') $d['resolved_at'] = $p['resolved_at'] ?: now(); if ($new === 'closed') $d['closed_at'] = now(); if ($new === 'open' || $new === 'analysis' || $new === 'cause_found') { $d['closed_at'] = null; }
            DB::update('at_problems', $d, 'id=?', [$p['id']]); $n = 0;
            if (($new === 'resolved' || $new === 'closed') && $this->in('close_tickets')) foreach (DB::all("SELECT t.* FROM at_problem_tickets x JOIN at_tickets t ON t.id=x.ticket_id WHERE x.problem_id=? AND t.status IN ('new','assigned','in_progress','waiting')", [$p['id']]) as $t) {
                DB::update('at_tickets', ['status' => 'resolved', 'resolved_at' => now(), 'resolution' => 'Cause traitée par le problème ' . $p['ref'] . '.'] + Tickets::transition($t, 'resolved'), 'id=?', [$t['id']]); Tickets::event((int)$t['id'], 'status', 'Résolu avec le problème ' . $p['ref'] . '.', Auth::id());
                if ($t['requester_id']) Notifier::send((int)$t['requester_id'], 'Votre demande est résolue : ' . $t['reference'], 'La cause commune a été corrigée (' . $p['ref'] . ').', '/at/' . $t['id']); $n++; }
            Audit::log('status', 'at_problem', $p['id'], $p['status'], $new); $this->go($to, 'Statut : ' . Itil::PRB[$new] . ($n ? " ; $n ticket(s) lié(s) résolu(s) et demandeurs prévenus." : '.'));
        }
        if ($act === 'link') { $r = trim((string)$this->in('ticket')); $t = DB::one('SELECT id FROM at_tickets WHERE reference=? OR id=?', [$r, ctype_digit($r) ? (int)$r : 0]); if (!$t) $this->go($to, 'Ticket introuvable.', 'danger'); $this->go($to, Itil::linkTicket((int)$p['id'], (int)$t['id']) ? 'Ticket rattaché.' : 'Ce ticket est déjà rattaché.'); }
        if ($act === 'unlink') { $t = (int)$this->in('ticket_id'); DB::exec('DELETE FROM at_problem_tickets WHERE problem_id=? AND ticket_id=?', [$p['id'], $t]); $this->go($to, 'Ticket détaché.'); }
        if ($act === 'change') { $c = (int)$this->in('change_id', 0); if ($c && !DB::val('SELECT 1 FROM at_changes WHERE id=?', [$c])) $this->go($to, 'Changement introuvable.', 'danger'); DB::update('at_problems', ['change_id' => $c ?: null], 'id=?', [$p['id']]); $this->go($to, $c ? 'Changement correctif lié.' : 'Lien retiré.'); }
        if ($act === 'ke') {
            $t = trim((string)$this->in('title')) ?: $p['title']; $d = ['title' => mb_substr($t, 0, 250), 'symptoms' => mb_substr((string)$this->in('symptoms'), 0, 3000) ?: null, 'cause' => mb_substr((string)$this->in('cause'), 0, 3000) ?: ($p['cause'] ?: null), 'workaround' => mb_substr((string)$this->in('workaround'), 0, 3000) ?: ($p['workaround'] ?: null), 'updated_at' => now()];
            if (!$d['workaround']) $this->go($to, 'Indiquez au moins un contournement pour documenter l\'erreur connue.', 'danger');
            $ke = DB::one('SELECT * FROM at_known_errors WHERE problem_id=? ORDER BY id DESC LIMIT 1', [$p['id']]);
            if ($ke) { DB::update('at_known_errors', $d, 'id=?', [$ke['id']]); $kid = (int)$ke['id']; } else $kid = DB::insert('at_known_errors', $d + ['problem_id' => $p['id'], 'published' => 0, 'created_by' => Auth::id(), 'created_at' => now()]);
            $this->go($to, 'Erreur connue enregistrée.');
        }
        if ($act === 'ke_publish' || $act === 'ke_unpublish') {
            $ke = DB::one('SELECT * FROM at_known_errors WHERE problem_id=? ORDER BY id DESC LIMIT 1', [$p['id']]); if (!$ke) $this->go($to, 'Documentez d\'abord l\'erreur connue.', 'danger');
            if ($act === 'ke_unpublish') { DB::update('at_known_errors', ['published' => 0], 'id=?', [$ke['id']]); if ($ke['kb_id']) DB::update('kb_articles', ['status' => 'draft'], 'id=?', [$ke['kb_id']]); $this->go($to, 'Erreur connue dépubliée.'); }
            $body = "**Symptômes**\n" . ($ke['symptoms'] ?: '—') . "\n\n**Cause**\n" . ($ke['cause'] ?: 'En cours d\'analyse') . "\n\n**Contournement**\n" . $ke['workaround'];
            if ($ke['kb_id'] && DB::val('SELECT 1 FROM kb_articles WHERE id=?', [$ke['kb_id']])) { DB::update('kb_articles', ['title' => 'Erreur connue : ' . $ke['title'], 'body' => $body, 'status' => 'published', 'search_norm' => null, 'published_at' => now(), 'updated_at' => now()], 'id=?', [$ke['kb_id']]); $kb = (int)$ke['kb_id']; }
            else $kb = DB::insert('kb_articles', ['kind' => 'article', 'title' => mb_substr('Erreur connue : ' . $ke['title'], 0, 190), 'summary' => mb_substr((string)$ke['workaround'], 0, 300), 'body' => $body, 'tags' => 'erreur connue', 'internal' => 1, 'status' => 'published', 'author_id' => Auth::id(), 'published_at' => now(), 'created_at' => now(), 'updated_at' => now()]);
            DB::update('at_known_errors', ['published' => 1, 'kb_id' => $kb], 'id=?', [$ke['id']]); $this->go($to, 'Erreur connue publiée dans la base de connaissances (réservée aux équipes).');
        }
        $this->go($to, 'Action inconnue.', 'danger');
    }
    function prbKe(): void {
        $this->view('itil/ke_index', ['title' => 'Erreurs connues', 'rows' => DB::all('SELECT k.*, p.ref FROM at_known_errors k LEFT JOIN at_problems p ON p.id=k.problem_id ORDER BY k.id DESC LIMIT 300')]);
    }
    /** Rattache le ticket courant à un problème (depuis la fiche ticket). */
    function prbLink(): void {
        $t = (int)$this->in('ticket_id', 0); $pid = (int)$this->in('problem_id', 0); $tk = DB::one('SELECT id, reference FROM at_tickets WHERE id=?', [$t]); if (!$tk) { $this->notFound(); return; }
        if ($pid === 0) { redirect('prb/new?ticket=' . $t); }
        if (!DB::val('SELECT 1 FROM at_problems WHERE id=?', [$pid])) { $this->notFound(); return; }
        $this->go('at/' . $t, Itil::linkTicket($pid, $t) ? 'Ticket rattaché au problème.' : 'Déjà rattaché.');
    }
    // ------------------------------------------------------------------ changements
    private function chg(string $id): ?array { $c = DB::one('SELECT * FROM at_changes WHERE id=?', [(int)$id]); if (!$c) $this->notFound(); return $c; }
    function chgIndex(): void {
        $w = ['1=1']; $p = []; $st = (string)($_GET['status'] ?? 'open');
        if ($st === 'open') $w[] = "c.status IN ('draft','submitted','coord_ok','approved','in_progress')"; elseif ($st === 'wait') $w[] = "c.status IN ('submitted','coord_ok')"; elseif (isset(Itil::CHG[$st])) { $w[] = 'c.status=?'; $p[] = $st; }
        if (isset(Itil::CHG_KIND[(string)($_GET['kind'] ?? '')])) { $w[] = 'c.kind=?'; $p[] = $_GET['kind']; }
        if (($q = trim((string)($_GET['q'] ?? ''))) !== '') { $w[] = '(c.title LIKE ? OR c.ref LIKE ? OR c.targets LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $from = 'at_changes c LEFT JOIN stores s ON s.id=c.store_id LEFT JOIN users u ON u.id=c.requester_id WHERE ' . implode(' AND ', $w);
        if (($_GET['export'] ?? '') === 'csv') { $rows = DB::all("SELECT c.*, s.name store, u.name requester FROM $from ORDER BY c.id DESC", $p); csv_download('changements_' . date('Ymd_His') . '.csv', ['Réf.', 'Titre', 'Type', 'Risque', 'Store', 'Cible', 'Début', 'Fin', 'Statut', 'Résultat', 'Demandeur'], array_map(fn($r) => [$r['ref'], $r['title'], Itil::CHG_KIND[$r['kind']] ?? '', Itil::RISK[$r['risk']] ?? '', $r['store'], $r['targets'], $r['win_start'], $r['win_end'], Itil::CHG[$r['status']] ?? '', Itil::OUTCOME[$r['outcome'] ?? ''] ?? '', $r['requester']], $rows)); }
        $this->view('itil/chg_index', ['title' => 'Changements', 'p' => paginate($from, $p, $this->page(), 25, 'c.*, s.name store, u.name requester', 'c.id DESC'), 'st' => $st]);
    }
    function chgNew(): void { $this->view('itil/chg_form', ['title' => 'Nouvelle demande de changement', 'c' => null, 'stores' => DB::all('SELECT id, name FROM stores ORDER BY name'), 'problem' => (int)($_GET['problem'] ?? 0)]); }
    function chgStore(): void {
        $t = trim((string)$this->in('title')); $kind = (string)$this->in('kind'); $risk = (string)$this->in('risk'); $err = [];
        if ($t === '' || mb_strlen($t) > 250) $err[] = 'L\'intitulé est obligatoire.'; if (!isset(Itil::CHG_KIND[$kind])) $kind = 'normal'; if (!isset(Itil::RISK[$risk])) $risk = 'medium';
        $ws = (string)$this->in('win_start'); $we = (string)$this->in('win_end');
        if (!Itil::okDt($ws) || !Itil::okDt($we)) $err[] = 'La fenêtre souhaitée (début et fin) est obligatoire.'; elseif ($we <= $ws) $err[] = 'La fin de la fenêtre doit suivre le début.';
        $plan = trim((string)$this->in('impl_plan')); $rb = trim((string)$this->in('rollback_plan')); if ($plan === '') $err[] = 'Le plan de mise en œuvre est obligatoire.'; if ($rb === '' && $kind !== 'standard') $err[] = 'Le plan de retour arrière est obligatoire.';
        $sid = (int)$this->in('store_id', 0) ?: null; if ($sid && !DB::val('SELECT 1 FROM stores WHERE id=?', [$sid])) $sid = null; $tg = mb_substr(trim((string)$this->in('targets')), 0, 300) ?: null;
        if (!$sid && !$tg) $err[] = 'Indiquez le store ou l\'application concernés.';
        if ($err) { foreach ($err as $e) flash($e, 'danger'); $_SESSION['_old'] = $_POST; redirect('chg/new'); }
        $d = ['ref' => Itil::ref('CHG', 'at_changes'), 'title' => $t, 'kind' => $kind, 'risk' => $risk, 'impact' => mb_substr(trim((string)$this->in('impact')), 0, 3000) ?: null, 'impl_plan' => mb_substr($plan, 0, 5000), 'rollback_plan' => mb_substr($rb, 0, 3000) ?: null, 'win_start' => Itil::dtv($ws), 'win_end' => Itil::dtv($we), 'targets' => $tg, 'store_id' => $sid,
              'status' => 'draft', 'requester_id' => Auth::id(), 'problem_id' => (int)$this->in('problem_id', 0) ?: null, 'announced' => $this->in('announced') ? 1 : 0, 'created_at' => now(), 'updated_at' => now()];
        $id = DB::insert('at_changes', $d); Itil::clog($id, 'create', 'Création'); if ($d['problem_id']) DB::update('at_problems', ['change_id' => $id], 'id=?', [$d['problem_id']]);
        Audit::log('create', 'at_change', $id); if ($this->in('submit')) { $_POST['act'] = 'submit'; $this->chgUpdate((string)$id); } $this->go("chg/$id", 'Demande enregistrée.');
    }
    function chgShow(string $id): void {
        if (!($c = $this->chg($id))) return;
        $this->view('itil/chg_show', ['title' => $c['ref'], 'c' => $c, 'log' => DB::all('SELECT l.*, u.name FROM at_change_log l LEFT JOIN users u ON u.id=l.user_id WHERE l.change_id=? ORDER BY l.id', [$c['id']]), 'conf' => Itil::conflicts($c, (int)$c['id']), 'after' => $c['status'] === 'done' || $c['status'] === 'in_progress' ? Itil::aftermath($c) : [],
            'store' => $c['store_id'] ? (string)DB::val('SELECT name FROM stores WHERE id=?', [$c['store_id']]) : '', 'requester' => Itil::name($c['requester_id'] ? (int)$c['requester_id'] : null), 'prb' => $c['problem_id'] ? DB::one('SELECT id, ref FROM at_problems WHERE id=?', [$c['problem_id']]) : null]);
    }
    function chgUpdate(string $id): void {
        if (!($c = $this->chg($id))) return; $act = (string)$this->in('act'); $to = "chg/{$c['id']}"; $cm = mb_substr(trim((string)$this->in('comment')), 0, 500); $st = $c['status']; $own = (int)$c['requester_id'] === (int)Auth::id();
        $set = function (string $s, string $a, string $msg = '') use ($c, $cm) { DB::update('at_changes', ['status' => $s, 'updated_at' => now()], 'id=?', [$c['id']]); Itil::clog((int)$c['id'], $a, $msg ?: $cm); Audit::log($a, 'at_change', $c['id'], $c['status'], $s); };
        if ($act === 'submit') {
            if ($st !== 'draft' || !($own || can('chg.manage'))) $this->go($to, 'Action impossible.', 'danger');
            $conf = Itil::conflicts($c, (int)$c['id']); if ($conf && !$this->in('force')) $this->go($to, 'Conflit de fenêtre avec ' . $conf[0]['ref'] . ' : modifiez les dates ou confirmez le passage en force.', 'warning');
            if ($c['kind'] === 'standard') { $set('approved', 'approve', 'Changement standard : pré-approuvé.'); $this->announce($c); $this->go($to, 'Changement standard approuvé automatiquement.'); }
            $set('submitted', 'submit'); Notifier::toPermission($c['kind'] === 'urgent' ? 'chg.cab' : 'chg.coord', ($c['kind'] === 'urgent' ? 'Changement urgent à valider : ' : 'Avis demandé sur un changement : ') . $c['ref'], $c['title'], '/chg/' . $c['id']); $this->go($to, $c['kind'] === 'urgent' ? 'Soumis : validation accélérée par le comité.' : 'Soumis au coordonnateur.');
        }
        if ($act === 'coord') {
            if ($st !== 'submitted' || $c['kind'] !== 'normal' || !can('chg.coord')) $this->go($to, 'Action impossible.', 'danger');
            if ($this->in('ok')) { $set('coord_ok', 'coord', $cm ?: 'Avis favorable'); Notifier::toPermission('chg.cab', 'Changement à valider par le comité : ' . $c['ref'], $c['title'], '/chg/' . $c['id']); $this->go($to, 'Avis favorable donné ; transmis au comité.'); }
            $set('rejected', 'reject', $cm ?: 'Avis défavorable'); if ($c['requester_id']) Notifier::send((int)$c['requester_id'], 'Changement refusé : ' . $c['ref'], $cm, '/chg/' . $c['id']); $this->go($to, 'Changement refusé.');
        }
        if ($act === 'cab') {
            if (!can('chg.cab') || !(($st === 'coord_ok' && $c['kind'] === 'normal') || ($st === 'submitted' && $c['kind'] === 'urgent'))) $this->go($to, 'Action impossible.', 'danger');
            if ($this->in('ok')) { $set('approved', 'approve', $cm ?: 'Approuvé par le comité'); $this->announce($c); if ($c['requester_id']) Notifier::send((int)$c['requester_id'], 'Changement approuvé : ' . $c['ref'], 'Fenêtre : ' . dt($c['win_start']), '/chg/' . $c['id']); $this->go($to, 'Changement approuvé.'); }
            if ($cm === '') $this->go($to, 'Motivez le refus.', 'danger'); $set('rejected', 'reject', $cm); if ($c['requester_id']) Notifier::send((int)$c['requester_id'], 'Changement refusé : ' . $c['ref'], $cm, '/chg/' . $c['id']); $this->go($to, 'Changement refusé.');
        }
        if ($act === 'start') { if ($st !== 'approved' || !(can('chg.manage') || $own)) $this->go($to, 'Action impossible.', 'danger'); $set('in_progress', 'start'); $this->go($to, 'Changement démarré.'); }
        if ($act === 'finish') {
            if ($st !== 'in_progress' || !(can('chg.manage') || $own)) $this->go($to, 'Action impossible.', 'danger'); $o = (string)$this->in('outcome'); if (!isset(Itil::OUTCOME[$o])) $this->go($to, 'Choisissez le résultat.', 'danger');
            DB::update('at_changes', ['status' => 'done', 'outcome' => $o, 'review_note' => mb_substr(trim((string)$this->in('review_note')), 0, 3000) ?: null, 'updated_at' => now()], 'id=?', [$c['id']]); Itil::clog((int)$c['id'], 'finish', Itil::OUTCOME[$o]); Audit::log('finish', 'at_change', $c['id'], $st, 'done'); $this->go($to, 'Bilan enregistré.');
        }
        if ($act === 'cancel') { if (in_array($st, ['done', 'cancelled', 'rejected'], true) || !($own || can('chg.manage'))) $this->go($to, 'Action impossible.', 'danger'); $set('cancelled', 'cancel'); $this->go($to, 'Changement annulé.'); }
        if ($act === 'comment') { if ($cm === '') $this->go($to, 'Commentaire vide.', 'warning'); Itil::clog((int)$c['id'], 'comment', $cm); $this->go($to, 'Commentaire ajouté.'); }
        $this->go($to, 'Action inconnue.', 'danger');
    }
    /** Annonce ciblée : prévient les collaborateurs du store concerné et les techniciens avant la fenêtre. */
    private function announce(array $c): void {
        if (!$c['announced']) return; $body = 'Intervention planifiée le ' . dt($c['win_start']) . ' → ' . dt($c['win_end']) . '. ' . mb_substr((string)$c['impact'], 0, 200);
        if ($c['store_id']) foreach (DB::all("SELECT DISTINCT u.id FROM users u JOIN employees e ON e.id=u.employee_id WHERE e.store_id=? AND u.status='active'", [$c['store_id']]) as $u) Notifier::send((int)$u['id'], 'Maintenance prévue : ' . $c['title'], $body, '/chg/' . $c['id']);
        Notifier::toPermission('at.handle', 'Changement planifié : ' . $c['ref'], $body, '/chg/' . $c['id']);
    }
    function chgCalendar(): void {
        $m = preg_match('/^\d{4}-\d{2}$/', (string)($_GET['m'] ?? '')) ? (string)$_GET['m'] : date('Y-m'); $a = $m . '-01 00:00:00'; $b = date('Y-m-d 23:59:59', strtotime("$m-01 +1 month -1 day"));
        $rows = DB::all("SELECT c.*, s.name store FROM at_changes c LEFT JOIN stores s ON s.id=c.store_id WHERE c.status IN ('submitted','coord_ok','approved','in_progress','done') AND c.win_start<=? AND c.win_end>=? ORDER BY c.win_start", [$b, $a]);
        $conf = []; foreach ($rows as $r) if (in_array($r['status'], ['submitted', 'coord_ok', 'approved', 'in_progress'], true) && Itil::conflicts($r, (int)$r['id'])) $conf[$r['id']] = 1;
        $this->view('itil/chg_calendar', ['title' => 'Calendrier des changements', 'm' => $m, 'rows' => $rows, 'conf' => $conf]);
    }
}
