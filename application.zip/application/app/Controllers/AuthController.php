<?php
namespace App\Controllers;
use App\Core\{Controller, Auth, Activity, Audit, Request};
class AuthController extends Controller {
    function showLogin(): void {
        if (Auth::check()) redirect('/');
        $this->view('auth/login', ['title' => 'Connexion'], 'layout/guest');
    }
    function login(): void {
        Activity::skipRequest();
        $email = (string)$this->in('email'); $r = Auth::attempt($email, (string)$this->in('password'));
        if (!$r['ok']) {
            Activity::event('login_failed', ['module' => 'auth', 'route' => '/login', 'result' => 'denied', 'status_code' => 401, 'user_name' => $r['user']['name'] ?? $email], $r['user']);
            $reason = $r['reason'] ?? 'bad_password'; $ip = Request::ip();
            if (in_array($reason, ['unknown_account', 'blocked_account', 'inactive_account'], true)) Activity::intrusion($reason, $email, $r['user']);
            if (Auth::recentFailures($ip) >= 5 && Auth::recentFailures($ip) % 5 === 0) Activity::intrusion('brute_force', $email, null, ['user_name' => 'IP ' . $ip]);
            flash($r['msg'], 'danger');
            $_SESSION['_old'] = ['email' => $email];
            redirect('login');
        }
        Audit::log('login', 'user', $r['user']['id']);
        Activity::event('login', ['module' => 'auth', 'route' => '/login', 'status_code' => 200], $r['user']);
        $to = $_SESSION['_intended'] ?? '/'; unset($_SESSION['_intended']);
        redirect($to);
    }
    function logout(): void {
        Activity::skipRequest();
        Activity::event('logout', ['module' => 'auth', 'route' => '/logout', 'status_code' => 200]);
        Auth::logout();
        session_start();
        flash('Vous êtes déconnecté.', 'info');
        redirect('login');
    }
}
