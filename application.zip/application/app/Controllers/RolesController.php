<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit};

/** Rôles et droits : création, duplication, modification, suppression, matrice modules / sous-modules / droits détaillés. */
class RolesController extends Controller {
    private function role(string $id): ?array { return DB::one('SELECT * FROM roles WHERE id=?', [(int)$id]); }
    private function codes(int $id): array { return array_column(DB::all('SELECT p.code FROM permissions p JOIN role_permissions rp ON rp.permission_id=p.id WHERE rp.role_id=? ORDER BY p.code', [$id]), 'code'); }
    function index(): void {
        $rows = DB::all('SELECT r.*, (SELECT COUNT(*) FROM user_roles ur WHERE ur.role_id=r.id) users, (SELECT COUNT(*) FROM role_permissions rp WHERE rp.role_id=r.id) perms FROM roles r ORDER BY r.name');
        $this->view('admin/roles/index', ['title' => 'Rôles et droits', 'rows' => $rows, 'total' => (int)DB::val('SELECT COUNT(*) FROM permissions')]);
    }
    function create(): void { $this->view('admin/roles/form', ['title' => 'Nouveau rôle', 'roles' => DB::all('SELECT id, name FROM roles ORDER BY name')]); }
    function store(): void {
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 120], 'description' => ['label' => 'La description', 'max' => 255]], $_POST);
        $code = strtolower(trim((string)$this->in('code', ''))); if ($code === '' && !empty($d['name'])) $code = trim(preg_replace('/[^a-z0-9]+/', '_', strtolower(iconv('UTF-8', 'ASCII//TRANSLIT', $d['name']) ?: $d['name'])), '_');
        if (!preg_match('/^[a-z][a-z0-9_]{1,59}$/', $code)) $err['code'] = 'Code invalide : lettres minuscules, chiffres et « _ » (2 à 60 caractères).'; elseif (DB::val('SELECT 1 FROM roles WHERE code=?', [$code])) $err['code'] = 'Ce code de rôle existe déjà.';
        if (!empty($d['name']) && DB::val('SELECT 1 FROM roles WHERE name=?', [$d['name']])) $err['name'] = 'Un rôle porte déjà ce nom.';
        if ($err) $this->back($err, $_POST, 'admin/roles/new');
        $id = DB::insert('roles', ['code' => $code, 'name' => $d['name'], 'description' => $d['description'], 'is_system' => 0]); $src = (int)$this->in('copy_from', 0); $n = 0;
        if ($src && ($sr = $this->role((string)$src)) && $sr['code'] !== 'admin') foreach (DB::all('SELECT permission_id FROM role_permissions WHERE role_id=?', [$src]) as $x) { DB::insert('role_permissions', ['role_id' => $id, 'permission_id' => (int)$x['permission_id']]); $n++; }
        elseif ($src && $sr && $sr['code'] === 'admin') foreach (DB::all('SELECT id FROM permissions') as $x) { DB::insert('role_permissions', ['role_id' => $id, 'permission_id' => (int)$x['id']]); $n++; }
        Audit::log('create', 'role', $id, null, ['code' => $code, 'name' => $d['name'], 'copied' => $n]); flash($n ? "Rôle créé avec $n droit(s) repris du rôle choisi." : 'Rôle créé : cochez maintenant ses accès.'); redirect("admin/roles/$id");
    }
    function show(string $id): void {
        $r = $this->role($id); if (!$r) { $this->notFound(); return; }
        $perms = DB::all('SELECT * FROM permissions ORDER BY module, code'); $byCode = []; foreach ($perms as $p) $byCode[$p['code']] = $p;
        $groups = []; $items = DB::all('SELECT * FROM menu_items WHERE active=1 ORDER BY sort_order, id');
        foreach ($items as $m) if (!$m['parent_id']) $groups[$m['id']] = $m + ['children' => []];
        foreach ($items as $m) if ($m['parent_id'] && isset($groups[$m['parent_id']]) && $m['permission']) $groups[$m['parent_id']]['children'][] = $m + ['perm' => $byCode[$m['permission']] ?? null];
        $groups = array_values(array_filter($groups, fn($g) => $g['children']));
        $this->view('admin/roles/show', ['title' => $r['name'], 'r' => $r, 'perms' => $perms, 'groups' => $groups, 'users' => DB::all('SELECT u.id, u.name FROM users u JOIN user_roles ur ON ur.user_id=u.id WHERE ur.role_id=? ORDER BY u.name LIMIT 30', [(int)$id]),
            'has' => array_map('intval', array_column(DB::all('SELECT permission_id FROM role_permissions WHERE role_id=?', [(int)$id]), 'permission_id'))]);
    }
    function meta(string $id): void {
        $r = $this->role($id); if (!$r) { $this->notFound(); return; } if ($r['code'] === 'admin') { flash('Le rôle Administrateur ne se modifie pas.', 'warning'); redirect("admin/roles/$id"); }
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 120], 'description' => ['label' => 'La description', 'max' => 255]], $_POST);
        if (!empty($d['name']) && DB::val('SELECT 1 FROM roles WHERE name=? AND id<>?', [$d['name'], (int)$id])) $err['name'] = 'Un rôle porte déjà ce nom.';
        if ($err) { flash(implode(' ', $err), 'danger'); redirect("admin/roles/$id"); }
        DB::update('roles', $d, 'id=?', [(int)$id]); Audit::log('update', 'role', $id, $r, $d); flash('Rôle modifié.'); redirect("admin/roles/$id");
    }
    function update(string $id): void {
        $r = $this->role($id); if (!$r) { $this->notFound(); return; }
        if ($r['code'] === 'admin') { flash('Le rôle Administrateur dispose de tous les droits et ne se modifie pas.', 'warning'); redirect("admin/roles/$id"); }
        $before = $this->codes((int)$id); $ids = array_values(array_unique(array_map('intval', (array)($_POST['perm'] ?? []))));
        if ($ids) $ids = array_map(fn($x) => (int)$x['id'], DB::all('SELECT id FROM permissions WHERE id IN (' . implode(',', $ids) . ')'));
        DB::exec('DELETE FROM role_permissions WHERE role_id=?', [(int)$id]);
        foreach ($ids as $pid) DB::insert('role_permissions', ['role_id' => (int)$id, 'permission_id' => $pid]);
        $after = $this->codes((int)$id); Audit::log('update_permissions', 'role', $id, ['permissions' => $before], ['permissions' => $after, 'added' => array_values(array_diff($after, $before)), 'removed' => array_values(array_diff($before, $after))]);
        flash('Droits du rôle enregistrés (' . count($after) . ').'); redirect("admin/roles/$id");
    }
    function delete(string $id): void {
        $r = $this->role($id); if (!$r) { $this->notFound(); return; }
        if ($r['code'] === 'admin' || $r['is_system']) { flash('Un rôle système ne se supprime pas ; vous pouvez en retirer les droits.', 'danger'); redirect("admin/roles/$id"); }
        if ((int)DB::val('SELECT COUNT(*) FROM user_roles WHERE role_id=?', [(int)$id])) { flash('Ce rôle est encore attribué à des utilisateurs : retirez-le d\'abord.', 'danger'); redirect("admin/roles/$id"); }
        DB::exec('DELETE FROM role_permissions WHERE role_id=?', [(int)$id]); DB::exec('DELETE FROM roles WHERE id=?', [(int)$id]); Audit::log('delete', 'role', $id, $r); flash('Rôle supprimé.'); redirect('admin/roles');
    }
}
