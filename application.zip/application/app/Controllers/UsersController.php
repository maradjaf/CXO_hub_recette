<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Notifier, Auth, Reset};
class UsersController extends Controller {
    static function tempPassword(): string {
        $c = 'ABCDEFGHJKLMNPQRSTUVWXYZ'; $l = 'abcdefghijkmnpqrstuvwxyz'; $n = '23456789';
        $p = $c[random_int(0, 23)] . $l[random_int(0, 23)] . $n[random_int(0, 7)];
        for ($i = 0; $i < 9; $i++) { $s = $c . $l . $n; $p .= $s[random_int(0, strlen($s) - 1)]; }
        return str_shuffle($p);
    }
    function index(): void {
        $q = trim((string)$this->in('q', '')); $w = ['1=1']; $p = [];
        if ($q !== '') { $w[] = '(u.name LIKE ? OR u.email LIKE ?)'; array_push($p, "%$q%", "%$q%"); }
        if ($this->in('status')) { $w[] = 'u.status=?'; $p[] = $this->in('status'); }
        $pg = paginate('users u WHERE ' . implode(' AND ', $w), $p, $this->page(), 25, "u.* ", 'u.name');
        foreach ($pg['rows'] as &$r) $r['roles'] = implode(', ', array_column(DB::all('SELECT r.name FROM roles r JOIN user_roles ur ON ur.role_id=r.id WHERE ur.user_id=?', [$r['id']]), 'name'));
        unset($r);
        $this->view('admin/users/index', ['title' => 'Utilisateurs', 'p' => $pg]);
    }
    private function form(array $u, string $action, string $title): void {
        $this->view('admin/users/form', ['title' => $title, 'u' => $u, 'action' => $action, 'roles' => DB::all('SELECT * FROM roles ORDER BY name'),
            'mine' => $u ? array_column(DB::all('SELECT role_id FROM user_roles WHERE user_id=?', [$u['id']]), 'role_id') : [],
            'employees' => DB::all("SELECT id, first_name, last_name, matricule FROM employees WHERE status='active' ORDER BY last_name, first_name"), 'providers' => \App\Core\Provider::all()]);
    }
    function create(): void { $this->form([], url('admin/users'), 'Nouvel utilisateur'); }
    function edit(string $id): void { $u = DB::one('SELECT * FROM users WHERE id=?', [(int)$id]); if (!$u) { $this->notFound(); return; } $this->form($u, url("admin/users/$id"), 'Modifier ' . $u['name']); }
    function show(string $id): void {
        $u = DB::one('SELECT * FROM users WHERE id=?', [(int)$id]); if (!$u) { $this->notFound(); return; }
        $roles = DB::all('SELECT r.* FROM roles r JOIN user_roles ur ON ur.role_id=r.id WHERE ur.user_id=?', [(int)$id]);
        $last = DB::all('SELECT * FROM user_activity_events WHERE user_id=? ORDER BY id DESC LIMIT 10', [(int)$id]);
        $this->view('admin/users/show', ['title' => $u['name'], 'u' => $u, 'roles' => $roles, 'last' => $last]);
    }
    private function data(?int $id): array {
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'email' => ['label' => 'L\'email', 'req' => true, 'email' => true, 'max' => 190]], $_POST);
        if ($d['email']) $d['email'] = strtolower($d['email']);
        if ($d['email'] && DB::val('SELECT 1 FROM users WHERE email=? AND id<>?', [$d['email'], $id ?? 0])) $err['email'] = 'Cet email est déjà utilisé.';
        $d['employee_id'] = $this->in('employee_id') ? (int)$this->in('employee_id') : null;
        $roles = array_map('intval', (array)($_POST['roles'] ?? []));
        if (!$roles) $err['roles'] = 'Choisissez au moins un rôle.';
        $ec = trim((string)$this->in('employer_code', '')); $d['employer_code'] = null;
        if ($ec !== '') { if (!DB::val("SELECT 1 FROM employers WHERE code=? AND kind='provider' AND active=1", [$ec])) $err['employer_code'] = 'Société prestataire inconnue.'; else $d['employer_code'] = $ec; }
        if ($roles && DB::val("SELECT 1 FROM roles WHERE code='provider_manager' AND id IN (" . implode(',', $roles) . ')') && !$d['employer_code']) $err['employer_code'] = 'Un responsable prestataire doit être rattaché à une société prestataire.';
        return [$d, $err, $roles];
    }
    private function saveRoles(int $uid, array $roles): void {
        DB::exec('DELETE FROM user_roles WHERE user_id=?', [$uid]);
        foreach (array_unique($roles) as $r) DB::insert('user_roles', ['user_id' => $uid, 'role_id' => $r]);
    }
    function store(): void {
        [$d, $err, $roles] = $this->data(null);
        if ($err) $this->back($err, $_POST, 'admin/users/new');
        $pw = self::tempPassword();
        $d += ['password_hash' => password_hash($pw, PASSWORD_DEFAULT), 'status' => 'active', 'must_change_password' => 1, 'created_at' => now(), 'updated_at' => now()];
        $id = DB::insert('users', $d); $this->saveRoles($id, $roles);
        Audit::log('create', 'user', $id, null, $d + ['roles' => $roles]);
        flash("Compte créé. Mot de passe provisoire (à transmettre à l'utilisateur, affiché une seule fois) : <code>$pw</code>", 'success');
        redirect('admin/users/' . $id);
    }
    function update(string $id): void {
        $old = DB::one('SELECT * FROM users WHERE id=?', [(int)$id]); if (!$old) { $this->notFound(); return; }
        [$d, $err, $roles] = $this->data((int)$id);
        $d['status'] = $old['status'] === 'blocked' ? 'blocked' : (in_array($this->in('status'), ['active', 'inactive'], true) ? $this->in('status') : 'active');
        if ((int)$id === \App\Core\Auth::id() && $d['status'] !== 'active') $err['status'] = 'Vous ne pouvez pas désactiver votre propre compte.';
        if ($err) $this->back($err, $_POST, "admin/users/$id/edit");
        $d['updated_at'] = now();
        DB::update('users', $d, 'id=?', [(int)$id]); $this->saveRoles((int)$id, $roles);
        Audit::log('update', 'user', $id, $old, $d + ['roles' => $roles]);
        flash('Utilisateur modifié.'); redirect('admin/users/' . $id);
    }
    function updateReset(string $id): void {
        $u = DB::one('SELECT * FROM users WHERE id=?', [(int)$id]); if (!$u) { $this->notFound(); return; }
        $pw = self::tempPassword();
        DB::update('users', ['password_hash' => password_hash($pw, PASSWORD_DEFAULT), 'must_change_password' => 1, 'failed_attempts' => 0, 'locked_until' => null, 'updated_at' => now()], 'id=?', [(int)$id]);
        Audit::log('password_reset', 'user', $id);
        flash("Mot de passe réinitialisé et compte déverrouillé. Mot de passe provisoire : <code>$pw</code>", 'success');
        redirect('admin/users/' . $id);
    }
    /** Désactive / réactive / force le changement de mot de passe sur un compte (hors compte blocké, qui a son propre circuit). */
    private function applyState(array $u, string $act): ?string {
        if ((int)$u['id'] === Auth::id() && $act !== 'force_pw') return 'Vous ne pouvez pas agir sur votre propre compte.';
        if ($act === 'disable') { if ($u['status'] !== 'active') return 'Seul un compte actif peut être désactivé.'; DB::update('users', ['status' => 'inactive', 'updated_at' => now()], 'id=?', [$u['id']]); DB::exec('UPDATE pw_tokens SET used_at=? WHERE user_id=? AND used_at IS NULL', [now(), $u['id']]); }
        elseif ($act === 'enable') { if ($u['status'] !== 'inactive') return 'Seul un compte désactivé peut être réactivé.'; DB::update('users', ['status' => 'active', 'failed_attempts' => 0, 'locked_until' => null, 'updated_at' => now()], 'id=?', [$u['id']]); }
        elseif ($act === 'force_pw') { if ($u['status'] === 'blocked') return 'Compte bloqué : débloquez-le d\'abord.'; DB::update('users', ['must_change_password' => 1, 'updated_at' => now()], 'id=?', [$u['id']]); }
        elseif ($act === 'unforce_pw') { DB::update('users', ['must_change_password' => 0, 'updated_at' => now()], 'id=?', [$u['id']]); }
        else return 'Action inconnue.';
        Audit::log($act, 'user', $u['id'], ['status' => $u['status'], 'must_change_password' => $u['must_change_password']]);
        return null;
    }
    function state(string $id): void {
        $u = DB::one('SELECT * FROM users WHERE id=?', [(int)$id]); if (!$u) { $this->notFound(); return; }
        $act = (string)$this->in('act', ''); $e = $this->applyState($u, $act);
        flash($e ?? ['disable' => 'Compte désactivé : la connexion est refusée.', 'enable' => 'Compte réactivé.', 'force_pw' => 'Le mot de passe devra être changé à la prochaine connexion.', 'unforce_pw' => 'Changement de mot de passe obligatoire annulé.'][$act], $e ? 'danger' : 'success');
        redirect("admin/users/$id");
    }
    /** Action groupée depuis la liste : désactiver, réactiver ou forcer le changement de mot de passe. */
    function bulk(): void {
        $act = (string)$this->in('act', ''); $ids = array_filter(array_map('intval', (array)($_POST['ids'] ?? [])));
        if (!$ids || !in_array($act, ['disable', 'enable', 'force_pw'], true)) { flash('Cochez au moins un utilisateur et choisissez une action.', 'danger'); redirect('admin/users'); }
        $ok = 0; $ko = 0; foreach ($ids as $i) { $u = DB::one('SELECT * FROM users WHERE id=?', [$i]); if ($u && $this->applyState($u, $act) === null) $ok++; else $ko++; }
        flash("$ok compte(s) mis à jour" . ($ko ? ", $ko ignoré(s) (statut incompatible ou votre propre compte)." : '.'), $ok ? 'success' : 'warning'); redirect('admin/users');
    }
    function block(string $id): void {
        $u = DB::one('SELECT * FROM users WHERE id=?', [(int)$id]); if (!$u) { $this->notFound(); return; }
        $reason = trim((string)$this->in('reason', '')); if (mb_strlen($reason) > 255) $reason = mb_substr($reason, 0, 255);
        if ((int)$id === Auth::id()) { flash('Vous ne pouvez pas bloquer votre propre compte.', 'danger'); redirect("admin/users/$id"); }
        if ($reason === '') { flash('Indiquez le motif du blocage.', 'danger'); redirect("admin/users/$id"); }
        DB::update('users', ['status' => 'blocked', 'blocked_reason' => $reason, 'blocked_at' => now(), 'blocked_by' => Auth::id(), 'updated_at' => now()], 'id=?', [(int)$id]);
        DB::exec('UPDATE pw_tokens SET used_at=? WHERE user_id=? AND used_at IS NULL', [now(), (int)$id]);
        Audit::log('block', 'user', $id, ['status' => $u['status']], ['status' => 'blocked', 'reason' => $reason]); flash('Compte bloqué : la connexion est refusée et les sessions ouvertes sont coupées à la prochaine action.'); redirect("admin/users/$id");
    }
    function unblock(string $id): void {
        $u = DB::one('SELECT * FROM users WHERE id=?', [(int)$id]); if (!$u) { $this->notFound(); return; }
        DB::update('users', ['status' => 'active', 'blocked_reason' => null, 'blocked_at' => null, 'blocked_by' => null, 'failed_attempts' => 0, 'locked_until' => null, 'updated_at' => now()], 'id=?', [(int)$id]);
        Audit::log('unblock', 'user', $id, ['status' => $u['status'], 'reason' => $u['blocked_reason']], ['status' => 'active']); flash('Compte débloqué.'); redirect("admin/users/$id");
    }
    /** Génère un lien à usage unique (24 h) ; l'envoie par e-mail si le courrier est configuré, sinon l'affiche pour transmission. */
    function sendLink(string $id): void {
        $u = DB::one('SELECT * FROM users WHERE id=?', [(int)$id]); if (!$u) { $this->notFound(); return; }
        if ($u['status'] === 'blocked') { flash('Débloquez le compte avant d\'envoyer un lien.', 'danger'); redirect("admin/users/$id"); }
        $tok = Reset::issue((int)$id, 'reset', Auth::id()); $mailed = Reset::mail($u, $tok, 'reset');
        DB::exec("UPDATE pw_requests SET status='done', handled_by=?, handled_at=? WHERE user_id=? AND status='open'", [Auth::id(), now(), (int)$id]);
        Audit::log('password_link', 'user', $id, null, ['mailed' => $mailed]);
        flash($mailed ? 'Lien envoyé par e-mail à ' . e($u['email']) . ' (valable ' . Reset::TTL_HOURS . ' h, usage unique).' : 'Lien à transmettre à l\'utilisateur (valable ' . Reset::TTL_HOURS . ' h, usage unique) : <code class="user-select-all">' . e(Reset::link($tok)) . '</code>', 'success'); redirect("admin/users/$id");
    }
    function requests(): void {
        $st = in_array($this->in('status'), ['open', 'done', 'rejected'], true) ? $this->in('status') : 'open';
        $pg = paginate('pw_requests r LEFT JOIN users u ON u.id=r.user_id WHERE r.status=?', [$st], $this->page(), 25, 'r.*, u.name user_name, u.status user_status', 'r.id DESC');
        $this->view('admin/users/requests', ['title' => 'Demandes de réinitialisation', 'p' => $pg, 'st' => $st, 'open' => (int)DB::val("SELECT COUNT(*) FROM pw_requests WHERE status='open'")]);
    }
    function requestLink(string $rid): void {
        $q = DB::one('SELECT * FROM pw_requests WHERE id=?', [(int)$rid]); if (!$q || !$q['user_id']) { flash('Demande introuvable ou sans compte associé.', 'danger'); redirect('admin/users/requests'); }
        $this->sendLink((string)$q['user_id']);
    }
    function requestReject(string $rid): void {
        $q = DB::one('SELECT * FROM pw_requests WHERE id=?', [(int)$rid]); if (!$q) { $this->notFound(); return; }
        DB::update('pw_requests', ['status' => 'rejected', 'handled_by' => Auth::id(), 'handled_at' => now(), 'note' => mb_substr(trim((string)$this->in('note', '')), 0, 300)], 'id=?', [(int)$rid]);
        Audit::log('reject_reset_request', 'user', $q['user_id']); flash('Demande rejetée.'); redirect('admin/users/requests');
    }
}
