<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Ct, CtFlow, Scope, Settings};

/** Contrats en masse, renouvellements et avenants, « Mes contrats » (signature depuis le tableau de bord, copie PDF). */
class ContractFlowController extends Controller {
    private function types(): array { return DB::all("SELECT v.code, v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='contract_types' AND v.active=1 ORDER BY v.sort_order, v.label"); }
    private function typeOk(string $t): bool { return (bool)DB::val("SELECT 1 FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='contract_types' AND v.code=?", [$t]); }
    private function ids(): array { return array_values(array_unique(array_filter(array_map('intval', (array)($_POST['ids'] ?? []))))); }
    private function date(?string $v): ?string { $v = trim((string)$v); return preg_match('/^\d{4}-\d{2}-\d{2}$/', $v) ? $v : null; }
    private function report(array $r, string $to): never {
        $m = ["{$r['created']} contrat(s) créé(s)"]; if ($r['sent']) $m[] = $r['sent'] . ' envoyé(s) en signature'; if ($r['draft']) $m[] = $r['draft'] . ' en brouillon';
        if ($r['incomplete']) $m[] = $r['incomplete'] . ' à compléter (variables {{…}} non remplies)'; if ($r['nosigner']) $m[] = $r['nosigner'] . ' sans e-mail de signataire'; if ($r['skipped']) $m[] = $r['skipped'] . ' ignoré(s)';
        flash(implode(' · ', $m) . '.', ($r['created'] && !$r['incomplete'] && !$r['nosigner']) ? 'success' : 'warning'); redirect($to);
    }
    private function newReport(): array { return ['created' => 0, 'sent' => 0, 'draft' => 0, 'incomplete' => 0, 'nosigner' => 0, 'skipped' => 0]; }
    private function tally(array &$r, string $state): void { $r['created']++; match ($state) { 'sent' => $r['sent']++, 'incomplete' => $r['incomplete']++, 'nosigner' => $r['nosigner']++, default => $r['draft']++ }; }

    // ---------- établissement en masse ----------
    function bulk(): void {
        [$sw, $sp] = Scope::sql('e.id'); $w = ["e.status<>'left'", $sw]; $p = $sp;
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(e.first_name LIKE ? OR e.last_name LIKE ? OR e.matricule LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        if (($em = (string)$this->in('employer', '')) !== '') { $w[] = 'e.employer=?'; $p[] = $em; }
        if ($this->in('without') === '1') $w[] = "NOT EXISTS (SELECT 1 FROM contracts c WHERE c.employee_id=e.id AND c.status IN ('active','planned'))";
        $rows = DB::all('SELECT e.id, e.first_name, e.last_name, e.matricule, e.email, e.employer, e.hire_date, ' .
            "(SELECT c.type FROM contracts c WHERE c.employee_id=e.id AND c.status='active' ORDER BY c.id DESC LIMIT 1) cur_type, (SELECT c.end_date FROM contracts c WHERE c.employee_id=e.id AND c.status='active' ORDER BY c.id DESC LIMIT 1) cur_end, " .
            "(SELECT COUNT(*) FROM contracts c WHERE c.employee_id=e.id AND c.status='planned') planned FROM employees e WHERE " . implode(' AND ', $w) . ' ORDER BY e.last_name, e.first_name LIMIT 600', $p);
        $this->view('contracts/bulk', ['title' => 'Établir des contrats en masse', 'rows' => $rows, 'types' => $this->types(), 'tpls' => DB::all('SELECT id, name, type FROM ct_templates WHERE active=1 ORDER BY name'),
            'employers' => DB::all('SELECT code, name FROM employers WHERE active=1 ORDER BY name'), 'mailOn' => \App\Core\Mailer::enabled()]);
    }
    function bulkStore(): void {
        $ids = $this->ids(); if (!$ids) { flash('Cochez au moins un collaborateur.', 'warning'); redirect('contracts/bulk'); }
        $type = (string)$this->in('type', ''); if (!$this->typeOk($type)) { flash('Choisissez le type de contrat.', 'danger'); redirect('contracts/bulk'); }
        $start = $this->date($this->in('start_date')); $end = $this->date($this->in('end_date')); if (!$start) { flash('La date de début est obligatoire.', 'danger'); redirect('contracts/bulk'); }
        $tpl = DB::one('SELECT * FROM ct_templates WHERE id=? AND active=1', [(int)$this->in('template_id')]); $send = $this->in('send') === '1'; $extra = CtFlow::parseVars((string)$this->in('vars', ''));
        $r = $this->newReport(); $st = (array)($_POST['start'] ?? []); $en = (array)($_POST['end'] ?? []);
        foreach ($ids as $emp) {
            if (!Scope::allows($emp) || !DB::val('SELECT 1 FROM employees WHERE id=?', [$emp])) { $r['skipped']++; continue; }
            $s = $this->date($st[$emp] ?? '') ?: $start; $e = array_key_exists($emp, $en) ? $this->date($en[$emp]) : $end; if ($e && $e < $s) { $r['skipped']++; continue; }
            [$id, $state] = CtFlow::create($emp, $type, $s, $e, $tpl, 'new', null, $send, $extra); $this->tally($r, $state);
        }
        Audit::log('bulk_create', 'contract', null, null, $r); $this->report($r, 'contracts?status=all');
    }

    // ---------- renouvellements et avenants ----------
    static function horizon(): int { $n = (int)setting('ct.renew_months', 3); return $n >= 1 && $n <= 12 ? $n : 3; }
    static function options(): array { $o = array_values(array_unique(array_filter(array_map('intval', explode(',', (string)setting('ct.renew_options', '1,2,3'))), fn($x) => $x >= 1 && $x <= 12))); sort($o); return $o ?: [1, 2, 3]; }
    function renewals(): void {
        $opts = self::options(); $m = (int)$this->in('months', self::horizon()); if (!in_array($m, $opts, true)) $m = in_array(self::horizon(), $opts, true) ? self::horizon() : $opts[0];
        [$sw, $sp] = Scope::sql('e.id'); $lim = date('Y-m-d', strtotime("+$m months"));
        $rows = DB::all("SELECT c.id, c.employee_id, c.type, c.start_date, c.end_date, c.kind, e.first_name, e.last_name, e.matricule, e.employer, e.email, (SELECT COUNT(*) FROM contracts n WHERE n.employee_id=c.employee_id AND n.status='planned') planned FROM contracts c JOIN employees e ON e.id=c.employee_id " .
            "WHERE c.status='active' AND c.end_date IS NOT NULL AND c.end_date<=? AND e.status<>'left' AND $sw ORDER BY c.end_date, e.last_name", array_merge([$lim], $sp));
        foreach ($rows as &$r) { $r['new_start'] = max(date('Y-m-d', strtotime($r['end_date'] . ' +1 day')), date('Y-m-d')); $a = new \DateTime($r['start_date']); $b = new \DateTime($r['end_date']); $df = $a->diff($b); $mm = max(1, $df->y * 12 + $df->m + ($df->d > 15 ? 1 : 0)); $r['new_end'] = date('Y-m-d', strtotime($r['new_start'] . " +$mm months -1 day")); } unset($r);
        $this->view('contracts/renewals', ['title' => 'Renouvellements et avenants', 'rows' => $rows, 'months' => $m, 'opts' => $opts, 'types' => $this->types(), 'tpls' => DB::all('SELECT id, name, type FROM ct_templates WHERE active=1 ORDER BY name'),
            'horizon' => self::horizon(), 'optsText' => implode(',', $opts), 'mailOn' => \App\Core\Mailer::enabled()]);
    }
    function renewSettings(): void {
        $h = (int)$this->in('horizon', 3); $o = array_values(array_unique(array_filter(array_map('intval', preg_split('/[,\s;]+/', (string)$this->in('options', '1,2,3'))), fn($x) => $x >= 1 && $x <= 12))); sort($o);
        if ($h < 1 || $h > 12 || !$o) { flash('Indiquez un horizon de 1 à 12 mois et au moins un choix (ex. 1,2,3).', 'danger'); redirect('contracts/renewals'); }
        if (!in_array($h, $o, true)) $o[] = $h; sort($o); Settings::set('ct.renew_months', (string)$h); Settings::set('ct.renew_options', implode(',', $o));
        Audit::log('update', 'ct_renew_settings', null, null, ['horizon' => $h, 'options' => $o]); flash('Réglage enregistré.'); redirect('contracts/renewals?months=' . $h);
    }
    function renewStore(): void {
        $ids = $this->ids(); if (!$ids) { flash('Cochez au moins un collaborateur.', 'warning'); redirect('contracts/renewals'); }
        $kind = $this->in('kind') === 'amendment' ? 'amendment' : 'renewal'; $send = $this->in('send') === '1'; $extra = CtFlow::parseVars((string)$this->in('vars', ''));
        $tplId = (int)$this->in('template_id'); $fixed = $tplId ? DB::one('SELECT * FROM ct_templates WHERE id=? AND active=1', [$tplId]) : null;
        $r = $this->newReport(); $st = (array)($_POST['start'] ?? []); $en = (array)($_POST['end'] ?? []); $ty = (array)($_POST['type'] ?? []);
        foreach ($ids as $cid) {
            $c = DB::one("SELECT * FROM contracts WHERE id=? AND status='active'", [$cid]);
            if (!$c || !Scope::allows((int)$c['employee_id']) || DB::val("SELECT 1 FROM contracts WHERE parent_id=? AND status='planned'", [$cid])) { $r['skipped']++; continue; }
            $s = $this->date($st[$cid] ?? ''); $e = $this->date($en[$cid] ?? ''); $type = $this->typeOk((string)($ty[$cid] ?? '')) ? (string)$ty[$cid] : (string)$c['type'];
            if (!$s || ($e && $e < $s)) { $r['skipped']++; continue; }
            $tpl = $fixed ?: CtFlow::bestTemplate($type, $kind);
            $x = $extra; if ($kind === 'amendment' && empty($x['modification'])) $x['modification'] = $e ? 'Le terme du contrat est reporté au ' . d($e) . '.' : 'Le contrat se poursuit pour une durée indéterminée à compter du ' . d($s) . '.';
            [$id, $state] = CtFlow::create((int)$c['employee_id'], $type, $s, $e, $tpl, $kind, (int)$cid, $send, $x, $kind === 'amendment' ? 'Avenant au contrat n° ' . $cid : 'Renouvellement du contrat n° ' . $cid); $this->tally($r, $state);
        }
        Audit::log($kind === 'amendment' ? 'bulk_amend' : 'bulk_renew', 'contract', null, null, $r); $this->report($r, 'contracts?status=planned');
    }
    function activate(string $id): void {
        $ok = CtFlow::activate((int)$id); flash($ok ? 'Contrat activé : l\'ancien contrat est clos.' : 'Ce contrat n\'est pas en attente d\'activation.', $ok ? 'success' : 'warning'); redirect('contracts/' . (int)$id);
    }

    // ---------- Mes contrats ----------
    function mine(): void { $m = CtFlow::mine(); $this->view('contracts/mine', ['title' => 'Mes contrats', 'sign' => $m['sign'], 'own' => $m['own']]); }
    function minePdf(string $id): void {
        $c = DB::one('SELECT * FROM contracts WHERE id=?', [(int)$id]); $u = Auth::user() ?: [];
        $ok = $c && in_array($c['doc_status'], ['to_sign', 'signed'], true) && ((int)$c['employee_id'] === (int)($u['employee_id'] ?? 0) && (int)$c['employee_id'] > 0
            || DB::val('SELECT 1 FROM ct_signers WHERE contract_id=? AND LOWER(email)=?', [(int)$id, strtolower((string)($u['email'] ?? ''))]));
        if (!$ok) { $this->notFound(); return; } Audit::log('pdf', 'contract', $id, null, ['self' => true]); Ct::pdfOut($c, 'contrat-' . $c['id']);
    }
}
