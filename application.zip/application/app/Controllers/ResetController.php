<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Activity, Request, Reset, Auth};

/** Mot de passe oublié (demande), lien à usage unique et saisie du nouveau mot de passe. Pages publiques : réponses volontairement neutres. */
class ResetController extends Controller {
    static function policyError(string $n): ?string { return strlen($n) < 10 || !preg_match('/[A-Z]/', $n) || !preg_match('/[a-z]/', $n) || !preg_match('/\d/', $n) ? 'Le mot de passe doit comporter au moins 10 caractères, avec majuscule, minuscule et chiffre.' : null; }
    static function createRequest(string $email, ?int $userId, string $reason = ''): bool {
        $ip = Request::ip();
        if ((int)DB::val('SELECT COUNT(*) FROM pw_requests WHERE ip=? AND created_at>=?', [$ip, date('Y-m-d H:i:s', time() - 3600)]) >= 5) return false;
        if (DB::val("SELECT 1 FROM pw_requests WHERE email=? AND status='open'", [$email])) return true;
        DB::insert('pw_requests', ['user_id' => $userId, 'email' => $email, 'reason' => mb_substr($reason, 0, 300), 'status' => 'open', 'ip' => $ip, 'created_at' => now()]);
        if ($userId) foreach (DB::all("SELECT DISTINCT ur.user_id FROM user_roles ur JOIN roles r ON r.id=ur.role_id LEFT JOIN role_permissions rp ON rp.role_id=r.id LEFT JOIN permissions p ON p.id=rp.permission_id AND p.code='users.manage' JOIN users u ON u.id=ur.user_id WHERE u.status='active' AND (r.code='admin' OR p.id IS NOT NULL)") as $a) \App\Core\Notifier::send((int)$a['user_id'], 'Demande de réinitialisation', $email . ' demande un lien de mot de passe.', 'admin/users/requests');
        return true;
    }
    function forgot(): void { if (Auth::check()) redirect('profile'); $this->view('auth/forgot', ['title' => 'Mot de passe oublié'], 'layout/guest'); }
    function request(): void {
        Activity::skipRequest();
        $email = strtolower(trim((string)$this->in('email', '')));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { flash('Saisissez une adresse e-mail valide.', 'danger'); redirect('forgot'); }
        $u = DB::one('SELECT * FROM users WHERE email=?', [$email]);
        $ok = self::createRequest($email, $u['id'] ?? null, (string)$this->in('reason', ''));
        if (!$ok) Activity::intrusion('reset_flood', $email);
        elseif (!$u) Activity::intrusion('reset_unknown', $email);
        else Activity::event('reset_request', ['module' => 'auth', 'route' => '/forgot', 'status_code' => 200], $u);
        flash('Si cette adresse correspond à un compte, la demande a été transmise à l\'administrateur, qui vous enverra un lien de réinitialisation.', 'info'); redirect('login');
    }
    function form(string $token): void {
        $t = Reset::find($token);
        if (!$t) { Activity::skipRequest(); if (preg_match('/^[a-f0-9]{48}$/', $token) === 0 || true) Activity::intrusion('reset_bad_token', 'lien'); http_response_code(410); $this->view('auth/reset', ['title' => 'Lien invalide', 'valid' => false, 'token' => ''], 'layout/guest'); return; }
        $this->view('auth/reset', ['title' => 'Nouveau mot de passe', 'valid' => true, 'token' => $token, 't' => $t], 'layout/guest');
    }
    function save(string $token): void {
        Activity::skipRequest();
        $t = Reset::find($token); if (!$t) { Activity::intrusion('reset_bad_token', 'lien'); flash('Ce lien n\'est plus valide : demandez-en un nouveau.', 'danger'); redirect('forgot'); }
        $n = (string)$this->in('new'); $c = (string)$this->in('confirm');
        $err = self::policyError($n) ?? ($n !== $c ? 'La confirmation ne correspond pas.' : null);
        if ($err) { flash($err, 'danger'); redirect('reset/' . $token); }
        if ($t['status'] === 'blocked') { flash('Ce compte est bloqué : contactez l\'administrateur.', 'danger'); redirect('login'); }
        DB::update('users', ['password_hash' => password_hash($n, PASSWORD_DEFAULT), 'must_change_password' => 0, 'failed_attempts' => 0, 'locked_until' => null, 'updated_at' => now()], 'id=?', [(int)$t['user_id']]);
        DB::exec('UPDATE pw_tokens SET used_at=? WHERE user_id=? AND used_at IS NULL', [now(), (int)$t['user_id']]);
        DB::exec("UPDATE pw_requests SET status='done', handled_at=? WHERE user_id=? AND status='open'", [now(), (int)$t['user_id']]);
        $u = DB::one('SELECT * FROM users WHERE id=?', [(int)$t['user_id']]);
        Audit::log('password_reset_link', 'user', $t['user_id']); Activity::event('password_reset', ['module' => 'auth', 'route' => '/reset', 'status_code' => 200], $u);
        flash('Mot de passe modifié. Vous pouvez vous connecter.'); redirect('login');
    }
}
