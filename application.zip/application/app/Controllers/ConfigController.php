<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Settings, Ref};
/** Centre de paramétrage : vue d'ensemble de tout ce qui se configure, export et import de la configuration (JSON). */
class ConfigController extends Controller {
    const FORMAT = 'cxo-config';
    private function areas(): array {
        $c = fn($t, $w = '') => (int)DB::val("SELECT COUNT(*) FROM $t" . ($w ? " WHERE $w" : ''));
        return [
            'Organisation' => [['Équipes', 'Équipes, rattachement aux canaux', '/org/teams', 'org.view', $c('teams')], ['Boutiques', 'Points de vente, villes, régions', '/org/stores', 'org.view', $c('stores')], ['Canaux', 'Canaux de relation client', '/org/channels', 'org.view', $c('channels')], ['Postes', 'Fonctions et postes', '/org/positions', 'org.view', $c('positions')]],
            'Listes de valeurs' => array_map(fn($l) => [$l['label'], 'Module « ' . ($l['module'] ?: 'général') . ' » — ' . $l['n'] . ' valeur(s)', '/admin/referentials/' . $l['id'], 'referentials.view', (int)$l['n']], DB::all('SELECT l.id, l.label, l.module, (SELECT COUNT(*) FROM ref_values v WHERE v.list_id=l.id) n FROM ref_lists l ORDER BY l.module, l.label')),
            'Droits et navigation' => [['Rôles et droits', 'Droits par rôle', '/admin/roles', 'roles.view', $c('roles')], ['Menus', 'Navigation, libellés, ordre, droits', '/admin/menus', 'menus.manage', $c('menu_items')], ['Paramètres', 'Marque, sécurité, planification, projets, événements, scripts, études de cas…', '/admin/settings', 'settings.manage', 0]],
            'Modules' => [['Catégories de la base de connaissances', 'Classement des articles et modes opératoires', '/kb/categories', 'kb.manage', $c('kb_categories')], ['Codes de fin d\'appel', 'Catégories, FCR, ACW cible, script de clôture', '/eoc', 'eoc.manage', $c('cs_end_codes')], ['Piliers et rôles de projet', 'Piliers, rôles, droits de projet', '/pj/config', 'pj.manage', $c('pj_pillars')], ['Grilles qualité', 'Grilles d\'évaluation', '/qa/grids', 'qa.manage', $c('qa_grids')], ['Checklists de contrôle', 'Contrôles N1', '/ca/checklists', 'ca.manage', $c('ca_checklists')], ['Grilles Mystery Customer', 'Grilles de visite', '/cx/grids', 'cx.manage', $c('mc_grids')], ['Assistance technique', 'Délais SLA, calendriers, jours fériés', '/at/settings', 'at.manage', 0]],
        ];
    }
    function index(): void {
        $this->view('admin/config', ['title' => 'Centre de paramétrage', 'areas' => $this->areas()]);
    }
    /** Export JSON de la configuration (réglages, listes de valeurs, catégories, piliers, rôles de projet, codes de fin d'appel). Aucune donnée personnelle. */
    function export(): void {
        $refs = []; foreach (DB::all('SELECT * FROM ref_lists ORDER BY code') as $l) $refs[] = ['code' => $l['code'], 'label' => $l['label'], 'module' => $l['module'], 'active' => (int)$l['active'], 'values' => array_map(fn($v) => ['code' => $v['code'], 'label' => $v['label'], 'sort_order' => (int)$v['sort_order'], 'color' => $v['color'], 'active' => (int)$v['active']], DB::all('SELECT * FROM ref_values WHERE list_id=? ORDER BY sort_order, label', [(int)$l['id']]))];
        $pack = ['format' => self::FORMAT, 'version' => 1, 'exported_at' => now(), 'settings' => array_intersect_key(Settings::all(), SettingsController::known()), 'ref_lists' => $refs,
            'kb_categories' => DB::all('SELECT name, sort_order FROM kb_categories ORDER BY sort_order, name'), 'pj_pillars' => DB::all('SELECT code, name, color, sort_order, active FROM pj_pillars ORDER BY sort_order'),
            'pj_roles' => DB::all('SELECT code, name, access, is_lead, sort_order, active FROM pj_roles ORDER BY sort_order'), 'cs_end_codes' => DB::all('SELECT code, label, category, counts_fcr, needs_note, needs_callback, acw_target_sec, color, sort_order, active, description FROM cs_end_codes ORDER BY sort_order')];
        Audit::log('export', 'config', null, null, ['sections' => array_keys($pack)]);
        header('Content-Type: application/json; charset=utf-8'); header('Content-Disposition: attachment; filename="configuration_' . date('Ymd') . '.json"'); header('X-Content-Type-Options: nosniff');
        echo json_encode($pack, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); exit;
    }
    /** Importe une configuration : ajoute ou met à jour (jamais de suppression). La simulation n'enregistre rien. */
    function import(): void {
        $f = $_FILES['file'] ?? null; if (!$f || $f['error'] !== UPLOAD_ERR_OK || $f['size'] > 1048576) { flash('Choisissez un fichier JSON de configuration (1 Mo maximum).', 'danger'); redirect('admin/config'); }
        $pack = json_decode((string)file_get_contents($f['tmp_name']), true);
        if (!is_array($pack) || ($pack['format'] ?? '') !== self::FORMAT || (int)($pack['version'] ?? 0) !== 1) { flash('Ce fichier n\'est pas une configuration exportée par l\'application.', 'danger'); redirect('admin/config'); }
        $dry = $this->in('dry') === '1'; $n = ['settings' => 0, 'valeurs' => 0, 'listes' => 0, 'catégories' => 0, 'piliers' => 0, 'rôles de projet' => 0, 'codes de fin d\'appel' => 0, 'ignorés' => 0]; $known = SettingsController::known();
        $pdo = DB::pdo(); $pdo->beginTransaction();
        try {
            foreach ((array)($pack['settings'] ?? []) as $k => $v) {
                if (!isset($known[$k]) || !is_scalar($v)) { $n['ignorés']++; continue; } [$val, $e] = SettingsController::check($k, $known[$k][0], (string)$v);
                if ($e) { $n['ignorés']++; continue; } if ((string)Settings::get($k, $known[$k][1]) !== $val) { Settings::set($k, $val); $n['settings']++; } }
            foreach ((array)($pack['ref_lists'] ?? []) as $l) {
                if (!is_array($l) || !preg_match('/^[a-z0-9_]{1,80}$/', (string)($l['code'] ?? '')) || trim((string)($l['label'] ?? '')) === '') { $n['ignorés']++; continue; }
                $row = DB::one('SELECT id FROM ref_lists WHERE code=?', [$l['code']]);
                if ($row) $lid = (int)$row['id']; else { $lid = DB::insert('ref_lists', ['code' => $l['code'], 'label' => mb_substr((string)$l['label'], 0, 150), 'module' => mb_substr((string)($l['module'] ?? ''), 0, 60) ?: null, 'active' => 1]); $n['listes']++; }
                foreach ((array)($l['values'] ?? []) as $v) {
                    $c = trim((string)($v['code'] ?? '')); $lab = trim((string)($v['label'] ?? '')); if ($c === '' || $lab === '' || mb_strlen($c) > 80) { $n['ignorés']++; continue; }
                    $color = isset($v['color']) && preg_match('/^#[0-9A-Fa-f]{6}$/', (string)$v['color']) ? $v['color'] : null; $d = ['label' => mb_substr($lab, 0, 190), 'sort_order' => (int)($v['sort_order'] ?? 0), 'color' => $color, 'active' => !empty($v['active']) ? 1 : 0];
                    $ex = DB::one('SELECT id FROM ref_values WHERE list_id=? AND code=?', [$lid, $c]); if ($ex) DB::update('ref_values', $d, 'id=?', [(int)$ex['id']]); else DB::insert('ref_values', $d + ['list_id' => $lid, 'code' => $c]); $n['valeurs']++; } }
            foreach ((array)($pack['kb_categories'] ?? []) as $c) { $nm = trim((string)($c['name'] ?? '')); if ($nm === '' || mb_strlen($nm) > 100) { $n['ignorés']++; continue; } $ex = DB::one('SELECT id FROM kb_categories WHERE name=?', [$nm]); if ($ex) DB::update('kb_categories', ['sort_order' => (int)($c['sort_order'] ?? 0)], 'id=?', [(int)$ex['id']]); else DB::insert('kb_categories', ['name' => $nm, 'sort_order' => (int)($c['sort_order'] ?? 0)]); $n['catégories']++; }
            foreach ((array)($pack['pj_pillars'] ?? []) as $c) { $cd = trim((string)($c['code'] ?? '')); $nm = trim((string)($c['name'] ?? '')); if (!preg_match('/^[A-Za-z0-9_-]{1,40}$/', $cd) || $nm === '') { $n['ignorés']++; continue; } $col = preg_match('/^#[0-9A-Fa-f]{6}$/', (string)($c['color'] ?? '')) ? $c['color'] : '#003A84'; $d = ['name' => mb_substr($nm, 0, 150), 'color' => $col, 'sort_order' => (int)($c['sort_order'] ?? 0), 'active' => !empty($c['active']) ? 1 : 0]; $ex = DB::one('SELECT id FROM pj_pillars WHERE code=?', [$cd]); if ($ex) DB::update('pj_pillars', $d, 'id=?', [(int)$ex['id']]); else DB::insert('pj_pillars', $d + ['code' => $cd]); $n['piliers']++; }
            foreach ((array)($pack['pj_roles'] ?? []) as $c) { $cd = trim((string)($c['code'] ?? '')); $nm = trim((string)($c['name'] ?? '')); if (!preg_match('/^[A-Za-z0-9_-]{1,40}$/', $cd) || $nm === '' || !in_array($c['access'] ?? '', ['manage', 'contribute', 'view'], true)) { $n['ignorés']++; continue; } $d = ['name' => mb_substr($nm, 0, 120), 'access' => $c['access'], 'is_lead' => !empty($c['is_lead']) ? 1 : 0, 'sort_order' => (int)($c['sort_order'] ?? 0), 'active' => !empty($c['active']) ? 1 : 0]; $ex = DB::one('SELECT id FROM pj_roles WHERE code=?', [$cd]); if ($ex) DB::update('pj_roles', $d, 'id=?', [(int)$ex['id']]); else DB::insert('pj_roles', $d + ['code' => $cd]); $n['rôles de projet']++; }
            foreach ((array)($pack['cs_end_codes'] ?? []) as $c) { $cd = trim((string)($c['code'] ?? '')); $nm = trim((string)($c['label'] ?? '')); if (!preg_match('/^[A-Za-z0-9_-]{1,40}$/', $cd) || $nm === '' || !isset(\App\Core\Cs::CAT[$c['category'] ?? ''])) { $n['ignorés']++; continue; } $col = preg_match('/^#[0-9A-Fa-f]{6}$/', (string)($c['color'] ?? '')) ? $c['color'] : null; $d = ['label' => mb_substr($nm, 0, 150), 'category' => $c['category'], 'counts_fcr' => !empty($c['counts_fcr']) ? 1 : 0, 'needs_note' => !empty($c['needs_note']) ? 1 : 0, 'needs_callback' => !empty($c['needs_callback']) ? 1 : 0, 'acw_target_sec' => isset($c['acw_target_sec']) && is_numeric($c['acw_target_sec']) ? (int)$c['acw_target_sec'] : null, 'color' => $col, 'sort_order' => (int)($c['sort_order'] ?? 0), 'active' => !empty($c['active']) ? 1 : 0, 'description' => mb_substr((string)($c['description'] ?? ''), 0, 300) ?: null]; $ex = DB::one('SELECT id FROM cs_end_codes WHERE code=?', [$cd]); if ($ex) DB::update('cs_end_codes', $d, 'id=?', [(int)$ex['id']]); else DB::insert('cs_end_codes', $d + ['code' => $cd]); $n['codes de fin d\'appel']++; }
            if ($dry) $pdo->rollBack(); else $pdo->commit();
        } catch (\Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); flash('Import annulé : ' . $e->getMessage(), 'danger'); redirect('admin/config'); }
        Settings::reset(); Ref::reset(); $sum = implode(', ', array_map(fn($k, $v) => "$v $k", array_keys($n), $n));
        if (!$dry) Audit::log('import', 'config', null, null, $n);
        flash(($dry ? 'Simulation (rien n\'a été enregistré) : ' : 'Configuration importée : ') . $sum . '.', $n['ignorés'] ? 'warning' : 'success'); redirect('admin/config');
    }
}
