<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Att, Itil, Notifier, Request, Scope};

/** Lot 56 : pointage sécurisé, statuts de présence, régularisations (M11). */
class AttController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    private function ctx(): array { return ['ip' => Request::ip(), 'ua' => Request::ua(), 'token' => isset($_COOKIE['cxo_dev']) ? (string)$_COOKIE['cxo_dev'] : null]; }
    private function me(): ?array { $e = (int)(Auth::user()['employee_id'] ?? 0); return $e ? DB::one('SELECT e.*, t.name team_name, s.name store_name FROM employees e LEFT JOIN teams t ON t.id=e.team_id LEFT JOIN stores s ON s.id=e.store_id WHERE e.id=?', [$e]) : null; }

    // ------------------------------------------------------------------ pointage du collaborateur
    function index(): void {
        $emp = $this->me(); $today = date('Y-m-d'); $dg = null; $occ = null; $rows = []; $punches = [];
        if ($emp) {
            $dg = Att::diagnose($emp, $this->ctx()); $occ = Att::occurrence((int)$emp['id'], $today) ?: (Att::occurrence((int)$emp['id'], date('Y-m-d', strtotime('-1 day'))));
            for ($i = 0; $i < 14; $i++) { $d = date('Y-m-d', strtotime("-$i day")); $r = Att::computeDay((int)$emp['id'], $d); if ($r) $rows[] = $r; }
            $punches = DB::all("SELECT kind, punched_at, off_plan FROM att_punches WHERE employee_id=? AND day>=? ORDER BY punched_at DESC LIMIT 12", [(int)$emp['id'], date('Y-m-d', strtotime('-2 day'))]);
        }
        $att = DB::all('SELECT attempted_at, kind, code, reason FROM att_attempts WHERE user_id=? ORDER BY attempted_at DESC, id DESC LIMIT 5', [(int)Auth::id()]);
        $this->view('att/index', ['title' => 'Mon pointage', 'emp' => $emp, 'dg' => $dg, 'occ' => $occ, 'rows' => $rows, 'punches' => $punches, 'attempts' => $att, 'shifts' => DB::all('SELECT id, code, name, start_time, end_time FROM pl_shifts')]);
    }
    function punch(): void {
        $kind = (string)$this->in('kind'); $r = Att::punch(Auth::user() ?? [], $kind, $this->ctx());
        $this->go('att', $r['msg'], $r['ok'] ? 'success' : 'danger');
    }

    // ------------------------------------------------------------------ enrôlement d'un poste
    function enrollForm(): void { $this->view('att/enroll', ['title' => 'Enregistrer ce poste', 'dev' => Att::deviceByToken($_COOKIE['cxo_dev'] ?? null), 'ip' => Request::ip()]); }
    function enroll(): void {
        $code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)$this->in('code', '')));
        if (!Att::anyNetwork(Request::ip())) $this->go('att/enroll', 'L\'enrôlement d\'un poste se fait depuis le réseau d\'un site autorisé : le réseau actuel n\'est pas autorisé.', 'danger');
        $dev = $code === '' ? null : DB::one('SELECT * FROM att_devices WHERE code_hash=? AND code_expires>? AND active=1', [Att::hash($code), Att::nowStr()]);
        if (!$dev) { DB::insert('att_attempts', ['user_id' => Auth::id(), 'attempted_at' => Att::nowStr(), 'ip' => Request::ip(), 'user_agent' => mb_substr(Request::ua(), 0, 200), 'kind' => null, 'code' => 'enroll', 'reason' => 'Code d\'enrôlement invalide ou expiré']); $this->go('att/enroll', 'Code invalide ou expiré.', 'danger'); }
        $tok = Att::newToken(); DB::update('att_devices', ['token_hash' => Att::hash($tok), 'code_hash' => null, 'code_expires' => null, 'enrolled_at' => Att::nowStr()], 'id=?', [(int)$dev['id']]);
        setcookie('cxo_dev', $tok, ['expires' => time() + 5 * 365 * 86400, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS'])]);
        Audit::log('update', 'att_device', (int)$dev['id'], null, ['enrolled' => true, 'ip' => Request::ip()]);
        $this->go('att', 'Ce poste est enregistré : « ' . $dev['label'] . ' ».');
    }

    // ------------------------------------------------------------------ effectif du jour
    function team(): void {
        $day = (string)$this->in('day', date('Y-m-d')); if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $day) || !strtotime($day)) $day = date('Y-m-d');
        [$sw, $sp] = Scope::sql('e.id'); $w = ["e.status='active'", $sw]; $p = $sp;
        if ($this->in('team_id')) { $w[] = 'e.team_id=?'; $p[] = (int)$this->in('team_id'); }
        $emps = DB::all('SELECT e.id, e.last_name, e.first_name, e.matricule, t.name team_name FROM employees e LEFT JOIN teams t ON t.id=e.team_id WHERE ' . implode(' AND ', $w) . ' ORDER BY t.name, e.last_name, e.first_name LIMIT 1500', $p);
        $list = []; $cnt = array_fill_keys(array_keys(Att::ST), 0);
        foreach ($emps as $e) { $r = Att::computeDay((int)$e['id'], $day); if (!$r) continue; $cnt[$r['day_status']]++; if ($r['entry_status'] === 'late') $cnt['late']++; if ($r['entry_status'] === 'on_time') $cnt['on_time']++; $list[] = $e + $r; }
        $st = (string)$this->in('status', ''); if ($st !== '') $list = array_values(array_filter($list, fn($r) => $r['day_status'] === $st || $r['entry_status'] === $st));
        if ($this->in('export') === 'csv') {
            Audit::log('export', 'att_team', null, null, ['day' => $day, 'rows' => count($list)]);
            csv_download('presence_' . $day . '.csv', ['Matricule', 'Nom', 'Prénom', 'Équipe', 'Entrée', 'Sortie', 'Statut entrée', 'Statut journée', 'Retard (min)', 'Départ anticipé (min)', 'Temps travaillé (min)', 'Heures supp. (min)', 'Corrigé'],
                array_map(fn($r) => [$r['matricule'], $r['last_name'], $r['first_name'], $r['team_name'], $r['in_at'], $r['out_at'], Att::ST[$r['entry_status']] ?? '', Att::ST[$r['day_status']] ?? '', $r['late_min'], $r['early_min'], $r['worked_min'], $r['overtime_min'], $r['adjusted'] ? 'oui' : 'non'], $list));
        }
        $this->view('att/team', ['title' => 'Effectif du jour', 'day' => $day, 'list' => $list, 'cnt' => $cnt, 'st' => $st, 'teams' => DB::all('SELECT id, name FROM teams ORDER BY name')]);
    }

    // ------------------------------------------------------------------ régularisations
    private function canDecide(array $a): bool {
        $uid = (int)Auth::id(); if ($uid === (int)$a['requester_id']) return false;
        $e = DB::one('SELECT id, manager_id FROM employees WHERE id=?', [(int)$a['employee_id']]); if (!$e) return false;
        if ((int)(Auth::user()['employee_id'] ?? 0) && (int)$e['manager_id'] === (int)Auth::user()['employee_id']) return true;
        return can('att.approve') && Scope::allows((int)$e['id']);
    }
    private function canSee(array $a): bool { return (int)$a['requester_id'] === (int)Auth::id() || (int)$a['employee_id'] === (int)(Auth::user()['employee_id'] ?? 0) || $this->canDecide($a) || (can('att.approve') && Scope::allows((int)$a['employee_id'])); }
    function adjIndex(): void {
        $view = (string)$this->in('view', 'mine'); $me = (int)(Auth::user()['employee_id'] ?? 0); $uid = (int)Auth::id();
        $q = 'att_adjustments a JOIN employees e ON e.id=a.employee_id WHERE '; $p = [];
        if ($view === 'todo') { [$sw, $sp] = Scope::sql('a.employee_id'); $q .= "a.status='pending' AND a.requester_id<>? AND (e.manager_id=? OR (" . (can('att.approve') ? '1=1' : '1=0') . " AND $sw))"; $p = array_merge([$uid, $me ?: 0], $sp); }
        else { $view = 'mine'; $q .= '(a.requester_id=? OR a.employee_id=?)'; $p = [$uid, $me ?: 0]; }
        $todo = (int)DB::val("SELECT COUNT(*) FROM att_adjustments a JOIN employees e ON e.id=a.employee_id WHERE a.status='pending' AND a.requester_id<>? AND (e.manager_id=? OR (" . (can('att.approve') ? '1=1' : '1=0') . ' AND ' . Scope::sql('a.employee_id')[0] . '))', array_merge([$uid, $me ?: 0], Scope::sql('a.employee_id')[1]));
        $this->view('att/adj_index', ['title' => 'Régularisations de pointage', 'view' => $view, 'todo' => $todo, 'p' => paginate($q, $p, $this->page(), 25, 'a.*, e.first_name, e.last_name, e.matricule', 'a.id DESC')]);
    }
    function adjNew(): void {
        $emp = $this->me(); $day = (string)$this->in('day', date('Y-m-d')); if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $day)) $day = date('Y-m-d');
        $eid = (int)$this->in('employee_id', $emp['id'] ?? 0); if ($eid !== (int)($emp['id'] ?? 0) && !(can('att.team') && Scope::allows($eid))) $eid = (int)($emp['id'] ?? 0);
        $team = can('att.team') ? Scope::employees() : [];
        $this->view('att/adj_form', ['title' => 'Demander une régularisation', 'day' => $day, 'eid' => $eid, 'team' => $team, 'eff' => $eid ? Att::effective($eid, $day) : null, 'occ' => $eid ? Att::occurrence($eid, $day) : null]);
    }
    function adjStore(): void {
        $me = (int)(Auth::user()['employee_id'] ?? 0); $eid = (int)$this->in('employee_id', $me);
        if ($eid !== $me && !(can('att.team') && Scope::allows($eid))) { $this->forbidden(); return; }
        if (!$eid) $this->go('att/adjust/new', 'Votre compte n\'est pas rattaché à un collaborateur.', 'danger');
        $day = (string)$this->in('day', ''); $ts = strtotime($day); $err = [];
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $day) || !$ts) $err[] = 'Date invalide.'; elseif ($day > date('Y-m-d')) $err[] = 'On ne régularise pas une date future.'; elseif ($day < date('Y-m-d', strtotime('-31 day'))) $err[] = 'Régularisation possible sur 31 jours au plus.';
        $dt = function (string $k) use ($day, &$err) { $v = trim((string)$this->in($k, '')); if ($v === '') return null; $x = strtotime(str_replace('T', ' ', $v)); if (!$x || !preg_match('/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}/', $v)) { $err[] = 'Heure invalide.'; return null; } if ($x < strtotime($day) - 86400 || $x > strtotime($day) + 3 * 86400) $err[] = 'L\'heure doit rester proche du jour concerné.'; return date('Y-m-d H:i:s', $x); };
        $in = $dt('new_in'); $out = $dt('new_out'); $reason = trim((string)$this->in('reason', ''));
        if (!$in && !$out) $err[] = 'Indiquez l\'heure d\'arrivée ou de départ corrigée.'; if ($in && $out && $out <= $in) $err[] = 'Le départ doit suivre l\'arrivée.';
        if (mb_strlen($reason) < 5) $err[] = 'Le motif est obligatoire (5 caractères au moins).'; if (mb_strlen($reason) > 500) $err[] = 'Motif trop long.';
        if (DB::val("SELECT 1 FROM att_adjustments WHERE employee_id=? AND day=? AND status='pending'", [$eid, $day])) $err[] = 'Une demande est déjà en attente pour ce jour.';
        if ($err) { $_SESSION['_old'] = $_POST; $this->go('att/adjust/new?day=' . urlencode($day) . '&employee_id=' . $eid, implode(' ', array_unique($err)), 'danger'); }
        $eff = Att::effective($eid, $day); $ref = Itil::ref('ATT', 'att_adjustments');
        $id = DB::insert('att_adjustments', ['ref' => $ref, 'employee_id' => $eid, 'day' => $day, 'old_in' => $eff['in'], 'old_out' => $eff['out'], 'new_in' => $in, 'new_out' => $out, 'reason' => mb_substr($reason, 0, 500), 'status' => 'pending', 'requester_id' => Auth::id(), 'created_at' => Att::nowStr()]);
        Audit::log('create', 'att_adjustment', $id, null, ['ref' => $ref, 'employee_id' => $eid, 'day' => $day]);
        $mgr = DB::val('SELECT u.id FROM users u JOIN employees e ON e.manager_id=u.employee_id WHERE e.id=? AND u.status=\'active\' LIMIT 1', [$eid]);
        if ($mgr && (int)$mgr !== (int)Auth::id()) Notifier::send((int)$mgr, 'Régularisation de pointage à valider', $ref . ' · ' . $day, 'att/adjust/' . $id); else Notifier::toPermission('att.approve', 'Régularisation de pointage à valider', $ref . ' · ' . $day, 'att/adjust/' . $id);
        $this->go('att/adjust/' . $id, 'Demande ' . $ref . ' envoyée pour validation.');
    }
    function adjShow(string $id): void {
        $a = DB::one('SELECT a.*, e.first_name, e.last_name, e.matricule FROM att_adjustments a JOIN employees e ON e.id=a.employee_id WHERE a.id=?', [(int)$id]); if (!$a || !$this->canSee($a)) { $this->notFound(); return; }
        $this->view('att/adj_show', ['title' => $a['ref'], 'a' => $a, 'decide' => $a['status'] === 'pending' && $this->canDecide($a), 'requester' => DB::val('SELECT name FROM users WHERE id=?', [(int)$a['requester_id']]), 'validator' => $a['validator_id'] ? DB::val('SELECT name FROM users WHERE id=?', [(int)$a['validator_id']]) : null]);
    }
    function adjDecide(string $id): void {
        $a = DB::one('SELECT * FROM att_adjustments WHERE id=?', [(int)$id]); if (!$a) { $this->notFound(); return; }
        if ($a['status'] !== 'pending') $this->go('att/adjust/' . $id, 'Cette demande est déjà traitée.', 'warning');
        $act = (string)$this->in('act'); $note = trim((string)$this->in('note', ''));
        if ($act === 'cancel') { if ((int)$a['requester_id'] !== (int)Auth::id()) { $this->forbidden(); return; } DB::update('att_adjustments', ['status' => 'cancelled', 'decided_at' => Att::nowStr()], 'id=?', [(int)$id]); Audit::log('update', 'att_adjustment', (int)$id, $a, ['status' => 'cancelled']); $this->go('att/adjust/' . $id, 'Demande annulée.'); }
        if (!$this->canDecide($a)) { $this->forbidden(); return; }
        if (!in_array($act, ['approve', 'reject'], true)) $this->go('att/adjust/' . $id, 'Action inconnue.', 'danger');
        if ($act === 'reject' && mb_strlen($note) < 3) $this->go('att/adjust/' . $id, 'Indiquez le motif du refus.', 'danger');
        $st = $act === 'approve' ? 'approved' : 'rejected';
        DB::update('att_adjustments', ['status' => $st, 'validator_id' => Auth::id(), 'decided_at' => Att::nowStr(), 'decision_note' => mb_substr($note, 0, 300) ?: null], 'id=?', [(int)$id]);
        Audit::log('update', 'att_adjustment', (int)$id, ['status' => 'pending', 'old_in' => $a['old_in'], 'old_out' => $a['old_out']], ['status' => $st, 'new_in' => $a['new_in'], 'new_out' => $a['new_out'], 'validator' => Auth::id()]);
        if ($act === 'approve') Att::computeDay((int)$a['employee_id'], $a['day']);
        Notifier::send((int)$a['requester_id'], 'Régularisation ' . ($act === 'approve' ? 'approuvée' : 'refusée'), $a['ref'] . ' · ' . $a['day'], 'att/adjust/' . $id);
        $this->go('att/adjust/' . $id, $act === 'approve' ? 'Régularisation approuvée : le pointage d\'origine est conservé, la correction est appliquée au calcul.' : 'Régularisation refusée.');
    }

    // ------------------------------------------------------------------ administration : postes, pools, réseaux, tentatives, réglages
    function devices(): void {
        $rows = DB::all('SELECT d.*, s.name store_name, e.first_name, e.last_name, p.name pool_name FROM att_devices d LEFT JOIN stores s ON s.id=d.store_id LEFT JOIN employees e ON e.id=d.employee_id LEFT JOIN att_pools p ON p.id=d.pool_id ORDER BY d.active DESC, d.label');
        $this->view('att/devices', ['title' => 'Postes de pointage', 'rows' => $rows, 'stores' => DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name'), 'pools' => DB::all('SELECT p.*, t.name team_name, (SELECT COUNT(*) FROM att_devices d WHERE d.pool_id=p.id) n FROM att_pools p LEFT JOIN teams t ON t.id=p.team_id ORDER BY p.name'),
            'teams' => DB::all('SELECT id, name FROM teams ORDER BY name'), 'emps' => DB::all("SELECT id, first_name, last_name, matricule FROM employees WHERE status='active' ORDER BY last_name, first_name LIMIT 2000")]);
    }
    private function code(): array { $c = ''; $al = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; for ($i = 0; $i < 8; $i++) $c .= $al[random_int(0, strlen($al) - 1)]; return [$c, Att::hash($c), date('Y-m-d H:i:s', Att::ts() + 86400)]; }
    function deviceStore(): void {
        $label = trim((string)$this->in('label', '')); $type = (string)$this->in('device_type', 'desktop'); $mode = (string)$this->in('mode', 'pool'); $err = [];
        if ($label === '' || mb_strlen($label) > 100) $err[] = 'Le nom du poste est obligatoire (100 caractères au plus).'; if (!in_array($type, ['desktop', 'laptop'], true)) $err[] = 'Seuls les ordinateurs fixes et portables sont acceptés.';
        $emp = $mode === 'emp' ? (int)$this->in('employee_id') : null; $pool = $mode === 'pool' ? (int)$this->in('pool_id') : null;
        if ($mode === 'emp' && !DB::val('SELECT 1 FROM employees WHERE id=?', [$emp])) $err[] = 'Choisissez le collaborateur.'; if ($mode === 'pool' && !DB::val('SELECT 1 FROM att_pools WHERE id=? AND active=1', [$pool])) $err[] = 'Choisissez le pool de postes.';
        if ($err) $this->go('att/devices', implode(' ', $err), 'danger');
        [$c, $h, $x] = $this->code();
        $id = DB::insert('att_devices', ['label' => mb_substr($label, 0, 100), 'device_type' => $type, 'store_id' => (int)$this->in('store_id') ?: null, 'asset_tag' => mb_substr(trim((string)$this->in('asset_tag', '')), 0, 60) ?: null, 'employee_id' => $emp ?: null, 'pool_id' => $pool ?: null, 'code_hash' => $h, 'code_expires' => $x, 'active' => 1, 'created_by' => Auth::id(), 'created_at' => Att::nowStr()]);
        Audit::log('create', 'att_device', $id, null, ['label' => $label, 'type' => $type]);
        $this->go('att/devices', 'Poste « ' . $label . ' » créé. Code d\'enrôlement (valable 24 h, à saisir sur ce poste dans « Enregistrer ce poste ») : <code>' . $c . '</code>');
    }
    function deviceUpdate(string $id): void {
        $d = DB::one('SELECT * FROM att_devices WHERE id=?', [(int)$id]); if (!$d) { $this->notFound(); return; } $act = (string)$this->in('act');
        if ($act === 'toggle') { DB::update('att_devices', ['active' => $d['active'] ? 0 : 1], 'id=?', [(int)$id]); Audit::log('update', 'att_device', (int)$id, ['active' => $d['active']], ['active' => $d['active'] ? 0 : 1]); $this->go('att/devices', $d['active'] ? 'Poste désactivé : il ne peut plus servir à pointer.' : 'Poste réactivé.'); }
        if ($act === 'code') { [$c, $h, $x] = $this->code(); DB::update('att_devices', ['code_hash' => $h, 'code_expires' => $x], 'id=?', [(int)$id]); Audit::log('update', 'att_device', (int)$id, null, ['new_code' => true]); $this->go('att/devices', 'Nouveau code d\'enrôlement (24 h) : <code>' . $c . '</code>'); }
        if ($act === 'assign') {
            $mode = (string)$this->in('mode'); $emp = $mode === 'emp' ? (int)$this->in('employee_id') : null; $pool = $mode === 'pool' ? (int)$this->in('pool_id') : null;
            if (($mode === 'emp' && !DB::val('SELECT 1 FROM employees WHERE id=?', [$emp])) || ($mode === 'pool' && !DB::val('SELECT 1 FROM att_pools WHERE id=?', [$pool])) || !in_array($mode, ['emp', 'pool'], true)) $this->go('att/devices', 'Affectation invalide.', 'danger');
            DB::update('att_devices', ['employee_id' => $emp ?: null, 'pool_id' => $pool ?: null], 'id=?', [(int)$id]); Audit::log('update', 'att_device', (int)$id, ['employee_id' => $d['employee_id'], 'pool_id' => $d['pool_id']], ['employee_id' => $emp, 'pool_id' => $pool]); $this->go('att/devices', 'Affectation modifiée.');
        }
        $this->go('att/devices', 'Action inconnue.', 'danger');
    }
    function poolStore(): void {
        $name = trim((string)$this->in('name', '')); $team = (int)$this->in('team_id') ?: null;
        if ($name === '' || mb_strlen($name) > 100 || !$team || !DB::val('SELECT 1 FROM teams WHERE id=?', [$team])) $this->go('att/devices', 'Indiquez le nom du pool et son équipe.', 'danger');
        if (DB::val('SELECT 1 FROM att_pools WHERE name=?', [$name])) $this->go('att/devices', 'Un pool porte déjà ce nom.', 'danger');
        $id = DB::insert('att_pools', ['name' => $name, 'team_id' => $team, 'active' => 1]); Audit::log('create', 'att_pool', $id, null, ['name' => $name, 'team_id' => $team]); $this->go('att/devices', 'Pool créé.');
    }
    function networks(): void { $this->view('att/networks', ['title' => 'Réseaux autorisés', 'rows' => DB::all('SELECT n.*, s.name store_name FROM att_networks n LEFT JOIN stores s ON s.id=n.store_id ORDER BY n.active DESC, n.label'), 'stores' => DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name'), 'ip' => Request::ip()]); }
    function networkStore(): void {
        $label = trim((string)$this->in('label', '')); $cidr = trim((string)$this->in('cidr', ''));
        if ($label === '' || mb_strlen($label) > 100) $this->go('att/networks', 'Le nom de la plage est obligatoire.', 'danger'); if (!Att::validCidr($cidr)) $this->go('att/networks', 'Plage réseau invalide (exemple : 192.168.10.0/24).', 'danger');
        $id = DB::insert('att_networks', ['label' => mb_substr($label, 0, 100), 'cidr' => $cidr, 'store_id' => (int)$this->in('store_id') ?: null, 'vpn' => $this->in('vpn') ? 1 : 0, 'active' => 1]); Audit::log('create', 'att_network', $id, null, ['cidr' => $cidr]); $this->go('att/networks', 'Plage ajoutée.');
    }
    function networkUpdate(string $id): void {
        $n = DB::one('SELECT * FROM att_networks WHERE id=?', [(int)$id]); if (!$n) { $this->notFound(); return; }
        if ($this->in('act') === 'delete') { DB::exec('DELETE FROM att_networks WHERE id=?', [(int)$id]); Audit::log('delete', 'att_network', (int)$id, $n, null); $this->go('att/networks', 'Plage supprimée.'); }
        DB::update('att_networks', ['active' => $n['active'] ? 0 : 1], 'id=?', [(int)$id]); Audit::log('update', 'att_network', (int)$id, ['active' => $n['active']], ['active' => $n['active'] ? 0 : 1]); $this->go('att/networks', $n['active'] ? 'Plage désactivée.' : 'Plage réactivée.');
    }
    function attempts(): void {
        $w = ['1=1']; $p = [];
        if ($this->in('code')) { $w[] = 'a.code=?'; $p[] = (string)$this->in('code'); }
        if ($this->in('from')) { $w[] = 'a.attempted_at>=?'; $p[] = (string)$this->in('from') . ' 00:00:00'; } if ($this->in('to')) { $w[] = 'a.attempted_at<=?'; $p[] = (string)$this->in('to') . ' 23:59:59'; }
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(e.last_name LIKE ? OR e.first_name LIKE ? OR e.matricule LIKE ? OR a.ip LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%", "%$q%"); }
        $from = 'att_attempts a LEFT JOIN employees e ON e.id=a.employee_id WHERE ' . implode(' AND ', $w);
        if ($this->in('export') === 'csv') { $rows = DB::all("SELECT a.attempted_at, e.matricule, e.last_name, e.first_name, a.kind, a.code, a.reason, a.device_label, a.ip, a.user_agent FROM $from ORDER BY a.attempted_at DESC LIMIT 5000", $p); Audit::log('export', 'att_attempts', null, null, ['rows' => count($rows)]); csv_download('pointages_refuses_' . date('Ymd_His') . '.csv', ['Date', 'Matricule', 'Nom', 'Prénom', 'Action', 'Code', 'Motif', 'Poste', 'IP', 'Navigateur'], array_map('array_values', $rows)); }
        $by = DB::all("SELECT a.code, COUNT(*) c FROM $from GROUP BY a.code ORDER BY c DESC", $p);
        $this->view('att/attempts', ['title' => 'Pointages refusés', 'by' => $by, 'p' => paginate($from, $p, $this->page(), 30, 'a.*, e.first_name, e.last_name, e.matricule', 'a.id DESC')]);
    }
    function settings(): void {
        $this->view('att/settings', ['title' => 'Règles de pointage', 'cfg' => array_combine(array_keys(Att::DEFAULTS), array_map(fn($k) => Att::cfg($k), array_keys(Att::DEFAULTS))),
            'shifts' => DB::all("SELECT s.*, r.late_tol, r.early_tol FROM pl_shifts s LEFT JOIN att_shift_rules r ON r.shift_id=s.id WHERE s.kind='work' ORDER BY s.start_time, s.name")]);
    }
    function settingsSave(): void {
        $lim = ['late_tol' => [0, 120], 'early_tol' => [0, 120], 'before' => [0, 240], 'dedupe' => [5, 300], 'close_after' => [0, 720], 'ot_after' => [0, 240], 'ot_round' => [1, 60], 'ot_max' => [0, 720]];
        foreach ($lim as $k => [$lo, $hi]) { $v = trim((string)$this->in($k, '')); if (!ctype_digit($v) || (int)$v < $lo || (int)$v > $hi) $this->go('att/settings', "Valeur invalide pour « $k » (entre $lo et $hi).", 'danger'); }
        foreach (array_keys($lim) as $k) \App\Core\Settings::set('att.' . $k, (string)(int)$this->in($k)); \App\Core\Settings::set('att.vpn_allowed', $this->in('vpn_allowed') ? '1' : '0');
        foreach ((array)($_POST['late'] ?? []) as $sid => $lv) {
            $sid = (int)$sid; if (!DB::val("SELECT 1 FROM pl_shifts WHERE id=? AND kind='work'", [$sid])) continue; $ev = $_POST['early'][$sid] ?? '';
            $l = ctype_digit((string)$lv) && (int)$lv <= 120 ? (int)$lv : null; $e2 = ctype_digit((string)$ev) && (int)$ev <= 120 ? (int)$ev : null; $cur = DB::val('SELECT id FROM att_shift_rules WHERE shift_id=?', [$sid]);
            if ($l === null && $e2 === null) { if ($cur) DB::exec('DELETE FROM att_shift_rules WHERE id=?', [(int)$cur]); continue; }
            if ($cur) DB::update('att_shift_rules', ['late_tol' => $l, 'early_tol' => $e2], 'id=?', [(int)$cur]); else DB::insert('att_shift_rules', ['shift_id' => $sid, 'late_tol' => $l, 'early_tol' => $e2]);
        }
        Audit::log('update', 'att_settings', null, null, array_intersect_key($_POST, $lim)); $this->go('att/settings', 'Règles enregistrées.');
    }
}
