<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Mailer, Sms, Wa, Integ, Rn, Tc, Xchg};

/** Diagnostic des canaux d'envoi du module Réunions : état réel, file d'attente, essai immédiat avec le message d'erreur exact de la passerelle. */
class RnDiagController extends Controller {
    function index(): void {
        $q = fn(string $t, string $w = '1=1') => (int)DB::val("SELECT COUNT(*) FROM $t WHERE $w");
        $job = DB::one('SELECT * FROM sys_jobs WHERE name=?', ['rn-reminders']);
        $this->view('rn/diag', ['title' => 'Diagnostic des envois', 'job' => $job, 'me' => DB::one("SELECT email, '' phone FROM users WHERE id=?", [(int)Auth::id()]) ?: [],
            'ch' => ['mail' => Mailer::enabled(), 'sms' => Sms::enabled(), 'wa' => Wa::enabled(), 'wa_on' => Xchg::on('rn.ch_wa'), 'mail_on' => Xchg::on('rn.ch_email'), 'sms_on' => Xchg::on('rn.ch_sms')],
            'q' => ['mail_p' => $q('at_outbox', "status='pending'"), 'mail_f' => $q('at_outbox', "status='failed'"), 'sms_p' => $q('sms_outbox', "status='pending'"), 'sms_f' => $q('sms_outbox', "status='failed'")],
            'errs' => ['mail' => DB::all("SELECT to_email dest, last_error err, created_at FROM at_outbox WHERE last_error IS NOT NULL AND last_error<>'' ORDER BY id DESC LIMIT 5"), 'sms' => DB::all("SELECT to_phone dest, last_error err, created_at FROM sms_outbox WHERE last_error IS NOT NULL AND last_error<>'' ORDER BY id DESC LIMIT 5")],
            'lp' => Xchg::int('tc.longpoll', 0, 30), 'lazy' => Xchg::on('rn.lazy')]);
    }
    function test(): void {
        $kind = (string)$this->in('kind'); $to = trim((string)$this->in('to')); $t = date('d/m/Y H:i');
        try {
            if ($kind === 'mail') {
                if (!Mailer::enabled()) throw new \RuntimeException('SMTP non configuré (SMTP_HOST vide dans .env).'); if (!filter_var($to, FILTER_VALIDATE_EMAIL)) throw new \RuntimeException('Adresse e-mail invalide.');
                Mailer::deliver($to, 'Essai d\'envoi · Réunions', "Ceci est un message d'essai du module Réunions, envoyé le $t.\nSi vous le lisez, les invitations et comptes rendus par e-mail fonctionnent."); $msg = "E-mail d'essai remis au serveur SMTP pour $to.";
            } elseif ($kind === 'sms') {
                if (!Sms::enabled()) throw new \RuntimeException('Passerelle SMS non configurée (SMS_GATEWAY_URL vide dans .env).'); $p = Sms::normalize($to); if (!$p) throw new \RuntimeException('Numéro invalide (format international, 8 à 15 chiffres).');
                Sms::deliver($p, "Essai d'envoi Reunions $t"); $msg = "SMS d'essai accepté par la passerelle pour $p.";
            } else { $this->notFound(); return; }
            Audit::log('test', 'rn_diag', $kind, null, ['ok' => true]); flash('✔ ' . $msg, 'success');
        } catch (\Throwable $e) { Audit::log('test', 'rn_diag', $kind, null, ['ok' => false]); flash('✘ ' . $e->getMessage(), 'danger'); }
        redirect('rn/diagnostic');
    }
}
