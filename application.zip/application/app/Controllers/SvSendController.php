<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Secret, Settings, Sms, Sv, SvSend};

/** Lot 67 — Envoi des enquêtes : suivi des invitations, réglages, fournisseurs SMS/WhatsApp (paramétrables), désinscriptions. */
class SvSendController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    function index(): void {
        $st = (string)$this->in('status'); $q = trim((string)$this->in('q')); $w = '1=1'; $p = [];
        if (isset(SvSend::STATUS[$st])) { $w .= ' AND v.status=?'; $p[] = $st; } if ($q !== '') { $w .= ' AND (v.to_phone LIKE ? OR v.client_name LIKE ?)'; $p[] = "%$q%"; $p[] = "%$q%"; }
        $rows = DB::all("SELECT v.*, s.name survey_name FROM sv_invitations v LEFT JOIN sv_surveys s ON s.id=v.survey_id WHERE $w ORDER BY v.id DESC LIMIT 100", $p);
        $cnt = array_column(DB::all('SELECT status, COUNT(*) n FROM sv_invitations GROUP BY status'), 'n', 'status'); $tot = array_sum($cnt);
        $this->view('survey/sending', ['title' => 'Envoi des enquêtes', 'rows' => $rows, 'cnt' => $cnt, 'tot' => $tot, 'st' => $st, 'q' => $q, 'cfg' => array_combine(array_keys(SvSend::DEFAULTS), array_map(fn($k) => SvSend::cfg($k), array_keys(SvSend::DEFAULTS))),
            'pending' => (int)DB::val("SELECT COUNT(*) FROM sv_interactions WHERE status='pending'"), 'providers' => DB::all('SELECT * FROM sv_providers ORDER BY channel, name'), 'optouts' => DB::all('SELECT * FROM sv_optouts ORDER BY id DESC LIMIT 100'), 'quiet' => SvSend::inQuietHours(), 'rate' => $tot ? round(100 * (($cnt['answered'] ?? 0)) / max(1, ($cnt['sent'] ?? 0) + ($cnt['answered'] ?? 0) + ($cnt['expired'] ?? 0)), 1) : null]);
    }
    function settingsSave(): void {
        $in = $_POST; $err = [];
        foreach (['delay_min' => [0, 10080], 'cooldown_days' => [0, 365], 'max_reminders' => [0, 5], 'expire_days' => [0, 365]] as $k => [$a, $b]) { $v = (string)($in[$k] ?? ''); if (!ctype_digit($v) || (int)$v < $a || (int)$v > $b) $err[] = "« $k » doit être un nombre entre $a et $b."; }
        foreach (['quiet_from', 'quiet_to'] as $k) if (!\App\Core\StoreHours::valid((string)($in[$k] ?? ''))) $err[] = 'Les heures de silence doivent être au format HH:MM.';
        $ord = array_values(array_intersect(array_map('trim', explode(',', (string)($in['order'] ?? ''))), ['whatsapp', 'sms'])); if (!$ord) $ord = ['whatsapp', 'sms'];
        $url = trim((string)($in['public_url'] ?? '')); if ($url !== '' && !preg_match('#^https?://[^\s]+$#', $url)) $err[] = 'L\'adresse publique doit commencer par http:// ou https://.';
        if ($err) $this->go('surveys/sending', implode(' ', $err), 'danger');
        foreach (['delay_min', 'quiet_from', 'quiet_to', 'cooldown_days', 'max_reminders', 'expire_days'] as $k) Settings::set('sv.send.' . $k, (string)$in[$k]);
        Settings::set('sv.send.order', implode(',', $ord)); Settings::set('sv.send.public_url', rtrim($url, '/')); foreach (['fallback', 'auto', 'stop_notice'] as $k) Settings::set('sv.send.' . $k, empty($in[$k]) ? '0' : '1');
        Audit::log('save', 'sv_send_settings'); $this->go('surveys/sending', 'Réglages d\'envoi enregistrés.');
    }
    function run(): void {
        $r = SvSend::run(); if (!empty($_POST['force'])) $r['flush'] = SvSend::flush(100, true); Audit::log('run', 'sv_send', null, null, $r);
        $this->go('surveys/sending', sprintf('Traitement terminé : %d invitation(s) créée(s), %d envoyée(s), %d relance(s), %d échec(s)%s.', $r['plan']['created'], $r['flush']['sent'], $r['remind']['reminded'], $r['flush']['failed'], $r['flush']['waiting'] ? ', ' . $r['flush']['waiting'] . ' en attente (heures de silence)' : ''));
    }
    function invCancel(string $id): void { $this->inv($id, 'cancel'); }
    function invResend(string $id): void { $this->inv($id, 'resend'); }
    private function inv(string $id, string $act): void {
        $v = DB::one('SELECT * FROM sv_invitations WHERE id=?', [(int)$id]); if (!$v) { $this->notFound(); return; }
        if ($act === 'cancel' && in_array($v['status'], ['queued', 'ready', 'sent'], true)) DB::update('sv_invitations', ['status' => 'cancelled'], 'id=?', [$v['id']]);
        elseif ($act === 'resend' && in_array($v['status'], ['failed', 'expired', 'cancelled'], true)) DB::update('sv_invitations', ['status' => $v['channel'] === 'link' ? 'ready' : 'queued', 'tries' => 0, 'last_error' => null], 'id=?', [$v['id']]);
        Audit::log($act, 'sv_invitation', $id); $this->go('surveys/sending', $act === 'cancel' ? 'Invitation annulée.' : 'Invitation remise en file.');
    }
    function optoutAdd(): void {
        $ph = Sms::normalize((string)($_POST['phone'] ?? '')); if (!$ph) $this->go('surveys/sending', 'Numéro invalide.', 'danger');
        if (!DB::val('SELECT 1 FROM sv_optouts WHERE phone=?', [$ph])) DB::insert('sv_optouts', ['phone' => $ph, 'reason' => mb_substr(trim((string)($_POST['reason'] ?? '')) ?: 'Ajout manuel', 0, 200), 'created_at' => now()]);
        Audit::log('create', 'sv_optout', $ph); $this->go('surveys/sending', 'Numéro ajouté à la liste de désinscription.');
    }
    function optoutDel(string $id): void { DB::exec('DELETE FROM sv_optouts WHERE id=?', [(int)$id]); Audit::log('delete', 'sv_optout', $id); $this->go('surveys/sending', 'Numéro retiré de la liste de désinscription.'); }
    // ───────── fournisseurs
    function providers(): void {
        $e = (int)$this->in('edit') ? DB::one('SELECT * FROM sv_providers WHERE id=?', [(int)$this->in('edit')]) : null;
        $this->view('survey/providers', ['title' => 'Fournisseurs SMS et WhatsApp', 'list' => DB::all('SELECT * FROM sv_providers ORDER BY channel, name'), 'e' => $e]);
    }
    function providerSave(string $id = ''): void {
        $old = (int)$id ? DB::one('SELECT * FROM sv_providers WHERE id=?', [(int)$id]) : null; if ((int)$id && !$old) { $this->notFound(); return; }
        $in = $_POST; $err = []; $name = trim((string)($in['name'] ?? '')); if ($name === '' || mb_strlen($name) > 150) $err[] = 'Le nom est obligatoire (150 caractères au plus).';
        $ch = in_array($in['channel'] ?? '', ['sms', 'whatsapp'], true) ? $in['channel'] : 'sms'; $kind = ($in['kind'] ?? '') === 'simulation' ? 'simulation' : 'http'; $url = trim((string)($in['url'] ?? ''));
        if ($kind === 'http' && !preg_match('#^https://[^\s]+$#', $url) && !preg_match('#^http://(127\.0\.0\.1|localhost)(:\d+)?(/[^\s]*)?$#', $url)) $err[] = 'L\'adresse (URL) doit commencer par https://.';
        $extra = trim((string)($in['extra'] ?? '')); if ($extra !== '' && !is_array(json_decode($extra, true))) $err[] = 'Les champs supplémentaires doivent être un objet JSON valide.';
        $auth = in_array($in['auth'] ?? '', ['none', 'bearer', 'header', 'basic'], true) ? $in['auth'] : 'none'; $secret = (string)($in['auth_secret'] ?? '');
        if ($err) $this->go('surveys/providers' . ($old ? '?edit=' . (int)$id : ''), implode(' ', $err), 'danger');
        $d = ['name' => $name, 'channel' => $ch, 'kind' => $kind, 'url' => $kind === 'http' ? $url : null, 'format' => ($in['format'] ?? '') === 'form' ? 'form' : 'json', 'auth' => $auth, 'auth_name' => mb_substr(trim((string)($in['auth_name'] ?? '')), 0, 80) ?: null,
            'field_to' => mb_substr(trim((string)($in['field_to'] ?? '')), 0, 40) ?: null, 'field_text' => mb_substr(trim((string)($in['field_text'] ?? '')), 0, 40) ?: null, 'field_from' => mb_substr(trim((string)($in['field_from'] ?? '')), 0, 40) ?: null, 'sender' => mb_substr(trim((string)($in['sender'] ?? '')), 0, 40) ?: null, 'extra' => $extra ?: null, 'active' => empty($in['inactive']) ? 1 : 0];
        if ($secret !== '') $d['auth_secret'] = Secret::enc($secret); elseif (!$old || $auth === 'none') $d['auth_secret'] = null;
        if ($old) { DB::update('sv_providers', $d, 'id=?', [$old['id']]); $pid = (int)$old['id']; } else $pid = DB::insert('sv_providers', $d + ['is_default' => 0, 'created_at' => now()]);
        if (!DB::val('SELECT 1 FROM sv_providers WHERE channel=? AND is_default=1 AND active=1', [$ch])) DB::update('sv_providers', ['is_default' => 1], 'id=?', [$pid]);
        Audit::log($old ? 'update' : 'create', 'sv_provider', (string)$pid, null, ['name' => $name, 'channel' => $ch, 'kind' => $kind]); $this->go('surveys/providers', 'Fournisseur enregistré.');
    }
    function providerDefault(string $id): void {
        $p = DB::one('SELECT * FROM sv_providers WHERE id=?', [(int)$id]); if (!$p) { $this->notFound(); return; }
        DB::exec('UPDATE sv_providers SET is_default=0 WHERE channel=?', [$p['channel']]); DB::update('sv_providers', ['is_default' => 1, 'active' => 1], 'id=?', [$p['id']]); Audit::log('default', 'sv_provider', $id); $this->go('surveys/providers', 'Fournisseur par défaut mis à jour pour ce canal.');
    }
    function providerDelete(string $id): void {
        $p = DB::one('SELECT * FROM sv_providers WHERE id=?', [(int)$id]); if (!$p) { $this->notFound(); return; }
        if (DB::val('SELECT 1 FROM sv_invitations WHERE provider_id=?', [$p['id']])) { DB::update('sv_providers', ['active' => 0, 'is_default' => 0], 'id=?', [$p['id']]); $this->go('surveys/providers', 'Fournisseur déjà utilisé : désactivé au lieu d\'être supprimé.', 'warning'); }
        DB::exec('DELETE FROM sv_providers WHERE id=?', [$p['id']]); Audit::log('delete', 'sv_provider', $id); $this->go('surveys/providers', 'Fournisseur supprimé.');
    }
    function providerTest(string $id): void {
        $p = DB::one('SELECT * FROM sv_providers WHERE id=?', [(int)$id]); if (!$p) { $this->notFound(); return; }
        $to = Sms::normalize((string)($_POST['phone'] ?? '')); if (!$to && $p['kind'] !== 'simulation') $this->go('surveys/providers', 'Saisissez un numéro de test valide.', 'danger');
        [$ok, $msg] = SvSend::deliver($p, $to ?: '+22800000000', 'Test d\'envoi — CXO Excellence Hub'); DB::update('sv_providers', ['last_test' => now(), 'last_result' => ($ok ? 'Réussi : ' : 'Échec : ') . mb_substr($msg, 0, 250)], 'id=?', [$p['id']]);
        Audit::log('test', 'sv_provider', $id, null, ['ok' => $ok]); $this->go('surveys/providers', ($ok ? 'Test réussi. ' : 'Test en échec. ') . $msg, $ok ? 'success' : 'danger');
    }
}
