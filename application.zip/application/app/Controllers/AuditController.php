<?php
namespace App\Controllers;
use App\Core\{Controller, DB};
class AuditController extends Controller {
    function index(): void {
        $w = ['1=1']; $p = [];
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(user_name LIKE ? OR entity_type LIKE ? OR entity_id LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        foreach (['action', 'entity_type'] as $f) if ($this->in($f)) { $w[] = "$f=?"; $p[] = $this->in($f); }
        if ($this->in('from')) { $w[] = 'created_at>=?'; $p[] = $this->in('from') . ' 00:00:00'; }
        if ($this->in('to')) { $w[] = 'created_at<=?'; $p[] = $this->in('to') . ' 23:59:59'; }
        $pg = paginate('audit_logs WHERE ' . implode(' AND ', $w), $p, $this->page(), 50);
        $this->view('admin/audit/index', ['title' => 'Journal d\'audit', 'p' => $pg,
            'actions' => array_column(DB::all('SELECT DISTINCT action FROM audit_logs ORDER BY action'), 'action'), 'entities' => array_column(DB::all('SELECT DISTINCT entity_type FROM audit_logs ORDER BY entity_type'), 'entity_type')]);
    }
    function show(string $id): void {
        $r = DB::one('SELECT * FROM audit_logs WHERE id=?', [(int)$id]); if (!$r) { $this->notFound(); return; }
        $this->view('admin/audit/show', ['title' => 'Entrée d\'audit n° ' . $id, 'r' => $r]);
    }
}
