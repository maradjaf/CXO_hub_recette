<?php
namespace App\Controllers;
use App\Core\{DB, Audit, Auth, Scope, Ca, QaSessions as S};
/** Débriefings d'activité menés par l'équipe qualité : programmation, compte rendu, statut, report, commentaires et alertes. */
class QaDebriefController extends QaSessionBase {
    protected string $kind = 'debrief'; protected string $path = 'debriefs';
    public function canSee(array $r): bool {
        if ((int)$r['coach_user_id'] === (int)Auth::id() || (int)$r['created_by'] === (int)Auth::id()) return true;
        if ($r['audience'] === 'team' && $r['team_id'] && $r['status'] !== 'cancelled' && can('qa.own') && (int)DB::val('SELECT team_id FROM employees WHERE id=?', [(int)(Auth::user()['employee_id'] ?? 0)]) === (int)$r['team_id']) return true;
        if (!can('qa.view')) return false; $ids = Scope::ids(); if ($ids === null) return true;
        return $r['team_id'] && (bool)DB::val('SELECT 1 FROM employees WHERE team_id=? AND ' . Scope::sql('id')[0], array_merge([(int)$r['team_id']], Scope::sql('id')[1]));
    }
    private function visible(): array {
        if (Scope::ids() === null) return ['1=1', []];
        [$w, $p] = Scope::sql('id');
        return ["(d.coach_user_id=? OR d.created_by=? OR d.team_id IN (SELECT team_id FROM employees WHERE team_id IS NOT NULL AND $w))", array_merge([Auth::id(), Auth::id()], $p)];
    }
    function index(): void {
        [$vw, $p] = $this->visible(); $w = [$vw];
        if (isset(S::ST[$this->in('status')])) { $w[] = 'd.status=?'; $p[] = $this->in('status'); }
        if ($this->in('team_id')) { $w[] = 'd.team_id=?'; $p[] = (int)$this->in('team_id'); }
        if ($this->in('from')) { $w[] = 'd.planned_at>=?'; $p[] = $this->in('from') . ' 00:00:00'; } if ($this->in('to')) { $w[] = 'd.planned_at<=?'; $p[] = $this->in('to') . ' 23:59:59'; }
        $from = 'qa_debriefs d LEFT JOIN teams t ON t.id=d.team_id JOIN users u ON u.id=d.coach_user_id WHERE ' . implode(' AND ', $w); $cols = 'd.*, t.name team_name, u.name coach_name';
        if ($this->in('export') === 'csv') csv_download('debriefings-activite.csv', ['Date', 'Titre', 'Équipe', 'Activité', 'Animateur', 'Statut', 'Compte rendu partagé le'], array_map(fn($r) => [dt($r['planned_at']), $r['title'], $r['team_name'], $r['activity'], $r['coach_name'], S::ST[$r['status']][0] ?? $r['status'], $r['shared_at'] ? dt($r['shared_at']) : ''], DB::all("SELECT $cols FROM $from ORDER BY d.planned_at DESC", $p)));
        $this->view('qa/debriefs', ['title' => 'Débriefings d\'activité', 'p' => paginate($from, $p, $this->page(), 25, $cols, 'd.planned_at DESC, d.id DESC'), 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name')]);
    }
    function create(): void { $this->view('qa/debrief_form', ['title' => 'Programmer un débriefing', 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'), 'coaches' => Ca::usersWith('qa.evaluate')]); }
    function store(): void {
        [$d, $err] = $this->validate(['title' => ['label' => 'Le titre', 'req' => true, 'max' => 190], 'activity' => ['label' => 'L\'activité', 'max' => 150], 'agenda' => ['label' => 'L\'ordre du jour', 'max' => 1000]], $_POST); $aud = $this->in('audience') === 'team' ? 'team' : 'quality';
        $at = S::when($this->in('date'), $this->in('time')); $dur = max(5, min(480, (int)$this->in('duration_min', 60))); $team = (int)$this->in('team_id') ?: null;
        $coach = can('qa.manage') && $this->in('coach_id') ? (int)$this->in('coach_id') : (int)Auth::id();
        if ($team && !DB::val('SELECT 1 FROM teams WHERE id=?', [$team])) $err['team'] = 'Équipe inconnue.';
        if (!$team && !$d['activity']) $err['activity'] = 'Choisissez une équipe ou précisez l\'activité.';
        if ($aud === 'team' && !$team) $err['audience'] = 'Pour diffuser à toute l\'équipe, choisissez une équipe.';
        if (!$at) $err['date'] = 'Indiquez la date du débriefing.'; elseif (strtotime($at) < strtotime(date('Y-m-d'))) $err['date'] = 'La date ne peut pas être passée.';
        if (!in_array($coach, array_map('intval', array_column(Ca::usersWith('qa.evaluate'), 'id')), true)) $err['coach'] = 'Animateur invalide.';
        if ($err) $this->back($err, $_POST, 'qa/debriefs/new');
        $row = ['title' => $d['title'], 'team_id' => $team, 'activity' => $d['activity'], 'audience' => $aud, 'coach_user_id' => $coach, 'planned_at' => $at, 'duration_min' => $dur, 'agenda' => $d['agenda'], 'status' => 'planned', 'created_by' => Auth::id(), 'created_at' => now()];
        $id = DB::insert('qa_debriefs', $row); S::log('debrief', $id, 'planned', null, $at, null); $row['id'] = $id;
        $this->notify($row, 'Débriefing programmé · ' . $d['title'], 'Le ' . dt($at) . ' (' . $dur . ' min)', true, true);
        Audit::log('create', 'qa_debrief', $id, null, $row); flash('Débriefing programmé. Rappels automatiques à J-3 et J-1.'); redirect("qa/debriefs/$id");
    }
    function show(string $id): void {
        $r = $this->open($id); if (!$r) return;
        $this->view('qa/session', $this->detail($r) + ['title' => 'Débriefing d\'activité', 'team' => $r['team_id'] ? DB::val('SELECT name FROM teams WHERE id=?', [(int)$r['team_id']]) : null, 'hideReport' => !$r['shared_at'] && !can('qa.view') && (int)$r['coach_user_id'] !== (int)Auth::id()]);
    }
}
