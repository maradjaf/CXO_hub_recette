<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, DashConfig};
/** Administration : widgets du tableau de bord par rôle ou par utilisateur. */
class DashConfigController extends Controller {
    function index(): void {
        $kind = $this->in('kind') === 'user' ? 'user' : 'role'; $id = (int)$this->in('id', 0);
        $roles = DB::all('SELECT id, name FROM roles ORDER BY name'); $users = DB::all("SELECT id, name FROM users WHERE status='active' ORDER BY name LIMIT 500");
        if (!$id) $id = (int)($kind === 'role' ? ($roles[0]['id'] ?? 0) : ($users[0]['id'] ?? 0));
        $this->view('admin/dashconfig', ['title' => 'Tableaux de bord par rôle ou utilisateur', 'kind' => $kind, 'id' => $id, 'roles' => $roles, 'users' => $users, 'cfg' => DashConfig::of($kind, $id)]);
    }
    function save(): void {
        $kind = $this->in('kind') === 'user' ? 'user' : 'role'; $id = (int)$this->in('id', 0);
        if (!$id || !DB::val($kind === 'role' ? 'SELECT 1 FROM roles WHERE id=?' : 'SELECT 1 FROM users WHERE id=?', [$id])) { $this->notFound(); return; }
        $custom = !isset($_POST['reset']); $vis = array_values(array_intersect((array)($_POST['w'] ?? []), array_keys(DashConfig::WIDGETS)));
        DashConfig::save($kind, $id, $vis, $custom);
        Audit::log('update', 'dash_config', $id, null, ['kind' => $kind, 'widgets' => $custom ? $vis : 'défaut']);
        flash($custom ? 'Tableau de bord enregistré.' : 'Retour à l\'affichage par défaut.'); redirect("admin/dashboards?kind=$kind&id=$id");
    }
}
