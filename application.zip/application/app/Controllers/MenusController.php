<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit};
class MenusController extends Controller {
    function index(): void {
        $items = DB::all('SELECT m.* FROM menu_items m LEFT JOIN menu_items g ON g.id = m.parent_id ORDER BY COALESCE(g.sort_order, m.sort_order), COALESCE(m.parent_id, m.id), m.parent_id IS NOT NULL, m.sort_order, m.id');
        $this->view('admin/menus', ['title' => 'Menus et navigation', 'items' => $items, 'groups' => DB::all('SELECT id, label FROM menu_items WHERE parent_id IS NULL ORDER BY sort_order'),
            'perms' => DB::all('SELECT code FROM permissions ORDER BY code')]);
    }
    private function data(): array {
        [$d, $err] = $this->validate(['label' => ['label' => 'Le libellé', 'req' => true, 'max' => 120], 'icon' => ['max' => 40, 'label' => 'L\'icône'], 'url' => ['max' => 190, 'label' => 'L\'adresse'], 'permission' => ['max' => 80, 'label' => 'Le droit']], $_POST);
        $d['sort_order'] = (int)$this->in('sort_order', 0); $d['active'] = isset($_POST['active']) ? 1 : 0;
        if ($d['url'] && !str_starts_with($d['url'], '/')) $err['url'] = 'L\'adresse doit commencer par /.';
        return [$d, $err];
    }
    function update(string $id): void {
        $old = DB::one('SELECT * FROM menu_items WHERE id=?', [(int)$id]); if (!$old) { $this->notFound(); return; }
        [$d, $err] = $this->data();
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('admin/menus'); }
        $d['parent_id'] = $this->in('parent_id') ? (int)$this->in('parent_id') : null;
        if ($d['parent_id'] === (int)$id) $d['parent_id'] = $old['parent_id'];
        DB::update('menu_items', $d, 'id=?', [(int)$id]); Audit::log('update', 'menu_item', $id, $old, $d);
        flash('Menu mis à jour.'); redirect('admin/menus');
    }
    function store(): void {
        [$d, $err] = $this->data();
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('admin/menus'); }
        $d['code'] = 'custom_' . bin2hex(random_bytes(3)); $d['parent_id'] = $this->in('parent_id') ? (int)$this->in('parent_id') : null;
        $id = DB::insert('menu_items', $d); Audit::log('create', 'menu_item', $id, null, $d);
        flash('Entrée de menu ajoutée.'); redirect('admin/menus');
    }
    function move(string $id): void {
        $m = DB::one('SELECT * FROM menu_items WHERE id=?', [(int)$id]); if (!$m) { $this->notFound(); return; }
        $dir = $this->in('dir') === 'up' ? -1 : 1;
        $sib = $m['parent_id'] === null
            ? DB::all('SELECT id FROM menu_items WHERE parent_id IS NULL ORDER BY sort_order, id')
            : DB::all('SELECT id FROM menu_items WHERE parent_id=? ORDER BY sort_order, id', [(int)$m['parent_id']]);
        $ids = array_map(fn($r) => (int)$r['id'], $sib);
        $i = array_search((int)$id, $ids, true);
        $j = $i + $dir;
        if ($i !== false && isset($ids[$j])) {
            [$ids[$i], $ids[$j]] = [$ids[$j], $ids[$i]];
            foreach ($ids as $k => $mid) DB::exec('UPDATE menu_items SET sort_order=? WHERE id=?', [($k + 1) * 10, $mid]);
            Audit::log('update', 'menu_item', $id, ['sort_order' => $m['sort_order']], ['move' => $dir < 0 ? 'up' : 'down']);
        }
        redirect('admin/menus#m' . (int)$id);
    }
}
