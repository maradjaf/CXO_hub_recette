<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Auth, Scope};
/** Historique qualité d'un collaborateur et état de notation (note par conseiller + note globale d'activité). */
class QaHistoryController extends Controller {
    private function dates(string $defFrom): array {
        $ok = fn($x) => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$x) && strtotime($x);
        $f = $this->in('from'); $t = $this->in('to');
        return [$ok($f) ? $f : $defFrom, $ok($t) ? $t : date('Y-m-d')];
    }
    function employee(string $id): void {
        $e = DB::one('SELECT e.*, t.name team_name FROM employees e LEFT JOIN teams t ON t.id=e.team_id WHERE e.id=?', [(int)$id]); if (!$e) { $this->notFound(); return; }
        $own = (int)(Auth::user()['employee_id'] ?? 0) === (int)$id && can('qa.own');
        if (!$own && !(can('qa.view') && Scope::allows((int)$id))) { $this->forbidden(); return; }
        [$f, $t] = $this->dates(date('Y-m-d', strtotime('-6 months')));
        $evs = DB::all('SELECT v.*, g.name grid_name, u.name evaluator, (SELECT COUNT(*) FROM qa_revisions r WHERE r.evaluation_id=v.id) revs, (SELECT COUNT(*) FROM qa_disputes d WHERE d.evaluation_id=v.id) disps FROM qa_evaluations v JOIN qa_grids g ON g.id=v.grid_id JOIN users u ON u.id=v.evaluator_id WHERE v.employee_id=? AND v.eval_date BETWEEN ? AND ? ORDER BY v.eval_date DESC, v.id DESC', [(int)$id, $f, $t]);
        $months = []; foreach ($evs as $v) { $m = substr($v['eval_date'], 0, 7); $months[$m][] = (float)$v['score_pct']; } ksort($months);
        $months = array_map(fn($a) => ['n' => count($a), 'avg' => round(array_sum($a) / count($a), 1)], $months);
        $crit = DB::all('SELECT c.label, ROUND(AVG(s.points * 100.0 / c.max_points), 1) pct, COUNT(*) n FROM qa_scores s JOIN qa_criteria c ON c.id=s.criterion_id JOIN qa_evaluations v ON v.id=s.evaluation_id WHERE v.employee_id=? AND v.eval_date BETWEEN ? AND ? GROUP BY c.label ORDER BY pct', [(int)$id, $f, $t]);
        $sc = array_map(fn($v) => (float)$v['score_pct'], $evs);
        $this->view('qa/employee', ['title' => 'Historique qualité', 'e' => $e, 'evs' => $evs, 'months' => $months, 'crit' => $crit, 'from' => $f, 'to' => $t,
            'kpi' => ['n' => count($sc), 'avg' => $sc ? round(array_sum($sc) / count($sc), 1) : null, 'min' => $sc ? min($sc) : null, 'max' => $sc ? max($sc) : null, 'crit' => count(array_filter($evs, fn($v) => $v['critical_fail']))],
            'actions' => DB::all('SELECT a.* FROM qa_actions a JOIN qa_evaluations v ON v.id=a.evaluation_id WHERE v.employee_id=? AND v.eval_date BETWEEN ? AND ? ORDER BY a.id DESC', [(int)$id, $f, $t])]);
    }
    function scoreboard(): void {
        [$f, $t] = $this->dates(date('Y-m-01'));
        [$sc, $sp] = Scope::sql('e.id'); $w = [$sc, "e.status<>'left'"]; $p = $sp;
        if ($this->in('team_id')) { $w[] = 'e.team_id=?'; $p[] = (int)$this->in('team_id'); }
        $vw = ['v.eval_date BETWEEN ? AND ?']; $vp = [$f, $t];
        if ($this->in('grid_id')) { $vw[] = 'v.grid_id=?'; $vp[] = (int)$this->in('grid_id'); }
        if ($this->in('channel')) { $vw[] = 'v.channel=?'; $vp[] = $this->in('channel'); }
        $join = 'LEFT JOIN qa_evaluations v ON v.employee_id=e.id AND ' . implode(' AND ', $vw);
        $rows = DB::all("SELECT e.id, e.matricule, e.first_name, e.last_name, e.qa_ref, t.name team_name, COUNT(v.id) n, AVG(v.score_pct) avg, MAX(v.eval_date) last_date, SUM(v.critical_fail) crit FROM employees e LEFT JOIN teams t ON t.id=e.team_id $join WHERE " . implode(' AND ', $w) . ' GROUP BY e.id, e.matricule, e.first_name, e.last_name, e.qa_ref, t.name ORDER BY (COUNT(v.id)=0), AVG(v.score_pct) DESC, e.last_name', array_merge($vp, $p));
        $scored = array_filter($rows, fn($r) => $r['n'] > 0); $all = DB::one("SELECT COUNT(*) n, AVG(v.score_pct) avg FROM qa_evaluations v JOIN employees e ON e.id=v.employee_id WHERE " . implode(' AND ', $w) . ' AND ' . implode(' AND ', $vw), array_merge($p, $vp));
        $stat = ['n_eval' => (int)$all['n'], 'activity' => $all['n'] ? round((float)$all['avg'], 1) : null, 'avg_of_avg' => $scored ? round(array_sum(array_map(fn($r) => (float)$r['avg'], $scored)) / count($scored), 1) : null, 'covered' => count($scored), 'total' => count($rows)];
        if ($this->in('export') === 'csv') {
            $out = array_map(fn($r) => [$r['matricule'], $r['last_name'] . ' ' . $r['first_name'], $r['qa_ref'], $r['team_name'], $r['n'], $r['n'] ? round((float)$r['avg'], 1) : '', $r['last_date'] ? d($r['last_date']) : '', (int)$r['crit'], $r['n'] ? 'Évalué' : 'Non évalué'], $rows);
            $out[] = ['', 'NOTE GLOBALE ACTIVITÉ', '', '', $stat['n_eval'], $stat['activity'] ?? '', '', '', ''];
            csv_download('etat-notation-qualite.csv', ['Matricule', 'Conseiller', 'Réf. qualité', 'Équipe', 'Évaluations', 'Note moyenne %', 'Dernière éval.', 'Éliminatoires', 'Statut'], $out);
        }
        $this->view('qa/scoreboard', ['title' => 'État de notation qualité', 'rows' => $rows, 'stat' => $stat, 'from' => $f, 'to' => $t, 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'), 'grids' => DB::all('SELECT id, name FROM qa_grids ORDER BY name'), 'channels' => DB::all('SELECT name FROM channels WHERE active=1 ORDER BY name')]);
    }
}
