<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth};
class ContractsController extends Controller {
    private function filter(): array {
        $w = ['1=1']; $p = [];
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(e.first_name LIKE ? OR e.last_name LIKE ? OR e.matricule LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $st = (string)$this->in('status', 'active');
        if ($st === 'expiring') { $w[] = "c.status='active' AND c.end_date IS NOT NULL AND c.end_date>=? AND c.end_date<=?"; array_push($p, date('Y-m-d'), date('Y-m-d', strtotime('+30 days'))); }
        elseif ($st === 'overdue') { $w[] = "c.status='active' AND c.end_date IS NOT NULL AND c.end_date<?"; $p[] = date('Y-m-d'); }
        elseif ($st !== 'all') { $w[] = 'c.status=?'; $p[] = $st; }
        if ($this->in('type')) { $w[] = 'c.type=?'; $p[] = $this->in('type'); }
        return [implode(' AND ', $w), $p];
    }
    private function types(): array { return DB::all("SELECT v.code, v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='contract_types' AND v.active=1 ORDER BY v.sort_order, v.label"); }
    function index(): void {
        [$w, $p] = $this->filter();
        $pg = paginate("contracts c JOIN employees e ON e.id=c.employee_id WHERE $w", $p, $this->page(), 25, 'c.*, e.first_name, e.last_name, e.matricule', 'c.end_date IS NULL, c.end_date, c.id DESC');
        $this->view('contracts/index', ['title' => 'Contrats', 'p' => $pg, 'types' => $this->types(),
            'employees' => can('contracts.manage') ? DB::all("SELECT id, first_name, last_name, matricule FROM employees WHERE status<>'left' ORDER BY last_name, first_name") : [],
            'expiring' => (int)DB::val("SELECT COUNT(*) FROM contracts WHERE status='active' AND end_date IS NOT NULL AND end_date>=? AND end_date<=?", [date('Y-m-d'), date('Y-m-d', strtotime('+30 days'))]),
            'overdue' => (int)DB::val("SELECT COUNT(*) FROM contracts WHERE status='active' AND end_date IS NOT NULL AND end_date<?", [date('Y-m-d')])]);
    }
    function store(): void {
        [$d, $err] = $this->validate(['type' => ['label' => 'Le type', 'req' => true, 'max' => 60], 'start_date' => ['label' => 'La date de début', 'req' => true, 'date' => true], 'end_date' => ['label' => 'La date de fin', 'date' => true], 'notes' => ['label' => 'La note', 'max' => 500]], $_POST);
        $emp = (int)$this->in('employee_id');
        if (!DB::val('SELECT 1 FROM employees WHERE id=?', [$emp])) $err['emp'] = 'Choisissez un collaborateur.';
        if ($d['type'] && !DB::val("SELECT 1 FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='contract_types' AND v.code=?", [$d['type']])) $err['type'] = 'Type de contrat inconnu.';
        if ($d['start_date'] && $d['end_date'] && $d['end_date'] < $d['start_date']) $err['end'] = 'La fin est antérieure au début.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('contracts'); }
        // Le contrat en cours est clos la veille du nouveau.
        $prev = DB::all("SELECT * FROM contracts WHERE employee_id=? AND status='active'", [$emp]);
        foreach ($prev as $c) DB::update('contracts', ['status' => 'ended', 'end_date' => $c['end_date'] && $c['end_date'] < $d['start_date'] ? $c['end_date'] : date('Y-m-d', strtotime($d['start_date'] . ' -1 day'))], 'id=?', [$c['id']]);
        $d += ['employee_id' => $emp, 'status' => 'active', 'created_by' => Auth::id(), 'created_at' => now()];
        $id = DB::insert('contracts', $d); DB::update('employees', ['contract_type' => $d['type'], 'updated_at' => now()], 'id=?', [$emp]);
        Audit::log('create', 'contract', $id, ['previous' => array_column($prev, 'id')], $d);
        flash('Contrat enregistré.' . ($prev ? ' Le contrat précédent est clos.' : '')); redirect('contracts');
    }
    /** Clôture un contrat et, au besoin, ouvre le parcours de départ « Fin de contrat ». */
    private function close(array $c, string $date, bool $launch, array &$roles): bool {
        $upd = ['status' => 'ended', 'end_date' => $date]; DB::update('contracts', $upd, 'id=?', [(int)$c['id']]); Audit::log('end', 'contract', $c['id'], $c, $upd);
        return $launch && OffboardingController::open((int)$c['employee_id'], 'end_contract', $date, 'Fin de contrat', $roles) !== null;
    }
    function end(string $id): void {
        $c = DB::one('SELECT * FROM contracts WHERE id=?', [(int)$id]); if (!$c) { $this->notFound(); return; }
        $roles = []; $started = $this->close($c, $c['end_date'] ?: date('Y-m-d'), $this->in('launch') === '1', $roles);
        if ($started) OffboardingController::tell($roles, 'Fin de contrat à traiter.', '/offboarding');
        flash('Contrat clos.' . ($started ? ' Parcours de départ lancé.' : '')); redirect('contracts');
    }
    function endBulk(): void {
        $date = (string)$this->in('end_date', date('Y-m-d')); if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) { flash('Date de fin invalide.', 'danger'); redirect('contracts'); }
        $ids = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['ids'] ?? [])))));
        if (!$ids) { flash('Cochez au moins un contrat.', 'warning'); redirect('contracts'); }
        $launch = $this->in('launch') === '1'; $roles = []; $n = 0; $dep = 0;
        foreach ($ids as $id) { $c = DB::one("SELECT * FROM contracts WHERE id=? AND status='active'", [$id]); if (!$c) continue; $n++; if ($this->close($c, $date, $launch, $roles)) $dep++; }
        if ($dep) OffboardingController::tell($roles, $dep . ' fin(s) de contrat à traiter.', '/offboarding');
        Audit::log('end_bulk', 'contract', null, null, ['closed' => $n, 'departures' => $dep]);
        flash("$n contrat(s) clos." . ($launch ? " $dep parcours de départ lancé(s)." : ''), $n ? 'success' : 'warning'); redirect('contracts');
    }
    function export(): void {
        [$w, $p] = $this->filter();
        $rows = DB::all("SELECT e.matricule, e.last_name, e.first_name, c.type, c.start_date, c.end_date, c.status FROM contracts c JOIN employees e ON e.id=c.employee_id WHERE $w ORDER BY e.last_name", $p);
        Audit::log('export', 'contracts', null, null, ['rows' => count($rows)]);
        csv_download('contrats_' . date('Ymd_His') . '.csv', ['Matricule', 'Nom', 'Prénom', 'Type', 'Début', 'Fin', 'Statut'], $rows);
    }
}
