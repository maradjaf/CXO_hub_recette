<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Ag, Html};

/** Messagerie interne : boîte de réception, envoi (personnes, rôles, équipes, tout le personnel), réponses, favoris, pièces jointes. */
class MsgController extends Controller {
    private static function dir(): string { $d = ROOT . '/storage/uploads/msg'; if (!is_dir($d)) @mkdir($d, 0775, true); return $d; }
    private function msg(string $id): ?array { return DB::one('SELECT * FROM msg_messages WHERE id=?', [(int)$id]); }
    private function mine(array $m): ?array { return DB::one('SELECT * FROM msg_recipients WHERE message_id=? AND user_id=? AND deleted=0', [(int)$m['id'], Auth::id()]); }
    private function visible(array $m): bool { return ((int)$m['sender_id'] === Auth::id() && !$m['sender_deleted']) || (bool)$this->mine($m); }
    static function unread(): int { return Auth::id() ? (int)DB::val('SELECT COUNT(*) FROM msg_recipients WHERE user_id=? AND deleted=0 AND read_at IS NULL', [Auth::id()]) : 0; }

    function index(): void {
        $box = (string)$this->in('box', 'inbox'); if (!in_array($box, ['inbox', 'sent', 'starred'], true)) $box = 'inbox'; $me = (int)Auth::id(); $q = trim((string)$this->in('q', '')); $p = [$me];
        if ($box === 'sent') { $from = 'msg_messages m JOIN users u ON u.id=m.sender_id WHERE m.sender_id=? AND m.sender_deleted=0'; $sel = 'm.*, u.name sender, NULL read_at, 0 starred, (SELECT COUNT(*) FROM msg_recipients WHERE message_id=m.id) nrec, (SELECT COUNT(*) FROM msg_files WHERE message_id=m.id) nfiles'; }
        else { $from = 'msg_recipients r JOIN msg_messages m ON m.id=r.message_id JOIN users u ON u.id=m.sender_id WHERE r.user_id=? AND r.deleted=0'; $sel = 'm.*, u.name sender, r.read_at, r.starred, 0 nrec, (SELECT COUNT(*) FROM msg_files WHERE message_id=m.id) nfiles';
            if ($box === 'starred') $from .= ' AND r.starred=1'; if ($this->in('unread', '') === '1') $from .= ' AND r.read_at IS NULL'; }
        if ($q !== '') { $from .= ' AND (m.subject LIKE ? OR m.body LIKE ? OR u.name LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $pg = paginate($from, $p, $this->page(), 25, $sel, 'm.created_at DESC, m.id DESC');
        $this->view('msg/index', ['title' => 'Messagerie', 'p' => $pg, 'box' => $box, 'unread' => self::unread()]);
    }
    function compose(): void {
        $to = []; if ((int)$this->in('to', 0)) $to[] = (int)$this->in('to');
        $this->view('msg/compose', ['title' => 'Nouveau message', 'users' => $this->users(), 'roles' => DB::all('SELECT id, name FROM roles ORDER BY name'), 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'), 'to' => $to, 'bc' => can('msg.broadcast')]);
    }
    private function users(): array { return DB::all("SELECT id, name, email FROM users WHERE status='active' AND id<>? ORDER BY name", [Auth::id()]); }
    /** @return int[] destinataires distincts (actifs, hors expéditeur) */
    private function resolve(): array {
        $ids = array_map('intval', (array)($_POST['to'] ?? [])); 
        foreach (array_map('intval', (array)($_POST['g_role'] ?? [])) as $r) foreach (DB::all('SELECT user_id FROM user_roles WHERE role_id=?', [$r]) as $x) $ids[] = (int)$x['user_id'];
        foreach (array_map('intval', (array)($_POST['g_team'] ?? [])) as $t) foreach (DB::all('SELECT u.id FROM users u JOIN employees e ON e.id=u.employee_id WHERE e.team_id=?', [$t]) as $x) $ids[] = (int)$x['id'];
        if (isset($_POST['g_all']) && can('msg.broadcast')) foreach (DB::all("SELECT id FROM users WHERE status='active'") as $x) $ids[] = (int)$x['id'];
        $ids = array_values(array_unique(array_diff($ids, [(int)Auth::id()]))); if (!$ids) return [];
        return array_map(fn($r) => (int)$r['id'], DB::all("SELECT id FROM users WHERE status='active' AND id IN (" . implode(',', $ids) . ')'));
    }
    private function files(int $mid): array {
        $f = $_FILES['files'] ?? null; $err = []; $n = 0; if (!$f || !is_array($f['name'])) return [];
        foreach ($f['name'] as $k => $name) {
            if (($f['error'][$k] ?? 4) === UPLOAD_ERR_NO_FILE) continue; if ($f['error'][$k] !== UPLOAD_ERR_OK) { $err[] = "« $name » non reçu."; continue; } if ($n >= 3) { $err[] = '3 pièces jointes maximum.'; break; }
            $nm = trim(preg_replace('#[\x00-\x1f\\\\/]+#', '_', (string)$name)); $ext = strtolower(pathinfo($nm, PATHINFO_EXTENSION));
            if (!isset(Ag::EV_TYPES[$ext]) || $f['size'][$k] > 5 * 1024 * 1024) { $err[] = "« $nm » refusé (png, jpg, pdf, docx ou xlsx ; 5 Mo maximum)."; continue; }
            $st = bin2hex(random_bytes(16)) . '.' . $ext; if (!@move_uploaded_file($f['tmp_name'][$k], self::dir() . '/' . $st)) { $err[] = "« $nm » non enregistré."; continue; }
            DB::insert('msg_files', ['message_id' => $mid, 'original_name' => mb_substr($nm, 0, 190), 'stored_name' => $st, 'mime' => Ag::EV_TYPES[$ext], 'size' => (int)$f['size'][$k], 'created_at' => now()]); $n++;
        }
        return $err;
    }
    private function deliver(string $subject, string $body, array $rcpt, string $scope, ?array $parent): int {
        $id = DB::insert('msg_messages', ['thread_id' => null, 'parent_id' => $parent['id'] ?? null, 'sender_id' => Auth::id(), 'subject' => mb_substr($subject, 0, 190), 'body' => $body, 'scope' => $scope, 'created_at' => now()]);
        DB::update('msg_messages', ['thread_id' => $parent ? (int)($parent['thread_id'] ?: $parent['id']) : $id], 'id=?', [$id]);
        foreach ($rcpt as $u) { DB::insert('msg_recipients', ['message_id' => $id, 'user_id' => $u]); Notifier::send($u, 'Nouveau message', Auth::user()['name'] . ' : ' . mb_substr($subject, 0, 120), '/msg/' . $id); }
        return $id;
    }
    function send(): void {
        [$d, $err] = $this->validate(['subject' => ['label' => 'L\'objet', 'req' => true, 'max' => 190], 'body' => ['label' => 'Le message', 'req' => true]], $_POST);
        if (!empty($d['body'])) { $d['body'] = Html::clean($d['body']); if (Html::text($d['body']) === '') $err['body'] = 'Le message est vide.'; elseif (mb_strlen($d['body']) > 60000) $err['body'] = 'Le message est trop long.'; }
        $rcpt = $this->resolve(); if (!$rcpt) $err['to'] = 'Choisissez au moins un destinataire (personne, rôle, équipe).';
        if ($err) $this->back($err, $_POST, 'msg/new');
        $scope = isset($_POST['g_all']) && can('msg.broadcast') ? 'all' : (!empty($_POST['g_role']) || !empty($_POST['g_team']) ? 'group' : 'direct');
        $id = $this->deliver($d['subject'], $d['body'], $rcpt, $scope, null); $fe = $this->files($id); Audit::log('send', 'msg_messages', $id, null, ['n' => count($rcpt), 'scope' => $scope]);
        foreach ($fe as $m) flash($m, 'warning'); flash('Message envoyé à ' . count($rcpt) . ' destinataire(s).'); redirect('msg?box=sent');
    }
    function show(string $id): void {
        $m = $this->msg($id); if (!$m || !$this->visible($m)) { $this->notFound(); return; } $me = (int)Auth::id();
        $thread = DB::all('SELECT m.*, u.name sender FROM msg_messages m JOIN users u ON u.id=m.sender_id WHERE m.thread_id=? ORDER BY m.created_at, m.id', [(int)$m['thread_id']]);
        $thread = array_values(array_filter($thread, fn($x) => $this->visible($x)));
        foreach ($thread as &$x) { $x['rcpt'] = DB::all('SELECT u.id, u.name, r.read_at FROM msg_recipients r JOIN users u ON u.id=r.user_id WHERE r.message_id=? ORDER BY u.name', [(int)$x['id']]); $x['files'] = DB::all('SELECT * FROM msg_files WHERE message_id=?', [(int)$x['id']]);
            DB::exec('UPDATE msg_recipients SET read_at=? WHERE message_id=? AND user_id=? AND read_at IS NULL', [now(), (int)$x['id'], $me]); $sr = DB::one('SELECT starred FROM msg_recipients WHERE message_id=? AND user_id=? AND deleted=0', [(int)$x['id'], $me]); $x['star'] = $sr ? (int)$sr['starred'] : null; } unset($x);
        $this->view('msg/show', ['title' => $m['subject'], 'm' => $m, 'thread' => $thread]);
    }
    function reply(string $id): void {
        $m = $this->msg($id); if (!$m || !$this->visible($m)) { $this->notFound(); return; } $body = Html::clean((string)$this->in('body', ''));
        if (Html::text($body) === '' || mb_strlen($body) > 60000) { flash('Écrivez votre réponse.', 'danger'); redirect("msg/$id"); }
        $me = (int)Auth::id(); $all = $this->in('all', '') === '1'; $rec = array_map(fn($r) => (int)$r['user_id'], DB::all('SELECT user_id FROM msg_recipients WHERE message_id=?', [(int)$m['id']]));
        $set = $all ? array_merge([(int)$m['sender_id']], $rec) : ((int)$m['sender_id'] === $me ? $rec : [(int)$m['sender_id']]); $set = array_values(array_diff(array_unique($set), [$me]));
        if ($set) $set = array_map(fn($r) => (int)$r['id'], DB::all("SELECT id FROM users WHERE status='active' AND id IN (" . implode(',', $set) . ')'));
        if (!$set) { flash('Aucun destinataire actif pour cette réponse.', 'danger'); redirect("msg/$id"); }
        $subj = preg_match('/^Re\s*:/i', $m['subject']) ? $m['subject'] : 'Re : ' . $m['subject']; $nid = $this->deliver($subj, $body, $set, 'direct', $m); foreach ($this->files($nid) as $e) flash($e, 'warning');
        Audit::log('reply', 'msg_messages', $nid); flash('Réponse envoyée.'); redirect("msg/$nid");
    }
    function star(string $id): void {
        $m = $this->msg($id); if (!$m || !($r = $this->mine($m))) { $this->notFound(); return; } DB::update('msg_recipients', ['starred' => $r['starred'] ? 0 : 1], 'id=?', [(int)$r['id']]); redirect('msg/' . (int)$id);
    }
    function delete(string $id): void { $this->hide([(int)$id]); flash('Message supprimé de votre boîte.'); redirect('msg'); }
    private function hide(array $ids): int {
        $n = 0; foreach ($ids as $id) { $m = $this->msg((string)$id); if (!$m) continue; if ((int)$m['sender_id'] === Auth::id()) { DB::update('msg_messages', ['sender_deleted' => 1], 'id=?', [(int)$id]); $n++; }
            $n += DB::exec('UPDATE msg_recipients SET deleted=1 WHERE message_id=? AND user_id=?', [(int)$id, Auth::id()]); } return $n;
    }
    function bulk(): void {
        $ids = array_map('intval', (array)($_POST['ids'] ?? [])); $act = (string)$this->in('act', ''); $box = (string)$this->in('box', 'inbox');
        if (!$ids) { flash('Aucun message sélectionné.', 'warning'); redirect('msg?box=' . $box); }
        if ($act === 'read' || $act === 'unread') DB::exec('UPDATE msg_recipients SET read_at=' . ($act === 'read' ? '?' : 'NULL') . ' WHERE user_id=? AND message_id IN (' . implode(',', $ids) . ')' , $act === 'read' ? [now(), Auth::id()] : [Auth::id()]);
        elseif ($act === 'delete') $this->hide($ids); flash('Fait.'); redirect('msg?box=' . $box);
    }
    function file(string $fid): void {
        $f = DB::one('SELECT * FROM msg_files WHERE id=?', [(int)$fid]); $m = $f ? $this->msg((string)$f['message_id']) : null; if (!$m || !$this->visible($m)) { $this->notFound(); return; }
        $path = self::dir() . '/' . $f['stored_name']; if (!is_file($path)) { $this->notFound(); return; }
        header('Content-Type: ' . $f['mime']); header('X-Content-Type-Options: nosniff'); header("Content-Security-Policy: sandbox; default-src 'none'; img-src 'self'; style-src 'unsafe-inline'"); header('Content-Length: ' . filesize($path));
        header('Content-Disposition: ' . (str_starts_with($f['mime'], 'image/') || $f['mime'] === 'application/pdf' ? 'inline' : 'attachment') . '; filename="' . rawurlencode($f['original_name']) . '"; filename*=UTF-8\'\'' . rawurlencode($f['original_name'])); readfile($path); exit;
    }
}
