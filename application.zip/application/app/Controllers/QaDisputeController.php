<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Scope, Notifier};
/** Contestation d'une note qualité par le collaborateur et retour de l'équipe qualité (historisés). */
class QaDisputeController extends Controller {
    const ST = ['open' => ['En attente', 'warning'], 'accepted' => ['Acceptée', 'success'], 'rejected' => ['Rejetée', 'secondary']];
    private function myEmp(): int { return (int)(Auth::user()['employee_id'] ?? 0); }
    function raise(string $id): void {
        $ev = DB::one('SELECT * FROM qa_evaluations WHERE id=?', [(int)$id]);
        if (!$ev || !$this->myEmp() || (int)$ev['employee_id'] !== $this->myEmp()) { $this->notFound(); return; }
        $reason = trim((string)$this->in('reason', ''));
        if (QaController::secondsLeft($ev, QaController::disputeHours()) <= 0) { flash('Le délai de contestation de ' . QaController::disputeHours() . ' h est écoulé.', 'danger'); redirect("qa/$id"); }
        if (DB::val("SELECT 1 FROM qa_disputes WHERE evaluation_id=? AND status='open'", [(int)$id])) { flash('Une contestation est déjà en cours sur cette note.', 'warning'); redirect("qa/$id"); }
        if (mb_strlen($reason) < 10 || mb_strlen($reason) > 1500) { flash('Expliquez votre contestation (10 à 1 500 caractères).', 'danger'); redirect("qa/$id"); }
        $did = DB::insert('qa_disputes', ['evaluation_id' => (int)$id, 'raised_by' => Auth::id(), 'reason' => $reason, 'status' => 'open', 'created_at' => now()]);
        $to = array_column(\App\Core\Ca::usersWith('qa.manage'), 'id'); if ($n1 = QaController::n1User($this->myEmp())) $to[] = $n1; if ($ev['evaluator_id']) $to[] = (int)$ev['evaluator_id'];
        foreach (array_unique(array_map('intval', $to)) as $u) if ($u !== (int)Auth::id()) Notifier::send($u, 'Contestation d\'une note qualité', 'Note du ' . d($ev['eval_date']) . ' : ' . mb_substr($reason, 0, 120), '/qa/' . $id);
        Audit::log('create', 'qa_dispute', $did, null, ['evaluation' => (int)$id]); flash('Votre contestation est transmise à l\'équipe qualité.'); redirect("qa/$id");
    }
    function answer(string $did): void {
        $d = DB::one('SELECT * FROM qa_disputes WHERE id=?', [(int)$did]); if (!$d) { $this->notFound(); return; }
        $ev = DB::one('SELECT * FROM qa_evaluations WHERE id=?', [(int)$d['evaluation_id']]);
        $dec = $this->in('decision'); $ans = trim((string)$this->in('answer', ''));
        if ($d['status'] !== 'open' || !in_array($dec, ['accepted', 'rejected'], true) || mb_strlen($ans) < 5 || mb_strlen($ans) > 1500) { flash('Renseignez le retour de l\'équipe qualité (5 caractères minimum).', 'danger'); redirect('qa/' . $d['evaluation_id']); }
        DB::update('qa_disputes', ['status' => $dec, 'answer' => $ans, 'answered_by' => Auth::id(), 'answered_at' => now()], 'id=?', [(int)$did]);
        $recip = array_filter([DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [(int)$ev['employee_id']]), QaController::n1User((int)$ev['employee_id'])]);
        foreach ($recip as $u) Notifier::send((int)$u, 'Contestation ' . strtolower(self::ST[$dec][0]), mb_substr($ans, 0, 160), '/qa/' . $ev['id']);
        Audit::log('answer', 'qa_dispute', $did, $d, ['status' => $dec]); flash('Retour enregistré.'); redirect('qa/' . $ev['id']);
    }
    function index(): void {
        [$w, $p] = Scope::sql('v.employee_id'); $w = [$w];
        if (in_array($this->in('status'), ['open', 'accepted', 'rejected'], true)) { $w[] = 'd.status=?'; $p[] = $this->in('status'); }
        if ($this->in('from')) { $w[] = 'd.created_at>=?'; $p[] = $this->in('from'); } if ($this->in('to')) { $w[] = 'd.created_at<=?'; $p[] = $this->in('to') . ' 23:59:59'; }
        $from = 'qa_disputes d JOIN qa_evaluations v ON v.id=d.evaluation_id JOIN employees e ON e.id=v.employee_id LEFT JOIN users a ON a.id=d.answered_by WHERE ' . implode(' AND ', $w);
        $cols = 'd.*, v.eval_date, v.score_pct, e.first_name, e.last_name, e.matricule, a.name answered_name';
        if ($this->in('export') === 'csv') {
            $rows = array_map(fn($r) => [$r['id'], d($r['created_at']), $r['matricule'], $r['last_name'] . ' ' . $r['first_name'], d($r['eval_date']), $r['score_pct'], self::ST[$r['status']][0] ?? $r['status'], $r['reason'], $r['answer'], $r['answered_name']], DB::all("SELECT $cols FROM $from ORDER BY d.id DESC", $p));
            csv_download('contestations-qualite.csv', ['N°', 'Date', 'Matricule', 'Collaborateur', 'Date éval.', 'Note %', 'Statut', 'Motif', 'Retour qualité', 'Traité par'], $rows);
        }
        $this->view('qa/disputes', ['title' => 'Contestations qualité', 'p' => paginate($from, $p, $this->page(), 25, $cols, 'd.id DESC')]);
    }
}
