<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Bot, BotWeb, Settings};
/** Administration de l'assistant : choix des sources consultées et contenu du site web. */
class BotSourcesController extends Controller {
    function index(): void {
        $counts = []; foreach (['kb' => "SELECT COUNT(*) FROM kb_articles WHERE status='published' AND kind='article'", 'faq' => "SELECT COUNT(*) FROM kb_articles WHERE status='published' AND kind='faq'", 'cs' => "SELECT COUNT(*) FROM cs_scripts WHERE status='published'", 'sop' => "SELECT COUNT(*) FROM kb_sops WHERE status='published'",
            'pr' => "SELECT COUNT(*) FROM pr_processes WHERE status='published'", 'el' => "SELECT COUNT(*) FROM el_courses WHERE status='published'", 'web' => 'SELECT COUNT(*) FROM bot_web_pages WHERE active=1'] as $k => $q) $counts[$k] = (int)DB::val($q);
        $this->view('bot/sources', ['title' => 'Sources de l\'assistant', 'tab' => 'sources', 'on' => Bot::enabledSources(), 'counts' => $counts, 'site' => (string)setting('bot.site_url', 'https://yas.tg'), 'max' => (int)setting('bot.site_max', 40),
            'pages' => DB::all('SELECT id, url, title, active, is_manual, fetched_at, LENGTH(body) len FROM bot_web_pages ORDER BY url')]);
    }
    function save(): void {
        $sel = array_values(array_intersect(array_keys(Bot::SRC), (array)($_POST['src'] ?? []))); $site = trim((string)$this->in('site', 'https://yas.tg')); $max = max(1, min(200, (int)$this->in('max', 40)));
        if (!preg_match('#^https?://[^\s/]+(/\S*)?$#i', $site)) { flash('Adresse du site invalide (https://…).', 'danger'); redirect('bot/sources'); }
        Settings::set('bot.sources', $sel ? implode(',', $sel) : '-'); Settings::set('bot.site_url', $site); Settings::set('bot.site_max', (string)$max);
        Audit::log('update', 'bot_sources', null, null, ['sources' => $sel]); flash($sel ? 'Sources enregistrées : ' . count($sel) . ' active(s).' : 'Aucune source active : l\'assistant ne trouvera plus de réponse.', $sel ? 'success' : 'warning'); redirect('bot/sources');
    }
    function sync(): void {
        $site = (string)setting('bot.site_url', 'https://yas.tg'); $max = (int)setting('bot.site_max', 40); @set_time_limit(120); $r = BotWeb::sync($site, $max);
        Audit::log('sync', 'bot_web', null, null, $r);
        if ($r['pages']) flash($r['pages'] . ' page(s) du site importée(s)' . ($r['errors'] ? ', ' . $r['errors'] . ' inaccessible(s)' : '') . '.', 'success');
        else flash('Aucune page importée. ' . ($r['first_error'] ?: '') . ' Le serveur n\'a peut-être pas accès à Internet : ajoutez le contenu des pages à la main ci-dessous.', 'danger');
        redirect('bot/sources');
    }
    function addPage(): void {
        $url = trim((string)$this->in('url', '')); $title = trim((string)$this->in('title', '')); $text = trim((string)$this->in('body', ''));
        if (!preg_match('#^https?://\S+$#i', $url) || mb_strlen($url) > 500) { flash('Adresse de page invalide.', 'danger'); redirect('bot/sources'); }
        if ($text === '') { $html = BotWeb::fetch($url); if ($html === null) { flash('Page inaccessible depuis le serveur : collez son texte dans le champ prévu.', 'danger'); redirect('bot/sources'); } $pg = BotWeb::parse($html, $url); $title = $title ?: $pg['title']; $text = $pg['text']; }
        if (mb_strlen($text) < 20) { flash('Contenu trop court.', 'danger'); redirect('bot/sources'); }
        BotWeb::save($url, $title, $text, true); Audit::log('add', 'bot_web', null, null, ['url' => $url]); flash('Page ajoutée.'); redirect('bot/sources');
    }
    function togglePage(string $id): void { $p = DB::one('SELECT * FROM bot_web_pages WHERE id=?', [(int)$id]); if (!$p) { $this->notFound(); return; } DB::update('bot_web_pages', ['active' => $p['active'] ? 0 : 1], 'id=?', [(int)$id]); redirect('bot/sources'); }
    function deletePage(string $id): void { DB::exec('DELETE FROM bot_web_pages WHERE id=?', [(int)$id]); Audit::log('delete', 'bot_web', $id); flash('Page retirée.'); redirect('bot/sources'); }
}
