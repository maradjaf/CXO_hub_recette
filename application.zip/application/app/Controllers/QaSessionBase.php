<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Scope, Notifier, QaSessions as S, Html};
/** Cycle de vie commun aux coachings et aux débriefings : clôture avec compte rendu partagé, report/reprogrammation, annulation, commentaires et alertes. */
abstract class QaSessionBase extends Controller {
    protected string $kind; protected string $path;
    abstract protected function canSee(array $row): bool;
    protected function row(string $id): ?array { return DB::one('SELECT * FROM ' . S::t($this->kind) . ' WHERE id=?', [(int)$id]); }
    protected function canManage(array $row): bool { return can('qa.manage') || (can('qa.evaluate') && (int)$row['coach_user_id'] === (int)Auth::id()); }
    protected function open(string $id): ?array {
        $r = $this->row($id); if (!$r) { $this->notFound(); return null; }
        if (!$this->canSee($r)) { $this->forbidden(); return null; } return $r;
    }
    /** Notification dans l'application + e-mail ; avec $invite, l'e-mail est une invitation calendrier (.ics : invitation, mise à jour ou annulation). */
    protected function notify(array $row, string $title, string $body, bool $skipMe = true, bool $invite = false): void {
        $rec = S::recipients($this->kind, $row);
        foreach ($rec as $u) if (!$skipMe || $u !== (int)Auth::id()) S::tell($u, $title, $body, '/qa/' . $this->path . '/' . $row['id'], !$invite);
        if ($invite) \App\Core\Ics::send($this->kind, $row, $rec, $title, $body . "\nLe fichier joint (.ics) ajoute ou met à jour la séance dans votre agenda.");
    }
    /** Fichier .ics d'une séance (téléchargement). */
    function ics(string $id): void {
        $r = $this->open($id); if (!$r) return;
        $emails = array_values(array_filter(array_map(fn($u) => DB::val('SELECT email FROM users WHERE id=?', [$u]), S::recipients($this->kind, $r))));
        header('Content-Type: text/calendar; charset=utf-8'); header('Content-Disposition: attachment; filename="' . $this->kind . '-' . (int)$id . '.ics"');
        echo \App\Core\Ics::calendar([\App\Core\Ics::vevent($this->kind, $r, $emails)], $r['status'] === 'cancelled' ? 'CANCEL' : 'REQUEST'); exit;
    }
    /** Données communes de la fiche : journal, commentaires, droits d'action. */
    protected function detail(array $row): array {
        return ['row' => $row, 'kind' => $this->kind, 'path' => $this->path, 'manage' => $this->canManage($row) && in_array($row['status'], ['planned', 'postponed'], true), 'editReport' => $this->canManage($row) && $row['status'] === 'done',
            'log' => DB::all('SELECT l.*, u.name by_name FROM qa_session_log l LEFT JOIN users u ON u.id=l.user_id WHERE l.kind=? AND l.ref_id=? ORDER BY l.id', [$this->kind, (int)$row['id']]),
            'comments' => DB::all('SELECT c.*, u.name by_name FROM qa_session_comments c LEFT JOIN users u ON u.id=c.user_id WHERE c.kind=? AND c.ref_id=? ORDER BY c.id', [$this->kind, (int)$row['id']]),
            'coach' => DB::val('SELECT name FROM users WHERE id=?', [(int)$row['coach_user_id']])];
    }
    function complete(string $id): void {
        $r = $this->open($id); if (!$r) return;
        if (!$this->canManage($r) || $r['status'] === 'cancelled') { $this->forbidden(); return; }
        $rep = Html::clean((string)$this->in('report', '')); $plain = trim(strip_tags($rep));
        if (mb_strlen($plain) < 10) { flash('Le compte rendu est obligatoire (10 caractères minimum).', 'danger'); redirect("qa/{$this->path}/$id"); }
        $first = $r['status'] !== 'done';
        DB::update(S::t($this->kind), ['report' => $rep, 'status' => 'done', 'done_at' => $r['done_at'] ?: now(), 'shared_at' => $r['shared_at'] ?: now()], 'id=?', [(int)$id]);
        S::log($this->kind, (int)$id, $first ? 'done' : 'report_edit', null, null, null);
        if ($first) $this->notify($r, 'Compte rendu disponible · ' . S::label($this->kind, $r), 'Le compte rendu a été partagé.');
        Audit::log($first ? 'complete' : 'report_edit', 'qa_' . $this->kind, $id); flash($first ? 'Séance clôturée : le compte rendu est partagé automatiquement.' : 'Compte rendu mis à jour (modification journalisée).'); redirect("qa/{$this->path}/$id");
    }
    function postpone(string $id): void {
        $r = $this->open($id); if (!$r) return; if (!$this->canManage($r) || !in_array($r['status'], ['planned', 'postponed'], true)) { $this->forbidden(); return; }
        $at = S::when($this->in('new_date'), $this->in('new_time')); $reason = trim((string)$this->in('reason', ''));
        if (!$at || strtotime($at) < strtotime(date('Y-m-d'))) { flash('Indiquez une nouvelle date valide (aujourd\'hui ou plus tard).', 'danger'); redirect("qa/{$this->path}/$id"); }
        if (mb_strlen($reason) < 5 || mb_strlen($reason) > 500) { flash('Indiquez le motif du report (5 à 500 caractères).', 'danger'); redirect("qa/{$this->path}/$id"); }
        S::postpone($this->kind, $r, $at, $reason); $r['planned_at'] = $at;
        $this->notify($r, 'Séance reportée · ' . S::label($this->kind, $r), 'Nouvelle date : ' . dt($at) . ' — ' . $reason, true, true);
        Audit::log('postpone', 'qa_' . $this->kind, $id, ['planned_at' => $r['planned_at']], ['planned_at' => $at]); flash('Séance reportée au ' . dt($at) . '.'); redirect("qa/{$this->path}/$id");
    }
    function cancel(string $id): void {
        $r = $this->open($id); if (!$r) return; if (!$this->canManage($r) || !in_array($r['status'], ['planned', 'postponed'], true)) { $this->forbidden(); return; }
        $reason = trim((string)$this->in('reason', '')); if (mb_strlen($reason) < 5 || mb_strlen($reason) > 300) { flash('Indiquez le motif de l\'annulation (5 à 300 caractères).', 'danger'); redirect("qa/{$this->path}/$id"); }
        DB::update(S::t($this->kind), ['status' => 'cancelled', 'cancel_reason' => $reason], 'id=?', [(int)$id]); S::log($this->kind, (int)$id, 'cancel', $r['planned_at'], null, $reason); $r['status'] = 'cancelled';
        $this->notify($r, 'Séance annulée · ' . S::label($this->kind, $r), $reason, true, true); Audit::log('cancel', 'qa_' . $this->kind, $id); flash('Séance annulée.'); redirect("qa/{$this->path}/$id");
    }
    function comment(string $id): void {
        $r = $this->open($id); if (!$r) return; $b = trim((string)$this->in('body', ''));
        if ($b === '' || mb_strlen($b) > 1000) { flash('Commentaire vide ou trop long (1 000 caractères maximum).', 'danger'); redirect("qa/{$this->path}/$id"); }
        $alert = isset($_POST['alert']) && $this->canManage($r) ? 1 : 0;
        DB::insert('qa_session_comments', ['kind' => $this->kind, 'ref_id' => (int)$id, 'user_id' => Auth::id(), 'body' => $b, 'alert' => $alert, 'created_at' => now()]);
        $this->notify($r, ($alert ? 'Alerte · ' : 'Commentaire · ') . S::label($this->kind, $r), mb_substr($b, 0, 160)); flash($alert ? 'Alerte envoyée aux participants.' : 'Commentaire ajouté.'); redirect("qa/{$this->path}/$id");
    }
}
