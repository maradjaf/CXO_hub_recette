<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Ev, Ref, Notifier};
class EvController extends Controller {
    private function load(string $id): ?array { $e = DB::one('SELECT * FROM ev_events WHERE id=?', [(int)$id]); return $e && Ev::visible($e, Ev::me()) ? $e : null; }
    private function emps(): array { return DB::all("SELECT id, first_name, last_name, matricule FROM employees WHERE status<>'left' ORDER BY last_name, first_name"); }
    private function visibleRows(array $rows): array { $me = Ev::me(); return array_values(array_filter($rows, fn($e) => Ev::visible($e, $me))); }
    private function dtl(?string $v): ?string { $v = trim((string)$v); return preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $v) ? str_replace('T', ' ', $v) . ':00' : null; }

    // =============== Consultation ===============
    function agenda(): void {
        $m = preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', (string)$this->in('m', '')) ? (string)$this->in('m') : date('Y-m');
        $from = "$m-01 00:00:00"; $to = date('Y-m-d 23:59:59', strtotime("$m-01 +1 month -1 day"));
        $rows = $this->visibleRows(DB::all("SELECT * FROM ev_events WHERE start_at<=? AND end_at>=? AND status<>'cancelled' ORDER BY start_at LIMIT 400", [$to, $from]));
        $by = []; foreach ($rows as $e) for ($t = strtotime(substr($e['start_at'], 0, 10)); $t <= strtotime(substr($e['end_at'], 0, 10)); $t += 86400) $by[date('Y-m-d', $t)][] = $e;
        $me = Ev::me();
        $mine = $me ? DB::all("SELECT e.*, a.status att FROM ev_events e JOIN ev_attendees a ON a.event_id=e.id WHERE a.employee_id=? AND a.status IN ('invited','registered','waitlist') AND e.status='published' AND e.end_at>=? ORDER BY e.start_at LIMIT 8", [$me, now()]) : [];
        $this->view('ev/agenda', ['title' => 'Agenda des événements', 'm' => $m, 'by' => $by, 'mine' => $mine]);
    }
    function index(): void {
        $q = trim((string)$this->in('q', '')); $type = (string)$this->in('type', ''); $st = (string)$this->in('status', ''); $per = (string)$this->in('period', 'upcoming');
        $w = ['1=1']; $p = [];
        if ($q !== '') { $w[] = '(LOWER(title) LIKE ? OR LOWER(location) LIKE ?)'; $l = '%' . mb_strtolower($q) . '%'; array_push($p, $l, $l); }
        if ($type !== '') { $w[] = 'type=?'; $p[] = $type; }
        if ($st !== '' && isset(Ev::STATUS[$st]) && can('ev.manage')) { $w[] = 'status=?'; $p[] = $st; }
        if ($per === 'upcoming') { $w[] = 'end_at>=?'; $p[] = now(); } elseif ($per === 'past') { $w[] = 'end_at<?'; $p[] = now(); }
        $pg = paginate('ev_events WHERE ' . implode(' AND ', $w), $p, $this->page(), 25, '*', 'start_at ' . ($per === 'past' ? 'DESC' : 'ASC')); $rows = $this->visibleRows($pg['rows']);
        foreach ($rows as &$r) { $r['c'] = Ev::counts((int)$r['id']); } unset($r);
        $this->view('ev/index', ['title' => 'Tous les événements', 'rows' => $rows, 'p' => $pg, 'q' => $q, 'type' => $type, 'st' => $st, 'per' => $per]);
    }
    function show(string $id): void {
        $e = $this->load($id); if (!$e) { $this->notFound(); return; }
        $me = Ev::me(); $mine = $me ? DB::one('SELECT * FROM ev_attendees WHERE event_id=? AND employee_id=?', [(int)$id, $me]) : null;
        $mg = can('ev.manage');
        $att = $mg ? DB::all('SELECT a.*, p.first_name, p.last_name, p.matricule, t.name team FROM ev_attendees a JOIN employees p ON p.id=a.employee_id LEFT JOIN teams t ON t.id=p.team_id WHERE a.event_id=? ORDER BY p.last_name, p.first_name', [(int)$id]) : [];
        $this->view('ev/show', ['title' => $e['title'], 'e' => $e, 'mine' => $mine, 'c' => Ev::counts((int)$id), 'seats' => Ev::seats($e), 'att' => $att, 'mg' => $mg, 'tg' => Ev::targets((int)$id),
            'org' => $e['organizer_id'] ? DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [(int)$e['organizer_id']]) : null,
            'tasks' => $mg ? DB::all('SELECT k.*, p.first_name, p.last_name FROM ev_tasks k LEFT JOIN employees p ON p.id=k.owner_id WHERE k.event_id=? ORDER BY k.done, k.due_date, k.id', [(int)$id]) : [],
            'fb' => DB::one('SELECT AVG(rating) a, COUNT(*) n FROM ev_feedback WHERE event_id=?', [(int)$id]), 'myfb' => $me ? DB::one('SELECT * FROM ev_feedback WHERE event_id=? AND employee_id=?', [(int)$id, $me]) : null,
            'comments' => $mg ? DB::all('SELECT rating, comment FROM ev_feedback WHERE event_id=? AND comment IS NOT NULL ORDER BY id DESC LIMIT 20', [(int)$id]) : [],
            'emps' => $mg ? $this->emps() : [], 'teams' => $mg ? DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name') : [], 'stores' => $mg ? DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name') : [],
            'checkin' => $mine && Ev::checkinOpen($e) && in_array($mine['status'], ['invited', 'registered'], true)]);
    }

    // =============== Création et modification ===============
    function create(): void { $this->form(null); }
    function edit(string $id): void { $e = DB::one('SELECT * FROM ev_events WHERE id=?', [(int)$id]); if (!$e) { $this->notFound(); return; } $this->form($e); }
    private function form(?array $e): void {
        $this->view('ev/form', ['title' => $e ? 'Modifier l\'événement' : 'Nouvel événement', 'e' => $e, 'tg' => $e ? Ev::targets((int)$e['id']) : ['team' => [], 'store' => []], 'emps' => $this->emps(), 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'), 'stores' => DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name')]);
    }
    private function data(?array $old): array {
        [$d, $err] = $this->validate(['title' => ['label' => 'Le titre', 'req' => true, 'max' => 200], 'description' => ['label' => 'La description', 'max' => 5000], 'location' => ['label' => 'Le lieu', 'max' => 200], 'online_url' => ['label' => 'Le lien de visioconférence', 'max' => 300], 'color' => ['label' => 'La couleur', 'max' => 20]], $_POST);
        $d['type'] = (string)$this->in('type', '') ?: null; if ($d['type'] && !Ref::has('event_types', $d['type']) && $d['type'] !== ($old['type'] ?? null)) $err['type'] = 'Type d\'événement inconnu.';
        $d['start_at'] = $this->dtl($this->in('start_at')); $d['end_at'] = $this->dtl($this->in('end_at')); $d['reg_deadline'] = $this->dtl($this->in('reg_deadline'));
        if (!$d['start_at']) $err['start_at'] = 'La date de début est obligatoire.'; if (!$d['end_at']) $err['end_at'] = 'La date de fin est obligatoire.';
        if ($d['start_at'] && $d['end_at'] && $d['end_at'] < $d['start_at']) $err['end_at'] = 'La fin doit être postérieure au début.';
        if ($d['reg_deadline'] && $d['start_at'] && $d['reg_deadline'] > $d['end_at']) $err['reg_deadline'] = 'La clôture des inscriptions doit précéder la fin de l\'événement.';
        if ($d['online_url'] && !preg_match('#^https://#i', $d['online_url'])) $err['online_url'] = 'Le lien doit commencer par https://.';
        if ($d['color'] && !preg_match('/^#[0-9A-Fa-f]{6}$/', $d['color'])) $err['color'] = 'Couleur invalide (ex. #003A84).';
        $d['audience'] = (string)$this->in('audience', 'all'); if (!isset(Ev::AUD[$d['audience']])) $err['audience'] = 'Audience inconnue.';
        $d['registration'] = (string)$this->in('registration', 'optional'); if (!isset(Ev::REG[$d['registration']])) $err['registration'] = 'Mode d\'inscription inconnu.';
        $cap = trim((string)$this->in('capacity', '0')); if ($cap === '') $cap = (string)setting('ev.default_capacity', '0'); if (!ctype_digit($cap) || (int)$cap > 100000) $err['capacity'] = 'Capacité : nombre entier (0 = illimitée).'; $d['capacity'] = (int)$cap;
        $d['waitlist'] = $this->in('waitlist') ? 1 : 0; $d['mandatory'] = $this->in('mandatory') ? 1 : 0; $d['organizer_id'] = (int)$this->in('organizer_id', 0) ?: null;
        return [$d, $err];
    }
    private function saveTargets(int $id, string $aud): void {
        DB::exec('DELETE FROM ev_targets WHERE event_id=?', [$id]);
        if ($aud === 'team') foreach ((array)($_POST['team_ids'] ?? []) as $t) if ((int)$t && DB::val('SELECT 1 FROM teams WHERE id=?', [(int)$t])) DB::insert('ev_targets', ['event_id' => $id, 'team_id' => (int)$t]);
        if ($aud === 'store') foreach ((array)($_POST['store_ids'] ?? []) as $t) if ((int)$t && DB::val('SELECT 1 FROM stores WHERE id=?', [(int)$t])) DB::insert('ev_targets', ['event_id' => $id, 'store_id' => (int)$t]);
    }
    /** Photo facultative de l'événement : JPEG, PNG ou WebP, 3 Mo au plus, contrôlée par son contenu. @return array{0:?string,1:?string,2:?string} [fichier, type, erreur] */
    private function photoIn(): array {
        $f = $_FILES['photo'] ?? null; if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return [null, null, null];
        if ($f['error'] !== UPLOAD_ERR_OK || $f['size'] > 3 * 1048576) return [null, null, 'Photo refusée : 3 Mo au plus.'];
        $info = @getimagesize($f['tmp_name']); $ext = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'][$info[2] ?? 0] ?? null; if (!$ext) return [null, null, 'Photo refusée : JPEG, PNG ou WebP uniquement.'];
        $st = \App\Core\Files::put('ev', (string)file_get_contents($f['tmp_name']), $ext); return $st ? [$st, ['jpg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'][$ext], null] : [null, null, 'Photo non enregistrée.'];
    }
    private function dropPhoto(?string $stored, int $exceptId): void { if ($stored && !DB::val('SELECT 1 FROM ev_events WHERE photo=? AND id<>?', [$stored, $exceptId])) @unlink(\App\Core\Files::dir('ev') . '/' . basename($stored)); }
    function photo(string $id): void {
        $e = $this->load($id); if (!$e || !$e['photo']) { $this->notFound(); return; } $p = \App\Core\Files::dir('ev') . '/' . basename($e['photo']); if (!is_file($p)) { $this->notFound(); return; }
        header('Content-Type: ' . ($e['photo_mime'] ?: 'image/jpeg')); header('X-Content-Type-Options: nosniff'); header('Cache-Control: private, max-age=3600'); readfile($p); exit;
    }
    function store(): void {
        [$d, $err] = $this->data(null); [$ph, $pm, $pe] = $this->photoIn(); if ($pe) $err['photo'] = $pe;
        $rep = (string)$this->in('repeat', ''); $until = (string)$this->in('repeat_until', '');
        if ($rep !== '' && !isset(Ev::REPEAT[$rep])) $err['repeat'] = 'Répétition inconnue.';
        if ($rep !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $until)) $err['repeat_until'] = 'Indiquez la date de la dernière occurrence.';
        if ($d['audience'] === 'team' && !array_filter((array)($_POST['team_ids'] ?? []))) $err['audience'] = 'Choisissez au moins une équipe.';
        if ($d['audience'] === 'store' && !array_filter((array)($_POST['store_ids'] ?? []))) $err['audience'] = 'Choisissez au moins une boutique.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); $this->back($err, $_POST, 'ev/new'); }
        $series = $rep !== '' ? 'S' . bin2hex(random_bytes(6)) : null; $n = 0; $first = null; $s = strtotime($d['start_at']); $en = strtotime($d['end_at']); $rd = $d['reg_deadline'] ? strtotime($d['reg_deadline']) : null;
        $step = ['weekly' => '+1 week', 'biweekly' => '+2 weeks', 'monthly' => '+1 month'][$rep] ?? null; $limit = strtotime($until . ' 23:59:59');
        for ($i = 0; $i < 52; $i++) {
            if ($i && !$step) break;
            $mult = $i === 0 ? '' : ($rep === 'monthly' ? "+$i month" : ($rep === 'weekly' ? "+$i week" : '+' . (2 * $i) . ' weeks'));
            $a = $mult ? strtotime($mult, $s) : $s; $b = $mult ? strtotime($mult, $en) : $en; $c = $rd ? ($mult ? strtotime($mult, $rd) : $rd) : null;
            if ($i && $a > $limit) break;
            $row = $d; $row['photo'] = $ph; $row['photo_mime'] = $pm; $row['start_at'] = date('Y-m-d H:i:s', $a); $row['end_at'] = date('Y-m-d H:i:s', $b); $row['reg_deadline'] = $c ? date('Y-m-d H:i:s', $c) : null;
            $row += ['ref' => Ev::nextRef(), 'status' => 'draft', 'series_id' => $series, 'created_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()];
            $id = DB::insert('ev_events', $row); $first ??= $id; $n++; $this->saveTargets($id, $d['audience']); Audit::log('create', 'ev_event', $id, null, $row);
            if (!$step) break;
        }
        flash($n > 1 ? "$n occurrences créées en brouillon." : 'Événement créé en brouillon : publiez-le pour inviter les participants.'); redirect("ev/$first");
    }
    function update(string $id): void {
        $e = DB::one('SELECT * FROM ev_events WHERE id=?', [(int)$id]); if (!$e) { $this->notFound(); return; }
        [$d, $err] = $this->data($e); [$ph, $pm, $pe] = $this->photoIn(); if ($pe) $err['photo'] = $pe;
        if ($d['audience'] === 'team' && !array_filter((array)($_POST['team_ids'] ?? []))) $err['audience'] = 'Choisissez au moins une équipe.';
        if ($d['audience'] === 'store' && !array_filter((array)($_POST['store_ids'] ?? []))) $err['audience'] = 'Choisissez au moins une boutique.';
        if ($e['capacity'] != $d['capacity'] && $d['capacity'] > 0 && $d['capacity'] < (int)DB::val("SELECT COUNT(*) FROM ev_attendees WHERE event_id=? AND status IN ('registered','attended')", [(int)$id])) $err['capacity'] = 'La capacité est inférieure au nombre d\'inscrits.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); $this->back($err, $_POST, "ev/$id/edit"); }
        $before = Ev::targets((int)$id); $d['updated_at'] = now();
        if ($ph) { $d['photo'] = $ph; $d['photo_mime'] = $pm; } elseif (!empty($_POST['remove_photo'])) { $d['photo'] = null; $d['photo_mime'] = null; } DB::update('ev_events', $d, 'id=?', [(int)$id]); $this->saveTargets((int)$id, $d['audience']);
        if (($ph || !empty($_POST['remove_photo'])) && $e['photo']) $this->dropPhoto($e['photo'], (int)$id);
        Audit::log('update', 'ev_event', $id, $e, $d); $new = DB::one('SELECT * FROM ev_events WHERE id=?', [(int)$id]);
        if ($e['status'] === 'published') {
            if ($e['start_at'] !== $new['start_at'] || $e['end_at'] !== $new['end_at'] || $e['location'] !== $new['location']) Ev::notifyAttendees($new, 'Événement modifié : ' . $new['title'], 'Nouveau créneau ou lieu : ' . dt($new['start_at']) . ($new['location'] ? ' — ' . $new['location'] : ''));
            if ($e['audience'] !== $new['audience'] || $before !== Ev::targets((int)$id)) Ev::invite($new);
            if ($new['capacity'] == 0 || $new['capacity'] > $e['capacity']) Ev::promote($new);
        }
        flash('Événement enregistré.'); redirect("ev/$id");
    }
    function publish(string $id): void {
        $e = DB::one('SELECT * FROM ev_events WHERE id=?', [(int)$id]); if (!$e || $e['status'] === 'published') { $this->notFound(); return; }
        if ($e['end_at'] < now()) { flash('Cet événement est déjà passé.', 'danger'); redirect("ev/$id"); }
        DB::update('ev_events', ['status' => 'published', 'cancel_reason' => null, 'updated_at' => now()], 'id=?', [(int)$id]); $n = Ev::invite($e); Audit::log('publish', 'ev_event', $id);
        flash("Événement publié, $n personne(s) prévenue(s)."); redirect("ev/$id");
    }
    function cancel(string $id): void {
        $e = DB::one('SELECT * FROM ev_events WHERE id=?', [(int)$id]); if (!$e || $e['status'] !== 'published') { $this->notFound(); return; }
        $why = trim((string)$this->in('reason', '')); if ($why === '') { flash('Indiquez le motif de l\'annulation.', 'danger'); redirect("ev/$id"); }
        DB::update('ev_events', ['status' => 'cancelled', 'cancel_reason' => mb_substr($why, 0, 300), 'updated_at' => now()], 'id=?', [(int)$id]);
        $n = Ev::notifyAttendees($e, 'Événement annulé : ' . $e['title'], mb_substr($why, 0, 200)); Audit::log('cancel', 'ev_event', $id, null, ['reason' => $why]);
        flash("Événement annulé, $n personne(s) prévenue(s)."); redirect("ev/$id");
    }
    function delete(string $id): void {
        $e = DB::one('SELECT * FROM ev_events WHERE id=?', [(int)$id]); if (!$e) { $this->notFound(); return; }
        if ($e['status'] === 'published') { flash('Annulez l\'événement avant de le supprimer.', 'danger'); redirect("ev/$id"); }
        foreach (['ev_targets', 'ev_attendees', 'ev_tasks', 'ev_feedback'] as $t) DB::exec("DELETE FROM $t WHERE event_id=?", [(int)$id]);
        DB::exec('DELETE FROM ev_events WHERE id=?', [(int)$id]); Audit::log('delete', 'ev_event', $id, $e); flash('Événement supprimé.'); redirect('ev/list');
    }

    // =============== Participation ===============
    function register(string $id): void {
        $e = $this->load($id); $me = Ev::me(); if (!$e || !$me) { $this->notFound(); return; }
        $r = Ev::register($e, $me);
        flash(['registered' => 'Vous êtes inscrit(e).', 'waitlist' => 'L\'événement est complet : vous êtes sur liste d\'attente.', 'full' => 'L\'événement est complet.', 'closed' => 'Les inscriptions sont closes.'][$r], in_array($r, ['registered', 'waitlist'], true) ? 'success' : 'danger'); redirect("ev/$id");
    }
    function unregister(string $id): void {
        $e = $this->load($id); $me = Ev::me(); if (!$e || !$me) { $this->notFound(); return; }
        if ((int)$e['mandatory']) { flash('Cet événement est obligatoire : contactez l\'organisateur pour une dispense.', 'danger'); redirect("ev/$id"); }
        if ($e['start_at'] <= now()) { flash('L\'événement a déjà commencé.', 'danger'); redirect("ev/$id"); }
        Ev::unregister($e, $me); flash('Votre inscription est annulée.'); redirect("ev/$id");
    }
    function checkin(string $id): void {
        $e = $this->load($id); $me = Ev::me(); if (!$e || !$me) { $this->notFound(); return; }
        $a = DB::one('SELECT * FROM ev_attendees WHERE event_id=? AND employee_id=?', [(int)$id, $me]);
        if (!$a || !Ev::checkinOpen($e) || !in_array($a['status'], ['invited', 'registered'], true)) { flash('Pointage impossible pour le moment.', 'danger'); redirect("ev/$id"); }
        DB::update('ev_attendees', ['status' => 'attended', 'checked_in_at' => now()], 'id=?', [(int)$a['id']]); flash('Présence enregistrée.'); redirect("ev/$id");
    }
    function addAttendees(string $id): void {
        $e = DB::one('SELECT * FROM ev_events WHERE id=?', [(int)$id]); if (!$e) { $this->notFound(); return; }
        $ids = array_map('intval', (array)($_POST['employee_ids'] ?? []));
        if ((int)$this->in('team_id', 0)) $ids = array_merge($ids, array_map('intval', array_column(DB::all("SELECT id FROM employees WHERE team_id=? AND status<>'left'", [(int)$this->in('team_id')]), 'id')));
        if ((int)$this->in('store_id', 0)) $ids = array_merge($ids, array_map('intval', array_column(DB::all("SELECT id FROM employees WHERE store_id=? AND status<>'left'", [(int)$this->in('store_id')]), 'id')));
        $n = 0;
        foreach (array_unique($ids) as $emp) {
            if (!$emp || !DB::val('SELECT 1 FROM employees WHERE id=?', [$emp]) || DB::val('SELECT 1 FROM ev_attendees WHERE event_id=? AND employee_id=?', [(int)$id, $emp])) continue;
            $reg = (int)$e['mandatory'] && $e['status'] === 'published';
            DB::insert('ev_attendees', ['event_id' => (int)$id, 'employee_id' => $emp, 'status' => $reg ? 'registered' : 'invited', 'source' => $reg ? 'auto' : 'invited', 'registered_at' => $reg ? now() : null]); $n++;
            if ($e['status'] === 'published' && ($u = Ev::userOf($emp))) Notifier::send($u, 'Invitation : ' . $e['title'], dt($e['start_at']), '/ev/' . $id);
        }
        Audit::log('invite', 'ev_event', $id, null, ['added' => $n]); flash("$n participant(s) ajouté(s)."); redirect("ev/$id");
    }
    function attendee(string $id, string $aid): void {
        $e = DB::one('SELECT * FROM ev_events WHERE id=?', [(int)$id]); $a = DB::one('SELECT * FROM ev_attendees WHERE id=? AND event_id=?', [(int)$aid, (int)$id]); if (!$e || !$a) { $this->notFound(); return; }
        $st = (string)$this->in('status', '');
        if ($st === 'remove') { DB::exec('DELETE FROM ev_attendees WHERE id=?', [(int)$aid]); if ($a['status'] === 'registered') Ev::promote($e); }
        elseif (isset(Ev::ATT[$st])) { DB::update('ev_attendees', ['status' => $st, 'checked_in_at' => $st === 'attended' ? ($a['checked_in_at'] ?: now()) : $a['checked_in_at'], 'registered_at' => $a['registered_at'] ?: ($st === 'registered' ? now() : null)], 'id=?', [(int)$aid]); if ($a['status'] === 'registered' && $st !== 'attended') Ev::promote($e); }
        flash('Participant mis à jour.'); redirect("ev/$id");
    }
    function bulkPresence(string $id): void {
        $e = DB::one('SELECT * FROM ev_events WHERE id=?', [(int)$id]); if (!$e) { $this->notFound(); return; }
        $present = array_map('intval', (array)($_POST['present'] ?? [])); $n = 0;
        foreach (DB::all("SELECT * FROM ev_attendees WHERE event_id=? AND status IN ('registered','invited','attended','absent')", [(int)$id]) as $a) {
            $st = in_array((int)$a['id'], $present, true) ? 'attended' : ($a['status'] === 'invited' && !(int)$e['mandatory'] ? 'invited' : 'absent');
            if ($st !== $a['status']) { DB::update('ev_attendees', ['status' => $st, 'checked_in_at' => $st === 'attended' ? ($a['checked_in_at'] ?: now()) : null], 'id=?', [(int)$a['id']]); $n++; }
        }
        Audit::log('presence', 'ev_event', $id, null, ['updated' => $n]); flash('Présences enregistrées.'); redirect("ev/$id");
    }
    function feedback(string $id): void {
        $e = $this->load($id); $me = Ev::me(); if (!$e || !$me) { $this->notFound(); return; }
        $a = DB::one('SELECT * FROM ev_attendees WHERE event_id=? AND employee_id=?', [(int)$id, $me]);
        if (!$a || !in_array($a['status'], ['attended', 'registered'], true) || $e['end_at'] > now()) { flash('Vous pourrez donner votre avis après l\'événement si vous y étiez inscrit.', 'danger'); redirect("ev/$id"); }
        $r = (int)$this->in('rating', 0); if ($r < 1 || $r > 5) { flash('Choisissez une note de 1 à 5.', 'danger'); redirect("ev/$id"); }
        $d = ['rating' => $r, 'comment' => mb_substr(trim((string)$this->in('comment', '')), 0, 1000) ?: null, 'created_at' => now()];
        $old = DB::one('SELECT id FROM ev_feedback WHERE event_id=? AND employee_id=?', [(int)$id, $me]);
        if ($old) DB::update('ev_feedback', $d, 'id=?', [(int)$old['id']]); else DB::insert('ev_feedback', $d + ['event_id' => (int)$id, 'employee_id' => $me]);
        flash('Merci pour votre avis.'); redirect("ev/$id");
    }

    // =============== Préparation (tâches) ===============
    function addTask(string $id): void {
        if (!DB::val('SELECT 1 FROM ev_events WHERE id=?', [(int)$id])) { $this->notFound(); return; }
        $l = trim((string)$this->in('label', '')); if ($l === '' || mb_strlen($l) > 200) { flash('Intitulé de la tâche obligatoire (200 caractères).', 'danger'); redirect("ev/$id"); }
        $due = (string)$this->in('due_date', ''); if ($due !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $due)) { flash('Date invalide.', 'danger'); redirect("ev/$id"); }
        DB::insert('ev_tasks', ['event_id' => (int)$id, 'label' => $l, 'owner_id' => (int)$this->in('owner_id', 0) ?: null, 'due_date' => $due ?: null, 'done' => 0]); flash('Tâche ajoutée.'); redirect("ev/$id");
    }
    function toggleTask(string $id, string $tid): void {
        $t = DB::one('SELECT * FROM ev_tasks WHERE id=? AND event_id=?', [(int)$tid, (int)$id]); if (!$t) { $this->notFound(); return; }
        DB::update('ev_tasks', ['done' => $t['done'] ? 0 : 1, 'done_at' => $t['done'] ? null : now()], 'id=?', [(int)$tid]); redirect("ev/$id");
    }
    function delTask(string $id, string $tid): void { DB::exec('DELETE FROM ev_tasks WHERE id=? AND event_id=?', [(int)$tid, (int)$id]); redirect("ev/$id"); }

    // =============== Exports ===============
    function exportAttendance(string $id): void {
        $e = DB::one('SELECT * FROM ev_events WHERE id=?', [(int)$id]); if (!$e) { $this->notFound(); return; }
        csv_download('presence_' . $e['ref'] . '.csv', ['Événement', 'Date', 'Matricule', 'Nom', 'Prénom', 'Équipe', 'Statut', 'Inscrit le', 'Pointé le'],
            array_map(fn($r) => [$e['title'], substr($e['start_at'], 0, 16), $r['matricule'], $r['last_name'], $r['first_name'], $r['team'], Ev::ATT[$r['status']] ?? $r['status'], $r['registered_at'], $r['checked_in_at']],
                DB::all('SELECT a.*, p.first_name, p.last_name, p.matricule, t.name team FROM ev_attendees a JOIN employees p ON p.id=a.employee_id LEFT JOIN teams t ON t.id=p.team_id WHERE a.event_id=? ORDER BY p.last_name', [(int)$id])));
    }
    private function sendIcs(array $events, string $name, string $file): never {
        header('Content-Type: text/calendar; charset=utf-8'); header('Content-Disposition: attachment; filename="' . $file . '"'); header('X-Content-Type-Options: nosniff'); echo Ev::ics($events, $name); exit;
    }
    function ics(string $id): void { $e = $this->load($id); if (!$e) { $this->notFound(); return; } $this->sendIcs([$e], $e['title'], $e['ref'] . '.ics'); }
    function icsAll(): void {
        $me = Ev::me(); $rows = array_filter($this->visibleRows(DB::all("SELECT * FROM ev_events WHERE status='published' AND end_at>=? ORDER BY start_at LIMIT 300", [date('Y-m-d H:i:s', strtotime('-7 days'))])), fn($e) => $e['audience'] === 'all' || DB::val('SELECT 1 FROM ev_attendees WHERE event_id=? AND employee_id=?', [(int)$e['id'], $me]) || can('ev.manage'));
        $this->sendIcs(array_values($rows), 'Événements', 'evenements.ics');
    }

    // =============== Statistiques ===============
    function stats(): void {
        $y = (int)$this->in('year', date('Y')); if ($y < 2000 || $y > 2100) $y = (int)date('Y');
        $ev = DB::all("SELECT * FROM ev_events WHERE status='published' AND start_at>=? AND start_at<=?", ["$y-01-01 00:00:00", "$y-12-31 23:59:59"]);
        $by = []; $tot = ['events' => 0, 'past' => 0, 'invited' => 0, 'registered' => 0, 'attended' => 0, 'absent' => 0];
        foreach ($ev as $e) {
            $past = $e['end_at'] < now(); $c = Ev::counts((int)$e['id']); $f = DB::one('SELECT AVG(rating) a, COUNT(*) n FROM ev_feedback WHERE event_id=?', [(int)$e['id']]);
            $t = $e['type'] ?: '—'; $by[$t] ??= ['n' => 0, 'reg' => 0, 'att' => 0, 'abs' => 0, 'rs' => 0, 'rn' => 0, 'inv' => 0];
            $by[$t]['n']++; $by[$t]['reg'] += $c['registered'] + $c['attended'] + $c['absent']; $by[$t]['att'] += $c['attended']; $by[$t]['abs'] += $c['absent']; $by[$t]['inv'] += $c['invited'];
            if ($f['n']) { $by[$t]['rs'] += $f['a'] * $f['n']; $by[$t]['rn'] += $f['n']; }
            $tot['events']++; $tot['past'] += $past ? 1 : 0; $tot['registered'] += $c['registered'] + $c['attended'] + $c['absent']; $tot['attended'] += $c['attended']; $tot['absent'] += $c['absent'];
        }
        $top = DB::all("SELECT e.id, e.title, e.start_at, AVG(f.rating) a, COUNT(*) n FROM ev_feedback f JOIN ev_events e ON e.id=f.event_id WHERE e.start_at>=? AND e.start_at<=? GROUP BY e.id, e.title, e.start_at ORDER BY a DESC LIMIT 5", ["$y-01-01", "$y-12-31 23:59:59"]);
        $this->view('ev/stats', ['title' => 'Statistiques des événements', 'y' => $y, 'by' => $by, 'tot' => $tot, 'top' => $top]);
    }
}
