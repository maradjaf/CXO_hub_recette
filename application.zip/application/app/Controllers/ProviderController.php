<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Provider, Bulk};

/** Espace du responsable prestataire : tableau de bord et gestion RH de son personnel (jamais celui des autres sociétés). */
class ProviderController extends Controller {
    private const MONTHS = ['01' => 'janv.', '02' => 'févr.', '03' => 'mars', '04' => 'avr.', '05' => 'mai', '06' => 'juin', '07' => 'juil.', '08' => 'août', '09' => 'sept.', '10' => 'oct.', '11' => 'nov.', '12' => 'déc.'];
    private function ml(string $ym): string { return self::MONTHS[substr($ym, 5, 2)] . ' ' . substr($ym, 2, 2); }
    private function code(): string { $c = Provider::code(); if (!$c) { flash('Aucune société prestataire n\'est configurée (Organisation › Sociétés employeuses).', 'warning'); redirect('/'); } return $c; }
    private function ctx(string $c): array { return ['code' => $c, 'pname' => Provider::name($c), 'providers' => Provider::locked() ? [] : Provider::all()]; }

    function dashboard(): void {
        $c = $this->code(); $today = date('Y-m-d'); $y1 = date('Y-m-d', strtotime('-12 months'));
        $head = (int)DB::val("SELECT COUNT(*) FROM employees WHERE employer=? AND status='active'", [$c]);
        $months = []; for ($i = 11; $i >= 0; $i--) $months[] = date('Y-m', strtotime(date('Y-m-01') . " -$i months"));
        $arr = array_column(DB::all("SELECT hire_date d FROM employees WHERE employer=? AND hire_date>=?", [$c, $months[0] . '-01']), 'd'); $dep = array_column(DB::all("SELECT o.exit_date d FROM offboarding_cases o JOIN employees e ON e.id=o.employee_id WHERE e.employer=? AND o.status<>'cancelled' AND o.exit_date>=?", [$c, $months[0] . '-01']), 'd');
        $cnt = fn(array $ds) => array_map(fn($m) => count(array_filter($ds, fn($d) => substr((string)$d, 0, 7) === $m)), $months);
        $arrM = $cnt($arr); $depM = $cnt($dep);
        $dep12 = (int)DB::val("SELECT COUNT(*) FROM offboarding_cases o JOIN employees e ON e.id=o.employee_id WHERE e.employer=? AND o.status<>'cancelled' AND o.exit_date>=? AND o.exit_date<=?", [$c, $y1, $today]);
        $abs = []; foreach ($months as $m) { $from = $m . '-01'; $to = date('Y-m-t', strtotime($from)); $days = (float)DB::val("SELECT COALESCE(SUM(a.days),0) FROM absences a JOIN employees e ON e.id=a.employee_id WHERE e.employer=? AND a.start_date>=? AND a.start_date<=?", [$c, $from, $to]);
            $wd = LeaveController::workingDays($from, min($to, $today) >= $from ? min($to, $today) : $from); $abs[] = $head ? round($days / ($head * max(1, $wd)) * 100, 2) : 0; }
        $qm = DB::all("SELECT SUBSTR(q.eval_date,1,7) m, AVG(q.score_pct) s FROM qa_evaluations q JOIN employees e ON e.id=q.employee_id WHERE e.employer=? AND q.eval_date>=? GROUP BY SUBSTR(q.eval_date,1,7)", [$c, $months[0] . '-01']); $qmap = array_column($qm, 's', 'm');
        $q90 = DB::val("SELECT AVG(q.score_pct) FROM qa_evaluations q JOIN employees e ON e.id=q.employee_id WHERE e.employer=? AND q.eval_date>=?", [$c, date('Y-m-d', strtotime('-90 days'))]);
        $tr = DB::one("SELECT COUNT(*) n, SUM(CASE WHEN te.status='passed' THEN 1 ELSE 0 END) ok FROM training_enrollments te JOIN employees e ON e.id=te.employee_id JOIN training_sessions s ON s.id=te.session_id WHERE e.employer=? AND s.session_date>=?", [$c, $y1]);
        $kinds = DB::all("SELECT a.kind, SUM(a.days) d FROM absences a JOIN employees e ON e.id=a.employee_id WHERE e.employer=? AND a.start_date>=? GROUP BY a.kind ORDER BY d DESC", [$c, date('Y-m-d', strtotime('-90 days'))]);
        $klabel = array_column(DB::all("SELECT v.code, v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='absence_kinds'"), 'label', 'code');
        $sen = [0, 0, 0, 0, 0]; foreach (DB::all("SELECT hire_date FROM employees WHERE employer=? AND status='active' AND hire_date IS NOT NULL", [$c]) as $r) { $mo = (strtotime($today) - strtotime($r['hire_date'])) / 2629800; $sen[$mo < 6 ? 0 : ($mo < 12 ? 1 : ($mo < 24 ? 2 : ($mo < 60 ? 3 : 4)))]++; }
        $this->view('provider/dashboard', $this->ctx($c) + ['title' => 'Tableau de bord prestataire', 'head' => $head, 'dep12' => $dep12, 'turn' => $head ? round($dep12 / $head * 100, 1) : 0, 'absRate' => end($abs) ?: 0,
            'soon' => (int)DB::val("SELECT COUNT(*) FROM contracts k JOIN employees e ON e.id=k.employee_id WHERE e.employer=? AND k.status='active' AND k.end_date IS NOT NULL AND k.end_date<=?", [$c, date('Y-m-d', strtotime('+30 days'))]),
            'onb' => (int)DB::val("SELECT COUNT(*) FROM onboarding_cases o JOIN employees e ON e.id=o.employee_id WHERE e.employer=? AND o.status='open'", [$c]), 'offb' => (int)DB::val("SELECT COUNT(*) FROM offboarding_cases o JOIN employees e ON e.id=o.employee_id WHERE e.employer=? AND o.status='open'", [$c]),
            'q90' => $q90 !== null ? round((float)$q90, 1) : null, 'trPct' => $tr && $tr['n'] ? round($tr['ok'] / $tr['n'] * 100) : null, 'trN' => (int)($tr['n'] ?? 0),
            'labels' => array_map([$this, 'ml'], $months), 'arr' => $arrM, 'dep' => $depM, 'abs' => $abs, 'qual' => array_map(fn($m) => isset($qmap[$m]) ? round((float)$qmap[$m], 1) : null, $months),
            'byTeam' => DB::all("SELECT COALESCE(t.name,'Sans équipe') name, COUNT(*) n FROM employees e LEFT JOIN teams t ON t.id=e.team_id WHERE e.employer=? AND e.status='active' GROUP BY t.name ORDER BY n DESC LIMIT 12", [$c]),
            'byContract' => DB::all("SELECT COALESCE(NULLIF(contract_type,''),'Non renseigné') name, COUNT(*) n FROM employees WHERE employer=? AND status='active' GROUP BY contract_type ORDER BY n DESC", [$c]),
            'kinds' => array_map(fn($k) => ['name' => (string)($klabel[$k['kind']] ?? $k['kind']), 'd' => (float)$k['d']], $kinds), 'sen' => $sen]);
    }

    /** Listes du personnel (une configuration par type, tout est filtré sur la société). */
    function lists(string $kind): void {
        $c = $this->code(); $cfg = $this->config($kind, $c); if (!$cfg) { $this->notFound(); return; }
        $this->view('provider/list', $this->ctx($c) + ['title' => $cfg['title'], 'kind' => $kind, 'head' => $cfg['head'], 'rows' => $cfg['rows'], 'staff' => DB::all("SELECT id, first_name, last_name, matricule FROM employees WHERE employer=? AND status<>'left' ORDER BY last_name, first_name", [$c]),
            'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'), 'positions' => DB::all('SELECT id, name FROM positions WHERE active=1 ORDER BY name'), 'contractTypes' => DB::all("SELECT v.code, v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='contract_types' AND v.active=1 ORDER BY v.sort_order, v.label"),
            'absKinds' => DB::all("SELECT v.code, v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='absence_kinds' AND v.active=1 ORDER BY v.sort_order, v.label"), 'templates' => DB::all('SELECT id, name FROM onboarding_templates WHERE active=1 ORDER BY name'), 'types' => OffboardingController::TYPES, 'manage' => can('provider.manage')]);
    }
    private function config(string $kind, string $c): ?array {
        $b = fn(string $l, string $k) => badge($l, $k);
        switch ($kind) {
            case 'staff':
                $st = (string)$this->in('status', 'active'); $w = $st === 'all' ? '1=1' : ($st === 'left' ? "e.status='left'" : "e.status='active'");
                $r = DB::all("SELECT e.*, t.name team, p.name pos FROM employees e LEFT JOIN teams t ON t.id=e.team_id LEFT JOIN positions p ON p.id=e.position_id WHERE e.employer=? AND $w ORDER BY e.last_name, e.first_name", [$c]);
                return ['title' => 'Personnel', 'head' => ['Matricule', 'Nom', 'Poste', 'Équipe', 'Contrat', 'Embauche', 'Statut'], 'rows' => array_map(fn($x) => [e($x['matricule']), e($x['last_name'] . ' ' . $x['first_name']), e((string)$x['pos']), e((string)$x['team']), e((string)$x['contract_type']), d($x['hire_date']), $x['status'] === 'active' ? $b('Actif', 'success') : $b($x['status'] === 'left' ? 'Sorti' : (string)$x['status'], 'secondary')], $r)];
            case 'absences':
                $r = DB::all("SELECT a.*, e.first_name, e.last_name, e.matricule FROM absences a JOIN employees e ON e.id=a.employee_id WHERE e.employer=? ORDER BY a.start_date DESC, a.id DESC LIMIT 1000", [$c]); $lab = array_column(DB::all("SELECT v.code, v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='absence_kinds'"), 'label', 'code');
                return ['title' => 'Absences', 'head' => ['Collaborateur', 'Du', 'Au', 'Jours', 'Motif', 'Justifiée'], 'rows' => array_map(fn($x) => [e($x['last_name'] . ' ' . $x['first_name']), d($x['start_date']), d($x['end_date']), rtrim(rtrim(number_format((float)$x['days'], 1, ',', ''), '0'), ','), e((string)($lab[$x['kind']] ?? $x['kind'])), $x['justified'] ? $b('Oui', 'success') : $b('Non', 'warning')], $r)];
            case 'contracts':
                $w = $this->in('soon') ? "AND k.status='active' AND k.end_date IS NOT NULL AND k.end_date<='" . date('Y-m-d', strtotime('+30 days')) . "'" : '';
                $r = DB::all("SELECT k.*, e.first_name, e.last_name, e.matricule FROM contracts k JOIN employees e ON e.id=k.employee_id WHERE e.employer=? $w ORDER BY k.status, k.end_date IS NULL, k.end_date", [$c]);
                return ['title' => 'Contrats', 'head' => ['Collaborateur', 'Type', 'Début', 'Fin', 'Statut', ''], 'rows' => array_map(function ($x) {
                    $late = $x['status'] === 'active' && $x['end_date'] && $x['end_date'] < date('Y-m-d'); $soon = $x['status'] === 'active' && $x['end_date'] && !$late && $x['end_date'] <= date('Y-m-d', strtotime('+30 days'));
                    $act = ($x['status'] === 'active' && can('provider.manage')) ? '<form method="post" action="' . url('provider/contracts/' . $x['id'] . '/end') . '" class="d-flex gap-2 justify-content-end" data-confirm="Clore ce contrat ?">' . csrf_field() . '<label class="form-check small mb-0 text-nowrap"><input class="form-check-input" type="checkbox" name="launch" value="1"> Lancer le départ</label><button class="btn btn-sm btn-outline-secondary">Clore</button></form>' : '';
                    return [e($x['last_name'] . ' ' . $x['first_name']), e($x['type']), d($x['start_date']), $x['end_date'] ? d($x['end_date']) : 'Indéterminée', $late ? badge('Échu', 'danger') : ($soon ? badge('Échéance proche', 'warning') : badge($x['status'] === 'active' ? 'En cours' : 'Clos', $x['status'] === 'active' ? 'success' : 'secondary')), $act]; }, $r)];
            case 'onboarding':
                $r = DB::all("SELECT o.*, e.first_name, e.last_name, (SELECT COUNT(*) FROM onboarding_tasks t WHERE t.case_id=o.id) n, (SELECT COUNT(*) FROM onboarding_tasks t WHERE t.case_id=o.id AND t.status='done') f FROM onboarding_cases o JOIN employees e ON e.id=o.employee_id WHERE e.employer=? ORDER BY o.id DESC", [$c]);
                return ['title' => 'Intégrations', 'head' => ['Collaborateur', 'Début', 'Avancement', 'Statut'], 'rows' => array_map(fn($x) => [e($x['last_name'] . ' ' . $x['first_name']), d($x['start_date']), $x['f'] . '/' . $x['n'] . ' tâches', $x['status'] === 'open' ? $b('En cours', 'warning') : $b('Terminé', 'success')], $r)];
            case 'offboarding':
                $r = DB::all("SELECT o.*, e.first_name, e.last_name, (SELECT COUNT(*) FROM offboarding_tasks t WHERE t.case_id=o.id) n, (SELECT COUNT(*) FROM offboarding_tasks t WHERE t.case_id=o.id AND t.status='done') f FROM offboarding_cases o JOIN employees e ON e.id=o.employee_id WHERE e.employer=? ORDER BY o.exit_date DESC, o.id DESC", [$c]);
                return ['title' => 'Départs', 'head' => ['Collaborateur', 'Type', 'Date de départ', 'Avancement', 'Statut'], 'rows' => array_map(fn($x) => [e($x['last_name'] . ' ' . $x['first_name']), e(OffboardingController::TYPES[$x['exit_type']] ?? $x['exit_type']), d($x['exit_date']), $x['f'] . '/' . $x['n'] . ' tâches', $x['status'] === 'open' ? $b('En cours', 'warning') : ($x['status'] === 'closed' ? $b('Clôturé', 'success') : $b('Annulé', 'secondary'))], $r)];
            case 'quality':
                $r = DB::all("SELECT q.eval_date, q.score_pct, q.critical_fail, e.first_name, e.last_name, g.name grid FROM qa_evaluations q JOIN employees e ON e.id=q.employee_id LEFT JOIN qa_grids g ON g.id=q.grid_id WHERE e.employer=? ORDER BY q.eval_date DESC, q.id DESC LIMIT 1000", [$c]);
                return ['title' => 'Qualité', 'head' => ['Date', 'Collaborateur', 'Grille', 'Note', 'Critique'], 'rows' => array_map(fn($x) => [d($x['eval_date']), e($x['last_name'] . ' ' . $x['first_name']), e((string)$x['grid']), number_format((float)$x['score_pct'], 1, ',', '') . ' %', $x['critical_fail'] ? $b('Échec critique', 'danger') : '—'], $r)];
            case 'trainings':
                $r = DB::all("SELECT te.status, te.score, s.session_date, tr.title, e.first_name, e.last_name FROM training_enrollments te JOIN employees e ON e.id=te.employee_id JOIN training_sessions s ON s.id=te.session_id JOIN trainings tr ON tr.id=s.training_id WHERE e.employer=? ORDER BY s.session_date DESC LIMIT 1000", [$c]);
                return ['title' => 'Formations', 'head' => ['Date', 'Collaborateur', 'Formation', 'Statut', 'Score'], 'rows' => array_map(fn($x) => [d($x['session_date']), e($x['last_name'] . ' ' . $x['first_name']), e($x['title']), $x['status'] === 'passed' ? $b('Validée', 'success') : badge((string)$x['status'], 'secondary'), $x['score'] !== null ? round((float)$x['score']) . ' %' : '—'], $r)];
        }
        return null;
    }
    function export(): void {
        $c = $this->code(); $r = DB::all("SELECT e.matricule, e.last_name, e.first_name, e.email, e.phone, t.name team, e.hire_date, e.contract_type, e.status FROM employees e LEFT JOIN teams t ON t.id=e.team_id WHERE e.employer=? ORDER BY e.last_name", [$c]);
        Audit::log('export', 'provider_staff', null, null, ['employer' => $c, 'rows' => count($r)]); csv_download('personnel_' . preg_replace('/[^A-Za-z0-9]+/', '_', $c) . '_' . date('Ymd') . '.csv', ['Matricule', 'Nom', 'Prénom', 'Email', 'Téléphone', 'Équipe', 'Embauche', 'Contrat', 'Statut'], $r);
    }

    // ---- Actions (droit provider.manage), toujours bornées à la société ----
    function addEmployee(): void {
        $c = $this->code(); [$d, $err] = $this->validate(['first_name' => ['label' => 'Le prénom', 'req' => true, 'max' => 100], 'last_name' => ['label' => 'Le nom', 'req' => true, 'max' => 100], 'email' => ['label' => 'L\'email', 'email' => true, 'max' => 190], 'phone' => ['label' => 'Le téléphone', 'max' => 40], 'hire_date' => ['label' => 'La date d\'embauche', 'date' => true]], $_POST);
        $team = (int)$this->in('team_id', 0) ?: null; $ch = $team ? DB::val('SELECT channel_id FROM teams WHERE id=?', [$team]) : null; if ($team && !DB::val('SELECT 1 FROM teams WHERE id=?', [$team])) $err['team'] = 'Équipe inconnue.';
        $pos = (int)$this->in('position_id', 0) ?: null; if ($pos && !DB::val('SELECT 1 FROM positions WHERE id=?', [$pos])) $err['pos'] = 'Poste inconnu.';
        $ct = (string)$this->in('contract_type', ''); if ($ct !== '' && !DB::val("SELECT 1 FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='contract_types' AND v.code=?", [$ct])) $err['ct'] = 'Type de contrat inconnu.';
        if ($err) { flash(implode(' ', $err), 'danger'); redirect('provider/staff'); }
        $d += ['matricule' => EmployeesController::nextMatricule($c), 'matricule_confirmed' => 0, 'employer' => $c, 'team_id' => $team, 'channel_id' => $ch ?: null, 'position_id' => $pos, 'contract_type' => $ct ?: null, 'status' => 'active', 'created_at' => now(), 'updated_at' => now()];
        $d['email'] = $d['email'] ? strtolower($d['email']) : null; $id = DB::insert('employees', $d); Audit::log('create', 'employee', $id, null, $d + ['via' => 'provider']);
        flash('Collaborateur ajouté (matricule ' . $d['matricule'] . ').'); redirect('provider/staff');
    }
    function addAbsence(): void {
        $c = $this->code(); $emp = (int)$this->in('employee_id', 0); [$d, $err] = $this->validate(['start_date' => ['label' => 'La date de début', 'req' => true, 'date' => true], 'end_date' => ['label' => 'La date de fin', 'req' => true, 'date' => true], 'note' => ['label' => 'La note', 'max' => 500]], $_POST);
        if (!Provider::owns($emp, $c)) $err['emp'] = 'Collaborateur hors de votre société.'; $k = (string)$this->in('kind', ''); if (!DB::val("SELECT 1 FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='absence_kinds' AND v.code=?", [$k])) $err['kind'] = 'Motif inconnu.';
        if (!$err && $d['end_date'] < $d['start_date']) $err['end'] = 'La fin est antérieure au début.';
        if ($err) { flash(implode(' ', $err), 'danger'); redirect('provider/absences'); }
        $days = (float)LeaveController::workingDays($d['start_date'], $d['end_date']); $row = $d + ['employee_id' => $emp, 'kind' => $k, 'days' => max(1, $days), 'justified' => $this->in('justified') === '1' ? 1 : 0, 'recorded_by' => Auth::id(), 'created_at' => now()];
        $id = DB::insert('absences', $row); Audit::log('create', 'absence', $id, null, $row + ['via' => 'provider']); flash('Absence enregistrée.'); redirect('provider/absences');
    }
    function endContract(string $id): void {
        $c = $this->code(); $k = DB::one("SELECT k.* FROM contracts k JOIN employees e ON e.id=k.employee_id WHERE k.id=? AND e.employer=? AND k.status='active'", [(int)$id, $c]); if (!$k) { $this->notFound(); return; }
        $date = $k['end_date'] ?: date('Y-m-d'); DB::update('contracts', ['status' => 'ended', 'end_date' => $date], 'id=?', [(int)$id]); Audit::log('end', 'contract', $id, $k, ['via' => 'provider']);
        $roles = []; $dep = $this->in('launch') === '1' && OffboardingController::open((int)$k['employee_id'], 'end_contract', $date, 'Fin de contrat', $roles) !== null; if ($dep) OffboardingController::tell($roles, 'Fin de contrat à traiter (prestataire).', '/offboarding');
        flash('Contrat clos.' . ($dep ? ' Parcours de départ lancé.' : '')); redirect('provider/contracts');
    }
    function launchOn(): void { $this->launch('onboarding'); }
    function launchOff(): void { $this->launch('offboarding'); }
    /** Lancement individuel ou en masse (cases + matricules) d'intégrations ou de départs pour le personnel de la société. */
    function launch(string $what): void {
        $c = $this->code(); if (!in_array($what, ['onboarding', 'offboarding'], true)) { $this->notFound(); return; }
        [$ids, $unknown] = Bulk::ids($_POST); $mine = array_values(array_filter($ids, fn($i) => Provider::owns($i, $c))); $foreign = count($ids) - count($mine); $roles = []; $ok = 0; $skip = 0; $date = (string)$this->in('date', date('Y-m-d'));
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) { flash('Date invalide.', 'danger'); redirect("provider/$what"); }
        if ($what === 'onboarding') { $tpl = (int)$this->in('template_id'); if (!DB::val('SELECT 1 FROM onboarding_templates WHERE id=? AND active=1', [$tpl])) { flash('Choisissez un modèle.', 'danger'); redirect('provider/onboarding'); } foreach ($mine as $i) { if (OnboardingController::open($i, $tpl, $date, $roles)) $ok++; else $skip++; } }
        else { $type = (string)$this->in('exit_type'); if (!isset(OffboardingController::TYPES[$type])) { flash('Type de départ invalide.', 'danger'); redirect('provider/offboarding'); } foreach ($mine as $i) { if (OffboardingController::open($i, $type, $date, trim((string)$this->in('reason', '')) ?: null, $roles)) $ok++; else $skip++; } }
        foreach (array_keys($roles) as $role) foreach (DB::all('SELECT ur.user_id FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE r.code=?', [$role]) as $u) \App\Core\Notifier::send((int)$u['user_id'], $what === 'onboarding' ? 'Parcours d\'intégration (prestataire)' : 'Départ à préparer (prestataire)', $ok . ' collaborateur(s) de ' . Provider::name($c) . '.', '/' . $what);
        Audit::log('bulk', $what . '_case', null, null, ['via' => 'provider', 'employer' => $c, 'created' => $ok, 'skipped' => $skip, 'foreign' => $foreign]);
        flash(Bulk::report($ok, $skip, $unknown, $what === 'onboarding' ? 'parcours lancé(s)' : 'départ(s) lancé(s)') . ($foreign ? " $foreign collaborateur(s) hors de votre société ignoré(s)." : ''), $ok ? 'success' : 'warning'); redirect("provider/$what");
    }
}
