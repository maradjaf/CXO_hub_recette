<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Auth, Xchg, Audit};

/** Médias insérés dans le contenu des cours par l'éditeur (images, vidéos, sons). */
class ElMediaController extends Controller {
    const TYPES = ['png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'gif' => 'image/gif', 'webp' => 'image/webp', 'mp4' => 'video/mp4', 'webm' => 'video/webm', 'mp3' => 'audio/mpeg', 'wav' => 'audio/wav', 'm4a' => 'audio/mp4', 'ogg' => 'audio/ogg'];
    private function json($d, int $code = 200): never { http_response_code($code); header('Content-Type: application/json; charset=utf-8'); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
    function upload(): void {
        $f = $_FILES['file'] ?? null; if (!$f || ($f['error'] ?? 4) !== UPLOAD_ERR_OK) $this->json(['error' => 'Fichier non reçu (limite PHP : upload_max_filesize / post_max_size).'], 422);
        $max = Xchg::int('elearn.media_max_mb', 1, 500) * 1048576; if ($f['size'] > $max) $this->json(['error' => 'Fichier trop volumineux (' . round($max / 1048576) . ' Mo maximum).'], 422);
        $name = trim(preg_replace('#[\x00-\x1f\\\\/]+#', '_', (string)$f['name'])); $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION)); if (!isset(self::TYPES[$ext])) $this->json(['error' => 'Type non autorisé (images, mp4, webm, sons).'], 422);
        $mime = function_exists('mime_content_type') ? (string)@mime_content_type($f['tmp_name']) : ''; $fam = explode('/', self::TYPES[$ext])[0];
        if ($mime !== '' && !str_starts_with($mime, $fam . '/') && !($fam === 'audio' && $mime === 'application/octet-stream') && !($ext === 'mp4' && $mime === 'application/octet-stream')) $this->json(['error' => 'Le contenu du fichier ne correspond pas à son extension.'], 422);
        $stored = bin2hex(random_bytes(16)) . '.' . $ext; if (!@move_uploaded_file($f['tmp_name'], ELearnController::fileDir() . '/' . $stored)) $this->json(['error' => 'Enregistrement impossible.'], 500);
        DB::insert('el_media', ['stored_name' => $stored, 'name' => mb_substr($name, 0, 190), 'mime' => self::TYPES[$ext], 'size' => (int)$f['size'], 'user_id' => Auth::id(), 'created_at' => now()]);
        $this->json(['url' => '/elearn/media/' . pathinfo($stored, PATHINFO_FILENAME), 'name' => $name, 'mime' => self::TYPES[$ext]]);
    }
    function serve(string $stored): void {
        if (!preg_match('/^[a-f0-9]{32}$/', $stored)) { $this->notFound(); return; } $m = DB::one('SELECT * FROM el_media WHERE stored_name LIKE ?', [$stored . '.%']); if (!$m) { $this->notFound(); return; }
        ELearnController::stream(['file_stored' => $m['stored_name'], 'file_mime' => $m['mime'], 'file_name' => $m['name']]);
    }
}
