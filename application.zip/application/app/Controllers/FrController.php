<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Fr, FrStats, FrChart, Voc};

/** Lot 60 — Franchises : synthèse réseau, référentiel des franchises (recherche, fiche, historique des affectations, alias). */
class FrController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    /** Listes de choix des filtres partagés. */
    static function opts(): array {
        $cat = DB::all('SELECT DISTINCT service, typology FROM fr_catalog WHERE active=1 ORDER BY service, typology');
        return ['zones' => Fr::zones(), 'franchises' => array_column(Fr::franchiseList(), 'name', 'id'), 'services' => array_values(array_unique(array_column($cat, 'service'))), 'typologies' => array_values(array_unique(array_column($cat, 'typology'))),
            'teams' => array_column(DB::all("SELECT DISTINCT team FROM fr_requests WHERE team IS NOT NULL AND team<>'' ORDER BY team"), 'team')];
    }
    /** Cible validée d'une mesure (null si absente ou non validée). */
    static function target(string $m): ?array { $t = DB::one('SELECT * FROM fr_targets WHERE measure=? AND franchise_id IS NULL AND zone IS NULL', [$m]); return $t ? $t + ['ok' => $t['validated_at'] !== null] : null; }
    static function fmt(string $code, ?float $v): string { if ($v === null) return '—'; $u = FrStats::M[$code][1]; return $u === '%' ? Fr::dec($v) . ' %' : ($u === 'h' ? Fr::dec($v) . ' h' : Fr::n($v)); }
    /** Carte KPI : valeur, date de référence, périmètre, effectif et états explicites. */
    static function kpi(string $code, array $f, string $from, string $to, ?string $href = null): string {
        $m = FrStats::M[$code]; $x = FrStats::value($code, $f, $from, $to); $t = self::target($code); $sub = [];
        if ($x['state'] === 'unavailable') $val = '<span class="fs-6 text-muted">Donnée indisponible</span>'; elseif ($x['state'] === 'na') $val = '<span class="fs-6 text-muted">Non calculable</span>'; else $val = '<span class="fs-3 fw-semibold">' . e(self::fmt($code, $x['v'])) . '</span>';
        if ($x['state'] === 'ok' && $m[1] === '%' && $x['den'] !== null) $sub[] = Fr::n($x['num']) . ' / ' . Fr::n($x['den']); elseif ($x['state'] === 'ok' && $m[2] === 'delay') $sub[] = 'sur ' . Fr::n($x['n']) . ' dossiers';
        $cov = FrStats::coverage($code); if ($x['state'] === 'ok' && $cov['to'] && $to > $cov['to'] && $m[2] !== 'stock') $sub[] = 'Période partielle : données jusqu\'au ' . d($cov['to']);
        $h = '<div class="col-6 col-lg-3"><div class="cardx h-100"><h3 class="h6 mb-1">' . e($m[0]) . '</h3>' . $val; if ($x['weak']) $h .= ' ' . badge('Base faible', 'warning');
        $ref = $m[2] === 'stock' ? ($x['cut'] ? 'au ' . d($x['cut']) : '') : d($from) . ' → ' . d($to); $h .= '<p class="small text-muted mb-1" title="' . e($m[4]) . '">' . e($m[3] . ' · ' . $ref) . '</p>';
        if ($sub) $h .= '<p class="small text-muted mb-1">' . e(implode(' · ', $sub)) . '</p>';
        if ($t && $x['v'] !== null && in_array($code, ['exec', 'sla', 'quality', 'nc', 'complete'], true)) { $gap = round($x['v'] - (float)$t['target'], 1); $ok = $t['direction'] === 'down' ? $gap <= 0 : $gap >= 0; $h .= '<p class="small mb-1">Objectif ' . e(Fr::dec($t['target'])) . ' % · ' . ($t['ok'] ? '<span class="text-' . ($ok ? 'success' : 'danger') . '">' . e(Fr::sgn($gap, 1)) . ' pt</span>' : '<span class="text-muted">objectif non validé</span>') . '</p>'; }
        if ($href) $h .= '<a class="small" href="' . e($href) . '">Ouvrir les dossiers</a>'; return $h . '</div></div>';
    }
    /** Rappel du périmètre et de la date de référence (affiché sur chaque vue et chaque export). */
    static function scopeLine(array $f): string {
        $o = []; $o[] = 'Période : ' . d($f['from']) . ' au ' . d($f['to']) . ' (inclus, heure locale Togo)'; $sp = FrStats::span($f['from'], $f['to']); $o[] = $sp['days'] . ' j calendaires · ' . $sp['work'] . ' j ouvrés' . (Fr::setting('fr.calendar_validated', '0') === '1' ? '' : ' (calendrier à valider)');
        $o[] = $f['zone'] ? 'Zone : ' . implode(', ', $f['zone']) . ($f['zmode'] === 'then' ? ' (périmètre de l\'époque)' : ' (périmètre actuel)') : 'Toutes zones'; $o[] = $f['fr'] ? count($f['fr']) . ' franchise(s) sélectionnée(s)' : 'Toutes franchises du périmètre';
        foreach (['service' => 'Service', 'typology' => 'Typologie', 'subtype' => 'Sous-typologie', 'priority' => 'Priorité', 'team' => 'Équipe'] as $k => $l) if ($f[$k] !== '') $o[] = $l . ' : ' . ($k === 'priority' ? Fr::PRIO[$f[$k]] : $f[$k]); if ($f['status'] !== '') $o[] = 'Statut : ' . Fr::ST[$f['status']];
        $cov = FrStats::coverage('received'); if ($cov['to']) $o[] = 'Données dossiers jusqu\'au ' . d($cov['to']);
        return '<p class="small text-muted mb-2"><i class="bi bi-funnel me-1"></i>' . e(implode(' · ', $o)) . '</p>';
    }

    // ───────────────────────── Synthèse réseau ─────────────────────────
    function dashboard(): void {
        if (!can('fr.view')) { if (can('fr.own')) redirect('fr/requests'); $this->forbidden(); return; }
        $cov = FrStats::coverage('received'); $end = $cov['to'] ?? date('Y-m-d'); $f = FrStats::filters($_GET, Fr::addDays($end, -29), $end); $ids = FrStats::ids($f, $f['to']);
        $grain = $f['grain'] === 'day' && Fr::daysBetween($f['from'], $f['to']) > 62 ? 'week' : $f['grain'];
        $per = FrStats::periods($f['from'], $f['to'], $grain); if (count($per) > 120) { $grain = 'month'; $per = FrStats::periods($f['from'], $f['to'], 'month'); }
        $labels = array_column($per, 'label'); $S = [];
        foreach (['received' => ['Entrées (demandes reçues)', FrChart::COL[0]], 'closed' => ['Sorties (demandes clôturées)', FrChart::COL[2]], 'stock' => ['Stock ouvert', FrChart::COL[1]]] as $c => [$n, $col]) { $s = FrStats::series($c, $f, $f['from'], $f['to'], $grain, $ids, true); $S[$c] = [['name' => $n, 'color' => $col, 'points' => $s['points']]]; }
        $rows = []; $fr = $ids === null ? Fr::franchiseList(true) : array_values(array_filter(Fr::franchiseList(true), fn($x) => in_array((int)$x['id'], $ids, true)));
        $late = FrStats::by('late', $f, $f['from'], $f['to'], 'fid', $ids, true); $stock = FrStats::by('stock', $f, $f['from'], $f['to'], 'fid', $ids, true); $recv = FrStats::by('received', $f, $f['from'], $f['to'], 'fid', $ids, true); $sla = FrStats::by('sla', $f, $f['from'], $f['to'], 'fid', $ids, true);
        foreach ($fr as $x) { $i = (int)$x['id']; $rows[] = ['f' => $x, 'late' => (int)($late[$i]['v'] ?? 0), 'stock' => (int)($stock[$i]['v'] ?? 0), 'recv' => (int)($recv[$i]['v'] ?? 0), 'sla' => $sla[$i] ?? null]; }
        usort($rows, fn($a, $b) => [$b['late'], $b['stock']] <=> [$a['late'], $a['stock']]); $rows = array_filter($rows, fn($r) => $r['stock'] || $r['recv'] || $r['late']);
        $this->view('fr/dashboard', ['title' => 'Synthèse réseau', 'f' => $f, 'o' => self::opts(), 'S' => $S, 'labels' => $labels, 'grain' => $grain, 'rows' => array_slice(array_values($rows), 0, 15), 'nrows' => count($rows), 'cov' => $cov, 'partial' => FrStats::span($f['from'], $f['to'])]);
    }

    // ───────────────────────── Franchises ─────────────────────────
    private function guardList(): void { if (!can('fr.view') && !can('fr.own') && !can('fr.handle')) { $this->forbidden(); exit; } }
    function index(): void {
        $this->guardList(); $q = trim((string)$this->in('q', '')); $zone = (string)$this->in('zone', ''); $act = (string)$this->in('active', ''); [$sc] = Fr::sqlScope('f.id'); $w = '1=1' . $sc; $p = [];
        if ($zone !== '') { $w .= ' AND f.zone=?'; $p[] = $zone; } if ($act !== '') { $w .= ' AND f.active=?'; $p[] = (int)$act; }
        $rows = $q !== '' ? array_column(Fr::search($q, 200), 'id') : null; if ($rows !== null) $w .= $rows ? ' AND f.id IN (' . implode(',', array_map('intval', $rows)) . ')' : ' AND 1=0';
        $list = DB::all("SELECT f.*, (SELECT COUNT(*) FROM fr_requests r WHERE r.franchise_id=f.id AND r.status IN ('new','assigned','in_progress','waiting')) open_n, (SELECT COUNT(*) FROM fr_requests r WHERE r.franchise_id=f.id AND r.status IN ('new','assigned','in_progress','waiting') AND r.due_at IS NOT NULL AND r.due_at<?) late_n FROM fr_franchises f WHERE $w ORDER BY f.name", array_merge([now()], $p));
        if ($this->in('export') === 'csv' && can('fr.export')) { csv_download('franchises_' . date('Ymd') . '.csv', ['ID CRM', 'Code métier', 'Code approuvé', 'Nom', 'Zone', 'Statut', 'Responsable', 'BO', 'Dossiers ouverts', 'Hors délai'], array_map(fn($r) => [$r['crm_id'], $r['code'], $r['code_ok'] ? 'oui' : 'non', $r['name'], $r['zone'], $r['active'] ? 'active' : 'inactive', $r['manager'], $r['bo_team'], $r['open_n'], $r['late_n']], $list)); }
        $this->view('fr/index', ['title' => 'Franchises', 'list' => $list, 'q' => $q, 'zone' => $zone, 'active' => $act, 'zones' => Fr::zones()]);
    }
    function suggest(): void { $this->guardList(); header('Content-Type: application/json; charset=utf-8'); echo json_encode(array_map(fn($r) => ['id' => (int)$r['id'], 'label' => $r['name'] . ($r['code'] ? ' · ' . $r['code'] : ''), 'zone' => $r['zone']], Fr::search((string)$this->in('q', ''), 12)), JSON_UNESCAPED_UNICODE); exit; }
    function show(string $id): void {
        $fr = Fr::franchise((int)$id); if (!$fr || !Fr::sees((int)$id)) { $this->notFound(); return; } if (!can('fr.view') && !can('fr.own')) { $this->forbidden(); return; } $fid = (int)$fr['id'];
        $cov = FrStats::coverage('received'); $end = $cov['to'] ?? date('Y-m-d'); $g = $_GET; unset($g['fr'], $g['zone']); $f = FrStats::filters($g, Fr::addDays($end, -29), $end); $f['fr'] = [$fid]; $grain = $f['grain'] === 'day' && Fr::daysBetween($f['from'], $f['to']) > 62 ? 'week' : $f['grain'];
        $per = FrStats::periods($f['from'], $f['to'], $grain); $labels = array_column($per, 'label'); $ids = [$fid]; $ser = [];
        foreach (['received' => ['Demandes reçues', FrChart::COL[0]], 'closed' => ['Demandes clôturées', FrChart::COL[2]], 'ops' => ['Opérations réalisées', FrChart::COL[1]]] as $c => [$n, $col]) $ser[] = ['name' => $n, 'color' => $col, 'points' => FrStats::series($c, $f, $f['from'], $f['to'], $grain, $ids, true)['points']];
        $svcs = array_column(DB::all('SELECT DISTINCT service FROM fr_catalog WHERE active=1 ORDER BY service'), 'service'); $stack = [];
        foreach ($svcs as $i => $s) { $fs = array_merge($f, ['service' => $s]); $pts = FrStats::series('ops', $fs, $f['from'], $f['to'], $grain, $ids, true)['points']; $stack[] = ['name' => $s, 'color' => FrChart::COL[$i % 8], 'values' => array_map(fn($p) => $p['v'], $pts)]; }
        $weeks = FrStats::periods($f['from'], $f['to'], 'week'); $heat = []; foreach ($svcs as $si => $s) { $fs = array_merge($f, ['service' => $s]); foreach ($weeks as $wi => $w) { $x = FrStats::value('received', $fs, $w['from'], $w['to'], $ids, true); $heat[$si][$wi] = $x['state'] === 'ok' ? ['v' => $x['v'], 'n' => (int)$x['v'], 'href' => url('fr/requests') . '?' . http_build_query(['fr' => $fid, 'service' => $s, 'from' => $w['from'], 'to' => $w['to']])] : null; } }
        $open = DB::all("SELECT r.*, u.name assignee FROM fr_requests r LEFT JOIN users u ON u.id=r.assignee_id WHERE r.franchise_id=? AND r.status IN ('new','assigned','in_progress','waiting') ORDER BY r.created_at LIMIT 10", [$fid]);
        $opsBy = FrStats::by('ops', $f, $f['from'], $f['to'], 'service', $ids, true); $late = (int)DB::val("SELECT COUNT(*) FROM fr_requests WHERE franchise_id=? AND status IN ('new','assigned','in_progress','waiting') AND due_at IS NOT NULL AND due_at<?", [$fid, now()]); $alerts = [];
        if ($late) $alerts[] = [$late . ' dossier(s) ouvert(s) hors délai SLA', 'danger', url('fr/requests') . '?' . http_build_query(['fr' => $fid, 'overdue' => 1])]; if (!(int)$fr['code_ok']) $alerts[] = ['Code métier non approuvé : « Code franchise(BT) » conservé comme référence source', 'warning', null]; if (!(int)$fr['active']) $alerts[] = ['Franchise désactivée', 'secondary', null];
        $wait = (int)DB::val("SELECT COUNT(*) FROM fr_requests WHERE franchise_id=? AND status='waiting'", [$fid]); if ($wait) $alerts[] = [$wait . ' dossier(s) en attente d\'une action', 'info', url('fr/requests') . '?' . http_build_query(['fr' => $fid, 'status' => 'waiting'])];
        $this->view('fr/show', ['title' => $fr['name'], 'fr' => $fr, 'f' => $f, 'o' => self::opts(), 'labels' => $labels, 'ser' => $ser, 'stack' => $stack, 'svcs' => $svcs, 'weeks' => $weeks, 'heat' => $heat, 'open' => $open, 'opsBy' => $opsBy, 'alerts' => $alerts, 'grain' => $grain,
            'aliases' => DB::all('SELECT * FROM fr_aliases WHERE franchise_id=? ORDER BY kind, alias', [$fid]), 'hist' => DB::all('SELECT * FROM fr_assign WHERE franchise_id=? ORDER BY from_day DESC, id DESC', [$fid]), 'users' => DB::all('SELECT u.name, a.kind FROM fr_access a JOIN users u ON u.id=a.user_id WHERE a.franchise_id=?', [$fid])]);
    }
    function form(?string $id = null): void {
        $fr = $id ? Fr::franchise((int)$id) : null; if ($id && !$fr) { $this->notFound(); return; }
        $this->view('fr/form', ['title' => $fr ? 'Modifier la franchise' : 'Nouvelle franchise', 'fr' => $fr, 'zones' => Fr::zones()]);
    }
    function save(?string $id = null): void {
        $fr = $id ? Fr::franchise((int)$id) : null; if ($id && !$fr) { $this->notFound(); return; } $back = $id ? "fr/franchises/$id/edit" : 'fr/franchises/new';
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom officiel', 'req' => 1, 'max' => 190], 'code' => ['label' => 'Le code métier', 'max' => 40], 'zone' => ['label' => 'La zone', 'req' => 1, 'max' => 80], 'manager' => ['label' => 'Le responsable', 'max' => 150], 'bo_team' => ['label' => 'Le BO de rattachement', 'max' => 120],
            'phone' => ['label' => 'Le téléphone', 'max' => 40], 'email' => ['label' => 'L\'e-mail', 'email' => 1, 'max' => 190], 'address' => ['label' => 'L\'adresse', 'max' => 300], 'city' => ['label' => 'La ville', 'max' => 100], 'effective_from' => ['label' => 'La date d\'effet', 'date' => 1], 'effective_to' => ['label' => 'La date de fin', 'date' => 1], 'note' => ['label' => 'La note', 'max' => 600]], $_POST);
        $code = $d['code'] !== null ? strtoupper(preg_replace('/\s+/', '', $d['code'])) : null; if ($code !== null && DB::val('SELECT 1 FROM fr_franchises WHERE code=? AND id<>?', [$code, (int)($id ?: 0)])) $err['code'] = 'Ce code métier est déjà attribué à une autre franchise.';
        if (!empty($d['effective_from']) && !empty($d['effective_to']) && $d['effective_to'] < $d['effective_from']) $err['effective_to'] = 'La date de fin précède la date d\'effet.';
        $chg = $fr && (($fr['zone'] ?? '') !== ($d['zone'] ?? '') || ($fr['manager'] ?? '') !== ($d['manager'] ?? '') || ($fr['bo_team'] ?? '') !== ($d['bo_team'] ?? '')); $from = (string)$this->in('assign_from', date('Y-m-d')); $why = trim((string)$this->in('assign_reason', ''));
        if ($chg && !Fr::isDay($from)) $err['assign_from'] = 'Date d\'effet de la réaffectation invalide.'; if ($chg && $why === '') $err['assign_reason'] = 'Un motif de réaffectation est obligatoire (il est historisé).';
        if ($err) $this->back($err, $_POST, $back);
        $row = $d; $row['code'] = $code; $row['code_ok'] = $code !== null && !empty($_POST['code_ok']) ? 1 : 0; $row['active'] = !empty($_POST['active']) || !$fr ? 1 : 0; $row['updated_at'] = now(); unset($row['zone_x']);
        if ($fr) { $act = (int)$fr['active']; DB::update('fr_franchises', $row, 'id=?', [$fr['id']]); if ($chg) Fr::assignPeriod((int)$fr['id'], $d['zone'], $d['manager'], $d['bo_team'], $from, $why); Audit::log('fr.franchise.update', 'fr_franchises', $fr['id'], $fr, $row); if ($act !== (int)$row['active']) Audit::log($row['active'] ? 'fr.franchise.activate' : 'fr.franchise.deactivate', 'fr_franchises', $fr['id']); $nid = (int)$fr['id']; }
        else { $row['crm_id'] = Fr::nextCrmId(); $row['created_at'] = now(); $row['is_demo'] = 0; $nid = DB::insert('fr_franchises', $row); Fr::assignPeriod($nid, $d['zone'], $d['manager'], $d['bo_team'], $d['effective_from'] ?: date('Y-m-d'), 'Création de la franchise'); Audit::log('fr.franchise.create', 'fr_franchises', $nid, null, $row); }
        Fr::resetMap(); $this->go("fr/franchises/$nid", 'Franchise enregistrée.');
    }
    function toggle(string $id): void {
        $fr = Fr::franchise((int)$id); if (!$fr) { $this->notFound(); return; } $to = (int)$fr['active'] ? 0 : 1;
        if (!$to && (int)DB::val("SELECT COUNT(*) FROM fr_requests WHERE franchise_id=? AND status IN ('new','assigned','in_progress','waiting')", [$id])) $this->go("fr/franchises/$id", 'Désactivation refusée : des dossiers sont encore ouverts. Clôturez-les ou réaffectez-les d\'abord.', 'danger');
        DB::update('fr_franchises', ['active' => $to, 'updated_at' => now()], 'id=?', [$id]); Audit::log($to ? 'fr.franchise.activate' : 'fr.franchise.deactivate', 'fr_franchises', $id); $this->go("fr/franchises/$id", $to ? 'Franchise réactivée.' : 'Franchise désactivée : l\'historique est conservé.');
    }
    function aliasAdd(string $id): void {
        $fr = Fr::franchise((int)$id); if (!$fr) { $this->notFound(); return; } $a = trim((string)$this->in('alias', '')); $k = in_array($this->in('kind'), ['alias', 'bt', 'former'], true) ? (string)$this->in('kind') : 'alias';
        if ($a === '' || mb_strlen($a) > 190) $this->go("fr/franchises/$id", 'Alias vide ou trop long.', 'danger'); [$o, $why] = Fr::resolve($a); if ($o !== null && $o !== (int)$id || $why === 'ambiguous') $this->go("fr/franchises/$id", 'Cet alias désigne déjà une autre franchise.', 'danger');
        if (!DB::val('SELECT 1 FROM fr_aliases WHERE franchise_id=? AND alias=?', [$id, $a])) DB::insert('fr_aliases', ['franchise_id' => (int)$id, 'alias' => $a, 'kind' => $k, 'created_at' => now()]); Fr::resetMap(); $this->go("fr/franchises/$id", 'Alias ajouté.');
    }
    function aliasDel(string $id, string $aid): void { DB::exec('DELETE FROM fr_aliases WHERE id=? AND franchise_id=?', [$aid, $id]); Fr::resetMap(); $this->go("fr/franchises/$id", 'Alias supprimé.'); }
    function accessAdd(string $id): void {
        $u = (int)$this->in('user_id', 0); if (!DB::val('SELECT 1 FROM users WHERE id=?', [$u]) || !Fr::franchise((int)$id)) $this->go("fr/franchises/$id", 'Utilisateur ou franchise introuvable.', 'danger');
        if (!DB::val('SELECT 1 FROM fr_access WHERE user_id=? AND franchise_id=?', [$u, $id])) DB::insert('fr_access', ['user_id' => $u, 'kind' => 'franchise', 'franchise_id' => (int)$id, 'created_at' => now()]); Audit::log('fr.access.add', 'fr_access', $id, null, ['user' => $u]); $this->go("fr/franchises/$id", 'Accès accordé à cette franchise.');
    }
}
