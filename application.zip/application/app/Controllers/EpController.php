<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Ep};

/** Execution plan : chaque activité définit ses programmes et initiatives, puis renseigne l'avancement en fin de période. */
class EpController extends Controller {
    private function plan(string $id): ?array { return DB::one('SELECT * FROM ep_plans WHERE id=?', [(int)$id]); }
    function index(): void {
        $plans = DB::all('SELECT * FROM ep_plans ORDER BY start_date DESC, id DESC');
        foreach ($plans as &$p) { $a = Ep::byActivity((int)$p['id']); $p['n'] = array_sum(array_column($a, 'n')); $p['avg'] = $p['n'] ? (int)round(array_sum(array_column($a, 'sum')) / $p['n']) : 0; $p['acts'] = count($a);
            $p['late'] = array_sum(array_map(fn($x) => $x['st']['at_risk'] + $x['st']['delayed'], $a)); } unset($p);
        $this->view('ep/index', ['title' => 'Execution plan', 'plans' => $plans]);
    }
    function create(): void { $this->view('ep/plan_form', ['title' => 'Nouveau plan d\'exécution', 'plans' => DB::all('SELECT id, name FROM ep_plans ORDER BY start_date DESC')]); }
    function store(): void {
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'period_label' => ['label' => 'La période', 'req' => true, 'max' => 60], 'start_date' => ['label' => 'Le début', 'req' => true, 'date' => true], 'end_date' => ['label' => 'La fin', 'req' => true, 'date' => true], 'note' => ['label' => 'La note', 'max' => 2000]], $_POST);
        $r1 = (int)$this->in('remind1_days', 10); $r2 = (int)$this->in('remind2_days', 3);
        if ($r1 < 1 || $r1 > 90 || $r2 < 1 || $r2 > 90) $err['remind1_days'] = 'Les relances se règlent entre 1 et 90 jours avant le bilan.'; elseif ($r1 <= $r2) $err['remind1_days'] = 'La 1re relance doit précéder la 2e (plus de jours avant le bilan).';
        $d['remind1_days'] = $r1; $d['remind2_days'] = $r2; $d['remind_email'] = isset($_POST['remind_email']) ? 1 : 0;
        if (empty($err['end_date']) && empty($err['start_date']) && $d['end_date'] < $d['start_date']) $err['end_date'] = 'La fin doit être postérieure au début.';
        if ($err) $this->back($err, $_POST, 'ep/new');
        $id = DB::insert('ep_plans', $d + ['status' => 'open', 'created_by' => Auth::id(), 'created_at' => now()]);
        $src = (int)$this->in('copy_from', 0); $n = 0;
        if ($src && DB::val('SELECT 1 FROM ep_plans WHERE id=?', [$src])) foreach (DB::all('SELECT * FROM ep_programmes WHERE plan_id=? ORDER BY activity, sort_order, id', [$src]) as $p) {
            $np = DB::insert('ep_programmes', ['plan_id' => $id, 'activity' => $p['activity'], 'org_unit_id' => $p['org_unit_id'], 'name' => $p['name'], 'owner_employee_id' => $p['owner_employee_id'], 'owner_label' => $p['owner_label'], 'timeline' => $p['timeline'], 'status' => 'not_started', 'progress' => 0, 'sort_order' => $p['sort_order'], 'created_by' => Auth::id(), 'created_at' => now()]);
            foreach (DB::all('SELECT * FROM ep_initiatives WHERE programme_id=? ORDER BY sort_order, id', [(int)$p['id']]) as $i) {
                $ni = DB::insert('ep_initiatives', ['programme_id' => $np, 'label' => $i['label'], 'timeline' => $i['timeline'], 'status' => 'not_started', 'progress' => 0, 'owner_employee_id' => $i['owner_employee_id'], 'activity' => $i['activity'], 'sort_order' => $i['sort_order']]);
                foreach (DB::all('SELECT * FROM ep_subs WHERE initiative_id=? ORDER BY sort_order, id', [(int)$i['id']]) as $x) DB::insert('ep_subs', ['initiative_id' => $ni, 'label' => $x['label'], 'timeline' => $x['timeline'], 'status' => 'not_started', 'progress' => 0, 'sort_order' => $x['sort_order']]);
            }
            $n++;
        }
        Audit::log('create', 'ep_plans', $id, null, $d); flash('Plan créé' . ($n ? " : $n programme(s) repris, statuts remis à zéro." : '.')); redirect("ep/$id");
    }
    function show(string $id): void {
        $plan = $this->plan($id); if (!$plan) { $this->notFound(); return; }
        $act = trim((string)$this->in('activity', '')); $st = (string)$this->in('status', ''); $w = ['plan_id=?']; $p = [(int)$id];
        if ($act !== '') { $w[] = '(activity=? OR id IN (SELECT programme_id FROM ep_initiatives WHERE activity=?))'; array_push($p, $act, $act); } if (isset(Ep::ST[$st])) { $w[] = 'status=?'; $p[] = $st; }
        $progs = DB::all('SELECT * FROM ep_programmes WHERE ' . implode(' AND ', $w) . ' ORDER BY activity, sort_order, id', $p);
        $by = []; foreach ($progs as $r) { $r['inis'] = Ep::tree((int)$r['id']); $r['can'] = Ep::canEdit($r, $plan); $by[$r['activity']][] = $r; }
        $this->view('ep/show', ['title' => $plan['name'], 'plan' => $plan, 'by' => $by, 'sum' => Ep::byActivity((int)$id), 'act' => $act, 'status' => $st, 'nobody' => count(array_filter(DB::all('SELECT * FROM ep_programmes WHERE plan_id=?', [(int)$id]), fn($x) => !Ep::ownerUser($x) && !array_filter(DB::all('SELECT owner_employee_id FROM ep_initiatives WHERE programme_id=? AND owner_employee_id IS NOT NULL', [(int)$x['id']]), fn($i) => Ep::userOfEmployee((int)$i['owner_employee_id'])))), 'acts' => array_values(array_unique(array_merge(array_column(DB::all('SELECT DISTINCT activity FROM ep_programmes WHERE plan_id=?', [(int)$id]), 'activity'), array_column(DB::all('SELECT DISTINCT i.activity FROM ep_initiatives i JOIN ep_programmes p ON p.id=i.programme_id WHERE p.plan_id=? AND i.activity IS NOT NULL', [(int)$id]), 'activity'))))]);
    }
    function setStatus(string $id): void {
        $plan = $this->plan($id); if (!$plan) { $this->notFound(); return; }
        $to = $this->in('to') === 'closed' ? 'closed' : 'open'; DB::update('ep_plans', ['status' => $to], 'id=?', [(int)$id]); Audit::log('update', 'ep_plans', $id, $plan, ['status' => $to]);
        flash($to === 'closed' ? 'Plan clôturé : les avancements ne sont plus modifiables.' : 'Plan rouvert.'); redirect("ep/$id");
    }
    function deletePlan(string $id): void {
        $plan = $this->plan($id); if (!$plan) { $this->notFound(); return; }
        foreach (DB::all('SELECT id FROM ep_programmes WHERE plan_id=?', [(int)$id]) as $p) Ep::deleteProgramme((int)$p['id']);
        DB::exec('DELETE FROM ep_plans WHERE id=?', [(int)$id]); Audit::log('delete', 'ep_plans', $id, $plan); flash('Plan supprimé.'); redirect('ep');
    }
    // ---- programmes
    private function formData(array $plan, array $prog, array $inis, string $title, string $action): void {
        $this->view('ep/prog_form', ['title' => $title, 'plan' => $plan, 'prog' => $prog, 'inis' => $inis, 'action' => $action, 'acts' => Ep::activities(), 'emps' => DB::all("SELECT id, first_name, last_name, matricule FROM employees WHERE status='active' ORDER BY last_name, first_name")]);
    }
    function progNew(string $id): void {
        $plan = $this->plan($id); if (!$plan) { $this->notFound(); return; }
        if ($plan['status'] !== 'open') { flash('Plan clôturé.', 'warning'); redirect("ep/$id"); }
        $this->formData($plan, ['activity' => (string)$this->in('activity', ''), 'status' => 'not_started', 'progress' => 0, 'owner_employee_id' => Ep::myEmployee()], [], 'Nouveau programme', url("ep/$id/programmes"));
    }
    private function save(array $plan, ?array $old): void {
        $pid = $old ? (int)$old['id'] : 0; $back = $old ? "ep/programmes/$pid/edit" : 'ep/' . $plan['id'] . '/programmes/new';
        [$d, $err] = $this->validate(['activity' => ['label' => 'L\'activité', 'req' => true, 'max' => 150], 'name' => ['label' => 'Le programme', 'req' => true, 'max' => 200], 'owner_label' => ['label' => 'Le responsable', 'max' => 150], 'timeline' => ['label' => 'La timeline', 'max' => 100], 'comment' => ['label' => 'Le commentaire', 'max' => 2000]], $_POST);
        $oe = (int)$this->in('owner_employee_id', 0) ?: null; if ($oe && !DB::val('SELECT 1 FROM employees WHERE id=?', [$oe])) $err['owner_employee_id'] = 'Responsable inconnu.';
        $d['owner_employee_id'] = $oe; if ($err) $this->back($err, $_POST, $back);
        $in = []; foreach ((array)($_POST['ini'] ?? []) as $x) { if (!is_array($x) || count($in) >= 40) continue; $l = trim((string)($x['label'] ?? '')); if ($l === '') continue;
            $subs = []; foreach ((array)($x['subs'] ?? []) as $y) { if (!is_array($y) || count($subs) >= 40) continue; $sl = trim((string)($y['label'] ?? '')); if ($sl === '') continue; $subs[] = ['id' => (int)($y['id'] ?? 0), 'label' => mb_substr($sl, 0, 300), 'timeline' => mb_substr(trim((string)($y['timeline'] ?? '')), 0, 60)]; }
            $ow = (int)($x['owner'] ?? 0) ?: null; if ($ow && !DB::val('SELECT 1 FROM employees WHERE id=?', [$ow])) $ow = null;
            $in[] = ['id' => (int)($x['id'] ?? 0), 'label' => mb_substr($l, 0, 300), 'timeline' => mb_substr(trim((string)($x['timeline'] ?? '')), 0, 60), 'owner' => $ow, 'subs' => $subs]; }
        if ($old) { DB::update('ep_programmes', $d + ['updated_by' => Auth::id(), 'updated_at' => now()], 'id=?', [$pid]); }
        else { $pid = DB::insert('ep_programmes', $d + ['plan_id' => (int)$plan['id'], 'status' => 'not_started', 'progress' => 0, 'sort_order' => (int)DB::val('SELECT COALESCE(MAX(sort_order),0)+1 FROM ep_programmes WHERE plan_id=?', [(int)$plan['id']]), 'created_by' => Auth::id(), 'created_at' => now()]); }
        $keep = [];
        foreach ($in as $k => $r) {
            if ($r['id'] && DB::val('SELECT 1 FROM ep_initiatives WHERE id=? AND programme_id=?', [$r['id'], $pid])) { DB::update('ep_initiatives', ['label' => $r['label'], 'timeline' => $r['timeline'], 'owner_employee_id' => $r['owner'], 'activity' => Ep::activityOf($r['owner']) ?: null, 'sort_order' => $k], 'id=?', [$r['id']]); $iid = $r['id']; }
            else $iid = DB::insert('ep_initiatives', ['programme_id' => $pid, 'label' => $r['label'], 'timeline' => $r['timeline'], 'status' => 'not_started', 'progress' => 0, 'owner_employee_id' => $r['owner'], 'activity' => Ep::activityOf($r['owner']) ?: null, 'sort_order' => $k]);
            $keep[] = $iid; $ks = [];
            foreach ($r['subs'] as $j => $y) {
                if ($y['id'] && DB::val('SELECT 1 FROM ep_subs WHERE id=? AND initiative_id=?', [$y['id'], $iid])) { DB::update('ep_subs', ['label' => $y['label'], 'timeline' => $y['timeline'], 'sort_order' => $j], 'id=?', [$y['id']]); $ks[] = $y['id']; }
                else $ks[] = DB::insert('ep_subs', ['initiative_id' => $iid, 'label' => $y['label'], 'timeline' => $y['timeline'], 'status' => 'not_started', 'progress' => 0, 'sort_order' => $j, 'updated_at' => now()]);
            }
            foreach (DB::all('SELECT id FROM ep_subs WHERE initiative_id=?', [$iid]) as $z) if (!in_array((int)$z['id'], $ks, true)) DB::exec('DELETE FROM ep_subs WHERE id=?', [(int)$z['id']]);
            Ep::recalc($iid);
        }
        foreach (DB::all('SELECT id FROM ep_initiatives WHERE programme_id=?', [$pid]) as $x) if (!in_array((int)$x['id'], $keep, true)) { DB::exec('DELETE FROM ep_subs WHERE initiative_id=?', [(int)$x['id']]); DB::exec('DELETE FROM ep_initiatives WHERE id=?', [(int)$x['id']]); }
        Audit::log($old ? 'update' : 'create', 'ep_programmes', $pid, $old, $d); flash($old ? 'Programme enregistré.' : 'Programme créé.'); redirect('ep/' . $plan['id']);
    }
    function progStore(string $id): void {
        $plan = $this->plan($id); if (!$plan) { $this->notFound(); return; }
        if ($plan['status'] !== 'open') { flash('Plan clôturé.', 'warning'); redirect("ep/$id"); }
        $this->save($plan, null);
    }
    private function load(string $pid): ?array { $p = DB::one('SELECT * FROM ep_programmes WHERE id=?', [(int)$pid]); return $p ? [$p, DB::one('SELECT * FROM ep_plans WHERE id=?', [(int)$p['plan_id']])] : null; }
    function progEdit(string $pid): void {
        $l = $this->load($pid); if (!$l) { $this->notFound(); return; } [$p, $plan] = $l;
        if (!Ep::canEdit($p, $plan)) { $this->forbidden(); return; }
        $this->formData($plan, $p, Ep::tree((int)$pid), 'Modifier le programme', url("ep/programmes/$pid"));
    }
    function progUpdate(string $pid): void {
        $l = $this->load($pid); if (!$l) { $this->notFound(); return; } [$p, $plan] = $l;
        if (!Ep::canEdit($p, $plan)) { $this->forbidden(); return; }
        $this->save($plan, $p);
    }
    function progDelete(string $pid): void {
        $l = $this->load($pid); if (!$l) { $this->notFound(); return; } [$p, $plan] = $l;
        if (!Ep::canEdit($p, $plan)) { $this->forbidden(); return; }
        Ep::deleteProgramme((int)$pid);
        Audit::log('delete', 'ep_programmes', $pid, $p); flash('Programme supprimé.'); redirect('ep/' . $plan['id']);
    }
    function progShow(string $pid): void {
        $l = $this->load($pid); if (!$l) { $this->notFound(); return; } [$p, $plan] = $l;
        $this->view('ep/prog_show', ['title' => $p['name'], 'p' => $p, 'plan' => $plan, 'inis' => Ep::tree((int)$pid),
            'hist' => DB::all('SELECT u.*, us.name uname FROM ep_updates u LEFT JOIN users us ON us.id=u.user_id WHERE u.programme_id=? ORDER BY u.id DESC', [(int)$pid]), 'can' => Ep::canEdit($p, $plan), 'suggest' => Ep::suggest((int)$pid)]);
    }
    // ---- avancement de fin de période
    function updateForm(string $id): void {
        $plan = $this->plan($id); if (!$plan) { $this->notFound(); return; }
        $progs = []; $me = Ep::myEmployee();
        foreach (DB::all('SELECT * FROM ep_programmes WHERE plan_id=? ORDER BY activity, sort_order, id', [(int)$id]) as $r) {
            $full = Ep::canEdit($r, $plan); $tree = Ep::tree((int)$r['id']);
            if (!$full) { $tree = array_values(array_filter($tree, fn($i) => Ep::canEditInitiative($i, $r, $plan))); if (!$tree) continue; }
            $r['inis'] = $tree; $r['full'] = $full; $r['suggest'] = Ep::suggest((int)$r['id']); $progs[] = $r;
        }
        $this->view('ep/update', ['title' => 'Avancement de fin de période', 'plan' => $plan, 'progs' => $progs]);
    }
    function updateSave(string $id): void {
        $plan = $this->plan($id); if (!$plan) { $this->notFound(); return; }
        if ($plan['status'] !== 'open') { flash('Plan clôturé : saisie impossible.', 'warning'); redirect("ep/$id"); }
        $A = fn($k) => (array)($_POST[$k] ?? []); $saved = []; $errs = []; $touched = []; $rec = [];
        $mine = function (int $pid) use ($plan, $id) { $p = DB::one('SELECT * FROM ep_programmes WHERE id=? AND plan_id=?', [$pid, (int)$id]); return $p && Ep::canEdit($p, $plan) ? $p : null; };
        $mineIni = function (array $ini) use ($plan, $id) { $p = DB::one('SELECT * FROM ep_programmes WHERE id=? AND plan_id=?', [(int)$ini['programme_id'], (int)$id]); return $p && Ep::canEditInitiative($ini, $p, $plan); };
        // sous-initiatives
        foreach ($A('ss') as $sid => $s) {
            $x = DB::one('SELECT s.*, i.programme_id, i.owner_employee_id FROM ep_subs s JOIN ep_initiatives i ON i.id=s.initiative_id WHERE s.id=?', [(int)$sid]); if (!$x || !$mineIni($x)) continue;
            [$st, $pr] = Ep::normalize((string)$s, $A('sp')[$sid] ?? null, (int)$x['progress']); $cm = array_key_exists($sid, $A('sc')) ? mb_substr(trim((string)$A('sc')[$sid]), 0, 2000) : (string)$x['comment'];
            if ($st !== $x['status'] || $pr !== (int)$x['progress'] || $cm !== (string)$x['comment']) { DB::update('ep_subs', ['status' => $st, 'progress' => $pr, 'comment' => $cm, 'updated_at' => now()], 'id=?', [(int)$sid]); DB::update('ep_initiatives', ['updated_at' => now()], 'id=?', [(int)$x['initiative_id']]); $touched[(int)$x['programme_id']] = true; }
            $rec[(int)$x['initiative_id']] = true;
        }
        // initiatives sans sous-initiative (saisie directe)
        foreach ($A('is') as $iid => $s) {
            $x = DB::one('SELECT * FROM ep_initiatives WHERE id=?', [(int)$iid]); if (!$x || !$mineIni($x) || DB::val('SELECT 1 FROM ep_subs WHERE initiative_id=?', [(int)$iid])) continue;
            [$st, $pr] = Ep::normalize((string)$s, $A('ip')[$iid] ?? null, (int)$x['progress']); $cm = array_key_exists($iid, $A('ic')) ? mb_substr(trim((string)$A('ic')[$iid]), 0, 2000) : (string)$x['comment'];
            if ($st !== $x['status'] || $pr !== (int)$x['progress'] || $cm !== (string)$x['comment']) { DB::update('ep_initiatives', ['status' => $st, 'progress' => $pr, 'comment' => $cm, 'updated_at' => now()], 'id=?', [(int)$iid]); $touched[(int)$x['programme_id']] = true; }
        }
        foreach (array_keys($rec) as $iid) { $before = DB::one('SELECT status, progress FROM ep_initiatives WHERE id=?', [$iid]); Ep::recalc($iid); }
        // programmes
        foreach ($A('st') as $pid => $s) {
            $p = $mine((int)$pid); if (!$p) continue;
            $s = (string)$s; $v = $A('pr')[$pid] ?? $p['progress']; $c = array_key_exists($pid, $A('cm')) ? mb_substr(trim((string)$A('cm')[$pid]), 0, 2000) : (string)$p['comment'];
            if (!isset(Ep::ST[$s]) || !is_numeric($v) || $v < 0 || $v > 100) { $errs[] = $p['name'] . ' : statut ou taux invalide.'; continue; }
            $v = (int)$v; if ($s === 'done' && $v !== 100) { $errs[] = $p['name'] . ' : un programme terminé doit être à 100 %.'; continue; }
            if ($s !== $p['status'] || $v !== (int)$p['progress'] || $c !== (string)$p['comment']) { DB::update('ep_programmes', ['status' => $s, 'progress' => $v, 'comment' => $c, 'updated_by' => Auth::id(), 'updated_at' => now()], 'id=?', [(int)$pid]); $touched[(int)$pid] = true; }
        }
        foreach (array_keys($touched) as $pid) {
            $p = DB::one('SELECT * FROM ep_programmes WHERE id=?', [$pid]); if (Ep::canEdit($p, $plan) && (!$p['updated_at'] || substr((string)$p['updated_at'], 0, 10) !== date('Y-m-d'))) DB::update('ep_programmes', ['updated_by' => Auth::id(), 'updated_at' => now()], 'id=?', [$pid]);
            DB::insert('ep_updates', ['programme_id' => $pid, 'period' => $plan['period_label'], 'status' => $p['status'], 'progress' => (int)$p['progress'], 'comment' => $p['comment'], 'detail' => Ep::snapshot($pid), 'user_id' => Auth::id(), 'created_at' => now()]); $saved[] = $pid;
        }
        Audit::log('update', 'ep_plans', $id, null, ['avancements' => count($saved)]);
        if ($errs) flash(implode(' ', $errs), 'danger'); flash(count($saved) . ' avancement(s) enregistré(s).', $errs ? 'warning' : 'success'); redirect($errs ? "ep/$id/update" : "ep/$id");
    }
    // ---- rapport
    function report(string $id): void {
        $plan = $this->plan($id); if (!$plan) { $this->notFound(); return; }
        $act = trim((string)$this->in('activity', '')); $w = 'plan_id=?'; $p = [(int)$id]; if ($act !== '') { $w .= ' AND (activity=? OR id IN (SELECT programme_id FROM ep_initiatives WHERE activity=?))'; array_push($p, $act, $act); }
        $by = []; foreach (DB::all("SELECT * FROM ep_programmes WHERE $w ORDER BY activity, sort_order, id", $p) as $r) { $r['inis'] = Ep::tree((int)$r['id']); $by[$r['activity']][] = $r; }
        $this->view('ep/report', ['title' => 'Execution plan — ' . $plan['period_label'], 'plan' => $plan, 'by' => $by, 'sum' => Ep::byActivity((int)$id), 'act' => $act, 'acts' => array_values(array_unique(array_merge(array_column(DB::all('SELECT DISTINCT activity FROM ep_programmes WHERE plan_id=?', [(int)$id]), 'activity'), array_column(DB::all('SELECT DISTINCT i.activity FROM ep_initiatives i JOIN ep_programmes p ON p.id=i.programme_id WHERE p.plan_id=? AND i.activity IS NOT NULL', [(int)$id]), 'activity')))), 'edit' => can('ep.manage')], 'layout/public');
    }
}
