<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Sys, Audit, Auth};
/** Console d'exploitation : santé, tâches planifiées, sauvegardes, comptes verrouillés, conservation, journal d'erreurs. */
class SysController extends Controller {
    function index(): void {
        $h = Sys::health(); $this->view('admin/system/index', ['title' => 'Santé du système', 'tab' => 'index', 'health' => $h, 'worst' => Sys::worst($h), 'jobs' => Sys::jobs()]);
    }
    function backups(): void { $this->view('admin/system/backups', ['title' => 'Sauvegardes', 'tab' => 'backups', 'rows' => Sys::backups(), 'keep' => max(1, (int)setting('sys.backup_keep', 7)), 'gz' => function_exists('gzopen')]); }
    function createBackup(): void {
        try { $f = Sys::backup(); $p = Sys::prune((int)setting('sys.backup_keep', 7)); Audit::log('create', 'backup', null, null, ['file' => $f]); flash("Sauvegarde $f créée" . ($p ? " ($p ancienne(s) supprimée(s))" : '') . '.'); }
        catch (\Throwable $e) { flash('Sauvegarde impossible : ' . $e->getMessage(), 'danger'); }
        redirect('admin/system/backups');
    }
    function download(string $name): void {
        if (!Sys::validName($name) || !is_file(Sys::path($name))) { $this->notFound(); return; }
        Audit::log('export', 'backup', null, null, ['file' => $name]);
        header('Content-Type: application/gzip'); header('Content-Disposition: attachment; filename="' . $name . '.jsonl.gz"'); header('Content-Length: ' . filesize(Sys::path($name))); header('X-Content-Type-Options: nosniff'); readfile(Sys::path($name)); exit;
    }
    function deleteBackup(string $name): void {
        if (!Sys::validName($name) || !is_file(Sys::path($name))) { $this->notFound(); return; }
        @unlink(Sys::path($name)); Audit::log('delete', 'backup', null, null, ['file' => $name]); flash('Sauvegarde supprimée.'); redirect('admin/system/backups');
    }
    function security(): void {
        $this->view('admin/system/security', ['title' => 'Comptes et sessions', 'tab' => 'security',
            'locked' => DB::all('SELECT id, name, email, locked_until, failed_attempts FROM users WHERE locked_until>? ORDER BY locked_until DESC', [now()]),
            'fails' => DB::all('SELECT email, COUNT(*) n, MAX(created_at) last, MAX(ip) ip FROM login_attempts WHERE success=0 AND created_at>=? GROUP BY email ORDER BY n DESC, last DESC LIMIT 20', [date('Y-m-d H:i:s', strtotime('-24 hours'))])]);
    }
    function unlock(string $id): void {
        $u = DB::one('SELECT id, name FROM users WHERE id=?', [(int)$id]); if (!$u) { $this->notFound(); return; }
        DB::update('users', ['locked_until' => null, 'failed_attempts' => 0], 'id=?', [(int)$id]); Audit::log('unlock', 'user', $id); flash('Compte déverrouillé : ' . $u['name'] . '.'); redirect('admin/system/security');
    }
    function killSessions(): void { $n = Sys::killSessions(); Audit::log('kill_sessions', 'system', null, null, ['sessions' => $n]); flash("$n session(s) fermée(s) ; la vôtre est conservée."); redirect('admin/system/security'); }
    function retention(): void { $this->view('admin/system/retention', ['title' => 'Conservation des données', 'tab' => 'retention', 'rows' => Sys::purgeable(), 'months' => (int)setting('activity.retention_months', 12)]); }
    function purge(): void { $r = Sys::purge(); Audit::log('purge', 'system', null, null, $r); flash(array_sum($r) . ' ligne(s) supprimée(s).'); redirect('admin/system/retention'); }
    function logs(): void { $this->view('admin/system/logs', ['title' => 'Journal d\'erreurs', 'tab' => 'logs', 'lines' => array_reverse(Sys::logTail(100)), 'size' => Sys::size(Sys::logSize())]); }
    function clearLogs(): void {
        $f = Sys::logFile(); if (is_file($f)) { @rename($f, $f . '.' . date('Ymd-His')); foreach (array_slice(array_reverse(glob($f . '.*') ?: []), 5) as $old) @unlink($old); }
        Audit::log('archive', 'error_log'); flash('Journal archivé (les 5 derniers archives sont conservés).'); redirect('admin/system/logs');
    }
    /** Point de contrôle pour supervision : 200 si la base répond, sans détail. */
    function health(): void {
        header('Content-Type: text/plain; charset=utf-8'); header('Cache-Control: no-store');
        try { DB::val('SELECT 1'); echo "ok\n"; } catch (\Throwable $e) { http_response_code(503); echo "ko\n"; } exit;
    }
}
