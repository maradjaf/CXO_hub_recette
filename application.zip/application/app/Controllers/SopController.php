<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Kb, Sop};
class SopController extends Controller {
    private function cats(): array { return DB::all('SELECT * FROM kb_categories ORDER BY sort_order, name'); }
    private function canEdit(array $s): bool { return can('kb.manage') || (can('kb.write') && (int)$s['author_id'] === Auth::id() && in_array($s['status'], ['draft', 'rejected'], true)); }
    private function readable(string $id): ?array {
        $s = DB::one('SELECT s.*, c.name category FROM kb_sops s LEFT JOIN kb_categories c ON c.id=s.category_id WHERE s.id=?', [(int)$id]); if (!$s) return null;
        if ($s['status'] === 'published') return ($s['internal'] && !Kb::canInternal()) ? null : $s;
        return (can('kb.manage') || (can('kb.write') && (int)$s['author_id'] === Auth::id())) ? $s : null;
    }
    // =============== Lecture ===============
    function library(): void {
        $q = trim((string)$this->in('q', '')); $cat = (int)$this->in('cat', 0) ?: null; $uid = (int)Auth::id();
        if ($q !== '') $rows = Sop::search($q, 60, $cat);
        else $rows = DB::all('SELECT a.id, a.ref, a.title, a.summary, a.risk_level, a.version, c.name category FROM kb_sops a LEFT JOIN kb_categories c ON c.id=a.category_id WHERE ' . Sop::visibleSql() . ($cat ? ' AND a.category_id=?' : '') . ' ORDER BY c.sort_order, c.name, a.title', $cat ? [$cat] : []);
        $pend = array_column(array_filter(Sop::pendingReads(), fn($p) => $p['kind'] === 'sop'), 'id');
        $this->view('kb/sop_library', ['title' => 'Modes opératoires', 'rows' => $rows, 'q' => $q, 'cat' => $cat, 'cats' => $this->cats(), 'pend' => $pend]);
    }
    function mine(): void { $this->view('kb/sop_mine', ['title' => 'À lire', 'rows' => Sop::pendingReads()]); }
    function show(string $id): void {
        $s = $this->readable($id); if (!$s) { $this->notFound(); return; }
        if ($s['status'] === 'published' && empty($_SESSION['_sopv'][$s['id']])) { DB::exec('UPDATE kb_sops SET views=views+1 WHERE id=?', [(int)$s['id']]); $_SESSION['_sopv'][$s['id']] = 1; }
        $steps = Sop::steps((int)$id); $uid = (int)Auth::id();
        $this->view('kb/sop_show', ['title' => $s['ref'] . ' · ' . $s['title'], 's' => $s, 'steps' => $steps, 'mins' => Sop::duration($s, $steps), 'acked' => Sop::acked('sop', (int)$id, (int)$s['version'], $uid), 'canEdit' => $this->canEdit($s),
            'owner' => $s['owner_id'] ? DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [(int)$s['owner_id']]) : null, 'team' => $s['team_id'] ? DB::val('SELECT name FROM teams WHERE id=?', [(int)$s['team_id']]) : null,
            'arts' => array_column(DB::all('SELECT id, title FROM kb_articles WHERE id IN (SELECT article_id FROM kb_sop_steps WHERE sop_id=? AND article_id IS NOT NULL)', [(int)$id]), 'title', 'id'),
            'nread' => can('kb.manage') ? (int)DB::val("SELECT COUNT(*) FROM kb_acks WHERE kind='sop' AND item_id=? AND version=?", [(int)$id, (int)$s['version']]) : null]);
    }
    function ack(string $id): void {
        $s = $this->readable($id); if (!$s || $s['status'] !== 'published') { $this->notFound(); return; }
        Sop::ack('sop', (int)$id, (int)$s['version'], (int)Auth::id()); flash('Lecture enregistrée : merci.'); redirect("kb/sops/$id");
    }
    // =============== Gestion ===============
    function manage(): void {
        $st = (string)$this->in('status', ''); $q = trim((string)$this->in('q', '')); $w = ['1=1']; $p = [];
        if (!can('kb.manage')) { $w[] = "(s.author_id=? OR s.status='published')"; $p[] = Auth::id(); }
        if ($st !== '' && isset(Kb::ST[$st])) { $w[] = 's.status=?'; $p[] = $st; }
        if ($q !== '') { $w[] = '(s.title LIKE ? OR s.ref LIKE ?)'; array_push($p, "%$q%", "%$q%"); }
        if ($this->in('stale') === '1') { $w[] = "s.status='published' AND s.review_due IS NOT NULL AND s.review_due<?"; $p[] = date('Y-m-d'); }
        $rows = DB::all('SELECT s.*, c.name category, (SELECT COUNT(*) FROM kb_acks k WHERE k.kind=\'sop\' AND k.item_id=s.id AND k.version=s.version) nread FROM kb_sops s LEFT JOIN kb_categories c ON c.id=s.category_id WHERE ' . implode(' AND ', $w) . ' ORDER BY s.updated_at DESC, s.id DESC LIMIT 300', $p);
        $this->view('kb/sop_manage', ['title' => 'Gérer les modes opératoires', 'rows' => $rows, 'st' => $st, 'q' => $q, 'pending' => can('kb.manage') ? (int)DB::val("SELECT COUNT(*) FROM kb_sops WHERE status='pending'") : 0]);
    }
    private function form(?array $s, array $steps): void {
        $this->view('kb/sop_form', ['title' => $s ? 'Modifier ' . $s['ref'] : 'Nouveau mode opératoire', 's' => $s, 'steps' => $steps, 'cats' => $this->cats(), 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'),
            'emps' => DB::all("SELECT id, first_name, last_name FROM employees WHERE status<>'left' ORDER BY last_name, first_name"), 'arts' => DB::all("SELECT id, title FROM kb_articles WHERE status='published' ORDER BY title LIMIT 300"),
            'versions' => $s ? DB::all('SELECT version, user_name, note, created_at FROM kb_sop_versions WHERE sop_id=? ORDER BY version DESC', [(int)$s['id']]) : []]);
    }
    function create(): void { $this->form(null, [['title' => '', 'instruction' => '']]); }
    function edit(string $id): void { $s = DB::one('SELECT * FROM kb_sops WHERE id=?', [(int)$id]); if (!$s || !$this->canEdit($s)) { $this->forbidden(); return; } $this->form($s, Sop::steps((int)$id) ?: [['title' => '', 'instruction' => '']]); }
    private function data(): array {
        [$d, $err] = $this->validate(['title' => ['label' => 'Le titre', 'req' => true, 'max' => 200], 'summary' => ['label' => 'Le résumé', 'max' => 300], 'objective' => ['label' => 'L\'objectif', 'max' => 3000], 'scope' => ['label' => 'Le périmètre', 'max' => 3000], 'prerequisites' => ['label' => 'Les prérequis', 'max' => 3000], 'tools' => ['label' => 'Les outils', 'max' => 300], 'tags' => ['label' => 'Les étiquettes', 'max' => 200], 'review_due' => ['label' => 'La date de révision', 'date' => true]], $_POST);
        $cat = (int)$this->in('category_id', 0); $d['category_id'] = $cat && DB::val('SELECT 1 FROM kb_categories WHERE id=?', [$cat]) ? $cat : null;
        $tm = (int)$this->in('team_id', 0); $d['team_id'] = $tm && DB::val('SELECT 1 FROM teams WHERE id=?', [$tm]) ? $tm : null;
        $ow = (int)$this->in('owner_id', 0); $d['owner_id'] = $ow && DB::val('SELECT 1 FROM employees WHERE id=?', [$ow]) ? $ow : null;
        $em = trim((string)$this->in('estimated_min', '')); if ($em !== '' && (!ctype_digit($em) || (int)$em > 1440)) $err['estimated_min'] = 'Durée estimée invalide (minutes).'; $d['estimated_min'] = $em !== '' ? (int)$em : null;
        $d['risk_level'] = isset(Sop::RISK[(string)$this->in('risk_level', 'normal')]) ? (string)$this->in('risk_level', 'normal') : 'normal';
        $d['mandatory'] = $this->in('mandatory') ? 1 : 0; $d['internal'] = $this->in('internal') ? 1 : 0; $d['updated_at'] = now();
        return [$d, $err];
    }
    function store(): void {
        [$d, $err] = $this->data(); [$steps, $e2] = Sop::readSteps(); if ($e2) $err['steps'] = $e2;
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); $_SESSION['_old'] = $_POST; redirect('kb/sops/new'); }
        $due = $d['review_due']; unset($d['review_due']);
        $id = DB::insert('kb_sops', $d + ['ref' => Sop::nextRef(), 'version' => 1, 'status' => 'draft', 'author_id' => Auth::id(), 'review_due' => $due, 'created_at' => now()]);
        Sop::replaceSteps($id, $steps); Sop::snapshot($id, 'Création'); Audit::log('create', 'kb_sop', $id, null, ['title' => $d['title']]);
        flash('Brouillon enregistré. Soumettez-le à la relecture quand il est prêt.'); redirect("kb/sops/$id");
    }
    function update(string $id): void {
        $s = DB::one('SELECT * FROM kb_sops WHERE id=?', [(int)$id]); if (!$s || !$this->canEdit($s)) { $this->forbidden(); return; }
        [$d, $err] = $this->data(); [$steps, $e2] = Sop::readSteps(); if ($e2) $err['steps'] = $e2;
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("kb/sops/$id/edit"); }
        if ($s['status'] === 'rejected') $d['status'] = 'draft';
        if ($s['status'] === 'published') { if ($this->in('new_version') === '1') { $d['version'] = (int)$s['version'] + 1; $d['published_at'] = now(); $d['review_due'] = $d['review_due'] ?: date('Y-m-d', strtotime('+' . Sop::months() . ' months')); $d['review_notified_at'] = null; } }
        if (!$d['review_due']) unset($d['review_due']);
        DB::update('kb_sops', $d, 'id=?', [(int)$id]); Sop::replaceSteps((int)$id, $steps);
        Sop::snapshot((int)$id, trim((string)$this->in('note', '')) ?: ($this->in('new_version') === '1' ? 'Nouvelle version' : 'Modification'));
        Audit::log('update', 'kb_sop', $id, ['title' => $s['title'], 'version' => $s['version']], ['title' => $d['title'], 'version' => $d['version'] ?? $s['version']]);
        if (!empty($d['version']) && $d['mandatory']) Notifier::toPermission('kb.read', 'Mode opératoire mis à jour : à relire', $s['ref'] . ' ' . $d['title'] . ' (version ' . $d['version'] . ')', '/kb/sops/' . $id);
        flash('Mode opératoire enregistré' . (!empty($d['version']) ? ' (version ' . $d['version'] . ').' : '.')); redirect("kb/sops/$id");
    }
    function status(string $id): void {
        $s = DB::one('SELECT * FROM kb_sops WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; }
        $act = (string)$this->in('action'); $mgr = can('kb.manage'); $own = can('kb.write') && (int)$s['author_id'] === Auth::id(); $u = ['updated_at' => now()]; $note = trim((string)$this->in('note', ''));
        if ($act === 'submit' && ($own || $mgr) && in_array($s['status'], ['draft', 'rejected'], true)) {
            if (!DB::val('SELECT 1 FROM kb_sop_steps WHERE sop_id=?', [(int)$id])) { flash('Ajoutez au moins une étape avant de soumettre.', 'danger'); redirect("kb/sops/$id"); }
            $u['status'] = 'pending'; $u['review_note'] = null; Notifier::toPermission('kb.manage', 'Mode opératoire à relire', $s['ref'] . ' ' . $s['title'], '/kb/sops/' . $id); $m = 'Soumis à la relecture.';
        } elseif ($act === 'publish' && $mgr && in_array($s['status'], ['pending', 'draft', 'rejected'], true)) {
            if ((int)$s['author_id'] === Auth::id() && $s['status'] === 'pending' && !can('admin.access') && (string)setting('kb.sop_four_eyes', '1') === '1') { flash('La relecture doit être faite par une autre personne que l\'auteur.', 'warning'); redirect("kb/sops/$id"); }
            if (!DB::val('SELECT 1 FROM kb_sop_steps WHERE sop_id=?', [(int)$id])) { flash('Ce mode opératoire n\'a aucune étape.', 'danger'); redirect("kb/sops/$id"); }
            $u += ['status' => 'published', 'reviewer_id' => Auth::id(), 'review_note' => null, 'published_at' => now(), 'review_due' => $s['review_due'] && $s['review_due'] > date('Y-m-d') ? $s['review_due'] : date('Y-m-d', strtotime('+' . Sop::months() . ' months')), 'review_notified_at' => null];
            if ($s['author_id'] && (int)$s['author_id'] !== Auth::id()) Notifier::send((int)$s['author_id'], 'Mode opératoire publié', $s['title'], '/kb/sops/' . $id);
            if ($s['mandatory']) Notifier::toPermission('kb.read', 'Lecture obligatoire : ' . $s['title'], $s['ref'] . ' — à lire et à confirmer', '/kb/sops/' . $id); $m = 'Publié.';
        } elseif ($act === 'reject' && $mgr && $s['status'] === 'pending') {
            if ($note === '') { flash('Indiquez ce qu\'il faut corriger.', 'danger'); redirect("kb/sops/$id"); }
            $u += ['status' => 'rejected', 'review_note' => mb_substr($note, 0, 500), 'reviewer_id' => Auth::id()]; if ($s['author_id']) Notifier::send((int)$s['author_id'], 'Mode opératoire à corriger', $s['title'] . ' : ' . mb_substr($note, 0, 100), '/kb/sops/' . $id . '/edit'); $m = 'Renvoyé à l\'auteur.';
        } elseif ($act === 'archive' && $mgr && $s['status'] !== 'archived') { $u['status'] = 'archived'; $m = 'Archivé (plus visible des lecteurs).'; }
        elseif ($act === 'unpublish' && $mgr && $s['status'] === 'published') { $u['status'] = 'draft'; $m = 'Dépublié (repassé en brouillon).'; }
        elseif ($act === 'restore' && $mgr && $s['status'] === 'archived') { $u['status'] = 'draft'; $m = 'Restauré en brouillon.'; }
        else { $this->forbidden(); return; }
        DB::update('kb_sops', $u, 'id=?', [(int)$id]); Audit::log($act, 'kb_sop', $id, ['status' => $s['status']], ['status' => $u['status']]); flash($m); redirect("kb/sops/$id");
    }
    function versions(string $id): void {
        $s = DB::one('SELECT * FROM kb_sops WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; }
        if (!can('kb.manage') && !(can('kb.write') && (int)$s['author_id'] === Auth::id())) { $this->forbidden(); return; }
        $vs = DB::all('SELECT * FROM kb_sop_versions WHERE sop_id=? ORDER BY version DESC', [(int)$id]); $sel = (int)$this->in('v', 0); $cur = $sel ? DB::one('SELECT * FROM kb_sop_versions WHERE sop_id=? AND version=?', [(int)$id, $sel]) : null;
        $this->view('kb/sop_versions', ['title' => 'Historique ' . $s['ref'], 's' => $s, 'vs' => $vs, 'cur' => $cur, 'snap' => $cur ? json_decode($cur['data'], true) : null]);
    }
    function restore(string $id, string $v): void {
        $s = DB::one('SELECT * FROM kb_sops WHERE id=?', [(int)$id]); if (!$s || !$this->canEdit($s)) { $this->forbidden(); return; }
        $x = DB::one('SELECT * FROM kb_sop_versions WHERE sop_id=? AND version=?', [(int)$id, (int)$v]); if (!$x) { $this->notFound(); return; }
        $data = json_decode($x['data'], true); $f = array_intersect_key($data['f'] ?? [], array_flip(Sop::FIELDS)); if (!$f) { $this->notFound(); return; }
        $ver = $s['status'] === 'published' ? (int)$s['version'] + 1 : (int)$s['version'];
        DB::update('kb_sops', $f + ['version' => $ver, 'updated_at' => now()], 'id=?', [(int)$id]); Sop::replaceSteps((int)$id, $data['steps'] ?? []); Sop::snapshot((int)$id, 'Restauration de la version ' . (int)$v);
        Audit::log('restore', 'kb_sop', $id, null, ['version' => (int)$v]); flash('Version ' . (int)$v . ' restaurée' . ($ver > (int)$s['version'] ? ' en version ' . $ver . '.' : '.')); redirect("kb/sops/$id");
    }
    function reads(string $id): void {
        $s = DB::one('SELECT * FROM kb_sops WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; }
        $aud = Sop::audience($s['team_id'] ? (int)$s['team_id'] : null);
        foreach ($aud as &$a) $a['read_at'] = DB::val("SELECT read_at FROM kb_acks WHERE kind='sop' AND item_id=? AND version=? AND user_id=?", [(int)$id, (int)$s['version'], (int)$a['user_id']]); unset($a);
        if ($this->in('export') === 'csv') csv_download('lecture_' . $s['ref'] . '.csv', ['Matricule', 'Nom', 'Prénom', 'Version', 'Lu le'], array_map(fn($a) => [$a['matricule'], $a['last_name'], $a['first_name'], $s['version'], $a['read_at']], $aud));
        $this->view('kb/sop_reads', ['title' => 'Lectures ' . $s['ref'], 's' => $s, 'aud' => $aud]);
    }
    function remind(string $id): void {
        $s = DB::one("SELECT * FROM kb_sops WHERE id=? AND status='published'", [(int)$id]); if (!$s) { $this->notFound(); return; }
        $n = 0; foreach (Sop::audience($s['team_id'] ? (int)$s['team_id'] : null) as $a) if (!Sop::acked('sop', (int)$id, (int)$s['version'], (int)$a['user_id'])) { Notifier::send((int)$a['user_id'], 'Lecture à confirmer', $s['ref'] . ' ' . $s['title'], '/kb/sops/' . $id); $n++; }
        flash("$n relance(s) envoyée(s)."); redirect("kb/sops/$id/reads");
    }
    function export(): void {
        csv_download('modes_operatoires.csv', ['Référence', 'Titre', 'Catégorie', 'Version', 'Statut', 'Risque', 'Lecture obligatoire', 'Étapes', 'Publié le', 'Revue avant le'],
            array_map(fn($r) => [$r['ref'], $r['title'], $r['category'], $r['version'], Kb::ST[$r['status']] ?? $r['status'], Sop::RISK[$r['risk_level']] ?? '', $r['mandatory'] ? 'Oui' : 'Non', $r['n'], $r['published_at'], $r['review_due']],
                DB::all('SELECT s.*, c.name category, (SELECT COUNT(*) FROM kb_sop_steps t WHERE t.sop_id=s.id) n FROM kb_sops s LEFT JOIN kb_categories c ON c.id=s.category_id ORDER BY s.ref')));
    }
}
