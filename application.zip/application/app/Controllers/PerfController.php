<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Perf, Notifier, Scope};

/** Performance 360° : cycles, évaluations à remplir, rapports anonymisés, plan de développement. */
class PerfController extends Controller {
    private function cycle(string $id): ?array { $c = DB::one('SELECT * FROM perf_cycles WHERE id=?', [(int)$id]); if (!$c) { $this->notFound(); return null; } return $c; }

    // ---------- gestion (RH) ----------
    function cycles(): void {
        $rows = DB::all('SELECT c.*, (SELECT COUNT(*) FROM perf_reviews r WHERE r.cycle_id=c.id) total, (SELECT COUNT(*) FROM perf_reviews r WHERE r.cycle_id=c.id AND r.status=\'done\') done FROM perf_cycles c ORDER BY c.id DESC');
        $this->view('perf/cycles', ['title' => 'Performance 360°', 'rows' => $rows]);
    }
    function cycleForm(): void { $this->view('perf/cycle_form', ['title' => 'Nouveau cycle 360°', 'teams' => DB::all('SELECT id, name FROM teams ORDER BY name'), 'comps' => (int)DB::val('SELECT COUNT(*) FROM perf_competencies WHERE active=1')]); }
    function cycleSave(): void {
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150]], $_POST); if ($err) $this->back($err, $_POST, 'perf/cycles/new');
        $d += ['start_date' => $this->in('start_date') ?: null, 'end_date' => $this->in('end_date') ?: null, 'deadline' => $this->in('deadline') ?: null, 'min_raters' => max(1, min(10, (int)$this->in('min_raters', 3))),
            'peers_max' => max(0, min(10, (int)$this->in('peers_max', 3))), 'team_id' => (int)$this->in('team_id') ?: null, 'status' => 'draft', 'created_by' => Auth::id(), 'created_at' => now()];
        $id = DB::insert('perf_cycles', $d); Audit::log('create', 'perf_cycle', $id, null, $d); flash('Cycle créé. Vérifiez les compétences puis ouvrez-le pour générer les évaluations.'); redirect("perf/cycles/$id");
    }
    function cycleShow(string $id): void {
        if (!($c = $this->cycle($id))) return; $st = (string)$this->in('status', ''); $q = trim((string)$this->in('q', ''));
        $w = ['r.cycle_id=?', 'r.role=\'self\'']; $p = [(int)$id]; if ($q !== '') { $w[] = '(e.first_name LIKE ? OR e.last_name LIKE ? OR e.matricule LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        [$sw, $sp] = Scope::sql('e.id'); $w[] = $sw; $p = array_merge($p, $sp);
        $emps = DB::all('SELECT e.id, e.first_name, e.last_name, e.matricule, (SELECT COUNT(*) FROM perf_reviews x WHERE x.cycle_id=r.cycle_id AND x.employee_id=e.id) total, (SELECT COUNT(*) FROM perf_reviews x WHERE x.cycle_id=r.cycle_id AND x.employee_id=e.id AND x.status=\'done\') done FROM perf_reviews r JOIN employees e ON e.id=r.employee_id WHERE ' . implode(' AND ', $w) . ' ORDER BY e.last_name, e.first_name LIMIT 500', $p);
        if ($st === 'incomplete') $emps = array_values(array_filter($emps, fn($e) => $e['done'] < $e['total']));
        $this->view('perf/cycle', ['title' => $c['name'], 'c' => $c, 'emps' => $emps, 'prog' => Perf::progress((int)$id), 'st' => $st, 'q' => $q, 'allEmps' => Scope::employees(), 'comps' => (int)DB::val('SELECT COUNT(*) FROM perf_competencies WHERE active=1')]);
    }
    function open(string $id): void {
        if (!($c = $this->cycle($id))) return; if ($c['status'] === 'closed') { flash('Ce cycle est clôturé.', 'warning'); redirect("perf/cycles/$id"); }
        if (!DB::val('SELECT 1 FROM perf_competencies WHERE active=1')) { flash('Définissez d\'abord au moins une compétence.', 'danger'); redirect('perf/competencies'); }
        $n = Perf::generate((int)$id); DB::update('perf_cycles', ['status' => 'open', 'opened_at' => $c['opened_at'] ?: now()], 'id=?', [(int)$id]); Audit::log('open', 'perf_cycle', $id, null, ['reviews' => $n]);
        $this->notifyRaters((int)$id, $c['name']); flash("Cycle ouvert : $n évaluation(s) générée(s) ; les évaluateurs sont prévenus."); redirect("perf/cycles/$id");
    }
    private function notifyRaters(int $cycle, string $name): void {
        foreach (DB::all("SELECT r.rater_id, COUNT(*) n FROM perf_reviews r WHERE r.cycle_id=? AND r.status='pending' GROUP BY r.rater_id", [$cycle]) as $r) {
            $uid = DB::val('SELECT id FROM users WHERE employee_id=? LIMIT 1', [(int)$r['rater_id']]); if ($uid) Notifier::send((int)$uid, 'Évaluation 360° : ' . $name, $r['n'] . ' évaluation(s) à remplir dans « Mes évaluations 360° ».', '/perf/mine');
        }
    }
    function close(string $id): void {
        if (!($c = $this->cycle($id))) return; if ($c['status'] !== 'open') { flash('Seul un cycle en cours peut être clôturé.', 'warning'); redirect("perf/cycles/$id"); }
        DB::update('perf_cycles', ['status' => 'closed', 'closed_at' => now()], 'id=?', [(int)$id]); Audit::log('close', 'perf_cycle', $id);
        foreach (DB::all("SELECT DISTINCT employee_id FROM perf_reviews WHERE cycle_id=? AND role='self'", [(int)$id]) as $r) {
            $uid = DB::val('SELECT id FROM users WHERE employee_id=? LIMIT 1', [(int)$r['employee_id']]); if ($uid) Notifier::send((int)$uid, 'Résultats 360° disponibles', 'Le cycle « ' . $c['name'] . ' » est clôturé : consultez votre rapport.', '/perf/mine');
        }
        flash('Cycle clôturé ; les collaborateurs et leurs responsables peuvent consulter les rapports.'); redirect("perf/cycles/$id");
    }
    function remind(string $id): void { if (!($c = $this->cycle($id))) return; if ($c['status'] !== 'open') { redirect("perf/cycles/$id"); } $this->notifyRaters((int)$id, $c['name']); flash('Rappel envoyé aux évaluateurs qui ont encore des évaluations à remplir.'); redirect("perf/cycles/$id"); }
    function delete(string $id): void {
        if (!($c = $this->cycle($id))) return; if ($c['status'] !== 'draft') { flash('Seul un cycle en brouillon peut être supprimé.', 'warning'); redirect("perf/cycles/$id"); }
        DB::exec('DELETE FROM perf_reviews WHERE cycle_id=?', [(int)$id]); DB::exec('DELETE FROM perf_cycles WHERE id=?', [(int)$id]); Audit::log('delete', 'perf_cycle', $id, $c); flash('Cycle supprimé.'); redirect('perf');
    }
    /** Ajoute un évaluateur (pair, responsable ou collaborateur) sur un collaborateur. */
    function addRater(string $id): void {
        if (!($c = $this->cycle($id))) return; $emp = (int)$this->in('employee_id'); $rater = (int)$this->in('rater_id'); $role = (string)$this->in('role', 'peer');
        if ($c['status'] === 'closed' || !isset(Perf::ROLE[$role]) || $role === 'self' || !$emp || !$rater || $emp === $rater || !Scope::allows($emp) || !DB::val('SELECT 1 FROM employees WHERE id=?', [$emp]) || !DB::val('SELECT 1 FROM employees WHERE id=?', [$rater])) { flash('Évaluateur invalide (deux collaborateurs différents, cycle non clôturé).', 'danger'); redirect("perf/cycles/$id"); }
        if (DB::val('SELECT 1 FROM perf_reviews WHERE cycle_id=? AND employee_id=? AND rater_id=? AND role=?', [(int)$id, $emp, $rater, $role])) { flash('Cet évaluateur est déjà affecté.', 'warning'); redirect("perf/cycles/$id"); }
        DB::insert('perf_reviews', ['cycle_id' => (int)$id, 'employee_id' => $emp, 'rater_id' => $rater, 'role' => $role, 'status' => 'pending', 'created_at' => now()]); Audit::log('add_rater', 'perf_cycle', $id, null, compact('emp', 'rater', 'role'));
        flash('Évaluateur ajouté.'); redirect("perf/cycles/$id");
    }
    function removeReview(string $id): void {
        $r = DB::one('SELECT * FROM perf_reviews WHERE id=?', [(int)$id]); if (!$r || !Scope::allows((int)$r['employee_id'])) { $this->notFound(); return; }
        if ($r['status'] !== 'pending' || $r['role'] === 'self') { flash('Seule une évaluation en attente (hors auto-évaluation) peut être retirée.', 'warning'); redirect('perf/cycles/' . $r['cycle_id']); }
        DB::exec('DELETE FROM perf_reviews WHERE id=?', [(int)$id]); Audit::log('remove_rater', 'perf_review', $id, $r); flash('Évaluateur retiré.'); redirect('perf/cycles/' . $r['cycle_id']);
    }
    function export(string $id): void {
        if (!($c = $this->cycle($id))) return; $rows = [];
        [$sw, $sp] = Scope::sql('e.id');
        foreach (DB::all("SELECT e.matricule, e.last_name, e.first_name, r.role, r.status, r.score_avg, r.submitted_at FROM perf_reviews r JOIN employees e ON e.id=r.employee_id WHERE r.cycle_id=? AND $sw ORDER BY e.last_name, r.role", array_merge([(int)$id], $sp)) as $r) $rows[] = [$r['matricule'], $r['last_name'], $r['first_name'], Perf::ROLE[$r['role']], $r['status'] === 'done' ? 'Remplie' : 'En attente', $r['score_avg'], $r['submitted_at']];
        csv_download('perf360_' . (int)$id, ['Matricule', 'Nom', 'Prénom', 'Rôle de l\'évaluateur', 'Statut', 'Moyenne', 'Remplie le'], $rows);
    }
    // ---------- compétences ----------
    function competencies(): void { $this->view('perf/competencies', ['title' => 'Compétences évaluées (360°)', 'rows' => DB::all('SELECT k.*, (SELECT COUNT(*) FROM perf_answers a WHERE a.competency_id=k.id) used FROM perf_competencies k ORDER BY k.active DESC, k.sort_order, k.name')]); }
    function compSave(string $id = ''): void {
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'description' => ['label' => 'La description', 'max' => 400]], $_POST); if ($err) { flash(implode(' ', array_map(fn($x) => is_array($x) ? implode(' ', $x) : $x, $err)), 'danger'); redirect('perf/competencies'); }
        $d['active'] = isset($_POST['active']) || $id === '' ? 1 : 0; $d['sort_order'] = max(0, min(999, (int)$this->in('sort_order', 50)));
        if ($id !== '') { if (!DB::val('SELECT 1 FROM perf_competencies WHERE id=?', [(int)$id])) { $this->notFound(); return; } DB::update('perf_competencies', $d, 'id=?', [(int)$id]); } else DB::insert('perf_competencies', $d);
        Audit::log($id !== '' ? 'update' : 'create', 'perf_competency', $id ?: null, null, $d); flash('Compétence enregistrée.'); redirect('perf/competencies');
    }
    function compDelete(string $id): void {
        if (!DB::val('SELECT 1 FROM perf_competencies WHERE id=?', [(int)$id])) { $this->notFound(); return; }
        if ((int)DB::val('SELECT COUNT(*) FROM perf_answers WHERE competency_id=?', [(int)$id])) { DB::update('perf_competencies', ['active' => 0], 'id=?', [(int)$id]); flash('Compétence déjà utilisée : elle est désactivée.', 'info'); }
        else { DB::exec('DELETE FROM perf_competencies WHERE id=?', [(int)$id]); flash('Compétence supprimée.'); } redirect('perf/competencies');
    }
    // ---------- évaluateur / collaborateur ----------
    function mine(): void {
        $me = Perf::myEmp();
        $todo = $me ? DB::all("SELECT r.*, c.name cycle_name, c.deadline, e.first_name, e.last_name FROM perf_reviews r JOIN perf_cycles c ON c.id=r.cycle_id JOIN employees e ON e.id=r.employee_id WHERE r.rater_id=? AND r.status='pending' AND c.status='open' ORDER BY (r.role='self') DESC, r.id", [$me]) : [];
        $done = $me ? DB::all("SELECT r.*, c.name cycle_name, e.first_name, e.last_name FROM perf_reviews r JOIN perf_cycles c ON c.id=r.cycle_id JOIN employees e ON e.id=r.employee_id WHERE r.rater_id=? AND r.status='done' ORDER BY r.submitted_at DESC LIMIT 30", [$me]) : [];
        $results = $me ? DB::all("SELECT DISTINCT c.id, c.name, c.closed_at FROM perf_cycles c JOIN perf_reviews r ON r.cycle_id=c.id WHERE c.status='closed' AND r.employee_id=? ORDER BY c.id DESC", [$me]) : [];
        $team = []; if ($me) { [$sw, $sp] = Scope::sql('e.id'); $team = DB::all("SELECT DISTINCT c.id cid, c.name cname, e.id, e.first_name, e.last_name FROM perf_reviews r JOIN perf_cycles c ON c.id=r.cycle_id JOIN employees e ON e.id=r.employee_id WHERE c.status='closed' AND e.id<>? AND $sw ORDER BY c.id DESC, e.last_name LIMIT 100", array_merge([$me], $sp)); }
        $this->view('perf/mine', ['title' => 'Mes évaluations 360°', 'me' => $me, 'todo' => $todo, 'done' => $done, 'results' => $results, 'team' => $team]);
    }
    private function myReview(string $id): ?array {
        $r = DB::one('SELECT r.*, c.name cycle_name, c.status cycle_status, e.first_name, e.last_name, e.matricule FROM perf_reviews r JOIN perf_cycles c ON c.id=r.cycle_id JOIN employees e ON e.id=r.employee_id WHERE r.id=?', [(int)$id]);
        if (!$r || (int)$r['rater_id'] !== Perf::myEmp()) { $this->notFound(); return null; } return $r;
    }
    function review(string $id): void {
        if (!($r = $this->myReview($id))) return;
        $ans = []; foreach (DB::all('SELECT * FROM perf_answers WHERE review_id=?', [(int)$id]) as $a) $ans[(int)$a['competency_id']] = $a;
        $this->view('perf/review', ['title' => ($r['role'] === 'self' ? 'Auto-évaluation' : 'Évaluation de ' . $r['first_name'] . ' ' . $r['last_name']), 'r' => $r, 'comps' => DB::all('SELECT * FROM perf_competencies WHERE active=1 OR id IN (SELECT competency_id FROM perf_answers WHERE review_id=' . (int)$id . ') ORDER BY sort_order, name'), 'ans' => $ans, 'editable' => $r['status'] === 'pending' && $r['cycle_status'] === 'open']);
    }
    function reviewSave(string $id): void {
        if (!($r = $this->myReview($id))) return;
        if ($r['status'] !== 'pending' || $r['cycle_status'] !== 'open') { flash('Cette évaluation n\'est plus modifiable.', 'warning'); redirect('perf/mine'); }
        $comps = DB::all('SELECT id FROM perf_competencies WHERE active=1'); $sc = (array)($_POST['score'] ?? []); $cm = (array)($_POST['cmt'] ?? []); $vals = [];
        foreach ($comps as $k) { $s = (int)($sc[$k['id']] ?? 0); if ($s < 1 || $s > 5) { flash('Notez chaque compétence de 1 à 5.', 'danger'); redirect("perf/review/$id"); } $vals[(int)$k['id']] = [$s, mb_substr(trim((string)($cm[$k['id']] ?? '')), 0, 500)]; }
        if (!$vals) { flash('Aucune compétence à évaluer.', 'danger'); redirect('perf/mine'); }
        DB::exec('DELETE FROM perf_answers WHERE review_id=?', [(int)$id]);
        foreach ($vals as $cid => [$s, $t]) DB::insert('perf_answers', ['review_id' => (int)$id, 'competency_id' => $cid, 'score' => $s, 'comment' => $t ?: null]);
        DB::update('perf_reviews', ['status' => 'done', 'score_avg' => round(array_sum(array_column($vals, 0)) / count($vals), 2), 'comment' => mb_substr(trim((string)$this->in('comment', '')), 0, 3000) ?: null, 'submitted_at' => now()], 'id=?', [(int)$id]);
        Audit::log('submit', 'perf_review', $id); flash('Évaluation envoyée, merci.'); redirect('perf/mine');
    }
    // ---------- rapport ----------
    function report(string $cid, string $eid): void {
        if (!($c = $this->cycle($cid))) return; $emp = DB::one('SELECT e.*, (SELECT name FROM teams t WHERE t.id=e.team_id) team FROM employees e WHERE e.id=?', [(int)$eid]);
        if (!$emp || !Perf::canView($c, (int)$eid) || Scope::hidden($emp)) { $this->notFound(); return; }
        $agg = Perf::aggregate((int)$cid, (int)$eid);
        $this->view('perf/report', ['title' => 'Rapport 360° : ' . $emp['first_name'] . ' ' . $emp['last_name'], 'c' => $c, 'emp' => $emp, 'a' => $agg, 'actions' => DB::all('SELECT * FROM perf_actions WHERE cycle_id=? AND employee_id=? ORDER BY id', [(int)$cid, (int)$eid]), 'manage' => can('perf.manage'),
            'pending' => (int)DB::val("SELECT COUNT(*) FROM perf_reviews WHERE cycle_id=? AND employee_id=? AND status='pending'", [(int)$cid, (int)$eid])]);
    }
    function actionAdd(string $cid, string $eid): void {
        if (!($c = $this->cycle($cid)) || !Perf::canView($c, (int)$eid)) { $this->notFound(); return; }
        $a = trim((string)$this->in('action', '')); if ($a === '') { flash('Décrivez l\'action de développement.', 'danger'); redirect("perf/report/$cid/$eid"); }
        DB::insert('perf_actions', ['cycle_id' => (int)$cid, 'employee_id' => (int)$eid, 'action' => mb_substr($a, 0, 300), 'due_date' => $this->in('due_date') ?: null, 'status' => 'todo', 'created_by' => Auth::id(), 'created_at' => now()]);
        flash('Action ajoutée au plan de développement.'); redirect("perf/report/$cid/$eid");
    }
    function actionStatus(string $id): void {
        $a = DB::one('SELECT * FROM perf_actions WHERE id=?', [(int)$id]); $c = $a ? DB::one('SELECT * FROM perf_cycles WHERE id=?', [(int)$a['cycle_id']]) : null;
        if (!$a || !Perf::canView($c, (int)$a['employee_id'])) { $this->notFound(); return; } $s = (string)$this->in('status'); if (!isset(Perf::ACT[$s])) $s = 'todo';
        DB::update('perf_actions', ['status' => $s], 'id=?', [(int)$id]); redirect('perf/report/' . $a['cycle_id'] . '/' . $a['employee_id']);
    }
}
