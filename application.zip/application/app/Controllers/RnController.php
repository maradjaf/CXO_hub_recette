<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Integ, Meet, Notifier, RichHtml, Rn, Sms, Tc, Xchg};

/** Réunions : liste, création, modification, report, annulation, présence, réponses des invités. */
class RnController extends Controller {
    private function meeting(string $id, bool $manage = false): ?array {
        if (!Rn::on()) { $this->notFound(); return null; } $m = DB::one('SELECT * FROM rn_meetings WHERE id=?', [(int)$id]);
        if (!$m || !Rn::sees($m)) { $this->notFound(); return null; } if ($manage && !Rn::manages($m)) { $this->forbidden(); return null; } return $m;
    }
    static function platforms(): array { return Meet::platforms() + ['onsite' => ['Présentiel (salle)', null, []]]; }
    function index(): void {
        if (!Rn::on()) { $this->notFound(); return; }
        [$sc, $p] = Rn::scope('m'); $tab = (string)($_GET['tab'] ?? 'upcoming'); $now = date('Y-m-d H:i:s', time() - 3600); $w = [$sc];
        if ($tab === 'past') { $w[] = "(m.status='held' OR (m.status='planned' AND m.start_at<?))"; $p[] = $now; } elseif ($tab === 'cancelled') $w[] = "m.status='cancelled'"; elseif ($tab === 'mine') { $w[] = '(m.organizer_id=? OR m.secretary_id=?)'; array_push($p, (int)Auth::id(), (int)Auth::id()); }
        elseif ($tab === 'minutes') $w[] = "m.status='held' AND m.minutes_status IN ('none','draft','validated')"; else { $tab = 'upcoming'; $w[] = "m.status='planned' AND m.start_at>=?"; $p[] = $now; }
        if (($q = trim((string)($_GET['q'] ?? ''))) !== '') { $w[] = '(m.title LIKE ? OR m.ref LIKE ?)'; $p[] = "%$q%"; $p[] = "%$q%"; }
        if (($k = (string)($_GET['kind'] ?? '')) !== '') { $w[] = 'm.kind=?'; $p[] = $k; }
        $pg = paginate('rn_meetings m LEFT JOIN users o ON o.id=m.organizer_id WHERE ' . implode(' AND ', $w), $p, $this->page(), 25, 'm.*, o.name organizer, (SELECT COUNT(*) FROM rn_attendees a WHERE a.meeting_id=m.id) n_att, (SELECT COUNT(*) FROM rn_actions x WHERE x.meeting_id=m.id) n_act', $tab === 'upcoming' ? 'm.start_at' : 'm.start_at DESC');
        $this->view('rn/index', ['title' => 'Réunions', 'p' => $pg, 'tab' => $tab, 'kinds' => Rn::kinds()]);
    }
    private function formData(?array $m = null): array {
        $att = []; if ($m) foreach (DB::all('SELECT user_id, name, role FROM rn_attendees WHERE meeting_id=? AND user_id IS NOT NULL', [(int)$m['id']]) as $a) $att[] = ['id' => (int)$a['user_id'], 'name' => $a['name'], 'role' => $a['role']];
        $ext = $m ? DB::all('SELECT name, email, phone FROM rn_attendees WHERE meeting_id=? AND user_id IS NULL', [(int)$m['id']]) : [];
        return ['title' => $m ? 'Modifier la réunion' : 'Nouvelle réunion', 'm' => $m, 'init' => $att, 'ext' => implode("\n", array_map(fn($e) => $e['name'] . ' ; ' . $e['email'] . ' ; ' . $e['phone'], $ext)), 'kinds' => Rn::kinds(), 'platforms' => self::platforms(),
                'users' => DB::all("SELECT id, name FROM users WHERE status='active' ORDER BY name LIMIT 1000")];
    }
    function create(): void { if (!Rn::on()) { $this->notFound(); return; } $this->view('rn/form', $this->formData()); }
    function edit(string $id): void { $m = $this->meeting($id, true); if (!$m) return; if ($m['status'] !== 'planned') { flash('Cette réunion n\'est plus modifiable.', 'warning'); redirect('rn/' . $id); } $this->view('rn/form', $this->formData($m)); }
    /** @return array{0:?array,1:array,2:array} données, participants, erreurs */
    private function read(?array $cur = null): array {
        $err = []; $pl = trim((string)$this->in('platform', 'teams')); $title = trim((string)$this->in('title')); $link = trim((string)$this->in('link')); $dial = trim((string)$this->in('dial_in')); $place = trim((string)$this->in('place'));
        $date = (string)$this->in('date'); $time = (string)$this->in('time'); $dur = (int)$this->in('duration_min', 60); $ts = strtotime($date . ' ' . $time);
        if (!isset(self::platforms()[$pl]) && !($cur && $cur['platform'] === $pl)) $err[] = 'Cet outil de réunion n\'est pas activé.'; if ($title === '') $err[] = 'Indiquez l\'objet (titre) de la réunion.';
        if ($pl === 'onsite' && $place === '') $err[] = 'Indiquez le lieu (salle) de la réunion.'; if ($link !== '' && !in_array($pl, ['onsite', 'phone', 'other'], true) && ($e = Meet::linkError($pl, $link, $dial))) $err[] = $e;
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !preg_match('/^\d{2}:\d{2}$/', $time) || !$ts) $err[] = 'Date ou heure invalide.'; elseif ($ts < time() - 60 && !($cur && substr($cur['start_at'], 0, 16) === date('Y-m-d H:i', $ts))) $err[] = 'La date de la réunion doit être dans le futur.';
        if ($dur < 5 || $dur > 720) $err[] = 'Durée : entre 5 et 720 minutes.';
        $att = []; foreach ((array)$this->in('att', []) as $uid => $role) { $u = DB::one("SELECT u.id, u.name, u.email, e.phone FROM users u LEFT JOIN employees e ON e.id=u.employee_id WHERE u.id=? AND u.status='active'", [(int)$uid]);
            if ($u && isset(Rn::ROLES[$role])) $att[] = ['user_id' => (int)$u['id'], 'name' => $u['name'], 'email' => $u['email'], 'phone' => $u['phone'] ? (Sms::normalize($u['phone']) ?: null) : null, 'role' => $role]; }
        [$extra, $e2] = Meet::parseExtra((string)$this->in('extra')); $err = array_merge($err, $e2); foreach ($extra as $x) $att[] = ['user_id' => null, 'name' => $x['name'], 'email' => $x['email'], 'phone' => $x['phone'], 'role' => 'required'];
        $org = $cur ? (int)$cur['organizer_id'] : (int)Auth::id(); if (!array_filter($att, fn($a) => (int)$a['user_id'] === $org)) { /* l'organisateur est toujours dans la liste */ $u = DB::one('SELECT u.id, u.name, u.email, e.phone FROM users u LEFT JOIN employees e ON e.id=u.employee_id WHERE u.id=?', [$org]); if ($u) array_unshift($att, ['user_id' => $org, 'name' => $u['name'], 'email' => $u['email'], 'phone' => $u['phone'] ? (Sms::normalize($u['phone']) ?: null) : null, 'role' => 'required']); }
        if (count($att) < 2) $err[] = 'Invitez au moins un participant en plus de vous.'; if (count($att) > Xchg::int('rn.max_attendees', 2, 500)) $err[] = 'Maximum ' . Xchg::int('rn.max_attendees', 2, 500) . ' participants.';
        $sec = (int)$this->in('secretary_id', 0); if ($sec && !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$sec])) $sec = 0;
        $agenda = RichHtml::clean((string)$this->in('agenda'), 20000); $kind = trim((string)$this->in('kind'));
        return [$err ? null : ['title' => mb_substr($title, 0, 190), 'kind' => mb_substr($kind, 0, 30) ?: null, 'objective' => mb_substr(trim((string)$this->in('objective')), 0, 500) ?: null, 'agenda' => $agenda ?: null, 'platform' => $pl, 'place' => mb_substr($place, 0, 190) ?: null, 'link' => mb_substr($link, 0, 500) ?: null, 'dial_in' => mb_substr($dial, 0, 200) ?: null,
            'start_at' => date('Y-m-d H:i:s', (int)$ts), 'duration_min' => $dur, 'secretary_id' => $sec ?: null], $att, $err];
    }
    private function saveAttendees(int $mid, array $att): void { foreach ($att as $g) DB::insert('rn_attendees', $g + ['meeting_id' => $mid, 'rsvp' => 'pending', 'n_inapp' => 'skipped', 'n_email' => 'skipped', 'n_sms' => 'skipped', 'n_wa' => 'skipped', 'created_at' => now()]); }
    function store(): void {
        if (!Rn::on()) { $this->notFound(); return; } [$d, $att, $err] = $this->read();         if ($err) { $this->back(['form' => implode(' ', $err)], $_POST, 'rn/new'); }
        $rep = (string)$this->in('repeat', 'none'); $count = $rep === 'none' ? 1 : max(2, min(12, (int)$this->in('repeat_n', 4))); $first = null; $warn = '';
        for ($i = 0; $i < $count; $i++) {
            $ts = strtotime($d['start_at']); if ($i) $ts = strtotime(['weekly' => "+$i week", 'biweekly' => '+' . (2 * $i) . ' week', 'monthly' => "+$i month"][$rep] ?? "+$i week", $ts);
            $row = ['start_at' => date('Y-m-d H:i:s', $ts)] + $d; $pid = null; $auto = 0;
            if ($i === 0 && (string)$this->in('auto_link') === '1' && Meet::autoCapable($d['platform'])) { try { [$lnk, $pid, $dial] = Integ::createMeeting($d['platform'], $d['title'], $row['start_at'], (int)$d['duration_min'], RichHtml::text($d['agenda'])); $row['link'] = mb_substr($lnk, 0, 500); if ($dial !== '') $row['dial_in'] = mb_substr(trim((string)$row['dial_in'] . ' ' . $dial), 0, 200); $auto = 1; } catch (\Throwable $x) { $warn = ' Lien non créé automatiquement (' . $x->getMessage() . ').'; } }
            $mid = DB::insert('rn_meetings', $row + ['ref' => Rn::ref(), 'provider_id' => $pid, 'auto' => $auto, 'status' => 'planned', 'organizer_id' => Auth::id(), 'seq' => 0, 'postponed_count' => 0, 'first_start_at' => $row['start_at'], 'reminder_sent' => 0, 'minutes_status' => 'none', 'minutes_version' => 0, 'created_at' => now(), 'updated_at' => now()]);
            $this->saveAttendees((int)$mid, $att); Rn::event((int)$mid, 'create', 'Réunion planifiée' . ($count > 1 ? ' (occurrence ' . ($i + 1) . '/' . $count . ')' : '') . ' — ' . count($att) . ' participant(s).');
            $n = (string)$this->in('notify', '1') === '1' ? Rn::notify((int)$mid, 'INVITATION') : 0; $first ??= (int)$mid; Audit::log('create', 'rn_meeting', (string)$mid, null, ['guests' => count($att), 'notified' => $n]);
        }
        flash(($count > 1 ? "$count réunions planifiées. " : 'Réunion planifiée. ') . ((string)$this->in('notify', '1') === '1' ? 'Invitations envoyées (outil, e-mail et SMS selon les coordonnées et réglages).' : 'Aucune invitation envoyée.') . $warn, $warn ? 'warning' : 'success'); redirect('rn/' . $first);
    }
    function show(string $id): void {
        $m = $this->meeting($id); if (!$m) return; $me = (int)Auth::id();
        $this->view('rn/show', ['title' => $m['ref'] . ' · ' . $m['title'], 'm' => $m, 'att' => DB::all("SELECT * FROM rn_attendees WHERE meeting_id=? ORDER BY CASE role WHEN 'required' THEN 1 WHEN 'optional' THEN 2 ELSE 3 END, name", [(int)$id]), 'mine' => DB::one('SELECT * FROM rn_attendees WHERE meeting_id=? AND user_id=?', [(int)$id, $me]),
            'dec' => Rn::decisions((int)$id), 'act' => Rn::actions((int)$id), 'events' => DB::all('SELECT e.*, u.name uname FROM rn_events e LEFT JOIN users u ON u.id=e.user_id WHERE e.meeting_id=? ORDER BY e.id DESC LIMIT 60', [(int)$id]),
            'k' => Rn::kpis([(int)$id]), 'manage' => Rn::manages($m), 'organizer' => DB::val('SELECT name FROM users WHERE id=?', [(int)$m['organizer_id']]), 'secretary' => $m['secretary_id'] ? DB::val('SELECT name FROM users WHERE id=?', [(int)$m['secretary_id']]) : null,
            'users' => DB::all("SELECT id, name FROM users WHERE status='active' ORDER BY name LIMIT 1000"), 'chat' => Xchg::on('tc.enabled')]);
    }
    function update(string $id): void {
        $m = $this->meeting($id, true); if (!$m) return; if ($m['status'] !== 'planned') { flash('Cette réunion n\'est plus modifiable.', 'warning'); redirect('rn/' . $id); }
        [$d, $att, $err] = $this->read($m); if ($err) $this->back(['form' => implode(' ', $err)], $_POST, 'rn/' . $id . '/edit');
        $moved = $d['start_at'] !== $m['start_at'] || (int)$d['duration_min'] !== (int)$m['duration_min']; $warn = '';
        if ($m['auto'] && $m['provider_id']) { try { Integ::updateMeeting($m['platform'], $m['provider_id'], $d['title'], $d['start_at'], (int)$d['duration_min'], RichHtml::text($d['agenda'])); } catch (\Throwable $x) { $warn = ' Attention : ' . $x->getMessage(); } }
        DB::update('rn_meetings', $d + ['seq' => (int)$m['seq'] + 1, 'reminder_sent' => 0, 'updated_at' => now()] + ($moved ? ['postponed_count' => (int)$m['postponed_count'] + ($d['start_at'] > $m['start_at'] ? 1 : 0)] : []), 'id=?', [(int)$id]);
        $old = DB::all('SELECT * FROM rn_attendees WHERE meeting_id=?', [(int)$id]); $sig = fn($g) => $g['user_id'] ? 'u' . $g['user_id'] : strtolower((string)$g['email']) . '|' . $g['phone']; $newSig = array_map($sig, $att);
        $removed = array_filter($old, fn($g) => !in_array($sig($g), $newSig, true));
        if ($removed) { DB::update('rn_meetings', ['status' => 'cancelled'], 'id=?', [(int)$id]); foreach ($removed as $g) Rn::notify((int)$id, 'ANNULATION', (int)$g['id']); DB::update('rn_meetings', ['status' => 'planned'], 'id=?', [(int)$id]); foreach ($removed as $g) DB::exec('DELETE FROM rn_attendees WHERE id=?', [(int)$g['id']]); }
        $have = array_map($sig, DB::all('SELECT * FROM rn_attendees WHERE meeting_id=?', [(int)$id])); foreach ($att as $g) { if (!in_array($sig($g), $have, true)) $this->saveAttendees((int)$id, [$g]); else DB::update('rn_attendees', ['role' => $g['role']], 'meeting_id=? AND ' . ($g['user_id'] ? 'user_id=?' : 'email=?'), [(int)$id, $g['user_id'] ?: $g['email']]); }
        if ($moved) DB::update('rn_attendees', ['rsvp' => 'pending', 'rsvp_at' => null], 'meeting_id=?', [(int)$id]);
        $n = (string)$this->in('notify', '1') === '1' ? Rn::notify((int)$id, 'MODIFICATION') : 0; Rn::event((int)$id, 'update', 'Réunion modifiée' . ($moved ? ' (nouveau créneau)' : '') . ($removed ? ' — ' . count($removed) . ' participant(s) retiré(s)' : '') . '.'); Audit::log('update', 'rn_meeting', $id);
        flash('Réunion mise à jour' . ($n ? " ; $n participant(s) informé(s)." : '.') . $warn, $warn ? 'warning' : 'success'); redirect('rn/' . $id);
    }
    function postpone(string $id): void {
        $m = $this->meeting($id, true); if (!$m) return; if ($m['status'] !== 'planned') { flash('Réunion déjà close.', 'warning'); redirect('rn/' . $id); }
        $date = (string)$this->in('date'); $time = (string)$this->in('time'); $dur = (int)$this->in('duration_min', (int)$m['duration_min']); $why = trim((string)$this->in('reason')); $ts = strtotime($date . ' ' . $time);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !preg_match('/^\d{2}:\d{2}$/', $time) || !$ts || $ts < time()) { flash('Indiquez une nouvelle date et heure dans le futur.', 'danger'); redirect('rn/' . $id . '#report'); }
        if ($why === '') { flash('Indiquez le motif du report.', 'danger'); redirect('rn/' . $id . '#report'); } if ($dur < 5 || $dur > 720) $dur = (int)$m['duration_min']; $new = date('Y-m-d H:i:s', $ts); $warn = '';
        if ($m['auto'] && $m['provider_id']) { try { Integ::updateMeeting($m['platform'], $m['provider_id'], $m['title'], $new, $dur, RichHtml::text($m['agenda'])); } catch (\Throwable $x) { $warn = ' Attention : ' . $x->getMessage(); } }
        DB::update('rn_meetings', ['start_at' => $new, 'duration_min' => $dur, 'seq' => (int)$m['seq'] + 1, 'postponed_count' => (int)$m['postponed_count'] + 1, 'reminder_sent' => 0, 'updated_at' => now()], 'id=?', [(int)$id]);
        DB::update('rn_attendees', ['rsvp' => 'pending', 'rsvp_at' => null], 'meeting_id=?', [(int)$id]); $n = Rn::notify((int)$id, 'REPORT', null, 'Ancien créneau : ' . date('d/m/Y H:i', strtotime($m['start_at'])) . '. Motif : ' . mb_substr($why, 0, 200));
        Rn::event((int)$id, 'postpone', 'Réunion reportée du ' . date('d/m/Y H:i', strtotime($m['start_at'])) . ' au ' . date('d/m/Y H:i', $ts) . ' — ' . $why); Audit::log('postpone', 'rn_meeting', $id, ['start_at' => $m['start_at']], ['start_at' => $new]);
        flash("Réunion reportée ; $n participant(s) informé(s)." . $warn, $warn ? 'warning' : 'success'); redirect('rn/' . $id);
    }
    function cancel(string $id): void {
        $m = $this->meeting($id, true); if (!$m) return; if ($m['status'] !== 'planned') { flash('Réunion déjà close.', 'warning'); redirect('rn/' . $id); } $why = trim((string)$this->in('reason'));
        if ($why === '') { flash('Indiquez le motif de l\'annulation.', 'danger'); redirect('rn/' . $id . '#annuler'); } $warn = '';
        DB::update('rn_meetings', ['status' => 'cancelled', 'cancel_reason' => mb_substr($why, 0, 300), 'cancelled_at' => now(), 'seq' => (int)$m['seq'] + 1, 'updated_at' => now()], 'id=?', [(int)$id]);
        if ($m['auto'] && $m['provider_id']) { try { Integ::deleteMeeting($m['platform'], $m['provider_id']); } catch (\Throwable $x) { $warn = ' Attention : ' . $x->getMessage(); } }
        $n = Rn::notify((int)$id, 'ANNULATION', null, mb_substr($why, 0, 200)); Rn::event((int)$id, 'cancel', 'Réunion annulée — ' . $why); Audit::log('cancel', 'rn_meeting', $id);
        flash("Réunion annulée ; $n participant(s) informé(s)." . $warn, $warn ? 'warning' : 'success'); redirect('rn/' . $id);
    }
    /** Marque la réunion comme tenue et enregistre les présences. */
    function held(string $id): void {
        $m = $this->meeting($id, true); if (!$m) return; if ($m['status'] === 'cancelled') { flash('Réunion annulée.', 'warning'); redirect('rn/' . $id); }
        if ($m['status'] === 'planned') { DB::update('rn_meetings', ['status' => 'held', 'held_at' => now(), 'updated_at' => now()], 'id=?', [(int)$id]); Rn::event((int)$id, 'held', 'Réunion marquée comme tenue.'); }
        $pres = array_map('intval', (array)$this->in('present', [])); foreach (DB::all('SELECT id FROM rn_attendees WHERE meeting_id=?', [(int)$id]) as $a) DB::update('rn_attendees', ['attended' => in_array((int)$a['id'], $pres, true) ? 1 : 0], 'id=?', [(int)$a['id']]);
        Rn::event((int)$id, 'attendance', 'Présences enregistrées : ' . count($pres) . ' présent(s).'); flash('Réunion tenue ; présences enregistrées. Vous pouvez maintenant rédiger le compte rendu.'); redirect('rn/' . $id . '/minutes/edit');
    }
    function rsvp(string $id): void {
        $m = $this->meeting($id); if (!$m) return; $a = DB::one('SELECT * FROM rn_attendees WHERE meeting_id=? AND user_id=?', [(int)$id, (int)Auth::id()]); $r = (string)$this->in('rsvp');
        if (!$a || !isset(Rn::RSVP[$r]) || $r === 'pending' || $m['status'] !== 'planned') { flash('Réponse impossible.', 'warning'); redirect('rn/' . $id); }
        DB::update('rn_attendees', ['rsvp' => $r, 'rsvp_at' => now()], 'id=?', [(int)$a['id']]); Rn::event((int)$id, 'rsvp', $a['name'] . ' : ' . Rn::RSVP[$r]);
        if ($r === 'no') Notifier::send((int)$m['organizer_id'], 'Réunion · ' . $a['name'] . ' décline', $m['title'] . ' — ' . Rn::when($m), '/rn/' . $id); flash('Votre réponse est enregistrée : ' . Rn::RSVP[$r] . '.'); redirect('rn/' . $id);
    }
    function resend(string $id): void {
        $m = $this->meeting($id, true); if (!$m) return; if ($m['status'] !== 'planned') { flash('Réunion close.', 'warning'); redirect('rn/' . $id); }
        $only = (int)$this->in('attendee', 0) ?: null; $n = Rn::notify((int)$id, 'INVITATION', $only); Rn::event((int)$id, 'resend', "Invitation renvoyée ($n)."); flash("Invitation renvoyée à $n participant(s)."); redirect('rn/' . $id);
    }
    function ics(string $id): void {
        $m = $this->meeting($id); if (!$m) return; header('Content-Type: text/calendar; charset=utf-8'); header('Content-Disposition: attachment; filename="reunion-' . (int)$m['id'] . '.ics"'); header('X-Content-Type-Options: nosniff');
        echo Rn::ics($m, DB::all('SELECT * FROM rn_attendees WHERE meeting_id=?', [(int)$id]), $m['status'] === 'cancelled' ? 'CANCEL' : 'REQUEST'); exit;
    }
    /** Ouvre (ou crée) la discussion de groupe de la réunion. */
    function chat(string $id): void {
        $m = $this->meeting($id, true); if (!$m) return; if (!Xchg::on('tc.enabled')) { flash('Les discussions sont désactivées.', 'warning'); redirect('rn/' . $id); }
        if (!$m['chat_id'] || !DB::val('SELECT 1 FROM tc_chats WHERE id=?', [(int)$m['chat_id']])) {
            $ids = array_map(fn($r) => (int)$r['user_id'], DB::all('SELECT DISTINCT user_id FROM rn_attendees WHERE meeting_id=? AND user_id IS NOT NULL', [(int)$id])); $cid = Tc::createGroup($m['ref'] . ' · ' . $m['title'], (int)Auth::id(), $ids, (int)$id);
            DB::update('rn_meetings', ['chat_id' => $cid], 'id=?', [(int)$id]); Rn::event((int)$id, 'chat', 'Discussion de groupe créée.'); $m['chat_id'] = $cid;
        }
        redirect('tc/' . (int)$m['chat_id']);
    }
}
