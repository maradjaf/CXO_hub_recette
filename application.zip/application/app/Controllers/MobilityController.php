<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Org};

/** Mobilité interne : un collaborateur quitte une activité ou une équipe pour une autre au sein de la direction. */
class MobilityController extends Controller {
    const ST = ['planned' => 'Planifiée', 'done' => 'Effectuée', 'cancelled' => 'Annulée'];
    function index(): void {
        $st = (string)$this->in('status', ''); $q = trim((string)$this->in('q', '')); $w = ['1=1']; $p = [];
        if (isset(self::ST[$st])) { $w[] = 'm.status=?'; $p[] = $st; } if ($q !== '') { $w[] = '(e.first_name LIKE ? OR e.last_name LIKE ? OR e.matricule LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $pg = paginate('mobility_moves m JOIN employees e ON e.id=m.employee_id WHERE ' . implode(' AND ', $w), $p, $this->page(), 25, 'm.*, e.first_name, e.last_name, e.matricule', 'm.effective_date DESC, m.id DESC'); $rows = $pg['rows'];
        foreach ($rows as &$r) { $r['from'] = Org::path($r['from_unit_id'] ? (int)$r['from_unit_id'] : null); $r['to'] = Org::path($r['to_unit_id'] ? (int)$r['to_unit_id'] : null); } unset($r);
        $this->view('mobility/index', ['title' => 'Mobilité interne', 'rows' => $rows, 'p' => $pg, 'status' => $st, 'q' => $q]);
    }
    private function lists(): array {
        return ['emps' => DB::all("SELECT e.id, e.first_name, e.last_name, e.matricule, e.org_unit_id, e.team_id, e.store_id, e.position_id FROM employees e WHERE e.status='active' ORDER BY e.last_name, e.first_name"), 'units' => Org::flat(), 'teams' => DB::all('SELECT id, name, org_unit_id FROM teams WHERE active=1 ORDER BY name'),
            'stores' => DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name'), 'positions' => DB::all('SELECT id, name FROM positions WHERE active=1 ORDER BY name')];
    }
    function create(): void { $this->view('mobility/form', ['title' => 'Nouvelle mobilité interne', 'pre' => (int)$this->in('employee', 0)] + $this->lists()); }
    function store(): void {
        $emp = DB::one("SELECT * FROM employees WHERE id=? AND status='active'", [(int)$this->in('employee_id')]); $err = [];
        if (!$emp) $err['employee_id'] = 'Choisissez le collaborateur.';
        $unit = (int)$this->in('to_unit_id', 0) ?: null; $team = (int)$this->in('to_team_id', 0) ?: null; $store = (int)$this->in('to_store_id', 0) ?: null; $pos = (int)$this->in('to_position_id', 0) ?: null; $mgr = (int)$this->in('to_manager_id', 0) ?: null;
        if ($unit && !DB::val('SELECT 1 FROM org_units WHERE id=?', [$unit])) $err['to_unit_id'] = 'Unité inconnue.';
        if (!$unit && !$team) $err['to_unit_id'] = 'Indiquez l\'activité (unité) ou l\'équipe de destination.';
        if ($team && !$unit) $unit = (int)DB::val('SELECT org_unit_id FROM teams WHERE id=?', [$team]) ?: null;
        $on = (string)$this->in('effective_date', date('Y-m-d')); if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $on)) $err['effective_date'] = 'Date d\'effet invalide.';
        $why = trim((string)$this->in('reason', '')); if (mb_strlen($why) < 5) $err['reason'] = 'Le motif est obligatoire (5 caractères minimum).';
        if ($emp && $unit && (int)$unit === (int)$emp['org_unit_id'] && (int)$team === (int)$emp['team_id'] && $store == $emp['store_id'] && !$pos && !$mgr) $err['to_unit_id'] = 'La destination est identique à l\'affectation actuelle.';
        if ($mgr && $emp && $mgr === (int)$emp['id']) $err['to_manager_id'] = 'Un collaborateur ne peut pas être son propre responsable.';
        if ($err) { $_SESSION['_old'] = $_POST; $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('mobility/new'); }
        $id = DB::insert('mobility_moves', ['employee_id' => (int)$emp['id'], 'from_team_id' => $emp['team_id'], 'from_store_id' => $emp['store_id'], 'from_unit_id' => $emp['org_unit_id'], 'from_position_id' => $emp['position_id'], 'from_manager_id' => $emp['manager_id'],
            'to_team_id' => $team, 'to_store_id' => $store, 'to_unit_id' => $unit, 'to_position_id' => $pos, 'to_manager_id' => $mgr, 'effective_date' => $on, 'reason' => mb_substr($why, 0, 300), 'status' => 'planned', 'requested_by' => Auth::id(), 'created_at' => now()]);
        Audit::log('create', 'mobility', $id, null, ['employee' => $emp['id'], 'to_unit' => $unit]);
        if ($on <= date('Y-m-d')) { Org::applyMove($id); flash('Mobilité effectuée : l\'affectation est à jour.'); } else flash('Mobilité planifiée au ' . d($on) . '.');
        redirect('mobility');
    }
    function act(string $id): void {
        $m = DB::one('SELECT * FROM mobility_moves WHERE id=?', [(int)$id]); if (!$m) { $this->notFound(); return; }
        if ($m['status'] !== 'planned') { flash('Cette mobilité n\'est plus modifiable.', 'warning'); redirect('mobility'); }
        if ($this->in('action') === 'apply') { Org::applyMove((int)$id); flash('Mobilité appliquée.'); } else { DB::update('mobility_moves', ['status' => 'cancelled'], 'id=?', [(int)$id]); flash('Mobilité annulée.'); }
        Audit::log((string)$this->in('action'), 'mobility', $id); redirect('mobility');
    }
}
