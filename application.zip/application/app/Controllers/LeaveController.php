<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Workflow};
class LeaveController extends Controller {
    const STATUS = ['pending' => 'En attente', 'approved' => 'Approuvé', 'rejected' => 'Refusé', 'cancelled' => 'Annulé'];
    /** Jours ouvrés (lundi à vendredi) entre deux dates incluses. Les jours fériés ne sont pas déduits. */
    static function workingDays(string $a, string $b): int {
        $n = 0; for ($t = strtotime($a); $t <= strtotime($b); $t += 86400) if ((int)date('N', $t) < 6) $n++; return $n;
    }
    private function employee(): ?array { return Auth::user()['employee_id'] ? DB::one('SELECT * FROM employees WHERE id=?', [Auth::user()['employee_id']]) : null; }
    static function balance(int $emp, array $type, int $year): array {
        $row = DB::one('SELECT allocated FROM leave_balances WHERE employee_id=? AND leave_type_id=? AND year=?', [$emp, $type['id'], $year]);
        $alloc = $row ? (float)$row['allocated'] : (float)$type['annual_days'];
        $used = (float)DB::val("SELECT COALESCE(SUM(days),0) FROM leave_requests WHERE employee_id=? AND leave_type_id=? AND status IN ('approved','pending') AND start_date>=? AND start_date<=?", [$emp, $type['id'], "$year-01-01", "$year-12-31"]);
        return ['allocated' => $alloc, 'used' => $used, 'left' => $alloc - $used];
    }
    function index(): void {
        $e = $this->employee(); $year = (int)date('Y'); $bal = [];
        if ($e) foreach (DB::all('SELECT * FROM leave_types WHERE active=1 AND controlled=1 ORDER BY name') as $t) $bal[] = ['type' => $t] + self::balance((int)$e['id'], $t, $year);
        $rows = $e ? DB::all('SELECT r.*, t.name type_name FROM leave_requests r JOIN leave_types t ON t.id=r.leave_type_id WHERE r.employee_id=? ORDER BY r.start_date DESC', [$e['id']]) : [];
        $this->view('leave/index', ['title' => 'Mes congés', 'e' => $e, 'bal' => $bal, 'rows' => $rows, 'year' => $year]);
    }
    function create(): void {
        if (!$this->employee()) { flash('Votre compte n\'est lié à aucune fiche collaborateur : demandez à un administrateur de le rattacher.', 'warning'); redirect('leave'); }
        $this->view('leave/form', ['title' => 'Demander un congé', 'types' => DB::all('SELECT * FROM leave_types WHERE active=1 ORDER BY name')]);
    }
    function store(): void {
        $e = $this->employee(); if (!$e) { $this->forbidden(); return; }
        [$d, $err] = $this->validate(['start_date' => ['label' => 'La date de début', 'req' => true, 'date' => true], 'end_date' => ['label' => 'La date de fin', 'req' => true, 'date' => true], 'reason' => ['label' => 'Le motif', 'max' => 500]], $_POST);
        $type = DB::one('SELECT * FROM leave_types WHERE id=? AND active=1', [(int)$this->in('leave_type_id')]); if (!$type) $err['type'] = 'Choisissez un type de congé.';
        $days = 0;
        if (!$err) {
            if ($d['end_date'] < $d['start_date']) $err['end'] = 'La fin est antérieure au début.';
            elseif (substr($d['start_date'], 0, 4) !== substr($d['end_date'], 0, 4)) $err['end'] = 'Une demande ne peut pas chevaucher deux années : faites-en deux.';
            else {
                $days = self::workingDays($d['start_date'], $d['end_date']);
                if ($days < 1) $err['end'] = 'La période ne contient aucun jour ouvré.';
                elseif (DB::val("SELECT 1 FROM leave_requests WHERE employee_id=? AND status IN ('pending','approved') AND start_date<=? AND end_date>=?", [$e['id'], $d['end_date'], $d['start_date']])) $err['overlap'] = 'Cette période chevauche une autre demande.';
                elseif ($type['controlled'] && ($b = self::balance((int)$e['id'], $type, (int)substr($d['start_date'], 0, 4))) && $days > $b['left']) $err['bal'] = "Solde insuffisant : $days jour(s) demandé(s), " . rtrim(rtrim(number_format($b['left'], 2, '.', ''), '0'), '.') . ' restant(s).';
            }
        }
        if ($err) $this->back($err, $_POST, 'leave/new');
        $def = (int)DB::val("SELECT id FROM wf_definitions WHERE code='CONGES' AND active=1");
        $row = ['employee_id' => (int)$e['id'], 'leave_type_id' => (int)$type['id'], 'start_date' => $d['start_date'], 'end_date' => $d['end_date'], 'days' => $days, 'reason' => $d['reason'], 'status' => 'pending', 'created_at' => now()];
        $id = DB::insert('leave_requests', $row);
        if ($def) { $wf = Workflow::start($def, $type['name'] . ' du ' . d($d['start_date']) . ' au ' . d($d['end_date']) . " ($days j)", $d['reason'], 'leave', $id); DB::update('leave_requests', ['wf_request_id' => $wf], 'id=?', [$id]); }
        else DB::update('leave_requests', ['status' => 'approved'], 'id=?', [$id]);
        Audit::log('create', 'leave_request', $id, null, $row);
        flash($def ? 'Demande envoyée pour validation.' : 'Congé enregistré.'); redirect('leave');
    }
    function cancel(string $id): void {
        $e = $this->employee(); $r = DB::one('SELECT * FROM leave_requests WHERE id=?', [(int)$id]);
        if (!$r || !$e || (int)$r['employee_id'] !== (int)$e['id']) { $this->notFound(); return; }
        if ($r['status'] === 'pending' && $r['wf_request_id']) Workflow::act(DB::one('SELECT * FROM wf_requests WHERE id=?', [$r['wf_request_id']]), 'cancel', 'Annulé par le demandeur');
        elseif ($r['status'] === 'approved' && $r['start_date'] > date('Y-m-d')) { DB::update('leave_requests', ['status' => 'cancelled'], 'id=?', [(int)$id]); Audit::log('leave_cancelled', 'leave_request', $id, $r, ['status' => 'cancelled']); }
        else { flash('Ce congé ne peut plus être annulé.', 'danger'); redirect('leave'); }
        flash('Congé annulé ; le solde est restitué.'); redirect('leave');
    }
    function manage(): void {
        $year = (int)($this->in('year') ?: date('Y')); $w = ['1=1']; $p = [];
        if ($this->in('status')) { $w[] = 'r.status=?'; $p[] = $this->in('status'); }
        if ($this->in('from')) { $w[] = 'r.end_date>=?'; $p[] = $this->in('from'); }
        if ($this->in('to')) { $w[] = 'r.start_date<=?'; $p[] = $this->in('to'); }
        $pg = paginate('leave_requests r JOIN employees e ON e.id=r.employee_id JOIN leave_types t ON t.id=r.leave_type_id WHERE ' . implode(' AND ', $w), $p, $this->page(), 25, 'r.*, e.first_name, e.last_name, t.name type_name', 'r.start_date DESC');
        $types = DB::all('SELECT * FROM leave_types ORDER BY name');
        $absent = DB::all("SELECT e.first_name, e.last_name, r.end_date, t.name type_name FROM leave_requests r JOIN employees e ON e.id=r.employee_id JOIN leave_types t ON t.id=r.leave_type_id WHERE r.status='approved' AND r.start_date<=? AND r.end_date>=? ORDER BY e.last_name", [date('Y-m-d'), date('Y-m-d')]);
        $this->view('leave/manage', ['title' => 'Suivi des congés', 'p' => $pg, 'types' => $types, 'absent' => $absent, 'status' => self::STATUS, 'year' => $year,
            'employees' => DB::all("SELECT id, first_name, last_name, matricule FROM employees WHERE status<>'left' ORDER BY last_name, first_name")]);
    }
    function storeType(): void {
        [$d, $err] = $this->validate(['code' => ['label' => 'Le code', 'req' => true, 'max' => 40], 'name' => ['label' => 'Le nom', 'req' => true, 'max' => 120]], $_POST);
        if ($d['code'] && DB::val('SELECT 1 FROM leave_types WHERE code=?', [$d['code']])) $err['code'] = 'Ce code existe déjà.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('leave/manage'); }
        $d += ['annual_days' => max(0, (float)$this->in('annual_days', 0)), 'controlled' => isset($_POST['controlled']) ? 1 : 0, 'active' => 1];
        $id = DB::insert('leave_types', $d); Audit::log('create', 'leave_type', $id, null, $d); flash('Type de congé ajouté.'); redirect('leave/manage');
    }
    function updateType(string $id): void {
        $o = DB::one('SELECT * FROM leave_types WHERE id=?', [(int)$id]); if (!$o) { $this->notFound(); return; }
        $n = ['name' => trim((string)$this->in('name', $o['name'])) ?: $o['name'], 'annual_days' => max(0, (float)$this->in('annual_days', 0)), 'controlled' => isset($_POST['controlled']) ? 1 : 0, 'active' => isset($_POST['active']) ? 1 : 0];
        DB::update('leave_types', $n, 'id=?', [(int)$id]); Audit::log('update', 'leave_type', $id, $o, $n); flash('Type enregistré.'); redirect('leave/manage');
    }
    function saveBalance(): void {
        $emp = (int)$this->in('employee_id'); $t = (int)$this->in('leave_type_id'); $y = (int)$this->in('year'); $a = (float)$this->in('allocated', -1);
        if (!DB::val('SELECT 1 FROM employees WHERE id=?', [$emp]) || !DB::val('SELECT 1 FROM leave_types WHERE id=?', [$t]) || $y < 2000 || $a < 0) { flash('Renseignez collaborateur, type, année et droits (≥ 0).', 'danger'); redirect('leave/manage'); }
        $old = DB::one('SELECT * FROM leave_balances WHERE employee_id=? AND leave_type_id=? AND year=?', [$emp, $t, $y]);
        if ($old) DB::update('leave_balances', ['allocated' => $a], 'id=?', [$old['id']]); else DB::insert('leave_balances', ['employee_id' => $emp, 'leave_type_id' => $t, 'year' => $y, 'allocated' => $a]);
        Audit::log('update', 'leave_balance', "$emp/$t/$y", $old, ['allocated' => $a]); flash('Droits à congé enregistrés.'); redirect('leave/manage');
    }
}
