<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Ged, Files, Notifier};

/** Lot 64 : GED (M41) — dossiers, documents versionnés, validation, verrou, revue/expiration, journal. */
class GedController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    private function doc(string $id, bool $write = false): ?array {
        $d = DB::one('SELECT d.*, f.name folder_name FROM ged_docs d JOIN ged_folders f ON f.id=d.folder_id WHERE d.id=?', [(int)$id]);
        if (!$d || !Ged::canRead($d)) { $this->notFound(); return null; }
        if ($write && !Ged::canWrite($d)) { $this->forbidden(); return null; }
        return $d;
    }
    private function meta(): array {
        [$v, $err] = $this->validate(['title' => ['label' => 'Le titre', 'req' => 1, 'max' => 200], 'category' => ['label' => 'La catégorie', 'max' => 60], 'tags' => ['label' => 'Les mots-clés', 'max' => 300], 'review_date' => ['label' => 'La date de revue', 'date' => 1], 'expires_at' => ['label' => 'La date d\'expiration', 'date' => 1]], $_POST);
        $v['description'] = trim((string)($_POST['description'] ?? '')) ?: null; $c = (string)($_POST['confidentiality'] ?? 'internal'); $v['confidentiality'] = isset(Ged::CONF[$c]) ? $c : 'internal';
        if ($v['review_date'] && $v['expires_at'] && $v['expires_at'] < $v['review_date']) $err['expires_at'] = 'L\'expiration ne peut pas précéder la revue.';
        return [$v, $err];
    }

    // ------------------------------------------------------------------ navigation
    function index(): void {
        $read = Ged::readableIds(); $fid = (int)$this->in('folder'); $q = trim((string)$this->in('q', '')); $st = (string)$this->in('status', '');
        if ($fid && !in_array($fid, $read, true)) { $this->notFound(); return; }
        $scope = $fid && $q === '' ? [$fid] : ($fid ? Ged::subtree($fid) : $read); $scope = array_values(array_intersect($scope, $read)); $trash = $st === 'deleted' && Ged::manager();
        $w = [$scope ? 'd.folder_id IN (' . implode(',', array_map('intval', $scope)) . ')' : '1=0', $trash ? 'd.deleted_at IS NOT NULL' : 'd.deleted_at IS NULL']; $p = [];
        if (!Ged::manager()) { $w[] = "(d.confidentiality<>'restricted' OR d.owner_id=?)"; $p[] = (int)Auth::id(); }
        if (isset(Ged::STATUS[$st])) { $w[] = 'd.status=?'; $p[] = $st; }
        if ($q !== '') { $w[] = '(d.title LIKE ? OR d.description LIKE ? OR d.tags LIKE ? OR d.ref LIKE ? OR d.category LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%", "%$q%", "%$q%"); }
        if (($c = trim((string)$this->in('category', ''))) !== '') { $w[] = 'd.category=?'; $p[] = $c; }
        $from = 'ged_docs d JOIN ged_folders f ON f.id=d.folder_id LEFT JOIN users u ON u.id=d.owner_id WHERE ' . implode(' AND ', $w);
        if ($this->in('export') === 'csv') {
            $rows = DB::all("SELECT d.ref, d.title, f.name folder, d.category, d.tags, d.confidentiality, d.status, d.current_version, u.name owner, d.review_date, d.expires_at, d.updated_at FROM $from ORDER BY d.title LIMIT 5000", $p);
            Audit::log('export', 'ged_register', null, null, ['rows' => count($rows)]);
            csv_download('registre_ged_' . date('Ymd_His') . '.csv', ['Référence', 'Titre', 'Dossier', 'Catégorie', 'Mots-clés', 'Confidentialité', 'Statut', 'Version', 'Propriétaire', 'Revue', 'Expiration', 'Mis à jour'],
                array_map(fn($r) => [$r['ref'], $r['title'], $r['folder'], $r['category'], $r['tags'], Ged::CONF[$r['confidentiality']] ?? '', Ged::STATUS[$r['status']] ?? '', $r['current_version'], $r['owner'], $r['review_date'], $r['expires_at'], $r['updated_at']], $rows));
        }
        $pg = paginate($from, $p, $this->page(), 25, 'd.*, f.name folder_name, u.name owner_name', 'd.updated_at DESC, d.id DESC');
        $due = array_values(array_filter(Ged::due(30), fn($d) => in_array((int)$d['folder_id'], $read, true) && Ged::canRead($d)));
        $this->view('ged/index', ['title' => 'GED — Documents', 'p' => $pg, 'tree' => Ged::tree(), 'read' => $read, 'fid' => $fid, 'path' => $fid ? Ged::path($fid) : [], 'q' => $q, 'st' => $st, 'due' => $due,
            'cats' => DB::all("SELECT DISTINCT category FROM ged_docs WHERE category IS NOT NULL AND category<>'' ORDER BY category"), 'counts' => array_column(DB::all('SELECT folder_id, COUNT(*) n FROM ged_docs WHERE deleted_at IS NULL GROUP BY folder_id'), 'n', 'folder_id')]);
    }

    // ------------------------------------------------------------------ dossiers
    function folders(): void {
        $roles = DB::all('SELECT id, name FROM roles ORDER BY name'); $acl = [];
        foreach (DB::all('SELECT folder_id, role_id, level FROM ged_folder_roles') as $a) $acl[(int)$a['folder_id']][(int)$a['role_id']] = $a['level'];
        $n = array_column(DB::all('SELECT folder_id, COUNT(*) n FROM ged_docs WHERE deleted_at IS NULL GROUP BY folder_id'), 'n', 'folder_id');
        $this->view('ged/folders', ['title' => 'Dossiers de la GED', 'tree' => Ged::tree(), 'roles' => $roles, 'acl' => $acl, 'n' => $n]);
    }
    function folderSave(string $id = ''): void {
        [$v, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => 1, 'max' => 150], 'description' => ['label' => 'La description', 'max' => 400]], $_POST);
        $acc = (string)($_POST['access'] ?? 'all'); if (!isset(Ged::ACCESS[$acc])) $acc = 'all'; $parent = (int)($_POST['parent_id'] ?? 0); $id = (int)$id;
        if ($parent && !DB::val('SELECT 1 FROM ged_folders WHERE id=?', [$parent])) $err['parent_id'] = 'Dossier parent inconnu.';
        if ($id && $parent && in_array($parent, Ged::subtree($id), true)) $err['parent_id'] = 'Un dossier ne peut pas être placé dans lui-même ou l\'un de ses sous-dossiers.';
        if (!$err && DB::val('SELECT 1 FROM ged_folders WHERE ' . ($parent ? 'parent_id=?' : '(parent_id IS NULL OR parent_id=0)') . ' AND LOWER(name)=LOWER(?) AND id<>?', array_merge($parent ? [$parent] : [], [$v['name'], $id]))) $err['name'] = 'Un dossier de même nom existe déjà à cet endroit.';
        if ($err) $this->go('ged/folders', implode(' ', $err), 'danger');
        $row = ['name' => $v['name'], 'description' => $v['description'], 'access' => $acc, 'parent_id' => $parent ?: null, 'sort_order' => (int)($_POST['sort_order'] ?? 0)];
        if ($id) { if (!DB::val('SELECT 1 FROM ged_folders WHERE id=?', [$id])) { $this->notFound(); return; } DB::update('ged_folders', $row, 'id=?', [$id]); } else $id = DB::insert('ged_folders', $row + ['owner_id' => Auth::id(), 'active' => 1, 'created_at' => now()]);
        DB::exec('DELETE FROM ged_folder_roles WHERE folder_id=?', [$id]);
        if ($acc === 'roles') foreach ((array)($_POST['role'] ?? []) as $rid => $lv) if (in_array($lv, ['read', 'write'], true) && DB::val('SELECT 1 FROM roles WHERE id=?', [(int)$rid])) DB::insert('ged_folder_roles', ['folder_id' => $id, 'role_id' => (int)$rid, 'level' => $lv]);
        Audit::log('save', 'ged_folder', (string)$id, null, ['name' => $v['name'], 'access' => $acc]); $this->go('ged/folders', 'Dossier enregistré.');
    }
    function folderDelete(string $id): void {
        $id = (int)$id; if (!DB::val('SELECT 1 FROM ged_folders WHERE id=?', [$id])) { $this->notFound(); return; }
        if (DB::val('SELECT 1 FROM ged_folders WHERE parent_id=?', [$id]) || DB::val('SELECT 1 FROM ged_docs WHERE folder_id=?', [$id])) $this->go('ged/folders', 'Impossible : le dossier contient des sous-dossiers ou des documents (même supprimés).', 'danger');
        DB::exec('DELETE FROM ged_folder_roles WHERE folder_id=?', [$id]); DB::exec('DELETE FROM ged_folders WHERE id=?', [$id]); Audit::log('delete', 'ged_folder', (string)$id); $this->go('ged/folders', 'Dossier supprimé.');
    }

    // ------------------------------------------------------------------ documents
    function create(): void {
        $f = (int)$this->in('folder'); $ok = array_values(array_filter(Ged::tree(), fn($x) => Ged::level((int)$x['id']) === 'write'));
        $this->view('ged/form', ['title' => 'Nouveau document', 'folders' => $ok, 'fid' => $f, 'cats' => DB::all("SELECT DISTINCT category FROM ged_docs WHERE category IS NOT NULL AND category<>'' ORDER BY category")]);
    }
    function store(): void {
        $fid = (int)($_POST['folder_id'] ?? 0); if (Ged::level($fid) !== 'write') { $this->forbidden(); return; }
        [$v, $err] = $this->meta(); [$files, $ferr] = Files::uploads('files'); if (!$files) $err['files'] = $ferr ? implode(' ', $ferr) : 'Joignez un fichier.';
        if ($err) { $_SESSION['_ferr'] = $err + ($_SESSION['_ferr'] ?? []); $this->go('ged/new?folder=' . $fid, implode(' ', $err), 'danger'); }
        $id = DB::insert('ged_docs', $v + ['ref' => Ged::ref(), 'folder_id' => $fid, 'status' => 'draft', 'owner_id' => Auth::id(), 'current_version' => 0, 'created_at' => now(), 'updated_at' => now()]);
        [$n, $e] = Ged::addVersion($id, $files[0], 'Version initiale'); if (!$n) { DB::exec('DELETE FROM ged_docs WHERE id=?', [$id]); $this->go('ged/new?folder=' . $fid, (string)$e, 'danger'); }
        Ged::log($id, 'création', $files[0]['name']); Audit::log('create', 'ged_doc', (string)$id, null, ['title' => $v['title']]); $this->go('ged/doc/' . $id, 'Document créé (version 1).');
    }
    function show(string $id): void {
        if (!($d = $this->doc($id))) return;
        $vers = DB::all('SELECT v.*, u.name user_name FROM ged_versions v LEFT JOIN users u ON u.id=v.user_id WHERE v.doc_id=? ORDER BY v.version DESC', [(int)$id]);
        $log = DB::all('SELECT l.*, u.name user_name FROM ged_log l LEFT JOIN users u ON u.id=l.user_id WHERE l.doc_id=? ORDER BY l.id DESC LIMIT 60', [(int)$id]);
        $this->view('ged/show', ['title' => $d['title'], 'd' => $d, 'vers' => $vers, 'log' => $log, 'path' => Ged::path((int)$d['folder_id']), 'canWrite' => Ged::canWrite($d), 'owner' => DB::val('SELECT name FROM users WHERE id=?', [(int)$d['owner_id']]), 'locker' => $d['locked_by'] ? DB::val('SELECT name FROM users WHERE id=?', [(int)$d['locked_by']]) : null,
            'folders' => array_values(array_filter(Ged::tree(), fn($x) => Ged::level((int)$x['id']) === 'write'))]);
    }
    function download(string $id): void {
        if (!($d = $this->doc($id))) return; $n = (int)$this->in('v', $d['current_version']);
        $v = DB::one('SELECT * FROM ged_versions WHERE doc_id=? AND version=?', [(int)$id, $n]); if (!$v) { $this->notFound(); return; }
        Ged::log((int)$id, 'lecture', 'v' . $n . ' · ' . $v['original_name']); Audit::log('download', 'ged_doc', $id, null, ['ref' => $d['ref'], 'version' => $n]); Files::send('ged', $v['stored_name'], $v['original_name'], $v['mime'] ?: 'application/octet-stream');
    }
    function update(string $id): void {
        if (!($d = $this->doc($id, true))) return; [$v, $err] = $this->meta(); $fid = (int)($_POST['folder_id'] ?? $d['folder_id']);
        if ($fid !== (int)$d['folder_id'] && Ged::level($fid) !== 'write') $err['folder_id'] = 'Dossier de destination non autorisé.';
        if ($err) { $_SESSION['_ferr'] = $err + ($_SESSION['_ferr'] ?? []); $this->go('ged/doc/' . $id, implode(' ', $err), 'danger'); }
        DB::update('ged_docs', $v + ['folder_id' => $fid, 'updated_at' => now()], 'id=?', [(int)$id]); Ged::log((int)$id, 'modification', 'métadonnées'); $this->go('ged/doc/' . $id, 'Informations enregistrées.');
    }
    function version(string $id): void {
        if (!($d = $this->doc($id, true))) return; [$files, $ferr] = Files::uploads('files'); if (!$files) $this->go('ged/doc/' . $id, $ferr ? implode(' ', $ferr) : 'Joignez un fichier.', 'danger');
        [$n, $e] = Ged::addVersion((int)$id, $files[0], (string)($_POST['comment'] ?? '')); if (!$n) $this->go('ged/doc/' . $id, (string)$e, 'danger');
        if ($d['locked_by'] && (int)$d['locked_by'] === (int)Auth::id()) DB::update('ged_docs', ['locked_by' => null, 'locked_at' => null], 'id=?', [(int)$id]);
        Ged::log((int)$id, 'version', 'v' . $n . ' · ' . $files[0]['name']); $this->go('ged/doc/' . $id, "Version $n enregistrée" . ($d['status'] === 'validated' ? ' : le document repasse en brouillon, à faire valider de nouveau.' : '.'));
    }
    function rollback(string $id): void {
        if (!($d = $this->doc($id, true))) return; $n = (int)($_POST['version'] ?? 0); $v = DB::one('SELECT * FROM ged_versions WHERE doc_id=? AND version=?', [(int)$id, $n]); if (!$v) { $this->notFound(); return; }
        $path = Files::dir('ged') . '/' . basename($v['stored_name']); if (!is_file($path)) $this->go('ged/doc/' . $id, 'Fichier de cette version introuvable.', 'danger');
        [$m, $e] = Ged::addVersion((int)$id, ['name' => $v['original_name'], 'bytes' => (string)file_get_contents($path), 'ext' => strtolower(pathinfo($v['original_name'], PATHINFO_EXTENSION)), 'mime' => $v['mime']], 'Restauration de la version ' . $n);
        if (!$m) $this->go('ged/doc/' . $id, (string)$e, 'danger'); Ged::log((int)$id, 'version', "restauration de v$n en v$m"); $this->go('ged/doc/' . $id, "Version $n restaurée en version $m.");
    }
    function lock(string $id): void {
        if (!($d = $this->doc($id, true))) return; $unlock = ($_POST['act'] ?? '') === 'unlock';
        if ($unlock) { if ($d['locked_by'] && (int)$d['locked_by'] !== (int)Auth::id() && !Ged::manager()) { $this->forbidden(); return; } DB::update('ged_docs', ['locked_by' => null, 'locked_at' => null], 'id=?', [(int)$id]); Ged::log((int)$id, 'verrou', 'libéré'); $this->go('ged/doc/' . $id, 'Verrou libéré.'); }
        if ($d['locked_by'] && (int)$d['locked_by'] !== (int)Auth::id()) $this->go('ged/doc/' . $id, 'Document déjà verrouillé par un autre utilisateur.', 'danger');
        DB::update('ged_docs', ['locked_by' => Auth::id(), 'locked_at' => now()], 'id=?', [(int)$id]); Ged::log((int)$id, 'verrou', 'pris pour modification'); $this->go('ged/doc/' . $id, 'Document verrouillé : vous seul pouvez déposer une nouvelle version.');
    }
    function workflow(string $id): void {
        if (!($d = $this->doc($id))) return; $act = (string)($_POST['act'] ?? ''); $note = trim((string)($_POST['note'] ?? '')) ?: null; $to = null;
        switch ($act) {
            case 'submit': if (!Ged::canWrite($d) || $d['status'] !== 'draft') { $this->forbidden(); return; }
                DB::update('ged_docs', ['status' => 'review', 'decision_note' => null], 'id=?', [(int)$id]); Ged::log((int)$id, 'statut', 'soumis à validation'); Notifier::toPermission('ged.manage', 'Document à valider : ' . $d['title'], 'Soumis par ' . (string)DB::val('SELECT name FROM users WHERE id=?', [(int)Auth::id()]), 'ged/doc/' . $id); $to = 'Document soumis à validation.'; break;
            case 'validate': case 'reject': if (!Ged::manager() || $d['status'] !== 'review') { $this->forbidden(); return; }
                if ($act === 'reject' && !$note) $this->go('ged/doc/' . $id, 'Indiquez le motif du refus.', 'danger');
                DB::update('ged_docs', $act === 'validate' ? ['status' => 'validated', 'validated_by' => Auth::id(), 'validated_at' => now(), 'decision_note' => $note] : ['status' => 'draft', 'decision_note' => $note], 'id=?', [(int)$id]);
                Ged::log((int)$id, 'statut', $act === 'validate' ? 'validé' : 'refusé : ' . $note); if ($d['owner_id']) Notifier::send((int)$d['owner_id'], ($act === 'validate' ? 'Document validé : ' : 'Document refusé : ') . $d['title'], (string)$note, 'ged/doc/' . $id);
                $to = $act === 'validate' ? 'Document validé.' : 'Document renvoyé en brouillon.'; break;
            case 'archive': if (!Ged::manager() && !Ged::canWrite($d)) { $this->forbidden(); return; } DB::update('ged_docs', ['status' => 'archived', 'locked_by' => null, 'locked_at' => null], 'id=?', [(int)$id]); Ged::log((int)$id, 'statut', 'archivé'); $to = 'Document archivé (lecture seule).'; break;
            case 'unarchive': if (!Ged::manager()) { $this->forbidden(); return; } DB::update('ged_docs', ['status' => 'draft'], 'id=?', [(int)$id]); Ged::log((int)$id, 'statut', 'désarchivé'); $to = 'Document remis en brouillon.'; break;
            case 'delete': if (!Ged::manager() && !((int)$d['owner_id'] === (int)Auth::id() && $d['status'] === 'draft' && Ged::canWrite($d))) { $this->forbidden(); return; }
                DB::update('ged_docs', ['deleted_at' => now()], 'id=?', [(int)$id]); Ged::log((int)$id, 'suppression', 'mis à la corbeille'); Audit::log('delete', 'ged_doc', $id, null, ['ref' => $d['ref']]); $this->go('ged', 'Document placé dans la corbeille (restaurable par un gestionnaire).');
            case 'restore': if (!Ged::manager()) { $this->forbidden(); return; } DB::update('ged_docs', ['deleted_at' => null], 'id=?', [(int)$id]); Ged::log((int)$id, 'suppression', 'restauré'); $to = 'Document restauré.'; break;
            default: $this->notFound(); return;
        }
        $this->go('ged/doc/' . $id, $to);
    }
    function alerts(): void { $n = Ged::alerts((int)setting('ged.alert_days', '30')); $this->go('ged', "$n rappel(s) envoyé(s) aux propriétaires."); }
}
