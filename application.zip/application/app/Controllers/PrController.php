<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Ca, Pr, PrDiagram, Pm};
class PrController extends Controller {
    private function owners(): array { return Ca::usersWith('pr.write'); }
    private function load(string $id, bool $edit = false): ?array {
        $p = DB::one('SELECT p.*, u.name owner FROM pr_processes p LEFT JOIN users u ON u.id=p.owner_id WHERE p.id=?', [(int)$id]);
        if (!$p || !Pr::canSee($p)) { $this->notFound(); return null; }
        if ($edit && !Pr::canEdit($p)) { $this->forbidden(); return null; } return $p;
    }
    private function visibleSql(string $a = 'p'): array {
        if (can('pr.manage')) return ['1=1', []];
        return ["($a.status='published' OR $a.owner_id=? OR $a.created_by=?)", [Auth::id(), Auth::id()]];
    }
    // ---- Cartographie ----
    function index(): void {
        [$w, $p] = $this->visibleSql(); $w = [$w, "p.status<>'archived'"];
        if ($q = trim((string)$this->in('q', ''))) { $w[] = '(p.name LIKE ? OR p.code LIKE ? OR p.purpose LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        if ($d = (string)$this->in('domain', '')) { $w[] = 'p.domain=?'; $p[] = $d; }
        if ($this->in('improve')) $w[] = "p.status='published' AND EXISTS (SELECT 1 FROM pr_gov g WHERE g.process_id=p.id AND g.improve=1)";
        $rows = DB::all('SELECT p.*, u.name owner FROM pr_processes p LEFT JOIN users u ON u.id=p.owner_id WHERE ' . implode(' AND ', $w) . ' ORDER BY p.domain, p.name', $p);
        $this->view('pr/index', ['title' => 'Cartographie des processus', 'rows' => $rows, 'domains' => array_column(DB::all("SELECT DISTINCT domain FROM pr_processes WHERE domain IS NOT NULL AND domain<>'' ORDER BY domain"), 'domain')]);
    }
    function export(): void {
        [$w, $p] = $this->visibleSql();
        $rows = DB::all("SELECT p.code, p.name, p.domain, u.name owner, p.status, p.version, p.published_at, p.review_due FROM pr_processes p LEFT JOIN users u ON u.id=p.owner_id WHERE $w ORDER BY p.domain, p.name", $p); Audit::log('export', 'pr_processes', null, null, ['rows' => count($rows)]);
        csv_download('processus.csv', ['Code', 'Processus', 'Domaine', 'Pilote', 'Statut', 'Version', 'Publié le', 'Revue avant le'], array_map(fn($r) => [$r['code'], $r['name'], $r['domain'], $r['owner'], Pr::ST[$r['status']] ?? '', $r['version'], $r['published_at'], $r['review_due']], $rows));
    }
    function mine(): void {
        $this->view('pr/mine', ['title' => 'Mes processus', 'rows' => DB::all('SELECT p.* FROM pr_processes p WHERE p.owner_id=? OR p.created_by=? ORDER BY p.status, p.name', [Auth::id(), Auth::id()]),
            'changes' => DB::all("SELECT c.*, p.name process FROM pr_changes c JOIN pr_processes p ON p.id=c.process_id WHERE p.owner_id=? AND c.status='open' ORDER BY c.id DESC", [Auth::id()])]);
    }
    // ---- Création / édition ----
    private function meta(): array {
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'domain' => ['label' => 'Le domaine', 'max' => 100], 'purpose' => ['label' => 'La finalité', 'max' => 500], 'scope_txt' => ['label' => 'Le périmètre', 'max' => 500], 'inputs' => ['label' => 'Les entrées', 'max' => 500], 'outputs' => ['label' => 'Les sorties', 'max' => 500], 'kpis' => ['label' => 'Les indicateurs', 'max' => 500]], $_POST);
        $m = (int)$this->in('review_months', 12); if ($m < 1 || $m > 60) $err['m'] = 'La périodicité de revue doit être de 1 à 60 mois.';
        $ack = $this->in('ack_required') === '1' ? 1 : 0; $days = (int)$this->in('ack_days', 15); if ($days < 1 || $days > 90) $err['a'] = 'Le délai de lecture doit être de 1 à 90 jours.';
        $valid = array_column(DB::all('SELECT code FROM roles'), 'code'); $roles = array_values(array_intersect((array)($_POST['ack_roles'] ?? []), $valid));
        return [$d + ['review_months' => $m, 'ack_required' => $ack, 'ack_days' => $days, 'ack_roles' => $roles ? implode(',', $roles) : null], $err];
    }
    function create(): void { $this->view('pr/form', ['title' => 'Nouveau processus', 'p' => null, 'owners' => $this->owners(), 'domains' => array_column(DB::all("SELECT DISTINCT domain FROM pr_processes WHERE domain IS NOT NULL AND domain<>'' ORDER BY domain"), 'domain')]); }
    function store(): void {
        [$d, $err] = $this->meta(); $code = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string)$this->in('code', '')));
        if ($code === '' || strlen($code) > 40) $err['c'] = 'Code obligatoire (lettres, chiffres, - et _).'; elseif (DB::val('SELECT 1 FROM pr_processes WHERE code=?', [$code])) $err['c2'] = 'Ce code existe déjà.';
        $owner = Auth::id(); if (can('pr.manage') && ($x = (int)$this->in('owner_id', 0))) { if (!in_array($x, array_map('intval', array_column($this->owners(), 'id')), true)) $err['o'] = 'Pilote non autorisé à rédiger des processus.'; else $owner = $x; }
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('pr/new'); }
        $id = DB::insert('pr_processes', $d + ['code' => $code, 'owner_id' => $owner, 'status' => 'draft', 'version' => 0, 'created_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()]); Audit::log('create', 'pr_process', $id); PrGovController::save((int)$id, $_POST); flash('Processus créé en brouillon : décrivez les étapes.'); redirect("pr/p/$id");
    }
    private function roles(): array { return DB::all('SELECT code, name FROM roles ORDER BY name'); }
    /** Contenu présenté : copie de travail pour les rédacteurs, dernière version approuvée pour les lecteurs. */
    private function present(array $p, bool $live): array {
        $id = (int)$p['id'];
        if ($live || $p['status'] !== 'published' || !($row = Pr::approved($id, (int)$p['version']))) { $steps = DB::all('SELECT * FROM pr_steps WHERE process_id=? ORDER BY position, id', [$id]); return [$p, $steps, DB::all('SELECT * FROM pr_links WHERE process_id=? ORDER BY id', [$id])]; }
        $c = $row['data']; foreach (array_keys(Pr::FIELDS) as $k) if (array_key_exists($k, $c) && $k !== 'owner') $p[$k] = $c[$k];
        $steps = []; foreach (($c['steps'] ?? []) as $i => $st) $steps[] = $st + ['id' => 'v' . $i]; $links = []; foreach (($c['links'] ?? []) as $i => $l) $links[] = $l + ['id' => 'v' . $i];
        return [$p, $steps, $links];
    }
    function show(string $id): void {
        if (!($p = $this->load($id))) return;
        $me = Auth::id(); $ver = (int)$p['version']; $edit = Pr::canEdit($p); $mg = can('pr.manage'); $pending = $p['status'] === 'published' ? Pr::pending((int)$id) : null; $live = $edit || $mg || Pr::isOwner($p);
        $real = $p; [$pv, $steps, $links] = $this->present($p, $live); $dirty = null;
        if ($live && $p['status'] === 'published' && ($ap = Pr::approved((int)$id, $ver)) && !$pending) { $d = Pr::diff($ap['data'], Pr::content((int)$id)); $dirty = $d['changed'] ? $d : null; }
        $edLinks = []; if ($edit) foreach ($steps as $s) $edLinks[(int)$s['id']] = url('pr/p/' . $id) . '#step-' . $s['id'];
        $gov = PrGovController::gov((int)$id); $risks = DB::all('SELECT r.*, u.name owner FROM pr_risks r LEFT JOIN users u ON u.id=r.owner_id WHERE r.process_id=? ORDER BY r.status, r.severity*r.probability DESC, r.id', [(int)$id]); $kpis = DB::all('SELECT k.*, u.name owner FROM pr_kpis k LEFT JOIN users u ON u.id=k.owner_id WHERE k.process_id=? ORDER BY k.active DESC, k.name', [(int)$id]); foreach ($kpis as &$kk) $kk['measures'] = DB::all('SELECT * FROM pr_kpi_measures WHERE kpi_id=? ORDER BY period DESC LIMIT 8', [(int)$kk['id']]); unset($kk);
        $this->view('pr/show', ['gov' => $gov, 'risks' => $risks, 'kpis' => $kpis, 'govUsers' => \App\Core\Itil::users(), 'directions' => Pm::directions(), 'title' => $p['name'], 'p' => $pv, 'edit' => $edit, 'steps' => $steps, 'links' => $links, 'pending' => $pending, 'dirty' => $dirty, 'diagram' => PrDiagram::svg($steps, $edLinks), 'roles' => $this->roles(), 'ackRoles' => array_filter(explode(',', (string)$p['ack_roles'])),
            'unread' => ($p['status'] === 'published' && $p['ack_required'] && ($mg || Pr::isOwner($p))) ? Pr::unread($p) : null, 'audience' => $p['ack_required'] ? count(Pr::audience($p)) : 0, 'mustRead' => $p['status'] === 'published' && $p['ack_required'] && in_array($me, Pr::audience($p), true),
            'versions' => DB::all("SELECT id, version, note, user_name, created_at, state, decision_note FROM pr_versions WHERE process_id=? AND state IN ('approved','pending','rejected') ORDER BY id DESC", [(int)$id]), 'reviews' => DB::all('SELECT r.*, u.name reviewer FROM pr_reviews r LEFT JOIN users u ON u.id=r.reviewer_id WHERE r.process_id=? ORDER BY r.id DESC LIMIT 10', [(int)$id]),
            'read' => (bool)DB::val('SELECT 1 FROM pr_reads WHERE process_id=? AND version=? AND user_id=?', [(int)$id, $ver, $me]), 'nreads' => (int)DB::val('SELECT COUNT(*) FROM pr_reads WHERE process_id=? AND version=?', [(int)$id, $ver]),
            'changes' => DB::all('SELECT c.*, u.name author FROM pr_changes c LEFT JOIN users u ON u.id=c.user_id WHERE c.process_id=? AND (c.user_id=? OR ?) ORDER BY c.id DESC', [(int)$id, $me, ($live) ? 1 : 0]), 'owners' => $this->owners(), 'fourEyes' => (string)setting('pr_four_eyes', '1') === '1',
            'domains' => array_column(DB::all("SELECT DISTINCT domain FROM pr_processes WHERE domain IS NOT NULL AND domain<>'' ORDER BY domain"), 'domain')]);
    }
    function update(string $id): void {
        if (!($p = $this->load($id, true))) return; [$d, $err] = $this->meta(); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("pr/p/$id"); }
        $u = $d + ['updated_at' => now()];
        if (can('pr.manage') && ($x = (int)$this->in('owner_id', 0)) && $x !== (int)$p['owner_id']) { if (!in_array($x, array_map('intval', array_column($this->owners(), 'id')), true)) { flash('Pilote non autorisé à rédiger des processus.', 'danger'); redirect("pr/p/$id"); } $u['owner_id'] = $x; Notifier::send($x, 'Vous êtes pilote d\'un processus', $p['name'], '/pr/p/' . $id); }
        if ($ge = PrGovController::save((int)$id, $_POST)) { flash($ge, 'danger'); redirect("pr/p/$id"); }
        DB::update('pr_processes', $u, 'id=?', [(int)$id]); Audit::log('update', 'pr_process', $id, $p, $u); flash($p['status'] === 'published' ? 'Copie de travail enregistrée : les lecteurs voient toujours la version publiée. Soumettez une nouvelle version pour la diffuser.' : 'Fiche enregistrée.'); redirect("pr/p/$id");
    }
    // ---- Étapes et liens ----
    private function stepData(): array {
        [$d, $err] = $this->validate(['label' => ['label' => 'L\'étape', 'req' => true, 'max' => 300], 'role' => ['label' => 'Le rôle', 'max' => 150], 'tool' => ['label' => 'L\'outil', 'max' => 150], 'description' => ['label' => 'La description', 'max' => 500], 'goto_label' => ['label' => 'Le libellé du renvoi', 'max' => 100]], $_POST);
        $kind = (string)$this->in('kind', 'task'); if (!isset(PrDiagram::KINDS[$kind])) $err['k'] = 'Type d\'étape invalide.';
        $g = trim((string)$this->in('goto_pos', '')); if ($g !== '' && (!ctype_digit($g) || (int)$g < 1 || (int)$g > 999)) $err['g'] = 'Le renvoi doit désigner un numéro d\'étape.';
        return [$d + ['kind' => $kind, 'goto_pos' => $g === '' ? null : (int)$g, 'goto_label' => $d['goto_label'] ?: null], $err];
    }
    function storeStep(string $id): void {
        if (!($p = $this->load($id, true))) return; [$d, $err] = $this->stepData(); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("pr/p/$id"); }
        DB::insert('pr_steps', $d + ['process_id' => (int)$id, 'position' => (int)DB::val('SELECT COALESCE(MAX(position),0) FROM pr_steps WHERE process_id=?', [(int)$id]) + 1]); DB::update('pr_processes', ['updated_at' => now()], 'id=?', [(int)$id]); redirect("pr/p/$id");
    }
    function updateStep(string $id, string $sid): void {
        if (!($p = $this->load($id, true))) return; $s = DB::one('SELECT * FROM pr_steps WHERE id=? AND process_id=?', [(int)$sid, (int)$id]); if (!$s) { $this->notFound(); return; }
        [$d, $err] = $this->stepData(); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("pr/p/$id"); } $pos = (int)$this->in('position', $s['position']); if ($pos < 1 || $pos > 999) $pos = (int)$s['position'];
        DB::update('pr_steps', $d + ['position' => $pos], 'id=?', [(int)$sid]); DB::update('pr_processes', ['updated_at' => now()], 'id=?', [(int)$id]); redirect("pr/p/$id");
    }
    function deleteStep(string $id, string $sid): void { if (!($p = $this->load($id, true))) return; DB::exec('DELETE FROM pr_steps WHERE id=? AND process_id=?', [(int)$sid, (int)$id]); DB::update('pr_processes', ['updated_at' => now()], 'id=?', [(int)$id]); redirect("pr/p/$id"); }
    function storeLink(string $id): void {
        if (!($p = $this->load($id, true))) return; $t = mb_substr(trim((string)$this->in('title', '')), 0, 190); $u = trim((string)$this->in('url', ''));
        if ($t === '' || !preg_match('#^https://[^\s<>"\']{3,480}$#i', $u) || !filter_var($u, FILTER_VALIDATE_URL)) { flash('Titre et lien https valide obligatoires.', 'danger'); redirect("pr/p/$id"); }
        DB::insert('pr_links', ['process_id' => (int)$id, 'title' => $t, 'url' => $u]); redirect("pr/p/$id");
    }
    function deleteLink(string $id, string $lid): void { if (!($p = $this->load($id, true))) return; DB::exec('DELETE FROM pr_links WHERE id=? AND process_id=?', [(int)$lid, (int)$id]); redirect("pr/p/$id"); }
    // ---- Circuit de validation ----
    function status(string $id): void {
        if (!($p = $this->load($id))) return; $a = (string)$this->in('action'); $note = mb_substr(trim((string)$this->in('note', '')), 0, 500); $mg = can('pr.manage'); $edit = Pr::canEdit($p); $owner = Pr::isOwner($p);
        $pend = $p['status'] === 'published' ? Pr::pending((int)$id) : null;
        if ($a === 'submit' && $edit && $p['status'] === 'draft') {
            $miss = []; if (!trim((string)$p['purpose'])) $miss[] = 'la finalité'; if (!$p['owner_id']) $miss[] = 'le pilote'; if (!DB::val('SELECT 1 FROM pr_steps WHERE process_id=?', [(int)$id])) $miss[] = 'au moins une étape';
            if ($miss) { flash('Complétez avant de soumettre : ' . implode(', ', $miss) . '.', 'danger'); redirect("pr/p/$id"); }
            DB::update('pr_processes', ['status' => 'in_review', 'updated_at' => now()], 'id=?', [(int)$id]); Notifier::toPermission('pr.manage', 'Processus à relire', $p['name'], '/pr/p/' . $id); $m = 'Soumis à la relecture.';
        } elseif ($a === 'publish' && $mg && in_array($p['status'], ['draft', 'in_review'], true)) {
            if (!trim((string)$p['purpose']) || !DB::val('SELECT 1 FROM pr_steps WHERE process_id=?', [(int)$id])) { flash('Finalité et au moins une étape sont requises.', 'danger'); redirect("pr/p/$id"); }
            if (!Pr::fourEyesOk([(int)$p['created_by'], (int)$p['owner_id']])) { flash('Double validation : la publication doit être faite par un gestionnaire autre que le rédacteur ou le pilote.', 'danger'); redirect("pr/p/$id"); }
            $v = Pr::release($p, $note ?: 'Première publication'); if ($p['owner_id'] && !$owner) Notifier::send((int)$p['owner_id'], 'Processus publié', $p['name'] . ' · version ' . $v, '/pr/p/' . $id); $m = "Publié en version $v ; prochaine revue le " . d(DB::val('SELECT review_due FROM pr_processes WHERE id=?', [(int)$id])) . '.';
        } elseif ($a === 'reject' && $mg && $p['status'] === 'in_review') {
            if ($note === '') { flash('Indiquez ce qui doit être corrigé.', 'danger'); redirect("pr/p/$id"); }
            DB::update('pr_processes', ['status' => 'draft', 'update_note' => $note], 'id=?', [(int)$id]); if ($p['owner_id']) Notifier::send((int)$p['owner_id'], 'Processus renvoyé', $p['name'] . ' : ' . mb_substr($note, 0, 100), '/pr/p/' . $id); $m = 'Renvoyé au pilote.';
        } elseif ($a === 'version' && $p['status'] === 'published' && !$pend && ($owner || $mg)) {
            if ($note === '') { flash('Décrivez les changements de cette version.', 'danger'); redirect("pr/p/$id"); }
            if (!DB::val('SELECT 1 FROM pr_steps WHERE process_id=?', [(int)$id])) { flash('Au moins une étape est requise.', 'danger'); redirect("pr/p/$id"); }
            $cur = Pr::approved((int)$id, (int)$p['version']); if ($cur && !Pr::diff($cur['data'], Pr::content((int)$id))['changed']) { flash('Aucune différence avec la version publiée.', 'warning'); redirect("pr/p/$id"); }
            DB::insert('pr_versions', ['process_id' => (int)$id, 'version' => (int)$p['version'] + 1, 'snapshot' => Pr::snapshot((int)$id), 'note' => $note, 'user_id' => Auth::id(), 'user_name' => (string)DB::val('SELECT name FROM users WHERE id=?', [Auth::id()]), 'created_at' => now(), 'state' => 'pending']);
            Notifier::toPermission('pr.manage', 'Version de processus à valider', $p['name'] . ' · v' . ((int)$p['version'] + 1) . ' : ' . mb_substr($note, 0, 80), '/pr/p/' . $id); $m = 'Version proposée : elle sera diffusée après validation par un gestionnaire. La copie de travail est gelée d\'ici là.';
        } elseif ($a === 'approve' && $mg && $pend) {
            if (!Pr::fourEyesOk([(int)$pend['user_id']])) { flash('Double validation : un autre gestionnaire que l\'auteur de la version doit la valider.', 'danger'); redirect("pr/p/$id"); }
            $v = Pr::release($p, $note, $pend); if ($pend['user_id'] && (int)$pend['user_id'] !== Auth::id()) Notifier::send((int)$pend['user_id'], 'Version de processus validée', $p['name'] . ' · v' . $v, '/pr/p/' . $id); $m = "Version $v validée et publiée.";
        } elseif ($a === 'decline' && $mg && $pend) {
            if ($note === '') { flash('Indiquez le motif du refus.', 'danger'); redirect("pr/p/$id"); }
            DB::update('pr_versions', ['state' => 'rejected', 'decided_by' => Auth::id(), 'decided_at' => now(), 'decision_note' => $note], 'id=?', [(int)$pend['id']]); if ($pend['user_id']) Notifier::send((int)$pend['user_id'], 'Version de processus refusée', $p['name'] . ' : ' . mb_substr($note, 0, 100), '/pr/p/' . $id); $m = 'Version refusée : la copie de travail est de nouveau modifiable.';
        } elseif ($a === 'cancel_version' && $pend && ($owner || $mg || (int)$pend['user_id'] === Auth::id())) { DB::update('pr_versions', ['state' => 'cancelled', 'decided_by' => Auth::id(), 'decided_at' => now()], 'id=?', [(int)$pend['id']]); $m = 'Proposition retirée.'; }
        elseif ($a === 'archive' && $mg && $p['status'] === 'published') { DB::update('pr_processes', ['status' => 'archived', 'review_due' => null, 'ack_deadline' => null], 'id=?', [(int)$id]); $m = 'Processus archivé.'; }
        elseif ($a === 'reopen' && $mg && $p['status'] === 'archived') { DB::update('pr_processes', ['status' => 'draft'], 'id=?', [(int)$id]); $m = 'Processus rouvert en brouillon.'; }
        else { $this->forbidden(); return; }
        Audit::log($a, 'pr_process', $id, ['status' => $p['status']]); flash($m); redirect("pr/p/$id");
    }
    function version(string $id, string $v): void {
        if (!($p = $this->load($id))) return; $r = Pr::approved((int)$id, (int)$v); if (!$r) { $this->notFound(); return; }
        $this->view('pr/version', ['title' => $p['name'] . ' · v' . (int)$v, 'p' => $p, 'r' => $r, 's' => $r['data'], 'diagram' => PrDiagram::svg(array_map(fn($st, $i) => $st + ['id' => 'v' . $i], $r['data']['steps'] ?? [], array_keys($r['data']['steps'] ?? [])))]);
    }
    /** Contenu d'une référence de comparaison : numéro de version approuvée, « pending » (proposée) ou « work » (copie de travail). */
    private function ref(array $p, string $ref): ?array {
        $priv = Pr::canEdit($p) || can('pr.manage') || Pr::isOwner($p);
        if ($ref === 'work') return $priv ? ['label' => 'copie de travail', 'data' => Pr::content((int)$p['id'])] : null;
        if ($ref === 'pending') { $r = Pr::pending((int)$p['id']); return ($r && $priv) ? ['label' => 'version proposée v' . $r['version'], 'data' => json_decode((string)$r['snapshot'], true) ?: []] : null; }
        if (!ctype_digit($ref)) return null; $r = Pr::approved((int)$p['id'], (int)$ref); return $r ? ['label' => 'version ' . (int)$ref, 'data' => $r['data']] : null;
    }
    function compare(string $id): void {
        if (!($p = $this->load($id))) return; $a = $this->ref($p, (string)$this->in('a', '')); $b = $this->ref($p, (string)$this->in('b', ''));
        if (!$a || !$b) { $this->notFound(); return; }
        $this->view('pr/compare', ['title' => 'Comparaison · ' . $p['name'], 'p' => $p, 'a' => $a, 'b' => $b, 'd' => Pr::diff($a['data'], $b['data']), 'versions' => DB::all("SELECT DISTINCT version FROM pr_versions WHERE process_id=? AND state='approved' ORDER BY version DESC", [(int)$id])]);
    }
    private function stepsFor(array $p, string $ref): ?array {
        if ($ref === 'work') { if (!(Pr::canEdit($p) || can('pr.manage') || Pr::isOwner($p))) return null; return DB::all('SELECT * FROM pr_steps WHERE process_id=? ORDER BY position, id', [(int)$p['id']]); }
        $r = Pr::approved((int)$p['id'], ctype_digit($ref) ? (int)$ref : (int)$p['version']); if (!$r) return null;
        return array_map(fn($st, $i) => $st + ['id' => 'v' . $i], $r['data']['steps'] ?? [], array_keys($r['data']['steps'] ?? []));
    }
    function diagram(string $id): void {
        if (!($p = $this->load($id))) return; $steps = $this->stepsFor($p, (string)$this->in('v', (Pr::canEdit($p) || can('pr.manage')) && $p['status'] !== 'published' ? 'work' : (string)$p['version'])); if ($steps === null) { $this->notFound(); return; }
        $fmt = (string)$this->in('format', 'svg'); $base = preg_replace('/[^A-Za-z0-9_-]/', '_', (string)$p['code']);
        header('X-Content-Type-Options: nosniff'); header("Content-Security-Policy: sandbox; default-src 'none'; style-src 'unsafe-inline'");
        if ($fmt === 'bpmn') { header('Content-Type: application/xml; charset=utf-8'); header('Content-Disposition: attachment; filename="' . $base . '.bpmn"'); Audit::log('export', 'pr_diagram', $id); echo PrDiagram::bpmn((string)$p['name'], $steps); exit; }
        header('Content-Type: image/svg+xml; charset=utf-8'); header('Content-Disposition: inline; filename="' . $base . '.svg"'); echo PrDiagram::svg($steps); exit;
    }
    function todo(): void {
        $this->view('pr/todo', ['title' => 'Processus à lire', 'rows' => Pr::todo(Auth::id())]);
    }
    // ---- Lecture, revue périodique, changements ----
    function ack(string $id): void {
        if (!($p = $this->load($id))) return; if ($p['status'] !== 'published') { flash('Seule une version publiée peut être lue.', 'warning'); redirect("pr/p/$id"); }
        if (!DB::val('SELECT 1 FROM pr_reads WHERE process_id=? AND version=? AND user_id=?', [(int)$id, (int)$p['version'], Auth::id()])) DB::insert('pr_reads', ['process_id' => (int)$id, 'version' => (int)$p['version'], 'user_id' => Auth::id(), 'read_at' => now()]);
        flash('Prise de connaissance enregistrée.'); redirect("pr/p/$id");
    }
    function review(string $id): void {
        if (!($p = $this->load($id))) return; if ($p['status'] !== 'published' || !(Pr::isOwner($p) || can('pr.manage'))) { $this->forbidden(); return; }
        $o = (string)$this->in('outcome'); $c = mb_substr(trim((string)$this->in('comment', '')), 0, 500); $months = max(1, min(60, (int)$p['review_months'] ?: 12));
        if ($o === 'confirmed') {
            $next = Pr::dueFrom(date('Y-m-d'), $months); DB::insert('pr_reviews', ['process_id' => (int)$id, 'reviewer_id' => Auth::id(), 'outcome' => 'confirmed', 'comment' => $c ?: null, 'version' => (int)$p['version'], 'reviewed_at' => now(), 'next_due' => $next]);
            DB::update('pr_processes', ['review_due' => $next, 'review_prealert_at' => null, 'review_notified_at' => null, 'needs_update' => 0, 'update_note' => null], 'id=?', [(int)$id]); $m = 'Revue enregistrée : processus confirmé, prochaine revue le ' . d($next) . '.';
        } elseif ($o === 'update_needed') {
            if ($c === '') { flash('Précisez ce qui doit évoluer.', 'danger'); redirect("pr/p/$id"); }
            DB::insert('pr_reviews', ['process_id' => (int)$id, 'reviewer_id' => Auth::id(), 'outcome' => 'update_needed', 'comment' => $c, 'version' => (int)$p['version'], 'reviewed_at' => now(), 'next_due' => $p['review_due']]);
            DB::update('pr_processes', ['needs_update' => 1, 'update_note' => $c], 'id=?', [(int)$id]); if ($p['owner_id'] && !Pr::isOwner($p)) Notifier::send((int)$p['owner_id'], 'Processus à mettre à jour', $p['name'] . ' : ' . mb_substr($c, 0, 100), '/pr/p/' . $id); $m = 'Mise à jour demandée : l\'échéance reste en vigueur jusqu\'à la nouvelle version.';
        } else { flash('Choix invalide.', 'danger'); redirect("pr/p/$id"); }
        Audit::log('review', 'pr_process', $id, null, ['outcome' => $o]); flash($m); redirect("pr/p/$id");
    }
    function storeChange(string $id): void {
        if (!($p = $this->load($id))) return; if ($p['status'] !== 'published') { flash('Les demandes portent sur un processus publié.', 'warning'); redirect("pr/p/$id"); }
        $t = mb_substr(trim((string)$this->in('title', '')), 0, 190); $d = mb_substr(trim((string)$this->in('description', '')), 0, 1000); if ($t === '') { flash('Objet obligatoire.', 'danger'); redirect("pr/p/$id"); }
        $cid = DB::insert('pr_changes', ['process_id' => (int)$id, 'user_id' => Auth::id(), 'title' => $t, 'description' => $d ?: null, 'status' => 'open', 'created_at' => now()]);
        if ($p['owner_id']) Notifier::send((int)$p['owner_id'], 'Demande de changement de processus', $p['name'] . ' : ' . $t, '/pr/p/' . $id); else Notifier::toPermission('pr.manage', 'Demande de changement de processus', $p['name'] . ' : ' . $t, '/pr/p/' . $id);
        Audit::log('create', 'pr_change', $cid); flash('Demande transmise au pilote.'); redirect("pr/p/$id");
    }
    function handleChange(string $cid): void {
        $c = DB::one('SELECT * FROM pr_changes WHERE id=?', [(int)$cid]); if (!$c) { $this->notFound(); return; } $p = DB::one('SELECT * FROM pr_processes WHERE id=?', [(int)$c['process_id']]);
        if (!$p || !(Pr::isOwner($p) || can('pr.manage'))) { $this->forbidden(); return; }
        $st = (string)$this->in('status'); $resp = mb_substr(trim((string)$this->in('response', '')), 0, 500);
        if (!in_array($st, ['accepted', 'rejected', 'done'], true) || ($st === 'rejected' && $resp === '')) { flash('Statut invalide ou motif de refus manquant.', 'danger'); redirect('pr/p/' . $p['id']); }
        DB::update('pr_changes', ['status' => $st, 'response' => $resp ?: null, 'handled_by' => Auth::id(), 'handled_at' => now()], 'id=?', [(int)$cid]);
        if ($c['user_id']) Notifier::send((int)$c['user_id'], 'Votre demande de changement', $p['name'] . ' : ' . Pr::CH[$st], '/pr/p/' . $p['id']); Audit::log('handle', 'pr_change', $cid, null, ['status' => $st]); redirect('pr/p/' . $p['id']);
    }
    function changes(): void {
        $this->view('pr/changes', ['title' => 'Demandes de changement', 'rows' => DB::all("SELECT c.*, p.name process, p.id pid, u.name author FROM pr_changes c JOIN pr_processes p ON p.id=c.process_id LEFT JOIN users u ON u.id=c.user_id WHERE c.status='open' ORDER BY c.id")]);
    }
    // ---- Pilotage ----
    private function overdue(): array {
        $out = []; foreach (DB::all("SELECT * FROM pr_processes WHERE status='published' AND ack_required=1 AND ack_deadline<? ORDER BY ack_deadline", [date('Y-m-d')]) as $p) { $m = count(Pr::unread($p)); if ($m) $out[] = $p + ['missing' => $m]; }
        return $out;
    }
    function dashboard(): void {
        $t = date('Y-m-d'); $soon = date('Y-m-d', strtotime('+30 days'));
        $by = DB::all("SELECT status, COUNT(*) n FROM pr_processes GROUP BY status"); $cnt = []; foreach ($by as $r) $cnt[$r['status']] = (int)$r['n'];
        $pub = "p.status='published'";
        $this->view('pr/dashboard', ['title' => 'Pilotage des processus', 'cnt' => $cnt,
            'late' => DB::all("SELECT p.*, u.name owner FROM pr_processes p LEFT JOIN users u ON u.id=p.owner_id WHERE $pub AND p.review_due<? ORDER BY p.review_due", [$t]),
            'soon' => DB::all("SELECT p.*, u.name owner FROM pr_processes p LEFT JOIN users u ON u.id=p.owner_id WHERE $pub AND p.review_due>=? AND p.review_due<=? ORDER BY p.review_due", [$t, $soon]),
            'upd' => DB::all("SELECT p.*, u.name owner FROM pr_processes p LEFT JOIN users u ON u.id=p.owner_id WHERE $pub AND p.needs_update=1 ORDER BY p.name"),
            'review' => DB::all("SELECT p.*, u.name owner FROM pr_processes p LEFT JOIN users u ON u.id=p.owner_id WHERE p.status='in_review' ORDER BY p.updated_at"),
            'noowner' => (int)DB::val("SELECT COUNT(*) FROM pr_processes WHERE status<>'archived' AND owner_id IS NULL"), 'openChanges' => (int)DB::val("SELECT COUNT(*) FROM pr_changes WHERE status='open'"),
            'domains' => DB::all("SELECT COALESCE(NULLIF(domain,''),'Sans domaine') d, COUNT(*) n, SUM(CASE WHEN status='published' THEN 1 ELSE 0 END) pub, SUM(CASE WHEN status='published' AND review_due<? THEN 1 ELSE 0 END) late FROM pr_processes WHERE status<>'archived' GROUP BY COALESCE(NULLIF(domain,''),'Sans domaine') ORDER BY d", [$t]),
            'overdue' => $this->overdue(), 'pend' => DB::all("SELECT p.id, p.name, v.version, v.user_name FROM pr_versions v JOIN pr_processes p ON p.id=v.process_id WHERE v.state='pending' ORDER BY v.id"),
            'reads' => DB::all("SELECT p.id, p.name, p.version, (SELECT COUNT(*) FROM pr_reads r WHERE r.process_id=p.id AND r.version=p.version) n FROM pr_processes p WHERE $pub ORDER BY n ASC, p.name LIMIT 10")]);
    }
}
