<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Cs};

/** Module « Fins d'appel » : référentiel des codes de clôture, indépendant de la bibliothèque de scripts. */
class EocController extends Controller {
    private const COLS = ['code', 'label', 'category', 'counts_fcr', 'needs_note', 'needs_callback', 'acw_target_sec', 'color', 'sort_order', 'active', 'description'];

    function index(): void {
        $w = ['1=1']; $p = [];
        if ($q = trim((string)$this->in('q', ''))) { $w[] = '(k.code LIKE ? OR k.label LIKE ? OR k.description LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        if (($c = (string)$this->in('category', '')) !== '' && isset(Cs::CAT[$c])) { $w[] = 'k.category=?'; $p[] = $c; }
        $st = (string)$this->in('state', ''); if ($st === 'active') $w[] = 'k.active=1'; elseif ($st === 'inactive') $w[] = 'k.active=0';
        if (!can('eoc.manage')) $w[] = 'k.active=1';
        $sql = 'SELECT k.*, (SELECT COUNT(*) FROM cs_checks c WHERE c.end_code_id=k.id) n, s.title script FROM cs_end_codes k LEFT JOIN cs_scripts s ON s.id=k.closing_script_id WHERE ' . implode(' AND ', $w) . ' ORDER BY k.sort_order, k.label';
        if ($this->in('export') === 'csv' && can('eoc.view')) $this->export(DB::all($sql, $p));
        $pg = paginate('cs_end_codes k LEFT JOIN cs_scripts s ON s.id=k.closing_script_id WHERE ' . implode(' AND ', $w), $p, $this->page(), 25, 'k.*, (SELECT COUNT(*) FROM cs_checks c WHERE c.end_code_id=k.id) n, s.title script', 'k.sort_order, k.label');
        $this->view('eoc/index', ['title' => 'Fins d\'appel', 'rows' => $pg['rows'], 'p' => $pg, 'q' => $q, 'category' => $c, 'state' => $st,
            'kpi' => ['total' => (int)DB::val('SELECT COUNT(*) FROM cs_end_codes'), 'active' => (int)DB::val('SELECT COUNT(*) FROM cs_end_codes WHERE active=1'), 'fcr' => (int)DB::val('SELECT COUNT(*) FROM cs_end_codes WHERE active=1 AND counts_fcr=1'), 'noscript' => (int)DB::val('SELECT COUNT(*) FROM cs_end_codes WHERE active=1 AND closing_script_id IS NULL')]]);
    }
    private function export(array $rows): never {
        csv_download('fins_d_appel.csv', ['code', 'libelle', 'categorie', 'fcr', 'commentaire_exige', 'rappel', 'acw_cible_sec', 'couleur', 'ordre', 'actif', 'description'],
            array_map(fn($k) => [$k['code'], $k['label'], $k['category'], $k['counts_fcr'], $k['needs_note'], $k['needs_callback'], $k['acw_target_sec'], $k['color'], $k['sort_order'], $k['active'], $k['description']], $rows));
    }
    function legacy(): void { redirect('eoc'); }
    function create(): void { $this->view('eoc/form', ['title' => 'Nouveau code de fin d\'appel', 'k' => [], 'scripts' => $this->scripts()]); }
    function edit(string $id): void {
        $k = DB::one('SELECT * FROM cs_end_codes WHERE id=?', [(int)$id]); if (!$k) { $this->notFound(); return; }
        $this->view('eoc/form', ['title' => 'Modifier ' . $k['code'], 'k' => $k, 'scripts' => $this->scripts()]);
    }
    private function scripts(): array { return DB::all("SELECT id, ref, title FROM cs_scripts WHERE status='published' ORDER BY title"); }
    function show(string $id): void {
        $k = DB::one('SELECT k.*, s.title script, s.ref sref FROM cs_end_codes k LEFT JOIN cs_scripts s ON s.id=k.closing_script_id WHERE k.id=?', [(int)$id]); if (!$k || (!$k['active'] && !can('eoc.manage'))) { $this->notFound(); return; }
        $this->view('eoc/show', ['title' => $k['code'] . ' · ' . $k['label'], 'k' => $k,
            'use' => DB::one('SELECT COUNT(*) n, AVG(acw_seconds) acw, SUM(CASE WHEN expected_code_id IS NOT NULL AND expected_code_id<>end_code_id THEN 1 ELSE 0 END) wrong FROM cs_checks WHERE end_code_id=?', [(int)$id]),
            'missed' => (int)DB::val('SELECT COUNT(*) FROM cs_checks WHERE expected_code_id=? AND (end_code_id IS NULL OR end_code_id<>expected_code_id)', [(int)$id]),
            'recent' => DB::all('SELECT c.id, c.created_at, c.acw_seconds, c.result, e.first_name, e.last_name FROM cs_checks c JOIN employees e ON e.id=c.employee_id WHERE c.end_code_id=? ORDER BY c.id DESC LIMIT 8', [(int)$id])]);
    }
    /** Valide et prépare une ligne ; retourne [données, erreurs]. */
    private function clean(array $in, ?int $id): array {
        [$d, $err] = $this->validate(['code' => ['label' => 'Le code', 'req' => true, 'max' => 40], 'label' => ['label' => 'Le libellé', 'req' => true, 'max' => 150], 'description' => ['label' => 'La description', 'max' => 300], 'color' => ['label' => 'La couleur', 'max' => 20]], $in);
        if ($d['code'] && !preg_match('/^[A-Za-z0-9_-]+$/', $d['code'])) $err['code'] = 'Code : lettres, chiffres, - et _ uniquement.';
        if ($d['code'] && DB::val('SELECT 1 FROM cs_end_codes WHERE code=? AND id<>?', [$d['code'], (int)$id])) $err['code'] = 'Ce code existe déjà.';
        if ($d['color'] && !preg_match('/^#[0-9A-Fa-f]{6}$/', $d['color'])) $err['color'] = 'Couleur invalide (ex. #2E8B57).';
        $d['category'] = (string)($in['category'] ?? 'resolved'); if (!isset(Cs::CAT[$d['category']])) $err['category'] = 'Catégorie inconnue.';
        $acw = trim((string)($in['acw_target_sec'] ?? '')); if ($acw !== '' && (!ctype_digit($acw) || (int)$acw > 3600)) $err['acw'] = 'Durée cible invalide (secondes).'; $d['acw_target_sec'] = $acw !== '' ? (int)$acw : null;
        $cs = (int)($in['closing_script_id'] ?? 0); $d['closing_script_id'] = $cs && DB::val('SELECT 1 FROM cs_scripts WHERE id=?', [$cs]) ? $cs : null;
        foreach (['counts_fcr', 'needs_note', 'needs_callback'] as $f) $d[$f] = !empty($in[$f]) ? 1 : 0;
        $d['active'] = array_key_exists('active', $in) ? (!empty($in['active']) ? 1 : 0) : 1; $d['sort_order'] = max(0, min(9999, (int)($in['sort_order'] ?? 0)));
        return [$d, $err];
    }
    function save(?string $id = null): void {
        $old = $id ? DB::one('SELECT * FROM cs_end_codes WHERE id=?', [(int)$id]) : null; if ($id && !$old) { $this->notFound(); return; }
        $in = $_POST; if (!$old) $in['active'] = 1;
        [$d, $err] = $this->clean($in, $id ? (int)$id : null);
        if ($err) { $_SESSION['_old'] = $_POST; $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect($id ? "eoc/$id/edit" : 'eoc/new'); }
        if ($old) { DB::update('cs_end_codes', $d, 'id=?', [(int)$id]); Audit::log('update', 'cs_end_code', $id, $old, $d); $nid = (int)$id; }
        else { $nid = DB::insert('cs_end_codes', $d); Audit::log('create', 'cs_end_code', $nid, null, $d); }
        flash('Code enregistré.'); redirect("eoc/$nid");
    }
    function toggle(string $id): void {
        $k = DB::one('SELECT * FROM cs_end_codes WHERE id=?', [(int)$id]); if (!$k) { $this->notFound(); return; }
        DB::update('cs_end_codes', ['active' => $k['active'] ? 0 : 1], 'id=?', [(int)$id]); Audit::log('update', 'cs_end_code', $id, $k, ['active' => $k['active'] ? 0 : 1]);
        flash($k['active'] ? 'Code désactivé.' : 'Code réactivé.'); redirect('eoc');
    }
    function delete(string $id): void {
        $k = DB::one('SELECT * FROM cs_end_codes WHERE id=?', [(int)$id]); if (!$k) { $this->notFound(); return; }
        if (DB::val('SELECT 1 FROM cs_checks WHERE end_code_id=? OR expected_code_id=?', [(int)$id, (int)$id])) { flash('Ce code est utilisé par des contrôles : désactivez-le plutôt que de le supprimer.', 'danger'); redirect("eoc/$id"); }
        DB::exec('DELETE FROM cs_end_codes WHERE id=?', [(int)$id]); Audit::log('delete', 'cs_end_code', $id, $k, null); flash('Code supprimé.'); redirect('eoc');
    }
    function template(): void {
        csv_download('modele-codes-fin-appel.csv', ['code', 'libelle', 'categorie', 'fcr', 'commentaire_exige', 'rappel', 'acw_cible_sec', 'couleur', 'ordre', 'actif', 'description'],
            [['RESOLU', 'Demande résolue', 'resolu', 1, 0, 0, 30, '#198754', 10, 1, 'Le client est satisfait, aucun rappel nécessaire.'], ['RAPPEL', 'Rappel client programmé', 'suivi', 0, 1, 1, 45, '#FFCE00', 20, 1, 'Un rappel est planifié.']]);
    }
    function importForm(): void { $this->view('eoc/import', ['title' => 'Importer des codes de fin d\'appel']); }
    function import(): void {
        $f = $_FILES['file'] ?? null; if (!$f || $f['error'] !== UPLOAD_ERR_OK || $f['size'] > 2 * 1048576) { flash('Choisissez un fichier CSV (2 Mo maximum).', 'danger'); redirect('eoc/import'); }
        $txt = preg_replace('/^\xEF\xBB\xBF/', '', (string)file_get_contents($f['tmp_name'])); $lines = preg_split('/\r\n|\n|\r/', trim($txt)); if (count($lines) < 2) { flash('Fichier vide.', 'danger'); redirect('eoc/import'); }
        $sep = substr_count($lines[0], ';') >= substr_count($lines[0], ',') ? ';' : ','; $head = array_map(fn($h) => strtolower(trim($h)), str_getcsv($lines[0], $sep));
        $map = ['libelle' => 'label', 'label' => 'label', 'code' => 'code', 'categorie' => 'category', 'category' => 'category', 'fcr' => 'counts_fcr', 'commentaire_exige' => 'needs_note', 'rappel' => 'needs_callback', 'acw_cible_sec' => 'acw_target_sec', 'couleur' => 'color', 'ordre' => 'sort_order', 'actif' => 'active', 'description' => 'description'];
        if (!in_array('code', $head, true) || !(in_array('libelle', $head, true) || in_array('label', $head, true))) { flash('Colonnes obligatoires : code et libelle.', 'danger'); redirect('eoc/import'); }
        $dry = !$this->in('apply'); $ok = $upd = 0; $errs = []; $rev = array_flip(array_map('mb_strtolower', Cs::CAT));
        foreach (array_slice($lines, 1) as $i => $ln) { if (trim($ln) === '') continue; $cells = str_getcsv($ln, $sep); $row = [];
            foreach ($head as $j => $h) if (isset($map[$h])) $row[$map[$h]] = trim($cells[$j] ?? '');
            if (isset($row['category'])) { $lc = mb_strtolower($row['category']); $row['category'] = $rev[$lc] ?? $row['category']; if ($row['category'] === '') $row['category'] = 'resolved'; }
            foreach (['counts_fcr', 'needs_note', 'needs_callback', 'active'] as $b) if (isset($row[$b])) $row[$b] = in_array(mb_strtolower($row[$b]), ['1', 'oui', 'o', 'yes', 'true', 'x'], true) ? 1 : 0;
            $ex = DB::one('SELECT * FROM cs_end_codes WHERE code=?', [$row['code'] ?? '']);
            if ($ex) { $row += ['closing_script_id' => $ex['closing_script_id']]; foreach (self::COLS as $c) if (!array_key_exists($c, $row)) $row[$c] = $ex[$c]; $row['closing_script_id'] = $ex['closing_script_id']; }
            [$d, $err] = $this->clean($row, $ex ? (int)$ex['id'] : null);
            if ($err) { $errs[] = 'Ligne ' . ($i + 2) . ' : ' . implode(' ', $err); continue; }
            if (!$dry) { if ($ex) { DB::update('cs_end_codes', $d, 'id=?', [(int)$ex['id']]); Audit::log('update', 'cs_end_code', $ex['id'], $ex, $d); } else { Audit::log('create', 'cs_end_code', DB::insert('cs_end_codes', $d), null, $d); } }
            $ex ? $upd++ : $ok++; }
        flash(($dry ? 'Simulation : ' : 'Importé : ') . "$ok création(s), $upd mise(s) à jour" . ($errs ? ', ' . count($errs) . ' erreur(s) — ' . implode(' | ', array_slice($errs, 0, 5)) : '') . '.', $errs ? 'warning' : 'success'); redirect($dry ? 'eoc/import' : 'eoc');
    }
}
