<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, ELearn, Files, RichHtml, Notifier, Xchg, Scope};

/** Lot 48 : parcours apprenant (quiz de partie, activités, questions au formateur, catalogue, demandes) et traitement par les formateurs. */
class ElLearnController extends Controller {
    private function enr(string $eid): ?array {
        $e = DB::one('SELECT en.*, c.title, c.pass_pct, c.sequential, c.level, c.domain, c.id cid, c.status course_status FROM el_enrollments en JOIN el_courses c ON c.id=en.course_id WHERE en.id=?', [(int)$eid]);
        if (!$e || (int)$e['user_id'] !== (int)Auth::id()) { $this->notFound(); return null; }
        if ($e['course_status'] !== 'published') { flash('Ce cours n\'est pas disponible pour le moment.', 'warning'); redirect('learn'); }
        if ($m = ELearn::missingPrereqs((int)$e['cid'], Auth::id())) { flash('Prérequis à réussir d\'abord : ' . implode(', ', $m) . '.', 'warning'); redirect("learn/$eid"); }
        if ($m = ELearn::levelMissing(['id' => $e['cid'], 'level' => $e['level'], 'domain' => $e['domain']], Auth::id())) { flash('Niveau verrouillé : validez d\'abord ' . implode(', ', $m) . '.', 'warning'); redirect("learn/$eid"); }
        return $e;
    }
    private function open(array $e): void { if ($e['status'] === 'assigned') DB::update('el_enrollments', ['status' => 'in_progress', 'started_at' => now()], 'id=?', [(int)$e['id']]); }
    private function access(array $e, string $key): void { if (!ELearn::canAccess((int)$e['id'], ['id' => $e['cid'], 'sequential' => $e['sequential']], $key)) { flash('Cette étape se débloque après avoir terminé les étapes précédentes.', 'warning'); redirect('learn/' . $e['id']); } }
    private function nextOf(array $e, string $key): string { $st = ELearn::steps((int)$e['cid']); foreach ($st as $k => $x) if ($x['key'] === $key && isset($st[$k + 1])) return ELearnController::stepUrl($e['id'], $st[$k + 1]); return 'learn/' . $e['id']; }

    // ---------- quiz de partie ----------
    private function nodeOf(array $e, string $nid): ?array { $n = DB::one('SELECT * FROM el_lessons WHERE id=? AND course_id=?', [(int)$nid, (int)$e['cid']]); if (!$n || !DB::val('SELECT 1 FROM el_questions WHERE node_id=?', [(int)$nid])) { $this->notFound(); return null; } return $n; }
    function nodeQuiz(string $eid, string $nid): void {
        if (!($e = $this->enr($eid)) || !($n = $this->nodeOf($e, $nid))) return; $this->access($e, 'q' . $nid);
        $qs = ELearn::shuffle(ELearn::questions((int)$e['cid'], false, null, (int)$nid), (int)$eid + (int)$nid); foreach ($qs as &$q) $q['options'] = ELearn::shuffle($q['options'], (int)$eid + (int)$q['id']);
        $this->view('learn/nodequiz', ['title' => 'Quiz : ' . $n['title'], 'e' => $e, 'n' => $n, 'qs' => $qs, 'res' => null, 'pass' => (int)($n['quiz_pass_pct'] ?: $e['pass_pct']), 'passed' => isset(ELearn::doneKeys((int)$eid)['q' . $nid])]);
    }
    function nodeQuizSubmit(string $eid, string $nid): void {
        if (!($e = $this->enr($eid)) || !($n = $this->nodeOf($e, $nid))) return; $this->access($e, 'q' . $nid); $this->open($e);
        $ids = array_map('intval', array_column(ELearn::questions((int)$e['cid'], false, null, (int)$nid), 'id')); $pass = (int)($n['quiz_pass_pct'] ?: $e['pass_pct']);
        $a = DB::insert('el_attempts', ['enrollment_id' => (int)$eid, 'node_id' => (int)$nid, 'passed' => 0, 'started_at' => now(), 'question_ids' => implode(',', $ids)]);
        [$pct, $ok, $detail] = ELearn::grade(['id' => $e['cid'], 'pass_pct' => $pass], ['id' => $a, 'question_ids' => implode(',', $ids)], $_POST);
        DB::update('el_attempts', ['score_pct' => $pct, 'passed' => $ok ? 1 : 0, 'submitted_at' => now()], 'id=?', [$a]);
        $done = $ok && ELearn::maybeComplete((int)$eid);
        $qs = ELearn::questions((int)$e['cid'], true, null, (int)$nid); $ans = []; foreach (DB::all('SELECT * FROM el_answers WHERE attempt_id=?', [$a]) as $x) $ans[(int)$x['question_id']] = $x;
        $this->view('learn/nodequiz', ['title' => 'Quiz : ' . $n['title'], 'e' => $e, 'n' => $n, 'qs' => $qs, 'res' => ['pct' => $pct, 'ok' => $ok, 'ans' => $ans, 'course_done' => $done, 'next' => $ok ? $this->nextOf($e, 'q' . $nid) : null], 'pass' => $pass, 'passed' => $ok]);
    }

    // ---------- activités ----------
    private function actOf(array $e, string $aid): ?array { $a = DB::one('SELECT * FROM el_activities WHERE id=? AND course_id=?', [(int)$aid, (int)$e['cid']]); if (!$a) { $this->notFound(); return null; } return $a; }
    function activity(string $eid, string $aid): void {
        if (!($e = $this->enr($eid)) || !($a = $this->actOf($e, $aid))) return; $this->access($e, 'a' . $aid);
        $this->view('learn/activity', ['title' => $a['title'], 'e' => $e, 'a' => $a, 's' => DB::one('SELECT * FROM el_submissions WHERE activity_id=? AND enrollment_id=?', [(int)$aid, (int)$eid]), 'next' => $this->nextOf($e, 'a' . $aid)]);
    }
    function activitySubmit(string $eid, string $aid): void {
        if (!($e = $this->enr($eid)) || !($a = $this->actOf($e, $aid))) return; $this->access($e, 'a' . $aid); $to = "learn/$eid/activity/$aid";
        $s = DB::one('SELECT * FROM el_submissions WHERE activity_id=? AND enrollment_id=?', [(int)$aid, (int)$eid]);
        if ($s && $s['status'] === 'validated') { flash('Ce travail est déjà validé.', 'info'); redirect($to); }
        $body = RichHtml::clean((string)$this->in('body'), 60000); [$files, $ferr] = Files::uploads('file'); $err = $ferr;
        if (trim(RichHtml::text($body)) === '' && !$files && !($s && $s['file_stored'])) $err[] = 'Rédigez votre travail ou joignez un fichier.';
        if ($err) { flash(implode(' ', $err), 'danger'); redirect($to); }
        $cols = ['body' => $body, 'status' => 'submitted', 'submitted_at' => now(), 'feedback' => null, 'score' => null];
        if ($files) { $f = $files[0]; $st = Files::put('el_sub', $f['bytes'], $f['ext']); if (!$st) { flash('Enregistrement du fichier impossible.', 'danger'); redirect($to); } if ($s && $s['file_stored']) @unlink(Files::dir('el_sub') . '/' . basename($s['file_stored'])); $cols += ['file_stored' => $st, 'file_name' => $f['name'], 'file_mime' => $f['mime'], 'file_size' => strlen($f['bytes'])]; }
        if ($s) DB::update('el_submissions', $cols, 'id=?', [(int)$s['id']]); else $sid = DB::insert('el_submissions', $cols + ['activity_id' => (int)$aid, 'enrollment_id' => (int)$eid]);
        $this->open($e); $me = (string)DB::val('SELECT name FROM users WHERE id=?', [Auth::id()]);
        foreach (ELearn::trainers((int)$e['cid']) as $t) Notifier::send($t, 'Travail à corriger', $me . ' — ' . $a['title'] . ' (' . $e['title'] . ')', '/elearn/reviews');
        if (!$a['required']) ELearn::maybeComplete((int)$eid);
        Audit::log('submit', 'el_activity', $aid, null, ['enrollment' => $eid]); flash('Travail envoyé' . ($a['required'] ? ' : il sera validé par le formateur.' : '.')); redirect($to);
    }
    function submissionFile(string $eid, string $aid): void {
        if (!($e = DB::one('SELECT user_id FROM el_enrollments WHERE id=?', [(int)$eid])) || (int)$e['user_id'] !== (int)Auth::id()) { $this->notFound(); return; }
        $s = DB::one('SELECT * FROM el_submissions WHERE enrollment_id=? AND activity_id=? AND file_stored IS NOT NULL', [(int)$eid, (int)$aid]); if (!$s) { $this->notFound(); return; } Files::send('el_sub', $s['file_stored'], $s['file_name'], $s['file_mime']);
    }
    function reviews(): void {
        $st = in_array($this->in('status'), ['submitted', 'validated', 'returned'], true) ? (string)$this->in('status') : 'submitted';
        $rows = DB::all("SELECT s.*, a.title atitle, a.type, a.instructions, c.title ctitle, c.id cid, u.name uname FROM el_submissions s JOIN el_activities a ON a.id=s.activity_id JOIN el_courses c ON c.id=a.course_id JOIN el_enrollments en ON en.id=s.enrollment_id JOIN users u ON u.id=en.user_id WHERE s.status=? ORDER BY s.submitted_at DESC LIMIT 200", [$st]);
        $this->view('elearn/reviews', ['title' => 'Travaux à corriger', 'rows' => $rows, 'st' => $st]);
    }
    function reviewGrade(string $sid): void {
        $s = DB::one('SELECT s.*, a.title atitle, en.user_id, en.id eid, en.course_id FROM el_submissions s JOIN el_activities a ON a.id=s.activity_id JOIN el_enrollments en ON en.id=s.enrollment_id WHERE s.id=?', [(int)$sid]); if (!$s) { $this->notFound(); return; }
        $dec = $this->in('decision') === 'validate' ? 'validated' : 'returned'; $fb = trim((string)$this->in('feedback')); $sc = $this->in('score') === '' ? null : (int)$this->in('score');
        if ($sc !== null && ($sc < 0 || $sc > 100)) { flash('Note entre 0 et 100.', 'danger'); redirect('elearn/reviews'); }
        if ($dec === 'returned' && mb_strlen($fb) < 5) { flash('Indiquez ce qu\'il faut corriger (5 caractères minimum).', 'danger'); redirect('elearn/reviews'); }
        DB::update('el_submissions', ['status' => $dec, 'feedback' => mb_substr($fb, 0, 2000), 'score' => $sc, 'graded_by' => Auth::id(), 'graded_at' => now()], 'id=?', [(int)$sid]);
        Notifier::send((int)$s['user_id'], $dec === 'validated' ? 'Travail validé' : 'Travail à reprendre', $s['atitle'] . ($fb ? ' — ' . mb_substr($fb, 0, 120) : ''), '/learn/' . $s['eid'] . '/activity/' . $s['activity_id']);
        $done = $dec === 'validated' && ELearn::maybeComplete((int)$s['eid']); Audit::log('review', 'el_submission', $sid, null, ['decision' => $dec]);
        flash($dec === 'validated' ? 'Travail validé.' . ($done ? ' Le cours est maintenant terminé pour l\'apprenant.' : '') : 'Travail renvoyé à l\'apprenant.'); redirect('elearn/reviews');
    }
    function reviewFile(string $sid): void { $s = DB::one('SELECT * FROM el_submissions WHERE id=? AND file_stored IS NOT NULL', [(int)$sid]); if (!$s) { $this->notFound(); return; } Files::send('el_sub', $s['file_stored'], $s['file_name'], $s['file_mime']); }

    // ---------- questions au formateur ----------
    function ask(string $eid): void {
        if (!Xchg::on('elearn.qna')) { $this->notFound(); return; } if (!($e = $this->enr($eid))) return;
        $nid = (int)$this->in('node_id', 0) ?: null; if ($nid && !DB::val('SELECT 1 FROM el_lessons WHERE id=? AND course_id=?', [$nid, (int)$e['cid']])) { $this->notFound(); return; }
        $t = ELearn::thread((int)$e['cid'], $nid, (int)Auth::id(), true); redirect("learn/ask/$t");
    }
    function askPage(string $tid): void {
        if (!Xchg::on('elearn.qna')) { $this->notFound(); return; } $t = DB::one('SELECT t.*, c.title ctitle, l.title ltitle FROM el_threads t JOIN el_courses c ON c.id=t.course_id LEFT JOIN el_lessons l ON l.id=t.node_id WHERE t.id=?', [(int)$tid]);
        if (!$t || (int)$t['user_id'] !== (int)Auth::id()) { $this->notFound(); return; } if ($t['status'] === 'answered') DB::update('el_threads', ['status' => 'open'], 'id=?', [(int)$tid]);
        $this->view('learn/ask', ['title' => 'Question au formateur', 't' => $t, 'enr' => DB::val('SELECT id FROM el_enrollments WHERE course_id=? AND user_id=?', [(int)$t['course_id'], Auth::id()])]);
    }
    function questions(): void {
        $rows = DB::all("SELECT t.*, c.title ctitle, l.title ltitle, u.name uname, (SELECT COUNT(*) FROM chat_messages m WHERE m.module='el' AND m.ref_id=t.id AND m.deleted_at IS NULL) nmsg FROM el_threads t JOIN el_courses c ON c.id=t.course_id LEFT JOIN el_lessons l ON l.id=t.node_id LEFT JOIN users u ON u.id=t.user_id WHERE EXISTS (SELECT 1 FROM chat_messages m WHERE m.module='el' AND m.ref_id=t.id) ORDER BY CASE t.status WHEN 'open' THEN 0 ELSE 1 END, t.last_at DESC LIMIT 200");
        $this->view('elearn/questions', ['title' => 'Questions des apprenants', 'rows' => $rows]);
    }
    function questionPage(string $tid): void {
        $t = DB::one('SELECT t.*, c.title ctitle, l.title ltitle, u.name uname FROM el_threads t JOIN el_courses c ON c.id=t.course_id LEFT JOIN el_lessons l ON l.id=t.node_id LEFT JOIN users u ON u.id=t.user_id WHERE t.id=?', [(int)$tid]); if (!$t) { $this->notFound(); return; }
        $this->view('elearn/question', ['title' => 'Question de ' . $t['uname'], 't' => $t]);
    }

    // ---------- catalogue, parcours, demandes ----------
    function catalog(): void {
        $q = trim((string)$this->in('q')); $dom = trim((string)$this->in('domain')); $cat = trim((string)$this->in('category')); $nat = (string)$this->in('nature'); $lv = (string)$this->in('level'); $w = ["c.status='published'"]; $p = [];
        if ($q !== '') { $w[] = '(c.title LIKE ? OR c.description LIKE ?)'; $p[] = "%$q%"; $p[] = "%$q%"; } if ($dom !== '') { $w[] = 'c.domain=?'; $p[] = $dom; } if ($cat !== '') { $w[] = 'c.category=?'; $p[] = $cat; }
        if (isset(ELearn::NATURES[$nat])) { $w[] = 'c.nature=?'; $p[] = $nat; } else $nat = ''; if (isset(ELearn::LEVELS[$lv])) { $w[] = 'c.level=?'; $p[] = $lv; } else $lv = '';
        $rows = DB::all('SELECT c.*, (SELECT en.id FROM el_enrollments en WHERE en.course_id=c.id AND en.user_id=' . (int)Auth::id() . ') eid, (SELECT en.status FROM el_enrollments en WHERE en.course_id=c.id AND en.user_id=' . (int)Auth::id() . ') estatus, (SELECT r.status FROM el_requests r WHERE r.course_id=c.id AND r.user_id=' . (int)Auth::id() . " AND r.kind='follow' AND r.status='pending' LIMIT 1) rstatus FROM el_courses c WHERE " . implode(' AND ', $w) . " ORDER BY COALESCE(c.domain,''), CASE c.level WHEN 'beginner' THEN 1 WHEN 'intermediate' THEN 2 WHEN 'advanced' THEN 3 ELSE 4 END, c.title LIMIT 300", $p);
        if ($q !== '' && count($rows) < 3) {   // tolérance aux fautes de frappe : on cherche parmi les autres cours publiés avec les mêmes filtres
            $w2 = array_filter($w, fn($x) => !str_contains($x, 'c.title LIKE')); $p2 = []; $i = 0; foreach ($w as $x) { $n = substr_count($x, '?'); if (str_contains($x, 'c.title LIKE')) { $i += $n; continue; } $p2 = array_merge($p2, array_slice($p, $i, $n)); $i += $n; }
            $ids = array_column($rows, 'id');
            $extra = DB::all('SELECT c.*, (SELECT en.id FROM el_enrollments en WHERE en.course_id=c.id AND en.user_id=' . (int)Auth::id() . ') eid, (SELECT en.status FROM el_enrollments en WHERE en.course_id=c.id AND en.user_id=' . (int)Auth::id() . ') estatus, NULL rstatus FROM el_courses c WHERE ' . implode(' AND ', $w2) . ' LIMIT 2000', $p2);
            foreach (\App\Core\Fuzzy::rank(array_filter($extra, fn($r) => !in_array($r['id'], $ids)), $q, fn($r) => [$r['title'], (string)$r['description'], (string)$r['domain'], (string)$r['category']], 30) as $r) { $r['fuzzy'] = true; $rows[] = $r; }
        }
        foreach ($rows as &$r) { $r['lock'] = ELearn::levelMissing($r, Auth::id()); }
        $pw = ["p.active=1"]; $pp = []; if ($dom !== '') { $pw[] = 'p.domain=?'; $pp[] = $dom; } if (isset(ELearn::LEVELS[$lv])) { $pw[] = 'p.level=?'; $pp[] = $lv; } if ($q !== '') { $pw[] = 'p.name LIKE ?'; $pp[] = "%$q%"; $qTerms = true; }
        $paths = DB::all('SELECT p.*, (SELECT COUNT(*) FROM el_path_courses pc JOIN el_courses c ON c.id=pc.course_id WHERE pc.path_id=p.id AND c.status=\'published\') n FROM el_paths p WHERE ' . implode(' AND ', $pw) . ' ORDER BY p.name', $pp);
        if ($q !== '' && !$paths) { $pw2 = array_slice($pw, 0, -1); $pp2 = array_slice($pp, 0, -1); $all = DB::all('SELECT p.*, (SELECT COUNT(*) FROM el_path_courses pc JOIN el_courses c ON c.id=pc.course_id WHERE pc.path_id=p.id AND c.status=\'published\') n FROM el_paths p WHERE ' . implode(' AND ', $pw2), $pp2); $paths = \App\Core\Fuzzy::rank($all, $q, fn($r) => [$r['name'], (string)$r['description']], 20); }
        foreach ($paths as &$pa) { $pa['enrolled'] = (int)DB::val("SELECT COUNT(*) FROM el_path_courses pc JOIN el_enrollments en ON en.course_id=pc.course_id AND en.user_id=? WHERE pc.path_id=?", [Auth::id(), (int)$pa['id']]); }
        $this->view('learn/catalog', ['title' => 'Catalogue des cours', 'rows' => $rows, 'paths' => array_values(array_filter($paths, fn($x) => $x['n'] > 0)), 'f' => compact('q', 'dom', 'cat', 'nat', 'lv'),
            'domains' => array_column(DB::all("SELECT DISTINCT domain FROM el_courses WHERE status='published' AND domain IS NOT NULL AND domain<>'' ORDER BY domain"), 'domain'), 'cats' => array_column(DB::all("SELECT DISTINCT category FROM el_courses WHERE status='published' AND category IS NOT NULL AND category<>'' ORDER BY category"), 'category'),
            'levels' => ELearn::levelStatus(Auth::id()), 'canReq' => Xchg::on('elearn.requests'), 'selfPaths' => Xchg::on('elearn.self_enroll_paths')]);
    }
    function enrollPath(string $id): void {
        $p = DB::one('SELECT * FROM el_paths WHERE id=? AND active=1 AND open_enroll=1', [(int)$id]); if (!$p || !Xchg::on('elearn.self_enroll_paths')) { $this->notFound(); return; } $n = 0;
        foreach (DB::all("SELECT c.id FROM el_path_courses pc JOIN el_courses c ON c.id=pc.course_id WHERE pc.path_id=? AND c.status='published' ORDER BY pc.position", [(int)$id]) as $c) if (ELearn::enroll((int)$c['id'], (int)Auth::id(), null, null)) $n++;
        Audit::log('enroll', 'el_path', $id, null, ['self' => true, 'courses' => $n]); flash($n ? "Inscription au parcours « {$p['name']} » : $n cours ajouté(s)." : 'Vous êtes déjà inscrit à tous les cours de ce parcours.', $n ? 'success' : 'info'); redirect('learn');
    }
    function myRequests(): void {
        if (!Xchg::on('elearn.requests')) { $this->notFound(); return; }
        $this->view('learn/requests', ['title' => 'Mes demandes de formation', 'rows' => DB::all('SELECT r.*, c.title ctitle FROM el_requests r LEFT JOIN el_courses c ON c.id=r.course_id WHERE r.user_id=? ORDER BY r.id DESC', [Auth::id()]),
            'courses' => DB::all("SELECT c.id, c.title FROM el_courses c WHERE c.status='published' AND NOT EXISTS (SELECT 1 FROM el_enrollments en WHERE en.course_id=c.id AND en.user_id=" . (int)Auth::id() . ') ORDER BY c.title'), 'sel' => (int)$this->in('course')]);
    }
    function storeRequest(): void {
        if (!Xchg::on('elearn.requests')) { $this->notFound(); return; } $kind = $this->in('kind') === 'create' ? 'create' : 'follow'; $just = trim((string)$this->in('justification'));
        if (mb_strlen($just) < 5 || mb_strlen($just) > 1000) { flash('Expliquez votre besoin (5 à 1000 caractères).', 'danger'); redirect('learn/requests'); }
        $d = ['user_id' => Auth::id(), 'kind' => $kind, 'justification' => $just, 'status' => 'pending', 'created_at' => now()];
        if ($kind === 'follow') { $cid = (int)$this->in('course_id', 0); $c = DB::one("SELECT id, title FROM el_courses WHERE id=? AND status='published'", [$cid]); if (!$c) { flash('Choisissez un cours.', 'danger'); redirect('learn/requests'); }
            if (DB::val('SELECT 1 FROM el_enrollments WHERE course_id=? AND user_id=?', [$cid, Auth::id()])) { flash('Vous êtes déjà inscrit à ce cours.', 'info'); redirect('learn/requests'); }
            if (DB::val("SELECT 1 FROM el_requests WHERE course_id=? AND user_id=? AND status='pending'", [$cid, Auth::id()])) { flash('Une demande est déjà en attente pour ce cours.', 'info'); redirect('learn/requests'); }
            $d += ['course_id' => $cid, 'title' => $c['title']]; }
        else { $t = trim((string)$this->in('title')); if ($t === '' || mb_strlen($t) > 190) { flash('Indiquez le sujet du cours souhaité.', 'danger'); redirect('learn/requests'); }
            $d += ['title' => $t, 'domain' => mb_substr(trim((string)$this->in('domain')), 0, 80) ?: null, 'nature' => isset(ELearn::NATURES[(string)$this->in('nature')]) ? (string)$this->in('nature') : null, 'level' => isset(ELearn::LEVELS[(string)$this->in('level')]) ? (string)$this->in('level') : null]; }
        $id = DB::insert('el_requests', $d); $me = (string)DB::val('SELECT name FROM users WHERE id=?', [Auth::id()]);
        foreach (DB::all("SELECT DISTINCT ur.user_id FROM user_roles ur JOIN roles r ON r.id=ur.role_id LEFT JOIN role_permissions rp ON rp.role_id=r.id LEFT JOIN permissions p ON p.id=rp.permission_id JOIN users u ON u.id=ur.user_id AND u.status='active' WHERE p.code IN ('elearn.assign','*') LIMIT 20") as $u) Notifier::send((int)$u['user_id'], $kind === 'create' ? 'Demande de nouveau cours' : 'Demande d\'accès à un cours', $me . ' — ' . $d['title'], '/elearn/requests');
        Audit::log('create', 'el_request', $id, null, ['kind' => $kind]); flash('Demande envoyée : vous serez prévenu de la décision.'); redirect('learn/requests');
    }
    function requests(): void {
        $st = in_array($this->in('status'), ['pending', 'approved', 'rejected'], true) ? (string)$this->in('status') : 'pending';
        $this->view('elearn/requests', ['title' => 'Demandes des apprenants', 'st' => $st, 'rows' => DB::all('SELECT r.*, u.name uname, c.title ctitle FROM el_requests r LEFT JOIN users u ON u.id=r.user_id LEFT JOIN el_courses c ON c.id=r.course_id WHERE r.status=? ORDER BY r.id DESC LIMIT 200', [$st])]);
    }
    function decideRequest(string $rid): void {
        $r = DB::one('SELECT * FROM el_requests WHERE id=?', [(int)$rid]); if (!$r || $r['status'] !== 'pending') { flash('Demande déjà traitée.', 'info'); redirect('elearn/requests'); }
        $ok = $this->in('decision') === 'approve'; $note = mb_substr(trim((string)$this->in('note')), 0, 500); if (!$ok && mb_strlen($note) < 5) { flash('Indiquez le motif du refus (5 caractères minimum).', 'danger'); redirect('elearn/requests'); }
        $cols = ['status' => $ok ? 'approved' : 'rejected', 'decided_by' => Auth::id(), 'decision_note' => $note ?: null, 'decided_at' => now()]; $msg = '';
        if ($ok && $r['kind'] === 'follow') { $eid = ELearn::enroll((int)$r['course_id'], (int)$r['user_id'], Auth::id(), null); $msg = $eid ? ' Apprenant inscrit.' : ' Déjà inscrit.'; }
        if ($ok && $r['kind'] === 'create') { $cid = DB::insert('el_courses', ['title' => $r['title'], 'domain' => $r['domain'], 'nature' => $r['nature'] ?: 'both', 'level' => $r['level'], 'description' => mb_substr((string)$r['justification'], 0, 1000), 'status' => 'draft', 'created_by' => Auth::id(), 'created_at' => now(), 'pass_pct' => 80]); $cols['created_course_id'] = $cid; $msg = ' Cours créé en brouillon.'; }
        DB::update('el_requests', $cols, 'id=?', [(int)$rid]);
        Notifier::send((int)$r['user_id'], $ok ? 'Demande acceptée' : 'Demande refusée', $r['title'] . ($note ? ' — ' . $note : ''), '/learn/requests'); Audit::log('decide', 'el_request', $rid, null, $cols);
        flash(($ok ? 'Demande acceptée.' : 'Demande refusée.') . $msg); redirect(($ok && $r['kind'] === 'create') ? 'elearn/' . $cols['created_course_id'] : 'elearn/requests');
    }
}
