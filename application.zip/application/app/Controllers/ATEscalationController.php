<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Tickets, Esc, Mailer};
/** Escalades de tickets (fonctionnelle, hiérarchique, prestataire, opérateur/métier) et administration des groupes, contacts, règles et matrice de priorité. */
class ATEscalationController extends Controller {
    private function ticket(string $id): ?array {
        $t = DB::one('SELECT * FROM at_tickets WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return null; }
        if (!in_array($t['status'], Tickets::OPEN, true) || $t['status'] === 'approval') { flash('Ce ticket n\'est pas ouvert au traitement : escalade impossible.', 'warning'); redirect("at/$id"); }
        return $t;
    }
    private function reason(string $id, int $min = 5, int $max = 500): string {
        $r = trim((string)$this->in('reason', '')); if (mb_strlen($r) < $min || mb_strlen($r) > $max) { flash("Indiquez le motif ($min à $max caractères).", 'danger'); redirect("at/$id"); } return $r;
    }
    /** Escalade fonctionnelle : vers un groupe de résolution (même niveau, niveau supérieur ou retour au niveau inférieur). */
    function escalate(string $id): void {
        if (!($t = $this->ticket($id))) return; $reason = $this->reason($id);
        $g = DB::one('SELECT * FROM at_groups WHERE id=? AND active=1', [(int)$this->in('group_id')]); if (!$g) { flash('Choisissez un groupe de résolution.', 'danger'); redirect("at/$id"); }
        $a = (int)$this->in('assignee_id') ?: null; if ($a && !DB::val('SELECT 1 FROM at_group_members WHERE group_id=? AND user_id=?', [(int)$g['id'], $a])) { flash('Le technicien choisi ne fait pas partie de ce groupe.', 'danger'); redirect("at/$id"); }
        $from = (int)$t['tier']; $to = (int)$g['tier']; $kind = $to < $from ? 'deescalate' : 'functional';
        DB::update('at_tickets', ['tier' => $to, 'group_id' => (int)$g['id'], 'assignee_id' => $a, 'status' => $a ? 'assigned' : 'new'] + Tickets::transition($t, $a ? 'assigned' : 'new'), 'id=?', [(int)$id]);
        Esc::log((int)$id, $kind, ['from_tier' => $from, 'to_tier' => $to, 'group_id' => (int)$g['id'], 'target_user_id' => $a, 'reason' => $reason]);
        Tickets::event((int)$id, 'escalation', ($kind === 'deescalate' ? 'Renvoi au niveau N' : 'Escalade au niveau N') . $to . ' — groupe « ' . $g['name'] . ' ».', Auth::id()); Tickets::event((int)$id, 'note', 'Motif de l\'escalade : ' . $reason, Auth::id());
        $to_users = $a ? [$a] : Esc::groupUsers((int)$g['id']); if (!$to_users) $to_users = Esc::levelRecipients($t, 3);
        Esc::notify($to_users, $t, ($kind === 'deescalate' ? 'Ticket renvoyé : ' : 'Ticket escaladé : ') . $t['reference'], $t['title'] . ' — ' . $reason);
        if ($t['requester_id'] && (int)$t['requester_id'] !== Auth::id()) Notifier::send((int)$t['requester_id'], 'Votre demande a été transmise : ' . $t['reference'], 'Elle est prise en charge par ' . $g['name'] . '.', '/at/' . $id);
        Audit::log($kind, 'at_ticket', $id, ['tier' => $from], ['tier' => $to, 'group' => $g['code']]); flash('Ticket transmis à « ' . $g['name'] . ' » (niveau N' . $to . ').'); redirect("at/$id");
    }
    /** Escalade hiérarchique manuelle : informe le niveau supérieur (N+1, N+2, direction). */
    function escalateUp(string $id): void {
        if (!($t = $this->ticket($id))) return; $reason = $this->reason($id); $lvl = min(3, (int)$t['esc_level'] + 1);
        if ((int)$t['esc_level'] >= 3) { flash('Ce ticket est déjà escaladé au niveau le plus élevé (direction).', 'warning'); redirect("at/$id"); }
        DB::update('at_tickets', ['esc_level' => $lvl], 'id=?', [(int)$id]); Esc::log((int)$id, 'hierarchical', ['level' => $lvl, 'reason' => $reason]);
        Tickets::event((int)$id, 'escalation', 'Escalade hiérarchique : ' . Esc::LEVEL[$lvl] . '.', Auth::id()); Tickets::event((int)$id, 'note', 'Motif de l\'escalade hiérarchique : ' . $reason, Auth::id());
        Esc::notify(Esc::levelRecipients($t, $lvl), $t, 'Escalade ' . Esc::LEVEL[$lvl] . ' : ' . $t['reference'], $t['title'] . ' — ' . $reason);
        Audit::log('escalate_up', 'at_ticket', $id, ['esc_level' => $t['esc_level']], ['esc_level' => $lvl]); flash('Escalade hiérarchique envoyée (' . Esc::LEVEL[$lvl] . ').'); redirect("at/$id");
    }
    /** Transmission à un prestataire : ticket fournisseur lié (référence externe), e-mail, relance planifiée. */
    function supplier(string $id): void {
        if (!($t = $this->ticket($id))) return; $msg = $this->reason($id, 5, 1000);
        $s = DB::one('SELECT * FROM at_suppliers WHERE id=? AND active=1', [(int)$this->in('supplier_id')]); if (!$s) { flash('Choisissez un prestataire.', 'danger'); redirect("at/$id"); }
        $ref = mb_substr(trim((string)$this->in('ext_ref', '')), 0, 60) ?: null; $days = max(1, (int)setting('at.ext_days', 3));
        DB::update('at_tickets', ['ext_supplier_id' => (int)$s['id'], 'ext_ref' => $ref, 'ext_status' => 'open', 'ext_since' => now(), 'ext_followup_at' => date('Y-m-d H:i:s', time() + $days * 86400), 'tier' => 3], 'id=?', [(int)$id]);
        Esc::log((int)$id, 'supplier', ['from_tier' => $t['tier'], 'to_tier' => 3, 'supplier_id' => (int)$s['id'], 'reason' => $msg]);
        Tickets::event((int)$id, 'escalation', 'Transmis au prestataire « ' . $s['name'] . ' »' . ($ref ? ' (réf. ' . $ref . ')' : '') . '.', Auth::id());
        $sent = $s['email'] && Mailer::queue($s['email'], '[' . $t['reference'] . '] ' . $t['title'], Esc::summary($t, $msg));
        if ($t['assignee_id'] && (int)$t['assignee_id'] !== Auth::id()) Notifier::send((int)$t['assignee_id'], 'Ticket transmis au prestataire : ' . $t['reference'], $s['name'], '/at/' . $id);
        Audit::log('supplier', 'at_ticket', $id, null, ['supplier' => $s['name'], 'ext_ref' => $ref]); flash('Ticket transmis à ' . $s['name'] . ($sent ? ' (e-mail mis en file d\'envoi).' : ' — aucun e-mail envoyé (adresse absente ou envoi non configuré) : prévenez-le directement.'), $sent ? 'success' : 'warning'); redirect("at/$id");
    }
    function supplierUpdate(string $id): void {
        $t = DB::one('SELECT * FROM at_tickets WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return; }
        if ($t['ext_status'] !== 'open') { flash('Aucun suivi prestataire ouvert sur ce ticket.', 'warning'); redirect("at/$id"); }
        $act = $this->in('action'); $note = trim((string)$this->in('reason', '')); $s = DB::one('SELECT * FROM at_suppliers WHERE id=?', [(int)$t['ext_supplier_id']]); $days = max(1, (int)setting('at.ext_days', 3));
        if ($act === 'remind') {
            DB::update('at_tickets', ['ext_followup_at' => date('Y-m-d H:i:s', time() + $days * 86400)], 'id=?', [(int)$id]); Esc::log((int)$id, 'reminder', ['supplier_id' => (int)$t['ext_supplier_id'], 'reason' => $note ?: 'Relance du prestataire']);
            if ($s && $s['email']) Mailer::queue($s['email'], 'Relance [' . $t['reference'] . '] ' . $t['title'], Esc::summary($t, $note ?: 'Relance : merci de nous communiquer l\'avancement.'));
            Tickets::event((int)$id, 'escalation', 'Relance du prestataire « ' . ($s['name'] ?? '—') . ' ».', Auth::id()); flash('Relance enregistrée.');
        } elseif ($act === 'close') {
            if (mb_strlen($note) < 5) { flash('Indiquez le retour du prestataire (5 caractères minimum).', 'danger'); redirect("at/$id"); }
            DB::update('at_tickets', ['ext_status' => 'closed', 'ext_followup_at' => null], 'id=?', [(int)$id]); Esc::log((int)$id, 'supplier', ['supplier_id' => (int)$t['ext_supplier_id'], 'reason' => 'Retour prestataire : ' . mb_substr($note, 0, 450)]);
            Tickets::event((int)$id, 'escalation', 'Retour du prestataire reçu : suivi externe clos.', Auth::id()); Tickets::event((int)$id, 'note', 'Retour prestataire : ' . $note, Auth::id()); flash('Suivi prestataire clos.');
        } else flash('Action inconnue.', 'danger');
        Audit::log('supplier_' . $act, 'at_ticket', $id); redirect("at/$id");
    }
    /** Escalade vers un contact opérateur / métier de la matrice d'escalade. */
    function contact(string $id): void {
        if (!($t = $this->ticket($id))) return; $msg = $this->reason($id, 5, 1000);
        $c = DB::one('SELECT * FROM at_contacts WHERE id=? AND active=1', [(int)$this->in('contact_id')]); if (!$c) { flash('Choisissez un contact d\'escalade.', 'danger'); redirect("at/$id"); }
        Esc::log((int)$id, 'operator', ['contact_id' => (int)$c['id'], 'level' => (int)$c['level'], 'reason' => $msg]);
        Tickets::event((int)$id, 'escalation', 'Escalade vers ' . ($c['kind'] === 'operator' ? 'l\'opérateur' : 'le métier') . ' : ' . $c['name'] . ($c['role'] ? ' (' . $c['role'] . ')' : '') . '.', Auth::id()); Tickets::event((int)$id, 'note', 'Message transmis : ' . $msg, Auth::id());
        $sent = $c['email'] && Mailer::queue($c['email'], '[' . $t['reference'] . '] ' . $t['title'], Esc::summary($t, $msg));
        Audit::log('contact', 'at_ticket', $id, null, ['contact' => $c['name']]); flash('Escalade enregistrée pour ' . $c['name'] . ($sent ? ' (e-mail mis en file d\'envoi).' : ' — aucun e-mail envoyé : appelez ou écrivez au contact' . ($c['phone'] ? ' (' . $c['phone'] . ')' : '') . '.'), $sent ? 'success' : 'warning'); redirect("at/$id");
    }

    // ---- Administration : groupes de résolution, contacts d'escalade, règles hiérarchiques, matrice impact × urgence
    function admin(): void {
        $this->view('at/escalation', ['title' => 'Escalades et niveaux de support', 'groups' => DB::all('SELECT * FROM at_groups ORDER BY tier, name'),
            'members' => DB::all('SELECT group_id, user_id FROM at_group_members'), 'users' => Tickets::handlers(), 'contacts' => DB::all('SELECT * FROM at_contacts ORDER BY active DESC, kind, category, level, name'),
            'rules' => DB::all('SELECT * FROM at_esc_rules ORDER BY CASE priority WHEN \'critical\' THEN 0 WHEN \'high\' THEN 1 WHEN \'normal\' THEN 2 ELSE 3 END, level, threshold_pct'), 'matrix' => Esc::matrix(),
            'cats' => DB::all("SELECT v.code, v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='at_categories' AND v.active=1 ORDER BY v.sort_order")]);
    }
    private function members(int $gid): void {
        DB::exec('DELETE FROM at_group_members WHERE group_id=?', [$gid]); $ok = array_map('intval', array_column(Tickets::handlers(), 'id'));
        foreach (array_unique(array_map('intval', (array)($_POST['members'] ?? []))) as $u) if (in_array($u, $ok, true)) DB::insert('at_group_members', ['group_id' => $gid, 'user_id' => $u]);
    }
    private function groupData(): array {
        $lead = (int)$this->in('lead_user_id') ?: null; if ($lead && !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$lead])) $lead = null;
        $cats = implode(',', array_filter(array_map(fn($c) => preg_replace('/[^A-Za-z0-9_-]/', '', $c), (array)($_POST['categories'] ?? []))));
        $mail = trim((string)$this->in('email', '')); if ($mail !== '' && !filter_var($mail, FILTER_VALIDATE_EMAIL)) $mail = '';
        return ['name' => mb_substr(trim((string)$this->in('name', '')), 0, 150), 'tier' => max(1, min(3, (int)$this->in('tier', 1))), 'lead_user_id' => $lead, 'email' => $mail ?: null, 'categories' => mb_substr($cats, 0, 300) ?: null, 'active' => isset($_POST['active']) ? 1 : 0];
    }
    function storeGroup(): void {
        $d = $this->groupData(); $code = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string)$this->in('code', '')));
        if ($d['name'] === '' || $code === '' || strlen($code) > 40 || DB::val('SELECT 1 FROM at_groups WHERE code=?', [$code])) { flash('Code unique et nom obligatoires.', 'danger'); redirect('at/escalation'); }
        $d['active'] = 1; $gid = DB::insert('at_groups', ['code' => $code] + $d); $this->members($gid); Audit::log('create', 'at_group', $gid, null, $d); flash('Groupe créé.'); redirect('at/escalation');
    }
    function updateGroup(string $id): void {
        $o = DB::one('SELECT * FROM at_groups WHERE id=?', [(int)$id]); if (!$o) { $this->notFound(); return; } $d = $this->groupData(); if ($d['name'] === '') $d['name'] = $o['name'];
        DB::update('at_groups', $d, 'id=?', [(int)$id]); $this->members((int)$id); Audit::log('update', 'at_group', $id, $o, $d); flash('Groupe enregistré.'); redirect('at/escalation');
    }
    private function contactData(): array {
        $mail = trim((string)$this->in('email', '')); if ($mail !== '' && !filter_var($mail, FILTER_VALIDATE_EMAIL)) $mail = '';
        return ['kind' => $this->in('kind') === 'business' ? 'business' : 'operator', 'category' => mb_substr(trim((string)$this->in('category', '')), 0, 60) ?: null, 'level' => max(1, min(3, (int)$this->in('level', 1))), 'name' => mb_substr(trim((string)$this->in('name', '')), 0, 150),
            'role' => mb_substr(trim((string)$this->in('role', '')), 0, 100) ?: null, 'email' => $mail ?: null, 'phone' => mb_substr(trim((string)$this->in('phone', '')), 0, 40) ?: null, 'active' => isset($_POST['active']) ? 1 : 0];
    }
    function storeContact(): void {
        $d = $this->contactData(); if ($d['name'] === '' || (!$d['email'] && !$d['phone'])) { flash('Nom et au moins un e-mail valide ou un téléphone obligatoires.', 'danger'); redirect('at/escalation'); }
        $d['active'] = 1; $cid = DB::insert('at_contacts', $d); Audit::log('create', 'at_contact', $cid, null, $d); flash('Contact ajouté.'); redirect('at/escalation');
    }
    function updateContact(string $id): void {
        $o = DB::one('SELECT * FROM at_contacts WHERE id=?', [(int)$id]); if (!$o) { $this->notFound(); return; } $d = $this->contactData(); if ($d['name'] === '') $d['name'] = $o['name'];
        DB::update('at_contacts', $d, 'id=?', [(int)$id]); Audit::log('update', 'at_contact', $id, $o, $d); flash('Contact enregistré.'); redirect('at/escalation');
    }
    function saveRules(): void {
        $m = []; foreach (array_keys(Esc::MATRIX) as $k) { $v = $_POST['matrix'][str_replace('|', '_', $k)] ?? ''; if (isset(Tickets::PRIO[$v])) $m[$k] = $v; }
        \App\Core\Settings::set('at.matrix', json_encode($m)); \App\Core\Settings::set('at.ext_days', (string)max(1, min(30, (int)$this->in('ext_days', 3))));
        foreach (DB::all('SELECT id FROM at_esc_rules') as $r) { $pct = (int)($_POST['pct'][$r['id']] ?? 0); $act = isset($_POST['ract'][$r['id']]) ? 1 : 0; if ($pct >= 10 && $pct <= 500) DB::update('at_esc_rules', ['threshold_pct' => $pct, 'active' => $act], 'id=?', [(int)$r['id']]); }
        $np = (string)$this->in('new_priority'); $nl = (int)$this->in('new_level'); $nt = (int)$this->in('new_pct');
        if (isset(Tickets::PRIO[$np]) && $nl >= 1 && $nl <= 3 && $nt >= 10 && $nt <= 500) DB::insert('at_esc_rules', ['priority' => $np, 'threshold_pct' => $nt, 'level' => $nl, 'active' => 1]);
        if ($del = (int)$this->in('delete_rule')) DB::exec('DELETE FROM at_esc_rules WHERE id=?', [$del]);
        Audit::log('update', 'at_escalation_rules', null, null, ['matrix' => $m]); flash('Règles d\'escalade et matrice de priorité enregistrées.'); redirect('at/escalation');
    }
}
