<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Ct, CtFlow, Request};

/** Contrats RH : modèles, rédaction, signature électronique, partage par e-mail. */
class ContractDocsController extends Controller {
    // ---------- modèles ----------
    function templates(): void {
        $this->view('contracts/templates', ['title' => 'Modèles de contrat', 'rows' => DB::all('SELECT t.*, (SELECT COUNT(*) FROM contracts c WHERE c.template_id=t.id) used FROM ct_templates t ORDER BY t.active DESC, t.name'), 'known' => Ct::KNOWN]);
    }
    function tplForm(string $id = ''): void {
        $t = $id !== '' ? DB::one('SELECT * FROM ct_templates WHERE id=?', [(int)$id]) : ['id' => null, 'name' => '', 'type' => '', 'body' => '', 'active' => 1];
        if (!$t) { $this->notFound(); return; }
        $this->view('contracts/template_form', ['title' => $t['id'] ? 'Modèle : ' . $t['name'] : 'Nouveau modèle', 't' => $t, 'known' => Ct::KNOWN, 'types' => DB::all("SELECT v.code, v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='contract_types' AND v.active=1 ORDER BY v.sort_order, v.label")]);
    }
    function tplSave(string $id = ''): void {
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'type' => ['label' => 'Le type', 'max' => 60], 'body' => ['label' => 'Le texte', 'req' => true, 'max' => 60000]], $_POST);
        if ($err) $this->back($err, $_POST, $id !== '' ? "contracts/templates/$id" : 'contracts/templates/new');
        $d['type'] = $d['type'] ?: null; $d['active'] = isset($_POST['active']) ? 1 : 0; $d['updated_at'] = now();
        if ($id !== '') { $old = DB::one('SELECT * FROM ct_templates WHERE id=?', [(int)$id]); if (!$old) { $this->notFound(); return; } DB::update('ct_templates', $d, 'id=?', [(int)$id]); Audit::log('update', 'ct_template', $id, $old, $d); }
        else { $d += ['created_by' => Auth::id(), 'created_at' => now()]; $id = (string)DB::insert('ct_templates', $d); Audit::log('create', 'ct_template', $id, null, $d); }
        flash('Modèle enregistré.'); redirect('contracts/templates');
    }
    function tplDelete(string $id): void {
        $t = DB::one('SELECT * FROM ct_templates WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return; }
        if ((int)DB::val('SELECT COUNT(*) FROM contracts WHERE template_id=?', [(int)$id])) { DB::update('ct_templates', ['active' => 0], 'id=?', [(int)$id]); flash('Modèle déjà utilisé : il est désactivé (les contrats rédigés restent intacts).', 'info'); }
        else { DB::exec('DELETE FROM ct_templates WHERE id=?', [(int)$id]); flash('Modèle supprimé.'); }
        Audit::log('delete', 'ct_template', $id, $t); redirect('contracts/templates');
    }

    // ---------- fiche contrat ----------
    private function load(string $id): ?array {
        $c = DB::one('SELECT c.*, e.first_name, e.last_name, e.matricule, e.email employee_email FROM contracts c JOIN employees e ON e.id=c.employee_id WHERE c.id=?', [(int)$id]);
        if (!$c) { $this->notFound(); return null; } return $c;
    }
    function show(string $id): void {
        if (!($c = $this->load($id))) return;
        $tpls = DB::all('SELECT id, name, type, body FROM ct_templates WHERE active=1 ORDER BY (type=?) DESC, name', [$c['type']]);
        $this->view('contracts/show', ['title' => 'Contrat de ' . $c['first_name'] . ' ' . $c['last_name'], 'c' => $c, 'tpls' => $tpls, 'signers' => Ct::signers((int)$c['id']), 'shares' => DB::all('SELECT * FROM ct_shares WHERE contract_id=? ORDER BY id DESC', [(int)$c['id']]),
            'vals' => Ct::values($c), 'known' => Ct::KNOWN, 'mailOn' => \App\Core\Mailer::enabled()]);
    }
    /** Rédige le contrat depuis un modèle : variables connues remplies, autres saisies. */
    function draft(string $id): void {
        if (!($c = $this->load($id))) return; if (in_array($c['doc_status'], ['to_sign', 'signed'], true)) { flash('Ce contrat est en signature ou signé : annulez-le d\'abord pour le rédiger à nouveau.', 'warning'); redirect("contracts/$id"); }
        $t = DB::one('SELECT * FROM ct_templates WHERE id=? AND active=1', [(int)$this->in('template_id')]); if (!$t) { flash('Choisissez un modèle.', 'danger'); redirect("contracts/$id"); }
        $extra = []; foreach ((array)($_POST['v'] ?? []) as $k => $v) { $k = strtolower((string)$k); if (preg_match('/^[a-z0-9_]{1,40}$/', $k) && trim((string)$v) !== '') $extra[$k] = mb_substr(trim((string)$v), 0, 300); }
        $dr = CtFlow::draft($c, $t, $extra); $miss = $dr['miss']; if ($dr['blank']) flash('Variables restées vides (affichées « ……………  » dans le texte) : ' . implode(', ', $dr['blank']) . '. Complétez-les avant l\'envoi.', 'warning'); if ($miss) flash('Signataire sans e-mail : ' . implode(', ', $miss) . '. Ajoutez-le ci-dessous avant l\'envoi.', 'warning');
        Audit::log('draft', 'contract', $id, null, ['template' => $t['id']]);
        flash('Contrat rédigé : relisez et ajustez le texte, vérifiez les signataires, puis envoyez-le en signature.'); redirect("contracts/$id");
    }
    function saveBody(string $id): void {
        if (!($c = $this->load($id))) return; if ($c['doc_status'] !== 'draft') { flash('Le texte ne se modifie qu\'en brouillon.', 'warning'); redirect("contracts/$id"); }
        $b = trim((string)$this->in('body', '')); $t = trim((string)$this->in('title', '')); if ($b === '' || mb_strlen($b) > 60000) { flash('Le texte est vide ou trop long.', 'danger'); redirect("contracts/$id"); }
        DB::update('contracts', ['body' => $b, 'title' => mb_substr($t, 0, 190) ?: $c['title']], 'id=?', [(int)$id]); Audit::log('update_text', 'contract', $id); flash('Texte enregistré.'); redirect("contracts/$id");
    }
    function addSigner(string $id): void {
        if (!($c = $this->load($id))) return; if (in_array($c['doc_status'], ['signed', 'cancelled'], true)) { flash('Plus de modification possible.', 'warning'); redirect("contracts/$id"); }
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'email' => ['label' => 'L\'e-mail', 'req' => true, 'email' => true, 'max' => 190], 'role' => ['label' => 'La qualité', 'max' => 80]], $_POST);
        if ($err) { flash(implode(' ', $err), 'danger'); redirect("contracts/$id"); }
        $sid = DB::insert('ct_signers', ['contract_id' => (int)$id, 'role' => $d['role'] ?: 'Autre partie', 'name' => $d['name'], 'email' => strtolower($d['email']), 'position' => (int)DB::val('SELECT COALESCE(MAX(position),0)+1 FROM ct_signers WHERE contract_id=?', [(int)$id]), 'token' => Ct::token(), 'status' => 'pending']);
        if ($c['doc_status'] === 'to_sign') $this->notifySigner((int)$sid, $c);
        Audit::log('add_signer', 'contract', $id, null, ['email' => $d['email']]); flash('Signataire ajouté.'); redirect("contracts/$id");
    }
    function delSigner(string $id, string $sid): void {
        if (!($c = $this->load($id))) return; $s = DB::one('SELECT * FROM ct_signers WHERE id=? AND contract_id=?', [(int)$sid, (int)$id]); if (!$s) { $this->notFound(); return; }
        if ($s['status'] === 'signed') { flash('Ce signataire a déjà signé.', 'warning'); redirect("contracts/$id"); }
        DB::exec('DELETE FROM ct_signers WHERE id=?', [(int)$sid]); Audit::log('del_signer', 'contract', $id, $s); Ct::refresh((int)$id); flash('Signataire retiré.'); redirect("contracts/$id");
    }
    private function notifySigner(int $sid, array $c, bool $reminder = false): bool { return CtFlow::notify($sid, $c, $reminder); }
    function send(string $id): void {
        if (!($c = $this->load($id))) return; $sg = Ct::signers((int)$id);
        if (!in_array($c['doc_status'], ['draft', 'to_sign'], true) || trim((string)$c['body']) === '') { flash('Rédigez d\'abord le contrat.', 'warning'); redirect("contracts/$id"); }
        if (!$sg) { flash('Ajoutez au moins un signataire.', 'danger'); redirect("contracts/$id"); }
        if (count(Ct::placeholders((string)$c['body'])) && $this->in('force') !== '1') { flash('Le texte contient encore des variables {{…}} non remplacées : complétez-les ou cochez « Envoyer malgré tout ».', 'danger'); redirect("contracts/$id"); }
        [$sent] = CtFlow::send($c);
        Audit::log('send', 'contract', $id, null, ['signers' => count($sg), 'mailed' => $sent]);
        flash($sent ? "Contrat envoyé en signature : $sent e-mail(s) envoyé(s)." : 'Contrat en signature. L\'envoi d\'e-mails n\'est pas configuré : copiez les liens personnels de chaque signataire ci-dessous et transmettez-les.', $sent ? 'success' : 'warning'); redirect("contracts/$id");
    }
    function remind(string $id): void {
        if (!($c = $this->load($id))) return; if ($c['doc_status'] !== 'to_sign') { redirect("contracts/$id"); }
        $n = 0; foreach (Ct::signers((int)$id) as $s) if ($s['status'] === 'pending' && $this->notifySigner((int)$s['id'], $c, true)) $n++;
        Audit::log('remind', 'contract', $id, null, ['mailed' => $n]); flash($n ? "$n rappel(s) envoyé(s)." : 'Aucun rappel envoyé (aucun signataire en attente ou e-mail non configuré).', $n ? 'success' : 'info'); redirect("contracts/$id");
    }
    function cancel(string $id): void {
        if (!($c = $this->load($id))) return; if ($c['doc_status'] === 'signed') { flash('Un contrat signé ne s\'annule pas ; établissez un avenant.', 'warning'); redirect("contracts/$id"); }
        DB::update('contracts', ['doc_status' => 'draft', 'doc_hash' => null, 'sent_at' => null], 'id=?', [(int)$id]); DB::exec("UPDATE ct_signers SET status='pending', signed_at=NULL, signed_name=NULL, doc_hash=NULL, ip=NULL, comment=NULL WHERE contract_id=?", [(int)$id]);
        Audit::log('cancel_signature', 'contract', $id); flash('Signature annulée : le contrat repasse en brouillon, les liens déjà envoyés restent valides pour le nouveau texte une fois renvoyé.'); redirect("contracts/$id");
    }
    function share(string $id): void {
        if (!($c = $this->load($id))) return; if ($c['doc_status'] === 'none') { flash('Rédigez d\'abord le contrat.', 'warning'); redirect("contracts/$id"); }
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'max' => 150], 'email' => ['label' => 'L\'e-mail', 'req' => true, 'email' => true, 'max' => 190]], $_POST);
        if ($err) { flash(implode(' ', $err), 'danger'); redirect("contracts/$id"); }
        $tk = Ct::token(); $sid = DB::insert('ct_shares', ['contract_id' => (int)$id, 'name' => $d['name'] ?: null, 'email' => strtolower($d['email']), 'token' => $tk, 'created_by' => Auth::id(), 'created_at' => now()]);
        $note = trim((string)$this->in('message', ''));
        $txt = 'Bonjour' . ($d['name'] ? ' ' . $d['name'] : '') . ",\n\n" . ($note !== '' ? mb_substr($note, 0, 600) . "\n\n" : '') . "Le document « {$c['title']} » est partagé avec vous en consultation (statut : " . Ct::DOC[$c['doc_status']] . ").\nConsultez-le et téléchargez-le en PDF :\n" . Ct::abs('ctdoc/' . $tk) . "\n\n" . (string)setting('company_name', (string)setting('app.name', 'CXO Excellence Hub'));
        $ok = Ct::mail($d['email'], 'Document partagé : ' . $c['title'], $txt); if ($ok) DB::update('ct_shares', ['sent_at' => now()], 'id=?', [(int)$sid]);
        Audit::log('share', 'contract', $id, null, ['email' => $d['email'], 'mailed' => $ok]); flash($ok ? 'Document partagé par e-mail.' : 'Partage créé, mais l\'envoi d\'e-mails n\'est pas configuré : copiez le lien affiché.', $ok ? 'success' : 'warning'); redirect("contracts/$id");
    }
    function unshare(string $id, string $sid): void {
        DB::exec('DELETE FROM ct_shares WHERE id=? AND contract_id=?', [(int)$sid, (int)$id]); Audit::log('unshare', 'contract', $id); flash('Partage retiré : le lien ne fonctionne plus.'); redirect("contracts/$id");
    }
    function pdf(string $id): void {
        if (!($c = $this->load($id))) return; if ($c['doc_status'] === 'none') { $this->notFound(); return; }
        Audit::log('pdf', 'contract', $id); Ct::pdfOut($c, 'contrat-' . $c['id']);
    }

    // ---------- pages publiques (lien personnel) ----------
    private function signer(string $token): ?array {
        if (!preg_match('/^[a-f0-9]{48}$/', $token)) return null;
        $s = DB::one('SELECT * FROM ct_signers WHERE token=?', [$token]); if (!$s) return null;
        $c = DB::one('SELECT * FROM contracts WHERE id=?', [(int)$s['contract_id']]); if (!$c) return null; return [$s, $c];
    }
    function signPage(string $token): void { \App\Core\Activity::skipRequest();
        $x = $this->signer($token); if (!$x) { http_response_code(404); $this->view('contracts/public_gone', ['title' => 'Lien invalide'], 'layout/public'); return; } [$s, $c] = $x;
        if (!$s['viewed_at']) DB::update('ct_signers', ['viewed_at' => now()], 'id=?', [(int)$s['id']]);
        $this->view('contracts/sign', ['title' => $c['title'] ?: 'Contrat', 's' => $s, 'c' => $c, 'all' => Ct::signers((int)$c['id'])], 'layout/public');
    }
    function signSubmit(string $token): void { \App\Core\Activity::skipRequest();
        $x = $this->signer($token); if (!$x) { http_response_code(404); $this->view('contracts/public_gone', ['title' => 'Lien invalide'], 'layout/public'); return; } [$s, $c] = $x;
        if ($c['doc_status'] !== 'to_sign' || $s['status'] !== 'pending') { flash('Ce document n\'est plus en attente de votre signature.', 'warning'); redirect('sign/c/' . $token); }
        $hash = Ct::hash($c); if ($c['doc_hash'] && !hash_equals($c['doc_hash'], $hash)) { flash('Le texte a changé depuis l\'envoi : demandez un nouvel envoi.', 'danger'); redirect('sign/c/' . $token); }
        if ($this->in('action') === 'reject') {
            $cm = trim((string)$this->in('comment', '')); if (mb_strlen($cm) < 3) { flash('Indiquez le motif du refus.', 'danger'); redirect('sign/c/' . $token); }
            DB::update('ct_signers', ['status' => 'rejected', 'signed_at' => now(), 'ip' => mb_substr(Request::ip(), 0, 45), 'comment' => mb_substr($cm, 0, 500)], 'id=?', [(int)$s['id']]);
            if ($c['created_by']) \App\Core\Notifier::send((int)$c['created_by'], 'Contrat refusé', $s['name'] . ' a refusé de signer « ' . $c['title'] . ' » : ' . mb_substr($cm, 0, 200), '/contracts/' . $c['id']);
            Audit::log('reject', 'contract', $c['id'], null, ['signer' => $s['email']]); flash('Votre refus a été transmis.'); redirect('sign/c/' . $token);
        }
        $mail = strtolower(trim((string)$this->in('email', ''))); $nm = trim((string)$this->in('signed_name', ''));
        if ($mail !== strtolower($s['email'])) { flash('L\'adresse e-mail saisie ne correspond pas à celle du signataire.', 'danger'); redirect('sign/c/' . $token); }
        if (mb_strlen($nm) < 3) { flash('Saisissez votre nom complet pour signer.', 'danger'); redirect('sign/c/' . $token); }
        if (!$this->in('agree')) { flash('Cochez « Lu et approuvé » pour signer.', 'danger'); redirect('sign/c/' . $token); }
        DB::update('ct_signers', ['status' => 'signed', 'signed_name' => mb_substr($nm, 0, 150), 'signed_at' => now(), 'doc_hash' => $hash, 'ip' => mb_substr(Request::ip(), 0, 45)], 'id=?', [(int)$s['id']]);
        Audit::log('sign', 'contract', $c['id'], null, ['signer' => $s['email'], 'role' => $s['role']]);
        if (Ct::refresh((int)$c['id'])) {
            $c = DB::one('SELECT * FROM contracts WHERE id=?', [(int)$c['id']]);
            foreach (Ct::signers((int)$c['id']) as $sg) Ct::mail($sg['email'], 'Contrat signé : ' . $c['title'], "Bonjour {$sg['name']},\n\nToutes les signatures sont réunies pour « {$c['title']} ». Document : " . Ct::abs('sign/c/' . $sg['token']) . "\n");
            foreach (DB::all('SELECT * FROM ct_shares WHERE contract_id=?', [(int)$c['id']]) as $sh) Ct::mail($sh['email'], 'Contrat signé : ' . $c['title'], "Le document « {$c['title']} » est désormais signé par toutes les parties : " . Ct::abs('ctdoc/' . $sh['token']) . "\n");
            if ($c['created_by']) \App\Core\Notifier::send((int)$c['created_by'], 'Contrat signé', '« ' . $c['title'] . ' » est signé par toutes les parties.', '/contracts/' . $c['id']);
        } elseif ($c['created_by']) \App\Core\Notifier::send((int)$c['created_by'], 'Signature reçue', $s['name'] . ' (' . $s['role'] . ') a signé « ' . $c['title'] . ' ».', '/contracts/' . $c['id']);
        flash('Merci, votre signature est enregistrée.'); redirect('sign/c/' . $token);
    }
    function signPdf(string $token): void { \App\Core\Activity::skipRequest(); $x = $this->signer($token); if (!$x || $x[1]['doc_status'] === 'none') { http_response_code(404); echo 'Introuvable'; return; } Ct::pdfOut($x[1], 'contrat-' . $x[1]['id']); }
    private function shared(string $token): ?array {
        if (!preg_match('/^[a-f0-9]{48}$/', $token)) return null; $s = DB::one('SELECT * FROM ct_shares WHERE token=?', [$token]); if (!$s) return null;
        $c = DB::one('SELECT * FROM contracts WHERE id=?', [(int)$s['contract_id']]); return $c ? [$s, $c] : null;
    }
    function sharePage(string $token): void { \App\Core\Activity::skipRequest();
        $x = $this->shared($token); if (!$x) { http_response_code(404); $this->view('contracts/public_gone', ['title' => 'Lien invalide'], 'layout/public'); return; } [$s, $c] = $x;
        if (!$s['viewed_at']) DB::update('ct_shares', ['viewed_at' => now()], 'id=?', [(int)$s['id']]);
        $this->view('contracts/shared', ['title' => $c['title'] ?: 'Contrat', 's' => $s, 'c' => $c, 'all' => Ct::signers((int)$c['id']), 'token' => $token], 'layout/public');
    }
    function sharePdf(string $token): void { \App\Core\Activity::skipRequest(); $x = $this->shared($token); if (!$x) { http_response_code(404); echo 'Introuvable'; return; } Ct::pdfOut($x[1], 'contrat-' . $x[1]['id']); }
    function verify(string $code): void {
        $code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $code)); $c = $code !== '' ? DB::one("SELECT id, title, doc_status, signed_at, doc_hash FROM contracts WHERE verify_code=? AND doc_status IN ('to_sign','signed')", [$code]) : null;
        $this->view('contracts/verify', ['title' => 'Vérification d\'un contrat', 'c' => $c, 'code' => $code, 'sig' => $c ? Ct::signers((int)$c['id']) : []], 'layout/public');
    }
}
