<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, StoreHours};

/** Plages horaires (back office) et horaires d'ouverture des stores (jours × plages à cocher). */
class StoreHoursController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    function slots(): void {
        $rows = DB::all('SELECT s.*, (SELECT COUNT(DISTINCT h.store_id) FROM store_hours h WHERE h.slot_id=s.id) used FROM store_slots s ORDER BY s.sort_order, s.start_time, s.end_time, s.id');
        $this->view('stores/slots', ['title' => 'Plages horaires des stores', 'rows' => $rows]);
    }
    private function parse(): array {
        $st = trim((string)($_POST['start_time'] ?? '')); $en = trim((string)($_POST['end_time'] ?? '')); $name = trim((string)($_POST['name'] ?? '')); $err = [];
        if (!StoreHours::valid($st) || !StoreHours::valid($en)) $err[] = 'Les heures doivent être au format HH:MM.'; elseif ($st === $en) $err[] = 'Le début et la fin doivent être différents.';
        if (mb_strlen($name) > 100) $err[] = 'Le libellé est trop long.';
        return [['name' => $name !== '' ? $name : ($err ? '' : StoreHours::label($st, $en)), 'start_time' => $st, 'end_time' => $en, 'overnight' => ($err || $en > $st) ? 0 : 1, 'active' => empty($_POST['inactive']) ? 1 : 0, 'sort_order' => (int)($_POST['sort_order'] ?? 0)], $err];
    }
    function slotCreate(): void {
        [$d, $err] = $this->parse(); if ($err) $this->go('org/store-slots', implode(' ', $err), 'danger');
        $code = 'S' . str_replace(':', '', $d['start_time']) . '-' . str_replace(':', '', $d['end_time']); if (DB::val('SELECT 1 FROM store_slots WHERE code=?', [$code])) $this->go('org/store-slots', 'Cette plage existe déjà.', 'danger');
        $id = DB::insert('store_slots', $d + ['code' => $code]); Audit::log('create', 'store_slot', (string)$id, null, $d); $this->go('org/store-slots', 'Plage horaire créée.');
    }
    function slotUpdate(string $id): void {
        $old = DB::one('SELECT * FROM store_slots WHERE id=?', [(int)$id]); if (!$old) { $this->notFound(); return; }
        [$d, $err] = $this->parse(); if ($err) $this->go('org/store-slots', implode(' ', $err), 'danger');
        DB::update('store_slots', $d, 'id=?', [(int)$id]); foreach (DB::all('SELECT DISTINCT store_id FROM store_hours WHERE slot_id=?', [(int)$id]) as $r) DB::update('stores', ['hours' => StoreHours::text((int)$r['store_id']) ?: null], 'id=?', [(int)$r['store_id']]);
        Audit::log('update', 'store_slot', $id, $old, $d); $this->go('org/store-slots', 'Plage horaire modifiée ; les horaires des stores concernés ont été recalculés.');
    }
    function slotDelete(string $id): void {
        $s = DB::one('SELECT * FROM store_slots WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; }
        if (DB::val('SELECT 1 FROM store_hours WHERE slot_id=?', [(int)$id])) { DB::update('store_slots', ['active' => 0], 'id=?', [(int)$id]); $this->go('org/store-slots', 'Plage utilisée par des stores : elle a été désactivée au lieu d\'être supprimée.', 'warning'); }
        DB::exec('DELETE FROM store_slots WHERE id=?', [(int)$id]); Audit::log('delete', 'store_slot', $id); $this->go('org/store-slots', 'Plage supprimée.');
    }
    function hours(string $id): void {
        $s = DB::one('SELECT * FROM stores WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; }
        $this->view('stores/hours', ['title' => 'Horaires — ' . $s['name'], 's' => $s, 'slots' => StoreHours::slots(), 'grid' => StoreHours::grid((int)$id), 'open' => StoreHours::openNow((int)$id)]);
    }
    function hoursSave(string $id): void {
        $s = DB::one('SELECT id FROM stores WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; }
        $g = []; foreach ((array)($_POST['h'] ?? []) as $dow => $list) $g[(int)$dow] = array_keys((array)$list);
        $txt = StoreHours::save((int)$id, $g); Audit::log('save', 'store_hours', $id, null, ['text' => $txt]); $this->go("org/stores/$id/hours", 'Horaires enregistrés : ' . ($txt ?: 'aucun jour d\'ouverture') . '.');
    }
}
