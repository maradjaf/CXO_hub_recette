<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Workflow};
class WorkflowController extends Controller {
    function index(): void {
        $w = ['r.requester_id=?']; $p = [Auth::id()];
        if ($this->in('status')) { $w[] = 'r.status=?'; $p[] = $this->in('status'); }
        $pg = paginate('wf_requests r JOIN wf_definitions d ON d.id=r.definition_id WHERE ' . implode(' AND ', $w), $p, $this->page(), 20, 'r.*, d.name def_name', 'r.id DESC');
        $this->view('workflow/index', ['title' => 'Mes demandes', 'p' => $pg]);
    }
    function inbox(): void {
        $rows = [];
        foreach (DB::all("SELECT r.*, d.name def_name, u.name requester FROM wf_requests r JOIN wf_definitions d ON d.id=r.definition_id JOIN users u ON u.id=r.requester_id WHERE r.status='pending' ORDER BY r.due_at") as $r)
            if (Workflow::canAct(Auth::id(), $r)) $rows[] = $r + ['step' => Workflow::step($r)];
        $this->view('workflow/inbox', ['title' => 'À valider', 'rows' => $rows]);
    }
    function create(): void { $this->view('workflow/form', ['title' => 'Nouvelle demande', 'defs' => DB::all('SELECT d.*, (SELECT COUNT(*) FROM wf_steps s WHERE s.definition_id=d.id) n FROM wf_definitions d WHERE d.active=1 ORDER BY d.name')]); }
    function store(): void {
        [$d, $err] = $this->validate(['title' => ['label' => 'L\'objet', 'req' => true, 'max' => 190], 'description' => ['label' => 'Le détail', 'max' => 4000]], $_POST);
        $def = (int)$this->in('definition_id');
        if (!DB::val('SELECT 1 FROM wf_definitions WHERE id=? AND active=1', [$def]) || !Workflow::steps($def)) $err['def'] = 'Choisissez un circuit valide.';
        if ($err) $this->back($err, $_POST, 'workflow/new');
        $id = Workflow::start($def, $d['title'], $d['description']);
        Audit::log('create', 'wf_request', $id, null, $d + ['definition_id' => $def]);
        flash('Demande envoyée.'); redirect("workflow/$id");
    }
    function show(string $id): void {
        $r = DB::one('SELECT r.*, d.name def_name, u.name requester FROM wf_requests r JOIN wf_definitions d ON d.id=r.definition_id JOIN users u ON u.id=r.requester_id WHERE r.id=?', [(int)$id]);
        if (!$r) { $this->notFound(); return; }
        if ((int)$r['requester_id'] !== Auth::id() && !can('workflow.approve') && !can('workflow.manage')) { $this->forbidden(); return; }
        $this->view('workflow/show', ['title' => $r['reference'], 'r' => $r, 'steps' => Workflow::steps((int)$r['definition_id']), 'actions' => DB::all('SELECT * FROM wf_actions WHERE request_id=? ORDER BY id', [(int)$id]),
            'canAct' => Workflow::canAct(Auth::id(), $r), 'mine' => (int)$r['requester_id'] === Auth::id(), 'approvers' => $r['status'] === 'pending' ? DB::all('SELECT name FROM users WHERE id IN (' . implode(',', array_map('intval', Workflow::approvers($r) ?: [0])) . ')') : []]);
    }
    function act(string $id): void {
        $r = DB::one('SELECT * FROM wf_requests WHERE id=?', [(int)$id]); if (!$r) { $this->notFound(); return; }
        $a = (string)$this->in('action'); if (!in_array($a, ['approve', 'reject', 'comment', 'cancel'], true)) { flash('Action inconnue.', 'danger'); redirect("workflow/$id"); }
        if ($a === 'comment' && (int)$r['requester_id'] !== Auth::id() && !can('workflow.approve') && !can('workflow.manage')) { $this->forbidden(); return; }
        $msg = Workflow::act($r, $a, trim((string)$this->in('comment', '')));
        Audit::log('wf_' . $a, 'wf_request', $id, ['status' => $r['status'], 'step' => $r['current_step']], ['result' => $msg]);
        flash($msg, str_contains($msg, 'pas habilité') || str_contains($msg, 'obligatoire') || str_contains($msg, 'clôturée') || str_contains($msg, 'Seul') ? 'danger' : 'success'); redirect("workflow/$id");
    }
    // --- Définitions des circuits ---
    function definitions(): void { $this->view('workflow/definitions', ['title' => 'Circuits de validation', 'rows' => DB::all('SELECT d.*, (SELECT COUNT(*) FROM wf_steps s WHERE s.definition_id=d.id) n, (SELECT COUNT(*) FROM wf_requests r WHERE r.definition_id=d.id) used FROM wf_definitions d ORDER BY d.name')]); }
    function storeDefinition(): void {
        [$d, $err] = $this->validate(['code' => ['label' => 'Le code', 'req' => true, 'max' => 60], 'name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'description' => ['label' => 'La description', 'max' => 500]], $_POST);
        if ($d['code'] && !preg_match('/^[A-Za-z0-9_]+$/', $d['code'])) $err['code'] = 'Code : lettres, chiffres et _ uniquement.';
        if ($d['code'] && DB::val('SELECT 1 FROM wf_definitions WHERE code=?', [$d['code']])) $err['code'] = 'Ce code existe déjà.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('workflow/definitions'); }
        $d['active'] = 1; $id = DB::insert('wf_definitions', $d); Audit::log('create', 'wf_definition', $id, null, $d); redirect("workflow/definitions/$id");
    }
    function definition(string $id): void {
        $d = DB::one('SELECT * FROM wf_definitions WHERE id=?', [(int)$id]); if (!$d) { $this->notFound(); return; }
        $this->view('workflow/definition', ['title' => $d['name'], 'd' => $d, 'steps' => Workflow::steps((int)$id), 'roles' => DB::all('SELECT code, name FROM roles ORDER BY name'), 'users' => DB::all("SELECT id, name FROM users WHERE status='active' ORDER BY name")]);
    }
    function updateDefinition(string $id): void {
        $d = DB::one('SELECT * FROM wf_definitions WHERE id=?', [(int)$id]); if (!$d) { $this->notFound(); return; }
        [$n, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'description' => ['label' => 'La description', 'max' => 500]], $_POST);
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("workflow/definitions/$id"); }
        $n['active'] = isset($_POST['active']) ? 1 : 0; DB::update('wf_definitions', $n, 'id=?', [(int)$id]); Audit::log('update', 'wf_definition', $id, $d, $n);
        flash('Circuit enregistré.'); redirect("workflow/definitions/$id");
    }
    function storeStep(string $id): void {
        if (!DB::val('SELECT 1 FROM wf_definitions WHERE id=?', [(int)$id])) { $this->notFound(); return; }
        $type = (string)$this->in('approver_type'); $ref = (string)$this->in('approver_ref', '');
        $name = trim((string)$this->in('name', '')); $sla = (int)$this->in('sla_hours', 48);
        if ($name === '' || !in_array($type, ['manager', 'role', 'user'], true) || ($type !== 'manager' && $ref === '') || $sla < 1) { flash('Renseignez le nom, l\'approbateur et un délai valide.', 'danger'); redirect("workflow/definitions/$id"); }
        if ($type === 'role' && !DB::val('SELECT 1 FROM roles WHERE code=?', [$ref])) { flash('Choisissez un rôle dans la liste.', 'danger'); redirect("workflow/definitions/$id"); }
        if ($type === 'user' && !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [(int)$ref])) { flash('Choisissez un utilisateur actif dans la liste.', 'danger'); redirect("workflow/definitions/$id"); }
        $row = ['definition_id' => (int)$id, 'position' => (int)DB::val('SELECT COALESCE(MAX(position),0)+1 FROM wf_steps WHERE definition_id=?', [(int)$id]), 'name' => $name, 'approver_type' => $type, 'approver_ref' => $type === 'manager' ? null : $ref, 'sla_hours' => $sla];
        $sid = DB::insert('wf_steps', $row); Audit::log('create', 'wf_step', $sid, null, $row); flash('Étape ajoutée.'); redirect("workflow/definitions/$id");
    }
    function deleteStep(string $id, string $sid): void {
        $s = DB::one('SELECT * FROM wf_steps WHERE id=? AND definition_id=?', [(int)$sid, (int)$id]); if (!$s) { $this->notFound(); return; }
        if (DB::val("SELECT 1 FROM wf_requests WHERE definition_id=? AND status='pending'", [(int)$id])) { flash('Des demandes sont en cours sur ce circuit : désactivez-le plutôt que de modifier ses étapes.', 'warning'); redirect("workflow/definitions/$id"); }
        DB::exec('DELETE FROM wf_steps WHERE id=?', [(int)$sid]); Audit::log('delete', 'wf_step', $sid, $s); flash('Étape supprimée.'); redirect("workflow/definitions/$id");
    }
}
