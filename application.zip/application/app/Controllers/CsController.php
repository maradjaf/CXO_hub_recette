<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Kb, Sop, Cs, Ref, Scope};
class CsController extends Controller {
    private function me(): int { return (int)(Auth::user()['employee_id'] ?? 0); }
    private function teamId(): int { return (int)DB::val('SELECT team_id FROM employees WHERE id=?', [$this->me()]); }
    private function readable(string $id): ?array {
        $s = DB::one('SELECT s.*, ch.name channel FROM cs_scripts s LEFT JOIN channels ch ON ch.id=s.channel_id WHERE s.id=?', [(int)$id]); if (!$s) return null;
        if (can('cs.manage')) return $s;
        return $s['status'] === 'published' && (!$s['team_id'] || (int)$s['team_id'] === $this->teamId()) ? $s : null;
    }
    // =============== Bibliothèque ===============
    function library(): void {
        $q = trim((string)$this->in('q', '')); $kind = (string)$this->in('kind', ''); $ch = (int)$this->in('channel', 0); $fam = (string)$this->in('family', ''); $fav = $this->in('fav') === '1'; $uid = (int)Auth::id();
        $w = ["s.status='published'"]; $p = [];
        if (!can('cs.manage')) { $w[] = '(s.team_id IS NULL OR s.team_id=?)'; $p[] = $this->teamId(); }
        if ($q !== '') { $w[] = '(LOWER(s.title) LIKE ? OR LOWER(s.situation) LIKE ? OR LOWER(s.body) LIKE ? OR LOWER(s.keywords) LIKE ?)'; $l = '%' . mb_strtolower($q) . '%'; array_push($p, $l, $l, $l, $l); }
        if ($kind !== '') { $w[] = 's.kind=?'; $p[] = $kind; }
        if ($fam !== '') { $w[] = 's.family=?'; $p[] = $fam; }
        if ($ch) { $w[] = 's.channel_id=?'; $p[] = $ch; }
        if ($fav) { $w[] = 's.id IN (SELECT script_id FROM cs_favs WHERE user_id=?)'; $p[] = $uid; }
        $rows = DB::all('SELECT s.id, s.ref, s.title, s.kind, s.family, s.situation, s.version, s.mandatory, ch.name channel FROM cs_scripts s LEFT JOIN channels ch ON ch.id=s.channel_id WHERE ' . implode(' AND ', $w) . ' ORDER BY s.kind, s.title LIMIT 300', $p);
        $this->view('cs/library', ['title' => 'Scripts', 'rows' => $rows, 'q' => $q, 'kind' => $kind, 'fam' => $fam, 'ch' => $ch, 'fav' => $fav, 'channels' => DB::all('SELECT id, name FROM channels WHERE active=1 ORDER BY name'),
            'favs' => array_map('intval', array_column(DB::all('SELECT script_id FROM cs_favs WHERE user_id=?', [$uid]), 'script_id')), 'pend' => array_column(array_filter(Sop::pendingReads(), fn($x) => $x['kind'] === 'script'), 'id')]);
    }
    function show(string $id): void {
        $s = $this->readable($id); if (!$s) { $this->notFound(); return; }
        if ($s['status'] === 'published' && empty($_SESSION['_csv'][$s['id']])) { DB::exec('UPDATE cs_scripts SET views=views+1 WHERE id=?', [(int)$s['id']]); $_SESSION['_csv'][$s['id']] = 1; }
        $uid = (int)Auth::id();
        $this->view('cs/show', ['title' => $s['ref'] . ' · ' . $s['title'], 's' => $s, 'pts' => Cs::points((int)$id), 'vars' => Cs::vars($s['body']), 'fav' => (bool)DB::val('SELECT 1 FROM cs_favs WHERE user_id=? AND script_id=?', [$uid, (int)$id]),
            'acked' => Sop::acked('script', (int)$id, (int)$s['version'], $uid), 'codes' => DB::all('SELECT code, label FROM cs_end_codes WHERE closing_script_id=? AND active=1 ORDER BY sort_order', [(int)$id]),
            'nread' => can('cs.manage') ? (int)DB::val("SELECT COUNT(*) FROM kb_acks WHERE kind='script' AND item_id=? AND version=?", [(int)$id, (int)$s['version']]) : null,
            'owner' => $s['owner_id'] ? DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [(int)$s['owner_id']]) : null]);
    }
    function fav(string $id): void {
        $s = $this->readable($id); if (!$s) { $this->notFound(); return; }
        if (DB::val('SELECT 1 FROM cs_favs WHERE user_id=? AND script_id=?', [Auth::id(), (int)$id])) DB::exec('DELETE FROM cs_favs WHERE user_id=? AND script_id=?', [Auth::id(), (int)$id]); else DB::insert('cs_favs', ['user_id' => Auth::id(), 'script_id' => (int)$id]);
        redirect($this->in('back') === 'lib' ? 'cs' : "cs/$id");
    }
    function ack(string $id): void {
        $s = $this->readable($id); if (!$s || $s['status'] !== 'published') { $this->notFound(); return; }
        Sop::ack('script', (int)$id, (int)$s['version'], (int)Auth::id()); flash('Lecture enregistrée : merci.'); redirect("cs/$id");
    }
    // =============== Gestion des scripts ===============
    function manage(): void {
        $st = (string)$this->in('status', ''); $w = ['1=1']; $p = [];
        if ($st !== '' && isset(Kb::ST[$st])) { $w[] = 's.status=?'; $p[] = $st; }
        if ($this->in('stale') === '1') { $w[] = "s.status='published' AND s.review_due IS NOT NULL AND s.review_due<?"; $p[] = date('Y-m-d'); }
        $rows = DB::all('SELECT s.*, ch.name channel, (SELECT COUNT(*) FROM kb_acks k WHERE k.kind=\'script\' AND k.item_id=s.id AND k.version=s.version) nread, (SELECT COUNT(*) FROM cs_checks c WHERE c.script_id=s.id) nchecks FROM cs_scripts s LEFT JOIN channels ch ON ch.id=s.channel_id WHERE ' . implode(' AND ', $w) . ' ORDER BY s.updated_at DESC LIMIT 300', $p);
        $this->view('cs/manage', ['title' => 'Gérer les scripts', 'rows' => $rows, 'st' => $st]);
    }
    private function form(?array $s, array $pts): void {
        $this->view('cs/form', ['title' => $s ? 'Modifier ' . $s['ref'] : 'Nouveau script', 's' => $s, 'pts' => $pts, 'channels' => DB::all('SELECT id, name FROM channels WHERE active=1 ORDER BY name'), 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'),
            'emps' => DB::all("SELECT id, first_name, last_name FROM employees WHERE status<>'left' ORDER BY last_name, first_name"), 'versions' => $s ? DB::all('SELECT version, user_name, note, created_at FROM cs_script_versions WHERE script_id=? ORDER BY version DESC', [(int)$s['id']]) : []]);
    }
    function create(): void { $this->form(null, [['label' => '', 'weight' => 1, 'mandatory' => 1]]); }
    function edit(string $id): void { $s = DB::one('SELECT * FROM cs_scripts WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; } $this->form($s, Cs::points((int)$id) ?: [['label' => '', 'weight' => 1, 'mandatory' => 1]]); }
    private function data(): array {
        [$d, $err] = $this->validate(['title' => ['label' => 'Le titre', 'req' => true, 'max' => 200], 'situation' => ['label' => 'La situation', 'max' => 300], 'body' => ['label' => 'Le texte du script', 'req' => true, 'max' => 20000], 'avoid' => ['label' => 'Les formulations à éviter', 'max' => 3000], 'required_phrases' => ['label' => 'Les formules obligatoires', 'max' => 3000], 'review_due' => ['label' => 'La date de revue', 'date' => true]], $_POST);
        $k = (string)$this->in('kind', ''); if ($k !== '' && !Ref::has('script_kinds', $k)) $err['kind'] = 'Type de script inconnu.'; $d['kind'] = $k ?: null;
        $ch = (int)$this->in('channel_id', 0); $d['channel_id'] = $ch && DB::val('SELECT 1 FROM channels WHERE id=?', [$ch]) ? $ch : null;
        $tm = (int)$this->in('team_id', 0); $d['team_id'] = $tm && DB::val('SELECT 1 FROM teams WHERE id=?', [$tm]) ? $tm : null;
        $ow = (int)$this->in('owner_id', 0); $d['owner_id'] = $ow && DB::val('SELECT 1 FROM employees WHERE id=?', [$ow]) ? $ow : null;
        $lg = trim((string)$this->in('language', 'fr')); $d['language'] = preg_match('/^[a-z]{2}(-[A-Z]{2})?$/', $lg) ? $lg : 'fr';
        $d['mandatory'] = $this->in('mandatory') ? 1 : 0; $d['updated_at'] = now();
        return [$d, $err];
    }
    function store(): void {
        [$d, $err] = $this->data(); [$pts, $e2] = Cs::readPoints(); if ($e2) $err['pts'] = $e2;
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); $_SESSION['_old'] = $_POST; redirect('cs/new'); }
        $id = DB::insert('cs_scripts', $d + ['ref' => Sop::nextRef('cs_scripts', 'SC'), 'version' => 1, 'status' => 'draft', 'author_id' => Auth::id(), 'created_at' => now()]);
        Cs::replacePoints($id, $pts); Cs::snapshot($id, 'Création'); Audit::log('create', 'cs_script', $id, null, ['title' => $d['title']]); flash('Script enregistré en brouillon.'); redirect("cs/$id");
    }
    function update(string $id): void {
        $s = DB::one('SELECT * FROM cs_scripts WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; }
        [$d, $err] = $this->data(); [$pts, $e2] = Cs::readPoints(); if ($e2) $err['pts'] = $e2;
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("cs/$id/edit"); }
        if ($s['status'] === 'rejected') $d['status'] = 'draft';
        if ($s['status'] === 'published' && $this->in('new_version') === '1') { $d['version'] = (int)$s['version'] + 1; $d['published_at'] = now(); $d['review_notified_at'] = null; $d['review_due'] = $d['review_due'] ?: date('Y-m-d', strtotime('+' . Cs::months() . ' months')); }
        if (!$d['review_due']) unset($d['review_due']);
        DB::update('cs_scripts', $d, 'id=?', [(int)$id]); Cs::replacePoints((int)$id, $pts); Cs::snapshot((int)$id, trim((string)$this->in('note', '')) ?: ($this->in('new_version') === '1' ? 'Nouvelle version' : 'Modification'));
        Audit::log('update', 'cs_script', $id, ['title' => $s['title'], 'version' => $s['version']], ['title' => $d['title'], 'version' => $d['version'] ?? $s['version']]);
        if (!empty($d['version']) && $d['mandatory']) Notifier::toPermission('cs.view', 'Script mis à jour : à relire', $s['ref'] . ' ' . $d['title'] . ' (version ' . $d['version'] . ')', '/cs/' . $id);
        flash('Script enregistré' . (!empty($d['version']) ? ' (version ' . $d['version'] . ').' : '.')); redirect("cs/$id");
    }
    function status(string $id): void {
        $s = DB::one('SELECT * FROM cs_scripts WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; }
        $act = (string)$this->in('action'); $u = ['updated_at' => now()]; $note = trim((string)$this->in('note', ''));
        if ($act === 'submit' && in_array($s['status'], ['draft', 'rejected'], true)) { if (!trim((string)$s['body'])) { flash('Le script est vide.', 'danger'); redirect("cs/$id"); } $u['status'] = 'pending'; $u['review_note'] = null; Notifier::toPermission('cs.manage', 'Script à relire', $s['ref'] . ' ' . $s['title'], '/cs/' . $id); $m = 'Soumis à la relecture.'; }
        elseif ($act === 'publish' && in_array($s['status'], ['pending', 'draft', 'rejected'], true)) {
            if ((int)$s['author_id'] === Auth::id() && $s['status'] === 'pending' && !can('admin.access') && (string)setting('cs.four_eyes', '1') === '1') { flash('La relecture doit être faite par une autre personne que l\'auteur.', 'warning'); redirect("cs/$id"); }
            $u += ['status' => 'published', 'reviewer_id' => Auth::id(), 'review_note' => null, 'published_at' => now(), 'review_due' => $s['review_due'] && $s['review_due'] > date('Y-m-d') ? $s['review_due'] : date('Y-m-d', strtotime('+' . Cs::months() . ' months')), 'review_notified_at' => null];
            if ($s['author_id'] && (int)$s['author_id'] !== Auth::id()) Notifier::send((int)$s['author_id'], 'Script publié', $s['title'], '/cs/' . $id);
            if ($s['mandatory']) Notifier::toPermission('cs.view', 'Script à lire : ' . $s['title'], $s['ref'] . ' — lecture à confirmer', '/cs/' . $id); $m = 'Publié.';
        } elseif ($act === 'reject' && $s['status'] === 'pending') { if ($note === '') { flash('Indiquez ce qu\'il faut corriger.', 'danger'); redirect("cs/$id"); } $u += ['status' => 'rejected', 'review_note' => mb_substr($note, 0, 500), 'reviewer_id' => Auth::id()]; if ($s['author_id']) Notifier::send((int)$s['author_id'], 'Script à corriger', $s['title'] . ' : ' . mb_substr($note, 0, 100), '/cs/' . $id . '/edit'); $m = 'Renvoyé à l\'auteur.'; }
        elseif ($act === 'archive' && $s['status'] !== 'archived') { $u['status'] = 'archived'; $m = 'Archivé.'; }
        elseif ($act === 'unpublish' && $s['status'] === 'published') { $u['status'] = 'draft'; $m = 'Dépublié.'; }
        elseif ($act === 'restore' && $s['status'] === 'archived') { $u['status'] = 'draft'; $m = 'Restauré en brouillon.'; }
        else { $this->forbidden(); return; }
        DB::update('cs_scripts', $u, 'id=?', [(int)$id]); Audit::log($act, 'cs_script', $id, ['status' => $s['status']], ['status' => $u['status']]); flash($m); redirect("cs/$id");
    }
    function versions(string $id): void {
        $s = DB::one('SELECT * FROM cs_scripts WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; }
        $vs = DB::all('SELECT * FROM cs_script_versions WHERE script_id=? ORDER BY version DESC', [(int)$id]); $sel = (int)$this->in('v', 0); $cur = $sel ? DB::one('SELECT * FROM cs_script_versions WHERE script_id=? AND version=?', [(int)$id, $sel]) : null;
        $this->view('cs/versions', ['title' => 'Historique ' . $s['ref'], 's' => $s, 'vs' => $vs, 'cur' => $cur, 'snap' => $cur ? json_decode($cur['data'], true) : null]);
    }
    function restore(string $id, string $v): void {
        $s = DB::one('SELECT * FROM cs_scripts WHERE id=?', [(int)$id]); $x = DB::one('SELECT * FROM cs_script_versions WHERE script_id=? AND version=?', [(int)$id, (int)$v]); if (!$s || !$x) { $this->notFound(); return; }
        $data = json_decode($x['data'], true); $f = array_intersect_key($data['f'] ?? [], array_flip(Cs::FIELDS)); if (!$f) { $this->notFound(); return; }
        $ver = $s['status'] === 'published' ? (int)$s['version'] + 1 : (int)$s['version'];
        DB::update('cs_scripts', $f + ['version' => $ver, 'updated_at' => now()], 'id=?', [(int)$id]); Cs::replacePoints((int)$id, $data['points'] ?? []); Cs::snapshot((int)$id, 'Restauration de la version ' . (int)$v);
        Audit::log('restore', 'cs_script', $id, null, ['version' => (int)$v]); flash('Version ' . (int)$v . ' restaurée.'); redirect("cs/$id");
    }
    function reads(string $id): void {
        $s = DB::one('SELECT * FROM cs_scripts WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; }
        $aud = Sop::audience($s['team_id'] ? (int)$s['team_id'] : null);
        foreach ($aud as &$a) $a['read_at'] = DB::val("SELECT read_at FROM kb_acks WHERE kind='script' AND item_id=? AND version=? AND user_id=?", [(int)$id, (int)$s['version'], (int)$a['user_id']]); unset($a);
        if ($this->in('export') === 'csv') csv_download('lecture_' . $s['ref'] . '.csv', ['Matricule', 'Nom', 'Prénom', 'Version', 'Lu le'], array_map(fn($a) => [$a['matricule'], $a['last_name'], $a['first_name'], $s['version'], $a['read_at']], $aud));
        $this->view('cs/reads', ['title' => 'Lectures ' . $s['ref'], 's' => $s, 'aud' => $aud]);
    }
    function remind(string $id): void {
        $s = DB::one("SELECT * FROM cs_scripts WHERE id=? AND status='published'", [(int)$id]); if (!$s) { $this->notFound(); return; }
        $n = 0; foreach (Sop::audience($s['team_id'] ? (int)$s['team_id'] : null) as $a) if (!Sop::acked('script', (int)$id, (int)$s['version'], (int)$a['user_id'])) { Notifier::send((int)$a['user_id'], 'Lecture à confirmer', $s['ref'] . ' ' . $s['title'], '/cs/' . $id); $n++; }
        flash("$n relance(s) envoyée(s)."); redirect("cs/$id/reads");
    }
    // =============== Contrôles d'adhérence ===============
    function checks(): void {
        [$sw, $sp] = Cs::checkScope(); $w = [$sw]; $p = $sp; $emp = (int)$this->in('employee', 0); $sc = (int)$this->in('script', 0); $res = (string)$this->in('result', '');
        if ($emp) { $w[] = 'c.employee_id=?'; $p[] = $emp; } if ($sc) { $w[] = 'c.script_id=?'; $p[] = $sc; } if (in_array($res, ['pass', 'fail'], true)) { $w[] = 'c.result=?'; $p[] = $res; }
        $from = 'cs_checks c JOIN employees e ON e.id=c.employee_id LEFT JOIN cs_scripts s ON s.id=c.script_id LEFT JOIN cs_end_codes k ON k.id=c.end_code_id LEFT JOIN cs_end_codes kx ON kx.id=c.expected_code_id WHERE ' . implode(' AND ', $w);
        if ($this->in('export') === 'csv' && can('cs.check')) csv_download('controles_scripts.csv', ['Réf.', 'Date', 'Collaborateur', 'Appel', 'Script', 'Code posé', 'Code attendu', 'ACW (s)', 'Suivi', 'Score %', 'Résultat'],
            array_map(fn($r) => [$r['ref'], $r['check_date'], $r['last_name'] . ' ' . $r['first_name'], $r['call_ref'], $r['script'], $r['kcode'], $r['xcode'], $r['acw_seconds'], Cs::FOLLOW[$r['followed']] ?? '', $r['score_pct'], $r['result'] === 'pass' ? 'Conforme' : 'Non conforme'], DB::all("SELECT c.*, e.first_name, e.last_name, s.title script, k.code kcode, kx.code xcode FROM $from ORDER BY c.check_date DESC, c.id DESC LIMIT 5000", $p)));
        $pg = paginate($from, $p, $this->page(), 25, 'c.*, e.first_name, e.last_name, s.ref sref, s.title script, k.code kcode, kx.code xcode', 'c.check_date DESC, c.id DESC');
        $this->view('cs/checks', ['title' => 'Contrôles d\'adhérence', 'p' => $pg, 'emp' => $emp, 'sc' => $sc, 'res' => $res, 'emps' => can('cs.check') ? Scope::employees() : [], 'scripts' => DB::all("SELECT id, ref, title FROM cs_scripts WHERE status<>'draft' ORDER BY title")]);
    }
    function newCheck(): void {
        $sid = (int)$this->in('script', 0); $s = $sid ? DB::one("SELECT * FROM cs_scripts WHERE id=? AND status='published'", [$sid]) : null;
        $this->view('cs/check_form', ['title' => 'Nouveau contrôle', 's' => $s, 'pts' => $s ? Cs::points($sid) : [], 'emps' => Scope::employees(), 'scripts' => DB::all("SELECT id, ref, title FROM cs_scripts WHERE status='published' ORDER BY title"),
            'codes' => DB::all('SELECT id, code, label FROM cs_end_codes WHERE active=1 ORDER BY sort_order, label'), 'channels' => DB::all('SELECT id, name FROM channels WHERE active=1 ORDER BY name'), 'emp' => (int)$this->in('employee', 0)]);
    }
    function storeCheck(): void {
        $emp = (int)$this->in('employee_id', 0); $err = [];
        if (!$emp || !Scope::allows($emp) || !DB::val("SELECT 1 FROM employees WHERE id=? AND status<>'left'", [$emp])) $err[] = 'Choisissez un collaborateur de votre périmètre.';
        if ($emp === $this->me() && !can('admin.access')) $err[] = 'Vous ne pouvez pas vous évaluer vous-même.';
        $date = (string)$this->in('check_date', date('Y-m-d')); if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || $date > date('Y-m-d')) $err[] = 'Date du contrôle invalide (pas dans le futur).';
        $sid = (int)$this->in('script_id', 0); $s = $sid ? DB::one('SELECT * FROM cs_scripts WHERE id=?', [$sid]) : null; if ($sid && !$s) $err[] = 'Script inconnu.';
        $kc = (int)$this->in('end_code_id', 0) ?: null; $xc = (int)$this->in('expected_code_id', 0) ?: null; foreach ([$kc, $xc] as $c) if ($c && !DB::val('SELECT 1 FROM cs_end_codes WHERE id=?', [$c])) $err[] = 'Code de fin d\'appel inconnu.';
        $acw = trim((string)$this->in('acw_seconds', '')); if ($acw !== '' && (!ctype_digit($acw) || (int)$acw > 7200)) $err[] = 'Durée de traitement après appel invalide (secondes).';
        $comment = mb_substr(trim((string)$this->in('comment', '')), 0, 1000); $kcRow = $kc ? DB::one('SELECT * FROM cs_end_codes WHERE id=?', [$kc]) : null;
        if ($kcRow && $kcRow['needs_note'] && $comment === '') $err[] = 'Ce code de fin d\'appel exige un commentaire.';
        $pts = []; if ($s) foreach (Cs::points($sid) as $p) $pts[] = $p + ['ok' => !empty($_POST['pt'][$p['id']]) ? 1 : 0];
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('cs/checks/new' . ($sid ? "?script=$sid" : '')); }
        [$score, $mand, $fol] = $s ? Cs::score($pts) : [null, true, null]; $res = $s ? (($score >= Cs::target() && $mand) ? 'pass' : 'fail') : ((!$xc || $xc === $kc) ? 'pass' : 'fail');
        $id = DB::insert('cs_checks', ['ref' => Sop::nextRef('cs_checks', 'CK'), 'employee_id' => $emp, 'evaluator_id' => Auth::id(), 'check_date' => $date, 'channel_id' => (int)$this->in('channel_id', 0) ?: null, 'call_ref' => mb_substr(trim((string)$this->in('call_ref', '')), 0, 100) ?: null, 'script_id' => $sid ?: null,
            'end_code_id' => $kc, 'expected_code_id' => $xc, 'acw_seconds' => $acw !== '' ? (int)$acw : null, 'followed' => $fol, 'score_pct' => $score, 'result' => $res, 'comment' => $comment ?: null, 'status' => 'submitted', 'created_at' => now()]);
        foreach ($pts as $p) DB::insert('cs_check_points', ['check_id' => $id, 'point_id' => (int)$p['id'], 'label' => $p['label'], 'mandatory' => $p['mandatory'], 'weight' => $p['weight'], 'ok' => $p['ok']]);
        if ($u = DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [$emp])) Notifier::send((int)$u, 'Nouveau contrôle de script', 'Résultat : ' . ($res === 'pass' ? 'conforme' : 'à améliorer'), '/cs/checks/' . $id);
        Audit::log('create', 'cs_check', $id, null, ['employee' => $emp, 'result' => $res]); flash('Contrôle enregistré (' . ($res === 'pass' ? 'conforme' : 'non conforme') . ').'); redirect("cs/checks/$id");
    }
    private function checkRow(string $id): ?array {
        [$sw, $sp] = Cs::checkScope();
        return DB::one("SELECT c.*, e.first_name, e.last_name, s.ref sref, s.title script, k.code kcode, k.label klabel, kx.code xcode, kx.label xlabel, u.name evaluator FROM cs_checks c JOIN employees e ON e.id=c.employee_id LEFT JOIN cs_scripts s ON s.id=c.script_id LEFT JOIN cs_end_codes k ON k.id=c.end_code_id LEFT JOIN cs_end_codes kx ON kx.id=c.expected_code_id LEFT JOIN users u ON u.id=c.evaluator_id WHERE c.id=? AND $sw", array_merge([(int)$id], $sp));
    }
    function showCheck(string $id): void {
        $c = $this->checkRow($id); if (!$c) { $this->notFound(); return; }
        $this->view('cs/check_show', ['title' => 'Contrôle ' . $c['ref'], 'c' => $c, 'pts' => DB::all('SELECT * FROM cs_check_points WHERE check_id=? ORDER BY id', [(int)$id]), 'mine' => (int)$c['employee_id'] === $this->me()]);
    }
    function ackCheck(string $id): void {
        $c = $this->checkRow($id); if (!$c || (int)$c['employee_id'] !== $this->me() || $c['status'] !== 'submitted') { $this->forbidden(); return; }
        DB::update('cs_checks', ['status' => 'acked', 'ack_at' => now(), 'ack_comment' => mb_substr(trim((string)$this->in('comment', '')), 0, 500) ?: null], 'id=?', [(int)$id]); flash('Retour pris en compte.'); redirect("cs/checks/$id");
    }
    // =============== Statistiques ===============
    function stats(): void {
        $from = (string)$this->in('from', date('Y-m-d', strtotime('-90 days'))); $to = (string)$this->in('to', date('Y-m-d'));
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) { $from = date('Y-m-d', strtotime('-90 days')); $to = date('Y-m-d'); }
        [$sw, $sp] = Cs::checkScope(); $base = "c.check_date>=? AND c.check_date<=? AND $sw"; $bp = array_merge([$from, $to], $sp);
        $agents = DB::all("SELECT e.id, e.first_name, e.last_name, COUNT(*) n, AVG(c.score_pct) score, SUM(CASE WHEN c.result='pass' THEN 1 ELSE 0 END) ok, SUM(CASE WHEN c.expected_code_id IS NOT NULL AND c.end_code_id IS NOT NULL AND c.expected_code_id<>c.end_code_id THEN 1 ELSE 0 END) wrong, SUM(CASE WHEN c.expected_code_id IS NOT NULL THEN 1 ELSE 0 END) coded, AVG(c.acw_seconds) acw FROM cs_checks c JOIN employees e ON e.id=c.employee_id WHERE $base GROUP BY e.id, e.first_name, e.last_name ORDER BY score", $bp);
        $scripts = DB::all("SELECT s.id, s.ref, s.title, COUNT(*) n, AVG(c.score_pct) score FROM cs_checks c JOIN cs_scripts s ON s.id=c.script_id WHERE $base GROUP BY s.id, s.ref, s.title ORDER BY score", $bp);
        $misses = DB::all("SELECT p.label, COUNT(*) n, SUM(CASE WHEN p.ok=0 THEN 1 ELSE 0 END) ko FROM cs_check_points p JOIN cs_checks c ON c.id=p.check_id WHERE $base GROUP BY p.label ORDER BY (SUM(CASE WHEN p.ok=0 THEN 1.0 ELSE 0 END)/COUNT(*)) DESC, n DESC LIMIT 8", $bp);
        $codes = DB::all("SELECT k.code, k.label, k.category, k.acw_target_sec, COUNT(*) n, AVG(c.acw_seconds) acw FROM cs_checks c JOIN cs_end_codes k ON k.id=c.end_code_id WHERE $base GROUP BY k.code, k.label, k.category, k.acw_target_sec ORDER BY n DESC", $bp);
        $min = max(0, (int)setting('cs.check_min_per_agent', 4)); $mStart = date('Y-m-01'); $under = [];
        if ($min) { [$ew, $ep] = Scope::sql('e.id'); $under = DB::all("SELECT e.id, e.first_name, e.last_name, (SELECT COUNT(*) FROM cs_checks c WHERE c.employee_id=e.id AND c.check_date>=?) n FROM employees e WHERE e.status='active' AND $ew AND e.id IN (SELECT employee_id FROM users WHERE employee_id IS NOT NULL) ORDER BY n, e.last_name", array_merge([$mStart], $ep)); $under = array_values(array_filter($under, fn($r) => (int)$r['n'] < $min)); }
        $tot = DB::one("SELECT COUNT(*) n, AVG(c.score_pct) score, SUM(CASE WHEN c.result='pass' THEN 1 ELSE 0 END) ok FROM cs_checks c WHERE $base", $bp);
        $this->view('cs/stats', ['title' => 'Statistiques des scripts et fins d\'appel', 'from' => $from, 'to' => $to, 'agents' => $agents, 'scripts' => $scripts, 'misses' => $misses, 'codes' => $codes, 'under' => $under, 'min' => $min, 'tot' => $tot]);
    }
    // =============== Import de la bibliothèque ===============
    function importForm(): void { $this->view('cs/import', ['title' => 'Importer une bibliothèque de scripts', 'tab' => 'import', 'report' => $_SESSION['_imp'] ?? null]); unset($_SESSION['_imp']); }
    /** Modèle JSON de bibliothèque de scripts (id, titre, script obligatoires). */
    function template(): void {
        $j = json_encode(['scripts' => [['id' => 'SC-001', 'titre' => 'Accueil du client', 'p' => '', 'kw' => 'accueil, bonjour', 'script' => "Bonjour [Prénom], je suis ravi de vous accompagner aujourd'hui. Comment puis-je vous aider ?"], ['id' => 'SC-002', 'titre' => 'Clôture de l\'appel', 'kw' => 'fin, merci', 'script' => 'Merci de votre appel, excellente journée.']]], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        header('Content-Type: application/json; charset=utf-8'); header('Content-Disposition: attachment; filename="modele-bibliotheque-scripts.json"'); echo $j; exit;
    }
    function import(): void {
        $f = $_FILES['file'] ?? null; if (!$f || $f['error'] !== UPLOAD_ERR_OK || $f['size'] > 5 * 1048576) { flash('Choisissez un fichier .html ou .json (5 Mo maximum).', 'danger'); redirect('cs/import'); }
        $dry = $this->in('dry') === '1'; $pub = $this->in('publish') === '1';
        try { $items = Cs::parseLibrary((string)file_get_contents($f['tmp_name'])); } catch (\Throwable $e) { flash($e->getMessage(), 'danger'); redirect('cs/import'); }
        $pdo = DB::pdo(); $pdo->beginTransaction();
        try { [$n, $notes] = Cs::importLibrary($items, $pub); if ($dry) $pdo->rollBack(); else $pdo->commit(); } catch (\Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); flash('Import annulé : ' . $e->getMessage(), 'danger'); redirect('cs/import'); }
        if (!$dry) Audit::log('import', 'cs_scripts', null, null, $n + ['fichier' => mb_substr((string)$f['name'], 0, 100)]);
        $_SESSION['_imp'] = ['n' => $n, 'notes' => $notes, 'dry' => $dry, 'total' => count($items)]; redirect('cs/import');
    }
}
