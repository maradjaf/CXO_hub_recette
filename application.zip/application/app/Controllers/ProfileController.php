<?php
namespace App\Controllers;
use App\Core\{Controller, Auth, DB, Audit};
class ProfileController extends Controller {
    function index(): void {
        $hist = DB::all("SELECT created_at, event_type, ip, city, country, device, os, browser, result FROM user_activity_events WHERE user_id=? AND event_type IN ('login','login_failed','logout') ORDER BY id DESC LIMIT 20", [Auth::id()]);
        $u = Auth::user(); $emp = !empty($u['employee_id']) ? DB::one('SELECT id, matricule, matricule_confirmed FROM employees WHERE id=?', [(int)$u['employee_id']]) : null;
        $this->view('auth/profile', ['title' => 'Mon profil', 'emp' => $emp, 'user' => $u, 'roles' => Auth::roles(), 'hist' => $hist]);
    }
    function password(): void { $this->view('auth/password', ['title' => 'Changer le mot de passe']); }
    function updatePassword(): void {
        $u = Auth::user(); $cur = (string)$this->in('current'); $n = (string)$this->in('new'); $c = (string)$this->in('confirm');
        $err = [];
        if (!password_verify($cur, $u['password_hash'])) $err[] = 'Le mot de passe actuel est incorrect.';
        if (strlen($n) < 10 || !preg_match('/[A-Z]/', $n) || !preg_match('/[a-z]/', $n) || !preg_match('/\d/', $n)) $err[] = 'Le nouveau mot de passe doit comporter au moins 10 caractères, avec majuscule, minuscule et chiffre.';
        if ($n !== $c) $err[] = 'La confirmation ne correspond pas.';
        if ($n === $cur) $err[] = 'Le nouveau mot de passe doit être différent de l\'ancien.';
        if ($err) { foreach ($err as $e) flash($e, 'danger'); redirect('password'); }
        DB::update('users', ['password_hash' => password_hash($n, PASSWORD_DEFAULT), 'must_change_password' => 0, 'updated_at' => now()], 'id=?', [$u['id']]);
        Audit::log('password_change', 'user', $u['id']);
        flash('Mot de passe modifié.');
        if (!empty($u['employee_id']) && DB::val('SELECT 1 FROM employees WHERE id=? AND matricule_confirmed=0', [(int)$u['employee_id']])) { flash('Vérifiez votre matricule ci-dessous : vous pouvez le corriger une fois.', 'info'); redirect('profile'); }
        redirect('/');
    }
    /** Demande de réinitialisation émise par un utilisateur connecté (traitée par l'administrateur). */
    function requestReset(): void {
        $u = Auth::user(); $ok = ResetController::createRequest($u['email'], (int)$u['id'], (string)$this->in('reason', ''));
        Audit::log('reset_request', 'user', $u['id']);
        flash($ok ? 'Demande transmise à l\'administrateur, qui vous enverra un lien de réinitialisation.' : 'Trop de demandes récentes : réessayez plus tard.', $ok ? 'success' : 'danger'); redirect('profile');
    }

    /** Le collaborateur confirme ou corrige son matricule généré automatiquement (une seule fois). */
    function matricule(): void {
        $u = Auth::user(); $emp = !empty($u['employee_id']) ? DB::one('SELECT * FROM employees WHERE id=?', [(int)$u['employee_id']]) : null;
        if (!$emp || (int)$emp['matricule_confirmed'] === 1) { flash('Votre matricule est déjà confirmé ; contactez les RH pour le modifier.', 'warning'); redirect('profile'); }
        $m = trim((string)$this->in('matricule', ''));
        if ($m === '' || mb_strlen($m) > 40 || !preg_match('/^[A-Za-z0-9._\/-]+$/', $m)) { flash('Matricule invalide (lettres, chiffres, . _ - / ; 40 caractères au plus).', 'danger'); redirect('profile'); }
        if (DB::val('SELECT 1 FROM employees WHERE matricule=? AND id<>?', [$m, $emp['id']])) { flash('Ce matricule est déjà attribué à un autre collaborateur.', 'danger'); redirect('profile'); }
        DB::update('employees', ['matricule' => $m, 'matricule_confirmed' => 1, 'updated_at' => now()], 'id=?', [$emp['id']]);
        Audit::log('matricule_self', 'employee', $emp['id'], ['matricule' => $emp['matricule']], ['matricule' => $m]);
        flash('Matricule enregistré.'); redirect('profile');
    }
}
