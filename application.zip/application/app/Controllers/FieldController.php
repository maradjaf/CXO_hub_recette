<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Files, Itil, Notifier, Tickets};

/** Lot 54 : interventions terrain et pièces (M36), demandes d'accès et comptes applicatifs (M37). */
class FieldController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    // ------------------------------------------------------------------ interventions
    private function int(string $id): ?array { $i = DB::one('SELECT * FROM at_interventions WHERE id=?', [(int)$id]); if (!$i) $this->notFound(); return $i; }
    private function mayAct(array $i): bool { return can('int.manage') || (int)$i['technician_id'] === (int)Auth::id(); }
    function intIndex(): void {
        $w = ['1=1']; $p = []; $st = (string)($_GET['status'] ?? 'open'); $mine = ($_GET['who'] ?? (can('int.manage') ? 'all' : 'mine')) === 'mine';
        if ($st === 'open') $w[] = "i.status IN ('planned','on_site')"; elseif (isset(Itil::INT[$st])) { $w[] = 'i.status=?'; $p[] = $st; }
        if ($mine) { $w[] = 'i.technician_id=?'; $p[] = Auth::id(); }
        if (($q = trim((string)($_GET['q'] ?? ''))) !== '') { $w[] = '(i.ref LIKE ? OR s.name LIKE ? OR i.route_label LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $from = 'at_interventions i JOIN stores s ON s.id=i.store_id LEFT JOIN users u ON u.id=i.technician_id LEFT JOIN at_tickets t ON t.id=i.ticket_id WHERE ' . implode(' AND ', $w);
        $this->view('itil/int_index', ['title' => 'Interventions terrain', 'p' => paginate($from, $p, $this->page(), 25, 'i.*, s.name store, u.name tech, t.reference tref', 'i.planned_at'), 'st' => $st, 'mine' => $mine]);
    }
    function intNew(): void {
        $tk = (int)($_GET['ticket'] ?? 0) ? DB::one('SELECT id, reference, title, store_id FROM at_tickets WHERE id=?', [(int)$_GET['ticket']]) : null;
        $this->view('itil/int_form', ['title' => 'Planifier une intervention', 'tk' => $tk, 'stores' => DB::all('SELECT id, name FROM stores ORDER BY name'), 'techs' => Itil::users('at.handle'), 'routes' => array_column(DB::all("SELECT DISTINCT route_label FROM at_interventions WHERE route_label IS NOT NULL AND planned_at>=? ORDER BY route_label", [date('Y-m-d', strtotime('-30 days'))]), 'route_label')]);
    }
    function intStore(): void {
        $sid = (int)$this->in('store_id', 0); $tech = (int)$this->in('technician_id', 0) ?: (int)Auth::id(); $at = (string)$this->in('planned_at'); $tid = (int)$this->in('ticket_id', 0) ?: null; $err = [];
        if (!DB::val('SELECT 1 FROM stores WHERE id=?', [$sid])) $err[] = 'Choisissez le store.'; if (!Itil::okDt($at)) $err[] = 'La date et l\'heure sont obligatoires.'; if (!DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$tech])) $err[] = 'Technicien inconnu.';
        if ($tid && !DB::val('SELECT 1 FROM at_tickets WHERE id=?', [$tid])) $tid = null; if ((int)$tech !== (int)Auth::id() && !can('int.manage')) $err[] = 'Vous ne pouvez planifier que vos propres interventions.';
        $warn = $err ? [] : Itil::busy($tech, Itil::dtv($at)); if ($warn && !$this->in('force')) $err[] = implode(' ', $warn) . ' Cochez « planifier malgré tout » pour confirmer.';
        if ($err) { foreach ($err as $e) flash($e, 'danger'); $_SESSION['_old'] = $_POST; redirect('int/new' . ($tid ? "?ticket=$tid" : '')); }
        $id = DB::insert('at_interventions', ['ref' => Itil::ref('INT', 'at_interventions'), 'ticket_id' => $tid, 'store_id' => $sid, 'technician_id' => $tech, 'route_label' => mb_substr(trim((string)$this->in('route_label')), 0, 100) ?: null, 'vehicle' => mb_substr(trim((string)$this->in('vehicle')), 0, 60) ?: null, 'planned_at' => Itil::dtv($at), 'status' => 'planned', 'notes' => mb_substr(trim((string)$this->in('notes')), 0, 2000) ?: null, 'created_by' => Auth::id(), 'created_at' => now()]);
        $ref = (string)DB::val('SELECT ref FROM at_interventions WHERE id=?', [$id]); if ($tid) Tickets::event($tid, 'intervention', "Intervention $ref planifiée le " . dt(Itil::dtv($at)) . '.', Auth::id());
        if ($tech !== (int)Auth::id()) Notifier::send($tech, 'Intervention planifiée : ' . $ref, dt(Itil::dtv($at)) . ' · ' . (string)DB::val('SELECT name FROM stores WHERE id=?', [$sid]), '/int/' . $id);
        Audit::log('create', 'at_intervention', $id); $this->go("int/$id", 'Intervention planifiée.');
    }
    function intShow(string $id): void {
        if (!($i = $this->int($id))) return;
        $this->view('itil/int_show', ['title' => $i['ref'], 'i' => $i, 'store' => DB::one('SELECT * FROM stores WHERE id=?', [$i['store_id']]), 'tech' => Itil::name((int)$i['technician_id']), 'ticket' => $i['ticket_id'] ? DB::one('SELECT id, reference, title, status FROM at_tickets WHERE id=?', [$i['ticket_id']]) : null,
            'check' => Itil::checklist($i), 'parts' => DB::all('SELECT p.*, s.label, s.sku FROM at_int_parts p JOIN at_stock s ON s.id=p.item_id WHERE p.intervention_id=? ORDER BY p.id', [$i['id']]), 'files' => DB::all('SELECT * FROM at_int_files WHERE intervention_id=? ORDER BY id', [$i['id']]),
            'stock' => DB::all('SELECT id, sku, label, qty FROM at_stock WHERE active=1 AND qty>0 ORDER BY label LIMIT 500'), 'may' => $this->mayAct($i), 'hint' => Files::hint()]);
    }
    function intUpdate(string $id): void {
        if (!($i = $this->int($id))) return; $act = (string)$this->in('act'); $to = "int/{$i['id']}";
        if (!$this->mayAct($i)) { $this->forbidden(); return; }
        $open = in_array($i['status'], ['planned', 'on_site'], true);
        if ($act === 'reschedule') { $at = (string)$this->in('planned_at'); if (!$open || !Itil::okDt($at)) $this->go($to, 'Date invalide.', 'danger'); $w = Itil::busy((int)$i['technician_id'], Itil::dtv($at), (int)$i['id']); if ($w && !$this->in('force')) $this->go($to, implode(' ', $w) . ' Confirmez pour replanifier malgré tout.', 'warning'); DB::update('at_interventions', ['planned_at' => Itil::dtv($at)], 'id=?', [$i['id']]); $this->go($to, 'Intervention replanifiée.'); }
        if ($act === 'reassign') { $t = (int)$this->in('technician_id', 0); if (!can('int.manage') || !$open || !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$t])) $this->go($to, 'Action impossible.', 'danger'); DB::update('at_interventions', ['technician_id' => $t], 'id=?', [$i['id']]); Notifier::send($t, 'Intervention confiée : ' . $i['ref'], dt($i['planned_at']), '/int/' . $i['id']); $this->go($to, 'Technicien changé.'); }
        if ($act === 'cancel') { if (!$open) $this->go($to, 'Action impossible.', 'danger'); DB::update('at_interventions', ['status' => 'cancelled'], 'id=?', [$i['id']]); foreach (DB::all('SELECT * FROM at_int_parts WHERE intervention_id=?', [$i['id']]) as $p) Itil::returnStock((int)$p['item_id'], (int)$p['qty'], (int)$i['ticket_id'], 'Annulation ' . $i['ref']); DB::exec('DELETE FROM at_int_parts WHERE intervention_id=?', [$i['id']]); $this->go($to, 'Intervention annulée ; pièces remises en stock.'); }
        if ($i['status'] === 'done' || $i['status'] === 'cancelled') $this->go($to, 'Intervention clôturée : plus de modification.', 'warning');
        if ($act === 'arrive') { if ($i['status'] !== 'planned') $this->go($to, 'Action impossible.', 'danger'); DB::update('at_interventions', ['status' => 'on_site', 'arrived_at' => now()], 'id=?', [$i['id']]); if ($i['ticket_id']) Tickets::event((int)$i['ticket_id'], 'intervention', 'Technicien arrivé sur site (' . $i['ref'] . ').', Auth::id()); $this->go($to, 'Arrivée enregistrée à ' . date('H:i') . ' (heure du serveur).'); }
        if ($i['status'] !== 'on_site') $this->go($to, 'Enregistrez d\'abord l\'arrivée sur site.', 'warning');
        if ($act === 'check') { $n = count(Itil::checklist()); $o = []; for ($k = 0; $k < $n; $k++) $o[$k] = !empty($_POST['c'][$k]) ? 1 : 0; DB::update('at_interventions', ['checklist' => json_encode($o), 'notes' => mb_substr(trim((string)$this->in('notes')), 0, 3000) ?: null], 'id=?', [$i['id']]); $this->go($to, 'Check-list enregistrée.'); }
        if ($act === 'part') {
            $it = (int)$this->in('item_id', 0); $q = (int)$this->in('qty', 0); if (!DB::val('SELECT 1 FROM at_stock WHERE id=?', [$it]) || $q < 1) $this->go($to, 'Choisissez une pièce et une quantité.', 'danger');
            if (!Itil::useStock($it, $q, (int)$i['ticket_id'], 'Intervention ' . $i['ref'])) $this->go($to, 'Stock insuffisant.', 'danger');
            DB::insert('at_int_parts', ['intervention_id' => $i['id'], 'item_id' => $it, 'qty' => $q, 'created_at' => now()]); $this->go($to, 'Pièce ajoutée et déduite du stock.');
        }
        if ($act === 'unpart') { $p = DB::one('SELECT * FROM at_int_parts WHERE id=? AND intervention_id=?', [(int)$this->in('part_id', 0), $i['id']]); if ($p) { Itil::returnStock((int)$p['item_id'], (int)$p['qty'], (int)$i['ticket_id'], 'Retour ' . $i['ref']); DB::exec('DELETE FROM at_int_parts WHERE id=?', [$p['id']]); } $this->go($to, 'Pièce retirée et remise en stock.'); }
        if ($act === 'photo') {
            $ph = (string)$this->in('phase') === 'after' ? 'after' : 'before'; [$files, $err] = Files::uploads('photos', (int)DB::val('SELECT COUNT(*) FROM at_int_files WHERE intervention_id=?', [$i['id']])); $n = 0;
            foreach ($files as $f) { if (!str_starts_with($f['mime'], 'image/')) { $err[] = '« ' . $f['name'] . ' » n\'est pas une image.'; continue; } $st = Files::put('int', $f['bytes'], $f['ext']); if (!$st) continue; DB::insert('at_int_files', ['intervention_id' => $i['id'], 'phase' => $ph, 'original_name' => $f['name'], 'stored_name' => $st, 'mime' => $f['mime'], 'size' => strlen($f['bytes']), 'user_id' => Auth::id(), 'created_at' => now()]); $n++; }
            foreach ($err as $e) flash($e, 'warning'); $this->go($to, $n ? "$n photo(s) ajoutée(s)." : 'Aucune photo ajoutée.', $n ? 'success' : 'warning');
        }
        if ($act === 'finish') {
            $o = (string)$this->in('outcome'); $by = mb_substr(trim((string)$this->in('signed_by')), 0, 150); $sig = (string)$this->in('pad');
            if (!isset(Itil::INT_OUT[$o])) $this->go($to, 'Choisissez le résultat.', 'danger'); if ($by === '') $this->go($to, 'Indiquez le nom du chef de store qui signe.', 'danger');
            if (!preg_match('#^data:image/png;base64,[A-Za-z0-9+/=]{60,}$#', $sig) || strlen($sig) > 400000) $this->go($to, 'La signature du chef de store est obligatoire.', 'danger');
            DB::update('at_interventions', ['status' => 'done', 'left_at' => now(), 'outcome' => $o, 'signed_by' => $by, 'signature' => $sig, 'notes' => mb_substr(trim((string)$this->in('notes')) ?: (string)$i['notes'], 0, 3000) ?: null], 'id=?', [$i['id']]);
            if ($i['ticket_id']) { $parts = DB::all('SELECT p.qty, s.label FROM at_int_parts p JOIN at_stock s ON s.id=p.item_id WHERE p.intervention_id=?', [$i['id']]); Tickets::event((int)$i['ticket_id'], 'intervention', 'Intervention ' . $i['ref'] . ' terminée : ' . Itil::INT_OUT[$o] . '. Signé par ' . $by . ($parts ? '. Pièces : ' . implode(', ', array_map(fn($x) => $x['qty'] . ' × ' . $x['label'], $parts)) : '') . '.', Auth::id()); }
            Audit::log('finish', 'at_intervention', $i['id']); $this->go($to, 'Intervention terminée et tracée dans le ticket.');
        }
        $this->go($to, 'Action inconnue.', 'danger');
    }
    function intPrint(string $id): void {
        if (!($i = $this->int($id))) return;
        echo \App\Core\View::partial('itil/int_print', ['title' => 'Rapport ' . $i['ref'], 'i' => $i, 'store' => (string)DB::val('SELECT name FROM stores WHERE id=?', [$i['store_id']]), 'tech' => Itil::name((int)$i['technician_id']), 'ticket' => $i['ticket_id'] ? DB::one('SELECT reference, title FROM at_tickets WHERE id=?', [$i['ticket_id']]) : null, 'check' => Itil::checklist($i),
            'parts' => DB::all('SELECT p.qty, s.label, s.sku FROM at_int_parts p JOIN at_stock s ON s.id=p.item_id WHERE p.intervention_id=?', [$i['id']])]);
    }
    function intPhoto(string $id): void {
        $f = DB::one('SELECT * FROM at_int_files WHERE id=?', [(int)$id]); if (!$f) { $this->notFound(); return; }
        $path = Files::dir('int') . '/' . basename($f['stored_name']); if (!is_file($path)) { $this->notFound(); return; }
        header('Content-Type: ' . (str_starts_with((string)$f['mime'], 'image/') && $f['mime'] !== 'image/svg+xml' ? $f['mime'] : 'application/octet-stream')); header('X-Content-Type-Options: nosniff'); header("Content-Security-Policy: sandbox; default-src 'none'"); header('Content-Length: ' . filesize($path)); readfile($path); exit;
    }
    // ------------------------------------------------------------------ accès et comptes
    private function acc(string $id): ?array {
        $r = DB::one('SELECT * FROM at_access_requests WHERE id=?', [(int)$id]); if (!$r || !$this->seeAcc($r)) { $this->notFound(); return null; } return $r;
    }
    private function seeAcc(array $r): bool { return can('acc.validate') || can('acc.execute') || (int)$r['requester_id'] === (int)Auth::id(); }
    function accIndex(): void {
        $w = ['1=1']; $p = []; $st = (string)($_GET['status'] ?? 'open'); $all = can('acc.validate') || can('acc.execute');
        if (!$all || ($_GET['who'] ?? '') === 'mine') { $w[] = 'r.requester_id=?'; $p[] = Auth::id(); }
        if ($st === 'open') $w[] = "r.status IN ('submitted','validated')"; elseif (isset(Itil::ACC[$st])) { $w[] = 'r.status=?'; $p[] = $st; }
        if (($q = trim((string)($_GET['q'] ?? ''))) !== '') { $w[] = '(r.ref LIKE ? OR r.app_name LIKE ? OR e.last_name LIKE ? OR e.first_name LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%", "%$q%"); }
        $from = 'at_access_requests r JOIN employees e ON e.id=r.employee_id LEFT JOIN users u ON u.id=r.requester_id WHERE ' . implode(' AND ', $w);
        $this->view('itil/acc_index', ['title' => 'Demandes d\'accès', 'p' => paginate($from, $p, $this->page(), 25, "r.*, e.first_name, e.last_name, u.name requester", 'r.id DESC'), 'st' => $st, 'all' => $all]);
    }
    function accNew(): void {
        $me = (int)DB::val('SELECT employee_id FROM users WHERE id=?', [Auth::id()]);
        $this->view('itil/acc_form', ['title' => 'Nouvelle demande d\'accès', 'emps' => DB::all("SELECT id, first_name, last_name, matricule FROM employees WHERE status<>'left' ORDER BY last_name, first_name LIMIT 3000"), 'me' => (int)($_GET['employee_id'] ?? $me), 'apps' => Itil::apps(), 'pre' => ['app' => (string)($_GET['app'] ?? ''), 'act' => (string)($_GET['act'] ?? 'create')]]);
    }
    function accStore(): void {
        $e = (int)$this->in('employee_id', 0); $app = mb_substr(trim((string)$this->in('app_name')), 0, 100); $act = (string)$this->in('act'); $err = [];
        if (!DB::val('SELECT 1 FROM employees WHERE id=?', [$e])) $err[] = 'Choisissez le collaborateur concerné.'; if ($app === '') $err[] = 'L\'application est obligatoire.'; if (!isset(Itil::ACC_ACT[$act])) $err[] = 'Choisissez le type de demande.';
        $just = mb_substr(trim((string)$this->in('justification')), 0, 500); if ($just === '') $err[] = 'La justification est obligatoire.';
        if (!$err && $act === 'create' && DB::val("SELECT 1 FROM at_app_accounts WHERE employee_id=? AND app_name=? AND status='active'", [$e, $app])) $err[] = 'Ce collaborateur a déjà un compte actif sur cette application.';
        if (!$err && in_array($act, ['modify', 'suspend', 'close'], true) && !DB::val("SELECT 1 FROM at_app_accounts WHERE employee_id=? AND app_name=? AND status<>'closed'", [$e, $app])) $err[] = 'Aucun compte à modifier, suspendre ou fermer pour cette application.';
        if (!$err && DB::val("SELECT 1 FROM at_access_requests WHERE employee_id=? AND app_name=? AND act=? AND status IN ('submitted','validated')", [$e, $app, $act])) $err[] = 'Une demande identique est déjà en cours.';
        if ($err) { foreach ($err as $x) flash($x, 'danger'); $_SESSION['_old'] = $_POST; redirect('acc/new'); }
        $id = DB::insert('at_access_requests', ['ref' => Itil::ref('ACC', 'at_access_requests'), 'employee_id' => $e, 'requester_id' => Auth::id(), 'app_name' => $app, 'act' => $act, 'profile_name' => mb_substr(trim((string)$this->in('profile_name')), 0, 150) ?: null, 'justification' => $just, 'status' => 'submitted', 'created_at' => now()]);
        Notifier::toPermission('acc.validate', 'Demande d\'accès à valider', Itil::ACC_ACT[$act] . ' · ' . $app, '/acc/' . $id); Audit::log('create', 'at_access_request', $id); $this->go("acc/$id", 'Demande envoyée pour validation.');
    }
    function accShow(string $id): void {
        if (!($r = $this->acc($id))) return;
        $this->view('itil/acc_show', ['title' => $r['ref'], 'r' => $r, 'emp' => DB::one('SELECT e.*, s.name store FROM employees e LEFT JOIN stores s ON s.id=e.store_id WHERE e.id=?', [$r['employee_id']]), 'requester' => Itil::name($r['requester_id'] ? (int)$r['requester_id'] : null), 'validator' => Itil::name($r['validator_id'] ? (int)$r['validator_id'] : null),
            'executor' => Itil::name($r['executor_id'] ? (int)$r['executor_id'] : null), 'accounts' => DB::all('SELECT * FROM at_app_accounts WHERE employee_id=? ORDER BY app_name', [$r['employee_id']])]);
    }
    function accUpdate(string $id): void {
        if (!($r = $this->acc($id))) return; $act = (string)$this->in('act'); $to = "acc/{$r['id']}"; $note = mb_substr(trim((string)$this->in('note')), 0, 300);
        if ($act === 'cancel') { if ($r['status'] !== 'submitted' || (int)$r['requester_id'] !== (int)Auth::id()) $this->go($to, 'Action impossible.', 'danger'); DB::update('at_access_requests', ['status' => 'cancelled'], 'id=?', [$r['id']]); $this->go($to, 'Demande annulée.'); }
        if ($act === 'decide') {
            if ($r['status'] !== 'submitted' || !can('acc.validate')) $this->go($to, 'Action impossible.', 'danger'); $ok = (bool)$this->in('ok'); if (!$ok && $note === '') $this->go($to, 'Motivez le refus.', 'danger');
            if ((int)$r['requester_id'] === (int)Auth::id() && !can('settings.manage')) $this->go($to, 'Vous ne pouvez pas valider votre propre demande.', 'danger');
            DB::update('at_access_requests', ['status' => $ok ? 'validated' : 'rejected', 'validator_id' => Auth::id(), 'decided_at' => now(), 'decision_note' => $note ?: null], 'id=?', [$r['id']]);
            if ($ok) Notifier::toPermission('acc.execute', 'Accès à exécuter : ' . $r['ref'], Itil::ACC_ACT[$r['act']] . ' · ' . $r['app_name'], '/acc/' . $r['id']); elseif ($r['requester_id']) Notifier::send((int)$r['requester_id'], 'Demande d\'accès refusée : ' . $r['ref'], $note, '/acc/' . $r['id']);
            Audit::log($ok ? 'validate' : 'reject', 'at_access_request', $r['id']); $this->go($to, $ok ? 'Demande validée ; transmise aux techniciens.' : 'Demande refusée.');
        }
        if ($act === 'execute') {
            if ($r['status'] !== 'validated' || !can('acc.execute')) $this->go($to, 'Action impossible.', 'danger'); $login = mb_substr(trim((string)$this->in('account_login')), 0, 100);
            if ($r['act'] === 'create' && $login === '') $this->go($to, 'Indiquez l\'identifiant du compte créé.', 'danger');
            DB::update('at_access_requests', ['status' => 'done', 'executor_id' => Auth::id(), 'done_at' => now(), 'account_login' => $login ?: null], 'id=?', [$r['id']]); Itil::applyAccount($r, $login);
            if ($r['requester_id']) Notifier::send((int)$r['requester_id'], 'Accès réalisé : ' . $r['ref'], Itil::ACC_ACT[$r['act']] . ' · ' . $r['app_name'], '/acc/' . $r['id']); Audit::log('execute', 'at_access_request', $r['id']); $this->go($to, 'Accès réalisé et inscrit au registre des comptes.');
        }
        $this->go($to, 'Action inconnue.', 'danger');
    }
    function accAccounts(): void {
        if (!can('acc.validate') && !can('acc.execute')) { $this->forbidden(); return; }
        $w = ['1=1']; $p = []; $st = (string)($_GET['status'] ?? 'active');
        if (isset(Itil::ACCT[$st])) { $w[] = 'a.status=?'; $p[] = $st; }
        if (($_GET['leaving'] ?? '') === '1') $w[] = "a.status<>'closed' AND (e.status='left' OR EXISTS (SELECT 1 FROM offboarding_cases o WHERE o.employee_id=e.id AND o.status='open'))";
        if (($a = trim((string)($_GET['app'] ?? ''))) !== '') { $w[] = 'a.app_name=?'; $p[] = $a; }
        if (($q = trim((string)($_GET['q'] ?? ''))) !== '') { $w[] = '(e.last_name LIKE ? OR e.first_name LIKE ? OR a.account_login LIKE ? OR e.matricule LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%", "%$q%"); }
        $from = 'at_app_accounts a JOIN employees e ON e.id=a.employee_id WHERE ' . implode(' AND ', $w);
        if (($_GET['export'] ?? '') === 'csv') { $rows = DB::all("SELECT a.*, e.first_name, e.last_name, e.matricule FROM $from ORDER BY a.app_name, e.last_name", $p); csv_download('comptes_applicatifs_' . date('Ymd_His') . '.csv', ['Application', 'Matricule', 'Nom', 'Prénom', 'Identifiant', 'Profil', 'Statut', 'Ouvert le', 'Fermé le'], array_map(fn($r) => [$r['app_name'], $r['matricule'], $r['last_name'], $r['first_name'], $r['account_login'], $r['profile_name'], Itil::ACCT[$r['status']] ?? '', $r['opened_at'], $r['closed_at']], $rows)); }
        $this->view('itil/accounts', ['title' => 'Comptes applicatifs', 'p' => paginate($from, $p, $this->page(), 30, 'a.*, e.first_name, e.last_name, e.matricule, e.status estatus', 'a.app_name, e.last_name'), 'st' => $st, 'apps' => Itil::apps()]);
    }
}
