<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Readiness, Scope};

/** Lot 55 : Operational Readiness (M28), tableau par périmètre, fiche collaborateur, règles par canal et poste. */
class ReadinessController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }

    function index(): void {
        [$sw, $sp] = Scope::sql('e.id');
        // les collaborateurs du périmètre jamais calculés sont évalués à l'ouverture (200 au plus à la fois)
        $new = DB::all("SELECT e.id FROM employees e LEFT JOIN rd_status s ON s.employee_id=e.id WHERE e.status<>'left' AND s.id IS NULL AND $sw LIMIT 200", $sp);
        if ($new) { Readiness::resetCache(); foreach ($new as $n) Readiness::compute((int)$n['id']); }
        $w = ["e.status<>'left'", $sw]; $p = $sp;
        foreach (['store_id', 'channel_id', 'team_id'] as $f) if ($this->in($f)) { $w[] = "e.$f=?"; $p[] = (int)$this->in($f); }
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(e.first_name LIKE ? OR e.last_name LIKE ? OR e.matricule LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $base = 'employees e LEFT JOIN rd_status s ON s.employee_id=e.id LEFT JOIN teams tm ON tm.id=e.team_id LEFT JOIN stores st ON st.id=e.store_id LEFT JOIN channels ch ON ch.id=e.channel_id LEFT JOIN positions po ON po.id=e.position_id WHERE ' . implode(' AND ', $w);
        $cnt = ['ready' => 0, 'partial' => 0, 'not_ready' => 0, 'none' => 0];
        foreach (DB::all("SELECT COALESCE(s.status,'none') st, COUNT(*) c FROM $base GROUP BY COALESCE(s.status,'none')", $p) as $r) $cnt[$r['st']] = (int)$r['c'];
        $tot = array_sum($cnt);
        $st = (string)$this->in('status', ''); $w2 = ''; $p2 = $p;
        if (isset(Readiness::ST[$st])) { $w2 = ' AND s.status=?'; $p2[] = $st; }
        // composantes les plus souvent manquantes dans la sélection
        $miss = array_fill_keys(array_keys(Readiness::COMP), ['blocking' => 0, 'other' => 0]);
        foreach (DB::all("SELECT s.detail FROM $base$w2 AND s.id IS NOT NULL LIMIT 2000", $p2) as $r) foreach (json_decode((string)$r['detail'], true) ?: [] as $c => $d) if (!empty($d['required']) && empty($d['ok']) && isset($miss[$c])) $miss[$c][$d['blocking'] ? 'blocking' : 'other']++;
        if ($this->in('export') === 'csv') {
            $rows = DB::all("SELECT e.matricule, e.last_name, e.first_name, tm.name team, st.name store, ch.name channel, po.name position, s.status, s.blocking_missing, s.other_missing, s.computed_at, s.detail FROM $base$w2 ORDER BY e.last_name, e.first_name LIMIT 5000", $p2);
            Audit::log('export', 'readiness', null, null, ['rows' => count($rows)]);
            csv_download('operational_readiness_' . date('Ymd_His') . '.csv', ['Matricule', 'Nom', 'Prénom', 'Équipe', 'Store', 'Canal', 'Poste', 'Statut', 'Blocages', 'Manques non bloquants', 'Composantes manquantes', 'Calculé le'],
                array_map(function ($r) { $m = []; foreach (json_decode((string)$r['detail'], true) ?: [] as $c => $d) if (!empty($d['required']) && empty($d['ok'])) $m[] = Readiness::COMP[$c] . ($d['blocking'] ? ' (bloquant)' : ''); return [$r['matricule'], $r['last_name'], $r['first_name'], $r['team'], $r['store'], $r['channel'], $r['position'], Readiness::ST[$r['status']] ?? 'Non calculé', $r['blocking_missing'], $r['other_missing'], implode(' ; ', $m), $r['computed_at']]; }, $rows));
        }
        $pg = paginate($base . $w2, $p2, $this->page(), 25, 'e.id, e.matricule, e.first_name, e.last_name, tm.name team_name, st.name store_name, ch.name channel_name, po.name position_name, s.status rd_status, s.blocking_missing, s.other_missing, s.detail, s.computed_at',
            "CASE s.status WHEN 'not_ready' THEN 0 WHEN 'partial' THEN 1 WHEN 'ready' THEN 2 ELSE 3 END, e.last_name, e.first_name");
        $this->view('readiness/index', ['title' => 'Operational Readiness', 'p' => $pg, 'cnt' => $cnt, 'tot' => $tot, 'miss' => $miss, 'st' => $st,
            'stores' => DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name'), 'channels' => DB::all('SELECT id, name FROM channels WHERE active=1 ORDER BY name'), 'teams' => DB::all('SELECT id, name FROM teams ORDER BY name')]);
    }

    function show(string $id): void {
        $e = DB::one('SELECT e.*, tm.name team_name, st.name store_name, ch.name channel_name, po.name position_name FROM employees e LEFT JOIN teams tm ON tm.id=e.team_id LEFT JOIN stores st ON st.id=e.store_id LEFT JOIN channels ch ON ch.id=e.channel_id LEFT JOIN positions po ON po.id=e.position_id WHERE e.id=?', [(int)$id]);
        if (!$e || !Scope::allows((int)$e['id'])) { $this->notFound(); return; }
        Readiness::resetCache(); $res = Readiness::compute((int)$e['id']);
        $this->view('readiness/show', ['title' => 'Readiness : ' . $e['last_name'] . ' ' . $e['first_name'], 'e' => $e, 'res' => $res,
            'hist' => DB::all('SELECT * FROM rd_history WHERE employee_id=? ORDER BY computed_at DESC, id DESC LIMIT 30', [(int)$e['id']])]);
    }

    function recalc(): void {
        $r = Readiness::recomputeAll(); Audit::log('update', 'readiness', null, null, $r);
        $this->go('readiness', 'Recalcul terminé : ' . $r['total'] . ' collaborateur(s), dont ' . $r['ready'] . ' Ready, ' . $r['partial'] . ' Partially Ready et ' . $r['not_ready'] . ' Not Ready (' . $r['changed'] . ' changement(s) de statut).');
    }

    function rules(): void {
        $rows = DB::all('SELECT r.*, c.name channel_name, p.name position_name FROM rd_rules r LEFT JOIN channels c ON c.id=r.channel_id LEFT JOIN positions p ON p.id=r.position_id ORDER BY r.component, (r.channel_id IS NULL), (r.position_id IS NULL), r.id');
        $this->view('readiness/rules', ['title' => 'Règles de préparation opérationnelle', 'rows' => $rows, 'channels' => DB::all('SELECT id, name FROM channels WHERE active=1 ORDER BY name'), 'positions' => DB::all('SELECT id, name FROM positions WHERE active=1 ORDER BY name')]);
    }
    function ruleSave(): void {
        $comp = (string)$this->in('component'); if (!isset(Readiness::COMP[$comp])) $this->go('readiness/rules', 'Composante inconnue.', 'danger');
        $ch = (int)$this->in('channel_id') ?: null; $po = (int)$this->in('position_id') ?: null;
        $thr = trim((string)$this->in('threshold', '')); if ($thr !== '' && (!is_numeric($thr) || $thr < 0 || $thr > 100)) $this->go('readiness/rules', 'Le seuil doit être compris entre 0 et 100.', 'danger');
        if ($comp === 'score' && $this->in('enabled') && $thr === '') $this->go('readiness/rules', 'Indiquez le seuil de score minimum.', 'danger');
        $apps = implode(', ', array_values(array_unique(array_filter(array_map('trim', explode(',', (string)$this->in('apps', ''))), 'strlen'))));
        $d = ['channel_id' => $ch, 'position_id' => $po, 'component' => $comp, 'enabled' => $this->in('enabled') ? 1 : 0, 'blocking' => $this->in('blocking') ? 1 : 0, 'threshold' => $thr === '' ? null : (float)$thr, 'apps' => mb_substr($apps, 0, 300), 'note' => mb_substr(trim((string)$this->in('note', '')), 0, 200)];
        $dup = DB::one('SELECT id FROM rd_rules WHERE component=? AND channel_id ' . ($ch ? '=?' : 'IS NULL') . ' AND position_id ' . ($po ? '=?' : 'IS NULL'), array_merge([$comp], $ch ? [$ch] : [], $po ? [$po] : []));
        if ($dup) { DB::update('rd_rules', $d, 'id=?', [(int)$dup['id']]); Audit::log('update', 'rd_rule', (int)$dup['id'], null, $d); $msg = 'Règle mise à jour.'; }
        else { $id = DB::insert('rd_rules', $d); Audit::log('create', 'rd_rule', $id, null, $d); $msg = 'Règle ajoutée.'; }
        Readiness::resetCache(); $this->go('readiness/rules', $msg . ' Lancez un recalcul pour appliquer la règle à tous les collaborateurs.');
    }
    function ruleDelete(string $id): void {
        $r = DB::one('SELECT * FROM rd_rules WHERE id=?', [(int)$id]); if (!$r) { $this->notFound(); return; }
        DB::exec('DELETE FROM rd_rules WHERE id=?', [(int)$id]); Audit::log('delete', 'rd_rule', (int)$id, $r, null); Readiness::resetCache();
        $this->go('readiness/rules', 'Règle supprimée.');
    }
}
