<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Ref, Tq, Notifier};
/** Demandes de formation : saisie, validation N+1, traitement par l'équipe formation, réalisation et rapport, tableau de bord. */
class TqController extends Controller {
    const FILES = ['pdf' => 'application/pdf', 'docx' => '', 'doc' => '', 'pptx' => '', 'ppt' => '', 'xlsx' => '', 'xls' => '', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png'];
    private static function dir(): string { $d = ROOT . '/storage/uploads/tq'; if (!is_dir($d)) @mkdir($d, 0775, true); return $d; }
    private function load(string $id): ?array { $r = DB::one('SELECT * FROM tq_requests WHERE id=?', [(int)$id]); return $r && Tq::canSee($r) ? $r : null; }
    private function lists(): array { return ['directions' => Ref::items('tq_directions'), 'services' => Ref::items('tq_services'), 'populations' => Ref::items('tq_populations'), 'objectives' => Ref::items('tq_objectives'), 'competences' => Ref::items('tq_competences'), 'impacts' => Ref::items('tq_impacts'), 'risks' => Ref::items('tq_risks'), 'supports' => Ref::items('tq_supports')]; }
    private function trainers(): array { return DB::all("SELECT id, name FROM users WHERE status='active' AND id IN (" . (implode(',', Tq::permUsers('tq.deliver')) ?: '0') . ') ORDER BY name'); }

    // =============== Demandeur ===============
    function index(): void {
        $w = ['requester_id=?']; $p = [Auth::id()]; if ($s = (string)$this->in('status', '')) { $w[] = 'status=?'; $p[] = $s; }
        $this->view('tq/index', ['title' => 'Mes demandes de formation', 'tab' => 'mine', 'status' => $s, 'p' => $pg = paginate('tq_requests WHERE ' . implode(' AND ', $w), $p, $this->page(), 25, '*', 'id DESC'), 'rows' => $pg['rows']]);
    }
    private function formVars(?array $r): array {
        $me = Tq::me(); $mgr = Tq::managerEmployee($me); return $this->lists() + ['title' => $r ? 'Modifier ' . $r['ref'] : 'Nouvelle demande de formation', 'tab' => 'new', 'r' => $r, 'n1' => $mgr ? DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [$mgr]) : null, 'files' => $r ? DB::all("SELECT * FROM tq_files WHERE request_id=? AND kind='attachment' ORDER BY id", [(int)$r['id']]) : []];
    }
    function create(): void { $this->view('tq/form', $this->formVars(null)); }
    function edit(string $id): void {
        $r = $this->load($id); if (!$r || (int)$r['requester_id'] !== (int)Auth::id() || !in_array($r['status'], ['draft', 'rejected_n1'], true)) { $this->forbidden(); return; }
        $this->view('tq/form', $this->formVars($r));
    }
    private function pick(string $f, array $allowed): string { return implode(',', array_values(array_intersect(array_map('strval', (array)($_POST[$f] ?? [])), array_keys($allowed)))); }
    /** Lit le formulaire ; en mode « envoi » tous les champs obligatoires sont exigés. */
    private function read(bool $submit): array {
        $L = $this->lists(); $err = []; $t = fn($k, $m = 300) => mb_substr(trim((string)$this->in($k, '')), 0, $m);
        $d = ['title' => $t('title', 200), 'description' => $t('description', 4000) ?: null, 'phone' => $t('phone', 40) ?: null, 'requester_comment' => $t('requester_comment', 3000) ?: null,
              'objective_other' => $t('objective_other') ?: null, 'competences_other' => $t('competences_other') ?: null, 'impacts_other' => $t('impacts_other') ?: null, 'risks_other' => $t('risks_other') ?: null,
              'populations' => $this->pick('populations', $L['populations']), 'competences' => $this->pick('competences', $L['competences']), 'impacts' => $this->pick('impacts', $L['impacts']), 'risks' => $this->pick('risks', $L['risks']), 'supports' => $this->pick('supports', $L['supports'])];
        foreach ([['direction', 'directions'], ['service', 'services'], ['objective', 'objectives']] as [$f, $l]) { $v = (string)$this->in($f, ''); if ($v !== '' && !isset($L[$l][$v])) $err[$f] = 'Valeur inconnue : ' . $f . '.'; $d[$f] = $v ?: null; }
        foreach ([['priority_level', Tq::PRIORITY], ['customer_impact', Tq::IMPACT], ['regulatory', Tq::REG]] as [$f, $set]) { $v = (string)$this->in($f, ''); if ($v !== '' && !isset($set[$v])) $err[$f] = 'Valeur inconnue : ' . $f . '.'; $d[$f] = $v ?: null; }
        foreach (['start_wish', 'end_wish', 'competence_date'] as $f) { $v = trim((string)$this->in($f, '')); if ($v !== '' && (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $v) || !strtotime($v))) $err[$f] = 'Date invalide (' . $f . ').'; $d[$f] = $v ?: null; }
        $h = trim((string)$this->in('headcount', '')); if ($h !== '' && (!ctype_digit($h) || (int)$h > 100000)) $err['headcount'] = 'Nombre de collaborateurs : entier positif.'; $d['headcount'] = $h !== '' ? (int)$h : 0;
        if ($d['phone'] && !preg_match('/^[0-9+ ().-]{6,25}$/', $d['phone'])) $err['phone'] = 'Téléphone invalide.';
        if ($d['title'] === '') $err['title'] = 'L\'intitulé est obligatoire.';
        if ($d['start_wish'] && $d['end_wish'] && $d['end_wish'] < $d['start_wish']) $err['end_wish'] = 'La fin ne peut pas précéder le début.';
        if ($d['end_wish'] && $d['competence_date'] && $d['competence_date'] < $d['end_wish']) $err['competence_date'] = 'La mise en compétence ne peut pas précéder la fin de la formation.';
        if ($submit) {
            foreach (['direction' => 'La direction', 'service' => 'Le service', 'description' => 'La description', 'priority_level' => 'Le niveau de priorité', 'start_wish' => 'La date de début', 'end_wish' => 'La date de fin', 'competence_date' => 'La date de mise en compétence', 'objective' => 'L\'objectif', 'customer_impact' => 'L\'impact client', 'regulatory' => 'L\'exigence réglementaire'] as $f => $lab) if (empty($d[$f])) $err[$f] = "$lab est obligatoire.";
            if (!$d['populations']) $err['populations'] = 'Choisissez au moins une population.'; if ($d['headcount'] < 1) $err['headcount'] = 'Indiquez le nombre de collaborateurs à former.';
            if (!$d['competences']) $err['competences'] = 'Choisissez au moins une compétence.'; if (!$d['impacts']) $err['impacts'] = 'Choisissez au moins un impact attendu.'; if (!$d['risks']) $err['risks'] = 'Choisissez au moins un risque.'; if (!$d['supports']) $err['supports'] = 'Indiquez les supports disponibles (ou « Supports non disponibles »).';
            if ($d['objective'] === 'autres' && !$d['objective_other']) $err['objective_other'] = 'Précisez l\'objectif.';
        }
        return [$d, $err];
    }
    function store(): void { $this->save(null); }
    function update(string $id): void { $this->save($id); }
    private function save(?string $id): void {
        $old = null; if ($id) { $old = $this->load($id); if (!$old || (int)$old['requester_id'] !== (int)Auth::id() || !in_array($old['status'], ['draft', 'rejected_n1'], true)) { $this->forbidden(); return; } }
        $submit = $this->in('send') === '1'; [$d, $err] = $this->read($submit);
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); $_SESSION['_old'] = $_POST; redirect($id ? "tq/$id/edit" : 'tq/new'); }
        $me = Tq::me(); $d['updated_at'] = now();
        if ($old) { DB::update('tq_requests', $d, 'id=?', [(int)$old['id']]); $rid = (int)$old['id']; }
        else { $rid = DB::insert('tq_requests', $d + ['ref' => Tq::nextRef(), 'requester_id' => Auth::id(), 'employee_id' => $me ?: null, 'status' => 'draft', 'created_at' => now()]); }
        $fe = $this->takeFiles($rid, 'files', 'attachment'); if ($fe) flash(implode(' ', $fe), 'warning');
        if ($this->in('rm_file')) foreach ((array)$this->in('rm_file') as $fid) { $f = DB::one("SELECT * FROM tq_files WHERE id=? AND request_id=? AND kind='attachment'", [(int)$fid, $rid]); if ($f) { @unlink(self::dir() . '/' . $f['stored_name']); DB::exec('DELETE FROM tq_files WHERE id=?', [(int)$f['id']]); } }
        if (!$submit) { Audit::log($old ? 'update' : 'create', 'tq_request', $rid); flash('Brouillon enregistré.'); redirect("tq/$rid"); }
        $this->submitRequest($rid);
    }
    private function submitRequest(int $rid): void {
        $r = DB::one('SELECT * FROM tq_requests WHERE id=?', [$rid]); $sc = Tq::score($r, date('Y-m-d')); $mgr = Tq::managerEmployee((int)$r['employee_id']);
        DB::update('tq_requests', $sc + ['manager_employee_id' => $mgr ?: null, 'status' => 'pending_n1', 'submitted_at' => now(), 'sla_due' => Tq::slaDue($sc['pclass']), 'sla_alerted_at' => null, 'manager_decision' => null, 'manager_comment' => null, 'manager_at' => null, 'updated_at' => now()], 'id=?', [$rid]);
        $r = DB::one('SELECT * FROM tq_requests WHERE id=?', [$rid]); Tq::log($rid, 'submit', 'Score ' . $r['score'] . '/100, ' . $r['pclass']); Audit::log('submit', 'tq_request', $rid, null, ['score' => $r['score'], 'class' => $r['pclass']]);
        Tq::notify([(int)$r['requester_id']], 'Accusé de réception : ' . $r['ref'], 'Votre demande est enregistrée (' . Tq::CLS[$r['pclass']][0] . ', ' . $r['score'] . '/100). Prise en charge avant le ' . date('d/m/Y H:i', strtotime($r['sla_due'])) . '.', '/tq/' . $rid, true);
        $n1 = $mgr ? Tq::userOf($mgr) : 0;
        if ($n1) Tq::notify([$n1], 'Demande de formation à valider : ' . $r['ref'], $r['title'], '/tq/' . $rid, true);
        else { Tq::notify(Tq::permUsers('tq.treat'), 'Demande sans N+1 à valider : ' . $r['ref'], $r['title'] . ' — aucun responsable direct renseigné pour le demandeur.', '/tq/' . $rid); flash('Aucun N+1 n\'est renseigné pour vous : l\'équipe formation a été prévenue pour valider votre demande.', 'warning'); }
        flash('Demande envoyée : ' . $r['ref'] . ' — ' . Tq::CLS[$r['pclass']][0] . ' (' . $r['score'] . '/100).'); redirect("tq/$rid");
    }
    function destroy(string $id): void {
        $r = $this->load($id); if (!$r || (int)$r['requester_id'] !== (int)Auth::id() || $r['status'] !== 'draft') { $this->forbidden(); return; }
        foreach (DB::all('SELECT * FROM tq_files WHERE request_id=?', [(int)$r['id']]) as $f) @unlink(self::dir() . '/' . $f['stored_name']);
        DB::exec('DELETE FROM tq_files WHERE request_id=?', [(int)$r['id']]); DB::exec('DELETE FROM tq_events WHERE request_id=?', [(int)$r['id']]); DB::exec('DELETE FROM tq_requests WHERE id=?', [(int)$r['id']]); Audit::log('delete', 'tq_request', $id); flash('Brouillon supprimé.'); redirect('tq');
    }
    function cancel(string $id): void {
        $r = $this->load($id); $mine = $r && (int)$r['requester_id'] === (int)Auth::id();
        if (!$r || !in_array($r['status'], ['draft', 'pending_n1', 'pending_training', 'planned', 'rejected_n1'], true) || !($mine || can('tq.treat'))) { $this->forbidden(); return; }
        $why = mb_substr(trim((string)$this->in('reason', '')), 0, 500); if ($why === '') { flash('Indiquez le motif de l\'annulation.', 'danger'); redirect("tq/$id"); }
        DB::update('tq_requests', ['status' => 'cancelled', 'updated_at' => now()], 'id=?', [(int)$r['id']]); Tq::log((int)$r['id'], 'cancel', $why); Audit::log('cancel', 'tq_request', $id);
        Tq::notify(array_filter([(int)$r['requester_id'], Tq::userOf((int)$r['manager_employee_id']), (int)$r['trainer_user_id']]), 'Demande de formation annulée : ' . $r['ref'], $why, '/tq/' . $r['id']); flash('Demande annulée.'); redirect("tq/$id");
    }

    // =============== Fiche ===============
    function show(string $id): void {
        $r = $this->load($id); if (!$r) { $this->notFound(); return; }
        $mgr = $r['manager_employee_id'] ? DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [(int)$r['manager_employee_id']]) : null;
        $this->view('tq/show', $this->lists() + ['title' => $r['ref'] . ' · ' . $r['title'], 'tab' => ($r['requester_id'] == Auth::id() ? 'mine' : ''), 'r' => $r, 'n1' => $mgr, 'requester' => DB::val('SELECT name FROM users WHERE id=?', [(int)$r['requester_id']]),
            'files' => DB::all('SELECT * FROM tq_files WHERE request_id=? ORDER BY id', [(int)$r['id']]), 'events' => DB::all('SELECT * FROM tq_events WHERE request_id=? ORDER BY id', [(int)$r['id']]), 'trainers' => $this->trainers()]);
    }

    // =============== N+1 ===============
    function validateList(): void {
        $rows = []; foreach (DB::all("SELECT r.*, u.name requester FROM tq_requests r JOIN users u ON u.id=r.requester_id WHERE r.status='pending_n1' ORDER BY r.sla_due") as $r) if (Tq::canValidate($r)) $rows[] = $r;
        $this->view('tq/validate', ['title' => 'Demandes de formation à valider', 'tab' => 'validate', 'rows' => $rows]);
    }
    function decideN1(string $id): void {
        $r = $this->load($id); if (!$r || !Tq::canValidate($r)) { $this->forbidden(); return; }
        $dec = (string)$this->in('decision', ''); $c = mb_substr(trim((string)$this->in('comment', '')), 0, 2000); $err = [];
        if (!isset(Tq::MGR[$dec])) $err[] = 'Choisissez une décision.'; if (in_array($dec, ['reserves', 'rejete', 'report'], true) && $c === '') $err[] = 'Un commentaire est obligatoire pour cette décision.';
        $nd = trim((string)$this->in('new_start', '')); if ($dec === 'report' && (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $nd) || !strtotime($nd))) $err[] = 'Indiquez la nouvelle date de début souhaitée.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("tq/$id"); }
        $u = ['manager_decision' => $dec, 'manager_comment' => $c ?: null, 'manager_at' => now(), 'manager_user_id' => Auth::id(), 'updated_at' => now()];
        if ($dec === 'rejete') { DB::update('tq_requests', $u + ['status' => 'rejected_n1'], 'id=?', [(int)$r['id']]); Tq::log((int)$r['id'], 'n1_reject', $c); Tq::notify([(int)$r['requester_id']], 'Demande de formation rejetée par votre N+1 : ' . $r['ref'], $c, '/tq/' . $r['id'], true); flash('Demande rejetée : elle ne remonte pas à l\'équipe formation.'); redirect('tq/validate'); }
        if ($dec === 'report') { $u['start_wish'] = $nd; if ($r['end_wish'] && $r['end_wish'] < $nd) $u['end_wish'] = $nd; if ($r['competence_date'] && $r['competence_date'] < ($u['end_wish'] ?? $r['end_wish'])) $u['competence_date'] = $u['end_wish'] ?? $r['end_wish']; }
        $m = array_merge($r, $u); $sc = Tq::score($m, substr((string)$r['submitted_at'], 0, 10)); $u += $sc + ['sla_due' => Tq::slaDue($sc['pclass'], strtotime($r['submitted_at'])), 'status' => 'pending_training'];
        DB::update('tq_requests', $u, 'id=?', [(int)$r['id']]); Tq::log((int)$r['id'], 'n1_' . $dec, $c . ($dec === 'report' ? " (nouveau début : $nd)" : ''));
        $r = DB::one('SELECT * FROM tq_requests WHERE id=?', [(int)$r['id']]); Tq::announce($r); Audit::log('n1_decision', 'tq_request', $id, null, ['decision' => $dec]);
        flash('Demande transmise à l\'équipe formation.'); redirect('tq/validate');
    }

    // =============== Équipe formation ===============
    function treatList(): void {
        $st = (string)$this->in('status', 'pending_training'); $cl = (string)$this->in('class', ''); $w = ["r.status NOT IN ('draft','pending_n1','rejected_n1')"]; $p = [];
        if ($st !== 'all') { $w[] = 'r.status=?'; $p[] = $st; } if (isset(Tq::CLS[$cl])) { $w[] = 'r.pclass=?'; $p[] = $cl; }
        $this->view('tq/treat', ['title' => 'Traitement des demandes de formation', 'tab' => 'treat', 'st' => $st, 'cl' => $cl, 'rows' => DB::all('SELECT r.*, u.name requester FROM tq_requests r JOIN users u ON u.id=r.requester_id WHERE ' . implode(' AND ', $w) . ' ORDER BY r.sla_due LIMIT 300', $p)]);
    }
    function treat(string $id): void {
        $r = $this->load($id); if (!$r || !Tq::canTreat($r)) { $this->forbidden(); return; }
        $dec = (string)$this->in('decision', ''); $why = mb_substr(trim((string)$this->in('reason', '')), 0, 2000); $err = [];
        if (!isset(Tq::DEC[$dec])) $err[] = 'Choisissez une décision.';
        $pd = trim((string)$this->in('planned_date', '')); $pe = trim((string)$this->in('planned_end', '')); $tu = (int)$this->in('trainer_user_id', 0); $tn = mb_substr(trim((string)$this->in('trainer_name', '')), 0, 150);
        if ($tu && !in_array($tu, Tq::permUsers('tq.deliver'), true)) { $err[] = 'Ce formateur n\'est pas habilité.'; $tu = 0; }
        if ($tu) $tn = (string)DB::val('SELECT name FROM users WHERE id=?', [$tu]);
        if ($dec === 'rejete' && $why === '') $err[] = 'Le motif du rejet est obligatoire.';
        if (in_array($dec, ['approuve', 'report'], true)) {
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $pd) || !strtotime($pd)) $err[] = 'La date de formation est obligatoire.'; if ($pe !== '' && (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $pe) || $pe < $pd)) $err[] = 'Date de fin invalide.';
            if ($tn === '') $err[] = 'Affectez un formateur.'; if ($dec === 'report' && $why === '') $err[] = 'Le motif du report est obligatoire.';
        }
        $rl = (string)$this->in('risk_level', ''); if ($rl !== '' && !isset(Tq::RISK[$rl])) $err[] = 'Niveau de risque inconnu.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("tq/$id"); }
        $m = $r; if ($rl !== '' && $rl !== $r['risk_level']) $m['risk_level'] = $rl; $sc = Tq::score($m, substr((string)$r['submitted_at'], 0, 10));
        $u = ['decision' => $dec, 'decision_reason' => $why ?: null, 'decided_by' => Auth::id(), 'decided_at' => now(), 'updated_at' => now(), 'status' => $dec === 'rejete' ? 'rejected' : 'planned', 'planned_date' => $dec === 'rejete' ? null : $pd, 'planned_end' => $dec === 'rejete' ? null : ($pe ?: null), 'trainer_user_id' => $tu ?: null, 'trainer_name' => $tn ?: null];
        if ($sc['score'] !== (int)$r['score']) { $u += $sc + ['sla_due' => Tq::slaDue($sc['pclass'], strtotime($r['submitted_at']))]; Tq::log((int)$r['id'], 'rescore', 'Niveau de risque ajusté : score ' . $r['score'] . ' → ' . $sc['score']); }
        DB::update('tq_requests', $u, 'id=?', [(int)$r['id']]); Tq::log((int)$r['id'], 'decision_' . $dec, trim(($dec === 'rejete' ? '' : "Date $pd · Formateur $tn · ") . $why)); Audit::log('treat', 'tq_request', $id, null, ['decision' => $dec]);
        $who = array_filter([(int)$r['requester_id'], Tq::userOf((int)$r['manager_employee_id']), $tu]);
        $msg = $dec === 'rejete' ? 'Rejetée : ' . $why : ($dec === 'report' ? 'Reportée au ' . date('d/m/Y', strtotime($pd)) . ' (' . $why . ')' : 'Approuvée : ' . date('d/m/Y', strtotime($pd))) . ($tn ? ' · formateur : ' . $tn : '');
        Tq::notify($who, 'Demande de formation ' . $r['ref'] . ' : ' . Tq::DEC[$dec], $msg, '/tq/' . $r['id'], true); flash('Décision enregistrée.'); redirect('tq/treat');
    }

    // =============== Formateur ===============
    function deliverList(): void {
        $w = ["r.status IN ('planned','done')"]; $p = []; if (!can('tq.treat')) { $w[] = 'r.trainer_user_id=?'; $p[] = Auth::id(); }
        $this->view('tq/deliver', ['title' => 'Formations à animer', 'tab' => 'deliver', 'rows' => DB::all('SELECT r.*, u.name requester FROM tq_requests r JOIN users u ON u.id=r.requester_id WHERE ' . implode(' AND ', $w) . " ORDER BY r.status='done', r.planned_date LIMIT 300", $p)]);
    }
    function complete(string $id): void {
        $r = $this->load($id); if (!$r || $r['status'] !== 'planned' || !Tq::isTrainer($r) || !(can('tq.deliver') || can('tq.treat'))) { $this->forbidden(); return; }
        $o = (string)$this->in('outcome', ''); $c = mb_substr(trim((string)$this->in('comment', '')), 0, 2000); $n = trim((string)$this->in('participants', '')); $err = [];
        if (!isset(Tq::OUTCOME[$o])) $err[] = 'Indiquez si la formation a été réalisée.'; if ($o !== 'realisee' && $c === '') $err[] = 'Un commentaire est obligatoire si la formation n\'est pas entièrement réalisée.';
        if ($n !== '' && (!ctype_digit($n) || (int)$n > 100000)) $err[] = 'Nombre de participants invalide.';
        $fe = []; $had = (int)DB::val("SELECT COUNT(*) FROM tq_files WHERE request_id=? AND kind='report'", [(int)$r['id']]);
        if (!$err) { $fe = $this->takeFiles((int)$r['id'], 'report', 'report'); $has = (int)DB::val("SELECT COUNT(*) FROM tq_files WHERE request_id=? AND kind='report'", [(int)$r['id']]); if ($o !== 'non_realisee' && !$has) $err[] = 'Joignez le rapport de fin de formation.'; }
        if ($err || $fe) { flash(implode(' ', array_merge($err, $fe)), 'danger'); redirect("tq/$id"); }
        DB::update('tq_requests', ['status' => 'done', 'outcome' => $o, 'outcome_comment' => $c ?: null, 'participants' => $n !== '' ? (int)$n : null, 'done_at' => now(), 'updated_at' => now()], 'id=?', [(int)$r['id']]);
        Tq::log((int)$r['id'], 'done_' . $o, $c); Audit::log('complete', 'tq_request', $id, null, ['outcome' => $o]);
        Tq::notify(array_merge([(int)$r['requester_id'], Tq::userOf((int)$r['manager_employee_id'])], Tq::permUsers('tq.treat')), 'Formation ' . strtolower(Tq::OUTCOME[$o]) . ' : ' . $r['ref'], $r['title'] . ($c ? ' — ' . $c : ''), '/tq/' . $r['id'], true); flash('Statut enregistré, les personnes concernées sont prévenues.'); redirect('tq/deliver');
    }

    // =============== Fichiers ===============
    private function takeFiles(int $rid, string $field, string $kind): array {
        $f = $_FILES[$field] ?? null; $err = []; if (!$f) return [];
        $names = is_array($f['name']) ? $f['name'] : [$f['name']]; $tmp = is_array($f['tmp_name']) ? $f['tmp_name'] : [$f['tmp_name']]; $er = is_array($f['error']) ? $f['error'] : [$f['error']]; $sz = is_array($f['size']) ? $f['size'] : [$f['size']];
        $have = (int)DB::val('SELECT COUNT(*) FROM tq_files WHERE request_id=? AND kind=?', [$rid, $kind]);
        foreach ($names as $k => $name) {
            if (($er[$k] ?? 4) === UPLOAD_ERR_NO_FILE) continue; if ($er[$k] !== UPLOAD_ERR_OK) { $err[] = "« $name » non reçu."; continue; }
            if ($have >= 10) { $err[] = '10 fichiers maximum.'; break; }
            $n = trim(preg_replace('#[\x00-\x1f\\\\/]+#', '_', (string)$name)); $ext = strtolower(pathinfo($n, PATHINFO_EXTENSION));
            if (!array_key_exists($ext, self::FILES) || $sz[$k] > 10 * 1024 * 1024) { $err[] = "« $n » refusé (pdf, Word, PowerPoint, Excel, jpg ou png, 10 Mo maximum)."; continue; }
            $mime = function_exists('mime_content_type') ? (string)@mime_content_type($tmp[$k]) : ''; $want = self::FILES[$ext];
            if ($want !== '' && $mime !== '' && $mime !== $want) { $err[] = "« $n » : contenu non conforme à l'extension."; continue; }
            $st = bin2hex(random_bytes(16)) . '.' . $ext; if (!@move_uploaded_file($tmp[$k], self::dir() . '/' . $st)) { $err[] = "« $n » non enregistré."; continue; }
            DB::insert('tq_files', ['request_id' => $rid, 'kind' => $kind, 'original_name' => mb_substr($n, 0, 190), 'stored_name' => $st, 'mime' => $want ?: 'application/octet-stream', 'size' => (int)$sz[$k], 'user_id' => Auth::id(), 'created_at' => now()]); $have++;
        }
        return $err;
    }
    function file(string $fid): void {
        $f = DB::one('SELECT * FROM tq_files WHERE id=?', [(int)$fid]); $r = $f ? $this->load((string)$f['request_id']) : null; if (!$f || !$r) { $this->notFound(); return; }
        $p = self::dir() . '/' . $f['stored_name']; if (!is_file($p)) { $this->notFound(); return; } Audit::log('download', 'tq_file', $fid);
        header('Content-Type: ' . $f['mime']); header('X-Content-Type-Options: nosniff'); header("Content-Security-Policy: sandbox; default-src 'none'"); header('Content-Length: ' . filesize($p));
        header('Content-Disposition: attachment; filename="' . str_replace(['"', "\r", "\n"], '', $f['original_name']) . '"'); readfile($p); exit;
    }

    // =============== Tableau de bord ===============
    function dashboard(): void {
        $from = (string)$this->in('from', date('Y-01-01')); $to = (string)$this->in('to', date('Y-m-d')); $cl = (string)$this->in('class', ''); $dir = (string)$this->in('direction', '');
        $w = ["r.status<>'draft'", 'DATE(r.submitted_at)>=?', 'DATE(r.submitted_at)<=?']; $p = [$from, $to]; if (isset(Tq::CLS[$cl])) { $w[] = 'r.pclass=?'; $p[] = $cl; } if ($dir !== '') { $w[] = 'r.direction=?'; $p[] = $dir; }
        $rows = DB::all('SELECT r.*, u.name requester FROM tq_requests r JOIN users u ON u.id=r.requester_id WHERE ' . implode(' AND ', $w) . ' ORDER BY r.submitted_at DESC', $p); $now = now();
        $k = ['total' => count($rows), 'open' => 0, 'late' => 0, 'ontime' => 0, 'decided' => 0, 'score' => 0, 'hours' => 0]; $byCls = []; $bySt = []; $byDir = []; $byObj = [];
        foreach ($rows as &$r) {
            $byCls[$r['pclass']] = ($byCls[$r['pclass']] ?? 0) + 1; $bySt[$r['status']] = ($bySt[$r['status']] ?? 0) + 1; $byDir[$r['direction'] ?: '—'] = ($byDir[$r['direction'] ?: '—'] ?? 0) + 1; $byObj[$r['objective'] ?: '—'] = ($byObj[$r['objective'] ?: '—'] ?? 0) + 1; $k['score'] += (int)$r['score'];
            $r['late'] = false; if ($r['decided_at']) { $k['decided']++; $k['hours'] += (strtotime($r['decided_at']) - strtotime($r['submitted_at'])) / 3600; if ($r['decided_at'] <= $r['sla_due']) $k['ontime']++; else $r['late'] = true; }
            elseif (in_array($r['status'], ['pending_n1', 'pending_training'], true)) { $k['open']++; if ($r['sla_due'] < $now) { $k['late']++; $r['late'] = true; } }
        } unset($r);
        if ($this->in('export') === 'csv') { csv_download('demandes_formation_' . date('Ymd') . '.csv', ['Réf.', 'Demandeur', 'Direction', 'Intitulé', 'Priorité', 'Score', 'Classe', 'Statut', 'Soumise le', 'Échéance prise en charge', 'Décision', 'Formateur', 'Date prévue', 'Résultat', 'Hors délai'],
            array_map(fn($r) => [$r['ref'], $r['requester'], Ref::label('tq_directions', $r['direction']), $r['title'], Tq::PRIORITY[$r['priority_level']][0] ?? '', $r['score'], $r['pclass'], Tq::ST[$r['status']][0] ?? $r['status'], $r['submitted_at'], $r['sla_due'], Tq::DEC[$r['decision']] ?? '', $r['trainer_name'], $r['planned_date'], Tq::OUTCOME[$r['outcome']] ?? '', $r['late'] ? 'oui' : 'non'], $rows)); return; }
        $this->view('tq/dashboard', ['title' => 'Demandes de formation : tableau de bord', 'tab' => 'dash', 'rows' => $rows, 'k' => $k, 'byCls' => $byCls, 'bySt' => $bySt, 'byDir' => $byDir, 'byObj' => $byObj, 'from' => $from, 'to' => $to, 'cl' => $cl, 'dir' => $dir, 'directions' => Ref::items('tq_directions'), 'objectives' => Ref::items('tq_objectives')]);
    }
}
