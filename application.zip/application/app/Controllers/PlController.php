<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Auth, Pl, Scope, Audit, Notifier};
/** Planification des équipes (centre d'appels, digital, boutiques, fonctions support) et performance. */
class PlController extends Controller {
    // ---- Outils ----
    /** Unités ayant au moins un collaborateur dans le périmètre de l'utilisateur. */
    protected function myUnits(): array {
        $all = Pl::units(); if (Scope::ids() === null) return $all; $o = [];
        foreach ($all as $k => $u) if (Pl::employees($u)) $o[$k] = $u; return $o;
    }
    protected function pickUnit(array $units): ?array { $k = (string)$this->in('unit', ''); return $units[$k] ?? ($units ? reset($units) : null); }
    private function week(): string { $w = (string)$this->in('week', ''); return Pl::monday(Pl::validDate($w) ? $w : date('Y-m-d')); }
    private function userOf(int $emp): ?int { $u = DB::val('SELECT id FROM users WHERE employee_id=? AND status=?', [$emp, 'active']); return $u ? (int)$u : null; }
    protected function empName(int $id): string { $e = DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [$id]); return $e ? $e['first_name'] . ' ' . $e['last_name'] : '—'; }

    // ---- Mon planning ----
    function mine(): void {
        $emp = Pl::myEmployee(); $w = $this->week(); $sh = Pl::shifts(false); $rows = [];
        if ($emp) foreach (DB::all("SELECT * FROM pl_assignments WHERE employee_id=? AND day>=? AND day<=? AND status='published'", [$emp, $w, Pl::addDays($w, 6)]) as $a) $rows[$a['day']] = $a;
        $min = 0; foreach ($rows as $a) $min += Pl::minutes($sh[(int)$a['shift_id']] ?? []);
        $this->view('pl/mine', ['title' => 'Mon planning', 'emp' => $emp, 'week' => $w, 'rows' => $rows, 'shifts' => $sh, 'hours' => round($min / 60, 1)]);
    }

    // ---- Planning des équipes ----
    function roster(): void {
        $units = $this->myUnits(); $u = $this->pickUnit($units); $w = $this->week(); $emps = $u ? Pl::employees($u) : []; $sh = Pl::shifts(); $asg = []; $min = [];
        if ($u && $emps) {
            $ids = array_column($emps, 'id'); $in = implode(',', array_fill(0, count($ids), '?')); $all = Pl::shifts(false);
            foreach (DB::all("SELECT * FROM pl_assignments WHERE employee_id IN ($in) AND day>=? AND day<=?", array_merge($ids, [$w, Pl::addDays($w, 6)])) as $a) { $asg[$a['employee_id']][$a['day']] = $a; $min[$a['employee_id']] = ($min[$a['employee_id']] ?? 0) + Pl::minutes($all[(int)$a['shift_id']] ?? []); }
        }
        $this->view('pl/roster', ['title' => 'Planning des équipes', 'units' => $units, 'u' => $u, 'week' => $w, 'emps' => $emps, 'shifts' => $sh, 'asg' => $asg, 'min' => $min, 'published' => $u ? Pl::published($u['type'], $u['id'], $w) : false, 'max' => (int)setting('pl.max_week_hours', 48)]);
    }
    private function planCtx(): ?array {
        $units = $this->myUnits(); $u = $units[(string)$this->in('unit', '')] ?? null; $w = $this->week();
        if (!$u) { $this->notFound(); return null; } return [$u, $w];
    }
    function saveRoster(): void {
        if (!($c = $this->planCtx())) return; [$u, $w] = $c; $emps = []; foreach (Pl::employees($u) as $e) $emps[(int)$e['id']] = $e; $sh = Pl::shifts(); $today = date('Y-m-d'); $ok = 0; $bad = []; $warn = [];
        foreach ((array)($_POST['a'] ?? []) as $eid => $days) {
            if (!isset($emps[(int)$eid]) || !is_array($days)) continue;
            foreach ($days as $day => $sid) {
                if (!Pl::validDate((string)$day) || $day < $w || $day > Pl::addDays($w, 6)) continue; $sid = $sid === '' ? null : (int)$sid; $name = $emps[(int)$eid]['last_name'] . ' ' . $emps[(int)$eid]['first_name'];
                if ($sid !== null && !isset($sh[$sid])) continue; $cur = Pl::assignment((int)$eid, $day); if (($cur ? (int)$cur['shift_id'] : null) === $sid) continue;
                if ($day < $today) { $bad[] = "$name " . date('d/m', strtotime($day)) . ' : jour passé'; continue; }
                [$err, $wr] = Pl::conflicts((int)$eid, $day, $sid ? $sh[$sid] : null); if ($err) { $bad[] = "$name " . date('d/m', strtotime($day)) . ' : ' . implode(', ', $err); continue; }
                foreach ($wr as $x) $warn[] = "$name : $x"; if (Pl::assign((int)$eid, $day, $sid, $u)) $ok++;
            }
        }
        Audit::log('update', 'pl_roster', null, null, ['unit' => $u['key'], 'week' => $w, 'changes' => $ok]);
        flash("$ok modification(s) enregistrée(s)." . ($bad ? ' Refusées : ' . implode(' ; ', array_slice($bad, 0, 6)) . (count($bad) > 6 ? '…' : '') : ''), $bad ? 'warning' : 'success');
        if ($warn) flash('À vérifier : ' . implode(' ; ', array_slice(array_unique($warn), 0, 5)), 'warning');
        redirect('pl/roster?unit=' . $u['key'] . '&week=' . $w);
    }
    function copyWeek(): void {
        if (!($c = $this->planCtx())) return; [$u, $w] = $c; $prev = Pl::addDays($w, -7); $sh = Pl::shifts(); $ok = 0; $skip = 0; $today = date('Y-m-d');
        foreach (Pl::employees($u) as $e) foreach (DB::all('SELECT day, shift_id FROM pl_assignments WHERE employee_id=? AND day>=? AND day<=? AND shift_id IS NOT NULL', [(int)$e['id'], $prev, Pl::addDays($prev, 6)]) as $a) {
            $d = Pl::addDays($a['day'], 7); if ($d < $today || !isset($sh[(int)$a['shift_id']]) || Pl::assignment((int)$e['id'], $d)) { $skip++; continue; }
            [$err] = Pl::conflicts((int)$e['id'], $d, $sh[(int)$a['shift_id']]); if ($err) { $skip++; continue; } Pl::assign((int)$e['id'], $d, (int)$a['shift_id'], $u); $ok++;
        }
        Audit::log('copy', 'pl_roster', null, null, ['unit' => $u['key'], 'week' => $w, 'copied' => $ok]); flash("$ok affectation(s) copiée(s) de la semaine précédente ($skip ignorée(s) : déjà planifiées, en congé, repos non respecté ou passées)."); redirect('pl/roster?unit=' . $u['key'] . '&week=' . $w);
    }
    function publishWeek(): void {
        if (!($c = $this->planCtx())) return; [$u, $w] = $c;
        if (!DB::val('SELECT 1 FROM pl_assignments WHERE unit_type=? AND unit_id=? AND day>=? AND day<=?', [$u['type'], $u['id'], $w, Pl::addDays($w, 6)])) { flash('Rien à publier : la semaine est vide.', 'warning'); redirect('pl/roster?unit=' . $u['key'] . '&week=' . $w); }
        $n = Pl::publish($u, $w); Audit::log('publish', 'pl_roster', null, null, ['unit' => $u['key'], 'week' => $w]); flash("Planning publié ; $n collaborateur(s) prévenu(s)."); redirect('pl/roster?unit=' . $u['key'] . '&week=' . $w);
    }

    // ---- Couverture ----
    function coverage(): void {
        $units = $this->myUnits(); $u = $this->pickUnit($units); $w = $this->week(); $day = (string)$this->in('day', ''); if (!Pl::validDate($day) || $day < $w || $day > Pl::addDays($w, 6)) $day = ($w <= date('Y-m-d') && date('Y-m-d') <= Pl::addDays($w, 6)) ? date('Y-m-d') : $w;
        $this->view('pl/coverage', ['title' => 'Couverture', 'units' => $units, 'u' => $u, 'week' => $w, 'day' => $day, 'shifts' => array_filter(Pl::shifts(), fn($s) => Pl::isWork($s)), 'needs' => $u ? Pl::needs($u) : [], 'planned' => $u ? Pl::planned($u, $w, Pl::addDays($w, 6)) : [], 'hourly' => $u ? Pl::hourly($u, $day) : array_fill(0, 24, 0)]);
    }

    // ---- Échanges de shifts ----
    function swaps(): void {
        $emp = Pl::myEmployee(); $sh = Pl::shifts(false); $cands = [];
        if ($emp) foreach (DB::all("SELECT * FROM pl_assignments WHERE employee_id=? AND day>? AND day<=? AND status='published' AND shift_id IS NOT NULL ORDER BY day", [$emp, date('Y-m-d'), Pl::addDays(date('Y-m-d'), 28)]) as $a) {
            if (!Pl::isWork($sh[(int)$a['shift_id']] ?? null)) continue;
            foreach (DB::all("SELECT p.*, e.first_name, e.last_name FROM pl_assignments p JOIN employees e ON e.id=p.employee_id WHERE p.unit_type=? AND p.unit_id=? AND p.day=? AND p.employee_id<>? AND p.status='published' AND p.shift_id<>? AND p.shift_id IS NOT NULL", [$a['unit_type'], $a['unit_id'], $a['day'], $emp, $a['shift_id']]) as $p) if (Pl::isWork($sh[(int)$p['shift_id']] ?? null)) $cands[] = ['v' => $a['day'] . '|' . $p['employee_id'], 'l' => date('d/m', strtotime($a['day'])) . ' : mon ' . Pl::label($sh[(int)$a['shift_id']]) . ' ↔ ' . $p['first_name'] . ' ' . $p['last_name'] . ' (' . Pl::label($sh[(int)$p['shift_id']]) . ')'];
        }
        $mine = $emp ? DB::all('SELECT * FROM pl_swaps WHERE requester_id=? OR partner_id=? ORDER BY id DESC LIMIT 30', [$emp, $emp]) : [];
        $todo = []; if (can('pl.plan')) foreach (DB::all("SELECT * FROM pl_swaps WHERE status='pending_manager' ORDER BY id") as $s) if (Scope::allows((int)$s['requester_id'])) $todo[] = $s;
        $this->view('pl/swaps', ['title' => 'Échanges de shifts', 'emp' => $emp, 'cands' => $cands, 'mine' => $mine, 'todo' => $todo, 'shifts' => $sh, 'names' => fn($i) => $this->empName($i)]);
    }
    function createSwap(): void {
        $emp = Pl::myEmployee(); [$day, $pid] = array_pad(explode('|', (string)$this->in('pick', '')), 2, ''); $pid = (int)$pid; $sh = Pl::shifts(false);
        $a = $emp ? Pl::assignment($emp, $day) : null; $b = $pid ? Pl::assignment($pid, $day) : null;
        if (!$a || !$b || $a['status'] !== 'published' || $b['status'] !== 'published' || $day <= date('Y-m-d') || $a['unit_type'] !== $b['unit_type'] || (int)$a['unit_id'] !== (int)$b['unit_id'] || (int)$a['shift_id'] === (int)$b['shift_id'] || !Pl::isWork($sh[(int)$a['shift_id']] ?? null) || !Pl::isWork($sh[(int)$b['shift_id']] ?? null)) { flash('Échange impossible : choisissez un jour futur où vous et votre collègue avez un shift publié différent dans la même équipe.', 'danger'); redirect('pl/swaps'); }
        if (DB::val("SELECT 1 FROM pl_swaps WHERE day=? AND status IN ('pending_partner','pending_manager') AND (requester_id IN (?,?) OR partner_id IN (?,?))", [$day, $emp, $pid, $emp, $pid])) { flash('Un échange est déjà en cours pour ce jour.', 'warning'); redirect('pl/swaps'); }
        $id = DB::insert('pl_swaps', ['day' => $day, 'requester_id' => $emp, 'partner_id' => $pid, 'req_shift_id' => (int)$a['shift_id'], 'partner_shift_id' => (int)$b['shift_id'], 'status' => 'pending_partner', 'note' => mb_substr(trim((string)$this->in('note', '')), 0, 300) ?: null, 'created_at' => now(), 'updated_at' => now()]);
        if ($uid = $this->userOf($pid)) Notifier::send($uid, 'Demande d\'échange de shift', $this->empName($emp) . ' propose d\'échanger le ' . date('d/m/Y', strtotime($day)), '/pl/swaps'); Audit::log('create', 'pl_swap', $id); flash('Demande envoyée à votre collègue.'); redirect('pl/swaps');
    }
    function swapAction(string $id, string $act): void {
        $s = DB::one('SELECT * FROM pl_swaps WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; } $emp = Pl::myEmployee(); $note = mb_substr(trim((string)$this->in('note', '')), 0, 300); $m = '';
        if ($act === 'accept' && $s['status'] === 'pending_partner' && $emp === (int)$s['partner_id']) {
            DB::update('pl_swaps', ['status' => 'pending_manager', 'updated_at' => now()], 'id=?', [(int)$id]); $m = 'Accepté : en attente de validation du responsable.';
            $mgr = DB::val('SELECT manager_id FROM employees WHERE id=?', [(int)$s['requester_id']]); $uid = $mgr ? $this->userOf((int)$mgr) : null; $txt = $this->empName((int)$s['requester_id']) . ' ↔ ' . $this->empName((int)$s['partner_id']) . ' le ' . date('d/m/Y', strtotime($s['day']));
            if ($uid) Notifier::send($uid, 'Échange de shift à valider', $txt, '/pl/swaps'); else Notifier::toPermission('pl.plan', 'Échange de shift à valider', $txt, '/pl/swaps');
        } elseif ($act === 'decline' && $s['status'] === 'pending_partner' && $emp === (int)$s['partner_id']) { DB::update('pl_swaps', ['status' => 'refused', 'decision_note' => $note ?: null, 'updated_at' => now()], 'id=?', [(int)$id]); if ($uid = $this->userOf((int)$s['requester_id'])) Notifier::send($uid, 'Échange de shift refusé', $this->empName((int)$s['partner_id']) . ' a refusé', '/pl/swaps'); $m = 'Échange refusé.'; }
        elseif ($act === 'cancel' && in_array($s['status'], ['pending_partner', 'pending_manager'], true) && $emp === (int)$s['requester_id']) { DB::update('pl_swaps', ['status' => 'cancelled', 'updated_at' => now()], 'id=?', [(int)$id]); $m = 'Demande annulée.'; }
        elseif (in_array($act, ['approve', 'refuse'], true) && $s['status'] === 'pending_manager' && can('pl.plan') && Scope::allows((int)$s['requester_id']) && $emp !== (int)$s['requester_id'] && $emp !== (int)$s['partner_id']) {
            if ($act === 'refuse') { if ($note === '') { flash('Indiquez le motif du refus.', 'danger'); redirect('pl/swaps'); } DB::update('pl_swaps', ['status' => 'refused', 'decision_note' => $note, 'decided_by' => Auth::id(), 'updated_at' => now()], 'id=?', [(int)$id]); $m = 'Échange refusé.'; }
            else {
                $a = Pl::assignment((int)$s['requester_id'], $s['day']); $b = Pl::assignment((int)$s['partner_id'], $s['day']); $sh = Pl::shifts(false);
                if (!$a || !$b || (int)$a['shift_id'] !== (int)$s['req_shift_id'] || (int)$b['shift_id'] !== (int)$s['partner_shift_id']) { flash('Les plannings ont changé depuis la demande : refusez-la et demandez un nouvel échange.', 'danger'); redirect('pl/swaps'); }
                [$e1] = Pl::conflicts((int)$s['requester_id'], $s['day'], $sh[(int)$b['shift_id']]); [$e2] = Pl::conflicts((int)$s['partner_id'], $s['day'], $sh[(int)$a['shift_id']]);
                if ($e1 || $e2) { flash('Échange impossible : ' . implode(', ', array_merge($e1, $e2)) . '.', 'danger'); redirect('pl/swaps'); }
                $u = ['type' => $a['unit_type'], 'id' => (int)$a['unit_id']]; Pl::assign((int)$s['requester_id'], $s['day'], (int)$b['shift_id'], $u); Pl::assign((int)$s['partner_id'], $s['day'], (int)$a['shift_id'], $u);
                DB::update('pl_swaps', ['status' => 'approved', 'decision_note' => $note ?: null, 'decided_by' => Auth::id(), 'updated_at' => now()], 'id=?', [(int)$id]); $m = 'Échange validé : les deux plannings sont mis à jour.';
            }
            foreach ([(int)$s['requester_id'], (int)$s['partner_id']] as $e) if ($uid = $this->userOf($e)) Notifier::send($uid, $act === 'approve' ? 'Échange de shift validé' : 'Échange de shift refusé', date('d/m/Y', strtotime($s['day'])) . ($note ? ' : ' . $note : ''), '/pl/mine');
        } else { $this->forbidden(); return; }
        Audit::log($act, 'pl_swap', $id); flash($m); redirect('pl/swaps');
    }

    // ---- Performance ----
    private function range(): array { $to = (string)$this->in('to', ''); $from = (string)$this->in('from', ''); if (!Pl::validDate($to)) $to = date('Y-m-d'); if (!Pl::validDate($from) || $from > $to) $from = Pl::addDays($to, -29); if (strtotime($to) - strtotime($from) > 400 * 86400) $from = Pl::addDays($to, -399); return [$from, $to]; }
    function performance(): void {
        [$from, $to] = $this->range(); $units = $this->myUnits(); $rows = [];
        foreach ($units as $k => $u) { $st = DB::all('SELECT * FROM pl_stats WHERE unit_type=? AND unit_id=? AND day>=? AND day<=?', [$u['type'], $u['id'], $from, $to]); if (!$st) continue; $kp = Pl::kpi($st); $t = Pl::targets($u); $rows[] = ['u' => $u, 'k' => $kp, 't' => $t, 's' => ['sl' => Pl::status('sl', $kp['sl'], $t['sl']), 'ab' => Pl::status('ab', $kp['ab'], $t['ab']), 'aht' => Pl::status('aht', $kp['aht'], $t['aht']), 'wait' => Pl::status('wait', $kp['wait'], $t['wait'])]]; }
        $d = $units[(string)$this->in('unit', '')] ?? null; $daily = []; $agents = [];
        if ($d) {
            foreach (DB::all('SELECT * FROM pl_stats WHERE unit_type=? AND unit_id=? AND day>=? AND day<=? ORDER BY day', [$d['type'], $d['id'], $from, $to]) as $r) $daily[] = ['day' => $r['day']] + Pl::kpi([$r]);
            $ids = array_column(Pl::employees($d), 'id');
            if ($ids) { $in = implode(',', array_fill(0, count($ids), '?')); foreach (DB::all("SELECT e.id, e.first_name, e.last_name, SUM(a.handled) h, SUM(a.aht_sec*a.handled) ah, SUM(a.logged_min) lg FROM pl_agent_stats a JOIN employees e ON e.id=a.employee_id WHERE a.employee_id IN ($in) AND a.day>=? AND a.day<=? GROUP BY e.id, e.first_name, e.last_name ORDER BY h DESC", array_merge($ids, [$from, $to])) as $a) {
                $qa = DB::val('SELECT AVG(score_pct) FROM qa_evaluations WHERE employee_id=? AND eval_date>=? AND eval_date<=?', [(int)$a['id'], $from, $to]);
                $agents[] = ['name' => $a['first_name'] . ' ' . $a['last_name'], 'h' => (int)$a['h'], 'aht' => $a['h'] ? $a['ah'] / $a['h'] : null, 'hours' => round($a['lg'] / 60, 1), 'occ' => $a['lg'] ? min(100, 100 * $a['ah'] / 60 / $a['lg']) : null, 'qa' => $qa === null ? null : (float)$qa]; } }
        }
        $this->view('pl/performance', ['title' => 'Performance', 'from' => $from, 'to' => $to, 'rows' => $rows, 'd' => $d, 'daily' => $daily, 'agents' => $agents, 'units' => $units]);
    }
    function exportPerformance(): void {
        [$from, $to] = $this->range(); $out = [];
        foreach ($this->myUnits() as $u) { $st = DB::all('SELECT * FROM pl_stats WHERE unit_type=? AND unit_id=? AND day>=? AND day<=?', [$u['type'], $u['id'], $from, $to]); if (!$st) continue; $k = Pl::kpi($st); $out[] = [$u['name'], $k['offered'], $k['handled'], $k['sl'] === null ? '' : round($k['sl'], 1), $k['ab'] === null ? '' : round($k['ab'], 1), $k['aht'] === null ? '' : round($k['aht']), $k['wait'] === null ? '' : round($k['wait'])]; }
        Audit::log('export', 'pl_performance'); csv_download("performance-$from-$to.csv", ['Unité', 'Reçus', 'Traités', 'Taux de service %', 'Abandon %', 'DMT (s)', 'Attente (s)'], $out);
    }
    function forecast(): void {
        $units = $this->myUnits(); $u = $this->pickUnit($units);
        $this->view('pl/forecast', ['title' => 'Prévisions et effectifs', 'units' => $units, 'u' => $u, 'rows' => $u ? Pl::forecast($u) : [], 'queue' => $u ? Pl::queueUnit($u) : false, 'shrink' => (float)setting('pl.shrinkage', '25'), 'peak' => (float)setting('pl.peak_share', '12'), 'thr' => (float)setting('pl.sl_threshold', '20'), 'target' => $u ? Pl::targets($u)['sl'] : 80]);
    }

    // ---- Données d'activité ----
    function data(): void {
        $this->view('pl/data', ['title' => 'Données d\'activité', 'units' => Pl::units(), 'recent' => DB::all('SELECT * FROM pl_stats ORDER BY day DESC, id DESC LIMIT 25'), 'agents' => (int)DB::val('SELECT COUNT(*) FROM pl_agent_stats'), 'last' => DB::val('SELECT MAX(day) FROM pl_stats')]);
    }
    protected function csvRows(): ?array {
        $f = $_FILES['file'] ?? null; if (!$f || $f['error'] !== UPLOAD_ERR_OK) { flash('Choisissez un fichier CSV.', 'danger'); return null; }
        if ($f['size'] > 2 * 1048576) { flash('Fichier trop lourd (2 Mo maximum).', 'danger'); return null; }
        $txt = (string)file_get_contents($f['tmp_name']); $txt = preg_replace('/^\xEF\xBB\xBF/', '', $txt); if (!mb_check_encoding($txt, 'UTF-8')) $txt = mb_convert_encoding($txt, 'UTF-8', 'ISO-8859-1');
        $lines = preg_split('/\r\n|\r|\n/', trim($txt)); if (count($lines) < 2) { flash('Fichier vide.', 'danger'); return null; } if (count($lines) > 5001) { flash('5 000 lignes maximum par import.', 'danger'); return null; }
        $delim = substr_count($lines[0], ';') >= substr_count($lines[0], ',') ? ';' : ','; $rows = []; foreach ($lines as $l) $rows[] = str_getcsv($l, $delim, '"', '');
        return $rows;
    }
    protected static function ymd(string $d): ?string { $d = trim($d); if (preg_match('#^(\d{1,2})/(\d{1,2})/(\d{4})$#', $d, $m)) $d = sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]); return Pl::validDate($d) ? $d : null; }
    function importUnits(): void {
        if (($rows = $this->csvRows()) === null) redirect('pl/data'); $head = array_map(fn($h) => strtolower(trim($h)), array_shift($rows)); $need = ['date', 'unit', 'offered', 'handled', 'in_sla', 'abandoned', 'aht_sec', 'wait_sec'];
        if (array_diff($need, $head)) { flash('Colonnes attendues : ' . implode(';', $need), 'danger'); redirect('pl/data'); }
        $byCode = []; foreach (Pl::units() as $u) $byCode[strtolower($u['code'])][] = $u; $ok = 0; $err = [];
        foreach ($rows as $i => $r) {
            if (count(array_filter($r, 'strlen')) === 0) continue; $r = array_combine($head, array_pad(array_slice($r, 0, count($head)), count($head), '')); $ln = $i + 2;
            $d = self::ymd((string)$r['date']); $us = $byCode[strtolower(trim($r['unit']))] ?? []; $n = []; foreach (array_slice($need, 2) as $k) { $v = trim((string)$r[$k]); if (!ctype_digit($v) || strlen($v) > 9) { $n = null; break; } $n[$k] = (int)$v; }
            if (!$d) $err[] = "ligne $ln : date invalide"; elseif (count($us) !== 1) $err[] = "ligne $ln : unité « {$r['unit']} » " . ($us ? 'ambiguë' : 'inconnue'); elseif ($n === null) $err[] = "ligne $ln : nombre invalide";
            elseif ($n['handled'] > $n['offered'] || $n['in_sla'] > $n['offered'] || $n['abandoned'] > $n['offered']) $err[] = "ligne $ln : traités, dans le délai ou abandons supérieurs aux reçus";
            else { $this->upsertStat($d, $us[0], $n, 'csv'); $ok++; }
        }
        Audit::log('import', 'pl_stats', null, null, ['ok' => $ok, 'errors' => count($err)]); flash("$ok ligne(s) importée(s)." . ($err ? ' ' . count($err) . ' refusée(s) : ' . implode(' ; ', array_slice($err, 0, 8)) . (count($err) > 8 ? '…' : '') : ''), $err ? 'warning' : 'success'); redirect('pl/data');
    }
    private function upsertStat(string $d, array $u, array $n, string $src): void {
        $row = ['offered' => $n['offered'], 'handled' => $n['handled'], 'in_sla' => $n['in_sla'], 'abandoned' => $n['abandoned'], 'aht_sec' => $n['aht_sec'], 'wait_sec' => $n['wait_sec'], 'source' => $src];
        $x = DB::val('SELECT id FROM pl_stats WHERE day=? AND unit_type=? AND unit_id=?', [$d, $u['type'], $u['id']]); if ($x) DB::update('pl_stats', $row, 'id=?', [(int)$x]); else DB::insert('pl_stats', $row + ['day' => $d, 'unit_type' => $u['type'], 'unit_id' => $u['id'], 'created_at' => now()]);
    }
    function entry(): void {
        $u = Pl::unit((string)$this->in('unit', '')); $d = self::ymd((string)$this->in('day', '')); $n = [];
        foreach (['offered', 'handled', 'in_sla', 'abandoned', 'aht_sec', 'wait_sec'] as $k) { $v = trim((string)$this->in($k, '0')); if (!ctype_digit($v) || strlen($v) > 9) { $n = null; break; } $n[$k] = (int)$v; }
        if (!$u || !$d || $n === null || $n['handled'] > $n['offered'] || $n['in_sla'] > $n['offered'] || $n['abandoned'] > $n['offered']) { flash('Saisie invalide : unité, date, nombres entiers ; traités, dans le délai et abandons ne peuvent dépasser les reçus.', 'danger'); redirect('pl/data'); }
        $this->upsertStat($d, $u, $n, 'manual'); Audit::log('update', 'pl_stats', null, null, ['unit' => $u['key'], 'day' => $d]); flash('Données enregistrées.'); redirect('pl/data');
    }
    function importAgents(): void {
        if (($rows = $this->csvRows()) === null) redirect('pl/data'); $head = array_map(fn($h) => strtolower(trim($h)), array_shift($rows)); $need = ['date', 'matricule', 'handled', 'aht_sec', 'logged_min'];
        if (array_diff($need, $head)) { flash('Colonnes attendues : ' . implode(';', $need), 'danger'); redirect('pl/data'); }
        $ok = 0; $err = [];
        foreach ($rows as $i => $r) {
            if (count(array_filter($r, 'strlen')) === 0) continue; $r = array_combine($head, array_pad(array_slice($r, 0, count($head)), count($head), '')); $ln = $i + 2; $d = self::ymd((string)$r['date']); $e = DB::val('SELECT id FROM employees WHERE matricule=?', [trim($r['matricule'])]); $n = [];
            foreach (['handled', 'aht_sec', 'logged_min'] as $k) { $v = trim((string)$r[$k]); if (!ctype_digit($v) || strlen($v) > 9) { $n = null; break; } $n[$k] = (int)$v; }
            if (!$d) $err[] = "ligne $ln : date invalide"; elseif (!$e) $err[] = "ligne $ln : matricule inconnu"; elseif ($n === null) $err[] = "ligne $ln : nombre invalide";
            else { $x = DB::val('SELECT id FROM pl_agent_stats WHERE employee_id=? AND day=?', [(int)$e, $d]); if ($x) DB::update('pl_agent_stats', $n, 'id=?', [(int)$x]); else DB::insert('pl_agent_stats', $n + ['employee_id' => (int)$e, 'day' => $d, 'created_at' => now()]); $ok++; }
        }
        Audit::log('import', 'pl_agent_stats', null, null, ['ok' => $ok, 'errors' => count($err)]); flash("$ok ligne(s) importée(s)." . ($err ? ' ' . count($err) . ' refusée(s) : ' . implode(' ; ', array_slice($err, 0, 8)) : ''), $err ? 'warning' : 'success'); redirect('pl/data');
    }
    function deleteStat(string $id): void { DB::exec('DELETE FROM pl_stats WHERE id=?', [(int)$id]); Audit::log('delete', 'pl_stats', $id); flash('Ligne supprimée.'); redirect('pl/data'); }
    function template(string $kind): void {
        if ($kind === 'units') csv_download('modele-activite-unites.csv', ['date', 'unit', 'offered', 'handled', 'in_sla', 'abandoned', 'aht_sec', 'wait_sec'], [[date('Y-m-d', strtotime('-1 day')), 'CC1', 1200, 1100, 950, 100, 280, 22]]);
        if ($kind === 'flows') csv_download('modele-flux-horaires.csv', ['date', 'unit', 'hour', 'offered', 'handled', 'aht_sec'], [[date('Y-m-d', strtotime('-1 day')), 'CC1', 9, 120, 110, 290]]);
        if ($kind === 'agents') csv_download('modele-activite-agents.csv', ['date', 'matricule', 'handled', 'aht_sec', 'logged_min'], [[date('Y-m-d', strtotime('-1 day')), 'M0001', 60, 300, 420]]);
        $this->notFound();
    }

    // ---- Paramétrage ----
    function setup(): void {
        $units = Pl::units(); $u = $units[(string)$this->in('unit', '')] ?? reset($units) ?: null;
        $this->view('pl/setup', ['title' => 'Shifts, besoins, objectifs', 'shifts' => Pl::shifts(false), 'units' => $units, 'u' => $u, 'needs' => $u ? Pl::needs($u) : [], 'targets' => $u ? array_column(DB::all('SELECT kpi, value FROM pl_targets WHERE unit_type=? AND unit_id=?', [$u['type'], $u['id']]), 'value', 'kpi') : [], 'defaults' => $u ? Pl::targets(['type' => '-', 'id' => 0]) : []]);
    }
    private function shiftData(): ?array {
        $code = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string)$this->in('code', ''))); $name = mb_substr(trim((string)$this->in('name', '')), 0, 80); $kind = (string)$this->in('kind', 'work'); $col = (string)$this->in('color', '#003A84');
        $a = trim((string)$this->in('start_time', '')); $b = trim((string)$this->in('end_time', '')); $br = (int)$this->in('break_min', 0);
        if ($code === '' || strlen($code) > 20 || $name === '' || !in_array($kind, ['work', 'off'], true) || !preg_match('/^#[0-9A-Fa-f]{6}$/', $col)) return null;
        if ($kind === 'work' && (!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $a) || !preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $b) || $a === $b || $br < 0 || $br > 240)) return null;
        return ['code' => $code, 'name' => $name, 'kind' => $kind, 'color' => $col, 'start_time' => $kind === 'work' ? $a : null, 'end_time' => $kind === 'work' ? $b : null, 'break_min' => $kind === 'work' ? $br : 0, 'active' => $this->in('active') === '1' ? 1 : 0];
    }
    function storeShift(): void {
        $d = $this->shiftData(); if (!$d || DB::val('SELECT 1 FROM pl_shifts WHERE code=?', [$d['code']])) { flash('Shift invalide ou code déjà utilisé (heures HH:MM différentes, pause 0 à 240 min).', 'danger'); redirect('pl/setup'); }
        $id = DB::insert('pl_shifts', $d); Audit::log('create', 'pl_shift', $id); flash('Shift créé.'); redirect('pl/setup');
    }
    function updateShift(string $id): void {
        $s = DB::one('SELECT * FROM pl_shifts WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; } $d = $this->shiftData();
        if (!$d || DB::val('SELECT 1 FROM pl_shifts WHERE code=? AND id<>?', [$d['code'], (int)$id])) { flash('Shift invalide ou code déjà utilisé.', 'danger'); redirect('pl/setup'); }
        DB::update('pl_shifts', $d, 'id=?', [(int)$id]); Audit::log('update', 'pl_shift', $id, $s, $d); flash('Shift modifié : les plannings déjà saisis utilisent les nouveaux horaires.'); redirect('pl/setup');
    }
    function saveNeeds(): void {
        $u = Pl::unit((string)$this->in('unit', '')); if (!$u) { $this->notFound(); return; } $sh = array_filter(Pl::shifts(false), fn($s) => Pl::isWork($s));
        DB::exec('DELETE FROM pl_needs WHERE unit_type=? AND unit_id=?', [$u['type'], $u['id']]);
        foreach ((array)($_POST['n'] ?? []) as $wd => $row) foreach ((array)$row as $sid => $v) { $v = trim((string)$v); if ($v === '' || !ctype_digit($v) || (int)$v > 999 || (int)$v === 0 || !isset($sh[(int)$sid]) || (int)$wd < 1 || (int)$wd > 7) continue; DB::insert('pl_needs', ['unit_type' => $u['type'], 'unit_id' => $u['id'], 'weekday' => (int)$wd, 'shift_id' => (int)$sid, 'required' => (int)$v]); }
        Audit::log('update', 'pl_needs', null, null, ['unit' => $u['key']]); flash('Besoins enregistrés.'); redirect('pl/setup?unit=' . $u['key']);
    }
    function saveTargets(): void {
        $u = Pl::unit((string)$this->in('unit', '')); if (!$u) { $this->notFound(); return; }
        foreach (array_keys(Pl::KPI) as $k) { $v = str_replace(',', '.', trim((string)$this->in($k, ''))); DB::exec('DELETE FROM pl_targets WHERE unit_type=? AND unit_id=? AND kpi=?', [$u['type'], $u['id'], $k]); if ($v !== '' && is_numeric($v) && $v >= 0 && $v <= 100000) DB::insert('pl_targets', ['unit_type' => $u['type'], 'unit_id' => $u['id'], 'kpi' => $k, 'value' => (float)$v]); }
        Audit::log('update', 'pl_targets', null, null, ['unit' => $u['key']]); flash('Objectifs enregistrés (champ vide = objectif par défaut).'); redirect('pl/setup?unit=' . $u['key']);
    }
}
