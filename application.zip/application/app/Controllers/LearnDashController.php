<?php
namespace App\Controllers;

use App\Core\{Audit, Controller, DB, ELearn, LearnDash};

/** Tableau de bord avancé : base de connaissances, cours e-learning et satisfaction. */
final class LearnDashController extends Controller {
    private function f(): array {
        $days = (int)$this->in('days', 90); if (!in_array($days, [30, 90, 180, 365], true)) $days = 90;
        $dom = trim((string)$this->in('domain', '')); $team = (int)$this->in('team', 0) ?: null;
        return [$days, $dom !== '' ? $dom : null, $team];
    }
    function index(): void {
        [$days, $dom, $team] = $this->f(); $tab = (string)$this->in('tab', 'overview'); if (!in_array($tab, ['overview', 'kb', 'el', 'sat'], true)) $tab = 'overview';
        $kb = can('kb.read') ? LearnDash::kb($days) : null; $el = LearnDash::el($days, $dom, $team); $sat = LearnDash::sat($days); unset($el['scope']);
        $this->view('learndash/index', ['title' => 'Pilotage savoir et formation en ligne', 'tab' => $tab, 'days' => $days, 'dom' => $dom, 'team' => $team, 'kb' => $kb, 'el' => $el, 'sat' => $sat,
            'domains' => array_column(DB::all("SELECT DISTINCT domain FROM el_courses WHERE domain IS NOT NULL AND domain<>'' ORDER BY domain"), 'domain'), 'teams' => DB::all('SELECT id, name FROM teams ORDER BY name')]);
    }
    function enrolled(): void {
        $kind = (string)$this->in('kind', 'path'); if (!in_array($kind, ['path', 'domain', 'course'], true)) $kind = 'path'; $key = (string)$this->in('key', '');
        $title = match ($kind) { 'path' => DB::val('SELECT name FROM el_paths WHERE id=?', [(int)$key]), 'course' => DB::val('SELECT title FROM el_courses WHERE id=?', [(int)$key]), default => $key === '' ? 'Sans domaine' : $key };
        if ($title === null || $title === false) { $this->notFound(); return; }
        $rows = LearnDash::enrolled($kind, $key);
        if ($this->in('csv')) { Audit::log('export', 'learn_enrolled', null, null, ['kind' => $kind, 'key' => $key]); csv_download('inscrits.csv', ['Collaborateur', 'Équipe', 'Cours inscrits', 'Réussis', 'En cours', 'Prochaine échéance'], array_map(fn($r) => [$r['name'], $r['team'], $r['courses'], $r['passed'], $r['open_n'], $r['next_due']], $rows)); }
        $this->view('learndash/enrolled', ['title' => 'Inscrits : ' . $title, 'label' => $title, 'kind' => $kind, 'key' => $key, 'rows' => $rows]);
    }
    function export(): void {
        [$days, $dom, $team] = $this->f(); $what = (string)$this->in('what', 'courses'); $el = LearnDash::el($days, $dom, $team);
        Audit::log('export', 'learn_dash', null, null, ['what' => $what, 'days' => $days]);
        if ($what === 'late') csv_download('retards_elearning.csv', ['Collaborateur', 'Cours', 'Échéance', 'Statut'], array_map(fn($r) => [$r['name'], $r['title'], $r['due_date'], ELearn::ES[$r['status']] ?? $r['status']], DB::all("SELECT u.name, c.title, en.due_date, en.status FROM {$el['scope'][0]} AND en.status IN ('assigned','in_progress') AND en.due_date IS NOT NULL AND en.due_date<? ORDER BY en.due_date", array_merge($el['scope'][1], [date('Y-m-d')]))));
        csv_download('cours_elearning.csv', ['Cours', 'Domaine', 'Inscrits', 'Réussis', 'Échecs', 'Taux de réussite %', 'Score moyen %', 'En retard', 'Satisfaction /5'], array_map(fn($c) => [$c['title'], $c['domain'], $c['n'], $c['ok'], $c['ko'], $c['rate'], $c['score'], $c['late'], $c['sat']], $el['courses']));
    }
}
