<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Pk};

/** Planificateur de tâches. */
class PkController extends Controller {
    private function users(): array { return DB::all("SELECT id, name FROM users WHERE status='active' ORDER BY name LIMIT 2000"); }
    private function load(string $id): ?array { $t = DB::one('SELECT * FROM pk_tasks WHERE id=?', [(int)$id]); if (!$t || !Pk::sees($t)) { $this->notFound(); return null; } return $t; }
    private function okDate($v): bool { return is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $v) && strtotime($v) !== false; }
    function index(): void {
        $me = (int)Auth::id(); $view = (string)($_GET['view'] ?? 'mine'); $w = ['t.deleted_at IS NULL']; $p = [];
        if ($view === 'all' && can('pk.all')) { } elseif ($view === 'given') { $w[] = 't.created_by=? AND t.assignee_id<>?'; array_push($p, $me, $me); } else { $view = 'mine'; $w[] = 't.assignee_id=?'; $p[] = $me; }
        $st = (string)($_GET['status'] ?? 'open');
        if ($st === 'open') $w[] = 't.status IN ' . Pk::OPEN; elseif ($st === 'late') { $w[] = 't.status IN ' . Pk::OPEN . ' AND t.due_date<?'; $p[] = date('Y-m-d'); } elseif ($st === 'postponed') $w[] = 't.postponed>0'; elseif (isset(Pk::ST[$st])) { $w[] = 't.status=?'; $p[] = $st; } else $st = 'any';
        if (isset(Pk::PRIO[(string)($_GET['priority'] ?? '')])) { $w[] = 't.priority=?'; $p[] = $_GET['priority']; }
        if ((int)($_GET['assignee'] ?? 0)) { $w[] = 't.assignee_id=?'; $p[] = (int)$_GET['assignee']; }
        if (($q = trim((string)($_GET['q'] ?? ''))) !== '') { $w[] = '(t.title LIKE ? OR t.ref LIKE ? OR t.category LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $from = 'pk_tasks t LEFT JOIN users a ON a.id=t.assignee_id LEFT JOIN users c ON c.id=t.created_by WHERE ' . implode(' AND ', $w);
        if (($_GET['export'] ?? '') === 'csv') csv_download('taches_' . date('Ymd_His') . '.csv', ['Réf.', 'Tâche', 'Catégorie', 'Priorité', 'Destinataire', 'Créée par', 'Échéance', 'Échéance initiale', 'Reports', 'Statut', 'Avancement %', 'Relances', 'Clôturée le'],
            array_map(fn($r) => [$r['ref'], $r['title'], $r['category'], Pk::PRIO[$r['priority']] ?? $r['priority'], $r['assignee'], $r['creator'], $r['due_date'], $r['orig_due'], $r['postponed'], Pk::ST[$r['status']] ?? $r['status'], $r['progress'], $r['reminders'], $r['done_at']], DB::all("SELECT t.*, a.name assignee, c.name creator FROM $from ORDER BY t.due_date, t.id", $p)));
        $cnt = fn(string $c, array $x = []) => (int)DB::val("SELECT COUNT(*) FROM pk_tasks t WHERE t.deleted_at IS NULL AND t.assignee_id=? AND $c", array_merge([$me], $x));
        $this->view('pk/index', ['title' => 'Planificateur de tâches', 'p' => paginate($from, $p, $this->page(), 25, 't.*, a.name assignee, c.name creator', "CASE WHEN t.status IN ('open','in_progress') THEN 0 ELSE 1 END, t.due_date, t.id"), 'view' => $view, 'st' => $st, 'users' => can('pk.all') ? $this->users() : [],
            'sum' => ['open' => $cnt('t.status IN ' . Pk::OPEN), 'late' => $cnt('t.status IN ' . Pk::OPEN . ' AND t.due_date<?', [date('Y-m-d')]), 'week' => $cnt('t.status IN ' . Pk::OPEN . ' AND t.due_date>=? AND t.due_date<=?', [date('Y-m-d'), date('Y-m-d', strtotime('+7 days'))])]]);
    }
    function create(): void { $this->view('pk/form', ['title' => 'Nouvelle tâche', 't' => null, 'users' => can('pk.assign') ? $this->users() : []]); }
    function edit(string $id): void { if (!($t = $this->load($id))) return; if (!Pk::owns($t)) { $this->forbidden(); return; } $this->view('pk/form', ['title' => 'Modifier ' . $t['ref'], 't' => $t, 'users' => []]); }
    private function fields(?array $cur): array {
        $d = ['title' => trim((string)$this->in('title')), 'description' => mb_substr(trim((string)$this->in('description')), 0, 5000) ?: null, 'category' => mb_substr(trim((string)$this->in('category')), 0, 60) ?: null, 'priority' => (string)$this->in('priority', 'normal'), 'start_date' => (string)$this->in('start_date') ?: null, 'due_date' => (string)$this->in('due_date')]; $err = [];
        if ($d['title'] === '' || mb_strlen($d['title']) > 300) $err[] = 'L\'intitulé est obligatoire (300 caractères au plus).';
        if (!isset(Pk::PRIO[$d['priority']])) $d['priority'] = 'normal';
        if (!$this->okDate($d['due_date'])) $err[] = 'L\'échéance est obligatoire.';
        if ($d['start_date'] && !$this->okDate($d['start_date'])) $d['start_date'] = null;
        if ($d['start_date'] && $this->okDate($d['due_date']) && $d['start_date'] > $d['due_date']) $err[] = 'La date de début doit précéder l\'échéance.';
        if ($cur) unset($d['due_date']);   // l'échéance d'une tâche existante ne change que par un report motivé
        return [$d, $err];
    }
    function store(): void {
        [$d, $err] = $this->fields(null); $me = (int)Auth::id(); $ids = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['assignees'] ?? [])))));
        if (!$ids || !can('pk.assign')) $ids = [$me];
        foreach ($ids as $u) if (!DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$u])) $err[] = 'Destinataire inconnu.';
        if (count($ids) > 50) $err[] = '50 destinataires au plus par création.';
        if ($err) { $_SESSION['_old'] = $_POST; flash(implode(' ', array_unique($err)), 'danger'); redirect('pk/new'); }
        $last = 0;
        foreach ($ids as $u) { $last = (int)DB::insert('pk_tasks', $d + ['ref' => Pk::ref(), 'assignee_id' => $u, 'created_by' => $me, 'orig_due' => $d['due_date'], 'status' => 'open', 'progress' => 0, 'postponed' => 0, 'reminders' => 0, 'created_at' => now(), 'updated_at' => now()]);
            Pk::log($last, 'create', 'Tâche créée'); Pk::tell($u, 'Nouvelle tâche : ' . $d['title'], 'Échéance ' . d($d['due_date']) . ' — confiée par ' . (Auth::user()['name'] ?? ''), $last); Audit::log('create', 'pk_task', $last); }
        unset($_SESSION['_old']); flash(count($ids) > 1 ? count($ids) . ' tâches créées, destinataires informés.' : 'Tâche créée.'); redirect(count($ids) > 1 ? 'pk?view=given' : 'pk/' . $last);
    }
    function show(string $id): void {
        if (!($t = $this->load($id))) return;
        $this->view('pk/show', ['title' => $t['ref'], 't' => $t, 'assignee' => DB::val('SELECT name FROM users WHERE id=?', [(int)$t['assignee_id']]), 'creator' => DB::val('SELECT name FROM users WHERE id=?', [(int)$t['created_by']]), 'owns' => Pk::owns($t), 'mine' => (int)$t['assignee_id'] === (int)Auth::id(),
            'log' => DB::all('SELECT l.*, u.name uname FROM pk_log l LEFT JOIN users u ON u.id=l.user_id WHERE l.task_id=? ORDER BY l.id DESC', [(int)$id]), 'users' => Pk::owns($t) ? $this->users() : []]);
    }
    function update(string $id): void {
        if (!($t = $this->load($id))) return; $act = (string)$this->in('act'); $c = trim((string)$this->in('comment')); $me = (int)Auth::id(); $owns = Pk::owns($t); $mine = (int)$t['assignee_id'] === $me; $open = in_array($t['status'], ['open', 'in_progress'], true); $back = 'pk/' . $id;
        $deny = function () { $this->forbidden(); }; $other = $mine ? (int)$t['created_by'] : (int)$t['assignee_id'];
        switch ($act) {
            case 'edit': if (!$owns) { $deny(); return; } [$d, $err] = $this->fields($t); if ($err) { flash(implode(' ', $err), 'danger'); redirect("pk/$id/edit"); }
                DB::update('pk_tasks', $d + ['updated_at' => now()], 'id=?', [(int)$id]); Pk::log((int)$id, 'edit', 'Tâche modifiée'); Pk::tell((int)$t['assignee_id'], 'Tâche modifiée : ' . $t['ref'], $d['title'], (int)$id); flash('Tâche modifiée.'); break;
            case 'progress': if (!$mine && !$owns) { $deny(); return; } if (!$open) { flash('Tâche close.', 'warning'); break; } $pr = max(0, min(100, (int)$this->in('progress')));
                DB::update('pk_tasks', ['progress' => $pr, 'status' => $pr > 0 ? 'in_progress' : 'open', 'updated_at' => now()], 'id=?', [(int)$id]); Pk::log((int)$id, 'progress', $pr . ' %' . ($c !== '' ? ' — ' . $c : '')); flash('Avancement enregistré.'); break;
            case 'postpone': if (!$mine && !$owns) { $deny(); return; } $due = (string)$this->in('due_date');
                if (!$open || !$this->okDate($due) || $due <= $t['due_date'] || $c === '') { flash('Report : nouvelle échéance postérieure à l\'actuelle et motif obligatoires.', 'danger'); break; }
                DB::update('pk_tasks', ['due_date' => $due, 'postponed' => (int)$t['postponed'] + 1, 'postpone_reason' => mb_substr($c, 0, 300), 'reminded_at' => null, 'updated_at' => now()], 'id=?', [(int)$id]); Pk::log((int)$id, 'postpone', d($t['due_date']) . ' → ' . d($due) . ' : ' . $c);
                Pk::tell($other, 'Tâche reportée : ' . $t['ref'], $t['title'] . ' : ' . d($t['due_date']) . ' → ' . d($due) . ' (' . $c . ')', (int)$id); flash('Échéance reportée.'); break;
            case 'assign': if (!$owns) { $deny(); return; } $u = (int)$this->in('assignee_id');
                if (!$open || !$u || $u === (int)$t['assignee_id'] || !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$u])) { flash('Choisissez un autre destinataire actif.', 'danger'); break; }
                if ($u !== $me && !can('pk.assign')) { $deny(); return; } $nm = DB::val('SELECT name FROM users WHERE id=?', [$u]);
                DB::update('pk_tasks', ['assignee_id' => $u, 'reminded_at' => null, 'updated_at' => now()], 'id=?', [(int)$id]); Pk::log((int)$id, 'assign', DB::val('SELECT name FROM users WHERE id=?', [(int)$t['assignee_id']]) . ' → ' . $nm . ($c !== '' ? ' : ' . $c : ''));
                Pk::tell($u, 'Tâche confiée : ' . $t['ref'], $t['title'] . ' — échéance ' . d($t['due_date']), (int)$id); Pk::tell((int)$t['assignee_id'], 'Tâche retirée : ' . $t['ref'], $t['title'] . ' — confiée à ' . $nm, (int)$id); flash('Destinataire modifié.'); break;
            case 'remind': if (!$owns) { $deny(); return; } if (!$open) { flash('Tâche close.', 'warning'); break; } Pk::remind($t, 'remind', $c); flash('Relance envoyée.'); break;
            case 'close': if (!$mine && !$owns) { $deny(); return; } if (!$open) { flash('Tâche déjà close.', 'warning'); break; }
                DB::update('pk_tasks', ['status' => 'done', 'progress' => 100, 'done_at' => now(), 'closed_by' => $me, 'closure_comment' => mb_substr($c, 0, 500) ?: null, 'updated_at' => now()], 'id=?', [(int)$id]); Pk::log((int)$id, 'close', $c ?: 'Tâche clôturée'); Pk::tell($other, 'Tâche clôturée : ' . $t['ref'], $t['title'], (int)$id); flash('Tâche clôturée.'); break;
            case 'reopen': if (!$owns) { $deny(); return; } if ($open) break; DB::update('pk_tasks', ['status' => 'in_progress', 'done_at' => null, 'closed_by' => null, 'updated_at' => now()], 'id=?', [(int)$id]); Pk::log((int)$id, 'reopen', $c ?: 'Tâche rouverte'); Pk::tell((int)$t['assignee_id'], 'Tâche rouverte : ' . $t['ref'], $t['title'], (int)$id); flash('Tâche rouverte.'); break;
            case 'cancel': if (!$owns) { $deny(); return; } if (!$open || $c === '') { flash('Motif d\'annulation obligatoire.', 'danger'); break; }
                DB::update('pk_tasks', ['status' => 'cancelled', 'closed_by' => $me, 'closure_comment' => mb_substr($c, 0, 500), 'updated_at' => now()], 'id=?', [(int)$id]); Pk::log((int)$id, 'cancel', $c); Pk::tell((int)$t['assignee_id'], 'Tâche annulée : ' . $t['ref'], $t['title'] . ' (' . $c . ')', (int)$id); flash('Tâche annulée.'); break;
            case 'comment': if ($c === '') { flash('Commentaire vide.', 'danger'); break; } Pk::log((int)$id, 'comment', $c); Pk::tell($other, 'Commentaire sur ' . $t['ref'], $c, (int)$id); flash('Commentaire ajouté.'); break;
            case 'delete': if (!$owns) { $deny(); return; } DB::update('pk_tasks', ['deleted_at' => now(), 'updated_at' => now()], 'id=?', [(int)$id]); Pk::log((int)$id, 'delete', $c ?: 'Tâche supprimée'); Pk::tell((int)$t['assignee_id'], 'Tâche supprimée : ' . $t['ref'], $t['title'], (int)$id); Audit::log('delete', 'pk_task', $id, ['title' => $t['title']]); flash('Tâche supprimée.'); redirect('pk');
            default: flash('Opération inconnue.', 'danger');
        }
        Audit::log('update', 'pk_task', $id, null, ['act' => $act]); redirect($back);
    }
    function dashboard(): void {
        [$sc, $p] = Pk::scope('t'); $days = in_array((int)($_GET['days'] ?? 90), [30, 90, 180, 365], true) ? (int)($_GET['days'] ?? 90) : 90; $since = date('Y-m-d', strtotime("-$days days")); $today = date('Y-m-d'); $w = [$sc];
        if ((int)($_GET['assignee'] ?? 0)) { $w[] = 't.assignee_id=?'; $p[] = (int)$_GET['assignee']; }
        $base = 'pk_tasks t LEFT JOIN users a ON a.id=t.assignee_id WHERE ' . implode(' AND ', $w); $v = fn(string $c, array $x = []) => (int)DB::val("SELECT COUNT(*) FROM $base AND $c", array_merge($p, $x));
        $done = $v("t.status='done' AND t.done_at>=?", [$since . ' 00:00:00']); $onTime = $v("t.status='done' AND t.done_at>=? AND substr(t.done_at,1,10)<=t.due_date", [$since . ' 00:00:00']);
        $K = ['open' => $v('t.status IN ' . Pk::OPEN), 'late' => $v('t.status IN ' . Pk::OPEN . ' AND t.due_date<?', [$today]), 'week' => $v('t.status IN ' . Pk::OPEN . ' AND t.due_date>=? AND t.due_date<=?', [$today, date('Y-m-d', strtotime('+7 days'))]), 'done' => $done, 'onTime' => $done ? round($onTime / $done * 100) : null,
            'postponed' => $v('t.postponed>0 AND t.created_at>=?', [$since . ' 00:00:00']), 'postponedOpen' => $v('t.postponed>0 AND t.status IN ' . Pk::OPEN), 'cancelled' => $v("t.status='cancelled' AND t.updated_at>=?", [$since . ' 00:00:00']), 'created' => $v('t.created_at>=?', [$since . ' 00:00:00'])];
        $by = []; foreach (DB::all("SELECT a.name, SUM(CASE WHEN t.status IN " . Pk::OPEN . " AND t.due_date<? THEN 1 ELSE 0 END) late, SUM(CASE WHEN t.status IN " . Pk::OPEN . " AND t.due_date>=? THEN 1 ELSE 0 END) ok, SUM(CASE WHEN t.status='done' AND t.done_at>=? THEN 1 ELSE 0 END) done FROM $base GROUP BY a.name ORDER BY late DESC, ok DESC LIMIT 15", array_merge([$today, $today, $since . ' 00:00:00'], $p)) as $r) if ($r['late'] + $r['ok'] + $r['done'] > 0) $by[] = $r;
        $weeks = []; for ($i = 11; $i >= 0; $i--) { $weeks[date('Y-m-d', strtotime('monday this week -' . $i . ' weeks'))] = [0, 0]; }
        foreach (DB::all("SELECT t.created_at, t.done_at, t.status FROM $base AND (t.created_at>=? OR t.done_at>=?)", array_merge($p, [array_key_first($weeks) . ' 00:00:00', array_key_first($weeks) . ' 00:00:00'])) as $r) {
            $k = date('Y-m-d', strtotime('monday this week', strtotime((string)$r['created_at']))); if (isset($weeks[$k])) $weeks[$k][0]++;
            if ($r['status'] === 'done' && $r['done_at']) { $k = date('Y-m-d', strtotime('monday this week', strtotime((string)$r['done_at']))); if (isset($weeks[$k])) $weeks[$k][1]++; } }
        $cols = 't.*, a.name assignee';
        $this->view('pk/dashboard', ['title' => 'Tableau de bord des tâches', 'K' => $K, 'days' => $days, 'by' => $by, 'weeks' => $weeks, 'users' => can('pk.all') ? $this->users() : [],
            'st' => array_column(DB::all("SELECT t.status s, COUNT(*) n FROM $base GROUP BY t.status", $p), 'n', 's'),
            'late' => DB::all("SELECT $cols FROM $base AND t.status IN " . Pk::OPEN . ' AND t.due_date<? ORDER BY t.due_date LIMIT 40', array_merge($p, [$today])),
            'post' => DB::all("SELECT $cols FROM $base AND t.postponed>0 ORDER BY t.updated_at DESC LIMIT 25", $p),
            'closed' => DB::all("SELECT $cols FROM $base AND t.status='done' AND t.done_at>=? ORDER BY t.done_at DESC LIMIT 25", array_merge($p, [$since . ' 00:00:00']))]);
    }
}
