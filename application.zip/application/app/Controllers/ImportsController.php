<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Importer, Notifier, Auth};
class ImportsController extends Controller {
    private function allowed(): array { return array_filter(Importer::DOMAINS, fn($d) => can($d['perm'])); }
    function index(): void {
        if ($this->in('cancel') && !empty($_SESSION['_import'])) { @unlink(ROOT . '/storage/imports/' . $_SESSION['_import']['token'] . '.json'); unset($_SESSION['_import']); redirect('imports'); }
        $jobs = DB::all('SELECT j.*, u.name user_name FROM import_jobs j LEFT JOIN users u ON u.id=j.user_id ORDER BY j.id DESC LIMIT 15');
        $this->view('imports/index', ['title' => 'Imports', 'domains' => $this->allowed(), 'jobs' => $jobs, 'preview' => $_SESSION['_import'] ?? null]);
    }
    function downloadTemplate(string $domain): void {
        $d = Importer::DOMAINS[$domain] ?? null; if (!$d || !isset($this->allowed()[$domain])) { $this->notFound(); return; }
        csv_download("modele_$domain.csv", $d['cols'], [$d['sample']]);
    }
    function importPreview(): void {
        $domain = (string)$this->in('domain');
        if (!isset($this->allowed()[$domain])) { $this->forbidden(); return; }
        $f = $_FILES['file'] ?? null;
        if (!$f || $f['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) { flash('Choisissez un fichier CSV.', 'danger'); redirect('imports'); }
        if ($f['size'] > 5 * 1024 * 1024) { flash('Fichier trop volumineux (5 Mo maximum).', 'danger'); redirect('imports'); }
        [$head, $rows] = Importer::parse($f['tmp_name']);
        $missing = array_diff(Importer::DOMAINS[$domain]['cols'], $head);
        if ($missing && count($missing) === count(Importer::DOMAINS[$domain]['cols'])) { flash('Aucune colonne reconnue. Téléchargez le modèle et conservez ses en-têtes.', 'danger'); redirect('imports'); }
        $token = bin2hex(random_bytes(8)); $out = [];
        foreach ($rows as $r) { [$n, $err] = Importer::check($domain, $r['data']); $out[] = ['line' => $r['line'], 'data' => $n, 'error' => $err]; }
        file_put_contents(ROOT . "/storage/imports/$token.json", json_encode(['domain' => $domain, 'name' => $f['name'], 'rows' => $out], JSON_UNESCAPED_UNICODE));
        $_SESSION['_import'] = ['token' => $token, 'domain' => $domain, 'name' => $f['name'], 'rows' => $out, 'ok' => count(array_filter($out, fn($x) => !$x['error'])), 'ko' => count(array_filter($out, fn($x) => $x['error']))];
        redirect('imports');
    }
    function commit(): void {
        $p = $_SESSION['_import'] ?? null; $token = (string)$this->in('token');
        if (!$p || $p['token'] !== $token) { flash('Aucun import à valider.', 'danger'); redirect('imports'); }
        $domain = $p['domain']; if (!isset($this->allowed()[$domain])) { $this->forbidden(); return; }
        $job = DB::insert('import_jobs', ['domain' => $domain, 'filename' => $p['name'], 'status' => 'running', 'total_rows' => count($p['rows']), 'user_id' => Auth::id(), 'created_at' => now()]);
        $ok = 0; $ko = 0;
        foreach ($p['rows'] as $r) {
            try {
                if ($r['error']) { $ko++; DB::insert('import_rows', ['job_id' => $job, 'line_no' => $r['line'], 'status' => 'rejected', 'message' => $r['error'], 'data_json' => json_encode($r['data'], JSON_UNESCAPED_UNICODE)]); continue; }
                $msg = Importer::save($domain, $r['data']); $ok++;
                DB::insert('import_rows', ['job_id' => $job, 'line_no' => $r['line'], 'status' => 'ok', 'message' => $msg, 'data_json' => json_encode($r['data'], JSON_UNESCAPED_UNICODE)]);
            } catch (\Throwable $e) { $ko++; DB::insert('import_rows', ['job_id' => $job, 'line_no' => $r['line'], 'status' => 'rejected', 'message' => 'Erreur : ' . substr($e->getMessage(), 0, 200)]); }
        }
        DB::update('import_jobs', ['status' => 'done', 'ok_rows' => $ok, 'error_rows' => $ko, 'finished_at' => now()], 'id=?', [$job]);
        Audit::log('import', $domain, $job, null, ['file' => $p['name'], 'ok' => $ok, 'rejected' => $ko]);
        Notifier::send(Auth::id(), 'Import terminé : ' . Importer::DOMAINS[$domain]['label'], "$ok ligne(s) intégrée(s), $ko rejetée(s).", "/imports/$job");
        @unlink(ROOT . "/storage/imports/$token.json"); unset($_SESSION['_import']);
        flash("Import terminé : $ok ligne(s) intégrée(s), $ko rejetée(s).", $ko ? 'warning' : 'success');
        redirect('imports/' . $job);
    }
    function show(string $id): void {
        $j = DB::one('SELECT j.*, u.name user_name FROM import_jobs j LEFT JOIN users u ON u.id=j.user_id WHERE j.id=?', [(int)$id]); if (!$j) { $this->notFound(); return; }
        $this->view('imports/show', ['title' => 'Import n° ' . $id, 'j' => $j, 'rows' => DB::all('SELECT * FROM import_rows WHERE job_id=? ORDER BY line_no LIMIT 500', [(int)$id])]);
    }
}
