<?php
namespace App\Controllers;
use App\Core\{DB, Pl, Cap, Audit};
/** Flux horaires, scénarios d'hypothèses et capacitaire (besoins en effectifs). */
class CapController extends PlController {
    // ---- Flux ----
    function flows(): void {
        $units = $this->myUnits(); $u = $this->pickUnit($units); $grid = []; $days = []; $max = 0; $from = date('Y-m-d', strtotime('-56 days'));
        if ($u) {
            foreach (DB::all('SELECT day, hour, offered, handled FROM pl_flows WHERE unit_type=? AND unit_id=? AND day>=? AND day<?', [$u['type'], $u['id'], $from, date('Y-m-d')]) as $r) { $n = (int)date('N', strtotime($r['day'])); $days[$n][$r['day']] = 1; $grid[$n][(int)$r['hour']][] = (int)$r['offered']; }
            foreach ($grid as $n => $hs) foreach ($hs as $h => $v) { $grid[$n][$h] = array_sum($v) / max(1, count($days[$n])); $max = max($max, $grid[$n][$h]); }
        }
        $this->view('pl/flows', ['title' => 'Flux et profils horaires', 'units' => $units, 'u' => $u, 'grid' => $grid, 'max' => $max, 'days' => $days, 'hist' => $u ? Cap::history($u) : null]);
    }
    function importFlows(): void {
        if (($rows = $this->csvRows()) === null) redirect('pl/data'); $head = array_map(fn($h) => strtolower(trim($h)), array_shift($rows)); $need = ['date', 'unit', 'hour', 'offered', 'handled', 'aht_sec'];
        if (array_diff($need, $head)) { flash('Colonnes attendues : ' . implode(';', $need), 'danger'); redirect('pl/data'); }
        $byCode = []; foreach (Pl::units() as $u) $byCode[strtolower($u['code'])][] = $u; $ok = 0; $err = [];
        foreach ($rows as $i => $r) {
            if (count(array_filter($r, 'strlen')) === 0) continue; $r = array_combine($head, array_pad(array_slice($r, 0, count($head)), count($head), '')); $ln = $i + 2; $d = self::ymd((string)$r['date']); $us = $byCode[strtolower(trim($r['unit']))] ?? []; $n = [];
            foreach (['hour', 'offered', 'handled', 'aht_sec'] as $k) { $v = trim((string)$r[$k]); if (!ctype_digit($v) || strlen($v) > 9) { $n = null; break; } $n[$k] = (int)$v; }
            if (!$d) $err[] = "ligne $ln : date invalide"; elseif (count($us) !== 1) $err[] = "ligne $ln : unité « {$r['unit']} » " . ($us ? 'ambiguë' : 'inconnue'); elseif ($n === null || $n['hour'] > 23) $err[] = "ligne $ln : nombre ou heure (0 à 23) invalide"; elseif ($n['handled'] > $n['offered']) $err[] = "ligne $ln : traités supérieurs aux reçus";
            else { $u = $us[0]; $x = DB::val('SELECT id FROM pl_flows WHERE day=? AND unit_type=? AND unit_id=? AND hour=?', [$d, $u['type'], $u['id'], $n['hour']]); $row = ['offered' => $n['offered'], 'handled' => $n['handled'], 'aht_sec' => $n['aht_sec'], 'source' => 'csv']; if ($x) DB::update('pl_flows', $row, 'id=?', [(int)$x]); else DB::insert('pl_flows', $row + ['day' => $d, 'unit_type' => $u['type'], 'unit_id' => $u['id'], 'hour' => $n['hour'], 'created_at' => now()]); $ok++; }
        }
        Audit::log('import', 'pl_flows', null, null, ['ok' => $ok, 'errors' => count($err)]); flash("$ok ligne(s) de flux importée(s)." . ($err ? ' ' . count($err) . ' refusée(s) : ' . implode(' ; ', array_slice($err, 0, 8)) . (count($err) > 8 ? '…' : '') : ''), $err ? 'warning' : 'success'); redirect('pl/data');
    }

    // ---- Scénarios ----
    function scenarios(): void { $this->view('pl/scenarios', ['title' => 'Hypothèses et scénarios', 'list' => DB::all("SELECT * FROM pl_scenarios ORDER BY status='archived', is_base DESC, id")]); }
    private function sc(string $id, bool $editable = false): ?array {
        $s = Cap::scenario((int)$id); if (!$s) { $this->notFound(); return null; }
        if ($editable && $s['status'] !== 'draft') { flash('Scénario ' . ($s['status'] === 'validated' ? 'validé' : 'archivé') . ' : verrouillé. Dupliquez-le pour tester d\'autres hypothèses.', 'warning'); redirect('pl/scenarios/' . $s['id']); return null; }
        return $s;
    }
    function createScenario(): void {
        $n = mb_substr(trim((string)$this->in('name', '')), 0, 120); if ($n === '') { flash('Donnez un nom au scénario.', 'danger'); redirect('pl/scenarios'); }
        $id = DB::insert('pl_scenarios', ['name' => $n, 'description' => mb_substr(trim((string)$this->in('description', '')), 0, 1000) ?: null, 'status' => 'draft', 'horizon_weeks' => 12, 'is_base' => 0, 'created_by' => \App\Core\Auth::id(), 'created_at' => now(), 'updated_at' => now()]);
        Audit::log('create', 'pl_scenario', $id); redirect('pl/scenarios/' . $id);
    }
    function copyScenario(string $id): void {
        if (!($s = $this->sc($id))) return; $new = DB::insert('pl_scenarios', ['name' => mb_substr('Copie de ' . $s['name'], 0, 120), 'description' => $s['description'], 'status' => 'draft', 'horizon_weeks' => $s['horizon_weeks'], 'is_base' => 0, 'created_by' => \App\Core\Auth::id(), 'created_at' => now(), 'updated_at' => now()]);
        foreach (DB::all('SELECT * FROM pl_hypotheses WHERE scenario_id=?', [$s['id']]) as $h) DB::insert('pl_hypotheses', ['scenario_id' => $new, 'unit_type' => $h['unit_type'], 'unit_id' => $h['unit_id'], 'hkey' => $h['hkey'], 'value' => $h['value']]);
        foreach (Cap::events($s['id']) as $e) DB::insert('pl_events', ['scenario_id' => $new, 'unit_type' => $e['unit_type'], 'unit_id' => $e['unit_id'], 'label' => $e['label'], 'date_from' => $e['date_from'], 'date_to' => $e['date_to'], 'uplift_pct' => $e['uplift_pct']]);
        Audit::log('copy', 'pl_scenario', $new, null, ['from' => $s['id']]); flash('Scénario dupliqué.'); redirect('pl/scenarios/' . $new);
    }
    function statusScenario(string $id): void {
        if (!($s = $this->sc($id))) return; $to = (string)$this->in('to', ''); if (!in_array($to, ['draft', 'validated', 'archived'], true) || ($s['is_base'] && $to !== 'validated')) { flash('Changement impossible (le scénario de référence reste validé).', 'danger'); redirect('pl/scenarios/' . $s['id']); }
        DB::update('pl_scenarios', ['status' => $to, 'updated_at' => now()], 'id=?', [$s['id']]); Audit::log('status', 'pl_scenario', $id, ['status' => $s['status']], ['status' => $to]); flash('Statut du scénario mis à jour.'); redirect('pl/scenarios/' . $s['id']);
    }
    function deleteScenario(string $id): void {
        if (!($s = $this->sc($id))) return; if ($s['is_base']) { flash('Le scénario de référence ne se supprime pas.', 'danger'); redirect('pl/scenarios'); }
        foreach (['pl_hypotheses', 'pl_events'] as $t) DB::exec("DELETE FROM $t WHERE scenario_id=?", [$s['id']]); DB::exec('DELETE FROM pl_scenarios WHERE id=?', [$s['id']]); Audit::log('delete', 'pl_scenario', $id, $s); flash('Scénario supprimé.'); redirect('pl/scenarios');
    }
    function scenario(string $id): void {
        if (!($s = $this->sc($id))) return; $units = $this->myUnits(); $rows = [];
        foreach ($units as $k => $u) { if (!Cap::headcount($u)) continue; $c = Cap::compute($s['id'], $u); $sm = Cap::summary($c); if ($sm['avg'] === null && !$c['warn']) continue; $rows[] = ['u' => $u, 'ch' => Cap::channelOf($u), 'c' => $c, 's' => $sm]; }
        usort($rows, fn($a, $b) => [$a['ch'], $a['u']['name']] <=> [$b['ch'], $b['u']['name']]);
        $this->view('pl/scenario', ['title' => $s['name'], 's' => $s, 'g' => Cap::globalValues($s['id']), 'ov' => Cap::unitOverrides($s['id']), 'ev' => Cap::events($s['id']), 'units' => Pl::units(), 'rows' => $rows]);
    }
    function saveScenario(string $id): void {
        if (!($s = $this->sc($id, true))) return; $name = mb_substr(trim((string)$this->in('name', '')), 0, 120); $hz = (int)$this->in('horizon_weeks', 12); if ($name === '' || $hz < 1 || $hz > 52) { flash('Nom requis ; horizon de 1 à 52 semaines.', 'danger'); redirect('pl/scenarios/' . $s['id']); }
        $vals = [];
        foreach (Cap::HYP as $k => $m) { $v = str_replace(',', '.', trim((string)$this->in('h_' . $k, ''))); if ($v === '') continue; if (!is_numeric($v) || $v < $m[3] || $v > $m[4]) { flash($m[0] . ' : valeur entre ' . $m[3] . ' et ' . $m[4] . ' attendue.', 'danger'); redirect('pl/scenarios/' . $s['id']); } $vals[$k] = (float)$v; }
        DB::exec("DELETE FROM pl_hypotheses WHERE scenario_id=? AND (unit_type IS NULL OR unit_type='')", [$s['id']]); foreach ($vals as $k => $v) DB::insert('pl_hypotheses', ['scenario_id' => $s['id'], 'hkey' => $k, 'value' => $v]);
        DB::update('pl_scenarios', ['name' => $name, 'description' => mb_substr(trim((string)$this->in('description', '')), 0, 1000) ?: null, 'horizon_weeks' => $hz, 'updated_at' => now()], 'id=?', [$s['id']]);
        Audit::log('update', 'pl_scenario', $id, null, $vals); flash('Hypothèses enregistrées.'); redirect('pl/scenarios/' . $s['id']);
    }
    function addOverride(string $id): void {
        if (!($s = $this->sc($id, true))) return; $u = Pl::unit((string)$this->in('unit', '')); $k = (string)$this->in('hkey', ''); $v = str_replace(',', '.', trim((string)$this->in('value', '')));
        if (!$u || !isset(Cap::HYP[$k]) || !is_numeric($v) || $v < Cap::HYP[$k][3] || $v > Cap::HYP[$k][4]) { flash('Surcharge invalide (unité, hypothèse et valeur dans les bornes).', 'danger'); redirect('pl/scenarios/' . $s['id']); }
        DB::exec('DELETE FROM pl_hypotheses WHERE scenario_id=? AND unit_type=? AND unit_id=? AND hkey=?', [$s['id'], $u['type'], $u['id'], $k]); DB::insert('pl_hypotheses', ['scenario_id' => $s['id'], 'unit_type' => $u['type'], 'unit_id' => $u['id'], 'hkey' => $k, 'value' => (float)$v]);
        Audit::log('update', 'pl_scenario', $id, null, ['override' => $u['key'] . ':' . $k]); flash('Surcharge enregistrée.'); redirect('pl/scenarios/' . $s['id']);
    }
    function delOverride(string $id, string $hid): void { if (!($s = $this->sc($id, true))) return; DB::exec('DELETE FROM pl_hypotheses WHERE id=? AND scenario_id=?', [(int)$hid, $s['id']]); redirect('pl/scenarios/' . $s['id']); }
    function addEvent(string $id): void {
        if (!($s = $this->sc($id, true))) return; $label = mb_substr(trim((string)$this->in('label', '')), 0, 120); $a = (string)$this->in('date_from', ''); $b = (string)$this->in('date_to', ''); $up = str_replace(',', '.', trim((string)$this->in('uplift_pct', ''))); $ukey = (string)$this->in('unit', ''); $u = $ukey === '' ? null : Pl::unit($ukey);
        if ($label === '' || !Pl::validDate($a) || !Pl::validDate($b) || $b < $a || !is_numeric($up) || $up < -90 || $up > 500 || ($ukey !== '' && !$u)) { flash('Événement invalide (libellé, dates cohérentes, variation de -90 à 500 %).', 'danger'); redirect('pl/scenarios/' . $s['id']); }
        DB::insert('pl_events', ['scenario_id' => $s['id'], 'unit_type' => $u['type'] ?? null, 'unit_id' => $u['id'] ?? null, 'label' => $label, 'date_from' => $a, 'date_to' => $b, 'uplift_pct' => (float)$up]); Audit::log('update', 'pl_scenario', $id, null, ['event' => $label]); flash('Événement ajouté.'); redirect('pl/scenarios/' . $s['id']);
    }
    function delEvent(string $id, string $eid): void { if (!($s = $this->sc($id, true))) return; DB::exec('DELETE FROM pl_events WHERE id=? AND scenario_id=?', [(int)$eid, $s['id']]); redirect('pl/scenarios/' . $s['id']); }

    // ---- Capacitaire ----
    private function capData(): array {
        $units = $this->myUnits(); $all = Cap::scenarios(); $sel = array_values(array_filter(array_map('intval', (array)$this->in('scen', [])), fn($i) => $i > 0)); $byId = array_column($all, null, 'id'); $sel = array_values(array_filter($sel, fn($i) => isset($byId[$i])));
        if (!$sel) { $sel = array_slice(array_column($all, 'id'), 0, 3); } $sel = array_slice($sel, 0, 4); $key = (string)$this->in('unit', 'all'); $u = $units[$key] ?? null; $res = [];
        foreach ($sel as $sid) {
            if ($u) { $res[$sid] = ['units' => [['u' => $u, 'c' => Cap::compute($sid, $u)]]]; continue; }
            $list = []; foreach ($units as $x) { if (!Cap::headcount($x)) continue; $c = Cap::compute($sid, $x); if (Cap::summary($c)['avg'] === null) continue; $list[] = ['u' => $x, 'c' => $c]; } $res[$sid] = ['units' => $list];
        }
        return [$units, $all, $sel, $u, $res];
    }
    function capacity(): void { [$units, $all, $sel, $u, $res] = $this->capData(); $this->view('pl/capacity', ['title' => 'Capacitaire', 'units' => $units, 'all' => $all, 'sel' => $sel, 'u' => $u, 'res' => $res]); }
    function exportCapacity(): void {
        [, $all, $sel, $u, $res] = $this->capData(); $byId = array_column($all, null, 'id'); $out = [];
        foreach ($res as $sid => $r) foreach ($r['units'] as $x) foreach ($x['c']['weeks'] as $w) $out[] = [$byId[$sid]['name'], Cap::channelOf($x['u']), $x['u']['name'], $w['week'], $w['volume'] ?? '', $w['hours'] ?? '', $w['peak'], $w['fte'] === null ? '' : str_replace('.', ',', $w['fte']), $x['c']['hc'], $w['gap'] === null ? '' : str_replace('.', ',', $w['gap'])];
        Audit::log('export', 'pl_capacity'); csv_download('capacitaire-' . date('Ymd') . '.csv', ['Scénario', 'Canal', 'Unité', 'Semaine du', 'Volume', 'Heures nettes', 'Pic d\'agents', 'ETP requis', 'Effectif actuel', 'Écart'], $out);
    }
}
