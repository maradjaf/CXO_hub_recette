<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Ca, Cx};
class CxController extends Controller {
    private function ids(string $perm): array { return array_map('intval', array_column(Ca::usersWith($perm), 'id')); }
    private function date(string $k, ?string $d = null): ?string { $v = (string)$this->in($k, ''); return preg_match('/^\d{4}-\d{2}-\d{2}$/', $v) ? $v : $d; }

    // =============== Grilles Mystery Customer ===============
    function grids(): void { $this->view('cx/grids', ['title' => 'Grilles Mystery Customer', 'rows' => DB::all('SELECT g.*, (SELECT COUNT(*) FROM mc_criteria c WHERE c.grid_id=g.id) nc, (SELECT COUNT(*) FROM mc_visits v WHERE v.grid_id=g.id) nv FROM mc_grids g ORDER BY g.status, g.name')]); }
    private function gridData(): array {
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'description' => ['label' => 'La description', 'max' => 500]], $_POST);
        $pass = (int)$this->in('pass_pct', 80); if ($pass < 1 || $pass > 100) $err['p'] = 'Le seuil doit être compris entre 1 et 100 %.';
        return [$d + ['pass_pct' => $pass, 'updated_at' => now()], $err];
    }
    function storeGrid(): void {
        [$d, $err] = $this->gridData(); $code = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string)$this->in('code', ''))); $ch = (string)$this->in('channel');
        if ($code === '' || strlen($code) > 40) $err['c'] = 'Code obligatoire.'; elseif (DB::val('SELECT 1 FROM mc_grids WHERE code=?', [$code])) $err['c2'] = 'Ce code existe déjà.';
        if (!isset(Cx::CH[$ch])) $err['ch'] = 'Canal invalide.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('cx/grids'); }
        $id = DB::insert('mc_grids', $d + ['code' => $code, 'channel' => $ch, 'status' => 'draft', 'created_by' => Auth::id(), 'created_at' => now()]); Audit::log('create', 'mc_grid', $id); flash('Grille créée en brouillon.'); redirect("cx/grids/$id");
    }
    private function grid(string $id): ?array { $g = DB::one('SELECT * FROM mc_grids WHERE id=?', [(int)$id]); if (!$g) $this->notFound(); return $g; }
    private function needDraft(array $g, string $back): void { if ($g['status'] !== 'draft') { flash('Une grille active ne se modifie pas : dupliquez-la.', 'warning'); redirect($back); } }
    function showGrid(string $id): void { if (!($g = $this->grid($id))) return; $this->view('cx/grid', ['title' => $g['name'], 'g' => $g, 'items' => DB::all('SELECT * FROM mc_criteria WHERE grid_id=? ORDER BY position, id', [(int)$id])]); }
    function updateGrid(string $id): void {
        if (!($g = $this->grid($id))) return; $this->needDraft($g, "cx/grids/$id"); [$d, $err] = $this->gridData(); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("cx/grids/$id"); }
        DB::update('mc_grids', $d, 'id=?', [(int)$id]); flash('Grille enregistrée.'); redirect("cx/grids/$id");
    }
    private function critData(): array {
        [$d, $err] = $this->validate(['label' => ['label' => 'Le critère', 'req' => true, 'max' => 300], 'section' => ['label' => 'La section', 'max' => 100], 'guidance' => ['label' => 'La consigne', 'max' => 500]], $_POST);
        $w = (int)$this->in('weight', 1); if ($w < 1 || $w > 5) $err['w'] = 'Le poids doit être compris entre 1 et 5.';
        return [$d + ['weight' => $w, 'critical' => $this->in('critical') === '1' ? 1 : 0, 'comment_required' => $this->in('comment_required') === '1' ? 1 : 0], $err];
    }
    function storeCrit(string $id): void {
        if (!($g = $this->grid($id))) return; $this->needDraft($g, "cx/grids/$id"); [$d, $err] = $this->critData(); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("cx/grids/$id"); }
        DB::insert('mc_criteria', $d + ['grid_id' => (int)$id, 'position' => (int)DB::val('SELECT COALESCE(MAX(position),0) FROM mc_criteria WHERE grid_id=?', [(int)$id]) + 1]); flash('Critère ajouté.'); redirect("cx/grids/$id");
    }
    function updateCrit(string $id, string $cid): void {
        if (!($g = $this->grid($id))) return; $this->needDraft($g, "cx/grids/$id"); $c = DB::one('SELECT * FROM mc_criteria WHERE id=? AND grid_id=?', [(int)$cid, (int)$id]); if (!$c) { $this->notFound(); return; }
        [$d, $err] = $this->critData(); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("cx/grids/$id"); }
        $pos = (int)$this->in('position', $c['position']); if ($pos < 1 || $pos > 999) $pos = (int)$c['position']; DB::update('mc_criteria', $d + ['position' => $pos], 'id=?', [(int)$cid]); flash('Critère enregistré.'); redirect("cx/grids/$id");
    }
    function deleteCrit(string $id, string $cid): void { if (!($g = $this->grid($id))) return; $this->needDraft($g, "cx/grids/$id"); DB::exec('DELETE FROM mc_criteria WHERE id=? AND grid_id=?', [(int)$cid, (int)$id]); flash('Critère supprimé.'); redirect("cx/grids/$id"); }
    function gridStatus(string $id): void {
        if (!($g = $this->grid($id))) return; $a = (string)$this->in('action');
        if ($a === 'publish' && $g['status'] === 'draft') {
            if (!DB::val('SELECT 1 FROM mc_criteria WHERE grid_id=?', [(int)$id])) { flash('Ajoutez au moins un critère.', 'danger'); redirect("cx/grids/$id"); }
            DB::update('mc_grids', ['status' => 'active', 'updated_at' => now()], 'id=?', [(int)$id]); $m = 'Grille activée.';
        } elseif ($a === 'archive' && $g['status'] === 'active') { DB::update('mc_grids', ['status' => 'archived'], 'id=?', [(int)$id]); $m = 'Grille archivée.'; }
        elseif ($a === 'copy' && $g['status'] !== 'draft') {
            $n = 2; while (DB::val('SELECT 1 FROM mc_grids WHERE code=?', [$g['code'] . '-V' . $n])) $n++;
            $nid = DB::insert('mc_grids', ['code' => $g['code'] . '-V' . $n, 'name' => $g['name'], 'description' => $g['description'], 'channel' => $g['channel'], 'pass_pct' => $g['pass_pct'], 'status' => 'draft', 'created_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()]);
            foreach (DB::all('SELECT * FROM mc_criteria WHERE grid_id=? ORDER BY position, id', [(int)$id]) as $c) DB::insert('mc_criteria', ['grid_id' => $nid, 'position' => $c['position'], 'section' => $c['section'], 'label' => $c['label'], 'guidance' => $c['guidance'], 'weight' => $c['weight'], 'critical' => $c['critical'], 'comment_required' => $c['comment_required']]);
            flash('Copie créée en brouillon.'); redirect("cx/grids/$nid");
        } else { flash('Action impossible.', 'danger'); redirect("cx/grids/$id"); }
        Audit::log($a, 'mc_grid', $id); flash($m); redirect("cx/grids/$id");
    }

    // =============== Visites mystère ===============
    private function vform(): array { return ['grids' => DB::all("SELECT id, name, channel FROM mc_grids WHERE status='active' ORDER BY name"), 'stores' => DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name'), 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'), 'shoppers' => Ca::usersWith('cx.run')]; }
    function newVisit(): void { $this->view('cx/visit_new', ['title' => 'Planifier une visite mystère'] + $this->vform()); }
    function storeVisit(): void {
        $g = DB::one("SELECT * FROM mc_grids WHERE id=? AND status='active'", [(int)$this->in('grid_id')]); if (!$g) { flash('Choisissez une grille active.', 'danger'); redirect('cx/visits/new'); }
        $store = $g['channel'] === 'store' ? (int)$this->in('store_id', 0) : 0; $team = $g['channel'] === 'call' ? (int)$this->in('team_id', 0) : 0;
        $shopper = (int)$this->in('shopper_id', 0); $label = mb_substr(trim((string)$this->in('shopper_label', '')), 0, 150);
        $bad = ($g['channel'] === 'store' && !DB::val('SELECT 1 FROM stores WHERE id=?', [$store])) || ($g['channel'] === 'call' && !DB::val('SELECT 1 FROM teams WHERE id=?', [$team])) || !in_array($shopper, $this->ids('cx.run'), true);
        if ($bad) { flash('Périmètre contrôlé et client mystère (autorisé à réaliser des visites) obligatoires.', 'danger'); redirect('cx/visits/new'); }
        $id = DB::insert('mc_visits', ['reference' => Ca::ref('MYS', 'mc_visits'), 'grid_id' => (int)$g['id'], 'store_id' => $store ?: null, 'team_id' => $team ?: null, 'shopper_id' => $shopper, 'shopper_label' => $label ?: null, 'planned_date' => $this->date('planned_date', date('Y-m-d')), 'status' => 'planned', 'created_by' => Auth::id(), 'created_at' => now()]);
        Notifier::send($shopper, 'Visite mystère à réaliser', (string)DB::val('SELECT reference FROM mc_visits WHERE id=?', [$id]), '/cx/visits/' . $id); Audit::log('create', 'mc_visit', $id); flash('Visite planifiée.'); redirect("cx/visits/$id");
    }
    function visits(): void {
        [$w, $p] = Cx::scope('v'); $w = [$w];
        foreach (['status' => 'v.status', 'result' => 'v.result', 'grid_id' => 'v.grid_id', 'store_id' => 'v.store_id'] as $k => $col) if ($this->in($k) !== null && $this->in($k) !== '') { $w[] = "$col=?"; $p[] = $this->in($k); }
        $from = 'mc_visits v JOIN mc_grids g ON g.id=v.grid_id LEFT JOIN stores s ON s.id=v.store_id LEFT JOIN teams t ON t.id=v.team_id WHERE ' . implode(' AND ', $w);
        if ($this->in('export') === 'csv') {
            $rows = DB::all("SELECT v.reference, g.name grid, s.name store, t.name team, v.visit_at, v.status, v.score_pct, v.result, v.wait_minutes FROM $from ORDER BY v.id DESC", $p); Audit::log('export', 'mc_visits', null, null, ['rows' => count($rows)]);
            csv_download('visites_mystere.csv', ['Référence', 'Grille', 'Store', 'Équipe', 'Visite', 'Statut', 'Score %', 'Résultat', 'Attente (min)'], array_map(fn($r) => [$r['reference'], $r['grid'], $r['store'], $r['team'], $r['visit_at'], Cx::VS[$r['status']] ?? '', $r['score_pct'], Cx::RES[$r['result']] ?? '', $r['wait_minutes']], $rows));
        }
        $this->view('cx/visits', ['title' => 'Visites mystère', 'p' => paginate($from, $p, $this->page(), 25, 'v.*, g.name grid, g.channel, s.name store, t.name team', 'v.id DESC'), 'grids' => DB::all('SELECT id, name FROM mc_grids ORDER BY name'), 'stores' => DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name')]);
    }
    function mine(): void {
        $this->view('cx/mine', ['title' => 'Mes missions', 'visits' => DB::all("SELECT v.*, g.name grid FROM mc_visits v JOIN mc_grids g ON g.id=v.grid_id WHERE v.shopper_id=? AND v.status IN ('planned','in_progress','rejected') ORDER BY v.planned_date", [Auth::id()]),
            'runs' => DB::all("SELECT r.*, j.name journey FROM jr_runs r JOIN jr_journeys j ON j.id=r.journey_id WHERE r.tester_id=? AND r.status IN ('planned','in_progress') ORDER BY r.planned_date", [Auth::id()]), 'journeys' => DB::all("SELECT id, name FROM jr_journeys WHERE status='active' ORDER BY name")]);
    }
    private function visit(string $id): ?array {
        $v = DB::one('SELECT v.*, g.name grid, g.pass_pct, g.channel FROM mc_visits v JOIN mc_grids g ON g.id=v.grid_id WHERE v.id=?', [(int)$id]);
        if (!$v) { $this->notFound(); return null; } if (!Cx::canSee($v)) { $this->forbidden(); return null; } return $v;
    }
    private function canRunVisit(array $v): bool { return in_array($v['status'], ['planned', 'in_progress', 'rejected'], true) && (int)$v['shopper_id'] === Auth::id(); }
    function showVisit(string $id): void {
        if (!($v = $this->visit($id))) return;
        $files = []; foreach (DB::all('SELECT * FROM mc_files WHERE visit_id=? ORDER BY id', [(int)$id]) as $f) $files[(int)$f['criterion_id']][] = $f;
        $this->view('cx/visit', ['title' => $v['reference'], 'v' => $v, 'subject' => Cx::subject($v), 'shopper' => Cx::shopperName($v), 'run' => $this->canRunVisit($v), 'files' => $files, 'owners' => Ca::usersWith('cx.act'),
            'items' => DB::all('SELECT c.*, a.answer, a.comment acomment FROM mc_criteria c LEFT JOIN mc_answers a ON a.criterion_id=c.id AND a.visit_id=? WHERE c.grid_id=? ORDER BY c.position, c.id', [(int)$id, (int)$v['grid_id']]),
            'actions' => DB::all('SELECT a.*, u.name owner FROM cx_actions a LEFT JOIN users u ON u.id=a.owner_id WHERE a.visit_id=? ORDER BY a.id', [(int)$id])]);
    }
    const EV = ['png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'pdf' => 'application/pdf'];
    private static function dir(): string { $d = ROOT . '/storage/uploads/cx'; if (!is_dir($d)) @mkdir($d, 0775, true); return $d; }
    private function takeEvidence(int $vid, int $cid): array {
        $f = $_FILES["ev_$cid"] ?? null; $err = []; if (!$f || !is_array($f['name'])) return [];
        $have = (int)DB::val('SELECT COUNT(*) FROM mc_files WHERE visit_id=? AND criterion_id=?', [$vid, $cid]);
        foreach ($f['name'] as $k => $name) {
            if (($f['error'][$k] ?? 4) === UPLOAD_ERR_NO_FILE) continue; if ($f['error'][$k] !== UPLOAD_ERR_OK) { $err[] = "« $name » non reçu."; continue; }
            if ($have >= 5) { $err[] = '5 preuves maximum par critère.'; break; }
            $n = trim(preg_replace('#[\x00-\x1f\\\\/]+#', '_', (string)$name)); $ext = strtolower(pathinfo($n, PATHINFO_EXTENSION));
            if (!isset(self::EV[$ext]) || $f['size'][$k] > 5 * 1024 * 1024) { $err[] = "« $n » refusé (png, jpg ou pdf, 5 Mo maximum)."; continue; }
            $mime = function_exists('mime_content_type') ? (string)@mime_content_type($f['tmp_name'][$k]) : ''; if ($mime !== '' && $mime !== self::EV[$ext]) { $err[] = "« $n » : contenu non conforme à l'extension."; continue; }
            $st = bin2hex(random_bytes(16)) . '.' . $ext; if (!@move_uploaded_file($f['tmp_name'][$k], self::dir() . '/' . $st)) { $err[] = "« $n » non enregistré."; continue; }
            DB::insert('mc_files', ['visit_id' => $vid, 'criterion_id' => $cid, 'user_id' => Auth::id(), 'original_name' => mb_substr($n, 0, 190), 'stored_name' => $st, 'mime' => self::EV[$ext], 'size' => (int)$f['size'][$k], 'created_at' => now()]); $have++;
        }
        return $err;
    }
    function file(string $fid): void {
        $f = DB::one('SELECT * FROM mc_files WHERE id=?', [(int)$fid]); if (!$f) { $this->notFound(); return; }
        $v = DB::one('SELECT * FROM mc_visits WHERE id=?', [(int)$f['visit_id']]); if (!$v || !Cx::canSee($v)) { $this->forbidden(); return; }
        $path = self::dir() . '/' . $f['stored_name']; if (!is_file($path)) { $this->notFound(); return; } Audit::log('download', 'mc_file', $fid);
        header('Content-Type: ' . $f['mime']); header('X-Content-Type-Options: nosniff'); header("Content-Security-Policy: sandbox; default-src 'none'; img-src 'self'; style-src 'unsafe-inline'"); header('Content-Length: ' . filesize($path));
        header('Content-Disposition: inline; filename="' . rawurlencode($f['original_name']) . '"; filename*=UTF-8\'\'' . rawurlencode($f['original_name'])); readfile($path); exit;
    }
    function saveVisit(string $id): void {
        if (!($v = $this->visit($id))) return; if (!$this->canRunVisit($v)) { $this->forbidden(); return; }
        $items = DB::all('SELECT * FROM mc_criteria WHERE grid_id=? ORDER BY position, id', [(int)$v['grid_id']]); $evErr = [];
        foreach ($items as $c) {
            $a = $_POST['a'][$c['id']] ?? ''; $cm = mb_substr(trim((string)($_POST['c'][$c['id']] ?? '')), 0, 500);
            if (isset(Cx::ANS[$a])) { $old = DB::val('SELECT id FROM mc_answers WHERE visit_id=? AND criterion_id=?', [(int)$id, (int)$c['id']]); $row = ['answer' => $a, 'comment' => $cm !== '' ? $cm : null];
                if ($old) DB::update('mc_answers', $row, 'id=?', [(int)$old]); else DB::insert('mc_answers', $row + ['visit_id' => (int)$id, 'criterion_id' => (int)$c['id']]); }
            $evErr = array_merge($evErr, $this->takeEvidence((int)$id, (int)$c['id']));
        }
        $wait = trim((string)$this->in('wait_minutes', '')); $wait = ctype_digit($wait) && (int)$wait <= 600 ? (int)$wait : null; $at = (string)$this->in('visit_at', ''); $at = preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $at) ? str_replace('T', ' ', $at) . ':00' : ($v['visit_at'] ?: null);
        $com = mb_substr(trim((string)$this->in('comment', '')), 0, 2000);
        DB::update('mc_visits', ['status' => 'in_progress', 'wait_minutes' => $wait, 'visit_at' => $at, 'comment' => $com !== '' ? $com : null], 'id=?', [(int)$id]);
        if ($this->in('finish') !== '1') { flash('Saisie enregistrée.' . ($evErr ? ' ' . implode(' ', $evErr) : ''), $evErr ? 'warning' : 'success'); redirect("cx/visits/$id"); }
        $res = DB::all('SELECT a.*, c.comment_required, c.label FROM mc_answers a JOIN mc_criteria c ON c.id=a.criterion_id WHERE a.visit_id=?', [(int)$id]); $err = [];
        if (count($res) < count($items)) $err[] = (count($items) - count($res)) . ' critère(s) sans réponse.';
        foreach ($res as $r) if ($r['answer'] === 'ko' && $r['comment_required'] && trim((string)$r['comment']) === '') $err[] = 'Commentaire obligatoire : « ' . mb_substr($r['label'], 0, 60) . ' ».';
        if (!$at) $err[] = 'Date et heure de la visite obligatoires.';
        if ($err) { flash('Envoi impossible : ' . implode(' ', $err), 'danger'); redirect("cx/visits/$id"); }
        [$score, $result] = Cx::computeVisit((int)$id, (int)$v['pass_pct']);
        DB::update('mc_visits', ['status' => 'submitted', 'submitted_at' => now(), 'score_pct' => $score, 'result' => $result], 'id=?', [(int)$id]);
        Notifier::toPermission('cx.manage', 'Visite mystère à valider', $v['reference'] . ' · ' . Cx::subject($v), '/cx/visits/' . $id); Audit::log('submit', 'mc_visit', $id, null, ['score' => $score, 'result' => $result]);
        flash('Visite transmise à la qualité pour validation.'); redirect("cx/visits/$id");
    }
    function validateVisit(string $id): void {
        if (!($v = $this->visit($id))) return; if ($v['status'] !== 'submitted') { flash('Cette visite n\'est pas en attente de validation.', 'danger'); redirect("cx/visits/$id"); }
        $note = mb_substr(trim((string)$this->in('note', '')), 0, 500); $act = (string)$this->in('action');
        if ($act === 'reject') {
            if ($note === '') { flash('Indiquez ce qui doit être repris.', 'danger'); redirect("cx/visits/$id"); }
            DB::update('mc_visits', ['status' => 'rejected', 'validation_comment' => $note], 'id=?', [(int)$id]); Notifier::send((int)$v['shopper_id'], 'Visite mystère à reprendre', $v['reference'] . ' : ' . mb_substr($note, 0, 100), '/cx/visits/' . $id); Audit::log('reject', 'mc_visit', $id); flash('Visite renvoyée au client mystère.'); redirect("cx/visits/$id");
        }
        $ko = DB::all("SELECT a.*, c.label, c.critical, c.section FROM mc_answers a JOIN mc_criteria c ON c.id=a.criterion_id WHERE a.visit_id=? AND a.answer='ko'", [(int)$id]); $owner = (int)$this->in('owner_id', 0);
        if ($ko && !in_array($owner, $this->ids('cx.act'), true)) { flash('Désignez le responsable des actions d\'amélioration.', 'danger'); redirect("cx/visits/$id"); }
        DB::update('mc_visits', ['status' => 'validated', 'validated_by' => Auth::id(), 'validated_at' => now(), 'validation_comment' => $note !== '' ? $note : null], 'id=?', [(int)$id]);
        foreach ($ko as $r) Cx::newAction(['source' => 'mc', 'visit_id' => (int)$id, 'title' => mb_substr('Corriger : ' . $r['label'], 0, 300), 'description' => mb_substr(trim(($r['section'] ? $r['section'] . ' · ' : '') . Cx::subject($v) . ($r['comment'] ? ' — ' . $r['comment'] : '')), 0, 1000), 'priority' => $r['critical'] ? 'critical' : 'normal', 'owner_id' => $owner, 'due_date' => date('Y-m-d', strtotime('+' . Cx::dueDays($r['critical'] ? 'critical' : 'normal') . ' days'))]);
        if ($v['result'] === 'critical') Notifier::toPermission('cx.report', 'Écart critique en visite mystère', $v['reference'] . ' · ' . Cx::subject($v), '/cx/visits/' . $id);
        Audit::log('validate', 'mc_visit', $id, null, ['actions' => count($ko)]); flash('Visite validée' . ($ko ? ' · ' . count($ko) . ' action(s) créée(s).' : '.')); redirect("cx/visits/$id");
    }
    function cancelVisit(string $id): void {
        if (!($v = $this->visit($id))) return; if (!in_array($v['status'], ['planned', 'in_progress', 'rejected', 'submitted'], true)) { flash('Annulation impossible.', 'danger'); redirect("cx/visits/$id"); }
        DB::update('mc_visits', ['status' => 'cancelled'], 'id=?', [(int)$id]); Audit::log('cancel', 'mc_visit', $id); flash('Visite annulée.'); redirect("cx/visits/$id");
    }

    // =============== Parcours client ===============
    function journeys(): void { $this->view('cx/journeys', ['title' => 'Parcours client', 'rows' => DB::all("SELECT j.*, (SELECT COUNT(*) FROM jr_steps s WHERE s.journey_id=j.id) ns, (SELECT COUNT(*) FROM jr_runs r WHERE r.journey_id=j.id AND r.status='completed') nr, (SELECT r2.result FROM jr_runs r2 WHERE r2.journey_id=j.id AND r2.status='completed' ORDER BY r2.completed_at DESC, r2.id DESC LIMIT 1) last_result FROM jr_journeys j ORDER BY j.status, j.name")]); }
    function storeJourney(): void {
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'description' => ['label' => 'La description', 'max' => 500]], $_POST); $code = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string)$this->in('code', ''))); $ch = (string)$this->in('channel');
        if ($code === '' || strlen($code) > 40) $err['c'] = 'Code obligatoire.'; elseif (DB::val('SELECT 1 FROM jr_journeys WHERE code=?', [$code])) $err['c2'] = 'Ce code existe déjà.'; if (!isset(Cx::CH_J[$ch])) $err['ch'] = 'Canal invalide.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('cx/journeys'); }
        $id = DB::insert('jr_journeys', $d + ['code' => $code, 'channel' => $ch, 'status' => 'draft', 'frequency' => 'none', 'created_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()]); Audit::log('create', 'jr_journey', $id); flash('Parcours créé en brouillon : ajoutez les étapes.'); redirect("cx/journeys/$id");
    }
    private function journey(string $id): ?array { $j = DB::one('SELECT * FROM jr_journeys WHERE id=?', [(int)$id]); if (!$j) $this->notFound(); return $j; }
    function showJourney(string $id): void {
        if (!($j = $this->journey($id))) return;
        $this->view('cx/journey', ['title' => $j['name'], 'j' => $j, 'steps' => DB::all('SELECT * FROM jr_steps WHERE journey_id=? ORDER BY position, id', [(int)$id]), 'testers' => Ca::usersWith('cx.run'),
            'runs' => DB::all("SELECT r.*, u.name tester FROM jr_runs r LEFT JOIN users u ON u.id=r.tester_id WHERE r.journey_id=? ORDER BY r.id DESC LIMIT 10", [(int)$id])]);
    }
    function updateJourney(string $id): void {
        if (!($j = $this->journey($id))) return; [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'description' => ['label' => 'La description', 'max' => 500]], $_POST);
        $freq = (string)$this->in('frequency', 'none'); $tester = (int)$this->in('tester_id', 0); $next = $this->date('next_date');
        if (!isset(Cx::FREQ[$freq])) $err['f'] = 'Fréquence invalide.'; if ($freq !== 'none' && (!in_array($tester, $this->ids('cx.run'), true) || !$next)) $err['t'] = 'Un test récurrent exige un testeur autorisé et une première date.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("cx/journeys/$id"); }
        $u = $d + ['frequency' => $freq, 'tester_id' => $tester ?: null, 'next_date' => $freq === 'none' ? null : $next, 'updated_at' => now()];
        if ($j['status'] !== 'draft') unset($u['name'], $u['description']); DB::update('jr_journeys', $u, 'id=?', [(int)$id]); Audit::log('update', 'jr_journey', $id); flash('Parcours enregistré.'); redirect("cx/journeys/$id");
    }
    private function stepData(): array {
        [$d, $err] = $this->validate(['label' => ['label' => 'L\'étape', 'req' => true, 'max' => 300], 'expected' => ['label' => 'Le résultat attendu', 'max' => 500]], $_POST);
        $max = trim((string)$this->in('max_seconds', '')); if ($max !== '' && (!ctype_digit($max) || (int)$max > 86400)) $err['m'] = 'Durée maximale invalide (secondes).';
        return [$d + ['max_seconds' => $max === '' ? null : (int)$max], $err];
    }
    function storeStep(string $id): void {
        if (!($j = $this->journey($id))) return; $this->needDraftJ($j); [$d, $err] = $this->stepData(); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("cx/journeys/$id"); }
        DB::insert('jr_steps', $d + ['journey_id' => (int)$id, 'position' => (int)DB::val('SELECT COALESCE(MAX(position),0) FROM jr_steps WHERE journey_id=?', [(int)$id]) + 1]); flash('Étape ajoutée.'); redirect("cx/journeys/$id");
    }
    private function needDraftJ(array $j): void { if ($j['status'] !== 'draft') { flash('Un parcours actif ne se modifie pas (l\'historique des tests s\'y réfère) : dupliquez-le.', 'warning'); redirect('cx/journeys/' . $j['id']); } }
    function updateStep(string $id, string $sid): void {
        if (!($j = $this->journey($id))) return; $this->needDraftJ($j); $s = DB::one('SELECT * FROM jr_steps WHERE id=? AND journey_id=?', [(int)$sid, (int)$id]); if (!$s) { $this->notFound(); return; }
        [$d, $err] = $this->stepData(); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("cx/journeys/$id"); } $pos = (int)$this->in('position', $s['position']); if ($pos < 1 || $pos > 999) $pos = (int)$s['position'];
        DB::update('jr_steps', $d + ['position' => $pos], 'id=?', [(int)$sid]); flash('Étape enregistrée.'); redirect("cx/journeys/$id");
    }
    function deleteStep(string $id, string $sid): void { if (!($j = $this->journey($id))) return; $this->needDraftJ($j); DB::exec('DELETE FROM jr_steps WHERE id=? AND journey_id=?', [(int)$sid, (int)$id]); flash('Étape supprimée.'); redirect("cx/journeys/$id"); }
    function journeyStatus(string $id): void {
        if (!($j = $this->journey($id))) return; $a = (string)$this->in('action');
        if ($a === 'publish' && $j['status'] === 'draft') { if (!DB::val('SELECT 1 FROM jr_steps WHERE journey_id=?', [(int)$id])) { flash('Ajoutez au moins une étape.', 'danger'); redirect("cx/journeys/$id"); } DB::update('jr_journeys', ['status' => 'active', 'updated_at' => now()], 'id=?', [(int)$id]); $m = 'Parcours activé.'; }
        elseif ($a === 'archive' && $j['status'] === 'active') { DB::update('jr_journeys', ['status' => 'archived', 'frequency' => 'none', 'next_date' => null], 'id=?', [(int)$id]); $m = 'Parcours archivé.'; }
        elseif ($a === 'copy' && $j['status'] !== 'draft') {
            $n = 2; while (DB::val('SELECT 1 FROM jr_journeys WHERE code=?', [$j['code'] . '-V' . $n])) $n++;
            $nid = DB::insert('jr_journeys', ['code' => $j['code'] . '-V' . $n, 'name' => $j['name'], 'description' => $j['description'], 'channel' => $j['channel'], 'status' => 'draft', 'frequency' => 'none', 'created_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()]);
            foreach (DB::all('SELECT * FROM jr_steps WHERE journey_id=? ORDER BY position, id', [(int)$id]) as $s) DB::insert('jr_steps', ['journey_id' => $nid, 'position' => $s['position'], 'label' => $s['label'], 'expected' => $s['expected'], 'max_seconds' => $s['max_seconds']]);
            flash('Copie créée en brouillon.'); redirect("cx/journeys/$nid");
        } else { flash('Action impossible.', 'danger'); redirect("cx/journeys/$id"); }
        Audit::log($a, 'jr_journey', $id); flash($m); redirect("cx/journeys/$id");
    }

    // =============== Exécutions de parcours ===============
    function startRun(): void {
        $j = DB::one("SELECT * FROM jr_journeys WHERE id=? AND status='active'", [(int)$this->in('journey_id')]); if (!$j) { flash('Choisissez un parcours actif.', 'danger'); redirect('cx/mine'); }
        $tester = Auth::id(); if (can('cx.manage') && ($x = (int)$this->in('tester_id', 0))) { if (!in_array($x, $this->ids('cx.run'), true)) { flash('Ce testeur n\'est pas autorisé.', 'danger'); redirect('cx/mine'); } $tester = $x; }
        $id = DB::insert('jr_runs', ['reference' => Ca::ref('PAR', 'jr_runs'), 'journey_id' => (int)$j['id'], 'tester_id' => $tester, 'planned_date' => date('Y-m-d'), 'status' => 'planned', 'created_by' => Auth::id(), 'created_at' => now()]);
        if ($tester !== Auth::id()) Notifier::send($tester, 'Test de parcours à réaliser', $j['name'], '/cx/runs/' . $id); redirect("cx/runs/$id");
    }
    function runs(): void {
        if (!can('cx.run') && !can('cx.view')) { $this->forbidden(); return; }
        $w = ['1=1']; $p = [];
        if (!can('cx.manage')) { $w = ['r.tester_id=?']; $p = [Auth::id()]; if (can('cx.view')) $w = ["(r.tester_id=? OR r.status='completed')"]; }
        foreach (['journey_id' => 'r.journey_id', 'result' => 'r.result', 'status' => 'r.status'] as $k => $col) if ($this->in($k) !== null && $this->in($k) !== '') { $w[] = "$col=?"; $p[] = $this->in($k); }
        $from = 'jr_runs r JOIN jr_journeys j ON j.id=r.journey_id LEFT JOIN users u ON u.id=r.tester_id WHERE ' . implode(' AND ', $w);
        if ($this->in('export') === 'csv') {
            $rows = DB::all("SELECT r.reference, j.name journey, u.name tester, r.completed_at, r.status, r.result, r.total_seconds FROM $from ORDER BY r.id DESC", $p); Audit::log('export', 'jr_runs', null, null, ['rows' => count($rows)]);
            csv_download('tests_parcours.csv', ['Référence', 'Parcours', 'Testeur', 'Terminé le', 'Statut', 'Résultat', 'Durée (s)'], array_map(fn($r) => [$r['reference'], $r['journey'], $r['tester'], $r['completed_at'], Cx::RS[$r['status']] ?? '', Cx::JRES[$r['result']] ?? '', $r['total_seconds']], $rows));
        }
        $this->view('cx/runs', ['title' => 'Tests de parcours', 'p' => paginate($from, $p, $this->page(), 25, 'r.*, j.name journey, u.name tester', 'r.id DESC'), 'journeys' => DB::all('SELECT id, name FROM jr_journeys ORDER BY name')]);
    }
    private function run(string $id): ?array {
        $r = DB::one('SELECT r.*, j.name journey, j.channel FROM jr_runs r JOIN jr_journeys j ON j.id=r.journey_id WHERE r.id=?', [(int)$id]); if (!$r) { $this->notFound(); return null; }
        $ok = (int)$r['tester_id'] === Auth::id() || can('cx.manage') || (can('cx.view') && $r['status'] === 'completed'); if (!$ok) { $this->forbidden(); return null; } return $r;
    }
    private function canRun(array $r): bool { return in_array($r['status'], ['planned', 'in_progress'], true) && ((int)$r['tester_id'] === Auth::id() || can('cx.manage')); }
    function showRun(string $id): void {
        if (!($r = $this->run($id))) return;
        $this->view('cx/run', ['title' => $r['reference'], 'r' => $r, 'run' => $this->canRun($r), 'owners' => Ca::usersWith('cx.act'), 'testerName' => DB::val('SELECT name FROM users WHERE id=?', [(int)$r['tester_id']]),
            'steps' => DB::all('SELECT s.*, x.status rstatus, x.seconds, x.comment rcomment FROM jr_steps s LEFT JOIN jr_results x ON x.step_id=s.id AND x.run_id=? WHERE s.journey_id=? ORDER BY s.position, s.id', [(int)$id, (int)$r['journey_id']]),
            'actions' => DB::all('SELECT a.*, u.name owner FROM cx_actions a LEFT JOIN users u ON u.id=a.owner_id WHERE a.run_id=? ORDER BY a.id', [(int)$id])]);
    }
    function saveRun(string $id): void {
        if (!($r = $this->run($id))) return; if (!$this->canRun($r)) { $this->forbidden(); return; }
        $steps = DB::all('SELECT * FROM jr_steps WHERE journey_id=? ORDER BY position, id', [(int)$r['journey_id']]);
        foreach ($steps as $s) {
            $st = $_POST['s'][$s['id']] ?? ''; if (!isset(Cx::STEP[$st])) continue; $sec = trim((string)($_POST['t'][$s['id']] ?? '')); $sec = ctype_digit($sec) && (int)$sec <= 86400 ? (int)$sec : null; $cm = mb_substr(trim((string)($_POST['c'][$s['id']] ?? '')), 0, 500);
            $old = DB::val('SELECT id FROM jr_results WHERE run_id=? AND step_id=?', [(int)$id, (int)$s['id']]); $row = ['status' => $st, 'seconds' => $sec, 'comment' => $cm !== '' ? $cm : null];
            if ($old) DB::update('jr_results', $row, 'id=?', [(int)$old]); else DB::insert('jr_results', $row + ['run_id' => (int)$id, 'step_id' => (int)$s['id']]);
        }
        $env = mb_substr(trim((string)$this->in('environment', '')), 0, 150); $com = mb_substr(trim((string)$this->in('comment', '')), 0, 2000);
        DB::update('jr_runs', ['status' => 'in_progress', 'environment' => $env ?: null, 'comment' => $com ?: null], 'id=?', [(int)$id]);
        if ($this->in('finish') !== '1') { flash('Saisie enregistrée.'); redirect("cx/runs/$id"); }
        $res = DB::all('SELECT x.*, s.label FROM jr_results x JOIN jr_steps s ON s.id=x.step_id WHERE x.run_id=?', [(int)$id]); $err = [];
        if (count($res) < count($steps)) $err[] = (count($steps) - count($res)) . ' étape(s) sans statut.';
        $bad = array_filter($res, fn($x) => in_array($x['status'], ['fail', 'blocked'], true)); foreach ($bad as $x) if (trim((string)$x['comment']) === '') $err[] = 'Décrivez l\'anomalie : « ' . mb_substr($x['label'], 0, 60) . ' ».';
        $owner = (int)$this->in('owner_id', 0); if ($bad && !in_array($owner, $this->ids('cx.act'), true)) $err[] = 'Désignez le responsable des actions.';
        if ($err) { flash('Clôture impossible : ' . implode(' ', $err), 'danger'); redirect("cx/runs/$id"); }
        [$result, $total] = Cx::computeRun((int)$id); DB::update('jr_runs', ['status' => 'completed', 'completed_at' => now(), 'result' => $result, 'total_seconds' => $total], 'id=?', [(int)$id]);
        foreach ($bad as $x) Cx::newAction(['source' => 'jr', 'run_id' => (int)$id, 'title' => mb_substr('Parcours ' . $r['journey'] . ' — ' . $x['label'], 0, 300), 'description' => mb_substr((string)$x['comment'], 0, 1000), 'priority' => $x['status'] === 'blocked' ? 'critical' : 'high', 'owner_id' => $owner, 'due_date' => date('Y-m-d', strtotime('+' . Cx::dueDays($x['status'] === 'blocked' ? 'critical' : 'normal') . ' days'))]);
        if ($result === 'failed') Notifier::toPermission('cx.manage', 'Parcours client en échec', $r['reference'] . ' · ' . $r['journey'], '/cx/runs/' . $id);
        Audit::log('complete', 'jr_run', $id, null, ['result' => $result, 'actions' => count($bad)]); flash('Test terminé : ' . Cx::JRES[$result] . (count($bad) ? ' · ' . count($bad) . ' action(s) créée(s).' : '.')); redirect("cx/runs/$id");
    }
    function cancelRun(string $id): void { if (!($r = $this->run($id))) return; if (!$this->canRun($r)) { $this->forbidden(); return; } DB::update('jr_runs', ['status' => 'cancelled'], 'id=?', [(int)$id]); Audit::log('cancel', 'jr_run', $id); flash('Test annulé.'); redirect("cx/runs/$id"); }

    // =============== Actions d'amélioration ===============
    function actions(): void {
        $w = []; $p = []; if (!can('cx.manage') && !can('cx.view')) { $w[] = 'a.owner_id=?'; $p[] = Auth::id(); } elseif (!can('cx.manage')) { [$sw, $sp] = Cx::scope('v'); $w[] = "(a.owner_id=? OR a.visit_id IS NULL OR ($sw))"; $p = array_merge($p, [Auth::id()], $sp); }
        if ($this->in('mine') === '1') { $w[] = 'a.owner_id=?'; $p[] = Auth::id(); }
        foreach (['status' => 'a.status', 'source' => 'a.source', 'owner_id' => 'a.owner_id'] as $k => $col) if ($this->in($k) !== null && $this->in($k) !== '') { $w[] = "$col=?"; $p[] = $this->in($k); }
        if ($this->in('late') === '1') { $w[] = "a.status IN ('open','in_progress') AND a.due_date<?"; $p[] = date('Y-m-d'); }
        $from = 'cx_actions a LEFT JOIN mc_visits v ON v.id=a.visit_id LEFT JOIN users u ON u.id=a.owner_id' . ($w ? ' WHERE ' . implode(' AND ', $w) : ' WHERE 1=1');
        if ($this->in('export') === 'csv') {
            $rows = DB::all("SELECT a.reference, a.source, a.title, a.priority, u.name owner, a.due_date, a.status, a.done_at, a.verified_at FROM $from ORDER BY a.id DESC", $p); Audit::log('export', 'cx_actions', null, null, ['rows' => count($rows)]);
            csv_download('actions_amelioration.csv', ['Référence', 'Origine', 'Action', 'Priorité', 'Responsable', 'Échéance', 'Statut', 'Réalisée le', 'Vérifiée le'], array_map(fn($r) => [$r['reference'], $r['source'] === 'mc' ? 'Mystery Customer' : 'Parcours', $r['title'], $r['priority'], $r['owner'], $r['due_date'], Cx::AS[$r['status']] ?? '', $r['done_at'], $r['verified_at']], $rows));
        }
        $this->view('cx/actions', ['title' => 'Actions d\'amélioration', 'p' => paginate($from, $p, $this->page(), 25, 'a.*, u.name owner', "CASE a.status WHEN 'open' THEN 0 WHEN 'in_progress' THEN 1 WHEN 'done' THEN 2 ELSE 3 END, a.due_date"), 'owners' => Ca::usersWith('cx.act')]);
    }
    private function action(string $id): ?array {
        $a = DB::one('SELECT a.*, u.name owner FROM cx_actions a LEFT JOIN users u ON u.id=a.owner_id WHERE a.id=?', [(int)$id]); if (!$a) { $this->notFound(); return null; }
        $ok = (int)$a['owner_id'] === Auth::id() || can('cx.manage'); if (!$ok && can('cx.view')) { if ($a['visit_id']) { $v = DB::one('SELECT * FROM mc_visits WHERE id=?', [(int)$a['visit_id']]); $ok = $v && Cx::canSee($v); } else $ok = true; }
        if (!$ok) { $this->forbidden(); return null; } return $a;
    }
    function showAction(string $id): void { if (!($a = $this->action($id))) return; $this->view('cx/action', ['title' => $a['reference'], 'a' => $a, 'owner' => (int)$a['owner_id'] === Auth::id(), 'verify' => can('cx.manage'), 'owners' => Ca::usersWith('cx.act')]); }
    function updateAction(string $id): void {
        if (!($a = $this->action($id))) return; $act = (string)$this->in('action'); $owner = (int)$a['owner_id'] === Auth::id(); $ver = can('cx.manage'); $note = trim((string)$this->in('note', '')); $u = []; $m = '';
        if ($act === 'start' && $owner && $a['status'] === 'open') { $u['status'] = 'in_progress'; $m = 'Action démarrée.'; }
        elseif ($act === 'done' && $owner && in_array($a['status'], ['open', 'in_progress'], true)) {
            if ($note === '') { flash('Décrivez ce qui a été fait.', 'danger'); redirect("cx/actions/$id"); }
            $u = ['status' => 'done', 'done_at' => now(), 'done_note' => mb_substr($note, 0, 1000)]; $m = 'Action déclarée réalisée : en attente de vérification.'; Notifier::toPermission('cx.manage', 'Action à vérifier', $a['reference'] . ' · ' . $a['title'], '/cx/actions/' . $id);
        } elseif ($act === 'verify' && $ver && $a['status'] === 'done' && !$owner) { $u = ['status' => 'verified', 'verified_by' => Auth::id(), 'verified_at' => now(), 'verify_note' => $note !== '' ? mb_substr($note, 0, 500) : null]; $m = 'Efficacité vérifiée : action clôturée.'; }
        elseif ($act === 'reopen' && $ver && in_array($a['status'], ['done', 'verified'], true)) {
            if ($note === '') { flash('Indiquez pourquoi l\'action est rouverte.', 'danger'); redirect("cx/actions/$id"); }
            $u = ['status' => 'in_progress', 'verify_note' => mb_substr($note, 0, 500), 'verified_by' => null, 'verified_at' => null, 'done_at' => null]; $m = 'Action rouverte.'; if ($a['owner_id']) Notifier::send((int)$a['owner_id'], 'Action rouverte', $a['reference'] . ' : ' . mb_substr($note, 0, 100), '/cx/actions/' . $id);
        } elseif ($act === 'cancel' && $ver && in_array($a['status'], Cx::OPEN_ACT, true)) { $u['status'] = 'cancelled'; $m = 'Action annulée.'; }
        elseif ($act === 'assign' && $ver && in_array($a['status'], Cx::OPEN_ACT, true)) {
            $o = (int)$this->in('owner_id', 0); $due = $this->date('due_date'); if (!in_array($o, $this->ids('cx.act'), true) || !$due) { flash('Responsable ou échéance invalide.', 'danger'); redirect("cx/actions/$id"); }
            $u = ['owner_id' => $o, 'due_date' => $due, 'reminded_at' => null]; $m = 'Responsable et échéance mis à jour.'; if ($o !== (int)$a['owner_id']) Notifier::send($o, 'Action d\'amélioration à traiter', $a['reference'] . ' · ' . $a['title'], '/cx/actions/' . $id);
        } else { $this->forbidden(); return; }
        DB::update('cx_actions', $u, 'id=?', [(int)$id]); Audit::log($act, 'cx_action', $id, ['status' => $a['status']], $u); flash($m); redirect("cx/actions/$id");
    }

    // =============== Tableau de bord ===============
    function dashboard(): void {
        $from = $this->date('from', date('Y-m-d', strtotime('-90 days'))); $to = $this->date('to', date('Y-m-d')); $lo = $from . ' 00:00:00'; $hi = date('Y-m-d', strtotime($to . ' +1 day')) . ' 00:00:00';
        $mw = "v.status='validated' AND v.validated_at>=? AND v.validated_at<?"; $mp = [$lo, $hi];
        if ($ch = (string)$this->in('channel')) { if (isset(Cx::CH[$ch])) { $mw .= ' AND g.channel=?'; $mp[] = $ch; } else $ch = ''; }
        $mf = 'mc_visits v JOIN mc_grids g ON g.id=v.grid_id';
        $mc = DB::one("SELECT COUNT(*) n, AVG(v.score_pct) avg, AVG(v.wait_minutes) wait, SUM(CASE WHEN v.result='critical' THEN 1 ELSE 0 END) crit FROM $mf WHERE $mw", $mp);
        $bySubject = DB::all("SELECT COALESCE(s.name, t.name, 'Canal digital') subject, COUNT(*) n, AVG(v.score_pct) avg, AVG(v.wait_minutes) wait FROM $mf LEFT JOIN stores s ON s.id=v.store_id LEFT JOIN teams t ON t.id=v.team_id WHERE $mw GROUP BY COALESCE(s.name, t.name, 'Canal digital') ORDER BY avg ASC LIMIT 15", $mp);
        $byCrit = DB::all("SELECT c.label, COUNT(*) n FROM mc_answers a JOIN mc_criteria c ON c.id=a.criterion_id JOIN mc_visits v ON v.id=a.visit_id JOIN mc_grids g ON g.id=v.grid_id WHERE $mw AND a.answer='ko' GROUP BY c.id, c.label ORDER BY n DESC LIMIT 8", $mp);
        $months = DB::all("SELECT SUBSTR(v.validated_at,1,7) m, COUNT(*) n, AVG(v.score_pct) avg FROM $mf WHERE $mw GROUP BY SUBSTR(v.validated_at,1,7) ORDER BY m", $mp);
        $rw = "r.status='completed' AND r.completed_at>=? AND r.completed_at<?"; $rp = [$lo, $hi]; if ($ch) { $rw .= ' AND (j.channel=? OR j.channel=\'multi\')'; $rp[] = $ch; }
        $jr = DB::one("SELECT COUNT(*) n, SUM(CASE WHEN r.result='passed' THEN 1 ELSE 0 END) ok, SUM(CASE WHEN r.result='degraded' THEN 1 ELSE 0 END) deg, SUM(CASE WHEN r.result='failed' THEN 1 ELSE 0 END) ko FROM jr_runs r JOIN jr_journeys j ON j.id=r.journey_id WHERE $rw", $rp);
        $byJ = DB::all("SELECT j.name, COUNT(*) n, SUM(CASE WHEN r.result='passed' THEN 1 ELSE 0 END) ok, SUM(CASE WHEN r.result='failed' THEN 1 ELSE 0 END) ko, AVG(r.total_seconds) dur FROM jr_runs r JOIN jr_journeys j ON j.id=r.journey_id WHERE $rw GROUP BY j.id, j.name ORDER BY ko DESC, n DESC", $rp);
        $byStep = DB::all("SELECT j.name journey, s.label, COUNT(*) n FROM jr_results x JOIN jr_steps s ON s.id=x.step_id JOIN jr_runs r ON r.id=x.run_id JOIN jr_journeys j ON j.id=r.journey_id WHERE $rw AND x.status IN ('fail','blocked') GROUP BY s.id, s.label, j.name ORDER BY n DESC LIMIT 8", $rp);
        $act = DB::one("SELECT COUNT(*) n, SUM(CASE WHEN status IN ('open','in_progress') THEN 1 ELSE 0 END) open, SUM(CASE WHEN status IN ('open','in_progress') AND due_date<? THEN 1 ELSE 0 END) late, SUM(CASE WHEN status='verified' THEN 1 ELSE 0 END) verified FROM cx_actions WHERE status<>'cancelled'", [date('Y-m-d')]);
        $this->view('cx/dashboard', ['title' => 'Tableau de bord Mystery Customer & parcours', 'from' => $from, 'to' => $to, 'ch' => $ch, 'mc' => $mc, 'bySubject' => $bySubject, 'byCrit' => $byCrit, 'months' => $months, 'jr' => $jr, 'byJ' => $byJ, 'byStep' => $byStep, 'act' => $act]);
    }
}
