<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Cc, Ref, Scope, Sop};
class CcController extends Controller {
    private function teamId(): int { return (int)DB::val('SELECT team_id FROM employees WHERE id=?', [Cc::me()]); }
    private function userOf(int $emp): ?int { $u = DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [$emp]); return $u ? (int)$u : null; }
    private function caseFor(string $id): ?array {
        $c = DB::one('SELECT * FROM cc_cases WHERE id=?', [(int)$id]); if (!$c) return null;
        if (can('cc.manage')) return $c;
        return $c['status'] === 'published' && (!$c['team_id'] || (int)$c['team_id'] === $this->teamId()) ? $c : null;
    }
    // =============== Apprenant ===============
    function mine(): void {
        $me = Cc::me();
        $rows = $me ? DB::all('SELECT a.*, c.ref, c.title, c.theme, c.pass_pct FROM cc_attempts a JOIN cc_cases c ON c.id=a.case_id WHERE a.employee_id=? ORDER BY CASE a.status WHEN \'assigned\' THEN 0 WHEN \'in_progress\' THEN 1 WHEN \'submitted\' THEN 2 ELSE 3 END, a.due_date, a.id DESC', [$me]) : [];
        $this->view('cc/mine', ['title' => 'Mes études de cas', 'rows' => $rows]);
    }
    function library(): void {
        $q = trim((string)$this->in('q', '')); $theme = (string)$this->in('theme', ''); $level = (string)$this->in('level', ''); $w = ["c.status='published'"]; $p = [];
        if (!can('cc.manage')) { $w[] = '(c.team_id IS NULL OR c.team_id=?)'; $p[] = $this->teamId(); }
        if ($q !== '') { $w[] = '(LOWER(c.title) LIKE ? OR LOWER(c.objective) LIKE ?)'; $l = '%' . mb_strtolower($q) . '%'; array_push($p, $l, $l); }
        if ($theme !== '') { $w[] = 'c.theme=?'; $p[] = $theme; } if ($level !== '') { $w[] = 'c.level=?'; $p[] = $level; }
        $this->view('cc/library', ['title' => 'Catalogue des études de cas', 'rows' => DB::all('SELECT c.*, (SELECT COUNT(*) FROM cc_questions WHERE case_id=c.id) nq FROM cc_cases c WHERE ' . implode(' AND ', $w) . ' ORDER BY c.theme, c.title LIMIT 300', $p), 'q' => $q, 'theme' => $theme, 'level' => $level]);
    }
    function show(string $id): void {
        $c = $this->caseFor($id); if (!$c) { $this->notFound(); return; } $me = Cc::me(); $mg = can('cc.manage');
        $mine = $me ? DB::all('SELECT * FROM cc_attempts WHERE case_id=? AND employee_id=? ORDER BY attempt_no DESC', [(int)$id, $me]) : [];
        $max = Cc::maxAttempts($c); $open = (bool)array_filter($mine, fn($a) => in_array($a['status'], ['assigned', 'in_progress', 'submitted'], true));
        $this->view('cc/show', ['title' => $c['ref'] . ' · ' . $c['title'], 'c' => $c, 'mine' => $mine, 'canStart' => $c['status'] === 'published' && $me && !$open && (!$max || count($mine) < $max), 'max' => $max, 'mg' => $mg,
            'qs' => $mg ? Cc::questions((int)$id) : [], 'nq' => (int)DB::val('SELECT COUNT(*) FROM cc_questions WHERE case_id=?', [(int)$id]), 'nat' => (int)DB::val('SELECT COUNT(*) FROM cc_attempts WHERE case_id=?', [(int)$id]),
            'stat' => $mg ? DB::one("SELECT COUNT(*) n, AVG(score_pct) s, SUM(CASE WHEN result='pass' THEN 1 ELSE 0 END) ok FROM cc_attempts WHERE case_id=? AND status='graded'", [(int)$id]) : null,
            'script' => $c['script_id'] ? DB::one('SELECT id, ref, title FROM cs_scripts WHERE id=?', [(int)$c['script_id']]) : null, 'sop' => $c['sop_id'] ? DB::one('SELECT id, ref, title FROM kb_sops WHERE id=?', [(int)$c['sop_id']]) : null,
            'teams' => can('cc.assign') ? DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name') : [], 'emps' => can('cc.assign') ? Scope::employees() : []]);
    }
    function start(string $id): void {
        $c = $this->caseFor($id); $me = Cc::me(); if (!$c || $c['status'] !== 'published' || !$me) { $this->notFound(); return; }
        $n = (int)DB::val('SELECT COUNT(*) FROM cc_attempts WHERE case_id=? AND employee_id=?', [(int)$id, $me]); $max = Cc::maxAttempts($c);
        if (DB::val("SELECT 1 FROM cc_attempts WHERE case_id=? AND employee_id=? AND status IN ('assigned','in_progress','submitted')", [(int)$id, $me])) { flash('Vous avez déjà une tentative en cours sur cette étude de cas.', 'warning'); redirect("cc/$id"); }
        if ($max && $n >= $max) { flash('Nombre maximal de tentatives atteint.', 'danger'); redirect("cc/$id"); }
        $aid = DB::insert('cc_attempts', ['case_id' => (int)$id, 'employee_id' => $me, 'assigned_by' => Auth::id(), 'status' => 'in_progress', 'attempt_no' => $n + 1, 'started_at' => now(), 'created_at' => now()]); redirect("cc/attempt/$aid");
    }
    private function attempt(string $aid): ?array {
        $a = DB::one('SELECT a.*, c.title, c.ref, c.pass_pct, c.show_answer, c.model_answer, c.context, c.customer_profile, c.objective, c.resources, c.duration_min, e.first_name, e.last_name FROM cc_attempts a JOIN cc_cases c ON c.id=a.case_id JOIN employees e ON e.id=a.employee_id WHERE a.id=?', [(int)$aid]); if (!$a) return null;
        if ((int)$a['employee_id'] === Cc::me()) return $a;
        return (can('cc.grade') || can('cc.manage')) && Scope::allows((int)$a['employee_id']) ? $a : null;
    }
    function attemptPage(string $aid): void {
        $a = $this->attempt($aid); if (!$a) { $this->notFound(); return; } $mine = (int)$a['employee_id'] === Cc::me(); $qs = Cc::questions((int)$a['case_id']);
        $ans = []; foreach (DB::all('SELECT * FROM cc_answers WHERE attempt_id=?', [(int)$aid]) as $x) $ans[(int)$x['question_id']] = $x;
        $take = $mine && in_array($a['status'], ['assigned', 'in_progress'], true);
        if ($take && $a['status'] === 'assigned') { DB::update('cc_attempts', ['status' => 'in_progress', 'started_at' => now()], 'id=?', [(int)$aid]); $a['status'] = 'in_progress'; }
        $reveal = $a['status'] === 'graded' && ($a['show_answer'] || !$mine);
        $this->view($take ? 'cc/take' : 'cc/review', ['title' => $a['ref'] . ' · ' . $a['title'], 'a' => $a, 'qs' => $qs, 'ans' => $ans, 'reveal' => $reveal, 'mine' => $mine, 'canGrade' => can('cc.grade') && !$mine]);
    }
    function saveAttempt(string $aid): void {
        $a = $this->attempt($aid); if (!$a || (int)$a['employee_id'] !== Cc::me() || !in_array($a['status'], ['assigned', 'in_progress'], true)) { $this->forbidden(); return; }
        foreach (Cc::questions((int)$a['case_id']) as $q) {
            $qid = (int)$q['id']; $row = DB::one('SELECT id FROM cc_answers WHERE attempt_id=? AND question_id=?', [(int)$aid, $qid]);
            if ($q['kind'] === 'open') $d = ['answer' => mb_substr(trim((string)($_POST['a'][$qid] ?? '')), 0, 8000) ?: null, 'selected' => null];
            else { $ids = array_map('intval', array_slice((array)($_POST['a'][$qid] ?? []), 0, 20)); $valid = array_map(fn($o) => (int)$o['id'], $q['options']); $d = ['answer' => null, 'selected' => implode(',', array_values(array_intersect($ids, $valid))) ?: null]; }
            if ($row) DB::update('cc_answers', $d, 'id=?', [(int)$row['id']]); else DB::insert('cc_answers', $d + ['attempt_id' => (int)$aid, 'question_id' => $qid]);
        }
        if ($this->in('submit') !== '1') { flash('Brouillon enregistré.'); redirect("cc/attempt/$aid"); }
        [$auto, $max, $open] = Cc::autoGrade((int)$aid, (int)$a['case_id']);
        DB::update('cc_attempts', ['submitted_at' => now(), 'auto_points' => $auto, 'max_points' => $max], 'id=?', [(int)$aid]);
        if (!$open) { [$pct, $res] = Cc::finalize((int)$aid); flash('Étude de cas corrigée : ' . round($pct) . ' % (' . ($res === 'pass' ? 'réussie' : 'à reprendre') . ').'); }
        else {
            DB::update('cc_attempts', ['status' => 'submitted'], 'id=?', [(int)$aid]); $who = trim($a['last_name'] . ' ' . $a['first_name']);
            if ($a['assigned_by'] && (int)$a['assigned_by'] !== Auth::id()) Notifier::send((int)$a['assigned_by'], 'Étude de cas à corriger', $who . ' — ' . $a['title'], '/cc/grade/' . $aid); else Notifier::toPermission('cc.grade', 'Étude de cas à corriger', $who . ' — ' . $a['title'], '/cc/grade/' . $aid);
            flash('Réponses transmises : un formateur va les corriger.');
        }
        Audit::log('submit', 'cc_attempt', $aid); redirect("cc/attempt/$aid");
    }
    // =============== Correction ===============
    function grading(): void {
        [$sw, $sp] = Scope::sql('a.employee_id');
        $this->view('cc/grading', ['title' => 'Études de cas à corriger', 'rows' => DB::all("SELECT a.*, c.ref, c.title, e.first_name, e.last_name FROM cc_attempts a JOIN cc_cases c ON c.id=a.case_id JOIN employees e ON e.id=a.employee_id WHERE a.status='submitted' AND $sw ORDER BY a.submitted_at", $sp)]);
    }
    function grade(string $aid): void {
        $a = $this->attempt($aid); if (!$a || (int)$a['employee_id'] === Cc::me()) { $this->notFound(); return; }
        $ans = []; foreach (DB::all('SELECT * FROM cc_answers WHERE attempt_id=?', [(int)$aid]) as $x) $ans[(int)$x['question_id']] = $x;
        $this->view('cc/grade', ['title' => 'Correction ' . $a['ref'], 'a' => $a, 'qs' => Cc::questions((int)$a['case_id']), 'ans' => $ans]);
    }
    function saveGrade(string $aid): void {
        $a = $this->attempt($aid); if (!$a || (int)$a['employee_id'] === Cc::me() || !in_array($a['status'], ['submitted', 'graded'], true)) { $this->forbidden(); return; }
        Cc::autoGrade((int)$aid, (int)$a['case_id']); $err = [];
        foreach (Cc::questions((int)$a['case_id']) as $q) {
            $qid = (int)$q['id']; $com = mb_substr(trim((string)($_POST['c'][$qid] ?? '')), 0, 1000) ?: null; $row = DB::one('SELECT id FROM cc_answers WHERE attempt_id=? AND question_id=?', [(int)$aid, $qid]);
            if ($q['kind'] === 'open') {
                $p = str_replace(',', '.', trim((string)($_POST['p'][$qid] ?? '0'))); if ($p === '') $p = '0';
                if (!is_numeric($p) || (float)$p < 0 || (float)$p > $q['points']) { $err[] = 'Question ' . $q['position'] . ' : points de 0 à ' . $q['points'] . '.'; continue; }
                DB::update('cc_answers', ['points' => (float)$p, 'comment' => $com], 'id=?', [(int)$row['id']]);
            } else DB::update('cc_answers', ['comment' => $com], 'id=?', [(int)$row['id']]);
        }
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("cc/grade/$aid"); }
        [$pct, $res] = Cc::finalize((int)$aid, Auth::id()); DB::update('cc_attempts', ['feedback' => mb_substr(trim((string)$this->in('feedback', '')), 0, 3000) ?: null], 'id=?', [(int)$aid]);
        if ($u = $this->userOf((int)$a['employee_id'])) Notifier::send($u, 'Étude de cas corrigée', $a['title'] . ' : ' . round($pct) . ' % — ' . ($res === 'pass' ? 'réussie' : 'à reprendre'), '/cc/attempt/' . $aid);
        Audit::log('grade', 'cc_attempt', $aid, null, ['score' => $pct, 'result' => $res]); flash('Correction enregistrée (' . round($pct) . ' %).'); redirect('cc/grading');
    }
    // =============== Gestion du catalogue ===============
    function manage(): void {
        $this->view('cc/manage', ['title' => 'Gérer les études de cas', 'rows' => DB::all("SELECT c.*, (SELECT COUNT(*) FROM cc_questions WHERE case_id=c.id) nq, (SELECT COUNT(*) FROM cc_attempts WHERE case_id=c.id) nat, (SELECT AVG(score_pct) FROM cc_attempts WHERE case_id=c.id AND status='graded') avg FROM cc_cases c ORDER BY c.updated_at DESC LIMIT 300")]);
    }
    private function form(?array $c, array $qs): void {
        $this->view('cc/form', ['title' => $c ? 'Modifier ' . $c['ref'] : 'Nouvelle étude de cas', 'c' => $c, 'qs' => $qs, 'locked' => $c && (int)DB::val('SELECT COUNT(*) FROM cc_attempts WHERE case_id=?', [(int)$c['id']]) > 0, 'channels' => DB::all('SELECT id, name FROM channels WHERE active=1 ORDER BY name'), 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'),
            'scripts' => DB::all("SELECT id, ref, title FROM cs_scripts WHERE status='published' ORDER BY title"), 'sops' => DB::all("SELECT id, ref, title FROM kb_sops WHERE status='published' ORDER BY title"), 'emps' => DB::all("SELECT id, first_name, last_name FROM employees WHERE status<>'left' ORDER BY last_name, first_name")]);
    }
    function create(): void { $this->form(null, []); }
    function edit(string $id): void { $c = DB::one('SELECT * FROM cc_cases WHERE id=?', [(int)$id]); if (!$c) { $this->notFound(); return; } $this->form($c, Cc::questions((int)$id)); }
    private function data(): array {
        [$d, $err] = $this->validate(['title' => ['label' => 'Le titre', 'req' => true, 'max' => 200], 'context' => ['label' => 'Le contexte', 'req' => true, 'max' => 8000], 'customer_profile' => ['label' => 'Le profil client', 'max' => 3000], 'objective' => ['label' => 'L\'objectif', 'max' => 3000], 'resources' => ['label' => 'Les ressources', 'max' => 3000], 'model_answer' => ['label' => 'Le corrigé', 'max' => 8000]], $_POST);
        foreach (['theme' => 'case_themes', 'level' => 'case_levels'] as $f => $list) { $v = (string)$this->in($f, ''); if ($v !== '' && !Ref::has($list, $v)) $err[$f] = 'Valeur de liste inconnue (' . $f . ').'; $d[$f] = $v ?: null; }
        $pp = trim((string)$this->in('pass_pct', (string)setting('cc.pass_pct', '70'))); if (!ctype_digit($pp) || (int)$pp < 1 || (int)$pp > 100) $err['pass_pct'] = 'Seuil de réussite : 1 à 100.'; $d['pass_pct'] = (int)$pp;
        $ma = trim((string)$this->in('max_attempts', '0')); if ($ma === '') $ma = '0'; if (!ctype_digit($ma) || (int)$ma > 50) $err['max_attempts'] = 'Tentatives : entier (0 = réglage général).'; $d['max_attempts'] = (int)$ma;
        $du = trim((string)$this->in('duration_min', '')); if ($du !== '' && (!ctype_digit($du) || (int)$du > 1440)) $err['duration'] = 'Durée indicative invalide.'; $d['duration_min'] = $du !== '' ? (int)$du : null;
        $d['channel_id'] = (int)$this->in('channel_id', 0) && DB::val('SELECT 1 FROM channels WHERE id=?', [(int)$this->in('channel_id')]) ? (int)$this->in('channel_id') : null;
        $d['team_id'] = (int)$this->in('team_id', 0) && DB::val('SELECT 1 FROM teams WHERE id=?', [(int)$this->in('team_id')]) ? (int)$this->in('team_id') : null;
        $d['script_id'] = (int)$this->in('script_id', 0) && DB::val('SELECT 1 FROM cs_scripts WHERE id=?', [(int)$this->in('script_id')]) ? (int)$this->in('script_id') : null;
        $d['sop_id'] = (int)$this->in('sop_id', 0) && DB::val('SELECT 1 FROM kb_sops WHERE id=?', [(int)$this->in('sop_id')]) ? (int)$this->in('sop_id') : null;
        $d['owner_id'] = (int)$this->in('owner_id', 0) && DB::val('SELECT 1 FROM employees WHERE id=?', [(int)$this->in('owner_id')]) ? (int)$this->in('owner_id') : null;
        $d['show_answer'] = $this->in('show_answer') ? 1 : 0; $d['updated_at'] = now();
        return [$d, $err];
    }
    function store(): void {
        [$d, $err] = $this->data(); [$qs, $e2] = Cc::readQuestions(); if ($e2) $err['q'] = $e2;
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); $_SESSION['_old'] = $_POST; redirect('cc/new'); }
        $id = DB::insert('cc_cases', $d + ['ref' => Sop::nextRef('cc_cases', 'EC'), 'status' => 'draft', 'author_id' => Auth::id(), 'version' => 1, 'created_at' => now()]); Cc::replaceQuestions($id, $qs);
        Audit::log('create', 'cc_case', $id, null, ['title' => $d['title']]); flash('Étude de cas enregistrée en brouillon.'); redirect("cc/$id");
    }
    function update(string $id): void {
        $c = DB::one('SELECT * FROM cc_cases WHERE id=?', [(int)$id]); if (!$c) { $this->notFound(); return; }
        [$d, $err] = $this->data(); $locked = (int)DB::val('SELECT COUNT(*) FROM cc_attempts WHERE case_id=?', [(int)$id]) > 0; $qs = null;
        if (!$locked) { [$qs, $e2] = Cc::readQuestions(); if ($e2) $err['q'] = $e2; }
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("cc/$id/edit"); }
        DB::update('cc_cases', $d, 'id=?', [(int)$id]); if ($qs !== null) Cc::replaceQuestions((int)$id, $qs);
        Audit::log('update', 'cc_case', $id, ['title' => $c['title']], ['title' => $d['title']]); flash('Étude de cas enregistrée.'); redirect("cc/$id");
    }
    function status(string $id): void {
        $c = DB::one('SELECT * FROM cc_cases WHERE id=?', [(int)$id]); if (!$c) { $this->notFound(); return; } $act = (string)$this->in('action');
        if ($act === 'publish' && $c['status'] !== 'published') { $pb = Cc::problems((int)$id); if ($pb) { flash(implode(' ', $pb), 'danger'); redirect("cc/$id"); } $st = 'published'; }
        elseif ($act === 'archive' && $c['status'] !== 'archived') $st = 'archived'; elseif ($act === 'unpublish' && $c['status'] === 'published') $st = 'draft';
        else { $this->forbidden(); return; }
        DB::update('cc_cases', ['status' => $st, 'updated_at' => now()], 'id=?', [(int)$id]); Audit::log($act, 'cc_case', $id); flash($st === 'published' ? 'Étude de cas publiée.' : ($st === 'archived' ? 'Archivée.' : 'Repassée en brouillon.')); redirect("cc/$id");
    }
    function delete(string $id): void {
        $c = DB::one('SELECT * FROM cc_cases WHERE id=?', [(int)$id]); if (!$c) { $this->notFound(); return; }
        if (DB::val('SELECT 1 FROM cc_attempts WHERE case_id=?', [(int)$id])) { flash('Des collaborateurs l\'ont déjà passée : archivez-la plutôt.', 'danger'); redirect("cc/$id"); }
        Cc::replaceQuestions((int)$id, []); DB::exec('DELETE FROM cc_cases WHERE id=?', [(int)$id]); Audit::log('delete', 'cc_case', $id, $c); flash('Étude de cas supprimée.'); redirect('cc/manage');
    }
    function duplicate(string $id): void {
        $c = DB::one('SELECT * FROM cc_cases WHERE id=?', [(int)$id]); if (!$c) { $this->notFound(); return; }
        unset($c['id']); $c['ref'] = Sop::nextRef('cc_cases', 'EC'); $c['title'] = mb_substr($c['title'] . ' (copie)', 0, 200); $c['status'] = 'draft'; $c['author_id'] = Auth::id(); $c['version'] = (int)$c['version'] + 1; $c['created_at'] = $c['updated_at'] = now();
        $nid = DB::insert('cc_cases', $c);
        $qs = Cc::questions((int)$id); Cc::replaceQuestions($nid, array_map(fn($q) => ['kind' => $q['kind'], 'prompt' => $q['prompt'], 'points' => $q['points'], 'expected' => $q['expected'], 'explanation' => $q['explanation'], 'options' => array_map(fn($o) => ['label' => $o['label'], 'correct' => $o['correct']], $q['options'])], $qs));
        flash('Copie créée en brouillon : vous pouvez modifier les questions.'); redirect("cc/$nid/edit");
    }
    // =============== Affectation ===============
    function assign(string $id): void {
        $c = DB::one("SELECT * FROM cc_cases WHERE id=? AND status='published'", [(int)$id]); if (!$c) { $this->notFound(); return; }
        $due = (string)$this->in('due_date', ''); if ($due !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $due)) { flash('Date limite invalide.', 'danger'); redirect("cc/$id"); }
        $ids = array_map('intval', (array)($_POST['employee_ids'] ?? [])); if ((int)$this->in('team_id', 0)) $ids = array_merge($ids, array_map('intval', array_column(DB::all("SELECT id FROM employees WHERE team_id=? AND status<>'left'", [(int)$this->in('team_id')]), 'id')));
        $n = 0; $skip = 0; $max = Cc::maxAttempts($c);
        foreach (array_unique($ids) as $emp) {
            if (!$emp || !Scope::allows($emp) || !DB::val("SELECT 1 FROM employees WHERE id=? AND status<>'left'", [$emp])) { $skip++; continue; }
            $cnt = (int)DB::val('SELECT COUNT(*) FROM cc_attempts WHERE case_id=? AND employee_id=?', [(int)$id, $emp]);
            if (DB::val("SELECT 1 FROM cc_attempts WHERE case_id=? AND employee_id=? AND status IN ('assigned','in_progress','submitted')", [(int)$id, $emp]) || ($max && $cnt >= $max)) { $skip++; continue; }
            $aid = DB::insert('cc_attempts', ['case_id' => (int)$id, 'employee_id' => $emp, 'assigned_by' => Auth::id(), 'due_date' => $due ?: null, 'status' => 'assigned', 'attempt_no' => $cnt + 1, 'created_at' => now()]); $n++;
            if ($u = $this->userOf($emp)) Notifier::send($u, 'Nouvelle étude de cas', $c['title'] . ($due ? ' — avant le ' . date('d/m/Y', strtotime($due)) : ''), '/cc/attempt/' . $aid);
        }
        Audit::log('assign', 'cc_case', $id, null, ['assigned' => $n, 'skipped' => $skip]); flash("$n affectation(s) créée(s)" . ($skip ? ", $skip ignorée(s) (hors périmètre, déjà en cours ou tentatives épuisées)." : '.'), $n ? 'success' : 'warning'); redirect("cc/$id");
    }
    // =============== Résultats et statistiques ===============
    function results(): void {
        [$sw, $sp] = Scope::sql('a.employee_id'); $w = [$sw, "a.status='graded'"]; $p = $sp; $cs = (int)$this->in('case', 0); $tm = (int)$this->in('team', 0); $rs = (string)$this->in('result', '');
        if ($cs) { $w[] = 'a.case_id=?'; $p[] = $cs; } if ($tm) { $w[] = 'e.team_id=?'; $p[] = $tm; } if (in_array($rs, ['pass', 'fail'], true)) { $w[] = 'a.result=?'; $p[] = $rs; }
        $from = 'cc_attempts a JOIN cc_cases c ON c.id=a.case_id JOIN employees e ON e.id=a.employee_id LEFT JOIN teams t ON t.id=e.team_id WHERE ' . implode(' AND ', $w);
        if ($this->in('export') === 'csv') csv_download('etudes_de_cas.csv', ['Étude de cas', 'Thème', 'Matricule', 'Nom', 'Prénom', 'Équipe', 'Tentative', 'Soumise le', 'Corrigée le', 'Score %', 'Résultat'],
            array_map(fn($r) => [$r['ref'] . ' ' . $r['title'], $r['theme'], $r['matricule'], $r['last_name'], $r['first_name'], $r['team'], $r['attempt_no'], $r['submitted_at'], $r['graded_at'], $r['score_pct'], $r['result'] === 'pass' ? 'Réussie' : 'À reprendre'], DB::all("SELECT a.*, c.ref, c.title, c.theme, e.matricule, e.first_name, e.last_name, t.name team FROM $from ORDER BY a.graded_at DESC LIMIT 5000", $p)));
        $this->view('cc/results', ['title' => 'Résultats des études de cas', 'p' => paginate($from, $p, $this->page(), 25, 'a.*, c.ref, c.title, e.first_name, e.last_name, t.name team', 'a.graded_at DESC, a.id DESC'), 'cs' => $cs, 'tm' => $tm, 'rs' => $rs, 'cases' => DB::all('SELECT id, ref, title FROM cc_cases ORDER BY title'), 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name')]);
    }
    function stats(): void {
        [$sw, $sp] = Scope::sql('a.employee_id'); $base = "a.status='graded' AND $sw";
        $byCase = DB::all("SELECT c.id, c.ref, c.title, c.theme, COUNT(*) n, AVG(a.score_pct) s, SUM(CASE WHEN a.result='pass' THEN 1 ELSE 0 END) ok FROM cc_attempts a JOIN cc_cases c ON c.id=a.case_id WHERE $base GROUP BY c.id, c.ref, c.title, c.theme ORDER BY s", $sp);
        $byTheme = DB::all("SELECT COALESCE(c.theme,'') theme, COUNT(*) n, AVG(a.score_pct) s FROM cc_attempts a JOIN cc_cases c ON c.id=a.case_id WHERE $base GROUP BY COALESCE(c.theme,'') ORDER BY s", $sp);
        $byTeam = DB::all("SELECT COALESCE(t.name,'Sans équipe') team, COUNT(*) n, AVG(a.score_pct) s, SUM(CASE WHEN a.result='pass' THEN 1 ELSE 0 END) ok FROM cc_attempts a JOIN employees e ON e.id=a.employee_id LEFT JOIN teams t ON t.id=e.team_id WHERE $base GROUP BY COALESCE(t.name,'Sans équipe') ORDER BY s", $sp);
        $hard = DB::all("SELECT q.id, q.position, q.prompt, c.ref, AVG(a2.points * 100.0 / q.points) s, COUNT(*) n FROM cc_answers a2 JOIN cc_questions q ON q.id=a2.question_id JOIN cc_cases c ON c.id=q.case_id JOIN cc_attempts a ON a.id=a2.attempt_id WHERE $base GROUP BY q.id, q.position, q.prompt, c.ref HAVING COUNT(*) >= 1 ORDER BY s LIMIT 8", $sp);
        $late = (int)DB::val("SELECT COUNT(*) FROM cc_attempts a WHERE a.status IN ('assigned','in_progress') AND a.due_date IS NOT NULL AND a.due_date<? AND $sw", array_merge([date('Y-m-d')], $sp));
        $this->view('cc/stats', ['title' => 'Statistiques des études de cas', 'byCase' => $byCase, 'byTheme' => $byTheme, 'byTeam' => $byTeam, 'hard' => $hard, 'late' => $late, 'toGrade' => (int)DB::val("SELECT COUNT(*) FROM cc_attempts a WHERE a.status='submitted' AND $sw", $sp)]);
    }
}
