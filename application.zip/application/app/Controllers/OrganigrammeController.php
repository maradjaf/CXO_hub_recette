<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Org, Settings, Auth};

/** Organisation du personnel : structure (Direction › Département › Pôle › Activité), niveaux N à N+6, organigramme, trombinoscope et publications. */
class OrganigrammeController extends Controller {
    private const PHOTO = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'];

    private function contracts(): array {
        return DB::all("SELECT v.code, v.label FROM ref_values v JOIN ref_lists l ON l.id=v.list_id WHERE l.code='contract_types' AND v.active=1 ORDER BY v.sort_order, v.label");
    }
    private function filters(): array {
        $f = ['unit' => (int)$this->in('unit', 0), 'level' => (string)$this->in('level', ''), 'contract' => (string)$this->in('contract', ''), 'status' => (string)$this->in('status', 'active'), 'q' => trim((string)$this->in('q', ''))];
        if (!in_array($f['status'], ['active', 'inactive', 'left', 'all'], true)) $f['status'] = 'active';
        return $f;
    }
    private function common(array $f): array { return ['f' => $f, 'units' => Org::flat(), 'levels' => Org::levels(), 'contracts' => $this->contracts()]; }

    // ───────────── Organigramme ─────────────
    function index(): void {
        $f = $this->filters(); $view = (string)$this->in('view', 'tree'); if (!in_array($view, ['tree', 'chain', 'list'], true)) $view = 'tree';
        $people = Org::people($f);
        if ($this->in('export') === 'csv') {
            csv_download('organigramme.csv', ['matricule', 'nom', 'prenom', 'niveau', 'poste', 'unite', 'chemin', 'contrat', 'responsable', 'statut'],
                array_map(fn($e) => [$e['matricule'], $e['last_name'], $e['first_name'], Org::code((int)$e['org_level']) . ' ' . Org::level((int)$e['org_level']), $e['position_name'], $e['unit_name'], Org::path($e['org_unit_id'] ? (int)$e['org_unit_id'] : null), $e['contract_type'], trim($e['mln'] . ' ' . $e['mfn']), $e['status']], $people));
        }
        $byUnit = []; foreach ($people as $e) $byUnit[(int)$e['org_unit_id']][] = $e;
        $count = array_fill_keys(range(0, 6), 0); foreach ($people as $e) $count[max(0, min(6, (int)$e['org_level']))]++;
        $this->view('organigramme/index', ['title' => 'Organigramme', 'mode' => $view, 'people' => $people, 'byUnit' => $byUnit, 'tree' => Org::tree(false), 'count' => $count, 'chain' => $view === 'chain' ? $this->chain($people) : []] + $this->common($f));
    }
    /** Arbre hiérarchique par responsable direct, limité aux collaborateurs filtrés. */
    private function chain(array $people): array {
        $ids = array_column($people, 'id'); $by = []; $roots = [];
        foreach ($people as $e) { $m = (int)$e['manager_id']; if ($m && in_array($m, array_map('intval', $ids), true) && $m !== (int)$e['id']) $by[$m][] = $e; else $roots[] = $e; }
        $seen = []; $build = function (array $e, int $d) use (&$build, $by, &$seen): array { $seen[(int)$e['id']] = 1; $k = []; if ($d < 8) foreach ($by[(int)$e['id']] ?? [] as $c) if (!isset($seen[(int)$c['id']])) $k[] = $build($c, $d + 1); return ['e' => $e, 'kids' => $k]; };
        usort($roots, fn($a, $b) => ((int)$b['org_level'] <=> (int)$a['org_level']) ?: strcmp($a['last_name'], $b['last_name']));
        return array_map(fn($r) => $build($r, 0), $roots);
    }

    // ───────────── Structure (gestion backend) ─────────────
    function structure(): void {
        $cnt = []; foreach (DB::all('SELECT org_unit_id u, COUNT(*) n FROM employees WHERE org_unit_id IS NOT NULL AND status<>\'left\' GROUP BY org_unit_id') as $r) $cnt[(int)$r['u']] = (int)$r['n'];
        $hn = []; foreach (DB::all('SELECT id, first_name, last_name FROM employees') as $h) $hn[(int)$h['id']] = $h['first_name'] . ' ' . $h['last_name'];
        $this->view('organigramme/structure', ['title' => 'Structure et niveaux', 'hn' => $hn, 'flat' => Org::flat(true), 'cnt' => $cnt, 'positions' => DB::all('SELECT id, name, org_level FROM positions WHERE active=1 ORDER BY org_level DESC, name'),
            'loose' => ['teams' => (int)DB::val('SELECT COUNT(*) FROM teams WHERE org_unit_id IS NULL AND active=1'), 'stores' => (int)DB::val('SELECT COUNT(*) FROM stores WHERE org_unit_id IS NULL AND active=1'), 'employees' => (int)DB::val("SELECT COUNT(*) FROM employees WHERE org_unit_id IS NULL AND status<>'left'")]]);
    }
    function unitNew(): void { $this->view('organigramme/unit_form', ['title' => 'Nouvelle unité', 'u' => ['kind' => (string)$this->in('kind', 'department'), 'parent_id' => (int)$this->in('parent', 0)]] + $this->formData(null)); }
    function unitEdit(string $id): void {
        $u = DB::one('SELECT * FROM org_units WHERE id=?', [(int)$id]); if (!$u) { $this->notFound(); return; }
        $this->view('organigramme/unit_form', ['title' => 'Modifier ' . $u['name'], 'u' => $u] + $this->formData((int)$id));
    }
    private function formData(?int $id): array {
        $own = $id ? Org::descendants($id) : [];
        return ['parents' => array_values(array_filter(Org::flat(true), fn($x) => !in_array((int)$x['id'], $own, true))), 'heads' => DB::all("SELECT id, first_name, last_name FROM employees WHERE status='active' ORDER BY last_name, first_name"),
            'teams' => $id ? DB::all('SELECT id, code, name FROM teams WHERE org_unit_id=? ORDER BY name', [$id]) : [], 'stores' => $id ? DB::all('SELECT id, code, name FROM stores WHERE org_unit_id=? ORDER BY name', [$id]) : [],
            'freeTeams' => DB::all('SELECT id, name FROM teams WHERE org_unit_id IS NULL OR org_unit_id<>? ORDER BY name', [$id ?? 0]), 'freeStores' => DB::all('SELECT id, name FROM stores WHERE org_unit_id IS NULL OR org_unit_id<>? ORDER BY name', [$id ?? 0]),
            'staff' => $id ? DB::all('SELECT id, first_name, last_name, org_level FROM employees WHERE org_unit_id=? AND status<>\'left\' ORDER BY org_level DESC, last_name', [$id]) : []];
    }
    function unitSave(?string $id = null): void {
        $old = $id ? DB::one('SELECT * FROM org_units WHERE id=?', [(int)$id]) : null; if ($id && !$old) { $this->notFound(); return; }
        [$d, $err] = $this->validate(['code' => ['label' => 'Le code', 'req' => true, 'max' => 40], 'name' => ['label' => 'La désignation', 'req' => true, 'max' => 150], 'description' => ['label' => 'La description', 'max' => 2000]], $_POST);
        $kind = (string)($_POST['kind'] ?? ''); if (!isset(Org::KINDS[$kind])) $err['kind'] = 'Type d\'unité inconnu.';
        if ($old && $old['kind'] !== $kind && DB::val('SELECT 1 FROM org_units WHERE parent_id=?', [(int)$id])) $err['kind'] = 'Impossible de changer le type d\'une unité qui a des sous-unités.';
        if ($d['code'] && !preg_match('/^[A-Za-z0-9_.-]+$/', $d['code'])) $err['code'] = 'Code : lettres, chiffres, - _ et . uniquement.';
        if ($d['code'] && DB::val('SELECT 1 FROM org_units WHERE code=? AND id<>?', [$d['code'], (int)$id])) $err['code'] = 'Ce code existe déjà.';
        $parent = (int)($_POST['parent_id'] ?? 0) ?: null;
        if (!isset($err['kind']) && ($m = Org::checkParent($kind, $parent, $id ? (int)$id : null)) !== '') $err['parent_id'] = $m;
        $head = (int)($_POST['head_employee_id'] ?? 0); $d += ['kind' => $kind, 'parent_id' => $kind === 'direction' ? null : $parent, 'head_employee_id' => $head && DB::val('SELECT 1 FROM employees WHERE id=?', [$head]) ? $head : null,
            'sort_order' => max(0, min(9999, (int)($_POST['sort_order'] ?? 0))), 'active' => $old ? (!empty($_POST['active']) ? 1 : 0) : 1, 'updated_at' => now()];
        if ($err) { $_SESSION['_old'] = $_POST; $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect($id ? "organigramme/units/$id/edit" : 'organigramme/units/new'); }
        if ($old) { DB::update('org_units', $d, 'id=?', [(int)$id]); Audit::log('update', 'org_unit', $id, $old, $d); $nid = (int)$id; }
        else { $d['created_at'] = now(); $nid = DB::insert('org_units', $d); Audit::log('create', 'org_unit', $nid, null, $d); }
        flash('Unité enregistrée.'); redirect("organigramme/units/$nid/edit");
    }
    function unitAttach(string $id): void {
        $u = DB::one('SELECT * FROM org_units WHERE id=?', [(int)$id]); if (!$u) { $this->notFound(); return; }
        $t = (int)$this->in('team_id', 0); $s = (int)$this->in('store_id', 0); $e = (int)$this->in('employee_id', 0);
        if ($t && DB::val('SELECT 1 FROM teams WHERE id=?', [$t])) { DB::update('teams', ['org_unit_id' => (int)$id], 'id=?', [$t]); DB::exec('UPDATE employees SET org_unit_id=? WHERE team_id=? AND (org_unit_id IS NULL OR org_unit_id IN (SELECT id FROM org_units WHERE kind=\'activity\'))', [(int)$id, $t]); Audit::log('attach', 'org_unit', $id, null, ['team' => $t]); }
        if ($s && DB::val('SELECT 1 FROM stores WHERE id=?', [$s])) { DB::update('stores', ['org_unit_id' => (int)$id], 'id=?', [$s]); Audit::log('attach', 'org_unit', $id, null, ['store' => $s]); }
        $many = array_values(array_unique(array_filter(array_map('intval', array_merge((array)($_POST['employee_ids'] ?? []), $e ? [$e] : [])))));
        $n = 0; foreach ($many as $eid) if (DB::val('SELECT 1 FROM employees WHERE id=?', [$eid])) { DB::update('employees', ['org_unit_id' => (int)$id, 'updated_at' => now()], 'id=?', [$eid]); $n++; }
        if ($n) Audit::log('attach', 'org_unit', $id, null, ['employees' => $many]);
        $hd = (int)$this->in('head_employee_id', 0); if ($this->in('set_head') && $hd && DB::val('SELECT 1 FROM employees WHERE id=?', [$hd])) { DB::update('org_units', ['head_employee_id' => $hd], 'id=?', [(int)$id]); Audit::log('head', 'org_unit', $id, null, ['employee' => $hd]); }
        if ($dt = (int)$this->in('detach_team')) { DB::update('teams', ['org_unit_id' => null], 'id=? AND org_unit_id=?', [$dt, (int)$id]); DB::update('employees', ['org_unit_id' => null], 'team_id=? AND org_unit_id=?', [$dt, (int)$id]); }
        if ($this->in('detach_store')) DB::update('stores', ['org_unit_id' => null], 'id=? AND org_unit_id=?', [(int)$this->in('detach_store'), (int)$id]);
        flash('Rattachement mis à jour' . ($n ? ' : ' . $n . ' collaborateur(s) rattaché(s)' : '') . '.'); redirect("organigramme/units/$id/edit");
    }
    function unitToggle(string $id): void {
        $u = DB::one('SELECT * FROM org_units WHERE id=?', [(int)$id]); if (!$u) { $this->notFound(); return; }
        DB::update('org_units', ['active' => $u['active'] ? 0 : 1, 'updated_at' => now()], 'id=?', [(int)$id]); Audit::log($u['active'] ? 'deactivate' : 'activate', 'org_unit', $id); flash($u['active'] ? 'Unité désactivée.' : 'Unité réactivée.'); redirect('organigramme/structure');
    }
    function unitDelete(string $id): void {
        $u = DB::one('SELECT * FROM org_units WHERE id=?', [(int)$id]); if (!$u) { $this->notFound(); return; }
        $use = (int)DB::val('SELECT COUNT(*) FROM org_units WHERE parent_id=?', [(int)$id]) + (int)DB::val('SELECT COUNT(*) FROM employees WHERE org_unit_id=?', [(int)$id]) + (int)DB::val('SELECT COUNT(*) FROM teams WHERE org_unit_id=?', [(int)$id]) + (int)DB::val('SELECT COUNT(*) FROM stores WHERE org_unit_id=?', [(int)$id]);
        if ($use) { flash('Suppression impossible : l\'unité contient des sous-unités, des équipes, des stores ou des collaborateurs. Désactivez-la plutôt.', 'danger'); redirect('organigramme/structure'); }
        DB::exec('DELETE FROM org_units WHERE id=?', [(int)$id]); Audit::log('delete', 'org_unit', $id, $u); flash('Unité supprimée.'); redirect('organigramme/structure');
    }
    /** Libellés des niveaux N à N+6 et niveau par défaut de chaque poste. */
    function levelsSave(): void {
        for ($i = 0; $i <= 6; $i++) { $v = trim((string)($_POST['lvl'][$i] ?? '')); Settings::set('org.lvl.' . $i, $v === '' || $v === Org::LEVELS[$i] ? '' : mb_substr($v, 0, 80)); }
        foreach ((array)($_POST['pos'] ?? []) as $pid => $lv) if (ctype_digit((string)$lv) && (int)$lv <= 6) DB::update('positions', ['org_level' => (int)$lv], 'id=?', [(int)$pid]);
        if (!empty($_POST['apply'])) DB::exec('UPDATE employees SET org_level=(SELECT p.org_level FROM positions p WHERE p.id=employees.position_id) WHERE position_id IS NOT NULL AND (SELECT p.org_level FROM positions p WHERE p.id=employees.position_id) IS NOT NULL');
        Audit::log('update', 'org_levels', null, null, ['apply' => !empty($_POST['apply'])]); flash('Niveaux enregistrés.'); redirect('organigramme/structure');
    }

    // ───────────── Trombinoscope ─────────────
    function trombi(): void {
        $f = $this->filters(); $people = Org::people($f);
        $this->view('organigramme/trombi', ['title' => 'Trombinoscope', 'people' => $people] + $this->common($f));
    }
    function photoSave(string $id): void {
        $e = DB::one('SELECT * FROM employees WHERE id=?', [(int)$id]); if (!$e) { $this->notFound(); return; }
        $f = $_FILES['photo'] ?? null;
        if (!$f || ($f['error'] ?? 4) === UPLOAD_ERR_NO_FILE) { flash('Choisissez une photo.', 'danger'); redirect('organigramme/trombinoscope'); }
        $ext = strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION));
        if ($f['error'] !== UPLOAD_ERR_OK || !isset(self::PHOTO[$ext]) || $f['size'] > 2 * 1024 * 1024) { flash('Photo refusée : jpg, png ou webp, 2 Mo maximum.', 'danger'); redirect('organigramme/trombinoscope'); }
        $mime = function_exists('mime_content_type') ? (string)@mime_content_type($f['tmp_name']) : ''; if ($mime !== '' && $mime !== self::PHOTO[$ext]) { flash('Le contenu ne correspond pas à l\'extension.', 'danger'); redirect('organigramme/trombinoscope'); }
        $st = bin2hex(random_bytes(16)) . '.' . $ext; if (!@move_uploaded_file($f['tmp_name'], Org::dir() . '/' . $st)) { flash('Photo non enregistrée.', 'danger'); redirect('organigramme/trombinoscope'); }
        if ($e['photo'] && is_file(Org::dir() . '/' . $e['photo'])) @unlink(Org::dir() . '/' . $e['photo']);
        DB::update('employees', ['photo' => $st], 'id=?', [(int)$id]); Audit::log('photo', 'employee', $id); flash('Photo enregistrée.'); redirect('organigramme/trombinoscope' . qs());
    }
    function photoDelete(string $id): void {
        $e = DB::one('SELECT * FROM employees WHERE id=?', [(int)$id]); if (!$e) { $this->notFound(); return; }
        if ($e['photo'] && is_file(Org::dir() . '/' . $e['photo'])) @unlink(Org::dir() . '/' . $e['photo']);
        DB::update('employees', ['photo' => null], 'id=?', [(int)$id]); Audit::log('photo_delete', 'employee', $id); flash('Photo retirée.'); redirect('organigramme/trombinoscope');
    }
    private function stream(?string $file): never {
        $path = $file ? Org::dir() . '/' . basename($file) : ''; if (!$file || !is_file($path)) { http_response_code(404); exit; }
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION)); header('Content-Type: ' . (self::PHOTO[$ext] ?? 'application/octet-stream')); header('X-Content-Type-Options: nosniff'); header('Cache-Control: private, max-age=3600'); header('Content-Length: ' . filesize($path)); readfile($path); exit;
    }
    function photo(string $id): void {
        $e = DB::one('SELECT photo FROM employees WHERE id=?', [(int)$id]);
        if (!$e || (!can('orgchart.view') && !DB::val('SELECT 1 FROM org_pub_items WHERE employee_id=?', [(int)$id]))) { http_response_code(404); exit; }
        $this->stream($e['photo']);
    }
    function pubPhoto(string $id): void {
        $i = DB::one('SELECT * FROM org_pub_items WHERE id=?', [(int)$id]); if (!$i || !$this->canSee((int)$i['publication_id'])) { http_response_code(404); exit; }
        $this->stream($i['photo']);
    }

    // ───────────── Publications ─────────────
    private function canSee(int $pubId): bool {
        if (can('orgchart.view')) return true;
        $p = DB::one('SELECT unit_id FROM org_publications WHERE id=?', [$pubId]); $eid = (int)(Auth::user()['employee_id'] ?? 0); if (!$p || !$eid) return false;
        return (bool)DB::val('SELECT 1 FROM org_pub_items WHERE publication_id=? AND employee_id=?', [$pubId, $eid]);
    }
    function pubs(): void {
        $this->view('organigramme/pubs', ['title' => 'Publications du trombinoscope', 'rows' => DB::all('SELECT p.*, u.name unit_name, (SELECT COUNT(*) FROM org_pub_items i WHERE i.publication_id=p.id) n FROM org_publications p LEFT JOIN org_units u ON u.id=p.unit_id ORDER BY p.id DESC LIMIT 100'),
            'units' => Org::flat(), 'levels' => Org::levels(), 'days' => (int)setting('org.pub_days', '0'), 'autoUnit' => (int)setting('org.pub_unit', '0'),
            'last' => DB::val('SELECT MAX(created_at) FROM org_publications WHERE auto=1')]);
    }
    function pubShow(string $id): void {
        $p = DB::one('SELECT p.*, u.name unit_name FROM org_publications p LEFT JOIN org_units u ON u.id=p.unit_id WHERE p.id=?', [(int)$id]); if (!$p || !$this->canSee((int)$id)) { $this->notFound(); return; }
        $this->view('organigramme/pub_show', ['title' => $p['title'], 'p' => $p, 'items' => DB::all('SELECT * FROM org_pub_items WHERE publication_id=? ORDER BY org_level DESC, full_name', [(int)$id])]);
    }
    function pubCreate(): void {
        $title = trim((string)$this->in('title', '')); if ($title === '') $title = 'Trombinoscope ' . date('m/Y');
        $unit = (int)$this->in('unit_id', 0) ?: null; if ($unit && !DB::val('SELECT 1 FROM org_units WHERE id=?', [$unit])) $unit = null;
        $lv = (int)$this->in('level_min', 0); $id = Org::publish(mb_substr($title, 0, 200), $unit, max(0, min(6, $lv)), false, Auth::id());
        Audit::log('publish', 'org_publication', $id); flash('Trombinoscope publié : le personnel du périmètre a été notifié.'); redirect("organigramme/publications/$id");
    }
    function pubSettings(): void {
        $d = max(0, min(366, (int)$this->in('days', 0))); Settings::set('org.pub_days', (string)$d); Settings::set('org.pub_unit', (string)(int)$this->in('unit_id', 0));
        Audit::log('update', 'org_pub_settings', null, null, ['days' => $d]); flash($d ? "Publication automatique tous les $d jours." : 'Publication automatique désactivée.'); redirect('organigramme/publications');
    }
    function pubDelete(string $id): void {
        $items = DB::all('SELECT photo FROM org_pub_items WHERE publication_id=?', [(int)$id]); foreach ($items as $i) if ($i['photo'] && is_file(Org::dir() . '/' . $i['photo'])) @unlink(Org::dir() . '/' . $i['photo']);
        DB::exec('DELETE FROM org_pub_items WHERE publication_id=?', [(int)$id]); DB::exec('DELETE FROM org_publications WHERE id=?', [(int)$id]); Audit::log('delete', 'org_publication', $id); flash('Publication supprimée.'); redirect('organigramme/publications');
    }
}
