<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Org, Settings, Congrats};

/** Mur des félicitations de mobilité : tout le monde voit les messages et peut féliciter ; le RH ou l'admin configure les modèles. */
class CongratsController extends Controller {
    function index(): void {
        $posts = DB::all('SELECT p.*, e.first_name, e.last_name, e.photo FROM congrats_posts p JOIN employees e ON e.id=p.employee_id WHERE p.active=1 ORDER BY p.created_at DESC, p.id DESC LIMIT 60');
        $me = (int)Auth::id();
        foreach ($posts as &$p) { $p['reacts'] = DB::all('SELECT r.*, u.name FROM congrats_reactions r JOIN users u ON u.id=r.user_id WHERE r.post_id=? ORDER BY r.id DESC LIMIT 30', [(int)$p['id']]); $p['n'] = (int)DB::val('SELECT COUNT(*) FROM congrats_reactions WHERE post_id=?', [(int)$p['id']]); $p['mine'] = (bool)DB::val('SELECT 1 FROM congrats_reactions WHERE post_id=? AND user_id=?', [(int)$p['id'], $me]); } unset($p);
        $this->view('congrats/index', ['title' => 'Félicitations', 'posts' => $posts, 'manage' => can('mobility.manage')]);
    }
    function react(string $id): void {
        $p = DB::one('SELECT * FROM congrats_posts WHERE id=? AND active=1', [(int)$id]); if (!$p) { $this->notFound(); return; }
        if (DB::val('SELECT 1 FROM congrats_reactions WHERE post_id=? AND user_id=?', [(int)$id, Auth::id()])) { flash('Vous avez déjà félicité cette personne.', 'info'); redirect('congrats'); }
        DB::insert('congrats_reactions', ['post_id' => (int)$id, 'user_id' => Auth::id(), 'message' => mb_substr(trim((string)$this->in('message', '')), 0, 300) ?: null, 'created_at' => now()]);
        if ($u = DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [(int)$p['employee_id']])) if ((int)$u !== (int)Auth::id()) Notifier::send((int)$u, 'Vous avez été félicité(e)', (string)(Auth::user()['name'] ?? '') . ' vous félicite pour votre mobilité.', '/congrats');
        flash('Félicitations envoyées.'); redirect('congrats#p' . $id);
    }
    function hide(string $id): void {
        $p = DB::one('SELECT * FROM congrats_posts WHERE id=?', [(int)$id]); if (!$p) { $this->notFound(); return; }
        DB::update('congrats_posts', ['active' => $p['active'] ? 0 : 1], 'id=?', [(int)$id]); Audit::log($p['active'] ? 'hide' : 'show', 'congrats_post', $id); redirect('congrats');
    }
    function photo(string $id): void {
        $e = DB::one('SELECT photo FROM employees WHERE id=?', [(int)$id]);
        if (!$e || !$e['photo'] || !DB::val('SELECT 1 FROM congrats_posts WHERE employee_id=? AND active=1', [(int)$id])) { http_response_code(404); exit; }
        $path = Org::dir() . '/' . basename((string)$e['photo']); if (!is_file($path)) { http_response_code(404); exit; }
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION)); $mime = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp'][$ext] ?? null; if (!$mime) { http_response_code(404); exit; }
        header('Content-Type: ' . $mime); header('X-Content-Type-Options: nosniff'); header('Cache-Control: private, max-age=3600'); header('Content-Length: ' . filesize($path)); readfile($path); exit;
    }
    // ---- Configuration (RH / admin) ----
    function templates(): void {
        $this->view('congrats/templates', ['title' => 'Messages de félicitations', 'rows' => DB::all('SELECT * FROM congrats_templates ORDER BY is_default DESC, name'), 'enabled' => Congrats::enabled()]);
    }
    function settings(): void { Settings::set('congrats.enabled', $this->in('enabled') === '1' ? '1' : '0'); Audit::log('update', 'congrats_settings', null, null, ['enabled' => $this->in('enabled')]); flash('Réglage enregistré.'); redirect('congrats/templates'); }
    function saveTemplate(?string $id = null): void {
        $old = $id ? DB::one('SELECT * FROM congrats_templates WHERE id=?', [(int)$id]) : null; if ($id && !$old) { $this->notFound(); return; }
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 120], 'title' => ['label' => 'Le titre', 'req' => true, 'max' => 190], 'body' => ['label' => 'Le message', 'req' => true, 'max' => 1000]], $_POST);
        if ($err) { flash(implode(' ', $err), 'danger'); redirect('congrats/templates'); }
        $d['is_default'] = !empty($_POST['is_default']) ? 1 : 0; $d['active'] = $old ? (!empty($_POST['active']) ? 1 : 0) : 1;
        if ($old) { DB::update('congrats_templates', $d, 'id=?', [(int)$id]); $nid = (int)$id; Audit::log('update', 'congrats_template', $id, $old, $d); } else { $d['created_at'] = now(); $nid = DB::insert('congrats_templates', $d); Audit::log('create', 'congrats_template', $nid, null, $d); }
        if ($d['is_default']) DB::exec('UPDATE congrats_templates SET is_default=0 WHERE id<>?', [$nid]);
        flash('Modèle enregistré.'); redirect('congrats/templates');
    }
    function deleteTemplate(string $id): void { $o = DB::one('SELECT * FROM congrats_templates WHERE id=?', [(int)$id]); if (!$o) { $this->notFound(); return; } DB::exec('DELETE FROM congrats_templates WHERE id=?', [(int)$id]); Audit::log('delete', 'congrats_template', $id, $o); flash('Modèle supprimé.'); redirect('congrats/templates'); }
}
