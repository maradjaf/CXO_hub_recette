<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Inc, IncEsc};

/**
 * Espace des intervenants support : ils n'y voient que les incidents escaladés vers leur(s) équipe(s), y donnent leur retour (prise en compte,
 * avancement, cause racine proposée) et consultent les statistiques de leur périmètre. Aucun accès aux autres modules de la direction.
 */
class SupportController extends Controller {
    private function scope(): ?array { return IncEsc::scope(); }
    private function sees(int $incId): bool {
        $sc = $this->scope(); if ($sc === null) return true; if (!$sc) return false;
        return (bool)DB::val('SELECT 1 FROM inc_escalations WHERE incident_id=? AND team_id IN (' . implode(',', array_map('intval', $sc)) . ')', [$incId]);
    }
    function index(): void {
        $sc = $this->scope(); $to = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($_GET['to'] ?? '')) ? $_GET['to'] : date('Y-m-d');
        $from = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($_GET['from'] ?? '')) ? $_GET['from'] : date('Y-m-d', strtotime($to . ' -89 days')); if ($from > $to) [$from, $to] = [$to, $from];
        $h1 = isset($_GET['h1']) && preg_match('/^\d{1,2}$/', (string)$_GET['h1']) && (int)$_GET['h1'] < 24 ? (string)(int)$_GET['h1'] : ''; $h2 = isset($_GET['h2']) && preg_match('/^\d{1,2}$/', (string)$_GET['h2']) && (int)$_GET['h2'] <= 24 ? (string)(int)$_GET['h2'] : '';
        if ($h1 === '' || $h2 === '') $h1 = $h2 = ''; $fam = isset(Inc::FAMILIES[(string)($_GET['family'] ?? '')]) ? (string)$_GET['family'] : '';
        $team = (int)($_GET['team_id'] ?? 0); $mine = IncEsc::userTeams((int)Auth::id()); $teamIds = $sc === null ? ($team ? [$team] : null) : ($team && in_array($team, $sc, true) ? [$team] : $sc);
        $keep = fn($e) => ($fam === '' || ($e['family'] ?? '') === $fam) && Inc::slotOk($e['started_at'], $h1, $h2, []);
        $w = 'e.escalated_at>=? AND e.escalated_at<=?'; $p = [$from . ' 00:00:00', $to . ' 23:59:59'];
        if ($teamIds !== null) { if (!$teamIds) $w .= ' AND 1=0'; else $w .= ' AND e.team_id IN (' . implode(',', array_map('intval', $teamIds)) . ')'; }
        $rows = array_values(array_filter(DB::all("SELECT e.*, i.reference, i.title, i.severity, i.family, i.service, i.status AS istatus, i.started_at, i.resolved_at, i.lost_hours, t.name AS team_name FROM inc_escalations e JOIN inc_incidents i ON i.id=e.incident_id JOIN inc_support_teams t ON t.id=e.team_id WHERE $w ORDER BY e.escalated_at DESC", $p), $keep));
        $stats = IncEsc::stats($from, $to, $teamIds, fn($e) => $keep($e + ['family' => (string)DB::val('SELECT family FROM inc_incidents WHERE id=?', [(int)$e['incident_id']])]));
        $this->view('support/index', ['title' => 'Espace support', 'rows' => $rows, 'stats' => $stats, 'from' => $from, 'to' => $to, 'h1' => $h1, 'h2' => $h2, 'family' => $fam, 'team' => $team, 'all' => $sc === null,
            'teams' => $sc === null ? DB::all('SELECT id, name FROM inc_support_teams ORDER BY name') : ($sc ? DB::all('SELECT id, name FROM inc_support_teams WHERE id IN (' . implode(',', array_map('intval', $sc)) . ') ORDER BY name') : []), 'mine' => $mine]);
    }
    function show(string $id): void {
        $i = DB::one('SELECT * FROM inc_incidents WHERE id=?', [(int)$id]); if (!$i || !$this->sees((int)$i['id'])) { $this->notFound(); return; }
        $sc = $this->scope(); $w = $sc === null ? '' : ' AND e.team_id IN (' . implode(',', array_map('intval', $sc ?: [0])) . ')';
        $this->view('support/show', ['title' => $i['reference'], 'i' => $i, 'files' => DB::all('SELECT * FROM inc_files WHERE incident_id=? ORDER BY id', [(int)$i['id']]), 'escs' => DB::all("SELECT e.*, t.name AS team_name, u.name AS by_name FROM inc_escalations e JOIN inc_support_teams t ON t.id=e.team_id LEFT JOIN users u ON u.id=e.acked_by WHERE e.incident_id=?$w ORDER BY e.id", [(int)$i['id']]),
            'events' => DB::all('SELECT * FROM inc_events WHERE incident_id=? ORDER BY created_at DESC, id DESC', [(int)$i['id']]), 'cat' => $i['category_id'] ? DB::val('SELECT label FROM inc_categories WHERE id=?', [(int)$i['category_id']]) : null]);
    }
    private function esc(string $id): ?array {
        $i = DB::one('SELECT * FROM inc_incidents WHERE id=?', [(int)$id]); if (!$i || !$this->sees((int)$i['id'])) { $this->notFound(); return null; }
        $e = DB::one('SELECT * FROM inc_escalations WHERE id=? AND incident_id=?', [(int)$this->in('esc_id'), (int)$i['id']]); if (!$e) { $this->notFound(); return null; }
        $sc = $this->scope(); if ($sc !== null && !in_array((int)$e['team_id'], $sc, true)) { $this->forbidden(); return null; }
        return [$i, $e];
    }
    function ack(string $id): void {
        $r = $this->esc($id); if (!$r) return; [$i, $e] = $r;
        if ($e['status'] === 'pending') { IncEsc::ack((int)$e['id'], (int)Auth::id()); Audit::log('update', 'inc_escalation', $e['id'], ['status' => 'pending'], ['status' => 'ack']); flash('Prise en compte enregistrée.'); }
        redirect('support/incidents/' . $id);
    }
    function feedback(string $id): void {
        $r = $this->esc($id); if (!$r) return; [$i, $e] = $r;
        $st = (string)$this->in('status'); $txt = trim((string)$this->in('feedback')); $cc = (string)$this->in('cause_code'); $ct = trim((string)$this->in('cause_text'));
        if (!in_array($st, ['working', 'done', 'declined'], true)) { flash('Choisissez le type de retour.', 'danger'); redirect('support/incidents/' . $id); }
        if (mb_strlen($txt) < 5) { flash('Décrivez votre retour (5 caractères minimum).', 'danger'); redirect('support/incidents/' . $id); }
        if ($cc !== '' && !isset(Inc::ROOT[$cc])) $cc = '';
        if ($st === 'done' && $cc === '' && $ct === '') { flash('Pour clore votre retour, indiquez au moins la cause identifiée (ou « Cause non déterminée »).', 'danger'); redirect('support/incidents/' . $id); }
        $team = (string)DB::val('SELECT name FROM inc_support_teams WHERE id=?', [(int)$e['team_id']]); $who = (string)Auth::user()['name']; $now = now();
        $upd = ['status' => $st, 'feedback' => mb_substr(trim((string)$e['feedback'] . "\n[" . dt($now) . ' · ' . $who . '] ' . $txt), 0, 8000)];
        if ($e['status'] === 'pending') { $upd['acked_at'] = $now; $upd['acked_by'] = (int)Auth::id(); }
        if ($cc !== '') $upd['cause_code'] = $cc; if ($ct !== '') $upd['cause_text'] = mb_substr($ct, 0, 4000);
        if ($st !== 'working') $upd['done_at'] = $now; else $upd['done_at'] = null;
        DB::update('inc_escalations', $upd, 'id=?', [(int)$e['id']]);
        Inc::event((int)$i['id'], 'support', ['working' => 'Point d\'avancement', 'done' => 'Retour final', 'declined' => 'Hors périmètre'][$st] . ' de « ' . $team . ' » : ' . mb_substr($txt, 0, 600) . ($cc !== '' ? ' — Cause proposée : ' . Inc::ROOT[$cc] : ''), (int)Auth::id());
        DB::update('inc_incidents', ['updated_at' => $now], 'id=?', [(int)$i['id']]);
        IncEsc::tell($i, ($st === 'declined' ? 'Hors périmètre · ' : ($st === 'done' ? 'Retour final · ' : 'Avancement · ')) . $i['reference'], $team . ' : ' . mb_substr($txt, 0, 140));
        Audit::log('update', 'inc_escalation', $e['id'], ['status' => $e['status']], ['status' => $st]); flash('Retour enregistré et transmis aux responsables de l\'incident.'); redirect('support/incidents/' . $id);
    }
}
