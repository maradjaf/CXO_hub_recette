<?php
namespace App\Controllers;
use App\Core\{Controller, DB, QaDash};
/** Tableau de bord qualité CXO : évolutions hebdomadaires, mensuelles, trimestrielles et annuelles (graphiques 1 à 6) et tableaux récapitulatifs. */
class QaDashboardController extends Controller {
    function index(): void {
        $g = (string)$this->in('gran'); if (!isset(QaDash::GRAN[$g])) $g = 'week';
        [$df, $dt] = QaDash::defaults($g);
        $ok = fn($v) => is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $v) && strtotime($v) !== false;
        $from = $ok($this->in('from')) ? $this->in('from') : $df; $to = $ok($this->in('to')) ? $this->in('to') : $dt;
        if ($from > $to) [$from, $to] = [$to, $from]; if (strtotime($to) - strtotime($from) > 366 * 5 * 86400) $from = date('Y-m-d', strtotime($to . ' -5 years'));
        $office = in_array($this->in('office'), ['FO', 'BO', 'SUP'], true) ? $this->in('office') : ''; $team = (int)$this->in('team_id') ?: 0; $team2 = (int)$this->in('team_id2') ?: 0; $tids = array_values(array_unique(array_filter([$team, $team2])));
        $f = ['gran' => $g, 'from' => $from, 'to' => $to, 'office' => $office, 'team_id' => $tids[0] ?? 0, 'team_id2' => $tids[1] ?? 0, 'team_ids' => $tids];
        $D = QaDash::build($f);
        if ($this->in('export') === 'csv') {
            $rows = []; foreach ($D['team'] as $name => $byP) $rows[] = array_merge([$name], array_map(fn($k) => $byP[$k] === null ? '' : number_format($byP[$k], 2, ',', ''), $D['pk']));
            $rows[] = array_merge(['Moyenne CXO'], array_map(fn($k) => $D['avg'][$k] === null ? '' : number_format($D['avg'][$k], 2, ',', ''), $D['pk']));
            csv_download('scores_qualite_' . $g . '_' . $from . '_' . $to . '.csv', array_merge(['Activité'], array_values($D['per'])), $rows);
        }
        $this->view('qa/dashboard', ['title' => 'Tableau de bord qualité CXO', 'f' => $f, 'D' => $D, 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name')]);
    }
}
