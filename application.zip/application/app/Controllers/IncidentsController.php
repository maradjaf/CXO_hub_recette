<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Settings, Inc, IncEsc};

/**
 * Gestion des incidents : déclaration, cycle de vie, impacts sur la productivité, cause racine et actions, tableau de bord expert,
 * aide au redimensionnement et paramétrage. Voir app/Core/Inc.php pour les règles de calcul.
 */
class IncidentsController extends Controller {
    // ------------------------------------------------------------------ Outils
    private function get(string $id): ?array { $i = DB::one('SELECT * FROM inc_incidents WHERE id=?', [(int)$id]); if (!$i) return null; if (!can('inc.view') && (int)$i['reporter_id'] !== (int)Auth::id()) return null; return $i; }
    private function ts(?string $v): ?string {
        $v = trim((string)$v); if ($v === '') return null; $t = strtotime(str_replace('T', ' ', $v)); return $t ? date('Y-m-d H:i:s', $t) : null;
    }
    private function intIn(string $k, int $min = 0, int $max = 100000000): int { return max($min, min($max, (int)preg_replace('/[^\d-]/', '', (string)$this->in($k, 0)))); }
    private function period(): array {
        $to = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($_GET['to'] ?? '')) ? $_GET['to'] : date('Y-m-d');
        $from = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($_GET['from'] ?? '')) ? $_GET['from'] : date('Y-m-d', strtotime($to . ' -89 days'));
        if ($from > $to) [$from, $to] = [$to, $from];
        return [$from, $to];
    }
    private function filters(): array {
        [$from, $to] = $this->period(); $f = ['from' => $from, 'to' => $to];
        foreach (['family', 'service', 'severity', 'team_id', 'channel_id', 'store_id', 'category_id'] as $k) $f[$k] = trim((string)($_GET[$k] ?? ''));
        if ($f['family'] !== '' && !isset(Inc::FAMILIES[$f['family']])) $f['family'] = '';
        if ($f['service'] !== '' && !isset(Inc::SERVICES[$f['service']])) $f['service'] = '';
        if ($f['severity'] !== '' && $f['severity'] !== 'P12' && !isset(Inc::SEV[$f['severity']])) $f['severity'] = '';
        return $f + $this->slot($_GET) + ['outage' => in_array((string)($_GET['outage'] ?? ''), ['0', '1'], true) ? (string)$_GET['outage'] : ''];
    }
    /** Créneau horaire (h1 → h2) et jours de semaine, depuis un tableau de paramètres. */
    private function slot(array $src): array {
        $h = fn($k, $max) => isset($src[$k]) && preg_match('/^\d{1,2}$/', (string)$src[$k]) && (int)$src[$k] <= $max ? (string)(int)$src[$k] : '';
        $h1 = $h('h1', 23); $h2 = $h('h2', 24); if ($h1 === '' || $h2 === '') { $h1 = $h2 = ''; }
        $d = Inc::dowList(is_array($src['dow'] ?? null) ? implode(',', $src['dow']) : ($src['dow'] ?? ''));
        return ['h1' => $h1, 'h2' => $h2, 'dow' => count($d) === 7 ? '' : implode(',', $d)];
    }
    private function lookups(): array {
        return ['teams' => Inc::teams(), 'channels' => DB::all('SELECT id, name FROM channels WHERE active=1 ORDER BY name'), 'stores' => DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name'),
                'cats' => DB::all('SELECT * FROM inc_categories WHERE active=1 ORDER BY sort_order, label')];
    }
    static function handlers(): array {
        return DB::all("SELECT DISTINCT u.id, u.name FROM users u JOIN user_roles ur ON ur.user_id=u.id JOIN roles r ON r.id=ur.role_id LEFT JOIN role_permissions rp ON rp.role_id=r.id LEFT JOIN permissions p ON p.id=rp.permission_id WHERE u.status='active' AND (r.code='admin' OR p.code='inc.manage') ORDER BY u.name");
    }

    // ------------------------------------------------------------------ Registre
    function index(): void {
        Inc::refreshOpen(); $f = $this->filters(); $q = trim((string)($_GET['q'] ?? '')); $st = (string)($_GET['status'] ?? '');
        $f2 = $f; if (empty($_GET['from']) && empty($_GET['to'])) { $f2['from'] = ''; $f2['to'] = ''; }
        [$w, $p] = Inc::where($f2, 'i');
        if (!can('inc.view') || ($_GET['mine'] ?? '') === '1') { $w .= ' AND i.reporter_id=?'; $p[] = (int)Auth::id(); }
        if ($st === 'open') $w .= " AND i.status IN ('new','ack','diag','mitigated')"; elseif (isset(Inc::STATUS[$st])) { $w = preg_replace("/i\.status<>'cancelled'/", '1=1', $w, 1); $w .= ' AND i.status=?'; $p[] = $st; }
        if ($q !== '') { $w .= ' AND (i.reference LIKE ? OR i.title LIKE ? OR i.vendor LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        if (($_GET['major'] ?? '') === '1') $w .= ' AND i.major=1';
        if (($_GET['recurring'] ?? '') === '1') $w .= ' AND i.recurring=1';
        if (($_GET['norca'] ?? '') === '1') $w .= " AND i.rca_done=0 AND i.severity IN ('P1','P2') AND i.status IN ('resolved','closed')";
        if (($_GET['late'] ?? '') === '1') {   // SLA de rétablissement dépassé : calculé à partir de l'échéance par gravité
            $ids = []; foreach (DB::all("SELECT * FROM inc_incidents i WHERE $w", $p) as $r) { $s = Inc::slaState($r); if ($s['res_late'] || $s['ack_late'] || $s['res_ok'] === false) $ids[] = (int)$r['id']; }
            $w .= $ids ? ' AND i.id IN (' . implode(',', $ids) . ')' : ' AND 1=0';
        }
        $pg = paginate("inc_incidents i LEFT JOIN users u ON u.id=i.reporter_id LEFT JOIN users o ON o.id=i.owner_id LEFT JOIN stores s ON s.id=i.store_id WHERE $w", $p, $this->page(), 25, 'i.*, u.name AS reporter, o.name AS owner_name, s.name AS store_name', 'i.started_at DESC, i.id DESC');
        if (($_GET['export'] ?? '') === 'csv' && can('inc.view')) { $this->csv("SELECT i.* FROM inc_incidents i WHERE $w ORDER BY i.started_at DESC", $p); }
        $this->view('incidents/index', ['title' => 'Registre des incidents', 'p' => $pg, 'f' => $f, 'q' => $q, 'st' => $st] + $this->lookups());
    }

    private function csv(string $sql, array $p): never {
        $cat = array_column(DB::all('SELECT id, label FROM inc_categories'), 'label', 'id'); $team = array_column(DB::all('SELECT id, name FROM teams'), 'name', 'id'); $rows = [];
        foreach (DB::all($sql, $p) as $r) {
            $imp = DB::all('SELECT team_id FROM inc_impacts WHERE incident_id=?', [(int)$r['id']]);
            $rows[] = [$r['reference'], $r['title'], Inc::FAMILIES[$r['family']] ?? $r['family'], $cat[$r['category_id']] ?? '', Inc::SERVICES[$r['service']] ?? $r['service'], $r['severity'], Inc::STATUS[$r['status']] ?? $r['status'], $r['outage'] ? 'Oui' : 'Non',
                $r['started_at'], $r['detected_at'], $r['acked_at'], $r['resolved_at'], $r['closed_at'], $r['duration_min'], implode(', ', array_filter(array_map(fn($x) => $team[$x['team_id']] ?? '', $imp))), $r['agents_impacted'], $r['lost_hours'],
                $r['customers_impacted'], $r['tx_failed'], $r['calls_lost'], $r['revenue_loss'], Inc::ROOT[$r['root_cause']] ?? '', $r['vendor'], $r['recurring'] ? 'Oui' : 'Non'];
        }
        Audit::log('export', 'incidents', null, null, ['rows' => count($rows)]);
        csv_download('incidents_' . date('Ymd_His') . '.csv', ['Référence', 'Titre', 'Famille', 'Catégorie', 'Service', 'Gravité', 'Statut', 'Panne totale', 'Début', 'Détection', 'Prise en charge', 'Rétablissement', 'Clôture', 'Durée (min)', 'Équipes impactées', 'Agents impactés', 'Heures-agent perdues', 'Clients impactés', 'Transactions échouées', 'Appels perdus', 'Perte de revenu', 'Cause racine', 'Fournisseur', 'Récurrent'], $rows);
    }

    // ------------------------------------------------------------------ Déclaration
    function create(): void {
        $this->view('incidents/form', ['title' => 'Déclarer un incident', 'now' => date('Y-m-d\TH:i')] + $this->lookups());
    }
    function store(): void {
        $mgr = can('inc.manage'); $err = [];
        $title = trim((string)$this->in('title')); $desc = trim((string)$this->in('description'));
        $cat = DB::one('SELECT * FROM inc_categories WHERE id=? AND active=1', [(int)$this->in('category_id')]);
        if ($title === '' ) $err[] = 'Le titre est obligatoire.'; if (mb_strlen($title) > 190) $err[] = 'Le titre est trop long (190 caractères).';
        if (!$cat) $err[] = 'Choisissez la catégorie de l\'incident.';
        if ($desc === '') $err[] = 'La description est obligatoire.';
        $start = $this->ts($this->in('started_at')) ?? date('Y-m-d H:i:s');
        if (strtotime($start) > time() + 300) $err[] = 'La date de début ne peut pas être dans le futur.';
        $impact = (string)$this->in('impact', 'medium'); $urg = (string)$this->in('urgency', 'medium');
        if (!isset(Inc::IMPACT[$impact]) || !isset(Inc::URGENCY[$urg])) $err[] = 'Impact ou urgence invalide.';
        $team = (int)$this->in('team_id', 0) ?: null; if ($team && !DB::val('SELECT 1 FROM teams WHERE id=?', [$team])) $err[] = 'Équipe inconnue.';
        $store = (int)$this->in('store_id', 0) ?: null; if ($store && !DB::val('SELECT 1 FROM stores WHERE id=?', [$store])) $err[] = 'Site ou boutique inconnu.';
        if ($err) { $this->back($err, $_POST, 'incidents/new'); }
        $sev = Inc::sev($impact, $urg); if ($mgr && isset(Inc::SEV[(string)$this->in('severity')])) $sev = (string)$this->in('severity');
        $service = isset(Inc::SERVICES[(string)$this->in('service')]) ? (string)$this->in('service') : (string)($cat['service'] ?: 'other');
        $detect = isset(Inc::DETECT[(string)$this->in('detection')]) ? (string)$this->in('detection') : ($mgr ? 'monitoring' : 'agent');
        $detected = $mgr ? ($this->ts($this->in('detected_at')) ?? now()) : now(); if (strtotime($detected) < strtotime($start)) $detected = $start;
        $chan = $team ? (int)DB::val('SELECT channel_id FROM teams WHERE id=?', [$team]) ?: null : null;
        $id = DB::insert('inc_incidents', ['reference' => Inc::ref(), 'title' => $title, 'description' => $desc, 'category_id' => (int)$cat['id'], 'family' => $cat['family'], 'service' => $service, 'severity' => $sev, 'impact' => $impact, 'urgency' => $urg,
            'status' => 'new', 'extent' => isset(Inc::EXTENT[(string)$this->in('extent')]) ? (string)$this->in('extent') : null, 'detection' => $detect, 'outage' => $this->in('outage') === '1' ? 1 : 0, 'major' => ($sev === 'P1' || ($mgr && $this->in('major') === '1')) ? 1 : 0,
            'recurring' => Inc::isRecurring((int)$cat['id'], $start) ? 1 : 0, 'store_id' => $store, 'team_id' => $team, 'channel_id' => $chan, 'location' => mb_substr(trim((string)$this->in('location')), 0, 150) ?: null,
            'started_at' => $start, 'detected_at' => $detected, 'customers_impacted' => $this->intIn('customers_impacted'), 'calls_lost' => $this->intIn('calls_lost'), 'tx_failed' => $this->intIn('tx_failed'),
            'revenue_loss' => $mgr ? max(0, (float)str_replace(',', '.', (string)$this->in('revenue_loss', 0))) : 0, 'vendor' => $mgr ? (mb_substr(trim((string)$this->in('vendor')), 0, 120) ?: null) : null, 'vendor_ref' => $mgr ? (mb_substr(trim((string)$this->in('vendor_ref')), 0, 60) ?: null) : null,
            'reporter_id' => Auth::id(), 'agents_impacted' => 0, 'lost_hours' => 0, 'duration_min' => 0, 'user_minutes' => 0, 'created_at' => now(), 'updated_at' => now()]);
        if ($team) {
            $heads = Inc::headcount()[$team] ?? 0; $ag = trim((string)$this->in('agents_impacted')) === '' ? $heads : $this->intIn('agents_impacted', 0, 5000);
            if ($ag > 0) DB::insert('inc_impacts', ['incident_id' => $id, 'team_id' => $team, 'channel_id' => $chan, 'agents_impacted' => $ag, 'capacity_loss_pct' => $this->intIn('capacity_loss_pct', 1, 100) ?: 100]);
        }
        Inc::event($id, 'system', 'Incident déclaré (' . Inc::SEV[$sev] . ', ' . (Inc::SERVICES[$service] ?? $service) . ').');
        Inc::refresh($id); Audit::log('create', 'incident', $id, null, ['title' => $title, 'severity' => $sev]);
        $ref = (string)DB::val('SELECT reference FROM inc_incidents WHERE id=?', [$id]);
        if (in_array($sev, ['P1', 'P2'], true)) Notifier::toPermission('inc.manage', ($sev === 'P1' ? 'INCIDENT CRITIQUE · ' : 'Incident majeur · ') . $ref, $title, '/incidents/' . $id);
        [$nf, $ferr] = IncFilesController::save($id);
        $ne = IncEsc::autoOpen(DB::one('SELECT * FROM inc_incidents WHERE id=?', [$id]));
        flash('Incident ' . $ref . ' déclaré (' . Inc::SEV[$sev] . ').' . ($ne ? " Escalade automatique : $ne équipe(s) support notifiée(s)." : '') . ($nf ? " $nf pièce(s) jointe(s) enregistrée(s)." : '') . ($ferr ? ' ' . implode(' ', $ferr) : ''), $ferr ? 'warning' : 'success'); redirect('incidents/' . $id);
    }

    // ------------------------------------------------------------------ Fiche
    function show(string $id): void {
        $i = $this->get($id); if (!$i) { $this->notFound(); return; }
        Inc::refresh((int)$i['id']); $i = DB::one('SELECT * FROM inc_incidents WHERE id=?', [(int)$i['id']]);
        $imps = DB::all('SELECT x.*, t.name AS team_name, c.name AS channel_name FROM inc_impacts x LEFT JOIN teams t ON t.id=x.team_id LEFT JOIN channels c ON c.id=x.channel_id WHERE x.incident_id=? ORDER BY x.id', [(int)$i['id']]);
        $escs = can('inc.view') ? DB::all('SELECT e.*, t.name AS team_name, u.name AS by_name FROM inc_escalations e JOIN inc_support_teams t ON t.id=e.team_id LEFT JOIN users u ON u.id=e.acked_by WHERE e.incident_id=? ORDER BY e.id', [(int)$i['id']]) : [];
        $similar = $i['category_id'] ? DB::all("SELECT id, reference, title, started_at, severity, status FROM inc_incidents WHERE category_id=? AND id<>? AND status<>'cancelled' AND started_at>=? ORDER BY started_at DESC LIMIT 6", [(int)$i['category_id'], (int)$i['id'], date('Y-m-d H:i:s', time() - 90 * 86400)]) : [];
        $this->view('incidents/show', ['title' => $i['reference'], 'i' => $i, 'imps' => $imps, 'events' => DB::all('SELECT * FROM inc_events WHERE incident_id=? ORDER BY created_at DESC, id DESC', [(int)$i['id']]),
            'actions' => DB::all('SELECT a.*, u.name AS owner_name FROM inc_actions a LEFT JOIN users u ON u.id=a.owner_id WHERE a.incident_id=? ORDER BY a.status, a.due_date', [(int)$i['id']]), 'similar' => $similar,
            'cat' => $i['category_id'] ? DB::one('SELECT * FROM inc_categories WHERE id=?', [(int)$i['category_id']]) : null, 'reporter' => DB::val('SELECT name FROM users WHERE id=?', [(int)$i['reporter_id']]),
            'owner' => $i['owner_id'] ? DB::val('SELECT name FROM users WHERE id=?', [(int)$i['owner_id']]) : null, 'mgr' => can('inc.manage'), 'handlers' => can('inc.manage') ? self::handlers() : [],
            'files' => DB::all('SELECT * FROM inc_files WHERE incident_id=? ORDER BY id', [(int)$i['id']]), 'escs' => $escs, 'proposed' => (string)(array_values(array_filter(array_column($escs, 'cause_code')))[0] ?? ''), 'steams' => DB::all('SELECT id, name FROM inc_support_teams WHERE active=1 ORDER BY sort_order, name'), 'suggest' => IncEsc::teamsFor((string)$i['family'])] + $this->lookups());
    }
    function comment(string $id): void {
        $i = $this->get($id); if (!$i) { $this->notFound(); return; }
        $t = trim((string)$this->in('body')); if ($t === '') { flash('Écrivez un message.', 'danger'); redirect('incidents/' . $id); }
        Inc::event((int)$i['id'], 'comment', $t); DB::update('inc_incidents', ['updated_at' => now()], 'id=?', [(int)$i['id']]);
        if ($i['owner_id'] && (int)$i['owner_id'] !== (int)Auth::id()) Notifier::send((int)$i['owner_id'], 'Nouveau message · ' . $i['reference'], mb_substr($t, 0, 140), '/incidents/' . $i['id']);
        flash('Message ajouté.'); redirect('incidents/' . $id . '#timeline');
    }
    function status(string $id): void {
        $i = $this->get($id); if (!$i || !can('inc.manage')) { $this->notFound(); return; }
        $to = (string)$this->in('status'); $from = (string)$i['status'];
        if (!in_array($to, Inc::TRANS[$from] ?? [], true)) { flash('Ce changement de statut n\'est pas autorisé.', 'danger'); redirect('incidents/' . $id); }
        $comment = trim((string)$this->in('comment')); $at = $this->ts($this->in('at')) ?? now();
        if (strtotime($at) > time() + 60) { flash('La date ne peut pas être dans le futur.', 'danger'); redirect('incidents/' . $id); }
        if (strtotime($at) < strtotime($i['started_at'])) { flash('La date ne peut pas précéder le début de l\'incident.', 'danger'); redirect('incidents/' . $id); }
        $u = ['status' => $to, 'updated_at' => now()];
        if ($to === 'resolved') {
            $res = trim((string)$this->in('resolution')) ?: $comment; if ($res === '' && !$i['resolution']) { flash('Indiquez comment le service a été rétabli.', 'danger'); redirect('incidents/' . $id); }
            if ($res !== '') $u['resolution'] = $res; $u['resolved_at'] = $at; if (!$i['acked_at']) $u['acked_at'] = $at;
        }
        if ($to === 'closed') {
            if (in_array($i['severity'], ['P1', 'P2'], true) && !$i['rca_done']) { flash('Un incident P1/P2 ne peut être clos qu\'après son analyse de cause racine (post-mortem).', 'danger'); redirect('incidents/' . $id); }
            $u['closed_at'] = $at;
        }
        if ($to === 'ack') { $u['acked_at'] = $i['acked_at'] ?: $at; }
        if (in_array($to, ['diag', 'mitigated'], true) && !$i['acked_at']) $u['acked_at'] = $at;
        if ($to === 'mitigated') $u['mitigated_at'] = $at;
        if ($to === 'diag' && in_array($from, ['resolved', 'closed'], true)) { $u['resolved_at'] = null; $u['closed_at'] = null; }   // réouverture
        if ($to === 'cancelled') { $u['resolved_at'] = null; }
        if ($to === 'new') { $u['acked_at'] = null; }
        if (!$i['owner_id'] && in_array($to, ['ack', 'diag'], true)) $u['owner_id'] = Auth::id();
        DB::update('inc_incidents', $u, 'id=?', [(int)$i['id']]);
        Inc::event((int)$i['id'], 'status', 'Statut : ' . Inc::STATUS[$from] . ' → ' . Inc::STATUS[$to] . ($comment !== '' ? ' — ' . $comment : ''), null, now());
        Inc::refresh((int)$i['id']); Audit::log('status', 'incident', $i['id'], ['status' => $from], ['status' => $to]);
        if ($to === 'resolved' && $i['reporter_id'] && (int)$i['reporter_id'] !== (int)Auth::id()) Notifier::send((int)$i['reporter_id'], 'Service rétabli · ' . $i['reference'], $i['title'], '/incidents/' . $i['id']);
        flash('Statut mis à jour : ' . Inc::STATUS[$to] . '.'); redirect('incidents/' . $id);
    }
    function assign(string $id): void {
        $i = $this->get($id); if (!$i || !can('inc.manage')) { $this->notFound(); return; }
        $o = (int)$this->in('owner_id', 0) ?: null; if ($o && !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$o])) { flash('Utilisateur inconnu.', 'danger'); redirect('incidents/' . $id); }
        DB::update('inc_incidents', ['owner_id' => $o, 'updated_at' => now()], 'id=?', [(int)$i['id']]);
        Inc::event((int)$i['id'], 'system', $o ? 'Responsable : ' . DB::val('SELECT name FROM users WHERE id=?', [$o]) : 'Responsable retiré.');
        if ($o && $o !== (int)Auth::id()) Notifier::send($o, 'Incident affecté · ' . $i['reference'], $i['title'], '/incidents/' . $i['id']);
        flash('Responsable enregistré.'); redirect('incidents/' . $id);
    }
    function update(string $id): void {
        $i = $this->get($id); if (!$i || !can('inc.manage')) { $this->notFound(); return; }
        $title = trim((string)$this->in('title')); if ($title === '') { flash('Le titre est obligatoire.', 'danger'); redirect('incidents/' . $id); }
        $cat = DB::one('SELECT * FROM inc_categories WHERE id=?', [(int)$this->in('category_id')]);
        $impact = (string)$this->in('impact', $i['impact']); $urg = (string)$this->in('urgency', $i['urgency']); if (!isset(Inc::IMPACT[$impact]) || !isset(Inc::URGENCY[$urg])) { flash('Impact ou urgence invalide.', 'danger'); redirect('incidents/' . $id); }
        $sev = isset(Inc::SEV[(string)$this->in('severity')]) ? (string)$this->in('severity') : Inc::sev($impact, $urg);
        $start = $this->ts($this->in('started_at')) ?? $i['started_at']; if (strtotime($start) > time() + 300) { flash('La date de début ne peut pas être dans le futur.', 'danger'); redirect('incidents/' . $id); }
        $u = ['title' => mb_substr($title, 0, 190), 'description' => trim((string)$this->in('description')), 'category_id' => $cat ? (int)$cat['id'] : $i['category_id'], 'family' => $cat ? $cat['family'] : $i['family'],
            'service' => isset(Inc::SERVICES[(string)$this->in('service')]) ? (string)$this->in('service') : $i['service'], 'impact' => $impact, 'urgency' => $urg, 'severity' => $sev,
            'extent' => isset(Inc::EXTENT[(string)$this->in('extent')]) ? (string)$this->in('extent') : $i['extent'], 'detection' => isset(Inc::DETECT[(string)$this->in('detection')]) ? (string)$this->in('detection') : $i['detection'],
            'outage' => $this->in('outage') === '1' ? 1 : 0, 'major' => ($sev === 'P1' || $this->in('major') === '1') ? 1 : 0, 'store_id' => (int)$this->in('store_id', 0) ?: null, 'location' => mb_substr(trim((string)$this->in('location')), 0, 150) ?: null,
            'started_at' => $start, 'detected_at' => $this->ts($this->in('detected_at')) ?? $i['detected_at'], 'customers_impacted' => $this->intIn('customers_impacted'), 'calls_lost' => $this->intIn('calls_lost'), 'tx_failed' => $this->intIn('tx_failed'),
            'revenue_loss' => max(0, (float)str_replace(',', '.', (string)$this->in('revenue_loss', 0))), 'vendor' => mb_substr(trim((string)$this->in('vendor')), 0, 120) ?: null, 'vendor_ref' => mb_substr(trim((string)$this->in('vendor_ref')), 0, 60) ?: null,
            'workaround' => trim((string)$this->in('workaround')) ?: null, 'problem_ref' => mb_substr(trim((string)$this->in('problem_ref')), 0, 60) ?: null, 'updated_at' => now()];
        $u['recurring'] = Inc::isRecurring($u['category_id'] ? (int)$u['category_id'] : null, $start, (int)$i['id']) ? 1 : 0;
        DB::update('inc_incidents', $u, 'id=?', [(int)$i['id']]); Inc::refresh((int)$i['id']);
        Inc::event((int)$i['id'], 'system', 'Fiche modifiée.'); Audit::log('update', 'incident', $i['id'], $i, $u);
        if ($sev !== $i['severity']) IncEsc::autoOpen(DB::one('SELECT * FROM inc_incidents WHERE id=?', [(int)$i['id']])); flash('Fiche enregistrée.'); redirect('incidents/' . $id);
    }

    // ------------------------------------------------------------------ Impacts, cause racine, actions
    function impactAdd(string $id): void {
        $i = $this->get($id); if (!$i || !can('inc.manage')) { $this->notFound(); return; }
        $team = (int)$this->in('team_id', 0); $t = $team ? DB::one('SELECT * FROM teams WHERE id=?', [$team]) : null;
        if (!$t) { flash('Choisissez l\'équipe impactée.', 'danger'); redirect('incidents/' . $id); }
        $ag = trim((string)$this->in('agents_impacted')) === '' ? (Inc::headcount()[$team] ?? 0) : $this->intIn('agents_impacted', 0, 5000);
        $a = $this->ts($this->in('started_at')); $b = $this->ts($this->in('ended_at'));
        if ($a && $b && strtotime($b) < strtotime($a)) { flash('La fin de l\'impact précède son début.', 'danger'); redirect('incidents/' . $id); }
        DB::insert('inc_impacts', ['incident_id' => (int)$i['id'], 'team_id' => $team, 'channel_id' => $t['channel_id'] ?: null, 'agents_impacted' => $ag, 'capacity_loss_pct' => $this->intIn('capacity_loss_pct', 1, 100) ?: 100, 'started_at' => $a, 'ended_at' => $b, 'note' => mb_substr(trim((string)$this->in('note')), 0, 300) ?: null]);
        if (!$i['team_id']) DB::update('inc_incidents', ['team_id' => $team, 'channel_id' => $t['channel_id'] ?: null], 'id=?', [(int)$i['id']]);
        Inc::refresh((int)$i['id']); Inc::event((int)$i['id'], 'impact', 'Impact ajouté : ' . $t['name'] . ', ' . $ag . ' agent(s), ' . $this->intIn('capacity_loss_pct', 1, 100) . ' % de capacité perdue.'); Audit::log('create', 'incident_impact', $i['id'], null, ['team' => $team]);
        flash('Impact ajouté.'); redirect('incidents/' . $id . '#impacts');
    }
    function impactDel(string $id, string $iid): void {
        $i = $this->get($id); if (!$i || !can('inc.manage')) { $this->notFound(); return; }
        DB::exec('DELETE FROM inc_impacts WHERE id=? AND incident_id=?', [(int)$iid, (int)$i['id']]); Inc::refresh((int)$i['id']); Inc::event((int)$i['id'], 'impact', 'Ligne d\'impact supprimée.'); flash('Impact supprimé.'); redirect('incidents/' . $id . '#impacts');
    }
    function rca(string $id): void {
        $i = $this->get($id); if (!$i || !can('inc.manage')) { $this->notFound(); return; }
        $rc = (string)$this->in('root_cause'); $txt = trim((string)$this->in('rca_text')); $done = $this->in('rca_done') === '1';
        if ($rc !== '' && !isset(Inc::ROOT[$rc])) { flash('Cause racine inconnue.', 'danger'); redirect('incidents/' . $id); }
        if ($done && ($rc === '' || $txt === '')) { flash('Pour valider l\'analyse, indiquez la catégorie de cause racine et l\'analyse (5 pourquoi, chronologie, enseignements).', 'danger'); redirect('incidents/' . $id . '#rca'); }
        DB::update('inc_incidents', ['root_cause' => $rc ?: null, 'rca_text' => $txt ?: null, 'rca_done' => $done ? 1 : 0, 'rca_at' => $done ? ($i['rca_at'] ?: now()) : null, 'problem_ref' => mb_substr(trim((string)$this->in('problem_ref')), 0, 60) ?: null, 'updated_at' => now()], 'id=?', [(int)$i['id']]);
        Inc::event((int)$i['id'], 'rca', $done ? 'Analyse de cause racine validée : ' . Inc::ROOT[$rc] . '.' : 'Analyse de cause racine enregistrée (brouillon).'); Audit::log('rca', 'incident', $i['id'], null, ['root_cause' => $rc, 'done' => $done]);
        flash($done ? 'Analyse validée.' : 'Brouillon enregistré.'); redirect('incidents/' . $id . '#rca');
    }
    function actionAdd(string $id): void {
        $i = $this->get($id); if (!$i || !can('inc.manage')) { $this->notFound(); return; }
        $t = trim((string)$this->in('title')); if ($t === '') { flash('Décrivez l\'action.', 'danger'); redirect('incidents/' . $id . '#actions'); }
        $due = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$this->in('due_date')) ? (string)$this->in('due_date') : null; $o = (int)$this->in('owner_id', 0) ?: null;
        $aid = DB::insert('inc_actions', ['incident_id' => (int)$i['id'], 'kind' => isset(Inc::ACTION_KIND[(string)$this->in('kind')]) ? (string)$this->in('kind') : 'corrective', 'title' => mb_substr($t, 0, 300), 'owner_id' => $o, 'due_date' => $due, 'status' => 'open', 'created_by' => Auth::id(), 'created_at' => now()]);
        if ($o && $o !== (int)Auth::id()) Notifier::send($o, 'Action à mener · ' . $i['reference'], $t, '/incidents/' . $i['id'] . '#actions');
        Inc::event((int)$i['id'], 'action', 'Action ajoutée : ' . $t); Audit::log('create', 'incident_action', $aid); flash('Action ajoutée.'); redirect('incidents/' . $id . '#actions');
    }
    function actionToggle(string $id, string $aid): void {
        $i = $this->get($id); if (!$i || !can('inc.manage')) { $this->notFound(); return; }
        $a = DB::one('SELECT * FROM inc_actions WHERE id=? AND incident_id=?', [(int)$aid, (int)$i['id']]); if (!$a) { $this->notFound(); return; }
        $done = $a['status'] === 'done'; DB::update('inc_actions', ['status' => $done ? 'open' : 'done', 'done_at' => $done ? null : now()], 'id=?', [(int)$aid]);
        Inc::event((int)$i['id'], 'action', ($done ? 'Action rouverte : ' : 'Action réalisée : ') . $a['title']); redirect('incidents/' . $id . '#actions');
    }
    function actionDel(string $id, string $aid): void {
        $i = $this->get($id); if (!$i || !can('inc.manage')) { $this->notFound(); return; }
        DB::exec('DELETE FROM inc_actions WHERE id=? AND incident_id=?', [(int)$aid, (int)$i['id']]); flash('Action supprimée.'); redirect('incidents/' . $id . '#actions');
    }

    // ------------------------------------------------------------------ Tableau de bord expert
    function dashboard(): void {
        Inc::refreshOpen(); $f = $this->filters(); $from = strtotime($f['from'] . ' 00:00:00'); $to = strtotime($f['to'] . ' 23:59:59');
        $rows = Inc::fetch($f); $K = Inc::kpis($rows, $from, $to);
        $len = $to - $from; $pf = $f; $pf['to'] = date('Y-m-d', $from - 86400); $pf['from'] = date('Y-m-d', $from - $len - 86400 + 86399);
        $prev = Inc::kpis(Inc::fetch($pf), strtotime($pf['from'] . ' 00:00:00'), strtotime($pf['to'] . ' 23:59:59'));
        $av = Inc::availability($rows, $from, $to); $S = Inc::sizing($rows, $from, $to, 0.9); $wk = Inc::weekly($rows, $from, $to);
        $cat = array_column(DB::all('SELECT id, label, code FROM inc_categories'), null, 'id'); $stores = array_column(DB::all('SELECT id, name FROM stores'), 'name', 'id');
        $open = [];
        foreach (DB::all("SELECT * FROM inc_incidents WHERE status IN ('new','ack','diag','mitigated') ORDER BY started_at") as $r) $open[] = $r;
        usort($open, fn($a, $b) => [$a['severity'], $a['started_at']] <=> [$b['severity'], $b['started_at']]);
        $aging = ['< 4 h' => 0, '4 à 24 h' => 0, '1 à 3 j' => 0, '3 à 7 j' => 0, '> 7 j' => 0]; $nowT = time();
        foreach ($open as $r) { $h = ($nowT - strtotime($r['started_at'])) / 3600; $aging[$h < 4 ? '< 4 h' : ($h < 24 ? '4 à 24 h' : ($h < 72 ? '1 à 3 j' : ($h < 168 ? '3 à 7 j' : '> 7 j')))]++; }
        $rcaDays = (int)Inc::num('inc.rca_days');
        $rcaLate = (int)DB::val("SELECT COUNT(*) FROM inc_incidents WHERE severity IN ('P1','P2') AND rca_done=0 AND status IN ('resolved','closed') AND resolved_at<?", [date('Y-m-d H:i:s', $nowT - $rcaDays * 86400)]);
        $actLate = (int)DB::val("SELECT COUNT(*) FROM inc_actions WHERE status='open' AND due_date<?", [date('Y-m-d')]);
        $vendors = []; foreach ($rows as $r) { $v = trim((string)$r['vendor']); if ($v === '') continue; $x = &$vendors[$v]; $x = $x ?? ['n' => 0, 'p12' => 0, 'lost' => 0.0, 'res' => []]; $x['n']++; $x['lost'] += (float)$r['lost_hours']; if (in_array($r['severity'], ['P1', 'P2'], true)) $x['p12']++; if ($r['resolved_at']) $x['res'][] = (strtotime($r['resolved_at']) - strtotime($r['started_at'])) / 60; unset($x); }
        uasort($vendors, fn($a, $b) => $b['lost'] <=> $a['lost']);
        $top = $rows; usort($top, fn($a, $b) => (float)$b['lost_hours'] <=> (float)$a['lost_hours']); $top = array_slice(array_filter($top, fn($r) => (float)$r['lost_hours'] > 0), 0, 8);
        $this->view('incidents/dashboard', ['title' => 'Tableau de bord des incidents', 'f' => $f, 'rows' => $rows, 'K' => $K, 'P' => $prev, 'av' => $av, 'S' => $S, 'wk' => $wk, 'cat' => $cat, 'storeNames' => $stores, 'open' => $open, 'aging' => $aging,
            'rcaLate' => $rcaLate, 'actLate' => $actLate, 'vendors' => $vendors, 'top' => $top, 'fromTs' => $from, 'toTs' => $to] + $this->lookups());
    }

    // ------------------------------------------------------------------ Comparaison de périodes (2 à 5), avec créneaux horaires propres à chaque période
    function compare(): void {
        Inc::refreshOpen(); $shared = [];
        foreach (['family', 'service', 'severity', 'team_id', 'channel_id', 'category_id'] as $k) $shared[$k] = trim((string)($_GET[$k] ?? ''));
        if ($shared['family'] !== '' && !isset(Inc::FAMILIES[$shared['family']])) $shared['family'] = '';
        if ($shared['service'] !== '' && !isset(Inc::SERVICES[$shared['service']])) $shared['service'] = '';
        if ($shared['severity'] !== '' && $shared['severity'] !== 'P12' && !isset(Inc::SEV[$shared['severity']])) $shared['severity'] = '';
        $shared['outage'] = in_array((string)($_GET['outage'] ?? ''), ['0', '1'], true) ? (string)$_GET['outage'] : '';
        $okd = fn($v) => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$v) && strtotime((string)$v) !== false;
        $ps = []; $notice = '';
        foreach (array_slice(is_array($_GET['p'] ?? null) ? array_values($_GET['p']) : [], 0, 5) as $i => $q) {
            if (!is_array($q) || !$okd($q['from'] ?? '') || !$okd($q['to'] ?? '')) continue;
            $a = $q['from']; $b = $q['to']; if ($a > $b) [$a, $b] = [$b, $a];
            $ps[] = ['label' => mb_substr(trim((string)($q['label'] ?? '')), 0, 40) ?: 'Période ' . chr(65 + count($ps)), 'from' => $a, 'to' => $b] + $this->slot($q);
        }
        if (count($ps) < 2) {
            if (!empty($_GET['p'])) $notice = 'Renseignez au moins deux périodes complètes (dates de début et de fin).';
            $today = date('Y-m-d'); $ps = [['label' => '30 derniers jours', 'from' => date('Y-m-d', strtotime('-29 days')), 'to' => $today, 'h1' => '', 'h2' => '', 'dow' => ''],
                ['label' => '30 jours précédents', 'from' => date('Y-m-d', strtotime('-59 days')), 'to' => date('Y-m-d', strtotime('-30 days')), 'h1' => '', 'h2' => '', 'dow' => '']];
        }
        $res = [];
        foreach ($ps as $P) {
            $f = $shared + $P; $rows = Inc::fetch($f); $from = strtotime($P['from'] . ' 00:00:00'); $to = strtotime($P['to'] . ' 23:59:59'); $K = Inc::kpis($rows, $from, $to);
            $dow = Inc::dowList($P['dow']); $cal = 0; for ($d = $from; $d <= $to; $d += 86400) if (!$dow || in_array((int)date('N', $d), $dow, true)) $cal++; $cal = max(1, $cal);
            $hour = array_fill(0, 24, 0); $wd = array_fill(1, 7, 0); $fam = []; $sev = ['P1' => 0, 'P2' => 0, 'P3' => 0, 'P4' => 0]; $root = [];
            foreach ($rows as $r) { $ts = strtotime($r['started_at']); $hour[(int)date('G', $ts)]++; $wd[(int)date('N', $ts)]++; $fam[$r['family']] = ($fam[$r['family']] ?? 0) + 1; if (isset($sev[$r['severity']])) $sev[$r['severity']]++; if ($r['rca_done'] && $r['root_cause']) $root[$r['root_cause']] = ($root[$r['root_cause']] ?? 0) + 1; }
            $K['cal'] = $cal; $K['per_day'] = $K['n'] / $cal; $K['lost_day'] = $K['lost'] / max(1, $K['days']);
            $res[] = ['P' => $P, 'K' => $K, 'hour' => $hour, 'wd' => $wd, 'fam' => $fam, 'sev' => $sev, 'root' => $root, 'slot' => Inc::slotLabel($P)];
        }
        $this->view('incidents/compare', ['title' => 'Comparaison de périodes', 'res' => $res, 'shared' => $shared, 'notice' => $notice] + $this->lookups());
    }

    function staffing(): void {
        Inc::refreshOpen(); $f = $this->filters(); $cov = (float)($_GET['cov'] ?? 90); $cov = in_array((int)$cov, [50, 75, 80, 90, 95, 100], true) ? $cov / 100 : 0.9;
        $from = strtotime($f['from'] . ' 00:00:00'); $to = strtotime($f['to'] . ' 23:59:59'); $rows = Inc::fetch($f); $S = Inc::sizing($rows, $from, $to, $cov);
        if (($_GET['export'] ?? '') === 'csv') {
            Audit::log('export', 'incident_sizing');
            csv_download('redimensionnement_' . date('Ymd') . '.csv', ['Équipe', 'Canal', 'Effectif', 'Incidents', 'Heures-agent perdues', '% capacité perdue', 'FTE perdus (moyenne/jour)', 'FTE perdus (pic)', 'FTE couverture ' . round($cov * 100) . ' %', 'Renfort recommandé (FTE)', 'Renfort (% effectif)', 'Jours touchés', 'Coût estimé'],
                array_map(fn($r) => [$r['team'], $r['channel'], $r['heads'], $r['incidents'], round($r['lost'], 1), $r['loss_pct'] === null ? '' : round($r['loss_pct'], 2), round($r['avg_fte'], 2), round($r['max_fte'], 2), round($r['q_fte'], 2), $r['reco'], $r['reco_pct'] === null ? '' : round($r['reco_pct'], 1), $r['hit_days'], round($r['cost'])], $S['rows']));
        }
        $this->view('incidents/staffing', ['title' => 'Aide au redimensionnement', 'f' => $f, 'S' => $S, 'cov' => $cov, 'channelNames' => array_column(DB::all('SELECT id, name FROM channels'), 'name', 'id'), 'fromTs' => $from, 'toTs' => $to] + $this->lookups());
    }

    // ------------------------------------------------------------------ Paramétrage
    function config(): void {
        $this->view('incidents/config', ['title' => 'Paramétrage des incidents', 'cats' => DB::all('SELECT c.*, (SELECT COUNT(*) FROM inc_incidents i WHERE i.category_id=c.id) AS used FROM inc_categories c ORDER BY c.family, c.sort_order, c.label'),
            'set' => array_combine(array_keys(Inc::DEFAULTS), array_map(fn($k) => Inc::set($k), array_keys(Inc::DEFAULTS))), 'sla' => array_map(fn($s) => Inc::sla($s), array_combine(array_keys(Inc::SEV), array_keys(Inc::SEV)))]);
    }
    function saveSettings(): void {
        $o = (int)$this->in('inc_open_hour', 7); $c = (int)$this->in('inc_close_hour', 20);
        if ($o < 0 || $o > 23 || $c <= $o || $c > 24) { flash('Plage horaire invalide (ouverture < fermeture, entre 0 et 24 h).', 'danger'); redirect('incidents/config'); }
        $days = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['inc_open_days'] ?? [])), fn($d) => $d >= 1 && $d <= 7))); if (!$days) { flash('Choisissez au moins un jour d\'ouverture.', 'danger'); redirect('incidents/config'); }
        $num = fn($k, $min, $max, $def) => (string)max($min, min($max, (float)str_replace(',', '.', (string)$this->in($k, $def))));
        $vals = ['inc.open_hour' => (string)$o, 'inc.close_hour' => (string)$c, 'inc.open_days' => implode(',', $days), 'inc.shift_hours' => $num('inc_shift_hours', 1, 24, 7.5), 'inc.hourly_cost' => $num('inc_hourly_cost', 0, 100000000, 0),
            'inc.currency' => mb_substr(trim((string)$this->in('inc_currency', 'FCFA')), 0, 8) ?: 'FCFA', 'inc.avail_target' => $num('inc_avail_target', 50, 100, 99.5), 'inc.reg_threshold' => $num('inc_reg_threshold', 0, 1000000000000, 900000),
            'inc.rca_days' => $num('inc_rca_days', 1, 90, 5), 'inc.recur_days' => $num('inc_recur_days', 1, 365, 30), 'inc.recur_min' => $num('inc_recur_min', 1, 50, 2)];
        $sla = []; foreach (array_keys(Inc::SEV) as $s) $sla[$s] = ['ack' => max(1, (int)($_POST['sla_ack'][$s] ?? Inc::SLA[$s]['ack'])), 'res' => max(1, (int)($_POST['sla_res'][$s] ?? Inc::SLA[$s]['res']))];
        foreach ($vals as $k => $v) Settings::set($k, $v); Settings::set('inc.sla', json_encode($sla));
        Audit::log('update', 'incident_settings', null, null, $vals + ['sla' => $sla]); flash('Paramètres enregistrés. Les heures perdues sont recalculées à l\'affichage.');
        foreach (DB::all("SELECT id FROM inc_incidents WHERE status<>'cancelled'") as $r) Inc::refresh((int)$r['id']);
        redirect('incidents/config');
    }
    /** Limites d'escalade : délais par gravité, niveau maximum, seuils d'escalade automatique et d'envoi de SMS. */
    function saveEscalation(): void {
        $lim = []; foreach (array_keys(Inc::SEV) as $s) { $d = IncEsc::LIMITS[$s]; $ack = max(1, min(10080, (int)($_POST['esc_ack'][$s] ?? $d['ack']))); $step = max($ack, min(10080, (int)($_POST['esc_step'][$s] ?? $d['step']))); $lim[$s] = ['ack' => $ack, 'step' => $step, 'fb' => max(1, min(43200, (int)($_POST['esc_fb'][$s] ?? $d['fb'])))]; }
        $sev = fn($k) => in_array((string)$this->in($k), ['P1', 'P2', 'P3', 'P4', 'none'], true) ? (string)$this->in($k) : 'P2';
        $v = ['inc.esc_limits' => json_encode($lim), 'inc.esc_auto_sev' => $sev('esc_auto_sev'), 'inc.esc_sms_sev' => $sev('esc_sms_sev'), 'inc.esc_max_level' => (string)max(1, min(5, (int)$this->in('esc_max_level', 3)))];
        foreach ($v as $k => $x) Settings::set($k, $x); Audit::log('update', 'incident_escalation_settings', null, null, $v); flash('Limites d\'escalade enregistrées.'); redirect('incidents/config#esc');
    }
    function saveCategory(?string $id = null): void {
        $old = $id ? DB::one('SELECT * FROM inc_categories WHERE id=?', [(int)$id]) : null; if ($id && !$old) { $this->notFound(); return; }
        $label = trim((string)$this->in('label')); $fam = (string)$this->in('family');
        if ($label === '' || !isset(Inc::FAMILIES[$fam])) { flash('Libellé et famille obligatoires.', 'danger'); redirect('incidents/config#cats'); }
        $d = ['family' => $fam, 'label' => mb_substr($label, 0, 150), 'service' => isset(Inc::SERVICES[(string)$this->in('service')]) ? (string)$this->in('service') : 'other', 'severity' => isset(Inc::SEV[(string)$this->in('severity')]) ? (string)$this->in('severity') : 'P3',
              'outage' => $this->in('outage') === '1' ? 1 : 0, 'mttr_target_min' => $this->intIn('mttr_target_min') ?: null, 'active' => $old ? ($this->in('active') === '1' ? 1 : 0) : 1];
        if ($old) { DB::update('inc_categories', $d, 'id=?', [(int)$id]); Audit::log('update', 'incident_category', $id, $old, $d); }
        else {
            $code = strtoupper(preg_replace('/[^A-Za-z0-9_]/', '_', (string)($this->in('code') ?: $fam . '_' . $label))); $code = substr(trim($code, '_'), 0, 38); $b = $code; $n = 1;
            while (DB::val('SELECT 1 FROM inc_categories WHERE code=?', [$code])) $code = substr($b, 0, 35) . '_' . ++$n;
            $d += ['code' => $code, 'sort_order' => (int)DB::val('SELECT MAX(sort_order) FROM inc_categories') + 1]; $nid = DB::insert('inc_categories', $d); Audit::log('create', 'incident_category', $nid, null, $d);
        }
        flash('Catégorie enregistrée.'); redirect('incidents/config#cats');
    }
}
