<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Inc, IncEsc, Files};

/** Pièces jointes des incidents : ajout (déclarant, gestionnaires, intervenants support concernés), téléchargement contrôlé, suppression. */
class IncFilesController extends Controller {
    private function incident(int $id): ?array { return DB::one('SELECT * FROM inc_incidents WHERE id=?', [$id]) ?: null; }
    /** Droit de voir l'incident : registre (inc.view), déclarant, ou intervenant d'une équipe sollicitée. */
    static function sees(array $i): bool {
        if (can('inc.view') || (int)$i['reporter_id'] === (int)Auth::id()) return true;
        $sc = IncEsc::userTeams((int)Auth::id()); return $sc && can('inc.support') && DB::val('SELECT 1 FROM inc_escalations WHERE incident_id=? AND team_id IN (' . implode(',', array_map('intval', $sc)) . ')', [(int)$i['id']]);
    }
    /** Droit d'ajouter une pièce jointe : gestionnaires, déclarant, intervenant concerné. */
    static function canAdd(array $i): bool { return can('inc.manage') || (int)$i['reporter_id'] === (int)Auth::id() || (can('inc.support') && self::sees($i)); }
    /** Enregistre les fichiers envoyés dans $_FILES[$field] ; retourne [nombre enregistré, erreurs]. */
    static function save(int $incId, string $field = 'files'): array {
        $already = (int)DB::val('SELECT COUNT(*) FROM inc_files WHERE incident_id=?', [$incId]); [$files, $err] = Files::uploads($field, $already); $n = 0; $uid = Auth::id();
        foreach ($files as $f) {
            $s = Files::put('inc', $f['bytes'], $f['ext']); if (!$s) { $err[] = '« ' . $f['name'] . ' » : enregistrement impossible.'; continue; }
            DB::insert('inc_files', ['incident_id' => $incId, 'user_id' => $uid, 'user_name' => $uid ? (string)DB::val('SELECT name FROM users WHERE id=?', [$uid]) : null, 'original_name' => $f['name'], 'stored_name' => $s, 'mime' => $f['mime'], 'size' => strlen($f['bytes']), 'created_at' => now()]);
            Inc::event($incId, 'fichier', 'Pièce jointe ajoutée : ' . $f['name']); $n++;
        }
        if ($n) DB::update('inc_incidents', ['updated_at' => now()], 'id=?', [$incId]);
        return [$n, $err];
    }
    function add(string $id): void {
        $i = $this->incident((int)$id); if (!$i || !self::sees($i)) { $this->notFound(); return; } if (!self::canAdd($i)) { $this->forbidden(); return; }
        [$n, $err] = self::save((int)$i['id']); if ($n) Audit::log('upload', 'incident', $id, null, ['files' => $n]);
        flash(($n ? "$n pièce(s) jointe(s) ajoutée(s). " : 'Aucun fichier enregistré. ') . implode(' ', $err), $err ? ($n ? 'warning' : 'danger') : 'success');
        redirect(can('inc.declare') ? 'incidents/' . $id . '#pj' : 'support/incidents/' . $id);
    }
    function download(string $id): void {
        $f = DB::one('SELECT * FROM inc_files WHERE id=?', [(int)$id]); $i = $f ? $this->incident((int)$f['incident_id']) : null; if (!$f || !$i || !self::sees($i)) { $this->notFound(); return; }
        Audit::log('download', 'inc_file', $id, null, ['incident' => $i['reference'], 'name' => $f['original_name']]); Files::send('inc', $f['stored_name'], $f['original_name'], $f['mime']);
    }
    function delete(string $id): void {
        $f = DB::one('SELECT * FROM inc_files WHERE id=?', [(int)$id]); $i = $f ? $this->incident((int)$f['incident_id']) : null; if (!$f || !$i || !self::sees($i)) { $this->notFound(); return; }
        if (!can('inc.manage') && (int)$f['user_id'] !== (int)Auth::id()) { $this->forbidden(); return; }
        DB::exec('DELETE FROM inc_files WHERE id=?', [(int)$id]); @unlink(Files::dir('inc') . '/' . basename($f['stored_name'])); Inc::event((int)$i['id'], 'fichier', 'Pièce jointe supprimée : ' . $f['original_name']); Audit::log('delete', 'inc_file', $id, $f, null);
        flash('Pièce jointe supprimée.'); redirect(can('inc.declare') ? 'incidents/' . $i['id'] . '#pj' : 'support/incidents/' . $i['id']);
    }
}
