<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Pm, Files, Itil};

/**
 * Lot 58 : procédures documentaires — code stable, versions numérotées par le serveur, circuit rédaction → validation → publication
 * (rédacteur ≠ approbateur), fichier final contrôlé, bibliothèque des versions courantes, fraîcheur, import d'un lot existant.
 */
class PdController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    private function manager(): bool { return can('pd.validate'); }
    private function writerOf(array $d): bool { $u = (int)Auth::id(); return $u === (int)$d['writer_id'] || $u === (int)$d['owner_id'] || $u === (int)$d['created_by']; }
    /** Un lecteur voit une procédure publiée selon sa visibilité ; rédacteurs et valideurs voient tout. */
    static function visible(array $d): bool {
        if (can('pd.validate') || can('pd.write') && ((int)Auth::id() === (int)$d['writer_id'] || (int)Auth::id() === (int)$d['owner_id'] || (int)Auth::id() === (int)$d['created_by'])) return true;
        if (!in_array($d['status'], ['published', 'obsolete'], true)) return false;
        if ($d['visibility'] === 'direction') return $d['direction'] && Pm::userDirection() === $d['direction'];
        if ($d['visibility'] === 'roles') { $mine = array_column(Auth::roles(), 'code'); return (bool)array_intersect($mine, array_filter(explode(',', (string)$d['roles_csv']))); }
        return true;
    }
    static function visibleSql(): array {
        if (can('pd.validate')) return ['1=1', []];
        $w = ["(d.status IN ('published','obsolete') AND (d.visibility='internal'"]; $p = [];
        if ($dir = Pm::userDirection()) { $w[0] .= " OR (d.visibility='direction' AND d.direction=?)"; $p[] = $dir; }
        foreach (array_column(Auth::roles(), 'code') as $rc) { $w[0] .= " OR (d.visibility='roles' AND (d.roles_csv=? OR d.roles_csv LIKE ? OR d.roles_csv LIKE ? OR d.roles_csv LIKE ?))"; array_push($p, $rc, "$rc,%", "%,$rc", "%,$rc,%"); }
        $w[0] .= '))'; if (can('pd.write')) { $w[0] = '(' . $w[0] . ' OR d.writer_id=? OR d.owner_id=? OR d.created_by=?)'; array_push($p, Auth::id(), Auth::id(), Auth::id()); }
        return [$w[0], $p];
    }
    private function load(string $id): ?array { $d = DB::one('SELECT d.*, p.name process, p.code process_code, u.name owner, w.name writer FROM pd_procedures d LEFT JOIN pr_processes p ON p.id=d.process_id LEFT JOIN users u ON u.id=d.owner_id LEFT JOIN users w ON w.id=d.writer_id WHERE d.id=?', [(int)$id]); if (!$d || !self::visible($d)) { $this->notFound(); return null; } return $d; }
    private function filters(): array { return ['directions' => Pm::directions(), 'processes' => DB::all("SELECT id, code, name FROM pr_processes WHERE status<>'archived' ORDER BY name"), 'users' => Itil::users('pd.write'), 'validators' => Itil::users('pd.validate'), 'roles' => DB::all('SELECT code, name FROM roles ORDER BY name')]; }
    static function event(int $pid, ?int $vid, string $action, ?string $note = null): void { $uid = Auth::id(); DB::insert('pd_events', ['procedure_id' => $pid, 'version_id' => $vid, 'user_id' => $uid, 'user_name' => $uid ? (string)DB::val('SELECT name FROM users WHERE id=?', [$uid]) : 'système', 'action' => $action, 'note' => $note ? mb_substr($note, 0, 500) : null, 'created_at' => now()]); }

    // ------------------------------------------------------------------ bibliothèque (lecteurs)
    function library(): void {
        [$vw, $vp] = self::visibleSql(); $w = ["d.status='published'", $vw]; $p = $vp; $asOf = date('Y-m-d');
        if ($this->in('direction')) { $w[] = 'd.direction=?'; $p[] = (string)$this->in('direction'); } if ($this->in('process_id')) { $w[] = 'd.process_id=?'; $p[] = (int)$this->in('process_id'); }
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(d.code LIKE ? OR d.title LIKE ? OR d.purpose LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $st = (string)$this->in('state', ''); if ($st === 'current') { $w[] = 'd.review_due>=?'; $p[] = $asOf; } elseif ($st === 'expired') { $w[] = 'd.review_due<?'; $p[] = $asOf; } elseif ($st === 'nodate') $w[] = 'd.review_due IS NULL';
        $from = 'pd_procedures d LEFT JOIN pr_processes p ON p.id=d.process_id LEFT JOIN users u ON u.id=d.owner_id LEFT JOIN pd_versions v ON v.id=d.current_version_id WHERE ' . implode(' AND ', $w);
        if ($this->in('export') === 'csv') { $rows = DB::all("SELECT d.code, d.title, d.direction, p.name process, u.name owner, v.number, v.effective_date, d.review_due FROM $from ORDER BY d.code LIMIT 5000", $p); Audit::log('export', 'pd_library', null, null, ['rows' => count($rows)]);
            csv_download('bibliotheque_procedures_' . date('Ymd_His') . '.csv', ['Code', 'Procédure', 'Direction', 'Processus', 'Pilote', 'Version', 'Date d\'effet', 'Révision prévue', 'État'], array_map(fn($r) => [$r['code'], $r['title'], $r['direction'], $r['process'], $r['owner'], 'v' . $r['number'], $r['effective_date'], $r['review_due'], !$r['review_due'] ? 'Sans échéance' : ($r['review_due'] < $asOf ? 'Expirée' : 'À jour')], $rows)); }
        $pg = paginate($from, $p, (int)$this->in('page', 1), 30, 'd.*, p.name process, u.name owner, v.number vnum, v.effective_date, (SELECT COUNT(*) FROM pd_files f WHERE f.version_id=d.current_version_id AND f.kind=\'final\') nfiles', 'd.code');
        $this->view('pd/library', ['title' => 'Bibliothèque des procédures', 'p' => $pg, 'st' => $st, 'asOf' => $asOf] + $this->filters());
    }
    // ------------------------------------------------------------------ gestion documentaire
    function index(): void {
        [$vw, $vp] = self::visibleSql(); $w = [$vw]; $p = $vp; $asOf = date('Y-m-d');
        if ($this->in('status') && isset(Pm::PD_ST[(string)$this->in('status')])) { $w[] = 'd.status=?'; $p[] = (string)$this->in('status'); } if ($this->in('direction')) { $w[] = 'd.direction=?'; $p[] = (string)$this->in('direction'); }
        $st = (string)$this->in('state', ''); if ($st === 'expired') { $w[] = "d.status='published' AND d.review_due<?"; $p[] = $asOf; } elseif ($st === 'nodate') $w[] = "d.status='published' AND d.review_due IS NULL"; elseif ($st === 'current') { $w[] = "d.status='published' AND d.review_due>=?"; $p[] = $asOf; } elseif ($st === 'revising') $w[] = "EXISTS (SELECT 1 FROM pd_versions v WHERE v.procedure_id=d.id AND v.state IN ('draft','submitted','returned','approved','scheduled'))";
        $band = (string)$this->in('band', ''); if (isset(Pm::BANDS[$band])) { $w[] = "d.status='published'"; $lo = [ 'd30' => 0, 'd60' => 31, 'd90' => 61, 'later' => 91 ]; if ($band === 'late') { $w[] = 'd.review_due<?'; $p[] = $asOf; } elseif ($band === 'none') $w[] = 'd.review_due IS NULL'; else { $w[] = 'd.review_due>=?'; $p[] = date('Y-m-d', strtotime("$asOf +{$lo[$band]} day")); if ($band !== 'later') { $w[] = 'd.review_due<=?'; $p[] = date('Y-m-d', strtotime("$asOf +" . ($lo[$band] + ($band === 'd30' ? 30 : 29)) . ' day')); } } }
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(d.code LIKE ? OR d.title LIKE ?)'; array_push($p, "%$q%", "%$q%"); }
        $from = 'pd_procedures d LEFT JOIN pr_processes p ON p.id=d.process_id LEFT JOIN users u ON u.id=d.owner_id LEFT JOIN pd_versions v ON v.id=d.current_version_id WHERE ' . implode(' AND ', $w);
        if ($this->in('export') === 'csv') { $rows = DB::all("SELECT d.code, d.title, d.direction, p.name process, u.name owner, d.status, v.number, d.review_due, d.publications, d.reminded_at FROM $from ORDER BY d.code LIMIT 5000", $p); Audit::log('export', 'pd_procedures', null, null, ['rows' => count($rows)]);
            csv_download('procedures_' . date('Ymd_His') . '.csv', ['Code', 'Procédure', 'Direction', 'Processus', 'Pilote', 'Statut', 'Version courante', 'Révision prévue', 'Révisions effectuées', 'Dernier rappel'], array_map(fn($r) => [$r['code'], $r['title'], $r['direction'], $r['process'], $r['owner'], Pm::PD_ST[$r['status']] ?? $r['status'], $r['number'] ? 'v' . $r['number'] : '', $r['review_due'], $r['publications'], $r['reminded_at']], $rows)); }
        $pg = paginate($from, $p, (int)$this->in('page', 1), 30, "d.*, p.name process, u.name owner, v.number vnum, (SELECT v2.state FROM pd_versions v2 WHERE v2.procedure_id=d.id AND v2.state IN ('draft','submitted','returned','approved','scheduled') ORDER BY v2.id DESC LIMIT 1) open_state", 'd.code');
        $this->view('pd/index', ['title' => 'Gestion des procédures', 'p' => $pg, 'asOf' => $asOf, 'st' => $st, 'counts' => ['todo' => $this->manager() ? (int)DB::val("SELECT COUNT(*) FROM pd_versions WHERE state='submitted'") : 0]] + $this->filters());
    }
    function create(): void { $this->view('pd/form', ['title' => 'Nouvelle procédure', 'd' => null] + $this->filters()); }
    private function meta(?array $cur): array {
        [$d, $err] = $this->validate(['title' => ['label' => 'Le titre', 'req' => true, 'max' => 200], 'scope_txt' => ['label' => 'Le périmètre', 'max' => 500], 'purpose' => ['label' => 'L\'objet', 'max' => 1000]], $_POST);
        $d['process_id'] = (int)$this->in('process_id') ?: null; if ($d['process_id'] && !DB::val('SELECT 1 FROM pr_processes WHERE id=?', [$d['process_id']])) $err['p'] = 'Processus inconnu.';
        $d['direction'] = mb_substr(trim((string)$this->in('direction', '')), 0, 100) ?: null; $d['visibility'] = (string)$this->in('visibility', 'internal'); if (!isset(Pm::VIS[$d['visibility']])) $d['visibility'] = 'internal';
        if ($d['visibility'] === 'direction' && !$d['direction']) $err['v'] = 'La visibilité par direction exige une direction propriétaire.';
        $valid = array_column(DB::all('SELECT code FROM roles'), 'code'); $roles = array_values(array_intersect((array)($_POST['roles'] ?? []), $valid)); $d['roles_csv'] = $roles ? implode(',', $roles) : null; if ($d['visibility'] === 'roles' && !$roles) $err['r'] = 'Choisissez au moins un rôle.';
        $d['owner_id'] = (int)$this->in('owner_id') ?: ($cur['owner_id'] ?? Auth::id()); if (!DB::val('SELECT 1 FROM users WHERE id=?', [$d['owner_id']])) $d['owner_id'] = Auth::id();
        $rd = (string)$this->in('review_due', ''); if ($rd !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $rd)) $err['d'] = 'Échéance de revue invalide.'; $d['proposed_review'] = $rd ?: null;
        return [$d, $err];
    }
    function store(): void {
        [$d, $err] = $this->meta(null); $code = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string)$this->in('code', '')));
        if ($code === '' || strlen($code) > 40) $err['c'] = 'Code obligatoire (lettres, chiffres, - et _).'; elseif (DB::val('SELECT 1 FROM pd_procedures WHERE code=?', [$code])) $err['c2'] = 'Ce code existe déjà.';
        if ($err) { $_SESSION['_old'] = $_POST; $this->go('pd/new', implode(' ', $err), 'danger'); }
        $rd = $d['proposed_review']; unset($d['proposed_review']);
        $id = DB::insert('pd_procedures', $d + ['code' => $code, 'writer_id' => Auth::id(), 'status' => 'draft', 'publications' => 0, 'created_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()]);
        $vid = DB::insert('pd_versions', ['procedure_id' => $id, 'number' => 1, 'state' => 'draft', 'review_due' => $rd, 'created_by' => Auth::id(), 'created_at' => now()]);
        Audit::log('create', 'pd_procedure', $id, null, ['code' => $code]); self::event($id, $vid, 'created', 'Procédure créée, version 1 en rédaction'); $this->go("pd/$id", 'Procédure créée : complétez la version 1 et déposez le fichier final.');
    }
    function show(string $id): void {
        if (!($d = $this->load($id))) return;
        $versions = DB::all('SELECT v.*, u.name created_by_name, s.name submitted_by_name, dd.name decided_by_name FROM pd_versions v LEFT JOIN users u ON u.id=v.created_by LEFT JOIN users s ON s.id=v.submitted_by LEFT JOIN users dd ON dd.id=v.decided_by WHERE v.procedure_id=? ORDER BY v.number DESC', [(int)$id]);
        $files = []; foreach (DB::all('SELECT f.* FROM pd_files f JOIN pd_versions v ON v.id=f.version_id WHERE v.procedure_id=? ORDER BY f.id', [(int)$id]) as $f) $files[(int)$f['version_id']][] = $f;
        $open = null; foreach ($versions as $v) if (in_array($v['state'], ['draft', 'submitted', 'returned', 'approved', 'scheduled'], true)) { $open = $v; break; }
        $reader = !$this->manager() && !(can('pd.write') && $this->writerOf($d));
        $this->view('pd/show', ['title' => $d['code'] . ' · ' . $d['title'], 'd' => $d, 'versions' => $reader ? array_values(array_filter($versions, fn($v) => in_array($v['state'], ['published', 'replaced', 'withdrawn'], true))) : $versions, 'files' => $files, 'open' => $reader ? null : $open, 'reader' => $reader, 'canWrite' => can('pd.write') && ($this->writerOf($d) || $this->manager()), 'canValidate' => $this->manager(),
            'events' => $reader ? [] : DB::all('SELECT * FROM pd_events WHERE procedure_id=? ORDER BY id DESC LIMIT 60', [(int)$id]), 'asOf' => date('Y-m-d'), 'mrps' => DB::all('SELECT id, ref, title, status FROM pm_mrp WHERE procedure_id=? ORDER BY id DESC LIMIT 10', [(int)$id])] + $this->filters());
    }
    function update(string $id): void {
        if (!($d = $this->load($id))) return; if (!can('pd.write') || !($this->writerOf($d) || $this->manager())) { $this->forbidden(); return; }
        [$m, $err] = $this->meta($d); unset($m['proposed_review']); if ($err) $this->go("pd/$id", implode(' ', $err), 'danger');
        DB::update('pd_procedures', $m + ['updated_at' => now()], 'id=?', [(int)$id]); Audit::log('update', 'pd_procedure', (int)$id, $d, $m); $this->go("pd/$id", 'Fiche enregistrée.');
    }
    // ------------------------------------------------------------------ versions
    private function version(string $id, string $vid): ?array { $v = DB::one('SELECT * FROM pd_versions WHERE id=? AND procedure_id=?', [(int)$vid, (int)$id]); if (!$v) { $this->notFound(); return null; } return $v; }
    function newVersion(string $id): void {
        if (!($d = $this->load($id))) return; if (!can('pd.write') || !($this->writerOf($d) || $this->manager())) { $this->forbidden(); return; }
        if (DB::val("SELECT 1 FROM pd_versions WHERE procedure_id=? AND state IN ('draft','submitted','returned','approved','scheduled')", [(int)$id])) $this->go("pd/$id", 'Une version est déjà en cours : terminez-la ou retirez-la avant d\'en ouvrir une autre.', 'warning');
        $n = (int)DB::val('SELECT COALESCE(MAX(number),0) FROM pd_versions WHERE procedure_id=?', [(int)$id]) + 1; $reason = trim((string)$this->in('reason', '')); if (mb_strlen($reason) < 5) $this->go("pd/$id", 'Indiquez le motif de la révision (5 caractères au moins).', 'danger');
        $vid = DB::insert('pd_versions', ['procedure_id' => (int)$id, 'number' => $n, 'state' => 'draft', 'reason' => mb_substr($reason, 0, 500), 'review_due' => $d['review_due'] ? date('Y-m-d', strtotime($d['review_due'] . ' +12 months')) : null, 'created_by' => Auth::id(), 'created_at' => now()]);
        if ($d['status'] !== 'published') DB::update('pd_procedures', ['status' => 'draft', 'updated_at' => now()], 'id=?', [(int)$id]);
        self::event((int)$id, $vid, 'revision', "Version $n ouverte : $reason"); Audit::log('create', 'pd_version', $vid, null, ['procedure' => $d['code'], 'number' => $n]); $this->go("pd/$id", "Version $n ouverte en rédaction ; la version publiée reste consultable.");
    }
    function saveVersion(string $id, string $vid): void {
        if (!($d = $this->load($id)) || !($v = $this->version($id, $vid))) return; if (!can('pd.write') || !($this->writerOf($d) || $this->manager())) { $this->forbidden(); return; }
        if (!in_array($v['state'], ['draft', 'returned'], true)) $this->go("pd/$id", 'Cette version n\'est plus modifiable.', 'warning');
        $err = []; $eff = (string)$this->in('effective_date', ''); $rd = (string)$this->in('review_due', ''); foreach (['effective_date' => $eff, 'review_due' => $rd] as $k => $x) if ($x !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $x)) $err[] = 'Date invalide (' . $k . ').';
        if ($eff && $rd && $rd <= $eff) $err[] = 'L\'échéance de revue doit être postérieure à la date d\'effet.';
        $u = ['reason' => mb_substr(trim((string)$this->in('reason', '')), 0, 500) ?: null, 'changes' => mb_substr(trim((string)$this->in('changes', '')), 0, 1000) ?: null, 'effective_date' => $eff ?: null, 'review_due' => $rd ?: null];
        // fichiers : final (PDF unique, remplace le précédent), source et annexes
        $kind = (string)$this->in('kind', 'final'); if (!in_array($kind, ['final', 'source', 'annex'], true)) $kind = 'final';
        [$up, $ferr] = Files::uploads('files'); $err = array_merge($err, $ferr);
        foreach ($up as $f) { if ($kind === 'final' && strtolower($f['ext']) !== 'pdf') { $err[] = 'Le fichier final doit être un PDF (« ' . $f['name'] . ' » refusé).'; continue; } $s = Files::put('pd', $f['bytes'], $f['ext']); if (!$s) { $err[] = 'Enregistrement impossible : ' . $f['name']; continue; }
            if ($kind === 'final') DB::exec("DELETE FROM pd_files WHERE version_id=? AND kind='final'", [(int)$vid]);
            DB::insert('pd_files', ['version_id' => (int)$vid, 'kind' => $kind, 'original_name' => $f['name'], 'stored_name' => $s, 'mime' => $f['mime'], 'size' => strlen($f['bytes']), 'sha256' => hash('sha256', $f['bytes']), 'user_id' => Auth::id(), 'created_at' => now()]); self::event((int)$id, (int)$vid, 'file', ucfirst($kind) . ' : ' . $f['name']); }
        DB::update('pd_versions', $u, 'id=?', [(int)$vid]); DB::update('pd_procedures', ['updated_at' => now()], 'id=?', [(int)$id]);
        $this->go("pd/$id", $err ? implode(' ', $err) : 'Version enregistrée.', $err ? 'warning' : 'success');
    }
    function deleteFile(string $id, string $fid): void {
        if (!($d = $this->load($id))) return; $f = DB::one('SELECT f.*, v.state FROM pd_files f JOIN pd_versions v ON v.id=f.version_id WHERE f.id=? AND v.procedure_id=?', [(int)$fid, (int)$id]); if (!$f) { $this->notFound(); return; }
        if (!can('pd.write') || !($this->writerOf($d) || $this->manager()) || !in_array($f['state'], ['draft', 'returned'], true)) { $this->forbidden(); return; }
        DB::exec('DELETE FROM pd_files WHERE id=?', [(int)$fid]); @unlink(Files::dir('pd') . '/' . $f['stored_name']); self::event((int)$id, (int)$f['version_id'], 'file', 'Fichier retiré : ' . $f['original_name']); $this->go("pd/$id", 'Fichier retiré.');
    }
    function submit(string $id, string $vid): void {
        if (!($d = $this->load($id)) || !($v = $this->version($id, $vid))) return; if (!can('pd.write') || !($this->writerOf($d) || $this->manager())) { $this->forbidden(); return; }
        if (!in_array($v['state'], ['draft', 'returned'], true)) $this->go("pd/$id", 'Cette version n\'est pas en rédaction.', 'warning');
        $err = []; if (!DB::val("SELECT 1 FROM pd_files WHERE version_id=? AND kind='final'", [(int)$vid])) $err[] = 'Déposez le PDF final avant de soumettre.'; if ((int)$v['number'] > 1 && !$v['reason']) $err[] = 'Le motif de révision est obligatoire.';
        if (!$v['review_due']) $err[] = 'Indiquez l\'échéance de revue.'; if ($v['effective_date'] && $v['review_due'] && $v['review_due'] <= $v['effective_date']) $err[] = 'L\'échéance de revue doit suivre la date d\'effet.';
        if ($err) $this->go("pd/$id", implode(' ', $err), 'danger');
        DB::update('pd_versions', ['state' => 'submitted', 'submitted_by' => Auth::id(), 'submitted_at' => now()], 'id=?', [(int)$vid]); DB::update('pd_procedures', ['status' => $d['status'] === 'published' ? 'published' : 'in_validation', 'updated_at' => now()], 'id=?', [(int)$id]);
        self::event((int)$id, (int)$vid, 'submitted', 'Version ' . $v['number'] . ' soumise à validation'); Audit::log('submit', 'pd_version', (int)$vid, null, ['procedure' => $d['code']]);
        Notifier::toPermission('pd.validate', 'Procédure à valider', $d['code'] . ' v' . $v['number'] . ' · ' . $d['title'], 'pd/' . $id); $this->go("pd/$id", 'Version soumise : les valideurs sont prévenus.');
    }
    function decide(string $id, string $vid): void {
        if (!($d = $this->load($id)) || !($v = $this->version($id, $vid))) return; if (!$this->manager()) { $this->forbidden(); return; }
        if ($v['state'] !== 'submitted') $this->go("pd/$id", 'Cette version n\'est pas en attente de validation.', 'warning');
        if ((int)$v['submitted_by'] === (int)Auth::id()) $this->go("pd/$id", 'Le rédacteur qui a soumis la version ne peut pas la valider (séparation rédacteur / approbateur).', 'danger');
        $act = (string)$this->in('act'); $note = trim((string)$this->in('note', ''));
        if ($act === 'return') { if (mb_strlen($note) < 3) $this->go("pd/$id", 'Indiquez le motif du retour en rédaction.', 'danger'); DB::update('pd_versions', ['state' => 'returned', 'decided_by' => Auth::id(), 'decided_at' => now(), 'decision_note' => mb_substr($note, 0, 500)], 'id=?', [(int)$vid]); if ($d['status'] === 'in_validation') DB::update('pd_procedures', ['status' => 'draft'], 'id=?', [(int)$id]);
            self::event((int)$id, (int)$vid, 'returned', $note); Audit::log('return', 'pd_version', (int)$vid, null, ['note' => $note]); if ($v['submitted_by']) Notifier::send((int)$v['submitted_by'], 'Procédure retournée en rédaction', $d['code'] . ' v' . $v['number'] . ' : ' . $note, 'pd/' . $id); $this->go("pd/$id", 'Version retournée en rédaction.'); }
        if ($act !== 'approve') $this->go("pd/$id", 'Action inconnue.', 'danger');
        DB::update('pd_versions', ['state' => 'approved', 'decided_by' => Auth::id(), 'decided_at' => now(), 'decision_note' => mb_substr($note, 0, 500) ?: null], 'id=?', [(int)$vid]); if ($d['status'] === 'in_validation') DB::update('pd_procedures', ['status' => 'approved'], 'id=?', [(int)$id]);
        self::event((int)$id, (int)$vid, 'approved', $note ?: null); Audit::log('approve', 'pd_version', (int)$vid, null, ['procedure' => $d['code']]); if ($v['submitted_by']) Notifier::send((int)$v['submitted_by'], 'Procédure approuvée', $d['code'] . ' v' . $v['number'], 'pd/' . $id);
        $this->go("pd/$id", 'Version approuvée : elle peut être publiée.');
    }
    /** Publication transactionnelle : la version approuvée devient courante, la précédente est remplacée ; une date d'effet future programme la publication. */
    static function publish(int $pid, int $vid, bool $force = false): string {
        $d = DB::one('SELECT * FROM pd_procedures WHERE id=?', [$pid]); $v = DB::one('SELECT * FROM pd_versions WHERE id=? AND procedure_id=?', [$vid, $pid]); if (!$d || !$v) return 'Version introuvable.';
        if (!in_array($v['state'], ['approved', 'scheduled'], true)) return 'Seule une version approuvée peut être publiée.';
        if (!DB::val("SELECT 1 FROM pd_files WHERE version_id=? AND kind='final'", [$vid])) return 'Le PDF final est absent.'; if (!$v['review_due']) return 'L\'échéance de revue est obligatoire.';
        $eff = $v['effective_date'] ?: date('Y-m-d'); if ($v['review_due'] <= $eff) return 'L\'échéance de revue doit être postérieure à la date d\'effet.';
        if ($eff > date('Y-m-d') && !$force) { DB::update('pd_versions', ['state' => 'scheduled', 'effective_date' => $eff], 'id=?', [$vid]); self::event($pid, $vid, 'scheduled', 'Publication programmée au ' . $eff); return ''; }
        $pdo = DB::pdo(); $own = !$pdo->inTransaction(); if ($own) $pdo->beginTransaction();
        try {
            $cur = DB::one("SELECT * FROM pd_procedures WHERE id=?", [$pid]); if ((int)$cur['current_version_id'] === $vid) { if ($own) $pdo->rollBack(); return 'Déjà publiée.'; }
            if ($cur['current_version_id']) DB::update('pd_versions', ['state' => 'replaced', 'replaced_at' => now()], 'id=? AND state=?', [(int)$cur['current_version_id'], 'published']);
            DB::update('pd_versions', ['state' => 'published', 'published_by' => Auth::id(), 'published_at' => now(), 'effective_date' => $eff], 'id=?', [$vid]);
            DB::update('pd_procedures', ['status' => 'published', 'current_version_id' => $vid, 'review_due' => $v['review_due'], 'publications' => (int)$cur['publications'] + ($cur['current_version_id'] || $cur['publications'] ? 1 : 0), 'reminder_stage' => 0, 'reminded_at' => null, 'updated_at' => now()], 'id=?', [$pid]);
            if ($own) $pdo->commit();
        } catch (\Throwable $e) { if ($own) $pdo->rollBack(); return 'Publication impossible : conflit d\'état, rechargez la fiche.'; }
        self::event($pid, $vid, 'published', 'Version ' . $v['number'] . ' publiée, effet au ' . $eff); Audit::log('publish', 'pd_version', $vid, null, ['procedure' => $d['code'], 'number' => $v['number']]);
        if ($d['writer_id']) Notifier::send((int)$d['writer_id'], 'Procédure publiée', $d['code'] . ' v' . $v['number'], 'pd/' . $pid); return '';
    }
    function publishNow(string $id, string $vid): void {
        if (!($d = $this->load($id)) || !($v = $this->version($id, $vid))) return; if (!$this->manager()) { $this->forbidden(); return; }
        $e = self::publish((int)$id, (int)$vid); if ($e) $this->go("pd/$id", $e, 'danger');
        $v2 = DB::one('SELECT state FROM pd_versions WHERE id=?', [(int)$vid]); $this->go("pd/$id", $v2['state'] === 'scheduled' ? 'Publication programmée à la date d\'effet.' : 'Version publiée : elle est désormais la version courante de la bibliothèque.');
    }
    function cancelVersion(string $id, string $vid): void {
        if (!($d = $this->load($id)) || !($v = $this->version($id, $vid))) return; if (!can('pd.write') || !($this->writerOf($d) || $this->manager())) { $this->forbidden(); return; }
        if (!in_array($v['state'], ['draft', 'returned', 'submitted', 'approved', 'scheduled'], true)) $this->go("pd/$id", 'Cette version ne peut pas être retirée.', 'warning');
        $note = trim((string)$this->in('note', '')); if (mb_strlen($note) < 3) $this->go("pd/$id", 'Indiquez le motif du retrait.', 'danger');
        DB::update('pd_versions', ['state' => 'withdrawn', 'decision_note' => mb_substr($note, 0, 500), 'decided_by' => Auth::id(), 'decided_at' => now()], 'id=?', [(int)$vid]);
        if ($d['status'] !== 'published') DB::update('pd_procedures', ['status' => DB::val('SELECT 1 FROM pd_versions WHERE procedure_id=? AND state=?', [(int)$id, 'published']) ? 'published' : 'draft'], 'id=?', [(int)$id]);
        self::event((int)$id, (int)$vid, 'withdrawn', $note); $this->go("pd/$id", 'Version retirée.');
    }
    function withdraw(string $id): void {
        if (!($d = $this->load($id))) return; if (!$this->manager()) { $this->forbidden(); return; } $note = trim((string)$this->in('note', '')); if (mb_strlen($note) < 3) $this->go("pd/$id", 'Indiquez le motif du retrait.', 'danger');
        if ($d['status'] !== 'published') $this->go("pd/$id", 'Seule une procédure publiée peut être rendue obsolète.', 'warning');
        DB::update('pd_versions', ['state' => 'withdrawn', 'decision_note' => mb_substr($note, 0, 500), 'decided_by' => Auth::id(), 'decided_at' => now()], 'id=?', [(int)$d['current_version_id']]); DB::update('pd_procedures', ['status' => 'obsolete', 'updated_at' => now()], 'id=?', [(int)$id]);
        self::event((int)$id, (int)$d['current_version_id'], 'obsolete', $note); Audit::log('withdraw', 'pd_procedure', (int)$id, null, ['note' => $note]); $this->go("pd/$id", 'Procédure retirée de la bibliothèque (obsolète) ; l\'historique est conservé.');
    }
    function file(string $fid): void {
        $f = DB::one('SELECT f.*, v.state, v.procedure_id FROM pd_files f JOIN pd_versions v ON v.id=f.version_id WHERE f.id=?', [(int)$fid]); $d = $f ? DB::one('SELECT * FROM pd_procedures WHERE id=?', [(int)$f['procedure_id']]) : null;
        if (!$f || !$d || !self::visible($d)) { $this->notFound(); return; }
        $reader = !$this->manager() && !(can('pd.write') && $this->writerOf($d)); if ($reader && !in_array($f['state'], ['published', 'replaced', 'withdrawn'], true)) { $this->notFound(); return; }
        if ($d['visibility'] !== 'internal') Audit::log('download', 'pd_file', (int)$fid, null, ['procedure' => $d['code'], 'name' => $f['original_name'], 'restricted' => true]);
        Files::send('pd', $f['stored_name'], $f['original_name'], $f['mime'] ?: 'application/octet-stream');
    }
    // ------------------------------------------------------------------ import d'un lot existant
    function importForm(): void { $this->view('pd/import', ['title' => 'Importer un dossier de procédures', 'batches' => DB::all('SELECT b.*, u.name user_name, (SELECT COUNT(*) FROM pd_import_items i WHERE i.import_id=b.id) n FROM pd_imports b LEFT JOIN users u ON u.id=b.user_id ORDER BY b.id DESC LIMIT 20')]); }
    function importStore(): void {
        [$up, $err] = Files::uploads('files'); if (!$up) $this->go('pd/import', 'Aucun fichier accepté. ' . implode(' ', $err), 'danger');
        $bid = DB::insert('pd_imports', ['label' => mb_substr(trim((string)$this->in('label', '')), 0, 150) ?: 'Lot du ' . date('d/m/Y H:i'), 'status' => 'preview', 'user_id' => Auth::id(), 'created_at' => now()]);
        foreach ($up as $f) { $s = Files::put('pd', $f['bytes'], $f['ext']); if (!$s) continue; $sha = hash('sha256', $f['bytes']); $base = preg_replace('/\.[^.]+$/', '', $f['name']);
            $code = null; $vh = null; $title = $base; if (preg_match('/^([A-Za-z]{2,6}-?\d{2,6})[ _-]*(?:v(\d+))?[ _-]*(.*)$/u', $base, $m)) { $code = strtoupper(str_replace(' ', '', $m[1])); $vh = $m[2] !== '' ? (int)$m[2] : null; $title = trim(str_replace(['_', '-'], ' ', $m[3])) ?: $base; }
            $dup = DB::val('SELECT v.procedure_id FROM pd_files pf JOIN pd_versions v ON v.id=pf.version_id WHERE pf.sha256=? LIMIT 1', [$sha]); $ext = strtolower($f['ext']);
            DB::insert('pd_import_items', ['import_id' => $bid, 'original_name' => $f['name'], 'stored_name' => $s, 'mime' => $f['mime'], 'size' => strlen($f['bytes']), 'sha256' => $sha, 'code' => $code, 'title' => mb_substr($title, 0, 200), 'version_hint' => $vh, 'check_status' => $ext !== 'pdf' ? 'not_pdf' : ($dup ? 'duplicate' : 'ok'), 'procedure_id' => $dup ? (int)$dup : null, 'decision' => $ext !== 'pdf' || $dup ? 'reject' : 'publish', 'reject_reason' => $ext !== 'pdf' ? 'Fichier non PDF' : ($dup ? 'Fichier identique déjà importé' : null), 'review_due' => date('Y-m-d', strtotime('+12 months')), 'effective_date' => date('Y-m-d'), 'approved_proof' => 0]); }
        Audit::log('import', 'pd_import', $bid, null, ['files' => count($up)]); $this->go("pd/import/$bid", count($up) . ' fichier(s) analysé(s) : vérifiez chaque ligne puis validez le lot.' . ($err ? ' ' . implode(' ', $err) : ''), $err ? 'warning' : 'success');
    }
    function importShow(string $id): void {
        $b = DB::one('SELECT * FROM pd_imports WHERE id=?', [(int)$id]); if (!$b) { $this->notFound(); return; } $items = DB::all('SELECT i.*, d.title ptitle FROM pd_import_items i LEFT JOIN pd_procedures d ON d.id=i.procedure_id WHERE i.import_id=? ORDER BY i.id', [(int)$id]);
        if ($this->in('export') === 'csv') { Audit::log('export', 'pd_import', (int)$id); csv_download('bilan_import_' . $id . '.csv', ['Fichier', 'Code', 'Titre', 'Contrôle', 'Décision', 'Motif de rejet', 'Procédure'], array_map(fn($i) => [$i['original_name'], $i['code'], $i['title'], $i['check_status'], $i['decision'], $i['reject_reason'], $i['procedure_id'] ? (string)DB::val('SELECT code FROM pd_procedures WHERE id=?', [(int)$i['procedure_id']]) : ''], $items)); }
        $this->view('pd/import_show', ['title' => 'Lot d\'import · ' . $b['label'], 'b' => $b, 'items' => $items, 'reasons' => array_count_values(array_filter(array_column($items, 'reject_reason')))] + $this->filters());
    }
    function importDecide(string $id): void {
        $b = DB::one('SELECT * FROM pd_imports WHERE id=?', [(int)$id]); if (!$b) { $this->notFound(); return; } if ($b['status'] !== 'preview') $this->go("pd/import/$id", 'Ce lot est déjà traité.', 'warning');
        $pub = 0; $rej = 0; $rows = (array)($_POST['item'] ?? []);
        foreach (DB::all('SELECT * FROM pd_import_items WHERE import_id=?', [(int)$id]) as $it) {
            $in = (array)($rows[$it['id']] ?? []); $code = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string)($in['code'] ?? $it['code']))); $title = mb_substr(trim((string)($in['title'] ?? $it['title'])), 0, 200); $dec = ($in['decision'] ?? $it['decision']) === 'publish' ? 'publish' : 'reject';
            $u = ['code' => $code ?: null, 'title' => $title ?: null, 'process_id' => (int)($in['process_id'] ?? 0) ?: null, 'direction' => mb_substr(trim((string)($in['direction'] ?? '')), 0, 100) ?: null, 'effective_date' => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($in['effective_date'] ?? '')) ? $in['effective_date'] : date('Y-m-d'), 'review_due' => preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($in['review_due'] ?? '')) ? $in['review_due'] : null, 'approved_proof' => !empty($in['approved_proof']) ? 1 : 0, 'note' => mb_substr(trim((string)($in['note'] ?? '')), 0, 300) ?: null, 'decision' => $dec, 'reject_reason' => $dec === 'reject' ? (mb_substr(trim((string)($in['reject_reason'] ?? '')), 0, 60) ?: ($it['reject_reason'] ?: 'Rejeté par le valideur')) : null];
            if ($dec === 'publish') { $why = null; if (strtolower(pathinfo($it['original_name'], PATHINFO_EXTENSION)) !== 'pdf') $why = 'Fichier non PDF'; elseif ($it['check_status'] === 'duplicate') $why = 'Fichier identique déjà importé'; elseif (!$code) $why = 'Code manquant'; elseif (!$title) $why = 'Titre manquant'; elseif (!$u['approved_proof']) $why = 'Approbation non attestée'; elseif (!$u['review_due'] || $u['review_due'] <= $u['effective_date']) $why = 'Échéance de revue absente ou antérieure à la date d\'effet';
                if (!$why) { $ex = DB::one('SELECT * FROM pd_procedures WHERE code=?', [$code]);
                    if ($ex && DB::val("SELECT 1 FROM pd_versions WHERE procedure_id=? AND state IN ('draft','submitted','returned','approved','scheduled')", [(int)$ex['id']])) $why = 'Code en conflit : une version est en cours';
                    else { $pid = $ex ? (int)$ex['id'] : (int)DB::insert('pd_procedures', ['code' => $code, 'title' => $title, 'process_id' => $u['process_id'], 'direction' => $u['direction'], 'owner_id' => Auth::id(), 'writer_id' => Auth::id(), 'visibility' => 'internal', 'status' => 'draft', 'publications' => 0, 'created_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()]);
                        $n = (int)DB::val('SELECT COALESCE(MAX(number),0) FROM pd_versions WHERE procedure_id=?', [$pid]) + 1; $vid = (int)DB::insert('pd_versions', ['procedure_id' => $pid, 'number' => $n, 'state' => 'approved', 'reason' => $ex ? 'Reprise du dossier existant (lot ' . $id . ')' : null, 'effective_date' => $u['effective_date'], 'review_due' => $u['review_due'], 'decided_by' => Auth::id(), 'decided_at' => now(), 'decision_note' => 'Approbation attestée à l\'import', 'imported' => 1, 'created_by' => Auth::id(), 'created_at' => now()]);
                        DB::insert('pd_files', ['version_id' => $vid, 'kind' => 'final', 'original_name' => $it['original_name'], 'stored_name' => $it['stored_name'], 'mime' => $it['mime'], 'size' => (int)$it['size'], 'sha256' => $it['sha256'], 'user_id' => Auth::id(), 'created_at' => now()]);
                        self::event($pid, $vid, 'imported', 'Importé depuis le lot ' . $id . ' (' . $it['original_name'] . ')'); $e = self::publish($pid, $vid, true); if ($e) $why = $e; else { $u['procedure_id'] = $pid; $pub++; } } }
                if ($why) { $u['decision'] = 'reject'; $u['reject_reason'] = $why; } }
            if ($u['decision'] === 'reject') $rej++; DB::update('pd_import_items', $u, 'id=?', [(int)$it['id']]);
        }
        DB::update('pd_imports', ['status' => 'done', 'decided_at' => now(), 'published' => $pub, 'rejected' => $rej], 'id=?', [(int)$id]); Audit::log('import', 'pd_import', (int)$id, null, ['published' => $pub, 'rejected' => $rej]);
        $this->go("pd/import/$id", "$pub procédure(s) publiée(s), $rej ligne(s) rejetée(s) : le bilan est exportable.");
    }
}
