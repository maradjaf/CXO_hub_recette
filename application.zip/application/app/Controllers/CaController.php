<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Ca};
class CaController extends Controller {
    // =============== Référentiels de contrôle (checklists) ===============
    function checklists(): void {
        $this->view('ca/checklists', ['title' => 'Référentiels de contrôle', 'rows' => DB::all("SELECT k.*, (SELECT COUNT(*) FROM ca_items i WHERE i.checklist_id=k.id) ni, (SELECT COUNT(*) FROM ca_controls c WHERE c.checklist_id=k.id) nc FROM ca_checklists k ORDER BY k.code, k.version DESC")]);
    }
    private function listData(): array {
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'description' => ['label' => 'La description', 'max' => 500]], $_POST);
        $pass = (int)$this->in('pass_pct', 80); if ($pass < 1 || $pass > 100) $err['p'] = 'Le seuil de conformité doit être compris entre 1 et 100 %.';
        $sub = in_array($this->in('subject'), ['store', 'team', 'support'], true) ? $this->in('subject') : 'store';
        return [$d + ['pass_pct' => $pass, 'subject' => $sub, 'updated_at' => now()], $err];
    }
    function storeChecklist(): void {
        [$d, $err] = $this->listData(); $code = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string)$this->in('code', '')));
        if ($code === '' || strlen($code) > 40) $err['c'] = 'Code obligatoire (lettres, chiffres, - et _).'; elseif (DB::val('SELECT 1 FROM ca_checklists WHERE code=?', [$code])) $err['c2'] = 'Ce code existe déjà.';
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('ca/checklists'); }
        $id = DB::insert('ca_checklists', $d + ['code' => $code, 'version' => 1, 'status' => 'draft', 'created_by' => Auth::id(), 'created_at' => now()]); Audit::log('create', 'ca_checklist', $id, null, $d); flash('Référentiel créé en brouillon : ajoutez les points de contrôle.'); redirect("ca/checklists/$id");
    }
    private function chk(string $id): ?array { $k = DB::one('SELECT * FROM ca_checklists WHERE id=?', [(int)$id]); if (!$k) $this->notFound(); return $k; }
    private function needDraft(array $k): void { if ($k['status'] !== 'draft') { flash('Un référentiel actif ne se modifie pas (les contrôles déjà réalisés s\'y réfèrent) : créez une nouvelle version.', 'warning'); redirect('ca/checklists/' . $k['id']); } }
    function checklist(string $id): void {
        if (!($k = $this->chk($id))) return;
        $this->view('ca/checklist', ['title' => $k['name'], 'k' => $k, 'items' => DB::all('SELECT * FROM ca_items WHERE checklist_id=? ORDER BY position, id', [(int)$id]), 'hasDraft' => (bool)DB::val("SELECT 1 FROM ca_checklists WHERE code=? AND status='draft' AND id<>?", [$k['code'], (int)$id])]);
    }
    function updateChecklist(string $id): void {
        if (!($k = $this->chk($id))) return; $this->needDraft($k); [$d, $err] = $this->listData(); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("ca/checklists/$id"); }
        DB::update('ca_checklists', $d, 'id=?', [(int)$id]); Audit::log('update', 'ca_checklist', $id, $k, $d); flash('Référentiel enregistré.'); redirect("ca/checklists/$id");
    }
    private function itemData(): array {
        [$d, $err] = $this->validate(['label' => ['label' => 'Le point de contrôle', 'req' => true, 'max' => 300], 'section' => ['label' => 'La section', 'max' => 100], 'guidance' => ['label' => 'La consigne', 'max' => 500]], $_POST);
        $w = (int)$this->in('weight', 1); if ($w < 1 || $w > 5) $err['w'] = 'Le poids doit être compris entre 1 et 5.';
        return [$d + ['weight' => $w, 'critical' => $this->in('critical') === '1' ? 1 : 0, 'comment_required' => $this->in('comment_required') === '1' ? 1 : 0], $err];
    }
    function storeItem(string $id): void {
        if (!($k = $this->chk($id))) return; $this->needDraft($k); [$d, $err] = $this->itemData(); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("ca/checklists/$id"); }
        $pos = (int)DB::val('SELECT COALESCE(MAX(position),0) FROM ca_items WHERE checklist_id=?', [(int)$id]) + 1; DB::insert('ca_items', $d + ['checklist_id' => (int)$id, 'position' => $pos]); flash('Point ajouté.'); redirect("ca/checklists/$id");
    }
    function updateItem(string $id, string $iid): void {
        if (!($k = $this->chk($id))) return; $this->needDraft($k); $it = DB::one('SELECT * FROM ca_items WHERE id=? AND checklist_id=?', [(int)$iid, (int)$id]); if (!$it) { $this->notFound(); return; }
        [$d, $err] = $this->itemData(); if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("ca/checklists/$id"); }
        $pos = (int)$this->in('position', $it['position']); if ($pos < 1 || $pos > 999) $pos = (int)$it['position'];
        DB::update('ca_items', $d + ['position' => $pos], 'id=?', [(int)$iid]); flash('Point enregistré.'); redirect("ca/checklists/$id");
    }
    function deleteItem(string $id, string $iid): void {
        if (!($k = $this->chk($id))) return; $this->needDraft($k); DB::pdo()->prepare('DELETE FROM ca_items WHERE id=? AND checklist_id=?')->execute([(int)$iid, (int)$id]); flash('Point supprimé.'); redirect("ca/checklists/$id");
    }
    function checklistStatus(string $id): void {
        if (!($k = $this->chk($id))) return; $a = (string)$this->in('action');
        if ($a === 'publish' && $k['status'] === 'draft') {
            if (!DB::val('SELECT 1 FROM ca_items WHERE checklist_id=?', [(int)$id])) { flash('Ajoutez au moins un point de contrôle.', 'danger'); redirect("ca/checklists/$id"); }
            DB::update('ca_checklists', ['status' => 'archived'], "code=? AND status='active'", [$k['code']]); DB::update('ca_checklists', ['status' => 'active', 'updated_at' => now()], 'id=?', [(int)$id]); $m = 'Référentiel activé (les versions précédentes sont archivées ; les plannings suivent automatiquement la version active).';
        } elseif ($a === 'archive' && $k['status'] === 'active') { DB::update('ca_checklists', ['status' => 'archived'], 'id=?', [(int)$id]); $m = 'Référentiel archivé.'; }
        elseif ($a === 'version' && $k['status'] !== 'draft') {
            if (DB::val("SELECT 1 FROM ca_checklists WHERE code=? AND status='draft'", [$k['code']])) { flash('Une version brouillon existe déjà.', 'warning'); redirect("ca/checklists/$id"); }
            $v = (int)DB::val('SELECT MAX(version) FROM ca_checklists WHERE code=?', [$k['code']]) + 1;
            $nid = DB::insert('ca_checklists', ['code' => $k['code'], 'version' => $v, 'name' => $k['name'], 'description' => $k['description'], 'subject' => $k['subject'], 'pass_pct' => $k['pass_pct'], 'status' => 'draft', 'created_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()]);
            foreach (DB::all('SELECT * FROM ca_items WHERE checklist_id=? ORDER BY position, id', [(int)$id]) as $i) DB::insert('ca_items', ['checklist_id' => $nid, 'position' => $i['position'], 'section' => $i['section'], 'label' => $i['label'], 'guidance' => $i['guidance'], 'weight' => $i['weight'], 'critical' => $i['critical'], 'comment_required' => $i['comment_required']]);
            Audit::log('version', 'ca_checklist', $nid, null, ['from' => $id]); flash("Version $v créée en brouillon."); redirect("ca/checklists/$nid");
        } else { flash('Action impossible.', 'danger'); redirect("ca/checklists/$id"); }
        Audit::log($a, 'ca_checklist', $id); flash($m); redirect("ca/checklists/$id");
    }

    // =============== Contrôles ===============
    private function cform(): array {
        return ['checklists' => DB::all("SELECT id, name, version, subject FROM ca_checklists WHERE status='active' ORDER BY name"), 'stores' => DB::all('SELECT id, name, city FROM stores WHERE active=1 ORDER BY name'), 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'), 'controllers' => Ca::usersWith('ca.control')];
    }
    function create(): void { $this->view('ca/new', ['title' => 'Planifier ou lancer un contrôle'] + $this->cform()); }
    function store(): void {
        $k = DB::one("SELECT * FROM ca_checklists WHERE id=? AND status='active'", [(int)$this->in('checklist_id')]); if (!$k) { flash('Choisissez un référentiel actif.', 'danger'); redirect('ca/new'); }
        $store = $k['subject'] === 'store' ? (int)$this->in('store_id', 0) : 0; $team = $k['subject'] === 'team' ? (int)$this->in('team_id', 0) : 0;
        if ($k['subject'] === 'store' && !DB::val('SELECT 1 FROM stores WHERE id=?', [$store])) { flash('Choisissez le store contrôlé.', 'danger'); redirect('ca/new'); }
        if ($k['subject'] === 'team' && !DB::val('SELECT 1 FROM teams WHERE id=?', [$team])) { flash('Choisissez l\'équipe contrôlée.', 'danger'); redirect('ca/new'); }
        $ctl = Auth::id(); if (can('ca.manage') && ($x = (int)$this->in('controller_id', 0))) { if (!in_array($x, array_map('intval', array_column(Ca::usersWith('ca.control'), 'id')), true)) { flash('Ce contrôleur n\'a pas le droit de réaliser des contrôles.', 'danger'); redirect('ca/new'); } $ctl = $x; }
        $date = (string)$this->in('planned_date', date('Y-m-d')); if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $date = date('Y-m-d');
        $id = DB::insert('ca_controls', ['reference' => Ca::ref('CTL', 'ca_controls'), 'checklist_id' => (int)$k['id'], 'store_id' => $store ?: null, 'team_id' => $team ?: null, 'controller_id' => $ctl, 'planned_date' => $date, 'status' => 'planned', 'created_by' => Auth::id(), 'created_at' => now()]);
        if ($ctl !== Auth::id()) Notifier::send($ctl, 'Contrôle à réaliser', DB::val('SELECT reference FROM ca_controls WHERE id=?', [$id]) . ' · prévu le ' . d($date), '/ca/controls/' . $id);
        Audit::log('create', 'ca_control', $id, null, ['checklist' => $k['code'], 'controller' => $ctl]); flash('Contrôle créé.'); redirect("ca/controls/$id");
    }
    function mine(): void {
        $this->view('ca/mine', ['title' => 'Mes contrôles', 'todo' => DB::all("SELECT c.*, k.name checklist FROM ca_controls c JOIN ca_checklists k ON k.id=c.checklist_id WHERE c.controller_id=? AND c.status IN ('planned','in_progress') ORDER BY c.planned_date", [Auth::id()]),
            'done' => DB::all("SELECT c.*, k.name checklist FROM ca_controls c JOIN ca_checklists k ON k.id=c.checklist_id WHERE c.controller_id=? AND c.status='completed' ORDER BY c.completed_at DESC LIMIT 10", [Auth::id()])]);
    }
    function controls(): void {
        [$w, $p] = Ca::scope('c'); $w = [$w];
        foreach (['status' => 'c.status', 'result' => 'c.result', 'checklist_id' => 'c.checklist_id', 'store_id' => 'c.store_id', 'team_id' => 'c.team_id', 'n2_status' => 'c.n2_status'] as $k => $col) if ($this->in($k) !== null && $this->in($k) !== '') { $w[] = "$col=?"; $p[] = $this->in($k); }
        if ($this->in('late') === '1') { $w[] = "c.status IN ('planned','in_progress') AND c.planned_date<?"; $p[] = date('Y-m-d'); }
        $from = 'ca_controls c JOIN ca_checklists k ON k.id=c.checklist_id LEFT JOIN stores s ON s.id=c.store_id LEFT JOIN teams t ON t.id=c.team_id LEFT JOIN users u ON u.id=c.controller_id WHERE ' . implode(' AND ', $w);
        if ($this->in('export') === 'csv') {
            $rows = DB::all("SELECT c.reference, k.name checklist, s.name store, t.name team, u.name controller, c.planned_date, c.status, c.completed_at, c.score_pct, c.result, c.n2_status FROM $from ORDER BY c.id DESC", $p); Audit::log('export', 'ca_controls', null, null, ['rows' => count($rows)]);
            csv_download('controles_n1.csv', ['Référence', 'Référentiel', 'Store', 'Équipe', 'Contrôleur', 'Prévu le', 'Statut', 'Terminé le', 'Score %', 'Résultat', 'Revue N2'], array_map(fn($r) => [$r['reference'], $r['checklist'], $r['store'], $r['team'], $r['controller'], $r['planned_date'], Ca::CS[$r['status']] ?? $r['status'], $r['completed_at'], $r['score_pct'], Ca::RES[$r['result']] ?? '', $r['n2_status']], $rows));
        }
        $this->view('ca/controls', ['title' => 'Contrôles', 'p' => paginate($from, $p, $this->page(), 25, 'c.*, k.name checklist, s.name store, t.name team, u.name controller', 'c.id DESC'), 'checklists' => DB::all('SELECT DISTINCT name, id FROM ca_checklists ORDER BY name'), 'stores' => DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name'), 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name')]);
    }
    private function load(string $id): ?array {
        $c = DB::one('SELECT c.*, k.name checklist, k.pass_pct, k.version, k.code FROM ca_controls c JOIN ca_checklists k ON k.id=c.checklist_id WHERE c.id=?', [(int)$id]);
        if (!$c) { $this->notFound(); return null; } if (!Ca::canSee($c)) { $this->forbidden(); return null; } return $c;
    }
    private function canRun(array $c): bool { return in_array($c['status'], ['planned', 'in_progress'], true) && ((int)$c['controller_id'] === Auth::id() || can('ca.manage')); }
    function control(string $id): void {
        if (!($c = $this->load($id))) return;
        $items = DB::all('SELECT i.*, r.answer, r.comment rcomment FROM ca_items i LEFT JOIN ca_results r ON r.item_id=i.id AND r.control_id=? WHERE i.checklist_id=? ORDER BY i.position, i.id', [(int)$id, (int)$c['checklist_id']]);
        $files = []; foreach (DB::all('SELECT * FROM ca_files WHERE control_id=? ORDER BY id', [(int)$id]) as $f) $files[(int)$f['item_id']][] = $f;
        $this->view('ca/control', ['title' => $c['reference'], 'c' => $c, 'items' => $items, 'files' => $files, 'subject' => Ca::subject($c), 'run' => $this->canRun($c), 'owners' => Ca::usersWith('ca.act'),
            'actions' => DB::all('SELECT a.*, u.name owner FROM ca_actions a LEFT JOIN users u ON u.id=a.owner_id WHERE a.control_id=? ORDER BY a.id', [(int)$id]), 'controllerName' => DB::val('SELECT name FROM users WHERE id=?', [(int)$c['controller_id']])]);
    }
    const EV_TYPES = ['png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'pdf' => 'application/pdf'];
    private static function evDir(): string { $d = ROOT . '/storage/uploads/ca'; if (!is_dir($d)) @mkdir($d, 0775, true); return $d; }
    /** Enregistre les preuves (png, jpg, pdf ; 5 Mo ; 5 par point) d'un point de contrôle. @return string[] erreurs */
    private function takeEvidence(int $cid, int $iid): array {
        $f = $_FILES["ev_$iid"] ?? null; $err = []; if (!$f || !is_array($f['name'])) return [];
        $have = (int)DB::val('SELECT COUNT(*) FROM ca_files WHERE control_id=? AND item_id=?', [$cid, $iid]);
        foreach ($f['name'] as $k => $name) {
            if (($f['error'][$k] ?? 4) === UPLOAD_ERR_NO_FILE) continue;
            if ($f['error'][$k] !== UPLOAD_ERR_OK) { $err[] = "« $name » non reçu."; continue; }
            if ($have >= 5) { $err[] = '5 preuves maximum par point.'; break; }
            $n = trim(preg_replace('#[\x00-\x1f\\\\/]+#', '_', (string)$name)); $ext = strtolower(pathinfo($n, PATHINFO_EXTENSION));
            if (!isset(self::EV_TYPES[$ext]) || $f['size'][$k] > 5 * 1024 * 1024) { $err[] = "« $n » refusé (png, jpg ou pdf, 5 Mo maximum)."; continue; }
            $mime = function_exists('mime_content_type') ? (string)@mime_content_type($f['tmp_name'][$k]) : ''; if ($mime !== '' && $mime !== self::EV_TYPES[$ext]) { $err[] = "« $n » : contenu non conforme à l'extension."; continue; }
            $stored = bin2hex(random_bytes(16)) . '.' . $ext; if (!@move_uploaded_file($f['tmp_name'][$k], self::evDir() . '/' . $stored)) { $err[] = "« $n » non enregistré."; continue; }
            DB::insert('ca_files', ['control_id' => $cid, 'item_id' => $iid, 'user_id' => Auth::id(), 'original_name' => mb_substr($n, 0, 190), 'stored_name' => $stored, 'mime' => self::EV_TYPES[$ext], 'size' => (int)$f['size'][$k], 'created_at' => now()]); $have++;
        }
        return $err;
    }
    function file(string $fid): void {
        $f = DB::one('SELECT * FROM ca_files WHERE id=?', [(int)$fid]); if (!$f) { $this->notFound(); return; }
        $c = DB::one('SELECT * FROM ca_controls WHERE id=?', [(int)$f['control_id']]); if (!$c || !Ca::canSee($c)) { $this->forbidden(); return; }
        $path = self::evDir() . '/' . $f['stored_name']; if (!is_file($path)) { $this->notFound(); return; } Audit::log('download', 'ca_file', $fid);
        header('Content-Type: ' . $f['mime']); header('X-Content-Type-Options: nosniff'); header("Content-Security-Policy: sandbox; default-src 'none'; img-src 'self'; style-src 'unsafe-inline'"); header('Content-Length: ' . filesize($path));
        header('Content-Disposition: inline; filename="' . rawurlencode($f['original_name']) . '"; filename*=UTF-8\'\'' . rawurlencode($f['original_name'])); readfile($path); exit;
    }
    function save(string $id): void {
        if (!($c = $this->load($id))) return; if (!$this->canRun($c)) { $this->forbidden(); return; }
        $items = DB::all('SELECT * FROM ca_items WHERE checklist_id=? ORDER BY position, id', [(int)$c['checklist_id']]); $evErr = [];
        foreach ($items as $i) {
            $a = $_POST['a'][$i['id']] ?? ''; $cm = trim((string)($_POST['c'][$i['id']] ?? '')); $cm = mb_substr($cm, 0, 500);
            if (isset(Ca::ANS[$a])) { $old = DB::val('SELECT id FROM ca_results WHERE control_id=? AND item_id=?', [(int)$id, (int)$i['id']]); $row = ['answer' => $a, 'comment' => $cm !== '' ? $cm : null];
                if ($old) DB::update('ca_results', $row, 'id=?', [(int)$old]); else DB::insert('ca_results', $row + ['control_id' => (int)$id, 'item_id' => (int)$i['id']]); }
            $evErr = array_merge($evErr, $this->takeEvidence((int)$id, (int)$i['id']));
        }
        $com = mb_substr(trim((string)$this->in('comment', '')), 0, 1000);
        DB::update('ca_controls', ['comment' => $com !== '' ? $com : null, 'status' => 'in_progress'] + ($c['started_at'] ? [] : ['started_at' => now()]), 'id=?', [(int)$id]);
        if ($this->in('finish') !== '1') { flash('Saisie enregistrée.' . ($evErr ? ' ' . implode(' ', $evErr) : ''), $evErr ? 'warning' : 'success'); redirect("ca/controls/$id"); }
        // clôture
        $res = DB::all('SELECT r.*, i.comment_required, i.label FROM ca_results r JOIN ca_items i ON i.id=r.item_id WHERE r.control_id=?', [(int)$id]); $err = [];
        if (count($res) < count($items)) $err[] = (count($items) - count($res)) . ' point(s) sans réponse.';
        foreach ($res as $r) if ($r['answer'] === 'ko' && $r['comment_required'] && trim((string)$r['comment']) === '') $err[] = 'Commentaire obligatoire : « ' . mb_substr($r['label'], 0, 60) . ' ».';
        $ko = array_filter($res, fn($r) => $r['answer'] === 'ko'); $owner = (int)$this->in('owner_id', 0);
        if ($ko && !in_array($owner, array_map('intval', array_column(Ca::usersWith('ca.act'), 'id')), true)) $err[] = 'Désignez le responsable des actions correctives.';
        if ($err) { flash('Clôture impossible : ' . implode(' ', $err) . ($evErr ? ' ' . implode(' ', $evErr) : ''), 'danger'); redirect("ca/controls/$id"); }
        [$score, $result] = Ca::compute((int)$id, (int)$c['pass_pct']);
        DB::update('ca_controls', ['status' => 'completed', 'completed_at' => now(), 'score_pct' => $score, 'result' => $result], 'id=?', [(int)$id]);
        $n = Ca::openActions($c, $owner ?: null);
        if ($result === 'critical') { Notifier::toPermission('ca.manage', 'Écart critique constaté', $c['reference'] . ' · ' . Ca::subject($c), '/ca/controls/' . $id); Notifier::toPermission('ca.review', 'Écart critique constaté', $c['reference'] . ' · ' . Ca::subject($c), '/ca/controls/' . $id); }
        Audit::log('complete', 'ca_control', $id, null, ['score' => $score, 'result' => $result, 'actions' => $n]);
        flash('Contrôle terminé : ' . ($score === null ? 'aucun point applicable' : round($score) . ' %') . ' · ' . Ca::RES[$result] . ($n ? " · $n action(s) corrective(s) créée(s)." : '.')); redirect("ca/controls/$id");
    }
    function cancel(string $id): void {
        if (!($c = $this->load($id))) return; if (!in_array($c['status'], ['planned', 'in_progress'], true)) { flash('Ce contrôle ne peut plus être annulé.', 'danger'); redirect("ca/controls/$id"); }
        DB::update('ca_controls', ['status' => 'cancelled'], 'id=?', [(int)$id]); Audit::log('cancel', 'ca_control', $id); flash('Contrôle annulé.'); redirect("ca/controls/$id");
    }
    function review(string $id): void {
        if (!($c = $this->load($id))) return; if ($c['status'] !== 'completed') { flash('Seul un contrôle terminé peut être revu.', 'danger'); redirect("ca/controls/$id"); }
        $note = trim((string)$this->in('n2_comment', '')); if ($note === '') { flash('Saisissez votre appréciation.', 'danger'); redirect("ca/controls/$id"); }
        DB::update('ca_controls', ['n2_status' => 'reviewed', 'n2_by' => Auth::id(), 'n2_at' => now(), 'n2_comment' => mb_substr($note, 0, 500)], 'id=?', [(int)$id]); Audit::log('review_n2', 'ca_control', $id); flash('Revue de niveau 2 enregistrée.'); redirect("ca/controls/$id");
    }

    // =============== Actions correctives ===============
    private function aScope(): array {
        [$w, $p] = Ca::scope('c'); $me = Auth::id();
        return can('ca.view') ? ["(a.owner_id=? OR a.control_id IS NULL OR c.id IS NOT NULL AND $w)", array_merge([$me], $p)] : ['a.owner_id=?', [$me]];
    }
    function actions(): void {
        [$w0, $p] = $this->aScope(); $w = [$w0];
        if ($this->in('mine') === '1') { $w[] = 'a.owner_id=?'; $p[] = Auth::id(); }
        foreach (['status' => 'a.status', 'priority' => 'a.priority', 'owner_id' => 'a.owner_id'] as $k => $col) if ($this->in($k) !== null && $this->in($k) !== '') { $w[] = "$col=?"; $p[] = $this->in($k); }
        if ($this->in('late') === '1') { $w[] = "a.status IN ('open','in_progress') AND a.due_date<?"; $p[] = date('Y-m-d'); }
        $from = 'ca_actions a LEFT JOIN ca_controls c ON c.id=a.control_id LEFT JOIN users u ON u.id=a.owner_id WHERE ' . implode(' AND ', $w);
        if ($this->in('export') === 'csv') {
            $rows = DB::all("SELECT a.reference, c.reference control, a.title, a.priority, u.name owner, a.due_date, a.status, a.done_at, a.verified_at FROM $from ORDER BY a.id DESC", $p); Audit::log('export', 'ca_actions', null, null, ['rows' => count($rows)]);
            csv_download('actions_correctives.csv', ['Référence', 'Contrôle', 'Action', 'Priorité', 'Responsable', 'Échéance', 'Statut', 'Réalisée le', 'Vérifiée le'], array_map(fn($r) => [$r['reference'], $r['control'], $r['title'], Ca::PRIO[$r['priority']] ?? '', $r['owner'], $r['due_date'], Ca::AS[$r['status']] ?? '', $r['done_at'], $r['verified_at']], $rows));
        }
        $this->view('ca/actions', ['title' => 'Actions correctives', 'p' => paginate($from, $p, $this->page(), 25, 'a.*, c.reference control, u.name owner', "CASE a.status WHEN 'open' THEN 0 WHEN 'in_progress' THEN 1 WHEN 'done' THEN 2 ELSE 3 END, a.due_date"), 'owners' => Ca::usersWith('ca.act')]);
    }
    private function loadAction(string $id): ?array {
        $a = DB::one('SELECT a.*, u.name owner FROM ca_actions a LEFT JOIN users u ON u.id=a.owner_id WHERE a.id=?', [(int)$id]); if (!$a) { $this->notFound(); return null; }
        $c = $a['control_id'] ? DB::one('SELECT * FROM ca_controls WHERE id=?', [(int)$a['control_id']]) : null;
        $ok = (int)$a['owner_id'] === Auth::id() || (can('ca.view') && (!$c || Ca::canSee($c))); if (!$ok) { $this->forbidden(); return null; } $a['_c'] = $c; return $a;
    }
    private function canVerify(array $a): bool { return can('ca.manage') || ($a['_c'] && (int)$a['_c']['controller_id'] === Auth::id()); }
    function action(string $id): void {
        if (!($a = $this->loadAction($id))) return;
        $this->view('ca/action', ['title' => $a['reference'], 'a' => $a, 'c' => $a['_c'], 'owner' => (int)$a['owner_id'] === Auth::id(), 'verify' => $this->canVerify($a), 'owners' => Ca::usersWith('ca.act')]);
    }
    function updateAction(string $id): void {
        if (!($a = $this->loadAction($id))) return; $act = (string)$this->in('action'); $owner = (int)$a['owner_id'] === Auth::id(); $ver = $this->canVerify($a); $note = trim((string)$this->in('note', '')); $u = []; $m = '';
        if ($act === 'start' && $owner && $a['status'] === 'open') { $u['status'] = 'in_progress'; $m = 'Action démarrée.'; }
        elseif ($act === 'done' && $owner && in_array($a['status'], ['open', 'in_progress'], true)) {
            if ($note === '') { flash('Décrivez ce qui a été fait.', 'danger'); redirect("ca/actions/$id"); }
            $u = ['status' => 'done', 'done_at' => now(), 'done_note' => mb_substr($note, 0, 1000)]; $m = 'Action déclarée réalisée : en attente de vérification.';
            if ($a['_c']) Notifier::send((int)$a['_c']['controller_id'], 'Action à vérifier', $a['reference'] . ' · ' . $a['title'], '/ca/actions/' . $id);
        } elseif ($act === 'verify' && $ver && $a['status'] === 'done') { $u = ['status' => 'verified', 'verified_by' => Auth::id(), 'verified_at' => now(), 'verify_note' => $note !== '' ? mb_substr($note, 0, 500) : null]; $m = 'Efficacité vérifiée : action clôturée.'; }
        elseif ($act === 'reopen' && $ver && in_array($a['status'], ['done', 'verified'], true)) {
            if ($note === '') { flash('Indiquez pourquoi l\'action est rouverte.', 'danger'); redirect("ca/actions/$id"); }
            $u = ['status' => 'in_progress', 'verify_note' => mb_substr($note, 0, 500), 'verified_by' => null, 'verified_at' => null, 'done_at' => null]; $m = 'Action rouverte.'; if ($a['owner_id']) Notifier::send((int)$a['owner_id'], 'Action rouverte', $a['reference'] . ' : ' . mb_substr($note, 0, 100), '/ca/actions/' . $id);
        } elseif ($act === 'cancel' && $ver && in_array($a['status'], Ca::OPEN_ACT, true)) { $u['status'] = 'cancelled'; $m = 'Action annulée.'; }
        elseif ($act === 'assign' && $ver && in_array($a['status'], Ca::OPEN_ACT, true)) {
            $o = (int)$this->in('owner_id', 0); $due = (string)$this->in('due_date', '');
            if (!in_array($o, array_map('intval', array_column(Ca::usersWith('ca.act'), 'id')), true) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $due)) { flash('Responsable ou échéance invalide.', 'danger'); redirect("ca/actions/$id"); }
            $u = ['owner_id' => $o, 'due_date' => $due, 'reminded_at' => null]; $m = 'Responsable et échéance mis à jour.'; if ($o !== (int)$a['owner_id']) Notifier::send($o, 'Action corrective à traiter', $a['reference'] . ' · ' . $a['title'], '/ca/actions/' . $id);
        } else { $this->forbidden(); return; }
        DB::update('ca_actions', $u, 'id=?', [(int)$id]); Audit::log($act, 'ca_action', $id, ['status' => $a['status']], $u); flash($m); redirect("ca/actions/$id");
    }

    // =============== Plannings ===============
    function schedules(): void {
        $this->view('ca/schedules', ['title' => 'Planification des contrôles', 'rows' => DB::all('SELECT s.*, k.name checklist, st.name store, t.name team, u.name controller FROM ca_schedules s JOIN ca_checklists k ON k.id=s.checklist_id LEFT JOIN stores st ON st.id=s.store_id LEFT JOIN teams t ON t.id=s.team_id LEFT JOIN users u ON u.id=s.controller_id ORDER BY s.active DESC, s.next_date')] + $this->cform());
    }
    function storeSchedule(): void {
        $k = DB::one("SELECT * FROM ca_checklists WHERE id=? AND status='active'", [(int)$this->in('checklist_id')]); $freq = $this->in('frequency'); $date = (string)$this->in('next_date', '');
        $store = $k && $k['subject'] === 'store' ? (int)$this->in('store_id', 0) : 0; $team = $k && $k['subject'] === 'team' ? (int)$this->in('team_id', 0) : 0; $ctl = (int)$this->in('controller_id', 0);
        $bad = !$k || !isset(Ca::FREQ[$freq]) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !in_array($ctl, array_map('intval', array_column(Ca::usersWith('ca.control'), 'id')), true)
            || ($k['subject'] === 'store' && !DB::val('SELECT 1 FROM stores WHERE id=?', [$store])) || ($k['subject'] === 'team' && !DB::val('SELECT 1 FROM teams WHERE id=?', [$team]));
        if ($bad) { flash('Planning incomplet : référentiel actif, périmètre, contrôleur, fréquence et première date sont requis.', 'danger'); redirect('ca/schedules'); }
        $id = DB::insert('ca_schedules', ['checklist_id' => (int)$k['id'], 'store_id' => $store ?: null, 'team_id' => $team ?: null, 'controller_id' => $ctl, 'frequency' => $freq, 'next_date' => $date, 'active' => 1, 'created_at' => now()]); Audit::log('create', 'ca_schedule', $id); flash('Planning créé : les contrôles sont générés à chaque échéance (bin/ca-schedule.php).'); redirect('ca/schedules');
    }
    function toggleSchedule(string $id): void { $s = DB::one('SELECT * FROM ca_schedules WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; } DB::update('ca_schedules', ['active' => $s['active'] ? 0 : 1], 'id=?', [(int)$id]); Audit::log('toggle', 'ca_schedule', $id); redirect('ca/schedules'); }
    function deleteSchedule(string $id): void { DB::pdo()->prepare('DELETE FROM ca_schedules WHERE id=?')->execute([(int)$id]); Audit::log('delete', 'ca_schedule', $id); flash('Planning supprimé (les contrôles déjà générés sont conservés).'); redirect('ca/schedules'); }

    // =============== Tableau de bord ===============
    function dashboard(): void {
        $from = (string)$this->in('from', date('Y-m-d', strtotime('-90 days'))); $to = (string)$this->in('to', date('Y-m-d'));
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) $from = date('Y-m-d', strtotime('-90 days')); if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) $to = date('Y-m-d');
        [$sw, $sp] = Ca::scope('c'); $w = "$sw AND c.status='completed' AND c.completed_at>=? AND c.completed_at<?"; $p = array_merge($sp, [$from . ' 00:00:00', date('Y-m-d', strtotime($to . ' +1 day')) . ' 00:00:00']);
        if ($k = (int)$this->in('checklist_id', 0)) { $w .= ' AND c.checklist_id=?'; $p[] = $k; }
        $agg = DB::one("SELECT COUNT(*) n, AVG(c.score_pct) avg, SUM(CASE WHEN c.result='critical' THEN 1 ELSE 0 END) crit, SUM(CASE WHEN c.result='conform' THEN 1 ELSE 0 END) ok FROM ca_controls c WHERE $w", $p);
        $late = (int)DB::val("SELECT COUNT(*) FROM ca_controls c WHERE $sw AND c.status IN ('planned','in_progress') AND c.planned_date<?", array_merge($sp, [date('Y-m-d')]));
        $act = DB::one("SELECT COUNT(*) n, SUM(CASE WHEN a.status IN ('open','in_progress') THEN 1 ELSE 0 END) open, SUM(CASE WHEN a.status IN ('open','in_progress') AND a.due_date<? THEN 1 ELSE 0 END) late, SUM(CASE WHEN a.status='done' THEN 1 ELSE 0 END) toverify, SUM(CASE WHEN a.status='verified' THEN 1 ELSE 0 END) verified FROM ca_actions a JOIN ca_controls c ON c.id=a.control_id WHERE $sw AND a.status<>'cancelled'", array_merge([date('Y-m-d')], $sp));
        $bySubject = DB::all("SELECT COALESCE(s.name, t.name, 'Fonction support') subject, COUNT(*) n, AVG(c.score_pct) avg, SUM(CASE WHEN c.result='critical' THEN 1 ELSE 0 END) crit FROM ca_controls c LEFT JOIN stores s ON s.id=c.store_id LEFT JOIN teams t ON t.id=c.team_id WHERE $w GROUP BY COALESCE(s.name, t.name, 'Fonction support') ORDER BY avg ASC LIMIT 15", $p);
        $bySection = DB::all("SELECT COALESCE(i.section, 'Général') section, SUM(CASE WHEN r.answer='ko' THEN 1 ELSE 0 END) ko, SUM(CASE WHEN r.answer<>'na' THEN 1 ELSE 0 END) tot FROM ca_results r JOIN ca_items i ON i.id=r.item_id JOIN ca_controls c ON c.id=r.control_id WHERE $w GROUP BY COALESCE(i.section, 'Général') ORDER BY ko DESC", $p);
        $topKo = DB::all("SELECT i.label, COUNT(*) n, COUNT(DISTINCT COALESCE(c.store_id, 0) * 1000 + COALESCE(c.team_id, 0)) subjects FROM ca_results r JOIN ca_items i ON i.id=r.item_id JOIN ca_controls c ON c.id=r.control_id WHERE $w AND r.answer='ko' GROUP BY i.id, i.label ORDER BY n DESC LIMIT 8", $p);
        $months = DB::all("SELECT SUBSTR(c.completed_at,1,7) m, COUNT(*) n, AVG(c.score_pct) avg FROM ca_controls c WHERE $w GROUP BY SUBSTR(c.completed_at,1,7) ORDER BY m", $p);
        $this->view('ca/dashboard', ['title' => 'Tableau de bord N1', 'from' => $from, 'to' => $to, 'k' => $k, 'agg' => $agg, 'late' => $late, 'act' => $act, 'bySubject' => $bySubject, 'bySection' => $bySection, 'topKo' => $topKo, 'months' => $months, 'checklists' => DB::all('SELECT DISTINCT id, name, version FROM ca_checklists ORDER BY name')]);
    }
}
