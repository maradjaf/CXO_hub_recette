<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Fr, FrStats};

/** Lot 60 — Franchises : comparaisons configurables (3 modes), suivi des SLA et de l'âge du stock, qualité. */
class FrAnalyticsController extends Controller {
    const MEAS = ['received', 'closed', 'ops', 'rest', 'exec', 'sla', 'stock', 'late', 'median', 'p90'];
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    private static function day($v, string $d): string { return Fr::isDay($v) ? $v : $d; }
    /** Plage [from,to] lue dans la requête sous le préfixe $p. */
    private static function range(array $g, string $p, array $def): array { $a = self::day($g[$p . '_from'] ?? null, $def[0]); $b = self::day($g[$p . '_to'] ?? null, $def[1]); return $a > $b ? [$b, $a] : [$a, $b]; }

    function compare(): void {
        if (!can('fr.view')) { $this->forbidden(); return; } $g = $_GET; $cov = FrStats::coverage('received'); $end = $cov['to'] ?? date('Y-m-d');
        $mode = in_array($g['mode'] ?? '', ['periods', 'franchises', 'windows'], true) ? $g['mode'] : 'periods'; $m = in_array($g['m'] ?? '', self::MEAS, true) ? $g['m'] : 'received';
        $f = FrStats::filters($g, Fr::addDays($end, -6), $end); $f['norm'] = !empty($g['norm']) ? 1 : 0; $f['align'] = !empty($g['align']) ? 1 : 0;
        $defB = [Fr::addDays($end, -6), $end]; $defA = FrStats::shift($defB[0], $defB[1], 'prev'); $A = self::range($g, 'a', $defA); $B = self::range($g, 'b', $defB);
        if (!empty($g['sc']) && in_array($g['sc'], ['prev', 'year'], true)) $A = FrStats::shift($B[0], $B[1], $g['sc']);
        $out = ['mode' => $mode, 'm' => $m, 'f' => $f, 'A' => $A, 'B' => $B, 'rows' => [], 'tot' => null, 'cfgs' => DB::all('SELECT * FROM fr_compare_cfg WHERE shared=1 OR user_id=? ORDER BY name', [(int)\App\Core\Auth::id()]), 'contrib' => [], 'cov' => $cov];
        $calOk = Fr::setting('fr.calendar_validated', '0') === '1';
        if ($mode === 'periods') {
            if ($f['align']) [$A, $B] = FrStats::align($A, $B); $ids = FrStats::ids($f, $B[1]); $a = FrStats::value($m, $f, $A[0], $A[1], $ids, true); $b = FrStats::value($m, $f, $B[0], $B[1], $ids, true);
            $out += ['a' => $a, 'b' => $b, 'gap' => FrStats::gap($m, $a, $b), 'sa' => FrStats::span($A[0], $A[1]), 'sb' => FrStats::span($B[0], $B[1]), 'calOk' => $calOk, 'A2' => $A, 'B2' => $B];
            if ($f['norm'] && $calOk && FrStats::M[$m][2] === 'vol') { $na = ['v' => FrStats::perWorkday($a, $A[0], $A[1])]; $nb = ['v' => FrStats::perWorkday($b, $B[0], $B[1])]; $out['norm'] = [$na, $nb, FrStats::gap($m, $na, $nb)]; }
            $pa = FrStats::by($m, $f, $A[0], $A[1], 'fid', $ids, true); $pb = FrStats::by($m, $f, $B[0], $B[1], 'fid', $ids, true); $names = array_column(Fr::franchiseList(), 'name', 'id'); $rows = [];
            foreach (array_unique(array_merge(array_keys($pa), array_keys($pb))) as $k) { $x = ['v' => $pa[$k]['v'] ?? null] + ($pa[$k] ?? []); $y = ['v' => $pb[$k]['v'] ?? null] + ($pb[$k] ?? []); $rows[] = ['id' => (int)$k, 'name' => $names[$k] ?? ('#' . $k), 'a' => $x['v'], 'b' => $y['v'], 'gap' => FrStats::gap($m, $x, $y)]; }
            $s = (string)($g['sort'] ?? 'diff'); usort($rows, fn($p, $q) => $s === 'b' ? [$q['b'] ?? -1] <=> [$p['b'] ?? -1] : abs($q['gap']['abs'] ?? 0) <=> abs($p['gap']['abs'] ?? 0)); $out['rows'] = array_slice($rows, 0, max(5, min(100, (int)($g['top'] ?? 15)))); $out['nrows'] = count($rows);
            if (FrStats::M[$m][2] === 'vol') { $dim = in_array($g['dim'] ?? '', ['service', 'fid'], true) ? $g['dim'] : 'service'; $out['dim'] = $dim; $out['contrib'] = FrStats::contributions($m, $f, $A, $B, $dim, max(3, min(15, (int)($g['top'] ?? 8)))); }
        } elseif ($mode === 'franchises') {
            $from = $f['from']; $to = $f['to']; $sel = $f['fr']; if (!$sel && $f['zone']) { $sel = array_map(fn($x) => (int)$x['id'], array_filter(Fr::franchiseList(true), fn($x) => in_array($x['zone'], $f['zone'], true))); }
            $net = FrStats::value($m, array_merge($f, ['fr' => [], 'zone' => []]), $from, $to); $rows = []; $names = array_column(Fr::franchiseList(), 'name', 'id');
            $all = FrStats::by($m, array_merge($f, ['fr' => [], 'zone' => []]), $from, $to, 'fid'); $vals = array_map(fn($x) => $x['v'], $all);
            foreach ($sel as $id) { $x = $all[$id] ?? ['v' => null, 'num' => null, 'den' => null, 'n' => 0]; [$rk, $pc] = $x['v'] === null ? [null, null] : FrStats::rank($vals, $x['v']); $rows[] = ['id' => (int)$id, 'name' => $names[$id] ?? ('#' . $id)] + $x + ['rank' => $rk, 'pc' => $pc, 'weak' => $x['v'] !== null && ($x['n'] ?? 0) < (int)Fr::setting('fr.weak_base', '20') && FrStats::M[$m][2] !== 'vol']; }
            usort($rows, fn($p, $q) => ($q['v'] ?? -INF) <=> ($p['v'] ?? -INF)); $out += ['rows' => $rows, 'net' => $net, 'span' => FrStats::span($from, $to), 'nall' => count($all)];
        } else {
            $fid = $f['fr'][0] ?? 0; $wins = []; foreach ((array)($g['w'] ?? []) as $w) if (Fr::isDay($w['from'] ?? null) && Fr::isDay($w['to'] ?? null) && $w['from'] <= $w['to']) $wins[] = [$w['from'], $w['to'], trim((string)($w['name'] ?? ''))];
            if (isset($g['wdel'])) unset($wins[(int)$g['wdel']]); $wins = array_values($wins); if (count($wins) < 2 && $fid) { $wins = [[Fr::addDays($end, -6), $end, ''], [Fr::addDays($end, -13), Fr::addDays($end, -7), ''], [Fr::addDays($end, -34), Fr::addDays($end, -28), '']]; }
            if (isset($g['wadd'])) { $l = end($wins); $wins[] = $l ? [Fr::addDays($l[0], -7), Fr::addDays($l[1], -7), ''] : [Fr::addDays($end, -6), $end, '']; }
            $rows = []; if ($fid) foreach ($wins as $w) { $x = FrStats::value($m, array_merge($f, ['fr' => [$fid]]), $w[0], $w[1], [$fid], true); $sp = FrStats::span($w[0], $w[1]); $rows[] = ['from' => $w[0], 'to' => $w[1], 'name' => $w[2], 'x' => $x, 'span' => $sp]; }
            $out += ['wins' => $wins, 'rows' => $rows, 'fid' => $fid, 'calOk' => $calOk];
        }
        $this->view('fr/compare', $out + ['title' => 'Comparaisons', 'o' => FrController::opts(), 'g' => $g]);
    }
    function saveCfg(): void {
        if (!can('fr.view')) { $this->forbidden(); return; } $name = trim((string)$this->in('name', '')); $q = (string)$this->in('query', ''); parse_str($q, $arr); unset($arr['_csrf'], $arr['csrf']);
        if ($name === '' || mb_strlen($name) > 150) $this->go('fr/compare?' . $q, 'Donnez un nom à la configuration (150 caractères au plus).', 'danger'); $mode = in_array($arr['mode'] ?? '', ['periods', 'franchises', 'windows'], true) ? $arr['mode'] : 'periods';
        $shared = !empty($_POST['shared']) && can('fr.manage') ? 1 : 0; $id = DB::insert('fr_compare_cfg', ['name' => $name, 'mode' => $mode, 'config' => json_encode($arr, JSON_UNESCAPED_UNICODE), 'user_id' => (int)\App\Core\Auth::id(), 'shared' => $shared, 'created_at' => now()]);
        Audit::log('fr.compare.save', 'fr_compare_cfg', $id, null, ['name' => $name]); $this->go('fr/compare?' . http_build_query($arr), 'Configuration enregistrée.');
    }
    function loadCfg(string $id): void { $c = DB::one('SELECT * FROM fr_compare_cfg WHERE id=? AND (shared=1 OR user_id=?)', [$id, (int)\App\Core\Auth::id()]); if (!$c) { $this->notFound(); return; } redirect('fr/compare?' . http_build_query(json_decode($c['config'], true) ?: [])); }
    function delCfg(string $id): void { DB::exec('DELETE FROM fr_compare_cfg WHERE id=? AND (user_id=? OR ?=1)', [$id, (int)\App\Core\Auth::id(), can('fr.manage') ? 1 : 0]); $this->go('fr/compare', 'Configuration supprimée.'); }

    /** Suivi des SLA : âge du stock par statut, médiane/P90 par typologie, Pareto des motifs de blocage et de rejet. */
    function sla(): void {
        if (!can('fr.view')) { $this->forbidden(); return; } $cov = FrStats::coverage('received'); $end = $cov['to'] ?? date('Y-m-d'); $f = FrStats::filters($_GET, Fr::addDays($end, -29), $end); $ids = FrStats::ids($f, $f['to']); $in = $ids === null ? '' : ($ids ? ' AND r.franchise_id IN (' . implode(',', array_map('intval', $ids)) . ')' : ' AND 1=0'); $now = now();
        $age = ['0-24 h' => [0, 24], '1-3 j' => [24, 72], '3-7 j' => [72, 168], '> 7 j' => [168, 1e9]]; $stock = DB::all("SELECT r.status, r.team, r.created_at, r.due_at FROM fr_requests r WHERE r.status IN ('new','assigned','in_progress','waiting')" . $in . ($f['service'] !== '' ? ' AND r.service=' . DB::pdo()->quote($f['service']) : ''));
        $matrix = []; $byTeam = []; foreach ($stock as $r) { $h = (strtotime($now) - strtotime($r['created_at'])) / 3600; foreach ($age as $k => [$lo, $hi]) if ($h >= $lo && $h < $hi) { $matrix[$r['status']][$k] = ($matrix[$r['status']][$k] ?? 0) + 1; $t = $r['team'] ?: 'Sans équipe'; $byTeam[$t][$k] = ($byTeam[$t][$k] ?? 0) + 1; } }
        $why = DB::all("SELECT COALESCE(rs.label,'Sans motif') label, COUNT(*) n FROM fr_requests r LEFT JOIN fr_reasons rs ON rs.id=r.reason_id WHERE (r.status IN ('rejected','not_executed','cancelled') OR r.status='waiting')" . $in . ' GROUP BY COALESCE(rs.label,\'Sans motif\') ORDER BY n DESC');
        $typ = FrStats::by('median', $f, $f['from'], $f['to'], 'typology', $ids, true); $p90 = FrStats::by('p90', $f, $f['from'], $f['to'], 'typology', $ids, true); $old = DB::all("SELECT r.id, r.ref, r.created_at, r.status, r.due_at, r.service, fr.name franchise FROM fr_requests r JOIN fr_franchises fr ON fr.id=r.franchise_id WHERE r.status IN ('new','assigned','in_progress','waiting')" . $in . ' ORDER BY r.created_at LIMIT 10');
        $this->view('fr/sla', ['title' => 'Suivi des SLA', 'f' => $f, 'o' => FrController::opts(), 'matrix' => $matrix, 'age' => array_keys($age), 'byTeam' => $byTeam, 'why' => $why, 'typ' => $typ, 'p90' => $p90, 'old' => $old, 'cat' => DB::all('SELECT * FROM fr_catalog WHERE active=1 ORDER BY service, typology, subtype')]);
    }
    /** Contrôle qualité : non-conformités et score par franchise. */
    function quality(): void {
        if (!can('fr.view')) { $this->forbidden(); return; } $cov = FrStats::coverage('quality'); $end = $cov['to'] ?? date('Y-m-d'); $f = FrStats::filters($_GET, Fr::addDays($end, -29), $end); $ids = FrStats::ids($f, $f['to']);
        $nc = FrStats::by('nc', $f, $f['from'], $f['to'], 'fid', $ids, true); $q = FrStats::by('quality', $f, $f['from'], $f['to'], 'fid', $ids, true); $names = array_column(Fr::franchiseList(), 'name', 'id'); $rows = [];
        foreach (array_unique(array_merge(array_keys($nc), array_keys($q))) as $k) $rows[] = ['id' => (int)$k, 'name' => $names[$k] ?? ('#' . $k), 'nc' => $nc[$k] ?? null, 'q' => $q[$k] ?? null]; usort($rows, fn($a, $b) => ($b['nc']['v'] ?? -1) <=> ($a['nc']['v'] ?? -1));
        $list = DB::all('SELECT q.*, f.name franchise FROM fr_qc q JOIN fr_franchises f ON f.id=q.franchise_id WHERE q.day>=? AND q.day<=? ORDER BY q.day DESC, q.id DESC LIMIT 100', [$f['from'], $f['to']]);
        $this->view('fr/quality', ['title' => 'Contrôle qualité', 'f' => $f, 'o' => FrController::opts(), 'rows' => $rows, 'list' => $list, 'cov' => $cov]);
    }
    function qualitySave(): void {
        if (!can('fr.manage') && !can('fr.handle')) { $this->forbidden(); return; } $fid = (int)$this->in('franchise_id', 0); $day = (string)$this->in('day', ''); $c = (int)$this->in('controls', 0); $n = (int)$this->in('nonconform', 0);
        $gm = (string)$this->in('points_max', ''); $gg = (string)$this->in('points_got', ''); $err = null;
        if (!Fr::franchise($fid)) $err = 'Franchise obligatoire.'; elseif (!Fr::isDay($day)) $err = 'Date du contrôle invalide.'; elseif ($c < 1) $err = 'Le nombre de contrôles doit être au moins 1.'; elseif ($n < 0 || $n > $c) $err = 'Les non-conformités ne peuvent pas dépasser les contrôles.';
        elseif (($gm !== '' || $gg !== '') && (!is_numeric($gm) || !is_numeric($gg) || (float)$gg > (float)$gm || (float)$gg < 0)) $err = 'Points obtenus et maximum incohérents.'; if ($err) $this->go('fr/quality', $err, 'danger');
        $id = DB::insert('fr_qc', ['franchise_id' => $fid, 'day' => $day, 'scope' => in_array($this->in('scope'), ['FO', 'BO'], true) ? $this->in('scope') : 'FO', 'controls' => $c, 'nonconform' => $n, 'points_got' => $gg === '' ? null : (float)$gg, 'points_max' => $gm === '' ? null : (float)$gm, 'reason' => mb_substr(trim((string)$this->in('reason', '')), 0, 190) ?: null, 'plan_ref' => mb_substr(trim((string)$this->in('plan_ref', '')), 0, 60) ?: null, 'source' => 'saisie', 'is_demo' => 0]);
        FrStats::resetCache(); Audit::log('fr.qc.create', 'fr_qc', $id); $this->go('fr/quality', 'Contrôle enregistré.');
    }
}
