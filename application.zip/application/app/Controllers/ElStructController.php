<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, ELearn, RichHtml, Xchg};

/** Éditeur de cours : modules > chapitres > sous-chapitres, contenu riche, quiz de partie, études de cas et exposés. */
class ElStructController extends Controller {
    private function course_(string $id): ?array { $c = DB::one('SELECT * FROM el_courses WHERE id=?', [(int)$id]); if (!$c) $this->notFound(); return $c; }
    private function node_(array $c, string $nid): ?array { $n = DB::one('SELECT * FROM el_lessons WHERE id=? AND course_id=?', [(int)$nid, (int)$c['id']]); if (!$n) $this->notFound(); return $n; }
    private function needDraft(array $c, string $to): void { if ($c['status'] === 'published') { flash('Dépubliez le cours avant de modifier sa structure (ajout, suppression, déplacement) : les apprenants en cours ne doivent pas voir le parcours changer.', 'warning'); redirect($to); } }
    private function depthOf(int $nodeId): int { $d = 0; $seen = []; while ($nodeId && !isset($seen[$nodeId])) { $seen[$nodeId] = 1; $d++; $nodeId = (int)DB::val('SELECT parent_id FROM el_lessons WHERE id=?', [$nodeId]); } return $d; }
    private function height(int $nodeId): int { $m = 0; foreach (DB::all('SELECT id FROM el_lessons WHERE parent_id=?', [$nodeId]) as $k) $m = max($m, $this->height((int)$k['id'])); return $m + 1; }
    private function isUnder(int $nodeId, int $ancestor): bool { $seen = []; while ($nodeId && !isset($seen[$nodeId])) { if ($nodeId === $ancestor) return true; $seen[$nodeId] = 1; $nodeId = (int)DB::val('SELECT parent_id FROM el_lessons WHERE id=?', [$nodeId]); } return false; }
    private function renumber(int $cid, ?int $parent): void { $i = 0; foreach (DB::all('SELECT id FROM el_lessons WHERE course_id=? AND ' . ($parent ? 'parent_id=?' : 'parent_id IS NULL') . ' ORDER BY position, id', $parent ? [$cid, $parent] : [$cid]) as $r) DB::update('el_lessons', ['position' => ++$i], 'id=?', [(int)$r['id']]); }

    function structure(string $id): void {
        if (!($c = $this->course_($id))) return; $nodes = ELearn::nodes((int)$id);
        $acts = []; foreach (DB::all('SELECT node_id, COUNT(*) n FROM el_activities WHERE course_id=? GROUP BY node_id', [(int)$id]) as $a) $acts[(int)$a['node_id']] = (int)$a['n'];
        $this->view('elearn/structure', ['title' => 'Structure : ' . $c['title'], 'c' => $c, 'nodes' => $nodes, 'acts' => $acts, 'endActs' => DB::all('SELECT * FROM el_activities WHERE course_id=? AND node_id IS NULL ORDER BY position, id', [(int)$id]), 'errors' => $c['status'] === 'draft' ? ELearn::publishErrors((int)$id) : []]);
    }
    function nodeCreate(string $id): void {
        if (!($c = $this->course_($id))) return; $to = "elearn/$id/structure"; $this->needDraft($c, $to);
        $t = trim((string)$this->in('title')); $parent = (int)$this->in('parent_id', 0) ?: null; $kind = isset(ELearn::KINDS[(string)$this->in('kind')]) ? (string)$this->in('kind') : 'text';
        if ($t === '' || mb_strlen($t) > 190) { flash('Titre obligatoire (190 caractères maximum).', 'danger'); redirect($to); }
        if ($parent) { if (!DB::val('SELECT 1 FROM el_lessons WHERE id=? AND course_id=?', [$parent, (int)$id])) { $this->notFound(); return; } if ($this->depthOf($parent) >= 3) { flash('Trois niveaux au maximum : module, chapitre, sous-chapitre.', 'danger'); redirect($to); } }
        $pos = (int)DB::val('SELECT COALESCE(MAX(position),0) FROM el_lessons WHERE course_id=? AND ' . ($parent ? 'parent_id=?' : 'parent_id IS NULL'), $parent ? [(int)$id, $parent] : [(int)$id]) + 1;
        $nid = DB::insert('el_lessons', ['course_id' => (int)$id, 'parent_id' => $parent, 'position' => $pos, 'title' => $t, 'body' => '', 'kind' => $kind]);
        Audit::log('create', 'el_lesson', $nid, null, ['course' => $id, 'title' => $t, 'parent' => $parent]); flash('Partie ajoutée : complétez son contenu.'); redirect("elearn/$id/nodes/$nid");
    }
    function nodeEdit(string $id, string $nid): void {
        if (!($c = $this->course_($id)) || !($n = $this->node_($c, $nid))) return; $nodes = ELearn::nodes((int)$id); $me = null; foreach ($nodes as $x) if ((int)$x['id'] === (int)$nid) $me = $x;
        $this->view('elearn/node', ['title' => $n['title'], 'c' => $c, 'n' => $n, 'me' => $me, 'nodes' => $nodes, 'qs' => ELearn::questions((int)$id, true, null, (int)$nid), 'acts' => DB::all('SELECT * FROM el_activities WHERE course_id=? AND node_id=? ORDER BY position, id', [(int)$id, (int)$nid]), 'hasKids' => (bool)DB::val('SELECT 1 FROM el_lessons WHERE parent_id=?', [(int)$nid])]);
    }
    private function takeVideo(): array {
        $f = $_FILES['lesson_file'] ?? null; if (!$f || ($f['error'] ?? 4) === UPLOAD_ERR_NO_FILE) return [null, null];
        if ($f['error'] !== UPLOAD_ERR_OK) return [null, 'Fichier non reçu (limite PHP : upload_max_filesize / post_max_size).'];
        if ($f['size'] > ELearnController::FILE_MAX) return [null, 'Fichier trop volumineux (150 Mo maximum).'];
        $name = trim(preg_replace('#[\x00-\x1f\\\\/]+#', '_', (string)$f['name'])); $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $ok = ['mp4' => 'video/mp4', 'webm' => 'video/webm', 'mp3' => 'audio/mpeg', 'pdf' => 'application/pdf', 'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg']; if (!isset($ok[$ext])) return [null, 'Type non autorisé (mp4, webm, mp3, pdf, png, jpg).'];
        $mime = function_exists('mime_content_type') ? (string)@mime_content_type($f['tmp_name']) : ''; if ($mime !== '' && !in_array($mime, ELearnController::FILE_TYPES[$ext], true)) return [null, 'Le contenu du fichier ne correspond pas à son extension.'];
        $stored = bin2hex(random_bytes(16)) . '.' . $ext; if (!@move_uploaded_file($f['tmp_name'], ELearnController::fileDir() . '/' . $stored)) return [null, 'Enregistrement impossible.'];
        return [['file_stored' => $stored, 'file_name' => mb_substr($name, 0, 190), 'file_mime' => $ok[$ext], 'file_size' => (int)$f['size']], null];
    }
    private function dropFile(?string $s): void { if ($s && preg_match('/^[a-f0-9]{32}\.[a-z0-9]{2,4}$/', $s)) @unlink(ELearnController::fileDir() . '/' . $s); }
    function nodeUpdate(string $id, string $nid): void {
        if (!($c = $this->course_($id)) || !($n = $this->node_($c, $nid))) return; $to = "elearn/$id/nodes/$nid"; $err = [];
        $t = trim((string)$this->in('title')); if ($t === '' || mb_strlen($t) > 190) $err[] = 'Titre obligatoire (190 caractères maximum).';
        $kind = isset(ELearn::KINDS[(string)$this->in('kind')]) ? (string)$this->in('kind') : 'text'; $body = RichHtml::clean((string)$this->in('body'), 400000);
        $url = trim((string)$this->in('url')); if ($url !== '' && (!preg_match('#^https://[^\s<>"]+$#i', $url) || mb_strlen($url) > 500)) $err[] = 'Le lien doit commencer par https://.';
        [$file, $ferr] = $this->takeVideo(); if ($ferr) $err[] = $ferr; $removeFile = $this->in('remove_file') === '1';
        if ($kind === 'text') { $body = preg_replace('#<(iframe|video|audio)\b[^>]*>(.*?)</\1>#is', '', $body); $body = preg_replace('#<(iframe|video|audio)\b[^>]*/?>#i', '', $body); }
        if ($kind === 'video' && mb_strlen(RichHtml::text($body)) > 600) $err[] = 'Un module vidéo n\'accepte qu\'une courte description (600 caractères) : choisissez « Mixte » pour du texte détaillé.';
        $parent = $n['parent_id'] ? (int)$n['parent_id'] : null;
        if ($this->in('parent_id') !== null && (int)$this->in('parent_id', 0) !== (int)$parent) {   // déplacement sous un autre parent
            $np = (int)$this->in('parent_id', 0) ?: null;
            if ($c['status'] === 'published') $err[] = 'Dépubliez le cours pour déplacer une partie.';
            elseif ($np && (!DB::val('SELECT 1 FROM el_lessons WHERE id=? AND course_id=?', [$np, (int)$id]) || $this->isUnder($np, (int)$nid))) $err[] = 'Destination invalide.';
            elseif ($np && $this->depthOf($np) + $this->height((int)$nid) > 3) $err[] = 'Ce déplacement dépasserait trois niveaux.'; else $parent = $np;
        }
        $pr = $this->in('quiz_pass_pct'); $pct = ($pr === null || $pr === '') ? null : (int)$pr; if ($pct !== null && ($pct < 1 || $pct > 100)) $err[] = 'Seuil du quiz entre 1 et 100.';
        if ($err) { if ($file) $this->dropFile($file['file_stored']); flash(implode(' ', $err), 'danger'); redirect($to); }
        $cols = ['title' => $t, 'kind' => $kind, 'body' => $body, 'url' => $kind === 'text' ? null : ($url ?: null), 'duration_min' => ($dm = (int)$this->in('duration_min', 0)) > 0 ? min($dm, 999) : null, 'quiz_required' => $this->in('quiz_required') === '1' ? 1 : 0, 'quiz_pass_pct' => $pct];
        if ($parent !== ($n['parent_id'] ? (int)$n['parent_id'] : null)) { $cols['parent_id'] = $parent; $cols['position'] = 9999; }
        if ($kind === 'text') { $this->dropFile($n['file_stored']); $cols += ['file_stored' => null, 'file_name' => null, 'file_mime' => null, 'file_size' => null]; }
        elseif ($file) { $this->dropFile($n['file_stored']); $cols += $file; } elseif ($removeFile && $n['file_stored']) { $this->dropFile($n['file_stored']); $cols += ['file_stored' => null, 'file_name' => null, 'file_mime' => null, 'file_size' => null]; }
        DB::update('el_lessons', $cols, 'id=?', [(int)$nid]); if (isset($cols['position'])) { $this->renumber((int)$id, $parent); $this->renumber((int)$id, $n['parent_id'] ? (int)$n['parent_id'] : null); }
        DB::update('el_courses', ['updated_at' => now()], 'id=?', [(int)$id]); Audit::log('update', 'el_lesson', $nid, null, ['title' => $t, 'kind' => $kind]); flash('Partie enregistrée.'); redirect($to);
    }
    function nodeMove(string $id, string $nid): void {
        if (!($c = $this->course_($id)) || !($n = $this->node_($c, $nid))) return; $to = "elearn/$id/structure"; $this->needDraft($c, $to);
        $par = $n['parent_id'] ? (int)$n['parent_id'] : null; $this->renumber((int)$id, $par);
        $sib = DB::all('SELECT id FROM el_lessons WHERE course_id=? AND ' . ($par ? 'parent_id=?' : 'parent_id IS NULL') . ' ORDER BY position, id', $par ? [(int)$id, $par] : [(int)$id]); $ids = array_map('intval', array_column($sib, 'id')); $i = array_search((int)$nid, $ids, true);
        $j = $this->in('dir') === 'up' ? $i - 1 : $i + 1; if ($i !== false && $j >= 0 && $j < count($ids)) { [$ids[$i], $ids[$j]] = [$ids[$j], $ids[$i]]; foreach ($ids as $k => $x) DB::update('el_lessons', ['position' => $k + 1], 'id=?', [$x]); }
        redirect($to . '#n' . $nid);
    }
    private function descendants(int $nid): array { $o = [$nid]; foreach (DB::all('SELECT id FROM el_lessons WHERE parent_id=?', [$nid]) as $k) $o = array_merge($o, $this->descendants((int)$k['id'])); return $o; }
    function nodeDelete(string $id, string $nid): void {
        if (!($c = $this->course_($id)) || !($n = $this->node_($c, $nid))) return; $to = "elearn/$id/structure"; $this->needDraft($c, $to);
        foreach ($this->descendants((int)$nid) as $x) {
            if ($f = DB::val('SELECT file_stored FROM el_lessons WHERE id=?', [$x])) $this->dropFile($f);
            foreach (DB::all('SELECT id FROM el_questions WHERE node_id=?', [$x]) as $q) DB::exec('DELETE FROM el_options WHERE question_id=?', [(int)$q['id']]); DB::exec('DELETE FROM el_answers WHERE question_id IN (SELECT id FROM el_questions WHERE node_id=?)', [$x]);
            DB::exec('DELETE FROM el_questions WHERE node_id=?', [$x]); DB::exec('DELETE FROM el_answers WHERE attempt_id IN (SELECT id FROM el_attempts WHERE node_id=?)', [$x]); DB::exec('DELETE FROM el_attempts WHERE node_id=?', [$x]);
            foreach (DB::all('SELECT id, file_stored FROM el_submissions WHERE activity_id IN (SELECT id FROM el_activities WHERE node_id=?)', [$x]) as $sb) $this->dropFile($sb['file_stored']);
            DB::exec('DELETE FROM el_submissions WHERE activity_id IN (SELECT id FROM el_activities WHERE node_id=?)', [$x]); DB::exec('DELETE FROM el_activities WHERE node_id=?', [$x]); DB::exec('DELETE FROM el_progress WHERE lesson_id=?', [$x]); DB::exec('DELETE FROM el_threads WHERE node_id=?', [$x]);
        }
        foreach (array_reverse($this->descendants((int)$nid)) as $x) DB::exec('DELETE FROM el_lessons WHERE id=?', [$x]);
        $this->renumber((int)$id, $n['parent_id'] ? (int)$n['parent_id'] : null); Audit::log('delete', 'el_lesson', $nid, ['course' => $id, 'title' => $n['title']]); flash('Partie supprimée (avec ses sous-parties, quiz et activités).'); redirect($to);
    }
    // ---- activités (études de cas, exposés) ----
    private function actData(): array {
        $err = []; $t = trim((string)$this->in('title')); if ($t === '' || mb_strlen($t) > 190) $err[] = 'Titre de l\'activité obligatoire.';
        $type = isset(ELearn::ACT[(string)$this->in('type')]) ? (string)$this->in('type') : 'case'; $ins = RichHtml::clean((string)$this->in('instructions'), 100000); if (trim(RichHtml::text($ins)) === '') $err[] = 'Les consignes sont obligatoires.';
        return [['title' => $t, 'type' => $type, 'instructions' => $ins, 'required' => $this->in('required') === '1' ? 1 : 0], $err];
    }
    function actStore(string $id): void {
        if (!($c = $this->course_($id))) return; $nid = (int)$this->in('node_id', 0) ?: null; $to = $nid ? "elearn/$id/nodes/$nid#acts" : "elearn/$id/structure#acts"; $this->needDraft($c, $to);
        if ($nid && !DB::val('SELECT 1 FROM el_lessons WHERE id=? AND course_id=?', [$nid, (int)$id])) { $this->notFound(); return; }
        [$d, $err] = $this->actData(); if ($err) { flash(implode(' ', $err), 'danger'); redirect($to); }
        $pos = (int)DB::val('SELECT COALESCE(MAX(position),0) FROM el_activities WHERE course_id=?', [(int)$id]) + 1; $aid = DB::insert('el_activities', $d + ['course_id' => (int)$id, 'node_id' => $nid, 'position' => $pos, 'created_at' => now()]);
        Audit::log('create', 'el_activity', $aid, null, ['course' => $id]); flash('Activité ajoutée.'); redirect($to);
    }
    function actUpdate(string $id, string $aid): void {
        if (!($c = $this->course_($id))) return; $a = DB::one('SELECT * FROM el_activities WHERE id=? AND course_id=?', [(int)$aid, (int)$id]); if (!$a) { $this->notFound(); return; }
        $to = $a['node_id'] ? "elearn/$id/nodes/{$a['node_id']}#acts" : "elearn/$id/structure#acts"; [$d, $err] = $this->actData(); if ($err) { flash(implode(' ', $err), 'danger'); redirect($to); }
        DB::update('el_activities', $d, 'id=?', [(int)$aid]); Audit::log('update', 'el_activity', $aid, null, ['course' => $id]); flash('Activité enregistrée.'); redirect($to);
    }
    function actDelete(string $id, string $aid): void {
        if (!($c = $this->course_($id))) return; $a = DB::one('SELECT * FROM el_activities WHERE id=? AND course_id=?', [(int)$aid, (int)$id]); if (!$a) { $this->notFound(); return; }
        $to = $a['node_id'] ? "elearn/$id/nodes/{$a['node_id']}#acts" : "elearn/$id/structure#acts"; $this->needDraft($c, $to);
        foreach (DB::all('SELECT file_stored FROM el_submissions WHERE activity_id=?', [(int)$aid]) as $sb) $this->dropFile($sb['file_stored']); DB::exec('DELETE FROM el_submissions WHERE activity_id=?', [(int)$aid]); DB::exec('DELETE FROM el_activities WHERE id=?', [(int)$aid]);
        Audit::log('delete', 'el_activity', $aid, ['course' => $id]); flash('Activité supprimée.'); redirect($to);
    }
}
