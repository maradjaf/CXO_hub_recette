<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Sms, SvSend};

/** Lot 67 — Page publique d'une enquête reçue par lien personnel (/s/{jeton}) et désinscription. */
class SvPublicController extends Controller {
    private function inv(string $t): ?array { return preg_match('/^[a-f0-9]{24}$/', $t) ? (DB::one('SELECT * FROM sv_invitations WHERE token=?', [$t]) ?: null) : null; }
    function show(string $token): void {
        $v = $this->inv($token); if (!$v) { $this->notFound(); return; } if (!$v['opened_at']) DB::update('sv_invitations', ['opened_at' => now()], 'id=?', [$v['id']]);
        $this->showPage($v, null);
    }
    private function showPage(array $v, ?string $msg, bool $done = false): void {
        $s = DB::one('SELECT * FROM sv_surveys WHERE id=?', [(int)$v['survey_id']]);
        $this->view('survey/public', ['title' => $s['name'] ?? 'Enquête', 's' => $s, 'v' => $v, 'qs' => DB::all('SELECT * FROM sv_questions WHERE survey_id=? ORDER BY position, id', [(int)$v['survey_id']]), 'msg' => $msg, 'done' => $done, 'open' => !in_array($v['status'], ['answered', 'expired', 'cancelled', 'failed'], true)], 'layout/public');
    }
    function submit(string $token): void {
        $v = $this->inv($token); if (!$v) { $this->notFound(); return; }
        if (!empty($_POST['website'])) { $this->showPage($v, 'Merci !', true); return; }   // champ piège anti-robots
        [$ok, $msg] = SvSend::answer($v, (array)($_POST['a'] ?? []), trim((string)($_POST['comment'] ?? '')));
        $this->showPage($ok ? (DB::one('SELECT * FROM sv_invitations WHERE id=?', [$v['id']]) ?: $v) : $v, $msg, $ok);
    }
    function stop(string $token): void { $v = $this->inv($token); if (!$v) { $this->notFound(); return; } $this->view('survey/stop', ['title' => 'Ne plus recevoir d\'enquêtes', 'v' => $v, 'done' => false], 'layout/public'); }
    function stopDo(string $token): void {
        $v = $this->inv($token); if (!$v) { $this->notFound(); return; } $ph = Sms::normalize((string)$v['to_phone']);
        if ($ph && !DB::val('SELECT 1 FROM sv_optouts WHERE phone=?', [$ph])) DB::insert('sv_optouts', ['phone' => $ph, 'reason' => 'Désinscription par le client (lien)', 'created_at' => now()]);
        DB::exec("UPDATE sv_invitations SET status='cancelled' WHERE to_phone=? AND status IN ('queued','ready','sent')", [$v['to_phone']]);
        $this->view('survey/stop', ['title' => 'Ne plus recevoir d\'enquêtes', 'v' => $v, 'done' => true], 'layout/public');
    }
}
