<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Auth};

/** Images insérées dans l'ordre du jour et le compte rendu : ne demande que le droit d'organiser des réunions (pas celui de l'e-learning). */
class RnMediaController extends Controller {
    const TYPES = ['png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'gif' => 'image/gif', 'webp' => 'image/webp'];
    const MAX = 8 * 1048576;
    private function json($d, int $code = 200): never { http_response_code($code); header('Content-Type: application/json; charset=utf-8'); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
    function upload(): void {
        $f = $_FILES['file'] ?? null; if (!$f || ($f['error'] ?? 4) !== UPLOAD_ERR_OK) $this->json(['error' => 'Fichier non reçu (limite PHP : upload_max_filesize / post_max_size).'], 422);
        if ($f['size'] > self::MAX) $this->json(['error' => 'Image trop volumineuse (8 Mo maximum).'], 422);
        $name = trim(preg_replace('#[\x00-\x1f\\\\/]+#', '_', (string)$f['name'])); $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if (!isset(self::TYPES[$ext])) $this->json(['error' => 'Seules les images (png, jpg, gif, webp) sont acceptées dans un compte rendu.'], 422);
        $mime = function_exists('mime_content_type') ? (string)@mime_content_type($f['tmp_name']) : ''; if ($mime !== '' && !str_starts_with($mime, 'image/')) $this->json(['error' => 'Le contenu du fichier ne correspond pas à une image.'], 422);
        $stored = bin2hex(random_bytes(16)) . '.' . $ext; if (!@move_uploaded_file($f['tmp_name'], ELearnController::fileDir() . '/' . $stored)) $this->json(['error' => 'Enregistrement impossible.'], 500);
        DB::insert('el_media', ['stored_name' => $stored, 'name' => mb_substr($name, 0, 190), 'mime' => self::TYPES[$ext], 'size' => (int)$f['size'], 'user_id' => Auth::id(), 'created_at' => now()]);
        $this->json(['url' => '/rn/media/' . pathinfo($stored, PATHINFO_FILENAME), 'name' => $name, 'mime' => self::TYPES[$ext]]);
    }
    function serve(string $stored): void {
        if (!preg_match('/^[a-f0-9]{32}$/', $stored)) { $this->notFound(); return; }
        $m = DB::one('SELECT * FROM el_media WHERE stored_name LIKE ? AND mime LIKE ?', [$stored . '.%', 'image/%']); if (!$m) { $this->notFound(); return; }
        ELearnController::stream(['file_stored' => $m['stored_name'], 'file_mime' => $m['mime'], 'file_name' => $m['name']]);
    }
}
