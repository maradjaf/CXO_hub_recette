<?php
namespace App\Controllers;
use App\Core\{Controller, Auth, DB};
class DashboardController extends Controller {
    function index(): void {
        if (!empty(Auth::user()['employer_code']) && can('provider.view')) redirect('provider');
        if (can('inc.support') && !can('employees.view') && !can('inc.view') && !can('inc.declare')) redirect('support');   // intervenant support : accès limité à son espace
        $d = ['title' => 'Tableau de bord', 'wd' => \App\Core\DashConfig::forUser(Auth::id())];
        if (can('employees.view')) {
            $d['employees'] = (int)DB::val("SELECT COUNT(*) FROM employees WHERE status='active'");
            $d['teams'] = (int)DB::val('SELECT COUNT(*) FROM teams WHERE active=1');
            $d['stores'] = (int)DB::val('SELECT COUNT(*) FROM stores WHERE active=1');
            $d['byTeam'] = DB::all("SELECT t.name, COUNT(e.id) n FROM teams t LEFT JOIN employees e ON e.team_id=t.id AND e.status='active' WHERE t.active=1 GROUP BY t.id, t.name ORDER BY n DESC LIMIT 12");
        }
        if (can('contracts.view')) $d['contractsSoon'] = (int)DB::val("SELECT COUNT(*) FROM contracts WHERE status='active' AND end_date IS NOT NULL AND end_date<=?", [date('Y-m-d', strtotime('+30 days'))]);
        if (can('absence.view')) $d['absRate'] = AbsencesController::rate(date('Y-m-01'), date('Y-m-t'))['rate'];
        if (can('workflow.approve')) { $d['toValidate'] = 0; foreach (DB::all("SELECT * FROM wf_requests WHERE status='pending'") as $r) if (\App\Core\Workflow::canAct(Auth::id(), $r)) $d['toValidate']++; }
        if (can('activity.view')) {
            $since = date('Y-m-d H:i:s', time() - 86400);
            $d['events24'] = (int)DB::val('SELECT COUNT(*) FROM user_activity_events WHERE created_at>=?', [$since]);
            $d['users24'] = (int)DB::val('SELECT COUNT(DISTINCT user_id) FROM user_activity_events WHERE created_at>=? AND user_id IS NOT NULL', [$since]);
            $d['failed24'] = (int)DB::val("SELECT COUNT(*) FROM user_activity_events WHERE created_at>=? AND event_type='login_failed'", [$since]);
            $d['recent'] = DB::all('SELECT * FROM user_activity_events ORDER BY id DESC LIMIT 8');
        }
        if (can('ag.view') && ($me = \App\Core\Ag::myEmployee())) {   // évaluation : mes résultats, mes auto-évaluations à remettre
            \App\Core\Ag::sync();
            $d['ag'] = ['results' => DB::all("SELECT v.id, v.final_score, v.reviewed_at, c.name FROM ag_evals v JOIN ag_campaigns c ON c.id=v.campaign_id WHERE v.employee_id=? AND v.status='reviewed' ORDER BY v.reviewed_at DESC, v.id DESC LIMIT 3", [$me]),
                'todo' => DB::all("SELECT v.id, c.name, c.closes_on FROM ag_evals v JOIN ag_campaigns c ON c.id=v.campaign_id WHERE v.employee_id=? AND v.status='todo' AND c.status='open' ORDER BY c.closes_on", [$me]),
                'obj' => (int)DB::val("SELECT COUNT(*) FROM ag_objectives WHERE employee_id=? AND status='validated' AND period_end>=?", [$me, date('Y-m-d')]),
                'pending' => (int)DB::val("SELECT COUNT(*) FROM ag_objectives WHERE employee_id=? AND status='submitted'", [$me])];
        }
        if (can('ag.team')) { $q = []; $sc = \App\Core\Ag::scope('employee_id', $q); $me2 = \App\Core\Ag::myEmployee();
            $d['agTeam'] = ['validate' => (int)DB::val("SELECT COUNT(*) FROM ag_objectives WHERE status='submitted' AND $sc" . ($me2 ? " AND employee_id<>$me2" : '')),
                'review' => (int)DB::val("SELECT COUNT(*) FROM ag_evals WHERE status='self_done' AND $sc" . ($me2 ? " AND employee_id<>$me2" : ''))]; }
        if (!empty($d['wd']['advisor'])) $d['adv'] = \App\Core\AdvisorDash::load((int)Auth::id(), !empty(Auth::user()['employee_id']) ? (int)Auth::user()['employee_id'] : null);
        $d['notifs'] = DB::all('SELECT * FROM notifications WHERE user_id=? AND read_at IS NULL ORDER BY id DESC LIMIT 5', [Auth::id()]);
        $d['shortcuts'] = array_values(array_filter([
            can('employees.view') ? ['Collaborateurs', '/employees', 'Rechercher un conseiller ou une équipe'] : null,
            can('employees.manage') ? ['Nouveau collaborateur', '/employees/new', 'Créer une fiche en 1 minute'] : null,
            can('imports.run') ? ['Importer un fichier', '/imports', 'Collaborateurs, équipes, stores, listes'] : null,
            can('msg.use') ? ['Messagerie', '/msg', ($n = MsgController::unread()) ? "$n message(s) non lu(s)" : 'Aucun message non lu'] : null,
            can('fo.use') ? ['Forum', '/forum', 'Échanger avec l\'ensemble du personnel'] : null,
            can('activity.view') ? ['Historique d\'activité', '/admin/activity', 'Qui a fait quoi, d\'où et quand'] : null,
        ]));
        $this->view('dashboard/index', $d);
    }
}
