<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Scope, Notifier};
class QaController extends Controller {
    private function myEmp(): int { return (int)(Auth::user()['employee_id'] ?? 0); }
    private function canSee(array $ev): bool { return ($this->myEmp() && (int)$ev['employee_id'] === $this->myEmp() && can('qa.own')) || (can('qa.view') && Scope::allows((int)$ev['employee_id'])); }
    function index(): void {
        [$w, $p] = Scope::sql('v.employee_id'); $w = [$w];
        if ($this->in('employee_id')) { $w[] = 'v.employee_id=?'; $p[] = (int)$this->in('employee_id'); }
        if ($this->in('grid_id')) { $w[] = 'v.grid_id=?'; $p[] = (int)$this->in('grid_id'); }
        if ($this->in('from')) { $w[] = 'v.eval_date>=?'; $p[] = $this->in('from'); }
        if ($this->in('to')) { $w[] = 'v.eval_date<=?'; $p[] = $this->in('to'); }
        if ($this->in('flag') === 'critical') $w[] = 'v.critical_fail=1';
        $cond = implode(' AND ', $w);
        $pg = paginate("qa_evaluations v JOIN employees e ON e.id=v.employee_id JOIN qa_grids g ON g.id=v.grid_id JOIN users u ON u.id=v.evaluator_id WHERE $cond", $p, $this->page(), 25, 'v.*, e.first_name, e.last_name, g.name grid_name, u.name evaluator', 'v.eval_date DESC, v.id DESC');
        $agg = DB::one("SELECT COUNT(*) n, AVG(v.score_pct) avg, SUM(v.critical_fail) crit FROM qa_evaluations v WHERE $cond", $p);
        $this->view('qa/index', ['title' => 'Évaluations qualité', 'p' => $pg, 'agg' => $agg, 'employees' => Scope::employees(), 'grids' => DB::all('SELECT id, name FROM qa_grids ORDER BY name')]);
    }
    // ---------- Fenêtres de modification et de contestation (réglables : qa.edit_hours, qa.dispute_hours ; 72 h par défaut) ----------
    static function editHours(): int { return max(1, (int)setting('qa.edit_hours', 72)); }
    static function disputeHours(): int { return max(1, (int)setting('qa.dispute_hours', 72)); }
    static function secondsLeft(array $ev, int $hours): int { return max(0, strtotime($ev['created_at']) + 3600 * $hours - time()); }
    private function canEdit(array $ev): bool {
        if (self::secondsLeft($ev, self::editHours()) <= 0) return false;
        return can('qa.manage') || (can('qa.evaluate') && (int)$ev['evaluator_id'] === (int)Auth::id() && Scope::allows((int)$ev['employee_id']));
    }
    /** Critères d'une grille avec leurs sous-critères. */
    private function criteria(int $gridId): array {
        $c = DB::all('SELECT * FROM qa_criteria WHERE grid_id=? ORDER BY position', [$gridId]);
        foreach ($c as &$x) {
            $x['subs'] = DB::all('SELECT * FROM qa_subcriteria WHERE criterion_id=? ORDER BY position', [(int)$x['id']]);
            $x['acts'] = DB::all('SELECT id, label FROM qa_corrective_actions WHERE criterion_id=? AND subcriterion_id IS NULL AND active=1 ORDER BY position, id', [(int)$x['id']]);
            foreach ($x['subs'] as &$b) $b['acts'] = DB::all('SELECT id, label FROM qa_corrective_actions WHERE subcriterion_id=? AND active=1 ORDER BY position, id', [(int)$b['id']]); unset($b);
        } unset($x);
        return $c;
    }
    /** Lit et contrôle les notes postées. Un critère avec sous-critères vaut la somme de ses sous-critères ; sinon il porte directement ses points. */
    private function parseScores(array $crit): array {
        $err = []; $pts = []; $subs = []; $sum = 0.0; $max = 0.0; $fail = 0;
        foreach ($crit as $c) {
            if ($c['subs']) {
                $tot = 0.0; $ok = true;
                foreach ($c['subs'] as $s) {
                    $v = $_POST['sub'][$s['id']] ?? ''; if ($v === '' || !is_numeric($v)) { $err['s' . $s['id']] = 'Note manquante : ' . $c['label'] . ' › ' . $s['label']; $ok = false; continue; }
                    $v = (float)$v; if ($v < 0 || $v > (float)$s['max_points']) { $err['s' . $s['id']] = 'Note hors limite (0 à ' . (float)$s['max_points'] . ') : ' . $s['label']; $ok = false; continue; }
                    $subs[$s['id']] = $v; $tot += $v;
                }
                if (!$ok) continue; $v = $tot; $cmax = array_sum(array_map(fn($s) => (float)$s['max_points'], $c['subs']));
            } else {
                $v = $_POST['points'][$c['id']] ?? ''; if ($v === '' || !is_numeric($v)) { $err['c' . $c['id']] = 'Note manquante : ' . $c['label']; continue; }
                $v = (float)$v; $cmax = (float)$c['max_points']; if ($v < 0 || $v > $cmax) { $err['c' . $c['id']] = 'Note hors limite (0 à ' . $cmax . ') : ' . $c['label']; continue; }
            }
            $pts[$c['id']] = $v; $sum += $v; $max += $cmax; if ($c['critical'] && $v == 0) $fail = 1;
        }
        if (!$crit) $err['crit'] = 'Cette grille n\'a aucun critère.';
        return [$err, $pts, $subs, $sum, $max, $fail];
    }
    /**
     * Actions correctives choisies par l'évaluateur (zéro, une ou plusieurs) dans le catalogue du critère ou du sous-critère.
     * Chaque choix devient une action de suivi de l'évaluation, sans doublon ; à la modification, les choix décochés (non réalisés) sont retirés.
     */
    private function correctives(int $evId, array $crit, array $subs, bool $sync = false): int {
        $valid = []; foreach ($crit as $c) { foreach ($c['acts'] as $a) $valid[$a['id']] = [$c['label'], $a['label']]; foreach ($c['subs'] as $b) foreach ($b['acts'] as $a) $valid[$a['id']] = [$c['label'] . ' › ' . $b['label'], $a['label']]; }
        $want = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['corr_a'] ?? [])), fn($i) => isset($valid[$i]))));
        if ($sync) foreach (DB::all('SELECT id, corrective_id FROM qa_actions WHERE evaluation_id=? AND corrective_id IS NOT NULL', [$evId]) as $o) if (!in_array((int)$o['corrective_id'], $want, true)) DB::exec("DELETE FROM qa_actions WHERE id=? AND status<>'done'", [$o['id']]);
        $n = 0;
        foreach ($want as $i) {
            if (DB::val('SELECT 1 FROM qa_actions WHERE evaluation_id=? AND corrective_id=?', [$evId, $i])) continue;
            DB::insert('qa_actions', ['corrective_id' => $i, 'evaluation_id' => $evId, 'action' => mb_substr('Action corrective · ' . $valid[$i][0] . ' : ' . $valid[$i][1], 0, 300), 'due_date' => date('Y-m-d', strtotime('+7 days')), 'status' => 'todo', 'created_by' => Auth::id()]); $n++;
        }
        return $n;
    }
    /** Utilisateur du N+1 (responsable direct) d'un collaborateur, s'il a un compte. */
    static function n1User(int $employeeId): ?int {
        $m = (int)DB::val('SELECT manager_id FROM employees WHERE id=?', [$employeeId]); if (!$m) return null;
        $u = DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [$m]); return $u ? (int)$u : null;
    }
    function create(): void {
        $gid = (int)$this->in('grid_id'); $grids = DB::all('SELECT * FROM qa_grids WHERE active=1 ORDER BY name');
        $grid = $gid ? DB::one('SELECT * FROM qa_grids WHERE id=? AND active=1', [$gid]) : ($grids[0] ?? null);
        $this->view('qa/form', ['title' => 'Nouvelle évaluation', 'grids' => $grids, 'grid' => $grid, 'criteria' => $grid ? $this->criteria((int)$grid['id']) : [], 'ev' => null, 'pre' => ['employee_id' => (int)$this->in('employee_id', 0)],
            'employees' => Scope::employees(), 'channels' => DB::all('SELECT name FROM channels WHERE active=1 ORDER BY name')]);
    }
    function store(): void {
        $grid = DB::one('SELECT * FROM qa_grids WHERE id=? AND active=1', [(int)$this->in('grid_id')]); $emp = (int)$this->in('employee_id');
        [$d, $err] = $this->validate(['eval_date' => ['label' => 'La date', 'req' => true, 'date' => true], 'reference' => ['label' => 'La référence', 'max' => 100], 'channel' => ['label' => 'Le canal', 'max' => 60], 'comment' => ['label' => 'Le commentaire', 'max' => 1500]], $_POST);
        if (!$grid) $err['grid'] = 'Choisissez une grille.';
        if (!Scope::allows($emp) || !DB::val("SELECT 1 FROM employees WHERE id=?", [$emp])) $err['emp'] = 'Choisissez un collaborateur de votre périmètre.';
        $crit = $grid ? $this->criteria((int)$grid['id']) : []; [$e2, $pts, $subs, $sum, $max, $fail] = $this->parseScores($crit); $err += $e2;
        if ($err) $this->back($err, $_POST, 'qa/new?grid_id=' . (int)$this->in('grid_id'));
        $row = ['grid_id' => (int)$grid['id'], 'employee_id' => $emp, 'evaluator_id' => Auth::id(), 'eval_date' => $d['eval_date'], 'channel' => $d['channel'], 'reference' => $d['reference'], 'score_pct' => round($sum / $max * 100, 2), 'critical_fail' => $fail, 'comment' => $d['comment'], 'status' => 'submitted', 'created_at' => now()];
        $id = DB::insert('qa_evaluations', $row);
        foreach ($pts as $cid => $v) DB::insert('qa_scores', ['evaluation_id' => $id, 'criterion_id' => $cid, 'points' => $v, 'comment' => substr(trim((string)($_POST['ccomment'][$cid] ?? '')), 0, 300) ?: null]);
        foreach ($subs as $sid => $v) DB::insert('qa_subscores', ['evaluation_id' => $id, 'subcriterion_id' => $sid, 'points' => $v, 'comment' => substr(trim((string)($_POST['scomment'][$sid] ?? '')), 0, 300) ?: null]);
        $nc = $this->correctives($id, $crit, $subs);
        if ($u = DB::val('SELECT id FROM users WHERE employee_id=? AND status=?', [$emp, 'active'])) Notifier::send((int)$u, 'Nouvelle évaluation qualité', 'Note : ' . $row['score_pct'] . ' %', '/qa/' . $id);
        if ($n1 = self::n1User($emp)) Notifier::send($n1, 'Évaluation qualité d\'un membre de votre équipe', 'Note : ' . $row['score_pct'] . ' %', '/qa/' . $id);
        Audit::log('create', 'qa_evaluation', $id, null, $row); flash('Évaluation enregistrée (' . $row['score_pct'] . ' %).' . ($fail ? ' Un critère éliminatoire est à zéro.' : '') . ($nc ? " $nc action(s) corrective(s) créée(s)." : '')); redirect("qa/$id");
    }
    function edit(string $id): void {
        $ev = DB::one('SELECT v.*, e.first_name, e.last_name, e.matricule, e.qa_ref FROM qa_evaluations v JOIN employees e ON e.id=v.employee_id WHERE v.id=?', [(int)$id]); if (!$ev) { $this->notFound(); return; }
        if (!$this->canEdit($ev)) { flash('Cette note n\'est plus modifiable : délai de ' . self::editHours() . ' h dépassé ou droits insuffisants.', 'danger'); redirect("qa/$id"); }
        $pre = ['points' => [], 'sub' => [], 'corr' => array_map('intval', array_column(DB::all('SELECT corrective_id FROM qa_actions WHERE evaluation_id=? AND corrective_id IS NOT NULL', [(int)$id]), 'corrective_id')), 'dispute' => (int)$this->in('dispute', 0)];
        foreach (DB::all('SELECT * FROM qa_scores WHERE evaluation_id=?', [(int)$id]) as $s) $pre['points'][$s['criterion_id']] = (float)$s['points'];
        foreach (DB::all('SELECT * FROM qa_subscores WHERE evaluation_id=?', [(int)$id]) as $s) $pre['sub'][$s['subcriterion_id']] = (float)$s['points'];
        $this->view('qa/form', ['title' => 'Modifier l\'évaluation', 'grids' => [], 'grid' => DB::one('SELECT * FROM qa_grids WHERE id=?', [(int)$ev['grid_id']]), 'criteria' => $this->criteria((int)$ev['grid_id']), 'ev' => $ev, 'pre' => $pre, 'employees' => [], 'channels' => [],
            'left' => self::secondsLeft($ev, self::editHours()), 'disputes' => DB::all("SELECT id, reason FROM qa_disputes WHERE evaluation_id=? AND status='open'", [(int)$id])]);
    }
    /** Modification dans le délai (72 h par défaut) : motif obligatoire, ancienne et nouvelle note conservées dans l'historique. */
    function update(string $id): void {
        $ev = DB::one('SELECT * FROM qa_evaluations WHERE id=?', [(int)$id]); if (!$ev) { $this->notFound(); return; }
        if (!$this->canEdit($ev)) { flash('Cette note n\'est plus modifiable : délai de ' . self::editHours() . ' h dépassé ou droits insuffisants.', 'danger'); redirect("qa/$id"); }
        $reason = trim((string)$this->in('reason', '')); $err = [];
        if (mb_strlen($reason) < 10) $err['reason'] = 'Documentez la modification (10 caractères minimum).'; if (mb_strlen($reason) > 500) $err['reason'] = 'Motif trop long (500 caractères maximum).';
        $disp = (int)$this->in('dispute_id', 0); if ($disp && !DB::val("SELECT 1 FROM qa_disputes WHERE id=? AND evaluation_id=? AND status='open'", [$disp, (int)$id])) $disp = 0;
        $crit = $this->criteria((int)$ev['grid_id']); [$e2, $pts, $subs, $sum, $max, $fail] = $this->parseScores($crit); $err += $e2;
        $comment = mb_substr(trim((string)$this->in('comment', '')), 0, 1500);
        if ($err) $this->back($err, $_POST, "qa/$id/edit" . ($disp ? "?dispute=$disp" : ''));
        $oldP = array_column(DB::all('SELECT criterion_id, points FROM qa_scores WHERE evaluation_id=?', [(int)$id]), 'points', 'criterion_id'); $oldS = array_column(DB::all('SELECT subcriterion_id, points FROM qa_subscores WHERE evaluation_id=?', [(int)$id]), 'points', 'subcriterion_id');
        $lines = [];
        foreach ($crit as $c) {
            if (isset($pts[$c['id']]) && (float)($oldP[$c['id']] ?? -1) != $pts[$c['id']]) $lines[] = $c['label'] . ' : ' . (float)($oldP[$c['id']] ?? 0) . ' → ' . $pts[$c['id']];
            foreach ($c['subs'] as $s) if (isset($subs[$s['id']]) && (float)($oldS[$s['id']] ?? -1) != $subs[$s['id']]) $lines[] = '   ' . $c['label'] . ' › ' . $s['label'] . ' : ' . (float)($oldS[$s['id']] ?? 0) . ' → ' . $subs[$s['id']];
        }
        $new = round($sum / $max * 100, 2);
        DB::exec('DELETE FROM qa_scores WHERE evaluation_id=?', [(int)$id]); DB::exec('DELETE FROM qa_subscores WHERE evaluation_id=?', [(int)$id]);
        foreach ($pts as $cid => $v) DB::insert('qa_scores', ['evaluation_id' => (int)$id, 'criterion_id' => $cid, 'points' => $v, 'comment' => substr(trim((string)($_POST['ccomment'][$cid] ?? '')), 0, 300) ?: null]);
        foreach ($subs as $sid => $v) DB::insert('qa_subscores', ['evaluation_id' => (int)$id, 'subcriterion_id' => $sid, 'points' => $v, 'comment' => substr(trim((string)($_POST['scomment'][$sid] ?? '')), 0, 300) ?: null]);
        DB::update('qa_evaluations', ['score_pct' => $new, 'critical_fail' => $fail, 'comment' => $comment ?: null], 'id=?', [(int)$id]);
        if ($comment !== (string)$ev['comment']) $lines[] = 'Commentaire général modifié';
        $rev = DB::insert('qa_revisions', ['evaluation_id' => (int)$id, 'revised_by' => Auth::id(), 'kind' => $disp ? 'dispute' : 'error', 'dispute_id' => $disp ?: null, 'reason' => $reason, 'old_score' => $ev['score_pct'], 'new_score' => $new, 'old_critical' => $ev['critical_fail'], 'new_critical' => $fail, 'detail' => implode("\n", $lines), 'created_at' => now()]);
        $this->correctives((int)$id, $crit, $subs, true);
        if ($disp) DB::update('qa_disputes', ['status' => 'accepted', 'answered_by' => Auth::id(), 'answered_at' => now(), 'answer' => mb_substr('Note corrigée : ' . $reason, 0, 1500), 'revision_id' => $rev], 'id=?', [$disp]);
        $msg = 'Note qualité modifiée : ' . (float)$ev['score_pct'] . ' % → ' . $new . ' %'; $recip = array_filter([DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [(int)$ev['employee_id']]), self::n1User((int)$ev['employee_id'])]);
        foreach ($recip as $u) Notifier::send((int)$u, 'Évaluation qualité modifiée', $msg . ' — ' . $reason, '/qa/' . $id);
        Audit::log('revise', 'qa_evaluation', $id, ['score_pct' => $ev['score_pct'], 'critical_fail' => $ev['critical_fail']], ['score_pct' => $new, 'critical_fail' => $fail, 'reason' => $reason, 'dispute' => $disp ?: null]);
        flash($msg . '. La modification est historisée.'); redirect("qa/$id");
    }
    function show(string $id): void {
        $ev = DB::one('SELECT v.*, e.first_name, e.last_name, e.matricule, e.qa_ref, e.qa_ref_type, g.name grid_name, u.name evaluator FROM qa_evaluations v JOIN employees e ON e.id=v.employee_id JOIN qa_grids g ON g.id=v.grid_id JOIN users u ON u.id=v.evaluator_id WHERE v.id=?', [(int)$id]);
        if (!$ev) { $this->notFound(); return; } if (!$this->canSee($ev)) { $this->forbidden(); return; }
        $own = $this->myEmp() === (int)$ev['employee_id'];
        $scores = DB::all('SELECT s.*, c.label, c.max_points, c.critical FROM qa_scores s JOIN qa_criteria c ON c.id=s.criterion_id WHERE s.evaluation_id=? ORDER BY c.position', [(int)$id]);
        $subs = []; foreach (DB::all('SELECT x.*, sc.label, sc.max_points, sc.criterion_id, sc.corrective FROM qa_subscores x JOIN qa_subcriteria sc ON sc.id=x.subcriterion_id WHERE x.evaluation_id=? ORDER BY sc.position', [(int)$id]) as $x) $subs[$x['criterion_id']][] = $x;
        $disputes = DB::all('SELECT d.*, u.name raised_name, a.name answered_name FROM qa_disputes d LEFT JOIN users u ON u.id=d.raised_by LEFT JOIN users a ON a.id=d.answered_by WHERE d.evaluation_id=? ORDER BY d.id', [(int)$id]);
        $open = array_filter($disputes, fn($d) => $d['status'] === 'open');
        $this->view('qa/show', ['title' => 'Évaluation du ' . d($ev['eval_date']), 'ev' => $ev, 'own' => $own, 'scores' => $scores, 'subs' => $subs, 'disputes' => $disputes,
            'revisions' => DB::all('SELECT r.*, u.name by_name FROM qa_revisions r LEFT JOIN users u ON u.id=r.revised_by WHERE r.evaluation_id=? ORDER BY r.id', [(int)$id]),
            'canEdit' => $this->canEdit($ev), 'editLeft' => self::secondsLeft($ev, self::editHours()), 'editHours' => self::editHours(),
            'canDispute' => $own && can('qa.own') && !$open && self::secondsLeft($ev, self::disputeHours()) > 0, 'disputeLeft' => self::secondsLeft($ev, self::disputeHours()), 'canAnswer' => can('qa.manage'),
            'actions' => DB::all('SELECT * FROM qa_actions WHERE evaluation_id=? ORDER BY id', [(int)$id])]);
    }
    function acknowledge(string $id): void {
        $ev = DB::one('SELECT * FROM qa_evaluations WHERE id=?', [(int)$id]);
        if (!$ev || !$this->myEmp() || (int)$ev['employee_id'] !== $this->myEmp()) { $this->notFound(); return; }
        if (!$ev['acknowledged_at']) { DB::update('qa_evaluations', ['acknowledged_at' => now(), 'status' => 'acknowledged'], 'id=?', [(int)$id]); Audit::log('acknowledge', 'qa_evaluation', $id); Notifier::send((int)$ev['evaluator_id'], 'Évaluation prise en compte', 'Le collaborateur a pris connaissance de l\'évaluation du ' . d($ev['eval_date']), '/qa/' . $id); }
        flash('Vous avez pris connaissance de cette évaluation.'); redirect("qa/$id");
    }
    function storeAction(string $id): void {
        $ev = DB::one('SELECT * FROM qa_evaluations WHERE id=?', [(int)$id]); if (!$ev) { $this->notFound(); return; } if (!Scope::allows((int)$ev['employee_id'])) { $this->forbidden(); return; }
        [$d, $err] = $this->validate(['action' => ['label' => 'L\'action', 'req' => true, 'max' => 300], 'due_date' => ['label' => 'L\'échéance', 'date' => true]], $_POST);
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("qa/$id"); }
        $d += ['evaluation_id' => (int)$id, 'status' => 'todo', 'created_by' => Auth::id()]; $aid = DB::insert('qa_actions', $d); Audit::log('create', 'qa_action', $aid, null, $d); flash('Action de coaching ajoutée.'); redirect("qa/$id");
    }
    function doneAction(string $aid): void {
        $a = DB::one('SELECT a.*, v.employee_id FROM qa_actions a JOIN qa_evaluations v ON v.id=a.evaluation_id WHERE a.id=?', [(int)$aid]); if (!$a) { $this->notFound(); return; }
        $ok = (can('qa.evaluate') && Scope::allows((int)$a['employee_id'])) || ($this->myEmp() && (int)$a['employee_id'] === $this->myEmp());
        if (!$ok) { $this->forbidden(); return; }
        $undo = $a['status'] === 'done'; DB::update('qa_actions', $undo ? ['status' => 'todo', 'done_at' => null] : ['status' => 'done', 'done_at' => now()], 'id=?', [(int)$aid]); Audit::log($undo ? 'reopen' : 'done', 'qa_action', $aid);
        redirect('qa/' . $a['evaluation_id']);
    }
    function mine(): void {
        $e = $this->myEmp();
        $rows = $e ? DB::all('SELECT v.*, g.name grid_name FROM qa_evaluations v JOIN qa_grids g ON g.id=v.grid_id WHERE v.employee_id=? ORDER BY v.eval_date DESC', [$e]) : [];
        $this->view('qa/mine', ['title' => 'Mes évaluations', 'rows' => $rows, 'linked' => (bool)$e, 'todo' => $e ? DB::all("SELECT a.*, v.id ev FROM qa_actions a JOIN qa_evaluations v ON v.id=a.evaluation_id WHERE v.employee_id=? AND a.status='todo' ORDER BY a.due_date", [$e]) : []]);
    }
    function stats(): void {
        [$w, $p] = Scope::sql('v.employee_id');
        $months = DB::all("SELECT SUBSTR(v.eval_date,1,7) m, COUNT(*) n, AVG(v.score_pct) avg, SUM(v.critical_fail) crit FROM qa_evaluations v WHERE v.eval_date>=? AND $w GROUP BY SUBSTR(v.eval_date,1,7) ORDER BY m", array_merge([date('Y-m-01', strtotime('-5 months'))], $p));
        $teams = DB::all("SELECT COALESCE(t.name,'Sans équipe') name, COUNT(*) n, AVG(v.score_pct) avg FROM qa_evaluations v JOIN employees e ON e.id=v.employee_id LEFT JOIN teams t ON t.id=e.team_id WHERE v.eval_date>=? AND $w GROUP BY COALESCE(t.name,'Sans équipe') ORDER BY avg", array_merge([date('Y-m-d', strtotime('-90 days'))], $p));
        $agents = DB::all("SELECT e.id, e.first_name, e.last_name, COUNT(*) n, AVG(v.score_pct) avg FROM qa_evaluations v JOIN employees e ON e.id=v.employee_id WHERE v.eval_date>=? AND $w GROUP BY e.id, e.first_name, e.last_name HAVING COUNT(*)>=2 ORDER BY avg LIMIT 10", array_merge([date('Y-m-d', strtotime('-90 days'))], $p));
        $crit = DB::all("SELECT c.label, AVG(s.points*100.0/c.max_points) pct, COUNT(*) n FROM qa_scores s JOIN qa_criteria c ON c.id=s.criterion_id JOIN qa_evaluations v ON v.id=s.evaluation_id WHERE v.eval_date>=? AND $w GROUP BY c.id, c.label ORDER BY pct LIMIT 8", array_merge([date('Y-m-d', strtotime('-90 days'))], $p));
        $this->view('qa/stats', ['title' => 'Tableau qualité', 'months' => $months, 'teams' => $teams, 'agents' => $agents, 'crit' => $crit]);
    }
    function grids(): void {
        $g = DB::all('SELECT g.*, (SELECT COUNT(*) FROM qa_evaluations v WHERE v.grid_id=g.id) used FROM qa_grids g ORDER BY g.active DESC, g.name');
        foreach ($g as &$x) { $x['criteria'] = DB::all('SELECT c.*, (SELECT COUNT(*) FROM qa_scores s WHERE s.criterion_id=c.id) used FROM qa_criteria c WHERE c.grid_id=? ORDER BY c.position', [$x['id']]);
            foreach ($x['criteria'] as &$c) {
                $c['subs'] = DB::all('SELECT b.*, (SELECT COUNT(*) FROM qa_subscores z WHERE z.subcriterion_id=b.id) used FROM qa_subcriteria b WHERE b.criterion_id=? ORDER BY b.position', [$c['id']]);
                $q = 'SELECT a.*, (SELECT COUNT(*) FROM qa_actions x WHERE x.corrective_id=a.id) used FROM qa_corrective_actions a WHERE ';
                $c['acts'] = DB::all($q . 'a.criterion_id=? AND a.subcriterion_id IS NULL ORDER BY a.position, a.id', [$c['id']]);
                foreach ($c['subs'] as &$b) $b['acts'] = DB::all($q . 'a.subcriterion_id=? ORDER BY a.position, a.id', [$b['id']]); unset($b);
            } unset($c); } unset($x);
        $this->view('qa/grids', ['title' => 'Grilles d\'évaluation', 'grids' => $g]);
    }
    function storeGrid(): void {
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'description' => ['label' => 'La description', 'max' => 500]], $_POST);
        if ($err) { $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect('qa/grids'); } $d['active'] = 1; $id = DB::insert('qa_grids', $d); Audit::log('create', 'qa_grid', $id, null, $d); redirect('qa/grids');
    }
    function updateGrid(string $id): void {
        $o = DB::one('SELECT * FROM qa_grids WHERE id=?', [(int)$id]); if (!$o) { $this->notFound(); return; }
        $n = ['name' => trim((string)$this->in('name', $o['name'])) ?: $o['name'], 'description' => trim((string)$this->in('description', '')) ?: null, 'active' => isset($_POST['active']) ? 1 : 0];
        DB::update('qa_grids', $n, 'id=?', [(int)$id]); Audit::log('update', 'qa_grid', $id, $o, $n); flash('Grille enregistrée.'); redirect('qa/grids');
    }
    function storeCriterion(string $id): void {
        $label = trim((string)$this->in('label', '')); $pts = (float)$this->in('max_points', 0);
        if (!DB::val('SELECT 1 FROM qa_grids WHERE id=?', [(int)$id]) || $label === '' || $pts <= 0) { flash('Renseignez un intitulé et des points supérieurs à 0.', 'danger'); redirect('qa/grids'); }
        $row = ['grid_id' => (int)$id, 'position' => (int)DB::val('SELECT COALESCE(MAX(position),0)+1 FROM qa_criteria WHERE grid_id=?', [(int)$id]), 'label' => mb_substr($label, 0, 190), 'max_points' => $pts, 'critical' => isset($_POST['critical']) ? 1 : 0];
        $cid = DB::insert('qa_criteria', $row); Audit::log('create', 'qa_criterion', $cid, null, $row); redirect('qa/grids');
    }
    function deleteCriterion(string $id, string $cid): void {
        $c = DB::one('SELECT * FROM qa_criteria WHERE id=? AND grid_id=?', [(int)$cid, (int)$id]); if (!$c) { $this->notFound(); return; }
        if (DB::val('SELECT 1 FROM qa_scores WHERE criterion_id=?', [(int)$cid])) { flash('Ce critère a déjà été noté : il ne peut pas être supprimé (désactivez la grille et créez-en une nouvelle).', 'warning'); redirect('qa/grids'); }
        DB::exec('DELETE FROM qa_criteria WHERE id=?', [(int)$cid]); Audit::log('delete', 'qa_criterion', $cid, $c); redirect('qa/grids');
    }

    /** Le critère porte la somme de ses sous-critères dès qu'il en a. */
    private function syncCriterion(int $cid): void {
        $t = DB::val('SELECT COALESCE(SUM(max_points),0) FROM qa_subcriteria WHERE criterion_id=?', [$cid]);
        if ((float)$t > 0) DB::update('qa_criteria', ['max_points' => $t], 'id=?', [$cid]);
    }
    function storeSub(string $id, string $cid): void {
        $c = DB::one('SELECT * FROM qa_criteria WHERE id=? AND grid_id=?', [(int)$cid, (int)$id]); if (!$c) { $this->notFound(); return; }
        $label = trim((string)$this->in('label', '')); $pts = (float)$this->in('max_points', 0); $corr = mb_substr(trim((string)$this->in('corrective', '')), 0, 300);
        if ($label === '' || $pts <= 0) { flash('Renseignez un intitulé et des points supérieurs à 0.', 'danger'); redirect('qa/grids'); }
        if (!DB::val('SELECT 1 FROM qa_subcriteria WHERE criterion_id=?', [(int)$cid]) && DB::val('SELECT 1 FROM qa_scores WHERE criterion_id=?', [(int)$cid])) { flash('Ce critère a déjà été noté directement : créez une nouvelle grille pour utiliser des sous-critères.', 'warning'); redirect('qa/grids'); }
        $row = ['criterion_id' => (int)$cid, 'position' => (int)DB::val('SELECT COALESCE(MAX(position),0)+1 FROM qa_subcriteria WHERE criterion_id=?', [(int)$cid]), 'label' => mb_substr($label, 0, 190), 'max_points' => $pts, 'corrective' => null];
        $sid = DB::insert('qa_subcriteria', $row); $this->syncCriterion((int)$cid); Audit::log('create', 'qa_subcriterion', $sid, null, $row); flash('Sous-critère ajouté.'); redirect('qa/grids');
    }
    function updateSub(string $id, string $cid, string $sid): void {
        $o = DB::one('SELECT b.* FROM qa_subcriteria b JOIN qa_criteria c ON c.id=b.criterion_id WHERE b.id=? AND c.id=? AND c.grid_id=?', [(int)$sid, (int)$cid, (int)$id]); if (!$o) { $this->notFound(); return; }
        $used = (bool)DB::val('SELECT 1 FROM qa_subscores WHERE subcriterion_id=?', [(int)$sid]);
        $n = ['label' => mb_substr(trim((string)$this->in('label', $o['label'])) ?: $o['label'], 0, 190)];
        $pts = (float)$this->in('max_points', $o['max_points']);
        if ($pts > 0 && $pts != (float)$o['max_points']) { if ($used) flash('Les points ne sont plus modifiables : ce sous-critère a déjà été noté. Intitulé enregistré.', 'warning'); else $n['max_points'] = $pts; }
        DB::update('qa_subcriteria', $n, 'id=?', [(int)$sid]); $this->syncCriterion((int)$cid); Audit::log('update', 'qa_subcriterion', $sid, $o, $n); redirect('qa/grids');
    }
    function deleteSub(string $id, string $cid, string $sid): void {
        $o = DB::one('SELECT b.* FROM qa_subcriteria b JOIN qa_criteria c ON c.id=b.criterion_id WHERE b.id=? AND c.id=? AND c.grid_id=?', [(int)$sid, (int)$cid, (int)$id]); if (!$o) { $this->notFound(); return; }
        if (DB::val('SELECT 1 FROM qa_subscores WHERE subcriterion_id=?', [(int)$sid])) { flash('Ce sous-critère a déjà été noté : suppression impossible.', 'warning'); redirect('qa/grids'); }
        DB::exec('DELETE FROM qa_subcriteria WHERE id=?', [(int)$sid]); $this->syncCriterion((int)$cid); Audit::log('delete', 'qa_subcriterion', $sid, $o); redirect('qa/grids');
    }

    // ---- Catalogue d'actions correctives (coach qualité, responsable qualité, administrateur) ----
    function storeCorrective(string $id): void {
        $c = DB::one('SELECT * FROM qa_criteria WHERE id=? AND grid_id=?', [(int)$this->in('criterion_id', 0), (int)$id]); if (!$c) { $this->notFound(); return; }
        $sid = (int)$this->in('subcriterion_id', 0); if ($sid && !DB::val('SELECT 1 FROM qa_subcriteria WHERE id=? AND criterion_id=?', [$sid, $c['id']])) { $this->notFound(); return; }
        $label = mb_substr(trim((string)$this->in('label', '')), 0, 300);
        if ($label === '') { flash('Saisissez l\'action corrective.', 'danger'); redirect('qa/grids'); }
        if (DB::val('SELECT 1 FROM qa_corrective_actions WHERE criterion_id=? AND ' . ($sid ? 'subcriterion_id=' . $sid : 'subcriterion_id IS NULL') . ' AND label=?', [$c['id'], $label])) { flash('Cette action existe déjà pour ce critère.', 'warning'); redirect('qa/grids'); }
        $row = ['criterion_id' => (int)$c['id'], 'subcriterion_id' => $sid ?: null, 'label' => $label, 'active' => 1, 'position' => (int)DB::val('SELECT COALESCE(MAX(position),0)+1 FROM qa_corrective_actions WHERE criterion_id=? AND ' . ($sid ? 'subcriterion_id=' . $sid : 'subcriterion_id IS NULL'), [$c['id']]), 'created_by' => Auth::id(), 'created_at' => now()];
        $aid = DB::insert('qa_corrective_actions', $row); Audit::log('create', 'qa_corrective', $aid, null, $row); flash('Action corrective ajoutée.'); redirect('qa/grids');
    }
    function updateCorrective(string $aid): void {
        $o = DB::one('SELECT * FROM qa_corrective_actions WHERE id=?', [(int)$aid]); if (!$o) { $this->notFound(); return; }
        $label = mb_substr(trim((string)$this->in('label', $o['label'])), 0, 300) ?: $o['label'];
        $n = ['label' => $label, 'active' => $this->in('active') === '1' ? 1 : 0];
        DB::update('qa_corrective_actions', $n, 'id=?', [(int)$aid]); Audit::log('update', 'qa_corrective', $aid, $o, $n); flash('Action corrective mise à jour.'); redirect('qa/grids');
    }
    function deleteCorrective(string $aid): void {
        $o = DB::one('SELECT * FROM qa_corrective_actions WHERE id=?', [(int)$aid]); if (!$o) { $this->notFound(); return; }
        DB::exec('UPDATE qa_actions SET corrective_id=NULL WHERE corrective_id=?', [(int)$aid]); DB::exec('DELETE FROM qa_corrective_actions WHERE id=?', [(int)$aid]);
        Audit::log('delete', 'qa_corrective', $aid, $o, null); flash('Action corrective retirée du catalogue (les évaluations passées la conservent).'); redirect('qa/grids');
    }
}
