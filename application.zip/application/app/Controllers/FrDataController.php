<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Fr, FrStats, FrImport, FrReport, Settings, Xlsx};

/** Lot 60 — Franchises : contrôle des fichiers sources (SND), états mensuels, import, anomalies, paramètres. */
class FrDataController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    private static function dir(): string { $d = ROOT . '/storage/uploads/fr'; if (!is_dir($d)) @mkdir($d, 0775, true); return $d; }

    // ───────────────────────── Contrôle des fichiers sources et règles d'inclusion ─────────────────────────
    function snd(): void {
        if (!can('fr.snd') && !can('fr.manage')) { $this->forbidden(); return; } $cov = FrStats::coverage('rest'); $end = $cov['to'] ?? date('Y-m-d'); $from = Fr::isDay($_GET['from'] ?? null) ? $_GET['from'] : ($cov['from'] ?? $end); $to = Fr::isDay($_GET['to'] ?? null) ? $_GET['to'] : $end; if ($from > $to) [$from, $to] = [$to, $from];
        $rec = (int)DB::val("SELECT COUNT(*) FROM fr_src WHERE day>=? AND day<=?", [$from, $to]) ? FrImport::reconcile($from, $to, false) : null;
        $this->view('fr/snd', ['title' => 'Contrôle SND', 'from' => $from, 'to' => $to, 'rec' => $rec, 'rules' => DB::all('SELECT * FROM fr_rules ORDER BY position'), 'cov' => $cov, 'batches' => DB::all("SELECT * FROM fr_batches WHERE kind='reprise' ORDER BY id DESC LIMIT 10"), 'cats' => FrImport::CATS, 'blockers' => FrImport::blockers('reprise'), 'rejects' => (int)DB::val("SELECT COUNT(*) FROM fr_rejects WHERE status='open'")]);
    }
    function ruleValidate(string $id): void {
        if (!can('fr.validate')) { $this->forbidden(); return; } $r = DB::one('SELECT * FROM fr_rules WHERE id=?', [$id]); if (!$r) { $this->notFound(); return; } $by = trim((string)$this->in('by', '')) ?: ((\App\Core\Auth::user()['name'] ?? '') ?: 'validateur');
        DB::update('fr_rules', ['validated_by' => $by, 'validated_at' => now()], 'id=?', [$id]); Audit::log('fr.rule.validate', 'fr_rules', $id, null, ['règle' => $r['code']]); $this->go('fr/snd', 'Règle validée.');
    }
    function ruleReset(string $id): void { if (!can('fr.validate')) { $this->forbidden(); return; } DB::update('fr_rules', ['validated_by' => null, 'validated_at' => null], 'id=?', [$id]); Audit::log('fr.rule.reset', 'fr_rules', $id); $this->go('fr/snd', 'Validation retirée : les états en brouillon ne pourront plus être validés.'); }

    // ───────────────────────── États mensuels ─────────────────────────
    function reports(): void {
        if (!can('fr.report') && !can('fr.snd')) { $this->forbidden(); return; }
        $this->view('fr/reports', ['title' => 'États SND', 'list' => DB::all('SELECT id, period, version, status, basis, ref_period, total, generated_at, validated_at, is_demo FROM fr_reports ORDER BY period DESC, version DESC'), 'cov' => FrStats::coverage('rest'), 'covOps' => FrStats::coverage('ops')]);
    }
    function generate(): void {
        if (!can('fr.report')) { $this->forbidden(); return; } $ym = (string)$this->in('period', ''); $basis = in_array($this->in('basis'), ['reprise', 'crm'], true) ? (string)$this->in('basis') : 'reprise'; $ref = (string)$this->in('ref', ''); $why = trim((string)$this->in('why', ''));
        if (!FrReport::ymOk($ym)) $this->go('fr/reports', 'Période invalide (format AAAA-MM).', 'danger'); if ($ref !== '' && !FrReport::ymOk($ref)) $this->go('fr/reports', 'Période de référence invalide.', 'danger'); if ($ref === $ym) $this->go('fr/reports', 'La période de référence doit différer de la période étudiée.', 'danger');
        if (DB::val('SELECT 1 FROM fr_reports WHERE period=?', [$ym]) && $why === '') $this->go('fr/reports', 'Cette période a déjà un état : indiquez le motif de la nouvelle version.', 'danger');
        $id = FrReport::generate($ym, $basis, $ref ?: null, $why); Audit::log('fr.report.generate', 'fr_reports', $id, null, ['période' => $ym, 'base' => $basis]); $this->go("fr/reports/$id", 'État généré (brouillon).');
    }
    function report(string $id): void {
        if (!can('fr.report') && !can('fr.snd')) { $this->forbidden(); return; } $r = DB::one('SELECT * FROM fr_reports WHERE id=?', [$id]); if (!$r) { $this->notFound(); return; }
        $this->view('fr/report', ['title' => 'État SND ' . FrReport::label($r['period']) . ' v' . $r['version'], 'r' => $r, 'd' => json_decode((string)$r['data'], true) ?: [], 'log' => DB::all('SELECT l.*, u.name uname FROM fr_report_log l LEFT JOIN users u ON u.id=l.user_id WHERE l.report_id=? ORDER BY l.id', [$id]), 'blockers' => $r['status'] === 'draft' ? FrImport::blockers($r['basis']) : []]);
    }
    function reportValidate(string $id): void {
        if (!can('fr.validate')) { $this->forbidden(); return; } $err = FrReport::validate((int)$id, (string)$this->in('justification', '')); $this->go("fr/reports/$id", $err ?? 'État validé pour la SND.', $err ? 'danger' : 'success');
    }
    function reportXlsx(string $id): void { $this->reportFile($id, 'xlsx'); }
    function reportPdf(string $id): void { $this->reportFile($id, 'pdf'); }
    private function reportFile(string $id, string $kind): void {
        if (!can('fr.report') && !can('fr.snd')) { $this->forbidden(); return; } $r = DB::one('SELECT * FROM fr_reports WHERE id=?', [$id]); if (!$r) { $this->notFound(); return; } $nm = 'etat_snd_' . $r['period'] . '_v' . $r['version'];
        Audit::log('fr.export', 'fr_reports', $id, null, ['format' => $kind]); FrReport::log((int)$id, 'export', strtoupper($kind));
        if ($kind === 'pdf') { header('Content-Type: application/pdf'); header('Content-Disposition: attachment; filename="' . $nm . '.pdf"'); echo FrReport::pdf($r); exit; }
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); header('Content-Disposition: attachment; filename="' . $nm . '.xlsx"'); echo FrReport::xlsx($r); exit;
    }

    // ───────────────────────── Import ─────────────────────────
    function import(): void {
        if (!can('fr.import')) { $this->forbidden(); return; }
        $this->view('fr/import', ['title' => 'Importer', 'batches' => DB::all('SELECT * FROM fr_batches ORDER BY id DESC LIMIT 15'), 'res' => $_SESSION['_fr_prev'] ?? null, 'rejects' => DB::all("SELECT x.*, b.name batch FROM fr_rejects x JOIN fr_batches b ON b.id=x.batch_id WHERE x.status='open' ORDER BY x.id DESC LIMIT 60"), 'nrej' => (int)DB::val("SELECT COUNT(*) FROM fr_rejects WHERE status='open'"), 'franchises' => array_column(Fr::franchiseList(true), 'name', 'id')]);
    }
    function preview(): void {
        if (!can('fr.import')) { $this->forbidden(); return; } $kind = $this->in('kind') === 'dossiers' ? 'dossiers' : 'reprise'; $f = $_FILES['file'] ?? null;
        if (!$f || $f['error'] !== UPLOAD_ERR_OK || $f['size'] > 30 * 1048576 || !preg_match('/\.(xlsx|csv)$/i', (string)$f['name'])) $this->go('fr/import', 'Choisissez un fichier .xlsx ou .csv de 30 Mo au plus.', 'danger');
        $tok = bin2hex(random_bytes(12)); $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION)); $path = self::dir() . "/$tok.$ext"; if (!move_uploaded_file($f['tmp_name'], $path)) $this->go('fr/import', 'Fichier non enregistré.', 'danger');
        [$sheets, $err] = FrImport::read($path, $f['name']); if ($err || !$sheets) { @unlink($path); $this->go('fr/import', $err ?: 'Fichier illisible ou vide.', 'danger'); }
        Fr::$system = true; try { [$st, $iss] = $kind === 'dossiers' ? FrImport::dossiers($sheets, false, $f['name']) : FrImport::reprise($sheets, false, $f['name']); } finally { Fr::$system = false; }
        $_SESSION['_fr_prev'] = ['tok' => $tok, 'ext' => $ext, 'name' => $f['name'], 'kind' => $kind, 'st' => $st, 'iss' => array_slice($iss, 0, 40), 'niss' => count($iss)]; $this->go('fr/import');
    }
    function commit(): void {
        if (!can('fr.import')) { $this->forbidden(); return; } $p = $_SESSION['_fr_prev'] ?? null; if (!$p || !preg_match('/^[a-f0-9]{24}$/', $p['tok']) || !in_array($p['ext'], ['xlsx', 'csv'], true)) $this->go('fr/import', 'Aucun aperçu à confirmer.', 'danger');
        $path = self::dir() . '/' . $p['tok'] . '.' . $p['ext']; if (!is_file($path)) $this->go('fr/import', 'Le fichier d\'aperçu a expiré : rechargez-le.', 'danger'); [$sheets, $err] = FrImport::read($path, $p['name']); if ($err) $this->go('fr/import', $err, 'danger');
        Fr::$system = true; try { [$st] = $p['kind'] === 'dossiers' ? FrImport::dossiers($sheets, true, $p['name']) : FrImport::reprise($sheets, true, $p['name']); } finally { Fr::$system = false; } @unlink($path); unset($_SESSION['_fr_prev']);
        Audit::log('fr.import', 'fr_batches', $st['batch_id'] ?? 0, null, ['fichier' => $p['name'], 'lues' => $st['read'], 'ok' => $st['ok'], 'doublons' => $st['dup'], 'rejets' => $st['reject']]);
        $this->go('fr/import', 'Import terminé : ' . Fr::n($st['ok']) . ' nouvelle(s) ligne(s), ' . Fr::n($st['dup']) . ' déjà connue(s), ' . Fr::n($st['reject']) . ' rejet(s).');
    }
    function cancel(): void { $p = $_SESSION['_fr_prev'] ?? null; if ($p && preg_match('/^[a-f0-9]{24}$/', $p['tok'])) @unlink(self::dir() . '/' . $p['tok'] . '.' . $p['ext']); unset($_SESSION['_fr_prev']); $this->go('fr/import', 'Aperçu abandonné.'); }
    function template(): void {
        if (!can('fr.import')) { $this->forbidden(); return; } $kind = $this->in('kind') === 'dossiers' ? 'dossiers' : 'reprise';
        $sheets = $kind === 'dossiers' ? ['Dossiers' => ['rows' => [['Date', 'Franchise', 'Service', 'Typologie', 'Statut', 'Numéro client', 'ICCID', 'Agent', 'Motif', 'Référence opération'], ['2026-11-02', 'Nom ou code de la franchise', 'Service', 'Typologie', 'Exécuté', '', '', '', '', '']], 'widths' => [12, 30, 18, 18, 14, 16, 24, 16, 24, 22]]]
            : ['BOSS' => ['rows' => [['Date', 'Franchise', 'Service', 'Statut', 'ICCID', 'Client', 'Agent']], 'widths' => [12, 30, 22, 16, 24, 16, 20]], 'TRAITEMENT' => ['rows' => [['Date', 'Franchise', 'Service', 'Statut', 'ICCID', 'Client', 'Agent']], 'widths' => [12, 30, 22, 16, 24, 16, 20]], 'Restitution' => ['rows' => [['Date', 'Franchise', 'Service']], 'widths' => [12, 30, 22]]];
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); header('Content-Disposition: attachment; filename="modele_import_franchises_' . $kind . '.xlsx"'); echo Xlsx::write($sheets); exit;
    }
    function rejectFix(string $id): void { if (!can('fr.import')) { $this->forbidden(); return; } $err = FrImport::fix((int)$id, (int)$this->in('franchise_id', 0), !empty($_POST['alias'])); $this->go('fr/import', $err ?? 'Anomalie corrigée.', $err ? 'danger' : 'success'); }
    function rejectIgnore(string $id): void {
        if (!can('fr.import')) { $this->forbidden(); return; } $why = trim((string)$this->in('why', '')); if ($why === '') $this->go('fr/import', 'Indiquez pourquoi cette anomalie est ignorée.', 'danger');
        DB::update('fr_rejects', ['status' => 'ignored', 'correction' => mb_substr($why, 0, 300), 'resolved_by' => \App\Core\Auth::id(), 'resolved_at' => now()], 'id=? AND status=?', [$id, 'open']); Audit::log('fr.reject.ignore', 'fr_rejects', $id, null, ['motif' => $why]); $this->go('fr/import', 'Anomalie ignorée (motif journalisé).');
    }

    // ───────────────────────── Paramètres ─────────────────────────
    const TABS = ['general' => 'Général et calendrier', 'catalog' => 'Catalogue et SLA', 'reasons' => 'Motifs', 'opdict' => 'Dictionnaire des opérations', 'targets' => 'Cibles et seuils', 'status' => 'Correspondance des statuts', 'access' => 'Accès par périmètre'];
    function settings(): void {
        if (!can('fr.manage')) { $this->forbidden(); return; } $tab = isset(self::TABS[$_GET['tab'] ?? '']) ? $_GET['tab'] : 'general';
        $d = ['title' => 'Paramètres Franchises', 'tab' => $tab, 'tabs' => self::TABS, 'users' => DB::all("SELECT id, name FROM users WHERE status='active' ORDER BY name")];
        $d += match ($tab) { 'catalog' => ['rows' => DB::all('SELECT * FROM fr_catalog ORDER BY service, typology, subtype')], 'reasons' => ['rows' => DB::all('SELECT * FROM fr_reasons ORDER BY kind, label')], 'opdict' => ['rows' => DB::all('SELECT * FROM fr_opdict ORDER BY label')], 'targets' => ['rows' => DB::all('SELECT * FROM fr_targets ORDER BY measure, id'), 'fr' => array_column(Fr::franchiseList(), 'name', 'id')],
            'status' => ['rows' => DB::all('SELECT m.*, r.label reason FROM fr_status_map m LEFT JOIN fr_reasons r ON r.id=m.reason_id ORDER BY m.raw')], 'access' => ['rows' => DB::all('SELECT a.*, u.name uname, f.name fname FROM fr_access a JOIN users u ON u.id=a.user_id LEFT JOIN fr_franchises f ON f.id=a.franchise_id ORDER BY u.name'), 'zones' => Fr::zones(), 'fr' => array_column(Fr::franchiseList(), 'name', 'id')],
            'general' => ['cal' => DB::all('SELECT * FROM fr_calendar ORDER BY day DESC LIMIT 60'), 's' => array_combine($k = ['fr.workdays', 'fr.day_start', 'fr.day_end', 'fr.calendar_validated', 'fr.weak_base', 'fr.sla_reopen', 'fr.sla_pause', 'fr.prio_factor', 'fr.aging', 'fr.alerts_on', 'fr.tolerance'], array_map(fn($x) => Fr::setting($x, ''), $k))], default => [] };
        $this->view('fr/settings', $d);
    }
    function settingsSave(string $tab): void {
        if (!can('fr.manage')) { $this->forbidden(); return; } if (!isset(self::TABS[$tab])) { $this->notFound(); return; } $back = 'fr/settings?tab=' . $tab; $op = (string)$this->in('op', 'save'); $msg = 'Enregistré.'; $in = fn($k, $d = '') => trim((string)$this->in($k, $d));
        switch ($tab) {
            case 'general':
                if ($op === 'holiday') { $day = $in('day'); if (!Fr::isDay($day)) $this->go($back, 'Date invalide.', 'danger'); $kind = in_array($in('kind'), ['holiday', 'closed', 'open'], true) ? $in('kind') : 'holiday'; if (!DB::val('SELECT 1 FROM fr_calendar WHERE day=?', [$day])) DB::insert('fr_calendar', ['day' => $day, 'kind' => $kind, 'label' => mb_substr($in('label'), 0, 150) ?: null]); Fr::resetCal(); $msg = 'Jour ajouté au calendrier.'; break; }
                if ($op === 'holiday_del') { DB::exec('DELETE FROM fr_calendar WHERE id=?', [(int)$this->in('id')]); Fr::resetCal(); $msg = 'Jour retiré.'; break; }
                $wd = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['workdays'] ?? [])), fn($x) => $x >= 1 && $x <= 7))); if (!$wd) $this->go($back, 'Choisissez au moins un jour ouvré.', 'danger'); sort($wd);
                foreach (['day_start', 'day_end'] as $k) if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $in($k))) $this->go($back, 'Heures d\'ouverture invalides (HH:MM).', 'danger'); if ($in('day_end') <= $in('day_start')) $this->go($back, 'La fermeture doit suivre l\'ouverture.', 'danger');
                $wk = (int)$in('weak_base'); if ($wk < 1 || $wk > 1000) $this->go($back, 'Seuil de base faible invalide (1 à 1000).', 'danger'); if (!preg_match('/^\d+(,\d+){0,5}$/', $in('aging'))) $this->go($back, 'Seuils d\'âge : jours séparés par des virgules.', 'danger');
                foreach (['fr.workdays' => implode(',', $wd), 'fr.day_start' => $in('day_start'), 'fr.day_end' => $in('day_end'), 'fr.calendar_validated' => !empty($_POST['calendar_validated']) ? '1' : '0', 'fr.weak_base' => (string)$wk, 'fr.sla_reopen' => $in('sla_reopen') === 'restart' ? 'restart' : 'keep', 'fr.sla_pause' => !empty($_POST['sla_pause']) ? '1' : '0', 'fr.aging' => $in('aging'), 'fr.alerts_on' => !empty($_POST['alerts_on']) ? '1' : '0'] as $k => $v) Settings::set($k, $v);
                Fr::resetCal(); FrStats::resetCache(); break;
            case 'catalog':
                if ($op === 'toggle') { DB::exec('UPDATE fr_catalog SET active=1-active WHERE id=?', [(int)$this->in('id')]); break; }
                $sv = mb_substr($in('service'), 0, 80); $ty = mb_substr($in('typology'), 0, 100); $h = (int)$in('sla_hours'); if ($sv === '' || $ty === '' || $h < 1 || $h > 2000) $this->go($back, 'Service, typologie et SLA (1 à 2000 h) sont obligatoires.', 'danger');
                DB::insert('fr_catalog', ['service' => $sv, 'typology' => $ty, 'subtype' => mb_substr($in('subtype'), 0, 100) ?: null, 'required_docs' => mb_substr($in('required_docs'), 0, 400) ?: null, 'sla_hours' => $h, 'calendar' => $in('calendar') === 'continuous' ? 'continuous' : 'business', 'eligible' => !empty($_POST['eligible']) ? 1 : 0, 'alert_hours' => max(0, (int)$in('alert_hours', '4')), 'active' => 1, 'sort_order' => 99]); $msg = 'Ligne ajoutée au catalogue.'; break;
            case 'reasons':
                if ($op === 'toggle') { DB::exec('UPDATE fr_reasons SET active=1-active WHERE id=?', [(int)$this->in('id')]); break; } $lab = mb_substr($in('label'), 0, 190); if ($lab === '' || !isset(Fr::KINDS[$in('kind')])) $this->go($back, 'Type et libellé du motif obligatoires.', 'danger'); DB::insert('fr_reasons', ['kind' => $in('kind'), 'label' => $lab, 'active' => 1]); $msg = 'Motif ajouté.'; break;
            case 'opdict':
                if ($op === 'validate') { $who = $in('who') === 'cxo' ? 'cxo_ok' : 'bo_ok'; if ($who === 'cxo_ok' ? !can('fr.validate') : !can('fr.manage')) { $this->forbidden(); return; } DB::exec("UPDATE fr_opdict SET $who=? WHERE id=?", [date('Y-m-d'), (int)$this->in('id')]); Audit::log('fr.opdict.validate', 'fr_opdict', $this->in('id'), null, ['par' => $who]); $msg = 'Validation enregistrée.'; break; }
                if ($op === 'counted') { DB::exec('UPDATE fr_opdict SET counted=1-counted, bo_ok=NULL, cxo_ok=NULL WHERE id=?', [(int)$this->in('id')]); $msg = 'Statut « compté » modifié : les validations BO et CXO sont à refaire.'; break; }
                $lab = mb_substr($in('label'), 0, 100); $fam = mb_substr($in('family'), 0, 60); if ($lab === '' || $fam === '') $this->go($back, 'Libellé et famille obligatoires.', 'danger'); if (DB::val('SELECT 1 FROM fr_opdict WHERE label=?', [$lab])) $this->go($back, 'Ce type d\'opération existe déjà.', 'danger');
                DB::insert('fr_opdict', ['label' => $lab, 'family' => $fam, 'counted' => !empty($_POST['counted']) ? 1 : 0, 'note' => mb_substr($in('note'), 0, 300) ?: null]); $msg = 'Type d\'opération ajouté (validation BO et CXO à faire).'; break;
            case 'targets':
                if ($op === 'validate') { if (!can('fr.validate')) { $this->forbidden(); return; } DB::exec('UPDATE fr_targets SET validated_at=? WHERE id=?', [date('Y-m-d'), (int)$this->in('id')]); Audit::log('fr.target.validate', 'fr_targets', $this->in('id')); $msg = 'Cible validée.'; break; }
                if ($op === 'delete') { DB::exec('DELETE FROM fr_targets WHERE id=?', [(int)$this->in('id')]); $msg = 'Cible retirée.'; break; }
                $m = $in('measure'); $t = str_replace(',', '.', $in('target')); $th = str_replace(',', '.', $in('threshold')); if (!in_array($m, ['exec', 'sla', 'quality', 'nc', 'complete'], true) || !is_numeric($t) || (float)$t < 0 || (float)$t > 100 || ($th !== '' && (!is_numeric($th) || (float)$th < 0 || (float)$th > 100))) $this->go($back, 'Mesure et cible (0 à 100 %) obligatoires ; seuil entre 0 et 100.', 'danger');
                $fid = (int)$in('franchise_id') ?: null; $zone = $in('zone') ?: null; if (DB::val('SELECT 1 FROM fr_targets WHERE measure=? AND ' . ($fid ? 'franchise_id=?' : 'franchise_id IS NULL') . ' AND ' . ($zone ? 'zone=?' : 'zone IS NULL'), array_values(array_filter([$m, $fid, $zone], fn($x) => $x !== null)))) $this->go($back, 'Une cible existe déjà pour ce périmètre.', 'danger');
                DB::insert('fr_targets', ['measure' => $m, 'franchise_id' => $fid, 'zone' => $zone, 'target' => (float)$t, 'threshold' => $th === '' ? null : (float)$th, 'direction' => $in('direction') === 'down' ? 'down' : 'up', 'note' => mb_substr($in('note'), 0, 300) ?: null]); $msg = 'Cible ajoutée (à valider avant toute alerte).'; break;
            case 'status':
                $raw = mb_substr($in('raw'), 0, 120); if ($raw === '' || !isset(Fr::ST[$in('status')])) $this->go($back, 'Libellé source et statut obligatoires.', 'danger'); if (DB::val('SELECT 1 FROM fr_status_map WHERE raw=?', [Fr::norm($raw)])) $this->go($back, 'Ce libellé est déjà associé.', 'danger');
                DB::insert('fr_status_map', ['raw' => Fr::norm($raw), 'status' => $in('status'), 'validated' => 0]); $msg = 'Correspondance ajoutée.'; break;
            case 'access':
                if ($op === 'delete') { DB::exec('DELETE FROM fr_access WHERE id=?', [(int)$this->in('id')]); Fr::resetScope(); Audit::log('fr.access.remove', 'fr_access', $this->in('id')); $msg = 'Accès retiré.'; break; }
                $u = (int)$in('user_id'); if (!DB::val('SELECT 1 FROM users WHERE id=?', [$u])) $this->go($back, 'Utilisateur introuvable.', 'danger'); $fid = (int)$in('franchise_id') ?: null; $zone = $in('zone') ?: null; if (($fid === null) === ($zone === null)) $this->go($back, 'Choisissez une franchise ou une zone (pas les deux).', 'danger');
                DB::insert('fr_access', ['user_id' => $u, 'kind' => $fid ? 'franchise' : 'zone', 'franchise_id' => $fid, 'zone' => $zone, 'created_at' => now()]); Fr::resetScope(); Audit::log('fr.access.add', 'fr_access', $u, null, ['franchise' => $fid, 'zone' => $zone]); $msg = 'Accès accordé.'; break;
        }
        Audit::log('fr.settings', 'settings', null, null, ['onglet' => $tab, 'op' => $op]); $this->go($back, $msg);
    }
}
