<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Voc};

/** Lot 59 — Indicateurs CX : catalogue de séries CSAT / FCR / FVR / CES, import de mesures, matrice par période, rapport comparatif. */
class VocMetricsController extends Controller {
    const COLS = ['serie', 'date', 'numerateur', 'base', 'region', 'segment', 'canal', 'granularite'];
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    private function g(string $k, string $d = ''): string { return isset($_GET[$k]) && is_string($_GET[$k]) ? trim($_GET[$k]) : $d; }
    private function arr(string $k): array { $v = $_GET[$k] ?? []; return is_array($v) ? array_values(array_unique(array_filter(array_map(fn($x) => is_string($x) ? $x : '', $v), fn($x) => $x !== ''))) : []; }

    /** Filtres + matrice ; partagé avec le tableau de bord. */
    static function collect(array $f): array {
        $cat = Voc::catalog(); $obs = Voc::observations();
        $all = array_filter($cat, fn($s) => ($f['metric'] === '' || $s['metric'] === $f['metric']) && ($f['scope'] === '' || $s['scope'] === $f['scope']) && ($f['sources'] === 'all' || ($f['sources'] === 'demo') === $s['demo']));
        $sel = array_values(array_intersect($f['selected'], array_keys($all))); $selected = $sel ? array_intersect_key($all, array_flip($sel)) : $all;
        $periods = Voc::periods($f['from'], $f['to'], $f['period']); $ids = array_values(array_intersect($f['periods'], array_column($periods, 'id'))); $compare = Voc::pick($periods, $ids);
        $auto = $f['baseline'] === 'available'; $baseIdx = -1; if (!$auto && $f['baseline'] !== 'none' && $compare) { $baseIdx = 0; foreach ($compare as $i => $p) if ($p['id'] === $f['baseline']) $baseIdx = $i; }
        $matrix = [];
        foreach ($selected as $s) { $vals = array_map(fn($p) => Voc::pool($obs[$s['id']] ?? [], $s, $p, $f), $compare); $ref = $baseIdx; if ($auto) { $ref = -1; foreach ($vals as $i => $v) if ($v['base'] > 0) { $ref = $i; break; } }
            $matrix[] = ['s' => $s, 'values' => $vals, 'ref' => $ref]; }
        return ['all' => $all, 'selected' => $selected, 'periods' => $periods, 'compare' => $compare, 'baseIdx' => $baseIdx, 'auto' => $auto, 'matrix' => $matrix, 'sel' => $sel, 'pids' => $ids];
    }
    static function defaults(): array {
        $dates = []; foreach (Voc::observations() as $rows) foreach ($rows as $r) $dates[] = $r['grain'] === 'month' ? Voc::monthEnd($r['date']) : $r['date'];
        $to = $dates ? Voc::monthEnd(max($dates)) : date('Y-m-t'); return ['from' => date('Y-m-01', strtotime(substr($to, 0, 7) . '-01 -3 months')), 'to' => $to];
    }
    private function filters(): array {
        $d = self::defaults(); $from = $this->g('from'); $to = $this->g('to');
        return ['from' => Voc::isDay($from) ? $from : $d['from'], 'to' => Voc::isDay($to) ? $to : $d['to'], 'period' => isset(Voc::METRIC_PERIODS[$this->g('period')]) ? $this->g('period') : 'month', 'periods' => $this->arr('periods'), 'baseline' => $this->g('baseline'),
            'metric' => isset(Voc::METRICS[$this->g('metric')]) ? $this->g('metric') : '', 'scope' => $this->g('scope'), 'region' => $this->g('region'), 'segment' => $this->g('segment'), 'channel' => $this->g('channel'),
            'sources' => in_array($this->g('sources'), ['real', 'demo'], true) ? $this->g('sources') : 'all', 'selected' => $this->arr('selected')];
    }
    static function reportFilters(array $f, array $v): array {
        $base = $v['baseIdx'] >= 0 ? $v['compare'][$v['baseIdx']] : null;
        return [['Dates', $f['from'] . ' au ' . $f['to']], ['Granularité', Voc::METRIC_PERIODS[$f['period']]], ['Indicateur', $f['metric'] ?: 'Tous'], ['Périmètre', $f['scope'] ?: 'Tous'], ['Canal', $f['channel'] ?: 'Tous'], ['Région', $f['region'] ?: 'Toutes'], ['Segment', $f['segment'] ?: 'Tous'],
            ['Origine', ['all' => 'Réel et démonstration', 'real' => 'Données réelles / importées', 'demo' => 'Démonstration'][$f['sources']]], ['Périodes', implode(' · ', array_map(fn($p) => $p['from'] . ' au ' . $p['to'], $v['compare'])) ?: 'Aucune'],
            ['Référence', $v['auto'] ? 'Première valeur disponible par série' : ($base ? $base['from'] . ' au ' . $base['to'] : 'Aucune')]];
    }
    function index(): void {
        $f = $this->filters(); $v = self::collect($f); $f['periods'] = $v['pids']; $f['selected'] = $v['sel'];
        $dims = ['region' => [], 'segment' => [], 'channel' => []]; foreach (Voc::observations() as $rows) foreach ($rows as $r) foreach ($dims as $k => $_) $dims[$k][$r[$k]] = 1; foreach ($dims as $k => $x) $dims[$k] = Voc::uniq(array_keys($x));
        if ($this->g('export') === 'csv') {
            Audit::log('export', 'voc_metrics', null, null, ['series' => count($v['matrix'])]);
            $out = array_merge(self::reportFilters($f, $v), [['Indicateur', 'Périmètre', 'Série', 'Formule', 'Source', 'Début', 'Fin', 'Valeur', 'Unité', 'Numérateur', 'Base', 'Écart']]);
            foreach ($v['matrix'] as $m) foreach ($m['values'] as $i => $st) { $s = $m['s']; $r = $m['ref'] >= 0 ? $m['values'][$m['ref']] : null;
                $out[] = [$s['metric'], $s['scope'], $s['name'], Voc::FORMULAS[$s['formula']], $s['demo'] ? 'Démonstration' : $s['origin'], $v['compare'][$i]['from'], $v['compare'][$i]['to'], $st['base'] ? round($st['value'], 4) : '', $s['unit'], $st['numerator'], $st['base'], ($i !== $m['ref'] && $st['base'] && $r && $r['base']) ? round($st['value'] - $r['value'], 4) : '']; }
            Voc::csvOut('CXO_INDICATEURS_comparaison.csv', $out);
        }
        $data = ['title' => 'Indicateurs CX', 'f' => $f, 'v' => $v, 'dims' => $dims, 'catalog' => Voc::catalog(), 'locked' => array_column(DB::all('SELECT DISTINCT series_id FROM vn_measures'), 'series_id')];
        if ($this->g('report') === 'html') {
            ob_start(); extract($data); $standalone = true; require ROOT . '/app/Views/voc/_metric_report.php'; $body = ob_get_clean();
            $css = 'body{font:15px system-ui,sans-serif;color:#152b45;max-width:1150px;padding:22px;margin:auto}table{border-collapse:collapse;width:100%;margin:12px 0 28px}th,td{text-align:left;border-bottom:1px solid #d9e4ef;padding:8px;vertical-align:top}thead{background:#edf4fa}small{display:block;color:#4e6680}h2{margin-top:25px}.text-muted,.small{color:#4e6680}.pos{color:#197e67}.neg{color:#b64b62}svg{max-width:850px;display:block}details{margin:6px 0}.d-flex{display:flex;gap:14px;flex-wrap:wrap}i.d-inline-block{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:4px}@media print{body{padding:0}table{font-size:11px}tr{break-inside:avoid}}';
            Audit::log('export', 'voc_metrics_report', null, null, []);
            header('Content-Type: text/html; charset=utf-8'); header('Content-Disposition: attachment; filename="Rapport_indicateurs_CXO_' . date('Y-m-d') . '.html"');
            echo '<!doctype html><html lang="fr"><meta charset="utf-8"><title>Rapport comparatif CXO</title><style>' . $css . '</style><body>' . $body . '</body></html>'; exit;
        }
        $this->view('voc/metrics', $data + ['report' => $this->g('report') === '1']);
    }

    // ───────────────────────── catalogue ─────────────────────────
    function seriesForm(string $id = ''): void {
        $s = $id !== '' ? DB::one('SELECT * FROM vn_series WHERE id=? AND is_demo=0', [(int)$id]) : null; if ($id !== '' && !$s) { $this->notFound(); return; }
        $this->view('voc/series_form', ['title' => $s ? 'Configurer la série' : 'Créer une série', 's' => $s, 'locked' => $s && DB::val('SELECT 1 FROM vn_measures WHERE series_id=?', [(int)$s['id']])]);
    }
    function seriesSave(string $id = ''): void {
        $s = $id !== '' ? DB::one('SELECT * FROM vn_series WHERE id=? AND is_demo=0', [(int)$id]) : null; if ($id !== '' && !$s) { $this->notFound(); return; }
        $back = 'voc/metrics/series/' . ($s ? $s['id'] : 'new'); $locked = $s && DB::val('SELECT 1 FROM vn_measures WHERE series_id=?', [(int)$s['id']]);
        if ($s && $this->in('act') === 'delete') { if ($locked) $this->go($back, 'Cette série porte des mesures : elle ne peut pas être supprimée.', 'danger'); DB::exec('DELETE FROM vn_series WHERE id=?', [(int)$s['id']]); Audit::log('delete', 'vn_series', (int)$s['id'], null, ['code' => $s['code']]); $this->go('voc/metrics', 'Série supprimée.'); }
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 100], 'scope' => ['label' => 'Le périmètre', 'req' => true, 'max' => 70], 'origin' => ['label' => 'La source des données', 'req' => true, 'max' => 120], 'description' => ['label' => 'La définition', 'req' => true, 'max' => 700]], $_POST);
        $formula = $locked ? $s['formula'] : (string)$this->in('formula'); $metric = $locked ? $s['metric'] : (string)$this->in('metric');
        if (!isset(Voc::FORMULAS[$formula])) $err['formula'] = 'Choisissez le calcul.'; if (!isset(Voc::METRICS[$metric])) $err['metric'] = 'Choisissez l\'indicateur.';
        $t = str_replace(',', '.', trim((string)$this->in('target', ''))); $target = $t === '' ? null : (is_numeric($t) ? (float)$t : NAN);
        if ($target !== null && !$err && (is_nan($target) || $target > Voc::seriesMax($formula) || $target < (Voc::unit($formula) === '%' ? 0 : 1))) $err['target'] = 'La cible est hors de l\'échelle choisie.';
        if ($err) { $_SESSION['_old'] = $_POST; $this->go($back, implode(' ', $err), 'danger'); }
        $d += ['metric' => $metric, 'formula' => $formula, 'direction' => $this->in('direction') === 'down' ? 'down' : 'up', 'target' => $target];
        if ($s) { DB::update('vn_series', $d, 'id=?', [(int)$s['id']]); Audit::log('update', 'vn_series', (int)$s['id'], null, ['code' => $s['code']]); }
        else {
            $slug = trim(preg_replace('/[^a-z0-9]+/', '-', Voc::fold($d['scope'] . '-' . $d['name'])), '-'); $code = 'kpi-' . substr($slug, 0, 60);
            if (DB::val('SELECT 1 FROM vn_series WHERE code=?', [$code]) || isset(Voc::catalog()[$code])) $code = 'kpi-' . substr($slug, 0, 50) . '-' . substr(bin2hex(random_bytes(3)), 0, 5);
            $nid = DB::insert('vn_series', $d + ['code' => $code, 'is_demo' => 0, 'created_at' => now()]); Audit::log('create', 'vn_series', $nid, null, ['code' => $code]);
        }
        Voc::flush(); $this->go('voc/metrics', 'Série enregistrée.');
    }
    function template(): void {
        $code = DB::val('SELECT code FROM vn_series WHERE is_demo=0 ORDER BY id LIMIT 1') ?: 'kpi-code-de-votre-serie';
        Voc::csvOut('Modele_mesures_CXO.csv', [self::COLS, [$code, '2026-10-01', 42, 55, 'Lomé', 'B2C', 'Call Center', 'jour']]);
    }
    /** Contrôle ligne à ligne : tout est refusé à la première feuille en erreur ; une clé identique met à jour la valeur déjà importée. */
    function import(): void {
        $back = 'voc/metrics'; $rows = json_decode((string)$this->in('payload', ''), true);
        if (!is_array($rows) || count($rows) < 2 || !is_array($rows[0])) $this->go($back, 'La feuille est vide ou illisible.', 'danger'); if (count($rows) > 20001) $this->go($back, 'Chargez 20 000 lignes au plus par import.', 'danger');
        $norm = fn($x) => Voc::fold((string)$x);
        $heads = array_map($norm, $rows[0]); $cols = array_map(fn($k) => array_search($k, $heads, true), self::COLS);
        if (in_array(false, array_slice($cols, 0, 4), true)) $this->go($back, 'Colonnes requises : serie, date, numerateur, base. Le modèle CSV reprend les colonnes attendues.', 'danger');
        $known = []; foreach (DB::all('SELECT * FROM vn_series WHERE is_demo=0') as $s) $known[$s['code']] = $s;
        $errors = []; $ok = []; $keys = []; $lim = fn($v) => mb_substr(trim((string)$v), 0, 70) ?: Voc::UNKNOWN;
        foreach (array_slice($rows, 1, null, true) as $i => $r) {
            if (!is_array($r) || !array_filter($r, fn($x) => trim((string)$x) !== '')) continue;
            $cell = fn($k) => $cols[$k] === false ? '' : trim((string)($r[$cols[$k]] ?? ''));
            $code = mb_substr($cell(0), 0, 100); $s = $known[$code] ?? null; $raw = $cell(1); $date = Voc::isDay(substr($raw, 0, 10)) ? substr($raw, 0, 10) : '';
            if ($date === '' && preg_match('/^\d{4,5}$/', $raw)) $date = date('Y-m-d', strtotime('1899-12-30 +' . (int)$raw . ' days'));
            $numRaw = str_replace(',', '.', $cell(2)); $baseRaw = $cell(3); $gl = $norm($cell(7)); $grain = in_array($gl, ['mois', 'month'], true) ? 'month' : 'day';
            $num = is_numeric($numRaw) ? (float)$numRaw : NAN; $base = ctype_digit($baseRaw) ? (int)$baseRaw : 0;
            $max = $s && Voc::unit($s['formula']) !== '%' ? Voc::seriesMax($s['formula']) * $base : $base; $min = $s && Voc::unit($s['formula']) !== '%' ? $base : 0;
            if (!$s || $date === '' || is_nan($num) || floor($num) != $num || $base <= 0 || $num < $min || $num > $max || !in_array($gl, ['', 'jour', 'day', 'mois', 'month'], true) || ($grain === 'month' && substr($date, -2) !== '01')) { $errors[] = 'Ligne ' . ($i + 1) . ' · Vérifiez le code série, les effectifs et la date. Un mois commence le 1er.'; continue; }
            $row = ['series_id' => (int)$s['id'], 'code' => $code, 'day' => $date, 'region' => $lim($cell(4)), 'segment' => $lim($cell(5)), 'channel' => $lim($cell(6)), 'numerator' => (int)$num, 'base' => $base, 'grain' => $grain];
            $key = json_encode([$row['series_id'], $date, $row['region'], $row['segment'], $row['channel'], $grain]);
            if (isset($keys[$key])) { $errors[] = 'Ligne ' . ($i + 1) . ' · Doublon de série, date et dimensions dans la feuille.'; continue; } $keys[$key] = 1; $ok[] = $row;
        }
        if ($errors || !$ok) $this->go($back, ($ok ? count($ok) . ' ligne(s) valides · ' : '') . count($errors) . ' erreur(s) : rien n\'a été importé. ' . implode(' ', array_slice($errors, 0, 7)), 'danger');
        // une même série ne mélange pas mesures journalières et mensuelles sur un même mois et une même dimension
        $grains = []; foreach (DB::all('SELECT series_id, region, segment, channel, day, grain FROM vn_measures WHERE series_id IN (' . implode(',', array_unique(array_column($ok, 'series_id'))) . ')') as $m) $grains[json_encode([(int)$m['series_id'], $m['region'], $m['segment'], $m['channel'], substr($m['day'], 0, 7)])] = $m['grain'];
        foreach ($ok as $r) { $k = json_encode([$r['series_id'], $r['region'], $r['segment'], $r['channel'], substr($r['day'], 0, 7)]); if (isset($grains[$k]) && $grains[$k] !== $r['grain']) $this->go($back, 'La série ' . $r['code'] . ' contient des mesures journalières et mensuelles qui se chevauchent pour une même dimension : rien n\'a été importé.', 'danger'); $grains[$k] = $r['grain']; }
        $src = mb_substr(trim((string)$this->in('source', 'Import')), 0, 150) ?: 'Import'; $pdo = DB::pdo(); $pdo->beginTransaction();
        try { foreach ($ok as $r) { $cur = DB::val('SELECT id FROM vn_measures WHERE series_id=? AND day=? AND region=? AND segment=? AND channel=? AND grain=?', [$r['series_id'], $r['day'], $r['region'], $r['segment'], $r['channel'], $r['grain']]);
                if ($cur) DB::update('vn_measures', ['numerator' => $r['numerator'], 'base' => $r['base'], 'source' => $src], 'id=?', [(int)$cur]);
                else DB::insert('vn_measures', ['series_id' => $r['series_id'], 'day' => $r['day'], 'region' => $r['region'], 'segment' => $r['segment'], 'channel' => $r['channel'], 'numerator' => $r['numerator'], 'base' => $r['base'], 'grain' => $r['grain'], 'source' => $src, 'created_at' => now()]); }
            $pdo->commit(); } catch (\Throwable $e) { $pdo->rollBack(); $this->go($back, 'Import impossible.', 'danger'); }
        Audit::log('import', 'vn_measures', null, null, ['rows' => count($ok)]); Voc::flush();
        $days = array_column($ok, 'day'); $q = http_build_query(['from' => min($days), 'to' => Voc::monthEnd(max($days)), 'sources' => 'real', 'selected' => array_values(array_unique(array_column($ok, 'code')))]);
        $this->go('voc/metrics?' . $q, count($ok) . ' mesures importées.');
    }
}
