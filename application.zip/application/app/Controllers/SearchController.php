<?php
namespace App\Controllers;
use App\Core\{Controller, Search};

/** Lot 55 : recherche globale (M28). */
class SearchController extends Controller {
    function index(): void {
        $q = trim((string)$this->in('q', '')); $only = (string)$this->in('type', ''); $src = Search::sources(); if (!isset($src[$only])) $only = '';
        $short = $q !== '' && mb_strlen(str_replace(['%', '_'], '', $q)) < Search::MIN;
        $res = $q === '' || $short ? [] : Search::run($q, $only ?: null);
        $this->view('search/index', ['title' => 'Recherche', 'q' => $q, 'res' => $res, 'only' => $only, 'short' => $short, 'sum' => array_sum(array_column($res, 'total'))]);
    }
    /** Suggestions pour la barre du haut (JSON) : quelques résultats par source. */
    function suggest(): void {
        $q = trim((string)$this->in('q', '')); $out = [];
        foreach (Search::run($q) as $k => $g) foreach (array_slice($g['rows'], 0, 3) as $r) $out[] = ['g' => $g['label'], 't' => $r['title'], 's' => $r['sub'], 'u' => url($r['url'])];
        header('Content-Type: application/json; charset=utf-8'); echo json_encode(['q' => $q, 'items' => array_slice($out, 0, 12)], JSON_UNESCAPED_UNICODE); exit;
    }
}
