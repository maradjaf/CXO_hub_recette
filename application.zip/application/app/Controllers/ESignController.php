<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Auth, ESign};

/** Paraphe de l'utilisateur et vérification publique d'un document signé. */
class ESignController extends Controller {
    function pad(): void { $this->view('esign/pad', ['title' => 'Ma signature', 'pad' => ESign::pad((int)Auth::id())]); }
    function savePad(): void { if (ESign::savePad((int)Auth::id(), (string)$this->in('pad'))) flash('Signature enregistrée.'); else flash('Dessinez votre signature dans le cadre avant d\'enregistrer.', 'danger'); redirect('esign/pad'); }
    function verify(string $code): void {
        $code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $code)); $doc = null;
        if ($code !== '' && ($n = DB::one("SELECT id, ref, title, note_date d FROM ns_notes WHERE verify_code=? AND status='signed'", [$code]))) $doc = ['Note de service', 'ns', $n];
        elseif ($code !== '' && ($m = DB::one("SELECT id, ref, subject title, memo_date d FROM mm_memos WHERE verify_code=? AND status IN ('to_sign','signed')", [$code]))) $doc = ['Mémorandum', 'memo', $m];
        $this->view('esign/verify', ['title' => 'Vérification d\'un document', 'doc' => $doc, 'code' => $code, 'sig' => $doc ? array_values(array_filter(ESign::rows($doc[1], (int)$doc[2]['id']), fn($s) => $s['status'] === 'signed')) : []], 'layout/public');
    }
}
