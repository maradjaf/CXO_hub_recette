<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Qualtrics, Secret, Settings};

/** Lot 68 — Connexion Qualtrics : jeton d'API, sources (enquête Qualtrics → modèle et correspondance locale), synchronisation. */
class QualtricsController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    function index(): void {
        $this->view('survey/qualtrics', ['title' => 'Qualtrics', 'dc' => Qualtrics::get('datacenter'), 'base' => Qualtrics::get('base'), 'hasToken' => Qualtrics::get('token') !== '', 'list' => DB::all('SELECT q.*, s.name survey_name, m.name mapping_name FROM sv_qsources q LEFT JOIN sv_surveys s ON s.id=q.survey_id LEFT JOIN sv_mappings m ON m.id=q.mapping_id ORDER BY q.name'),
            'surveys' => DB::all("SELECT id, name FROM sv_surveys WHERE status='active' ORDER BY name"), 'mappings' => DB::all("SELECT id, name FROM sv_mappings WHERE kind='results' ORDER BY name"), 'ok' => Qualtrics::ready()]);
    }
    function save(): void {
        $dc = strtolower(trim((string)($_POST['datacenter'] ?? ''))); $base = trim((string)($_POST['base'] ?? '')); $tok = (string)($_POST['token'] ?? '');
        if ($dc !== '' && !preg_match('/^[a-z0-9.-]{2,40}$/', $dc)) $this->go('surveys/qualtrics', 'Centre de données invalide (ex. fra1, ca1, yul1, iad1).', 'danger');
        if ($base !== '' && !preg_match('#^https://[^\s]+$#', $base) && !preg_match('#^http://(127\.0\.0\.1|localhost)(:\d+)?(/[^\s]*)?$#', $base)) $this->go('surveys/qualtrics', 'L\'adresse de base doit commencer par https://.', 'danger');
        Settings::set('qx.datacenter', $dc); Settings::set('qx.base', rtrim($base, '/')); if ($tok !== '') Settings::set('qx.token', Secret::enc($tok)); Audit::log('save', 'qualtrics'); $this->go('surveys/qualtrics', 'Connexion enregistrée.');
    }
    function test(): void { [$ok, $m] = Qualtrics::test(); Audit::log('test', 'qualtrics', null, null, ['ok' => $ok]); $this->go('surveys/qualtrics', $m, $ok ? 'success' : 'danger'); }
    function sourceSave(string $id = ''): void {
        $name = trim((string)($_POST['name'] ?? '')); $qid = trim((string)($_POST['qualtrics_id'] ?? '')); $err = [];
        if ($name === '' || mb_strlen($name) > 150) $err[] = 'Le nom est obligatoire.'; if (!preg_match('/^SV_[A-Za-z0-9]{8,30}$/', $qid)) $err[] = 'L\'identifiant Qualtrics ressemble à SV_xxxxxxxxxxxxxxx.';
        if (!DB::val('SELECT 1 FROM sv_surveys WHERE id=?', [(int)($_POST['survey_id'] ?? 0)])) $err[] = 'Choisissez le modèle d\'enquête.'; if (!DB::val("SELECT 1 FROM sv_mappings WHERE id=? AND kind='results'", [(int)($_POST['mapping_id'] ?? 0)])) $err[] = 'Choisissez une correspondance de résultats.';
        if ($err) $this->go('surveys/qualtrics', implode(' ', $err), 'danger'); $f = in_array($_POST['frequency'] ?? '', ['hourly', 'daily', 'weekly'], true) ? $_POST['frequency'] : 'daily';
        $d = ['name' => $name, 'qualtrics_id' => $qid, 'survey_id' => (int)$_POST['survey_id'], 'mapping_id' => (int)$_POST['mapping_id'], 'frequency' => $f, 'active' => empty($_POST['inactive']) ? 1 : 0];
        if ((int)$id && DB::val('SELECT 1 FROM sv_qsources WHERE id=?', [(int)$id])) DB::update('sv_qsources', $d, 'id=?', [(int)$id]); else DB::insert('sv_qsources', $d + ['created_at' => now()]); Audit::log('save', 'sv_qsource', $id ?: null); $this->go('surveys/qualtrics', 'Source enregistrée.');
    }
    function sourceDelete(string $id): void { DB::exec('DELETE FROM sv_qsources WHERE id=?', [(int)$id]); Audit::log('delete', 'sv_qsource', $id); $this->go('surveys/qualtrics', 'Source supprimée.'); }
    function sync(string $id): void { $s = DB::one('SELECT * FROM sv_qsources WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; } $m = Qualtrics::sync($s); Audit::log('sync', 'sv_qsource', $id); $this->go('surveys/qualtrics', $m); }
}
