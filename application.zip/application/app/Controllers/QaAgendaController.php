<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Auth, Ics, QaSessions as S};
/** Agenda mensuel des coachings et débriefings visibles par l'utilisateur, avec export .ics du mois. */
class QaAgendaController extends Controller {
    private function month(): string { $m = (string)$this->in('month', ''); return preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $m) ? $m : date('Y-m'); }
    /** @return array<int, array{kind:string,row:array,label:string,url:string}> séances du mois (hors annulées) visibles */
    private function items(string $month): array {
        $a = $month . '-01 00:00:00'; $b = date('Y-m-d 23:59:59', strtotime("$month-01 +1 month -1 day")); $kind = $this->in('kind'); $out = [];
        if ($kind !== 'debrief') { $c = new QaCoachingController(); foreach (DB::all("SELECT c.*, e.first_name, e.last_name FROM qa_coachings c JOIN employees e ON e.id=c.employee_id WHERE c.status<>'cancelled' AND c.planned_at BETWEEN ? AND ? ORDER BY c.planned_at", [$a, $b]) as $r)
            if ($c->canSee($r)) $out[] = ['kind' => 'coaching', 'row' => $r, 'label' => 'Coaching · ' . $r['last_name'] . ' ' . $r['first_name'], 'url' => 'qa/coachings/' . $r['id']]; }
        if ($kind !== 'coaching') { $d = new QaDebriefController(); foreach (DB::all("SELECT * FROM qa_debriefs WHERE status<>'cancelled' AND planned_at BETWEEN ? AND ? ORDER BY planned_at", [$a, $b]) as $r)
            if ($d->canSee($r)) $out[] = ['kind' => 'debrief', 'row' => $r, 'label' => 'Débriefing · ' . $r['title'], 'url' => 'qa/debriefs/' . $r['id']]; }
        usort($out, fn($x, $y) => strcmp($x['row']['planned_at'], $y['row']['planned_at'])); return $out;
    }
    function index(): void {
        $m = $this->month(); $items = $this->items($m); $byDay = []; foreach ($items as $i) $byDay[substr($i['row']['planned_at'], 0, 10)][] = $i;
        $this->view('qa/agenda', ['title' => 'Agenda qualité', 'month' => $m, 'byDay' => $byDay, 'n' => count($items), 'prev' => date('Y-m', strtotime("$m-01 -1 month")), 'next' => date('Y-m', strtotime("$m-01 +1 month"))]);
    }
    function ics(): void {
        $m = $this->month(); $ev = array_map(fn($i) => Ics::vevent($i['kind'], $i['row'], [], $i['label']), $this->items($m));
        header('Content-Type: text/calendar; charset=utf-8'); header('Content-Disposition: attachment; filename="agenda-qualite-' . $m . '.ics"');
        echo Ics::calendar($ev, 'PUBLISH', 'Agenda qualité ' . $m); exit;
    }
}
