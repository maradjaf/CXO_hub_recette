<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Ar, Ct, Notifier, Request, Scope};

/** Demandes d'attestation : le collaborateur demande, le service RH établit et signe électroniquement, le collaborateur télécharge le PDF. */
class ArController extends Controller {
    private function myEmp(): int { return (int)(Auth::user()['employee_id'] ?? 0); }
    // ---------- collaborateur ----------
    function mine(): void {
        $emp = $this->myEmp();
        $this->view('ar/mine', ['title' => 'Mes demandes d\'attestation', 'types' => DB::all('SELECT id, name FROM ar_types WHERE active=1 ORDER BY sort_order, name'), 'emp' => $emp,
            'rows' => $emp ? DB::all('SELECT r.*, t.name type_name FROM ar_requests r JOIN ar_types t ON t.id=r.type_id WHERE r.employee_id=? ORDER BY r.id DESC LIMIT 100', [$emp]) : []]);
    }
    function request(): void {
        $emp = $this->myEmp(); if (!$emp) { flash('Votre compte n\'est pas rattaché à une fiche collaborateur : contactez les RH.', 'danger'); redirect('attestations/mine'); }
        $t = DB::one('SELECT * FROM ar_types WHERE id=? AND active=1', [(int)$this->in('type_id')]); $purpose = mb_substr(trim((string)$this->in('purpose', '')), 0, 300);
        if (!$t) { flash('Choisissez le type d\'attestation.', 'danger'); redirect('attestations/mine'); }
        if (DB::val("SELECT COUNT(*) FROM ar_requests WHERE employee_id=? AND type_id=? AND status='requested'", [$emp, $t['id']]) >= 1) { flash('Une demande de ce type est déjà en cours de traitement.', 'warning'); redirect('attestations/mine'); }
        $id = DB::insert('ar_requests', ['employee_id' => $emp, 'type_id' => (int)$t['id'], 'purpose' => $purpose ?: null, 'status' => 'requested', 'requested_at' => now()]);
        Audit::log('create', 'ar_request', $id, null, ['type' => $t['name']]);
        $e = DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [$emp]);
        Notifier::toPermission('ar.manage', 'Demande d\'attestation', $e['first_name'] . ' ' . $e['last_name'] . ' : ' . $t['name'], '/attestations/' . $id);
        flash('Demande envoyée. Vous serez prévenu(e) dès que l\'attestation sera signée ; elle sera téléchargeable ici.'); redirect('attestations/mine');
    }
    function cancel(string $id): void {
        $r = DB::one("SELECT * FROM ar_requests WHERE id=? AND employee_id=? AND status='requested'", [(int)$id, $this->myEmp()]); if (!$r) { $this->notFound(); return; }
        DB::update('ar_requests', ['status' => 'cancelled'], 'id=?', [(int)$id]); Audit::log('cancel', 'ar_request', $id); flash('Demande annulée.'); redirect('attestations/mine');
    }
    function pdf(string $id): void {
        $r = DB::one('SELECT * FROM ar_requests WHERE id=?', [(int)$id]); if (!$r) { $this->notFound(); return; }
        $own = $r['status'] === 'issued' && $this->myEmp() && (int)$r['employee_id'] === $this->myEmp();
        if (!$own && !can('ar.manage')) { $this->notFound(); return; }
        if (!$own && $r['status'] !== 'issued' && trim((string)$r['body']) === '') { $this->notFound(); return; }
        Audit::log('pdf', 'ar_request', $id); Ar::pdfOut($r);
    }
    // ---------- RH ----------
    function queue(): void {
        $st = (string)$this->in('status', 'requested'); [$sw, $sp] = Scope::sql('r.employee_id'); $w = [$sw]; $p = $sp;
        if (isset(Ar::STATUS[$st])) { $w[] = 'r.status=?'; $p[] = $st; }
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(e.first_name LIKE ? OR e.last_name LIKE ? OR e.matricule LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $rows = DB::all('SELECT r.*, t.name type_name, e.first_name, e.last_name, e.matricule FROM ar_requests r JOIN ar_types t ON t.id=r.type_id JOIN employees e ON e.id=r.employee_id WHERE ' . implode(' AND ', $w) . ' ORDER BY (r.status=\'requested\') DESC, r.id DESC LIMIT 300', $p);
        $this->view('ar/queue', ['title' => 'Demandes d\'attestation', 'rows' => $rows, 'st' => $st, 'types' => DB::all('SELECT id, name FROM ar_types WHERE active=1 ORDER BY sort_order, name'), 'employees' => Scope::employees(), 'pending' => (int)DB::val("SELECT COUNT(*) FROM ar_requests WHERE status='requested'")]);
    }
    /** Le service RH établit une attestation de lui-même pour un collaborateur. */
    function direct(): void {
        $emp = (int)$this->in('employee_id'); $t = DB::one('SELECT * FROM ar_types WHERE id=? AND active=1', [(int)$this->in('type_id')]);
        if (!$emp || !Scope::allows($emp) || !DB::val('SELECT 1 FROM employees WHERE id=?', [$emp]) || !$t) { flash('Choisissez le collaborateur et le type.', 'danger'); redirect('attestations'); }
        $id = DB::insert('ar_requests', ['employee_id' => $emp, 'type_id' => (int)$t['id'], 'purpose' => mb_substr(trim((string)$this->in('purpose', '')), 0, 300) ?: null, 'status' => 'requested', 'requested_at' => now()]);
        Audit::log('create', 'ar_request', $id, null, ['direct' => true]); redirect('attestations/' . $id);
    }
    private function load(string $id): ?array {
        $r = DB::one('SELECT r.*, t.name type_name, t.body type_body, e.first_name, e.last_name, e.matricule FROM ar_requests r JOIN ar_types t ON t.id=r.type_id JOIN employees e ON e.id=r.employee_id WHERE r.id=?', [(int)$id]);
        if (!$r || !Scope::allows((int)$r['employee_id'])) { $this->notFound(); return null; } return $r;
    }
    function show(string $id): void {
        if (!($r = $this->load($id))) return;
        if ($r['status'] === 'requested' && trim((string)$r['body']) === '') { $r['body'] = Ct::render((string)$r['type_body'], Ar::values((int)$r['employee_id'], (string)$r['purpose'])); }
        $this->view('ar/show', ['title' => $r['type_name'] . ' : ' . $r['first_name'] . ' ' . $r['last_name'], 'r' => $r, 'left' => Ct::hasBlank((string)$r['body']) ? ['zones vides ……………'] : [], 'sig' => Ar::signatory((int)$r['employee_id']), 'known' => Ar::known()]);
    }
    function saveBody(string $id): void {
        if (!($r = $this->load($id))) return; if ($r['status'] !== 'requested') { flash('Seule une demande en attente peut être modifiée.', 'warning'); redirect("attestations/$id"); }
        $b = trim((string)$this->in('body', '')); if ($b === '' || mb_strlen($b) > 20000) { flash('Le texte est vide ou trop long.', 'danger'); redirect("attestations/$id"); }
        DB::update('ar_requests', ['body' => $b, 'title' => mb_substr($r['type_name'], 0, 190)], 'id=?', [(int)$id]); flash('Texte enregistré.'); redirect("attestations/$id");
    }
    function issue(string $id): void {
        if (!($r = $this->load($id))) return; if ($r['status'] !== 'requested') { flash('Cette demande est déjà traitée.', 'warning'); redirect("attestations/$id"); }
        $b = trim((string)($this->in('body', '') ?: $r['body'])); if ($b === '') $b = Ct::render((string)$r['type_body'], Ar::values((int)$r['employee_id'], (string)$r['purpose']));
        if (Ct::hasBlank($b) && $this->in('force') !== '1') { flash('Le texte contient encore des zones vides (« ……………  ») ou des variables {{…}} : complétez-les ou cochez « Signer malgré tout ».', 'danger'); DB::update('ar_requests', ['body' => $b], 'id=?', [(int)$id]); redirect("attestations/$id"); }
        [$sn, $st] = Ar::signatory((int)$r['employee_id']); $code = strtoupper(bin2hex(random_bytes(6)));
        $upd = ['status' => 'issued', 'title' => mb_substr($r['type_name'], 0, 190), 'body' => $b, 'verify_code' => $code, 'signed_by' => $sn, 'signed_title' => $st, 'signed_ip' => mb_substr(Request::ip(), 0, 45), 'decided_by' => Auth::id(), 'issued_at' => now()];
        $x = $upd + $r; DB::update('ar_requests', $upd + ['doc_hash' => Ar::hash($x)], 'id=?', [(int)$id]);
        Audit::log('issue', 'ar_request', $id, null, ['signed_by' => $sn]);
        $uid = DB::val('SELECT id FROM users WHERE employee_id=? LIMIT 1', [(int)$r['employee_id']]);
        if ($uid) Notifier::send((int)$uid, 'Attestation disponible', 'Votre « ' . $r['type_name'] . ' » est signée : téléchargez-la dans « Mes attestations ».', '/attestations/mine');
        $mail = (string)DB::val('SELECT email FROM employees WHERE id=?', [(int)$r['employee_id']]) ?: (string)DB::val('SELECT email FROM users WHERE employee_id=? LIMIT 1', [(int)$r['employee_id']]);
        $mailed = $mail !== '' && Ct::mail($mail, 'Votre attestation est disponible : ' . $r['type_name'], "Bonjour {$r['first_name']},\n\nVotre « {$r['type_name']} » est établie et signée électroniquement. Connectez-vous pour la télécharger (menu « Mes attestations ») : " . Ct::abs('attestations/mine') . "\n");
        flash('Attestation signée et délivrée' . ($mailed ? ' ; le collaborateur est prévenu par e-mail.' : ' ; le collaborateur est prévenu dans l\'application.')); redirect("attestations/$id");
    }
    function reject(string $id): void {
        if (!($r = $this->load($id))) return; if ($r['status'] !== 'requested') { redirect("attestations/$id"); }
        $n = trim((string)$this->in('note', '')); if (mb_strlen($n) < 3) { flash('Indiquez le motif du refus.', 'danger'); redirect("attestations/$id"); }
        DB::update('ar_requests', ['status' => 'rejected', 'decision_note' => mb_substr($n, 0, 300), 'decided_by' => Auth::id()], 'id=?', [(int)$id]); Audit::log('reject', 'ar_request', $id);
        if ($uid = DB::val('SELECT id FROM users WHERE employee_id=? LIMIT 1', [(int)$r['employee_id']])) Notifier::send((int)$uid, 'Demande d\'attestation refusée', $r['type_name'] . ' : ' . mb_substr($n, 0, 200), '/attestations/mine');
        flash('Demande refusée ; le collaborateur est prévenu.'); redirect('attestations');
    }
    // ---------- types ----------
    function types(): void { $this->view('ar/types', ['title' => 'Types d\'attestation', 'rows' => DB::all('SELECT t.*, (SELECT COUNT(*) FROM ar_requests r WHERE r.type_id=t.id) used FROM ar_types t ORDER BY t.active DESC, t.sort_order, t.name')]); }
    function typeForm(string $id = ''): void {
        $t = $id !== '' ? DB::one('SELECT * FROM ar_types WHERE id=?', [(int)$id]) : ['id' => null, 'name' => '', 'body' => "## ATTESTATION\n\nNous attestons que {{nom_complet}}, matricule {{matricule}}, ...\n\nMotif : {{motif}}.", 'active' => 1, 'sort_order' => 50];
        if (!$t) { $this->notFound(); return; } $this->view('ar/type_form', ['title' => $t['id'] ? 'Type : ' . $t['name'] : 'Nouveau type d\'attestation', 't' => $t, 'known' => Ar::known()]);
    }
    function typeSave(string $id = ''): void {
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 150], 'body' => ['label' => 'Le texte', 'req' => true, 'max' => 20000]], $_POST);
        if ($err) $this->back($err, $_POST, $id !== '' ? "attestations/types/$id" : 'attestations/types/new');
        $d['active'] = isset($_POST['active']) ? 1 : 0; $d['sort_order'] = max(0, min(999, (int)$this->in('sort_order', 50)));
        if ($id !== '') { if (!DB::val('SELECT 1 FROM ar_types WHERE id=?', [(int)$id])) { $this->notFound(); return; } DB::update('ar_types', $d, 'id=?', [(int)$id]); Audit::log('update', 'ar_type', $id, null, $d); }
        else { $id = (string)DB::insert('ar_types', $d); Audit::log('create', 'ar_type', $id, null, $d); }
        flash('Type enregistré.'); redirect('attestations/types');
    }
    function typeDelete(string $id): void {
        $t = DB::one('SELECT * FROM ar_types WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return; }
        if ((int)DB::val('SELECT COUNT(*) FROM ar_requests WHERE type_id=?', [(int)$id])) { DB::update('ar_types', ['active' => 0], 'id=?', [(int)$id]); flash('Type déjà utilisé : il est désactivé.', 'info'); }
        else { DB::exec('DELETE FROM ar_types WHERE id=?', [(int)$id]); flash('Type supprimé.'); } Audit::log('delete', 'ar_type', $id, $t); redirect('attestations/types');
    }
    // ---------- vérification publique ----------
    function verify(string $code): void {
        \App\Core\Activity::skipRequest(); $code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $code));
        $r = $code !== '' ? DB::one("SELECT r.id, r.title, r.issued_at, r.signed_by, r.signed_title, r.doc_hash, e.first_name, e.last_name FROM ar_requests r JOIN employees e ON e.id=r.employee_id WHERE r.verify_code=? AND r.status='issued'", [$code]) : null;
        $this->view('ar/verify', ['title' => 'Vérification d\'une attestation', 'r' => $r, 'code' => $code], 'layout/public');
    }
}
