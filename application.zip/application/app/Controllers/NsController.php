<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, ESign, Notifier, Ns, Tickets, View};

/** Notes de service : demande, rédaction par le secrétariat, visas, signature électronique. */
class NsController extends Controller {
    private function load(string $id): ?array { $n = DB::one('SELECT n.*, r.name requester, s.name signer, t.reference tref FROM ns_notes n LEFT JOIN users r ON r.id=n.requester_id LEFT JOIN users s ON s.id=n.signer_id LEFT JOIN at_tickets t ON t.id=n.ticket_id WHERE n.id=?', [(int)$id]); if (!$n || !Ns::sees($n)) { $this->notFound(); return null; } return $n; }
    private function tpls(): array { return DB::all('SELECT * FROM ns_templates WHERE active=1 ORDER BY name'); }
    function index(): void {
        $me = (int)Auth::id(); $wide = can('ns.secretary') || can('ns.all'); $view = (string)($_GET['view'] ?? 'mine'); $w = []; $p = [];
        if ($view === 'todo') { $w[] = "n.status IN ('visa','to_sign') AND EXISTS (SELECT 1 FROM esign s WHERE s.doc_type='ns' AND s.doc_id=n.id AND s.user_id=? AND s.status='pending')"; $p[] = $me; }
        elseif ($view === 'all' && $wide) { } else { $view = 'mine'; $w[] = 'n.requester_id=?'; $p[] = $me; }
        $st = (string)($_GET['status'] ?? ''); if (isset(Ns::ST[$st])) { $w[] = 'n.status=?'; $p[] = $st; }
        if (($q = trim((string)($_GET['q'] ?? ''))) !== '') { $w[] = '(n.title LIKE ? OR n.ref LIKE ? OR n.addressee LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $from = 'ns_notes n LEFT JOIN users r ON r.id=n.requester_id LEFT JOIN at_tickets t ON t.id=n.ticket_id WHERE ' . ($w ? implode(' AND ', $w) : '1=1');
        if (($_GET['export'] ?? '') === 'csv') csv_download('notes_de_service_' . date('Ymd_His') . '.csv', ['Référence', 'Objet', 'Destinataire', 'Demandeur', 'Ticket', 'Statut', 'Demandée le', 'Signée le'], array_map(fn($r) => [$r['ref'], $r['title'], $r['addressee'], $r['requester'], $r['tref'], Ns::ST[$r['status']] ?? $r['status'], $r['created_at'], $r['signed_at']], DB::all("SELECT n.*, r.name requester, t.reference tref FROM $from ORDER BY n.id DESC", $p)));
        $this->view('ns/index', ['title' => 'Notes de service', 'p' => paginate($from, $p, $this->page(), 25, 'n.*, r.name requester, t.reference tref', 'n.id DESC'), 'view' => $view, 'st' => $st, 'wide' => $wide,
            'todo' => (int)DB::val("SELECT COUNT(*) FROM esign s JOIN ns_notes n ON n.id=s.doc_id WHERE s.doc_type='ns' AND s.user_id=? AND s.status='pending' AND n.status IN ('visa','to_sign') AND (s.kind='visa' OR n.status='to_sign')", [$me])]);
    }
    /** Tableau de bord du secrétariat. */
    function board(): void {
        $v = fn(string $c, array $x = []) => (int)DB::val("SELECT COUNT(*) FROM ns_notes n WHERE $c", $x); $m0 = date('Y-m-01 00:00:00');
        $ds = array_map(fn($r) => (strtotime((string)$r['signed_at']) - strtotime((string)$r['created_at'])) / 86400, DB::all("SELECT signed_at, created_at FROM ns_notes WHERE status='signed' AND signed_at>=?", [date('Y-m-d H:i:s', strtotime('-90 days'))])); $delay = $ds ? array_sum($ds) / count($ds) : null;
        $cols = 'n.*, r.name requester, t.reference tref, tp.name tname'; $j = 'ns_notes n LEFT JOIN users r ON r.id=n.requester_id LEFT JOIN at_tickets t ON t.id=n.ticket_id LEFT JOIN ns_templates tp ON tp.id=n.template_id';
        $cats = array_column(DB::all('SELECT category FROM ns_motifs WHERE active=1 AND required=1'), 'category');
        $this->view('ns/board', ['title' => 'Secrétariat : notes de service', 'K' => ['req' => $v("n.status='requested'"), 'draft' => $v("n.status IN ('drafting','rejected')"), 'visa' => $v("n.status='visa'"), 'sign' => $v("n.status='to_sign'"), 'month' => $v("n.status='signed' AND n.signed_at>=?", [$m0]), 'delay' => $delay === null ? null : round((float)$delay, 1)],
            'queue' => DB::all("SELECT $cols FROM $j WHERE n.status IN ('requested','drafting','rejected') ORDER BY CASE n.status WHEN 'rejected' THEN 0 WHEN 'requested' THEN 1 ELSE 2 END, n.created_at LIMIT 100"),
            'flow' => array_map(function ($r) { $r['waiting'] = implode(', ', array_column(DB::all("SELECT u.name FROM esign s JOIN users u ON u.id=s.user_id WHERE s.doc_type='ns' AND s.doc_id=? AND s.status='pending' AND (s.kind='visa' OR ?='to_sign') ORDER BY s.position", [(int)$r['id'], $r['status']]), 'name')); return $r; }, DB::all("SELECT $cols FROM $j WHERE n.status IN ('visa','to_sign') ORDER BY n.submitted_at LIMIT 100")),
            'signed' => DB::all("SELECT $cols FROM $j WHERE n.status='signed' ORDER BY n.signed_at DESC LIMIT 15"),
            'orphans' => $cats ? DB::all('SELECT t.id, t.reference, t.title, t.category, t.created_at FROM at_tickets t WHERE t.category IN (' . implode(',', array_fill(0, count($cats), '?')) . ") AND t.status NOT IN ('closed','cancelled') AND NOT EXISTS (SELECT 1 FROM ns_notes n WHERE n.ticket_id=t.id AND n.status<>'cancelled') ORDER BY t.id DESC LIMIT 30", $cats) : []]);
    }
    function create(): void {
        $tk = (int)($_GET['ticket'] ?? 0); $t = $tk ? DB::one('SELECT id, reference, title, description, category, requester_id FROM at_tickets WHERE id=?', [$tk]) : null;
        if ($t && !((int)$t['requester_id'] === (int)Auth::id() || can('at.handle') || can('ns.secretary'))) $t = null;
        $this->view('ns/form', ['title' => 'Demander une note de service', 'tpls' => $this->tpls(), 'ticket' => $t, 'motif' => $t ? Ns::motif($t['category']) : null]);
    }
    function store(): void {
        $title = trim((string)$this->in('title')); $ctx = trim((string)$this->in('context')); $tk = (int)$this->in('ticket_id') ?: null;
        if ($tk) { $t = DB::one('SELECT requester_id FROM at_tickets WHERE id=?', [$tk]); if (!$t || !((int)$t['requester_id'] === (int)Auth::id() || can('at.handle') || can('ns.secretary'))) $tk = null; }
        if ($title === '' || mb_strlen($title) > 200 || $ctx === '') { $_SESSION['_old'] = $_POST; flash('L\'objet et les précisions de la demande sont obligatoires.', 'danger'); redirect('ns/new' . ($tk ? '?ticket=' . $tk : '')); }
        $id = Ns::request(['title' => $title, 'context' => $ctx, 'addressee' => trim((string)$this->in('addressee')), 'memo_ref' => trim((string)$this->in('memo_ref')), 'template_id' => (int)$this->in('template_id') ?: null, 'ticket_id' => $tk], (int)Auth::id());
        unset($_SESSION['_old']); Audit::log('create', 'ns_note', $id); flash('Demande transmise au secrétariat.'); redirect('ns/' . $id);
    }
    function show(string $id): void {
        if (!($n = $this->load($id))) return; $sig = ESign::rows('ns', (int)$id); $mine = null;
        foreach ($sig as $s) if ((int)$s['user_id'] === (int)Auth::id() && $s['status'] === 'pending' && (($s['kind'] === 'visa' && $n['status'] === 'visa') || ($s['kind'] === 'sign' && $n['status'] === 'to_sign'))) { $mine = $s; break; }
        $this->view('ns/show', ['title' => $n['ref'] ?: 'Note de service', 'n' => $n, 'sig' => $sig, 'mine' => $mine, 'pad' => ESign::pad((int)Auth::id()), 'sec' => can('ns.secretary'),
            'log' => DB::all('SELECT l.*, u.name uname FROM ns_log l LEFT JOIN users u ON u.id=l.user_id WHERE l.note_id=? ORDER BY l.id DESC', [(int)$id])]);
    }
    /** Écran de rédaction (secrétariat). */
    function draft(string $id): void {
        if (!can('ns.secretary')) { $this->forbidden(); return; } if (!($n = $this->load($id))) return;
        if (!in_array($n['status'], ['requested', 'drafting', 'rejected'], true)) { flash('Cette note n\'est plus modifiable.', 'warning'); redirect('ns/' . $id); }
        if ($n['status'] === 'requested') { DB::update('ns_notes', ['status' => 'drafting', 'secretary_id' => Auth::id(), 'updated_at' => now()], 'id=?', [(int)$id]); Ns::log((int)$id, 'take'); Notifier::send((int)$n['requester_id'], 'Votre note de service est en cours de rédaction', $n['title'], '/ns/' . $id); $n['status'] = 'drafting'; }
        $tpl = $n['template_id'] ? DB::one('SELECT * FROM ns_templates WHERE id=?', [(int)$n['template_id']]) : null; $cur = ESign::rows('ns', (int)$id);
        $vis = $cur ? array_map(fn($s) => ['label' => $s['role'], 'user_id' => (int)$s['user_id']], array_values(array_filter($cur, fn($s) => $s['kind'] === 'visa'))) : Ns::visas($tpl['visas'] ?? null);
        $this->view('ns/draft', ['title' => 'Rédiger la note', 'n' => $n, 'tpls' => $this->tpls(), 'vis' => $vis, 'validators' => ESign::usersWith('ns.validate'), 'signers' => ESign::usersWith('ns.sign')]);
    }
    function save(string $id): void {
        if (!can('ns.secretary')) { $this->forbidden(); return; } if (!($n = $this->load($id))) return;
        if (!in_array($n['status'], ['requested', 'drafting', 'rejected'], true)) { flash('Cette note n\'est plus modifiable.', 'warning'); redirect('ns/' . $id); }
        $act = (string)$this->in('act', 'save');
        if ($act === 'template') { $tpl = DB::one('SELECT * FROM ns_templates WHERE id=? AND active=1', [(int)$this->in('template_id')]); if ($tpl) { $n2 = ['template_id' => (int)$tpl['id'], 'addressee' => $tpl['addressee'] ?: $n['addressee'], 'entity' => $tpl['entity'] ?: $n['entity'], 'ref_suffix' => $tpl['ref_suffix'] ?: $n['ref_suffix'], 'signer_title' => $tpl['signer_title'], 'signer_id' => $tpl['signer_id']];
                $n2['body'] = Ns::fill((string)$tpl['body'], $n2 + $n); ESign::clear('ns', (int)$id); DB::update('ns_notes', $n2 + ['status' => 'drafting', 'updated_at' => now()], 'id=?', [(int)$id]); Ns::log((int)$id, 'draft', 'Modèle appliqué : ' . $tpl['name']); flash('Modèle appliqué.'); } redirect("ns/$id/draft"); }
        $d = ['title' => mb_substr(trim((string)$this->in('title')), 0, 200), 'addressee' => mb_substr(trim((string)$this->in('addressee')), 0, 200) ?: null, 'memo_ref' => mb_substr(trim((string)$this->in('memo_ref')), 0, 80) ?: null, 'body' => mb_substr(trim((string)$this->in('body')), 0, 20000) ?: null, 'entity' => mb_substr(trim((string)$this->in('entity')), 0, 100) ?: Ns::entity(), 'ref_suffix' => mb_substr(trim((string)$this->in('ref_suffix')), 0, 60) ?: Ns::suffix(),
            'signer_title' => mb_substr(trim((string)$this->in('signer_title')), 0, 100) ?: null, 'signer_id' => (int)$this->in('signer_id') ?: null, 'place' => mb_substr(trim((string)$this->in('place')), 0, 60) ?: 'Lomé', 'secretary_id' => $n['secretary_id'] ?: Auth::id(), 'updated_at' => now()];
        $okS = array_map('intval', array_column(ESign::usersWith('ns.sign'), 'id')); $okV = array_map('intval', array_column(ESign::usersWith('ns.validate'), 'id')); $vis = []; $err = [];
        foreach ((array)($_POST['v_label'] ?? []) as $i => $l) { $l = mb_substr(trim((string)$l), 0, 80); $u = (int)($_POST['v_user'][$i] ?? 0); if ($l === '' && !$u) continue; if ($l === '' || !in_array($u, $okV, true)) { $err[] = 'Chaque visa doit avoir un intitulé et un valideur habilité.'; continue; } $vis[] = [$l, $u]; }
        if ($d['title'] === '') $err[] = 'L\'objet est obligatoire.'; if ($d['signer_id'] && !in_array($d['signer_id'], $okS, true)) { $err[] = 'Le signataire choisi n\'est pas habilité à signer.'; $d['signer_id'] = null; }
        if ($act === 'submit') { if (!$d['body']) $err[] = 'Le texte de la note est vide.'; if (!$d['signer_id']) $err[] = 'Désignez le signataire.'; if (!$d['signer_title']) $err[] = 'Indiquez le titre du signataire.'; if (!$d['addressee']) $err[] = 'Indiquez le destinataire (« À l\'attention de »).'; }
        if ($err) { DB::update('ns_notes', array_filter($d, fn($x) => $x !== null) + ['status' => $n['status'] === 'requested' ? 'drafting' : $n['status']], 'id=?', [(int)$id]); flash(implode(' ', array_unique($err)), 'danger'); redirect("ns/$id/draft"); }
        ESign::clear('ns', (int)$id); foreach ($vis as $i => [$l, $u]) ESign::ask('ns', (int)$id, 'visa', $l, $u, $i + 1);
        if ($act !== 'submit') { DB::update('ns_notes', $d + ['status' => $n['status'] === 'rejected' ? 'rejected' : 'drafting'], 'id=?', [(int)$id]); Ns::log((int)$id, 'draft', 'Projet enregistré'); flash('Projet enregistré.'); redirect("ns/$id/draft"); }
        ESign::ask('ns', (int)$id, 'sign', (string)$d['signer_title'], (int)$d['signer_id'], 99);
        DB::update('ns_notes', $d + ['status' => $vis ? 'visa' : 'to_sign', 'reject_reason' => null, 'submitted_at' => now()], 'id=?', [(int)$id]); Ns::log((int)$id, 'submit', $vis ? count($vis) . ' visa(s) demandé(s)' : 'Envoyée directement à la signature');
        if ($vis) foreach ($vis as [$l, $u]) Notifier::send($u, 'Note de service à viser (' . $l . ')', $d['title'], '/ns/' . $id); else Notifier::send((int)$d['signer_id'], 'Note de service à signer', $d['title'], '/ns/' . $id);
        Audit::log('update', 'ns_note', $id, null, ['act' => 'submit']); flash($vis ? 'Note envoyée aux valideurs.' : 'Note envoyée au signataire.'); redirect('ns/' . $id);
    }
    /** Visa ou signature (mot de passe exigé), ou refus motivé. */
    function decide(string $id): void {
        if (!($n = $this->load($id))) return; $me = (int)Auth::id(); $kind = $n['status'] === 'visa' ? 'visa' : ($n['status'] === 'to_sign' ? 'sign' : null);
        $s = $kind ? ESign::mine('ns', (int)$id, $kind) : null; if (!$s) { $this->forbidden(); return; }
        $ok = (string)$this->in('decision') === 'ok'; $c = trim((string)$this->in('comment'));
        if (!ESign::confirm((string)$this->in('password'))) { flash('Mot de passe incorrect : la décision n\'a pas été enregistrée.', 'danger'); redirect('ns/' . $id); }
        if (!$ok) { if ($c === '') { flash('Le motif du refus est obligatoire.', 'danger'); redirect('ns/' . $id); }
            ESign::reject((int)$s['id'], $c); DB::update('ns_notes', ['status' => 'rejected', 'reject_reason' => mb_substr($s['role'] . ' : ' . $c, 0, 500), 'updated_at' => now()], 'id=?', [(int)$id]); Ns::log((int)$id, 'reject', $s['role'] . ' : ' . $c);
            foreach (array_unique(array_filter([(int)$n['secretary_id'], (int)$n['requester_id']])) as $u) Notifier::send($u, 'Note de service à corriger', $n['title'] . ' — ' . $c, '/ns/' . $id); flash('Refus enregistré : la note retourne au secrétariat.'); redirect('ns/' . $id); }
        $pad = (string)$this->in('pad'); if ($pad !== '') ESign::savePad($me, $pad);
        if ($kind === 'sign' && !ESign::pad($me)) { flash('Dessinez votre signature avant de signer.', 'danger'); redirect('ns/' . $id); }
        ESign::sign((int)$s['id'], Ns::hash($n), $c);
        if ($kind === 'visa') { Ns::log((int)$id, 'visa', $s['role']);
            if (!ESign::left('ns', (int)$id, 'visa')) { DB::update('ns_notes', ['status' => 'to_sign', 'updated_at' => now()], 'id=?', [(int)$id]); Notifier::send((int)$n['signer_id'], 'Note de service à signer', $n['title'], '/ns/' . $id); }
            flash('Visa enregistré.'); redirect('ns/' . $id); }
        [$no, $y] = Ns::number('ns_notes'); $ref = sprintf('%04d/%s', $no, $n['ref_suffix'] ?: Ns::suffix());
        DB::update('ns_notes', ['status' => 'signed', 'ref_no' => $no, 'year' => $y, 'ref' => $ref, 'note_date' => date('Y-m-d'), 'signed_at' => now(), 'verify_code' => ESign::code(), 'updated_at' => now()], 'id=?', [(int)$id]); Ns::log((int)$id, 'sign', 'N° ' . $ref);
        foreach (array_unique(array_filter([(int)$n['requester_id'], (int)$n['secretary_id']])) as $u) Notifier::send($u, 'Note de service signée : N° ' . $ref, $n['title'], '/ns/' . $id);
        if ($n['ticket_id']) Tickets::event((int)$n['ticket_id'], 'link', 'Note de service N° ' . $ref . ' signée.', $me);
        Audit::log('sign', 'ns_note', $id, null, ['ref' => $ref]); flash('Note signée : N° ' . $ref . '.'); redirect('ns/' . $id);
    }
    function cancel(string $id): void {
        if (!($n = $this->load($id))) return; $c = trim((string)$this->in('comment'));
        if (!(can('ns.secretary') || ((int)$n['requester_id'] === (int)Auth::id() && $n['status'] === 'requested'))) { $this->forbidden(); return; }
        if (in_array($n['status'], ['signed', 'cancelled'], true) || $c === '') { flash('Annulation impossible (note signée) ou motif manquant.', 'danger'); redirect('ns/' . $id); }
        ESign::clear('ns', (int)$id); DB::update('ns_notes', ['status' => 'cancelled', 'reject_reason' => mb_substr($c, 0, 500), 'updated_at' => now()], 'id=?', [(int)$id]); Ns::log((int)$id, 'cancel', $c);
        if ((int)$n['requester_id'] !== (int)Auth::id()) Notifier::send((int)$n['requester_id'], 'Demande de note de service annulée', $n['title'] . ' — ' . $c, '/ns/' . $id); flash('Demande annulée.'); redirect('ns/' . $id);
    }
    function printView(string $id): void {
        if (!($n = $this->load($id))) return; if ($n['status'] === 'requested' && !can('ns.secretary')) { $this->forbidden(); return; }
        echo View::partial('ns/print', ['n' => $n, 'sig' => ESign::rows('ns', (int)$id), 'kind' => 'ns']);
    }
    // ───── Paramétrage : modèles et motifs de ticket ─────
    function settings(): void {
        $this->view('ns/settings', ['title' => 'Notes de service : modèles et motifs', 'tpls' => DB::all('SELECT t.*, u.name signer FROM ns_templates t LEFT JOIN users u ON u.id=t.signer_id ORDER BY t.active DESC, t.name'), 'edit' => (int)($_GET['edit'] ?? 0) ? DB::one('SELECT * FROM ns_templates WHERE id=?', [(int)$_GET['edit']]) : null,
            'motifs' => DB::all('SELECT m.*, t.name tname FROM ns_motifs m LEFT JOIN ns_templates t ON t.id=m.template_id ORDER BY m.category'), 'cats' => Ns::cats(), 'validators' => ESign::usersWith('ns.validate'), 'signers' => ESign::usersWith('ns.sign')]);
    }
    function tplSave(): void {
        $id = (int)$this->in('id'); $vis = [];
        foreach ((array)($_POST['v_label'] ?? []) as $i => $l) { $l = mb_substr(trim((string)$l), 0, 80); $u = (int)($_POST['v_user'][$i] ?? 0); if ($l !== '' && $u) $vis[] = ['label' => $l, 'user_id' => $u]; }
        $d = ['name' => mb_substr(trim((string)$this->in('name')), 0, 150), 'addressee' => mb_substr(trim((string)$this->in('addressee')), 0, 200) ?: null, 'subject' => mb_substr(trim((string)$this->in('subject')), 0, 200) ?: null, 'body' => mb_substr(trim((string)$this->in('body')), 0, 20000), 'entity' => mb_substr(trim((string)$this->in('entity')), 0, 100) ?: Ns::entity(), 'ref_suffix' => mb_substr(trim((string)$this->in('ref_suffix')), 0, 60) ?: Ns::suffix(),
            'signer_title' => mb_substr(trim((string)$this->in('signer_title')), 0, 100) ?: null, 'signer_id' => (int)$this->in('signer_id') ?: null, 'visas' => json_encode($vis, JSON_UNESCAPED_UNICODE), 'active' => $this->in('active') ? 1 : 0];
        if ($d['name'] === '' || $d['body'] === '') { flash('Le nom et le texte du modèle sont obligatoires.', 'danger'); redirect('ns/settings' . ($id ? '?edit=' . $id : '')); }
        if ($id && DB::val('SELECT 1 FROM ns_templates WHERE id=?', [$id])) DB::update('ns_templates', $d, 'id=?', [$id]); else $id = (int)DB::insert('ns_templates', $d + ['created_at' => now()]);
        Audit::log('save', 'ns_template', $id); flash('Modèle enregistré.'); redirect('ns/settings');
    }
    function motifSave(): void {
        $cat = (string)$this->in('category'); $tpl = (int)$this->in('template_id') ?: null; $codes = array_column(Ns::cats(), 'code');
        if (!in_array($cat, $codes, true) || ($tpl && !DB::val('SELECT 1 FROM ns_templates WHERE id=?', [$tpl]))) { flash('Motif ou modèle inconnu.', 'danger'); redirect('ns/settings#motifs'); }
        $d = ['category' => $cat, 'template_id' => $tpl, 'required' => $this->in('required') ? 1 : 0, 'active' => 1];
        if (($id = DB::val('SELECT id FROM ns_motifs WHERE category=?', [$cat]))) DB::update('ns_motifs', $d, 'id=?', [(int)$id]); else DB::insert('ns_motifs', $d);
        Audit::log('save', 'ns_motif', $cat); flash('Motif enregistré.'); redirect('ns/settings#motifs');
    }
    function motifDelete(string $id): void { DB::exec('DELETE FROM ns_motifs WHERE id=?', [(int)$id]); Audit::log('delete', 'ns_motif', $id); flash('Motif retiré.'); redirect('ns/settings#motifs'); }
}
