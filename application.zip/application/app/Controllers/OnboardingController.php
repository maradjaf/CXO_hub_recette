<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Bulk};
class OnboardingController extends Controller {
    private function mayWork(array $task): bool { return can('onboarding.manage') || ($task['owner_role'] && in_array($task['owner_role'], array_column(Auth::roles(), 'code'), true)); }
    function index(): void {
        $st = (string)$this->in('status', 'open'); $w = $st === 'all' ? '1=1' : 'c.status=?'; $p = $st === 'all' ? [] : [$st];
        $pg = paginate("onboarding_cases c JOIN employees e ON e.id=c.employee_id WHERE $w", $p, $this->page(), 20,
            "c.*, e.first_name, e.last_name, e.matricule, (SELECT COUNT(*) FROM onboarding_tasks t WHERE t.case_id=c.id) total, (SELECT COUNT(*) FROM onboarding_tasks t WHERE t.case_id=c.id AND t.status='done') done, (SELECT COUNT(*) FROM onboarding_tasks t WHERE t.case_id=c.id AND t.status='todo' AND t.due_date<'" . date('Y-m-d') . "') late", 'c.id DESC');
        $roles = array_column(Auth::roles(), 'code'); $mine = [];
        if ($roles) { $in = implode(',', array_fill(0, count($roles), '?')); $mine = DB::all("SELECT t.*, e.first_name, e.last_name FROM onboarding_tasks t JOIN onboarding_cases c ON c.id=t.case_id JOIN employees e ON e.id=c.employee_id WHERE t.status='todo' AND c.status='open' AND t.owner_role IN ($in) ORDER BY t.due_date LIMIT 15", $roles); }
        $this->view('onboarding/index', ['title' => 'Intégrations', 'p' => $pg, 'mine' => $mine, 'templates' => can('onboarding.manage') ? DB::all('SELECT * FROM onboarding_templates WHERE active=1 ORDER BY name') : [],
            'employees' => can('onboarding.manage') ? DB::all("SELECT id, first_name, last_name, matricule FROM employees WHERE status='active' ORDER BY last_name, first_name") : []]);
    }
    /** Ouvre un parcours pour un collaborateur (null s'il en a déjà un ouvert). $roles cumule les rôles à prévenir. */
    static function open(int $emp, int $tpl, string $date, array &$roles): ?int {
        if (DB::val("SELECT 1 FROM onboarding_cases WHERE employee_id=? AND status='open'", [$emp])) return null;
        $case = DB::insert('onboarding_cases', ['employee_id' => $emp, 'template_id' => $tpl, 'start_date' => $date, 'status' => 'open', 'created_by' => Auth::id(), 'created_at' => now()]);
        foreach (DB::all('SELECT * FROM onboarding_template_tasks WHERE template_id=? ORDER BY position', [$tpl]) as $t) {
            DB::insert('onboarding_tasks', ['case_id' => $case, 'position' => $t['position'], 'title' => $t['title'], 'owner_role' => $t['owner_role'], 'due_date' => date('Y-m-d', strtotime("$date {$t['due_days']} days")), 'status' => 'todo']);
            if ($t['owner_role']) $roles[$t['owner_role']] = true;
        }
        Audit::log('create', 'onboarding_case', $case, null, ['employee_id' => $emp, 'template_id' => $tpl, 'start_date' => $date]);
        return $case;
    }
    private function tell(array $roles, string $title, string $url): void {
        foreach (array_keys($roles) as $role) foreach (DB::all('SELECT ur.user_id FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE r.code=?', [$role]) as $u) Notifier::send((int)$u['user_id'], $title, 'Des tâches vous sont confiées.', $url);
    }
    function start(): void {
        $emp = (int)$this->in('employee_id'); $tpl = (int)$this->in('template_id'); $date = (string)$this->in('start_date', date('Y-m-d'));
        if (!DB::val('SELECT 1 FROM employees WHERE id=?', [$emp]) || !DB::val('SELECT 1 FROM onboarding_templates WHERE id=? AND active=1', [$tpl]) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) { flash('Choisissez un collaborateur, un modèle et une date.', 'danger'); redirect('onboarding'); }
        $roles = []; $case = self::open($emp, $tpl, $date, $roles);
        if (!$case) { flash('Un parcours est déjà ouvert pour ce collaborateur.', 'warning'); redirect('onboarding'); }
        $this->tell($roles, 'Nouveau parcours d\'intégration', '/onboarding/' . $case);
        flash('Parcours d\'intégration lancé.'); redirect("onboarding/$case");
    }
    function bulkForm(): void {
        $this->view('bulk/launch', ['title' => 'Lancer des intégrations en masse', 'kind' => 'onboarding', 'action' => 'onboarding/bulk', 'back' => 'onboarding', 'templates' => DB::all('SELECT id, name FROM onboarding_templates WHERE active=1 ORDER BY name'), 'types' => [],
            'employees' => Bulk::candidates("e.status<>'left' AND NOT EXISTS (SELECT 1 FROM onboarding_cases c WHERE c.employee_id=e.id AND c.status='open')")]);
    }
    function bulk(): void {
        $tpl = (int)$this->in('template_id'); $date = (string)$this->in('start_date', date('Y-m-d'));
        if (!DB::val('SELECT 1 FROM onboarding_templates WHERE id=? AND active=1', [$tpl]) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) { flash('Choisissez un modèle et une date valides.', 'danger'); redirect('onboarding/bulk'); }
        [$ids, $unknown] = Bulk::ids($_POST); $roles = []; $ok = 0; $skip = 0;
        foreach ($ids as $emp) { if (self::open($emp, $tpl, $date, $roles)) $ok++; else $skip++; }
        $this->tell($roles, 'Nouveaux parcours d\'intégration', '/onboarding');
        Audit::log('bulk', 'onboarding_case', null, null, ['created' => $ok, 'skipped' => $skip, 'unknown' => count($unknown)]);
        flash(Bulk::report($ok, $skip, $unknown, 'parcours lancé(s)'), $ok ? 'success' : 'warning'); redirect('onboarding');
    }
    function show(string $id): void {
        $c = DB::one('SELECT c.*, e.first_name, e.last_name, e.matricule, tp.name tpl FROM onboarding_cases c JOIN employees e ON e.id=c.employee_id LEFT JOIN onboarding_templates tp ON tp.id=c.template_id WHERE c.id=?', [(int)$id]);
        if (!$c) { $this->notFound(); return; }
        $tasks = DB::all('SELECT t.*, u.name done_name FROM onboarding_tasks t LEFT JOIN users u ON u.id=t.done_by WHERE t.case_id=? ORDER BY t.position', [(int)$id]);
        foreach ($tasks as &$t) $t['may'] = $this->mayWork($t); unset($t);
        $this->view('onboarding/show', ['title' => 'Intégration · ' . $c['first_name'] . ' ' . $c['last_name'], 'c' => $c, 'tasks' => $tasks,
            'roleNames' => array_column(DB::all('SELECT code, name FROM roles'), 'name', 'code')]);
    }
    function completeTask(string $id, string $tid): void {
        $t = DB::one('SELECT * FROM onboarding_tasks WHERE id=? AND case_id=?', [(int)$tid, (int)$id]); if (!$t) { $this->notFound(); return; }
        if (!$this->mayWork($t)) { $this->forbidden(); return; }
        $undo = $t['status'] === 'done';
        DB::update('onboarding_tasks', $undo ? ['status' => 'todo', 'done_at' => null, 'done_by' => null, 'note' => null] : ['status' => 'done', 'done_at' => now(), 'done_by' => Auth::id(), 'note' => substr(trim((string)$this->in('note', '')), 0, 500) ?: null], 'id=?', [(int)$tid]);
        $left = (int)DB::val("SELECT COUNT(*) FROM onboarding_tasks WHERE case_id=? AND status='todo'", [(int)$id]);
        DB::update('onboarding_cases', $left ? ['status' => 'open', 'closed_at' => null] : ['status' => 'done', 'closed_at' => now()], 'id=?', [(int)$id]);
        Audit::log($undo ? 'reopen_task' : 'complete_task', 'onboarding_task', $tid, ['status' => $t['status']]);
        if (!$left) { $by = DB::val('SELECT created_by FROM onboarding_cases WHERE id=?', [(int)$id]); if ($by) Notifier::send((int)$by, 'Parcours d\'intégration terminé', 'Toutes les tâches sont faites.', '/onboarding/' . $id); }
        flash($undo ? 'Tâche rouverte.' : 'Tâche terminée.'); redirect("onboarding/$id");
    }
    function templates(): void {
        $tpls = DB::all('SELECT * FROM onboarding_templates ORDER BY name'); foreach ($tpls as &$t) $t['tasks'] = DB::all('SELECT * FROM onboarding_template_tasks WHERE template_id=? ORDER BY position', [$t['id']]); unset($t);
        $this->view('onboarding/templates', ['title' => 'Modèles d\'intégration', 'tpls' => $tpls, 'roles' => DB::all('SELECT code, name FROM roles ORDER BY name')]);
    }
    function storeTemplate(): void {
        $n = trim((string)$this->in('name', '')); if ($n === '') { flash('Donnez un nom au modèle.', 'danger'); redirect('onboarding/templates'); }
        $id = DB::insert('onboarding_templates', ['name' => mb_substr($n, 0, 150), 'active' => 1]); Audit::log('create', 'onboarding_template', $id, null, ['name' => $n]); redirect('onboarding/templates');
    }
    function storeTemplateTask(string $id): void {
        $title = trim((string)$this->in('title', '')); $role = (string)$this->in('owner_role', '');
        if (!DB::val('SELECT 1 FROM onboarding_templates WHERE id=?', [(int)$id]) || $title === '' || ($role !== '' && !DB::val('SELECT 1 FROM roles WHERE code=?', [$role]))) { flash('Renseignez un intitulé et un rôle valide.', 'danger'); redirect('onboarding/templates'); }
        $row = ['template_id' => (int)$id, 'position' => (int)DB::val('SELECT COALESCE(MAX(position),0)+1 FROM onboarding_template_tasks WHERE template_id=?', [(int)$id]), 'title' => mb_substr($title, 0, 190), 'owner_role' => $role ?: null, 'due_days' => (int)$this->in('due_days', 0)];
        $tid = DB::insert('onboarding_template_tasks', $row); Audit::log('create', 'onboarding_template_task', $tid, null, $row); redirect('onboarding/templates');
    }
    function deleteTemplateTask(string $id, string $tid): void {
        $o = DB::one('SELECT * FROM onboarding_template_tasks WHERE id=? AND template_id=?', [(int)$tid, (int)$id]); if (!$o) { $this->notFound(); return; }
        DB::exec('DELETE FROM onboarding_template_tasks WHERE id=?', [(int)$tid]); Audit::log('delete', 'onboarding_template_task', $tid, $o); redirect('onboarding/templates');
    }
}
