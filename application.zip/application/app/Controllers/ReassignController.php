<?php
namespace App\Controllers;

use App\Core\{Audit, Auth, Controller, DB, Notifier, Tr};

/** Réaffectation en cas d'indisponibilité : agents d'un coach qualité vers un autre coach, sessions et cours d'un formateur vers un autre. */
final class ReassignController extends Controller {
    const WHY = ['Absence', 'Congé', 'Maladie', 'Mission ou formation', 'Départ de l\'entreprise', 'Réorganisation', 'Autre'];

    private function reason(): ?string { $w = (string)($_POST['why'] ?? ''); $t = trim((string)($_POST['reason'] ?? '')); $o = in_array($w, self::WHY, true) ? $w : ''; return mb_substr(trim($o . ($t !== '' ? ($o ? ' — ' : '') . $t : '')), 0, 300) ?: null; }
    private function uidOf(int $emp): ?int { $u = DB::val("SELECT id FROM users WHERE employee_id=? AND status='active' ORDER BY id LIMIT 1", [$emp]); return $u ? (int)$u : null; }
    private function ename(int $emp): string { $e = DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [$emp]); return $e ? trim($e['first_name'] . ' ' . $e['last_name']) : ''; }

    function index(): void {
        $tab = (string)$this->in('tab', can('qa.manage') ? 'coach' : 'trainer'); if (!in_array($tab, ['coach', 'trainer'], true)) $tab = 'coach';
        if (($tab === 'coach' && !can('qa.manage')) || ($tab === 'trainer' && !can('training.manage'))) { $this->forbidden(); return; }
        $from = (int)$this->in('from', 0); $today = date('Y-m-d'); $d = ['title' => 'Réaffectation en cas d\'indisponibilité', 'tab' => $tab, 'from' => $from, 'why' => self::WHY];
        if ($tab === 'coach') {
            $d['coaches'] = DB::all("SELECT u.id, u.name, (SELECT COUNT(*) FROM qa_portfolios p WHERE p.coach_user_id=u.id AND p.period_end>=?) np, (SELECT COUNT(*) FROM qa_coachings c WHERE c.coach_user_id=u.id AND c.status='planned' AND c.planned_at>=?) nc FROM users u WHERE u.status='active' AND (EXISTS (SELECT 1 FROM qa_portfolios p WHERE p.coach_user_id=u.id AND p.period_end>=?) OR EXISTS (SELECT 1 FROM qa_coachings c WHERE c.coach_user_id=u.id AND c.status='planned' AND c.planned_at>=?)) ORDER BY u.name", [$today, now(), $today, now()]);
            $d['targets'] = DB::all("SELECT DISTINCT u.id, u.name FROM users u JOIN user_roles ur ON ur.user_id=u.id JOIN role_permissions rp ON rp.role_id=ur.role_id JOIN permissions p ON p.id=rp.permission_id WHERE u.status='active' AND p.code IN ('qa.evaluate','qa.manage') ORDER BY u.name");
            if ($from) {
                $d['agents'] = DB::all("SELECT e.id, e.first_name, e.last_name, e.matricule, (SELECT COUNT(*) FROM qa_portfolios p WHERE p.coach_user_id=? AND p.employee_id=e.id AND p.period_end>=?) np, (SELECT COUNT(*) FROM qa_coachings c WHERE c.coach_user_id=? AND c.employee_id=e.id AND c.status='planned' AND c.planned_at>=?) nc FROM employees e WHERE e.id IN (SELECT employee_id FROM qa_portfolios WHERE coach_user_id=? AND period_end>=? UNION SELECT employee_id FROM qa_coachings WHERE coach_user_id=? AND status='planned' AND planned_at>=?) ORDER BY e.last_name, e.first_name", [$from, $today, $from, now(), $from, $today, $from, now()]);
                $d['fromName'] = (string)DB::val('SELECT name FROM users WHERE id=?', [$from]);
            }
        } else {
            $d['trainers'] = DB::all("SELECT e.id, e.first_name, e.last_name, (SELECT COUNT(*) FROM training_sessions s WHERE (s.trainer_emp_id=e.id OR s.backup_emp_id=e.id) AND s.status NOT IN ('done','cancelled') AND COALESCE(s.end_date, s.session_date)>=?) ns, (SELECT COUNT(*) FROM el_courses c JOIN users u ON u.id=c.trainer_id WHERE u.employee_id=e.id AND c.status<>'archived') nc FROM employees e WHERE e.status='active' AND (EXISTS (SELECT 1 FROM training_sessions s WHERE (s.trainer_emp_id=e.id OR s.backup_emp_id=e.id) AND s.status NOT IN ('done','cancelled') AND COALESCE(s.end_date, s.session_date)>=?) OR EXISTS (SELECT 1 FROM el_courses c JOIN users u ON u.id=c.trainer_id WHERE u.employee_id=e.id AND c.status<>'archived')) ORDER BY e.last_name", [$today, $today]);
            $d['targets'] = DB::all("SELECT e.id, e.first_name, e.last_name FROM employees e JOIN users u ON u.employee_id=e.id AND u.status='active' WHERE e.status='active' AND EXISTS (SELECT 1 FROM user_roles ur JOIN roles r ON r.id=ur.role_id WHERE ur.user_id=u.id AND r.code IN ('trainer','training_team','hr','quality','quality_manager','manager')) ORDER BY e.last_name");
            if ($from) {
                $d['sessions'] = DB::all("SELECT s.id, s.session_date, s.end_date, s.label, s.trainer_emp_id, s.backup_emp_id, t.title, (SELECT COUNT(*) FROM training_enrollments en WHERE en.session_id=s.id) np FROM training_sessions s JOIN trainings t ON t.id=s.training_id WHERE (s.trainer_emp_id=? OR s.backup_emp_id=?) AND s.status NOT IN ('done','cancelled') AND COALESCE(s.end_date, s.session_date)>=? ORDER BY s.session_date", [$from, $from, $today]);
                $d['courses'] = DB::all("SELECT c.id, c.title, c.status, (SELECT COUNT(*) FROM el_enrollments en WHERE en.course_id=c.id AND en.status IN ('assigned','in_progress')) ne FROM el_courses c JOIN users u ON u.id=c.trainer_id WHERE u.employee_id=? AND c.status<>'archived' ORDER BY c.title", [$from]);
                $d['fromName'] = $this->ename($from); $d['pickSession'] = (int)$this->in('session', 0);
            }
        }
        $d['hist'] = DB::all('SELECT r.*, u.name by_name FROM reassignments r LEFT JOIN users u ON u.id=r.created_by WHERE r.kind=? ORDER BY r.id DESC LIMIT 30', [$tab]);
        foreach ($d['hist'] as &$h) { foreach (['from_id' => 'fn', 'to_id' => 'tn'] as $k => $o) $h[$o] = $tab === 'coach' ? (string)DB::val('SELECT name FROM users WHERE id=?', [(int)$h[$k]]) : $this->ename((int)$h[$k]); } unset($h);
        $this->view('reassign/index', $d);
    }

    function coach(): void {
        if (!can('qa.manage')) { $this->forbidden(); return; }
        $from = (int)($_POST['from'] ?? 0); $to = (int)($_POST['to'] ?? 0); $emps = array_map('intval', (array)($_POST['emp'] ?? [])); $why = $this->reason(); $today = date('Y-m-d');
        $back = fn() => redirect('reassign?tab=coach&from=' . $from);
        if (!$from || !$to || $from === $to || !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$to])) { flash('Choisissez le coach indisponible et un autre coach actif.', 'danger'); $back(); return; }
        if (!$emps) { flash('Sélectionnez au moins un agent à réaffecter.', 'danger'); $back(); return; }
        if (!$why) { flash('Indiquez le motif de l\'indisponibilité.', 'danger'); $back(); return; }
        $items = ['portfolios' => [], 'coachings' => []]; $agents = [];
        foreach ($emps as $e) {
            foreach (DB::all('SELECT id FROM qa_portfolios WHERE coach_user_id=? AND employee_id=? AND period_end>=?', [$from, $e, $today]) as $p) { DB::update('qa_portfolios', ['coach_user_id' => $to], 'id=?', [(int)$p['id']]); $items['portfolios'][] = (int)$p['id']; $agents[$e] = 1; }
            foreach (DB::all("SELECT id FROM qa_coachings WHERE coach_user_id=? AND employee_id=? AND status='planned' AND planned_at>=?", [$from, $e, now()]) as $c) { DB::update('qa_coachings', ['coach_user_id' => $to], 'id=?', [(int)$c['id']]); $items['coachings'][] = (int)$c['id']; $agents[$e] = 1;
                if (($au = $this->uidOf($e))) Notifier::send($au, 'Changement de coach qualité', 'Votre coaching sera assuré par ' . DB::val('SELECT name FROM users WHERE id=?', [$to]) . '.', '/qa/coachings/mine'); }
        }
        $n = count($items['portfolios']) + count($items['coachings']); if (!$n) { flash('Rien à réaffecter pour cette sélection.', 'warning'); $back(); return; }
        $id = DB::insert('reassignments', ['kind' => 'coach', 'from_id' => $from, 'to_id' => $to, 'reason' => $why, 'items' => json_encode($items), 'n_items' => $n, 'created_by' => Auth::id(), 'created_at' => now()]);
        Notifier::send($to, 'Agents réaffectés à votre portefeuille', count($agents) . ' agent(s) vous sont confiés (' . DB::val('SELECT name FROM users WHERE id=?', [$from]) . ' : ' . $why . ').', '/qa/portfolio');
        Notifier::send($from, 'Vos agents ont été réaffectés', count($agents) . ' agent(s) confiés à ' . DB::val('SELECT name FROM users WHERE id=?', [$to]) . '.', '/qa/portfolios');
        Audit::log('reassign', 'qa_coach', $id, ['coach' => $from], ['coach' => $to, 'agents' => array_keys($agents), 'motif' => $why]);
        flash(count($agents) . ' agent(s) réaffecté(s) (' . count($items['portfolios']) . ' portefeuille(s), ' . count($items['coachings']) . ' coaching(s) planifié(s)).'); redirect('reassign?tab=coach');
    }

    function trainer(): void {
        if (!can('training.manage')) { $this->forbidden(); return; }
        $from = (int)($_POST['from'] ?? 0); $to = (int)($_POST['to'] ?? 0); $why = $this->reason(); $ss = array_map('intval', (array)($_POST['sessions'] ?? [])); $cs = array_map('intval', (array)($_POST['courses'] ?? []));
        $back = fn() => redirect('reassign?tab=trainer&from=' . $from);
        if (!$from || !$to || $from === $to || !DB::val("SELECT 1 FROM employees WHERE id=? AND status='active'", [$to])) { flash('Choisissez le formateur indisponible et un autre formateur actif.', 'danger'); $back(); return; }
        if (!$ss && !$cs) { flash('Sélectionnez au moins une session ou un cours.', 'danger'); $back(); return; }
        if (!$why) { flash('Indiquez le motif de l\'indisponibilité.', 'danger'); $back(); return; }
        $toU = $this->uidOf($to); if ($cs && !$toU) { flash('Le nouveau formateur n\'a pas de compte actif : impossible de lui confier un cours e-learning.', 'danger'); $back(); return; }
        $items = ['sessions' => [], 'courses' => []]; $fromName = $this->ename($from); $toName = $this->ename($to);
        foreach ($ss as $sid) { $s = DB::one("SELECT s.*, t.title FROM training_sessions s JOIN trainings t ON t.id=s.training_id WHERE s.id=? AND (s.trainer_emp_id=? OR s.backup_emp_id=?) AND s.status NOT IN ('done','cancelled')", [$sid, $from, $from]); if (!$s) continue;
            $u = ['trainer_unavailable' => 0, 'unavail_reason' => null];
            if ((int)$s['trainer_emp_id'] === $from) $u['trainer_emp_id'] = $to; if ((int)$s['backup_emp_id'] === $from) $u['backup_emp_id'] = $to;
            if (($u['trainer_emp_id'] ?? (int)$s['trainer_emp_id']) === ($u['backup_emp_id'] ?? (int)$s['backup_emp_id'])) $u['backup_emp_id'] = null;
            DB::update('training_sessions', $u, 'id=?', [$sid]); $items['sessions'][] = ['id' => $sid, 'trainer' => (int)$s['trainer_emp_id'] ?: null, 'backup' => (int)$s['backup_emp_id'] ?: null, 'unav' => (int)$s['trainer_unavailable'], 'ur' => $s['unavail_reason']];
            $when = Tr::when($s); foreach (Tr::participants($sid) as $p) if ($p['uid']) Notifier::send((int)$p['uid'], 'Changement de formateur', $s['title'] . ' · ' . $when . ' : la session sera animée par ' . $toName . '.', '/trainings/sessions/' . $sid);
            if ($toU) Notifier::send($toU, 'Vous intervenez en remplacement', $s['title'] . ' · ' . $when, '/trainings/sessions/' . $sid); }
        foreach ($cs as $cid) { if (!DB::val('SELECT 1 FROM el_courses c JOIN users u ON u.id=c.trainer_id WHERE c.id=? AND u.employee_id=?', [$cid, $from])) continue; DB::update('el_courses', ['trainer_id' => $toU], 'id=?', [$cid]); $items['courses'][] = $cid;
            Notifier::send($toU, 'Cours e-learning confié', (string)DB::val('SELECT title FROM el_courses WHERE id=?', [$cid]) . ' — vous en êtes désormais le formateur.', '/elearn/' . $cid); }
        $n = count($items['sessions']) + count($items['courses']); if (!$n) { flash('Rien à réaffecter pour cette sélection.', 'warning'); $back(); return; }
        $id = DB::insert('reassignments', ['kind' => 'trainer', 'from_id' => $from, 'to_id' => $to, 'reason' => $why, 'items' => json_encode($items), 'n_items' => $n, 'created_by' => Auth::id(), 'created_at' => now()]);
        if (($fu = $this->uidOf($from))) Notifier::send($fu, 'Vos formations ont été réaffectées', $n . ' élément(s) confiés à ' . $toName . '.', '/trainings');
        Audit::log('reassign', 'trainer', $id, ['formateur' => $from], ['formateur' => $to, 'sessions' => array_column($items['sessions'], 'id'), 'cours' => $items['courses'], 'motif' => $why]);
        flash(count($items['sessions']) . ' session(s) et ' . count($items['courses']) . ' cours réaffecté(s) à ' . $toName . '.'); redirect('reassign?tab=trainer');
    }

    /** Rend les éléments encore confiés au remplaçant à la personne d'origine (retour de congé, fin d'absence). */
    function undo(string $id): void {
        $r = DB::one('SELECT * FROM reassignments WHERE id=?', [(int)$id]); if (!$r) { $this->notFound(); return; }
        if (!can($r['kind'] === 'coach' ? 'qa.manage' : 'training.manage')) { $this->forbidden(); return; }
        if ($r['restored_at']) { flash('Cette réaffectation a déjà été annulée.', 'info'); redirect('reassign?tab=' . $r['kind']); }
        $it = json_decode((string)$r['items'], true) ?: []; $n = 0; $from = (int)$r['from_id']; $to = (int)$r['to_id'];
        if ($r['kind'] === 'coach') {
            foreach ($it['portfolios'] ?? [] as $pid) $n += DB::update('qa_portfolios', ['coach_user_id' => $from], 'id=? AND coach_user_id=?', [(int)$pid, $to]) ? 1 : 0;
            foreach ($it['coachings'] ?? [] as $cid) $n += DB::update('qa_coachings', ['coach_user_id' => $from], "id=? AND coach_user_id=? AND status='planned'", [(int)$cid, $to]) ? 1 : 0;
            Notifier::send($from, 'Vos agents vous sont rendus', $n . ' élément(s) de portefeuille restitués.', '/qa/portfolio');
        } else {
            foreach ($it['sessions'] ?? [] as $s) { $cur = DB::one("SELECT * FROM training_sessions WHERE id=? AND status NOT IN ('done','cancelled')", [(int)$s['id']]); if (!$cur) continue;
                $u = []; if ((int)$cur['trainer_emp_id'] === $to && (int)$s['trainer'] === $from) $u['trainer_emp_id'] = $from; if ((int)$cur['backup_emp_id'] === $to && (int)$s['backup'] === $from) $u['backup_emp_id'] = $from;
                if ($u) { DB::update('training_sessions', $u, 'id=?', [(int)$s['id']]); $n++; } }
            $fu = $this->uidOf($from); foreach ($it['courses'] ?? [] as $cid) if ($fu && DB::update('el_courses', ['trainer_id' => $fu], 'id=? AND trainer_id=?', [(int)$cid, (int)$this->uidOf($to)])) $n++;
        }
        DB::update('reassignments', ['restored_at' => now(), 'restored_by' => Auth::id()], 'id=?', [(int)$id]); Audit::log('reassign_undo', $r['kind'], $id);
        flash($n . ' élément(s) restitué(s) à la personne d\'origine.'); redirect('reassign?tab=' . $r['kind']);
    }
}
