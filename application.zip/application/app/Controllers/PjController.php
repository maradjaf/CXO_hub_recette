<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Auth, Pj, Pl, Audit, Notifier, Settings};
/** Gestion de projet (PMO) : portefeuille, roadmap par pilier, reporting hebdomadaire, partage. */
class PjController extends Controller {
    // ---- Outils ----
    private function proj(string $id, string $need = 'view'): ?array {
        $p = Pj::project((int)$id); if (!$p || !Pj::level($p)) { $this->notFound(); return null; }
        if (!Pj::can($p, $need)) { $this->forbidden(); return null; } return $p;
    }
    private function emps(): array { return DB::all("SELECT id, first_name, last_name FROM employees WHERE status<>'left' ORDER BY last_name, first_name"); }
    private function date(string $k): ?string { $d = (string)$this->in($k, ''); return Pl::validDate($d) ? $d : null; }
    private function week(): string { $w = (string)$this->in('week', ''); return Pl::monday(Pl::validDate($w) ? $w : date('Y-m-d')); }
    private function toProject(array $p, string $anchor = ''): void { redirect('pj/projects/' . $p['id'] . $anchor); }
    private function row(array $p): array {
        $pl = DB::one('SELECT name, color FROM pj_pillars WHERE id=?', [$p['pillar_id']]); $al = Pj::alerts($p);
        return $p + ['pillar' => $pl['name'] ?? 'Sans pilier', 'color' => ($pl['color'] ?? null) ?: '#003A84', 'prog' => Pj::progress($p), 'chealth' => Pj::computedHealth($p), 'alerts' => $al, 'milestones' => DB::all('SELECT * FROM pj_milestones WHERE project_id=? ORDER BY due_date', [$p['id']]), 'mgr' => Pj::empName($p['manager_id'] ? (int)$p['manager_id'] : null)];
    }
    private function rows(array $f = []): array { return array_map(fn($p) => $this->row($p), Pj::visible($f)); }

    // ---- Portefeuille ----
    function dashboard(): void {
        $rows = $this->rows(); $st = []; $hl = ['green' => 0, 'amber' => 0, 'red' => 0]; $alerts = []; $miss = 0; $blk = 0; $dec = 0;
        foreach ($rows as $r) { $st[$r['status']] = ($st[$r['status']] ?? 0) + 1; if (in_array($r['status'], ['active', 'planned', 'on_hold'], true)) { $hl[$r['chealth']]++; foreach ($r['alerts'] as $a) $alerts[] = [$a[0], $r, $a[2]]; if (Pj::reportMissing($r)) $miss++; $blk += count(Pj::openItems($r['id'], 'blocker')); $dec += count(Pj::openItems($r['id'], 'decision')); } }
        usort($alerts, fn($a, $b) => [$a[0] === 'bad' ? 0 : 1] <=> [$b[0] === 'bad' ? 0 : 1]);
        $this->view('pj/dashboard', ['title' => 'Portefeuille de projets', 'rows' => $rows, 'st' => $st, 'hl' => $hl, 'alerts' => array_slice($alerts, 0, 12), 'miss' => $miss, 'blk' => $blk, 'dec' => $dec, 'pillars' => Pj::pillars(), 'load' => can('pj.manage') ? array_filter(Pj::load(), fn($l) => $l['total'] > 100) : []]);
    }

    // ---- Modèles de reporting (Lot 22) ----
    /** Projets d'un rapport : hors abandonnés, avec statut de reporting, points clés, prochaine étape. */
    private function reportRows(?string $nature): array {
        $rows = array_values(array_filter($this->rows($nature ? ['nature' => $nature] : []), fn($r) => $r['status'] !== 'cancelled'));
        foreach ($rows as &$r) { [$r['keys'], $r['next']] = Pj::keyInfo($r); $r['rst'] = Pj::rstatus($r, $r['chealth']); } unset($r);
        return $rows;
    }
    private function asOf(): string { $d = (string)$this->in('date', ''); return preg_match('/^\d{4}-\d{2}-\d{2}$/', $d) ? $d : date('Y-m-d'); }
    /** « Key Projects – Status Update » : initiatives groupe, par pilier (modèle RAPPORT_PROJET). */
    function reportKey(): void {
        $d = $this->asOf(); $groups = []; foreach ($this->reportRows('group') as $r) $groups[$r['pillar']][] = $r;
        Audit::log('export', 'pj_report_key');
        $this->view('pj/report_key', ['title' => 'Key Projects CXO Q' . (int)ceil(date('n', strtotime($d)) / 3) . ' ' . date('Y', strtotime($d)) . ' – Status Update', 'groups' => $groups, 'date' => $d], 'layout/public');
    }
    /** « Suivi des projets CXO » : tout le portefeuille, groupe et pays (modèle Suivi_projets_CXO). */
    function reportPortfolio(): void {
        $d = $this->asOf(); $n = (string)$this->in('nature', ''); $n = isset(Pj::NATURE[$n]) ? $n : null; $rows = $this->reportRows($n);
        usort($rows, fn($a, $b) => [$a['nature'] === 'group' ? 0 : 1, $a['id']] <=> [$b['nature'] === 'group' ? 0 : 1, $b['id']]);
        $ym = date('Y-m', strtotime($d)); $due = []; foreach ($rows as $i => $r) if ($r['end_date'] && substr($r['end_date'], 0, 7) === $ym) $due[] = [$i + 1, $r];
        Audit::log('export', 'pj_report_portfolio');
        $this->view('pj/report_portfolio', ['title' => 'Suivi des projets CXO', 'rows' => $rows, 'date' => $d, 'nature' => $n, 'due' => $due], 'layout/public');
    }

    // ---- Roadmap ----
    private function roadmap(): array {
        $f = ['pillar_id' => (int)$this->in('pillar', 0) ?: null, 'status' => (string)$this->in('status', '') ?: null]; $months = in_array((int)$this->in('months', 12), [6, 12, 18, 24], true) ? (int)$this->in('months', 12) : 12;
        $m = (string)$this->in('from', ''); $from = preg_match('/^\d{4}-\d{2}$/', $m) ? $m . '-01' : date('Y-m-01', strtotime('-2 months'));
        $rows = array_values(array_filter($this->rows($f), fn($r) => $r['status'] !== 'cancelled' || $f['status'] === 'cancelled'));
        return [$rows, $from, $months, $f];
    }
    function roadmapPage(): void { [$rows, $from, $months, $f] = $this->roadmap(); $this->view('pj/roadmap', ['title' => 'Roadmap', 'rows' => $rows, 'from' => $from, 'months' => $months, 'f' => $f, 'pillars' => Pj::pillars(true)]); }
    function roadmapExport(): void {
        [$rows] = $this->roadmap(); $out = []; foreach ($rows as $r) $out[] = [$r['ref'], $r['title'], $r['pillar'], Pj::STATUS[$r['status']], Pj::PRIORITY[$r['priority']], $r['mgr'], $r['start_date'], $r['end_date'], $r['baseline_end'], Pj::slip($r) ?? '', $r['prog'], Pj::HEALTH[$r['chealth']], count($r['alerts'])];
        Audit::log('export', 'pj_roadmap'); csv_download('roadmap-' . date('Ymd') . '.csv', ['Réf.', 'Projet', 'Pilier', 'Statut', 'Priorité', 'Chef de projet', 'Début', 'Fin', 'Fin initiale', 'Glissement (j)', 'Avancement %', 'Santé', 'Alertes'], $out);
    }

    // ---- Projets ----
    function projects(): void {
        $f = ['pillar_id' => (int)$this->in('pillar', 0) ?: null, 'status' => (string)$this->in('status', '') ?: null, 'nature' => isset(Pj::NATURE[(string)$this->in('nature', '')]) ? (string)$this->in('nature') : null]; $this->view('pj/projects', ['title' => 'Projets', 'rows' => $this->rows($f), 'f' => $f, 'pillars' => Pj::pillars(true)]);
    }
    function newProject(): void { $this->view('pj/form', ['title' => 'Nouveau projet', 'p' => null, 'pillars' => Pj::pillars(), 'emps' => $this->emps(), 'lead' => null, 'sponsor' => null]); }
    private function fields(): ?array {
        $t = mb_substr(trim((string)$this->in('title', '')), 0, 200); $a = $this->date('start_date'); $b = $this->date('end_date'); $st = (string)$this->in('status', 'planned'); $pr = (string)$this->in('priority', 'normal'); $vi = (string)$this->in('visibility', 'all'); $h = (string)$this->in('health', 'green'); $pm = (string)$this->in('progress_mode', 'auto'); $pg = (int)$this->in('progress_pct', 0);
        if ($t === '' || ($a && $b && $b < $a) || !isset(Pj::STATUS[$st]) || !isset(Pj::PRIORITY[$pr]) || !in_array($vi, ['all', 'team'], true) || !isset(Pj::HEALTH[$h]) || !in_array($pm, ['auto', 'manual'], true) || $pg < 0 || $pg > 100) return null;
        $bud = str_replace(',', '.', trim((string)$this->in('budget', '')));
        return ['title' => $t, 'description' => mb_substr(trim((string)$this->in('description', '')), 0, 4000) ?: null, 'pillar_id' => (int)$this->in('pillar_id', 0) ?: null, 'status' => $st, 'priority' => $pr, 'visibility' => $vi, 'start_date' => $a, 'end_date' => $b, 'progress_mode' => $pm, 'progress_pct' => $pg, 'health' => $h,
            'objectives' => mb_substr(trim((string)$this->in('objectives', '')), 0, 2000) ?: null, 'benefits' => mb_substr(trim((string)$this->in('benefits', '')), 0, 2000) ?: null, 'budget' => is_numeric($bud) ? (float)$bud : null,
            'nature' => isset(Pj::NATURE[(string)$this->in('nature', '')]) ? (string)$this->in('nature') : 'local', 'stage' => mb_substr(trim((string)$this->in('stage', '')), 0, 60) ?: null, 'key_update' => mb_substr(trim((string)$this->in('key_update', '')), 0, 2000) ?: null, 'next_step' => mb_substr(trim((string)$this->in('next_step', '')), 0, 300) ?: null];
    }
    private function setLead(array $p, ?int $emp, ?int $dep, ?int $sponsor): void {
        $lead = DB::one('SELECT id FROM pj_roles WHERE is_lead=1 AND active=1 ORDER BY sort_order LIMIT 1'); $sp = DB::one("SELECT id FROM pj_roles WHERE code='SPONSOR' AND active=1");
        if ($lead && $emp) { DB::exec('DELETE FROM pj_members WHERE project_id=? AND role_id=?', [$p['id'], $lead['id']]); DB::insert('pj_members', ['project_id' => $p['id'], 'employee_id' => $emp, 'role_id' => $lead['id'], 'deputy_id' => $dep && $dep !== $emp ? $dep : null, 'allocation_pct' => 0]); }
        if ($sp && $sponsor) { DB::exec('DELETE FROM pj_members WHERE project_id=? AND role_id=?', [$p['id'], $sp['id']]); DB::insert('pj_members', ['project_id' => $p['id'], 'employee_id' => $sponsor, 'role_id' => $sp['id'], 'allocation_pct' => 0]); }
        DB::update('pj_projects', ['manager_id' => $emp ?: null, 'sponsor_id' => $sponsor ?: null], 'id=?', [$p['id']]);
    }
    function createProject(): void {
        $f = $this->fields(); if (!$f) { flash('Projet invalide : titre requis, dates cohérentes, valeurs reconnues.', 'danger'); redirect('pj/projects/new'); }
        $id = DB::insert('pj_projects', $f + ['ref' => Pj::ref(), 'baseline_end' => $f['end_date'], 'created_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()]); $p = Pj::project($id);
        $this->setLead($p, (int)$this->in('manager_id', 0) ?: null, (int)$this->in('manager_deputy_id', 0) ?: null, (int)$this->in('sponsor_id', 0) ?: null);
        Audit::log('create', 'pj_project', $id); flash('Projet créé.'); redirect('pj/projects/' . $id);
    }
    function show(string $id): void {
        if (!($p = $this->proj($id))) return; $r = $this->row($p); $lvl = Pj::level($p); $week = Pl::monday(date('Y-m-d'));
        $this->view('pj/show', ['title' => $p['ref'] . ' ' . $p['title'], 'p' => $r, 'lvl' => $lvl, 'members' => DB::all('SELECT m.*, r.name role, r.access, r.is_lead FROM pj_members m JOIN pj_roles r ON r.id=m.role_id WHERE m.project_id=? ORDER BY r.sort_order', [$p['id']]), 'roles' => Pj::roles(), 'emps' => $this->emps(), 'items' => DB::all("SELECT * FROM pj_items WHERE project_id=? ORDER BY status='open' DESC, created_at DESC", [$p['id']]),
            'deps' => DB::all('SELECT d.id, q.id pid, q.ref, q.title, q.end_date, q.status FROM pj_deps d JOIN pj_projects q ON q.id=d.depends_on_id WHERE d.project_id=?', [$p['id']]), 'others' => array_filter(Pj::visible(), fn($x) => (int)$x['id'] !== (int)$p['id']), 'reports' => DB::all('SELECT * FROM pj_reports WHERE project_id=? ORDER BY week_start DESC LIMIT 12', [$p['id']]), 'week' => $week, 'pillars' => Pj::pillars(), 'users' => []]);
    }
    function editProject(string $id): void {
        if (!($p = $this->proj($id, 'manage'))) return; $lead = DB::one('SELECT m.* FROM pj_members m JOIN pj_roles r ON r.id=m.role_id WHERE m.project_id=? AND r.is_lead=1 LIMIT 1', [$p['id']]);
        $this->view('pj/form', ['title' => 'Modifier ' . $p['ref'], 'p' => $p, 'pillars' => Pj::pillars(true), 'emps' => $this->emps(), 'lead' => $lead, 'sponsor' => (int)$p['sponsor_id']]);
    }
    function saveProject(string $id): void {
        if (!($p = $this->proj($id, 'manage'))) return; $f = $this->fields(); if (!$f) { flash('Projet invalide.', 'danger'); redirect('pj/projects/' . $p['id'] . '/edit'); }
        if ($f['end_date'] !== $p['end_date'] && $f['end_date'] && $p['end_date'] && !trim((string)$this->in('why', ''))) { flash('Précisez le motif du changement de date de fin (réplanification).', 'danger'); redirect('pj/projects/' . $p['id'] . '/edit'); }
        DB::update('pj_projects', $f + ['updated_at' => now()], 'id=?', [$p['id']]);
        if ($this->in('manager_id') !== null) $this->setLead($p, (int)$this->in('manager_id', 0) ?: null, (int)$this->in('manager_deputy_id', 0) ?: null, (int)$this->in('sponsor_id', 0) ?: null);
        Audit::log('update', 'pj_project', $id, $p, $f + ['why' => mb_substr((string)$this->in('why', ''), 0, 300)]); flash('Projet enregistré.'); $this->toProject($p);
    }
    function rebaseline(string $id): void { if (!($p = $this->proj($id, 'manage'))) return; DB::update('pj_projects', ['baseline_end' => $p['end_date']], 'id=?', [$p['id']]); DB::exec('UPDATE pj_milestones SET baseline_date=due_date WHERE project_id=?', [$p['id']]); Audit::log('rebaseline', 'pj_project', $id); flash('Nouvelle référence de planning enregistrée.'); $this->toProject($p); }
    function deleteProject(string $id): void {
        if (!can('pj.manage')) { $this->forbidden(); return; } if (!($p = $this->proj($id, 'manage'))) return; foreach (['pj_members', 'pj_milestones', 'pj_items', 'pj_reports'] as $t) DB::exec("DELETE FROM $t WHERE project_id=?", [$p['id']]); DB::exec('DELETE FROM pj_deps WHERE project_id=? OR depends_on_id=?', [$p['id'], $p['id']]); DB::exec('DELETE FROM pj_projects WHERE id=?', [$p['id']]);
        Audit::log('delete', 'pj_project', $id, $p); flash('Projet supprimé.'); redirect('pj/projects');
    }

    // ---- Équipe et suppléants ----
    function addMember(string $id): void {
        if (!($p = $this->proj($id, 'manage'))) return; $e = (int)$this->in('employee_id', 0); $r = (int)$this->in('role_id', 0); $d = (int)$this->in('deputy_id', 0) ?: null; $al = (int)$this->in('allocation_pct', 0);
        if (!DB::val('SELECT 1 FROM employees WHERE id=?', [$e]) || !DB::val('SELECT 1 FROM pj_roles WHERE id=? AND active=1', [$r]) || $al < 0 || $al > 100 || ($d && ($d === $e || !DB::val('SELECT 1 FROM employees WHERE id=?', [$d])))) { flash('Membre invalide (collaborateur, rôle actif, suppléant différent du titulaire, charge de 0 à 100 %).', 'danger'); $this->toProject($p, '#equipe'); return; }
        DB::exec('DELETE FROM pj_members WHERE project_id=? AND employee_id=? AND role_id=?', [$p['id'], $e, $r]); DB::insert('pj_members', ['project_id' => $p['id'], 'employee_id' => $e, 'role_id' => $r, 'deputy_id' => $d, 'allocation_pct' => $al]);
        if ($u = Pj::userOf($e)) Notifier::send($u, 'Vous êtes membre d\'un projet', $p['ref'] . ' ' . $p['title'], '/pj/projects/' . $p['id']); if ($d && ($u = Pj::userOf($d))) Notifier::send($u, 'Vous êtes suppléant sur un projet', $p['ref'] . ' ' . $p['title'], '/pj/projects/' . $p['id']);
        Audit::log('update', 'pj_member', $id, null, ['employee' => $e, 'role' => $r, 'deputy' => $d]); flash('Membre enregistré.'); $this->toProject($p, '#equipe');
    }
    function delMember(string $id, string $mid): void {
        if (!($p = $this->proj($id, 'manage'))) return; $m = DB::one('SELECT m.*, r.is_lead FROM pj_members m JOIN pj_roles r ON r.id=m.role_id WHERE m.id=? AND m.project_id=?', [(int)$mid, $p['id']]);
        if ($m) { DB::exec('DELETE FROM pj_members WHERE id=?', [(int)$mid]); if ($m['is_lead'] && (int)$p['manager_id'] === (int)$m['employee_id']) DB::update('pj_projects', ['manager_id' => null], 'id=?', [$p['id']]); Audit::log('delete', 'pj_member', $id, $m); } $this->toProject($p, '#equipe');
    }
    function copyTeam(string $id): void {
        if (!($p = $this->proj($id, 'manage'))) return; $src = Pj::project((int)$this->in('from', 0)); if (!$src || !Pj::level($src) || (int)$src['id'] === (int)$p['id']) { flash('Projet source invalide.', 'danger'); $this->toProject($p, '#equipe'); return; } $n = 0;
        foreach (DB::all('SELECT * FROM pj_members WHERE project_id=?', [$src['id']]) as $m) if (!DB::val('SELECT 1 FROM pj_members WHERE project_id=? AND employee_id=? AND role_id=?', [$p['id'], $m['employee_id'], $m['role_id']])) { DB::insert('pj_members', ['project_id' => $p['id'], 'employee_id' => $m['employee_id'], 'role_id' => $m['role_id'], 'deputy_id' => $m['deputy_id'], 'allocation_pct' => $m['allocation_pct']]); $n++; }
        Audit::log('copy', 'pj_team', $id, null, ['from' => $src['id'], 'n' => $n]); flash("$n membre(s) copié(s) depuis " . $src['ref'] . '.'); $this->toProject($p, '#equipe');
    }

    // ---- Jalons ----
    function addMilestone(string $id): void {
        if (!($p = $this->proj($id, 'contribute'))) return; $t = mb_substr(trim((string)$this->in('title', '')), 0, 200); $d = $this->date('due_date'); $w = max(1, min(10, (int)$this->in('weight', 1)));
        if ($t === '' || !$d) { flash('Jalon invalide : titre et date requis.', 'danger'); $this->toProject($p, '#jalons'); return; }
        DB::insert('pj_milestones', ['project_id' => $p['id'], 'title' => $t, 'due_date' => $d, 'baseline_date' => $d, 'weight' => $w, 'status' => 'todo', 'owner_id' => (int)$this->in('owner_id', 0) ?: null]); Audit::log('create', 'pj_milestone', $id, null, ['title' => $t]); $this->toProject($p, '#jalons');
    }
    private function ms(array $p, string $mid): ?array { $m = DB::one('SELECT * FROM pj_milestones WHERE id=? AND project_id=?', [(int)$mid, $p['id']]); if (!$m) $this->notFound(); return $m; }
    function toggleMilestone(string $id, string $mid): void {
        if (!($p = $this->proj($id, 'contribute')) || !($m = $this->ms($p, $mid))) return; $done = $m['status'] !== 'done';
        DB::update('pj_milestones', ['status' => $done ? 'done' : 'todo', 'done_at' => $done ? now() : null], 'id=?', [$m['id']]); Audit::log('update', 'pj_milestone', $id, null, ['milestone' => $m['title'], 'done' => $done]); $this->toProject($p, '#jalons');
    }
    function moveMilestone(string $id, string $mid): void {
        if (!($p = $this->proj($id, 'contribute')) || !($m = $this->ms($p, $mid))) return; $d = $this->date('due_date'); if (!$d) { flash('Date invalide.', 'danger'); $this->toProject($p, '#jalons'); return; }
        DB::update('pj_milestones', ['due_date' => $d, 'note' => mb_substr(trim((string)$this->in('note', '')), 0, 500) ?: $m['note']], 'id=?', [$m['id']]); Audit::log('update', 'pj_milestone', $id, ['due' => $m['due_date']], ['due' => $d]); flash('Jalon replanifié (la date initiale est conservée pour mesurer le glissement).'); $this->toProject($p, '#jalons');
    }
    function delMilestone(string $id, string $mid): void { if (!($p = $this->proj($id, 'manage')) || !($m = $this->ms($p, $mid))) return; DB::exec('DELETE FROM pj_milestones WHERE id=?', [$m['id']]); Audit::log('delete', 'pj_milestone', $id, $m); $this->toProject($p, '#jalons'); }

    // ---- Blocages, risques, décisions, actions ----
    function addItem(string $id): void {
        if (!($p = $this->proj($id, 'contribute'))) return; $ty = (string)$this->in('type', ''); $t = mb_substr(trim((string)$this->in('title', '')), 0, 200); $sev = (string)$this->in('severity', 'medium');
        if (!isset(Pj::TYPE[$ty]) || $t === '' || !in_array($sev, ['low', 'medium', 'high'], true)) { flash('Point invalide : type et titre requis.', 'danger'); $this->toProject($p, '#points'); return; }
        DB::insert('pj_items', ['project_id' => $p['id'], 'type' => $ty, 'title' => $t, 'description' => mb_substr(trim((string)$this->in('description', '')), 0, 2000) ?: null, 'severity' => $sev, 'owner_id' => (int)$this->in('owner_id', 0) ?: null, 'due_date' => $this->date('due_date'), 'status' => 'open', 'solution' => mb_substr(trim((string)$this->in('solution', '')), 0, 2000) ?: null, 'created_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()]);
        if ($ty === 'blocker' && $sev === 'high') { Pj::notify($p, 'Point bloquant critique', $p['ref'] . ' · ' . $t, 'manage'); Notifier::toPermission('pj.manage', 'Point bloquant critique', $p['ref'] . ' · ' . $t, '/pj/projects/' . $p['id']); }
        Audit::log('create', 'pj_item', $id, null, ['type' => $ty, 'title' => $t]); flash(Pj::TYPE[$ty] . ' ajouté.'); $this->toProject($p, '#points');
    }
    function updateItem(string $id, string $iid): void {
        if (!($p = $this->proj($id, 'contribute'))) return; $i = DB::one('SELECT * FROM pj_items WHERE id=? AND project_id=?', [(int)$iid, $p['id']]); if (!$i) { $this->notFound(); return; }
        $st = (string)$this->in('status', $i['status']); $sol = mb_substr(trim((string)$this->in('solution', (string)$i['solution'])), 0, 2000) ?: null; $dec = mb_substr(trim((string)$this->in('decision', (string)$i['decision'])), 0, 2000) ?: null;
        if (!in_array($st, ['open', 'resolved', 'closed'], true)) { flash('Statut invalide.', 'danger'); $this->toProject($p, '#points'); return; }
        if ($i['type'] === 'decision' && $st !== 'open' && !$dec) { flash('Consignez la décision prise avant de la clore.', 'danger'); $this->toProject($p, '#points'); return; }
        if ($i['type'] === 'blocker' && $st === 'resolved' && !$sol) { flash('Indiquez la solution apportée.', 'danger'); $this->toProject($p, '#points'); return; }
        DB::update('pj_items', ['status' => $st, 'solution' => $sol, 'decision' => $dec, 'decided_by' => $dec && !$i['decision'] ? Pj::me() ?: null : $i['decided_by'], 'decided_at' => $dec && !$i['decision'] ? now() : $i['decided_at'], 'resolved_at' => $st === 'open' ? null : ($i['resolved_at'] ?: now()), 'updated_at' => now()], 'id=?', [$i['id']]);
        Audit::log('update', 'pj_item', $iid, ['status' => $i['status']], ['status' => $st]); flash('Point mis à jour.'); $this->toProject($p, '#points');
    }
    function delItem(string $id, string $iid): void { if (!($p = $this->proj($id, 'manage'))) return; DB::exec('DELETE FROM pj_items WHERE id=? AND project_id=?', [(int)$iid, $p['id']]); Audit::log('delete', 'pj_item', $iid); $this->toProject($p, '#points'); }
    function addDep(string $id): void {
        if (!($p = $this->proj($id, 'manage'))) return; $q = Pj::project((int)$this->in('depends_on_id', 0));
        if (!$q || (int)$q['id'] === (int)$p['id'] || DB::val('SELECT 1 FROM pj_deps WHERE project_id=? AND depends_on_id=?', [$p['id'], $q['id']]) || DB::val('SELECT 1 FROM pj_deps WHERE project_id=? AND depends_on_id=?', [$q['id'], $p['id']])) { flash('Dépendance invalide (déjà présente, circulaire ou projet inconnu).', 'danger'); $this->toProject($p, '#deps'); return; }
        DB::insert('pj_deps', ['project_id' => $p['id'], 'depends_on_id' => $q['id']]); $this->toProject($p, '#deps');
    }
    function delDep(string $id, string $did): void { if (!($p = $this->proj($id, 'manage'))) return; DB::exec('DELETE FROM pj_deps WHERE id=? AND project_id=?', [(int)$did, $p['id']]); $this->toProject($p, '#deps'); }

    // ---- Point hebdomadaire d'un projet ----
    function report(string $id): void {
        if (!($p = $this->proj($id))) return; $w = $this->week(); $r = Pj::can($p, 'contribute') && $w === Pl::monday(date('Y-m-d')) ? Pj::draft($p, $w) : Pj::report($p['id'], $w);
        $this->view('pj/report', ['title' => 'Point hebdomadaire · ' . $p['ref'], 'p' => $this->row($p), 'r' => $r, 'week' => $w, 'canEdit' => Pj::can($p, 'contribute'), 'canReopen' => Pj::can($p, 'manage'), 'blockers' => Pj::openItems($p['id'], 'blocker'), 'decisions' => Pj::openItems($p['id'], 'decision'), 'risks' => Pj::openItems($p['id'], 'risk'), 'frozen' => $r && $r['auto_data'] ? json_decode($r['auto_data'], true) : null]);
    }
    function saveReport(string $id): void {
        if (!($p = $this->proj($id, 'contribute'))) return; $w = $this->week(); $r = Pj::draft($p, $w); $act = (string)$this->in('act', 'save');
        if ($act === 'reopen') { if (!Pj::can($p, 'manage')) { $this->forbidden(); return; } DB::update('pj_reports', ['status' => 'draft', 'updated_at' => now()], 'id=?', [$r['id']]); flash('Point rouvert.'); redirect('pj/projects/' . $p['id'] . '/report?week=' . $w); }
        if ($r['status'] === 'submitted') { flash('Point déjà transmis : demandez sa réouverture au PMO.', 'warning'); redirect('pj/projects/' . $p['id'] . '/report?week=' . $w); }
        $h = (string)$this->in('health', 'green'); $pg = (int)$this->in('progress_pct', 0); $sum = trim((string)$this->in('summary', ''));
        if (!isset(Pj::HEALTH[$h]) || $pg < 0 || $pg > 100) { flash('Santé ou avancement invalide.', 'danger'); redirect('pj/projects/' . $p['id'] . '/report?week=' . $w); }
        if ($act === 'submit' && ($sum === '' || ($h !== 'green' && !trim((string)$this->in('summary', ''))))) { flash('Renseignez la synthèse avant de transmettre.', 'danger'); redirect('pj/projects/' . $p['id'] . '/report?week=' . $w); }
        $d = ['health' => $h, 'progress_pct' => $pg, 'summary' => mb_substr($sum, 0, 3000) ?: null, 'achievements' => mb_substr(trim((string)$this->in('achievements', '')), 0, 3000) ?: null, 'next_steps' => mb_substr(trim((string)$this->in('next_steps', '')), 0, 3000) ?: null, 'author_id' => Auth::id(), 'updated_at' => now()];
        if ($act === 'submit') { $d += ['status' => 'submitted', 'submitted_at' => now(), 'auto_data' => Pj::freeze($p)]; DB::update('pj_projects', ['health' => $h, 'progress_pct' => $p['progress_mode'] === 'manual' ? $pg : $p['progress_pct'], 'updated_at' => now()], 'id=?', [$p['id']]); }
        DB::update('pj_reports', $d, 'id=?', [$r['id']]);
        if ($act === 'submit') { if ($h !== 'green') Notifier::toPermission('pj.manage', 'Projet ' . mb_strtolower(Pj::HEALTH[$h]) . ' : ' . $p['ref'], $p['title'] . ' — ' . mb_substr($sum, 0, 140), '/pj/projects/' . $p['id'] . '/report?week=' . $w); Audit::log('submit', 'pj_report', $r['id']); flash('Point hebdomadaire transmis.'); } else flash('Brouillon enregistré.');
        redirect('pj/projects/' . $p['id'] . '/report?week=' . $w);
    }

    // ---- Reporting hebdomadaire du portefeuille ----
    private function weekly(string $w): array {
        $out = []; foreach ($this->rows() as $r) { if (!in_array($r['status'], ['active', 'on_hold', 'planned'], true)) continue; $rep = Pj::report($r['id'], $w); $fz = $rep && $rep['auto_data'] ? json_decode($rep['auto_data'], true) : null;
            $items = $rep && $rep['status'] === 'submitted' && $fz ? $fz['items'] : array_map(fn($i) => ['type' => $i['type'], 'title' => $i['title'], 'severity' => $i['severity'], 'solution' => $i['solution'], 'due' => $i['due_date']], Pj::openItems($r['id']));
            $out[$r['pillar']][] = $r + ['rep' => $rep, 'pitems' => $items]; }
        return $out;
    }
    function weeklyPage(): void { $w = $this->week(); $this->view('pj/weekly', ['title' => 'Reporting hebdomadaire', 'week' => $w, 'groups' => $this->weekly($w)]); }
    function weeklyPrint(): void { $w = $this->week(); $this->view('pj/weekly_print', ['title' => 'Reporting hebdomadaire — semaine du ' . date('d/m/Y', strtotime($w)), 'week' => $w, 'groups' => $this->weekly($w)], 'layout/public'); }
    function weeklyExport(): void {
        $w = $this->week(); $out = []; foreach ($this->weekly($w) as $pil => $list) foreach ($list as $r) { $rep = $r['rep']; $bl = array_filter($r['pitems'], fn($i) => $i['type'] === 'blocker'); $dc = array_filter($r['pitems'], fn($i) => $i['type'] === 'decision');
            $out[] = [$pil, $r['ref'], $r['title'], $r['mgr'], Pj::STATUS[$r['status']], $rep && $rep['status'] === 'submitted' ? Pj::HEALTH[$rep['health']] : Pj::HEALTH[$r['chealth']] . ' (calculée)', $rep ? $rep['progress_pct'] : $r['prog'], $rep ? ($rep['status'] === 'submitted' ? 'Transmis' : 'Brouillon') : 'Non établi', $rep['summary'] ?? '', implode(' | ', array_map(fn($i) => $i['title'] . ($i['solution'] ? ' → ' . $i['solution'] : ''), $bl)), implode(' | ', array_column($dc, 'title')), implode(' | ', array_map(fn($a) => $a[2], $r['alerts']))]; }
        Audit::log('export', 'pj_weekly'); csv_download("reporting-projets-$w.csv", ['Pilier', 'Réf.', 'Projet', 'Chef de projet', 'Statut', 'Santé', 'Avancement %', 'Point hebdo', 'Synthèse', 'Blocages → solutions', 'Décisions en attente', 'Alertes'], $out);
    }

    // ---- Registre : décisions, blocages, risques, actions ----
    private function registry(): array {
        $ty = (string)$this->in('type', ''); $st = (string)$this->in('status', ''); $vis = array_column(Pj::visible(), null, 'id'); $o = [];
        foreach (DB::all('SELECT * FROM pj_items ORDER BY created_at DESC') as $i) { if (!isset($vis[$i['project_id']]) || ($ty && $i['type'] !== $ty) || ($st && $i['status'] !== $st)) continue; $o[] = $i + ['proj' => $vis[$i['project_id']]]; } return [$o, $ty, $st];
    }
    function decisions(): void { [$rows, $ty, $st] = $this->registry(); $this->view('pj/decisions', ['title' => 'Décisions, blocages et risques', 'rows' => $rows, 'ty' => $ty, 'st' => $st]); }
    function decisionsExport(): void {
        [$rows] = $this->registry(); $out = array_map(fn($i) => [$i['proj']['ref'], $i['proj']['title'], Pj::TYPE[$i['type']], $i['title'], $i['severity'], $i['status'], $i['solution'] ?? '', $i['decision'] ?? '', $i['due_date'] ?? '', substr($i['created_at'], 0, 10)], $rows);
        Audit::log('export', 'pj_registry'); csv_download('registre-projets-' . date('Ymd') . '.csv', ['Réf.', 'Projet', 'Type', 'Intitulé', 'Gravité', 'Statut', 'Solution', 'Décision', 'Échéance', 'Créé le'], $out);
    }

    // ---- Instantanés ----
    function snapshots(): void {
        $list = DB::all('SELECT id, label, kind, created_at FROM pj_snapshots ORDER BY id DESC LIMIT 60'); $a = (int)$this->in('a', 0); $b = (int)$this->in('b', 0); $diff = null; $la = $lb = '';
        if ($a) { $sa = DB::one('SELECT * FROM pj_snapshots WHERE id=?', [$a]); $sb = $b ? DB::one('SELECT * FROM pj_snapshots WHERE id=?', [$b]) : null; if ($sa) { $diff = Pj::diff(json_decode($sa['data'], true) ?: [], $sb ? (json_decode($sb['data'], true) ?: []) : Pj::snapshotData()); $la = $sa['label'] . ' (' . substr($sa['created_at'], 0, 10) . ')'; $lb = $sb ? $sb['label'] . ' (' . substr($sb['created_at'], 0, 10) . ')' : 'Roadmap actuelle'; } }
        $this->view('pj/snapshots', ['title' => 'Instantanés de roadmap', 'list' => $list, 'a' => $a, 'b' => $b, 'diff' => $diff, 'la' => $la, 'lb' => $lb]);
    }
    function createSnapshot(): void { $l = mb_substr(trim((string)$this->in('label', '')), 0, 150) ?: 'Instantané du ' . date('d/m/Y'); $id = Pj::snapshot($l, 'manual', Auth::id()); Audit::log('create', 'pj_snapshot', $id); flash('Instantané enregistré.'); redirect('pj/snapshots'); }

    // ---- Partage et abonnements ----
    function share(): void {
        $this->view('pj/share', ['title' => 'Partage et abonnements', 'shares' => can('pj.manage') ? DB::all('SELECT * FROM pj_shares ORDER BY id DESC LIMIT 30') : [], 'pillars' => Pj::pillars(true), 'mine' => DB::all('SELECT * FROM pj_subscribers WHERE user_id=?', [Auth::id()]), 'subs' => can('pj.manage') ? DB::all('SELECT s.*, u.name FROM pj_subscribers s JOIN users u ON u.id=s.user_id ORDER BY u.name') : [], 'users' => can('pj.manage') ? DB::all("SELECT id, name FROM users WHERE status='active' ORDER BY name") : [], 'last' => DB::val("SELECT MAX(created_at) FROM pj_snapshots WHERE kind='weekly'")]);
    }
    function createShare(): void {
        $t = mb_substr(trim((string)$this->in('title', '')), 0, 150) ?: 'Roadmap des projets'; $exp = $this->date('expires_at'); $pil = (int)$this->in('pillar_id', 0) ?: null; if ($exp && $exp < date('Y-m-d')) { flash('Date d\'expiration passée.', 'danger'); redirect('pj/share'); }
        $id = DB::insert('pj_shares', ['token' => bin2hex(random_bytes(16)), 'title' => $t, 'pillar_id' => $pil, 'expires_at' => $exp, 'revoked' => 0, 'created_by' => Auth::id(), 'created_at' => now()]); Audit::log('create', 'pj_share', $id); flash('Lien de partage créé.'); redirect('pj/share');
    }
    function revokeShare(string $id): void { DB::update('pj_shares', ['revoked' => 1], 'id=?', [(int)$id]); Audit::log('revoke', 'pj_share', $id); flash('Lien révoqué.'); redirect('pj/share'); }
    function subscribe(): void {
        $kind = in_array((string)$this->in('kind', 'staff'), ['staff', 'stakeholder'], true) ? (string)$this->in('kind', 'staff') : 'staff'; $fr = in_array((string)$this->in('frequency', 'weekly'), ['weekly', 'monthly'], true) ? (string)$this->in('frequency', 'weekly') : 'weekly'; $pil = (int)$this->in('pillar_id', 0) ?: null; $uid = Auth::id();
        if (can('pj.manage') && (int)$this->in('user_id', 0)) $uid = (int)$this->in('user_id', 0);
        if (!DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$uid])) { flash('Utilisateur inconnu.', 'danger'); redirect('pj/share'); }
        DB::exec('DELETE FROM pj_subscribers WHERE user_id=? AND ' . ($pil ? 'pillar_id=?' : 'pillar_id IS NULL'), $pil ? [$uid, $pil] : [$uid]); DB::insert('pj_subscribers', ['user_id' => $uid, 'kind' => $kind, 'pillar_id' => $pil, 'frequency' => $fr]); flash('Abonnement enregistré.'); redirect('pj/share');
    }
    function unsubscribe(string $id): void { $s = DB::one('SELECT * FROM pj_subscribers WHERE id=?', [(int)$id]); if ($s && ((int)$s['user_id'] === Auth::id() || can('pj.manage'))) DB::exec('DELETE FROM pj_subscribers WHERE id=?', [(int)$id]); redirect('pj/share'); }
    /** Vue publique en lecture seule, sans connexion : projets visibles de tous uniquement, sans nom ni détail interne. */
    function publicView(string $token): void {
        $s = DB::one('SELECT * FROM pj_shares WHERE token=? AND revoked=0', [$token]); if (!$s || ($s['expires_at'] && $s['expires_at'] < date('Y-m-d'))) { $this->notFound(); return; }
        $rows = []; foreach (DB::all("SELECT * FROM pj_projects WHERE visibility='all' AND status<>'cancelled'" . ($s['pillar_id'] ? ' AND pillar_id=' . (int)$s['pillar_id'] : '') . ' ORDER BY pillar_id, start_date, id') as $p) { $r = $this->row($p); $r['mgr'] = ''; $r['alerts'] = []; $rows[] = $r; }
        $snap = DB::one("SELECT * FROM pj_snapshots WHERE kind='weekly' ORDER BY id DESC LIMIT 1"); $ok = array_flip(array_column($rows, 'id')); $flt = fn($a) => array_values(array_filter($a, fn($x) => isset($ok[$x['id']]))); $diff = $snap ? array_values(array_filter(Pj::diff($flt(json_decode($snap['data'], true) ?: []), $flt(Pj::snapshotData())), fn($l) => !str_contains($l, 'santé'))) : [];
        $this->view('pj/public', ['title' => $s['title'], 's' => $s, 'rows' => $rows, 'from' => date('Y-m-01', strtotime('-2 months')), 'months' => 12, 'diff' => $diff, 'since' => $snap['created_at'] ?? null], 'layout/public');
    }

    // ---- Configuration : piliers et rôles ----
    function config(): void { $this->view('pj/config', ['title' => 'Piliers et rôles', 'pillars' => Pj::pillars(true), 'roles' => Pj::roles(true), 'emps' => $this->emps(), 'count' => array_column(DB::all('SELECT pillar_id, COUNT(*) n FROM pj_projects GROUP BY pillar_id'), 'n', 'pillar_id'), 'rcount' => array_column(DB::all('SELECT role_id, COUNT(*) n FROM pj_members GROUP BY role_id'), 'n', 'role_id')]); }
    function savePillar(string $id = ''): void {
        $code = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string)$this->in('code', ''))); $name = mb_substr(trim((string)$this->in('name', '')), 0, 120); $col = (string)$this->in('color', '#003A84');
        $x = $id ? DB::one('SELECT * FROM pj_pillars WHERE id=?', [(int)$id]) : null; if (($id && !$x) || $code === '' || $name === '' || !preg_match('/^#[0-9A-Fa-f]{6}$/', $col) || DB::val('SELECT 1 FROM pj_pillars WHERE code=?' . ($x ? ' AND id<>' . (int)$x['id'] : ''), [$code])) { flash('Pilier invalide ou code déjà utilisé.', 'danger'); redirect('pj/config'); }
        $d = ['code' => $code, 'name' => $name, 'color' => $col, 'description' => mb_substr(trim((string)$this->in('description', '')), 0, 500) ?: null, 'owner_id' => (int)$this->in('owner_id', 0) ?: null, 'sort_order' => (int)$this->in('sort_order', 0), 'active' => $this->in('active') === '1' || !$x ? 1 : 0];
        if ($x) DB::update('pj_pillars', $d, 'id=?', [$x['id']]); else DB::insert('pj_pillars', $d); Audit::log($x ? 'update' : 'create', 'pj_pillar', $id ?: null, $x, $d); flash('Pilier enregistré.'); redirect('pj/config');
    }
    function saveRole(string $id = ''): void {
        $code = strtoupper(preg_replace('/[^A-Za-z0-9_-]/', '', (string)$this->in('code', ''))); $name = mb_substr(trim((string)$this->in('name', '')), 0, 120); $ac = (string)$this->in('access', 'contribute');
        $x = $id ? DB::one('SELECT * FROM pj_roles WHERE id=?', [(int)$id]) : null; if (($id && !$x) || $code === '' || $name === '' || !isset(Pj::ACCESS[$ac]) || DB::val('SELECT 1 FROM pj_roles WHERE code=?' . ($x ? ' AND id<>' . (int)$x['id'] : ''), [$code])) { flash('Rôle invalide ou code déjà utilisé.', 'danger'); redirect('pj/config'); }
        $d = ['code' => $code, 'name' => $name, 'access' => $ac, 'is_lead' => $this->in('is_lead') === '1' ? 1 : 0, 'sort_order' => (int)$this->in('sort_order', 0), 'active' => $this->in('active') === '1' || !$x ? 1 : 0];
        if ($x && !$d['active'] && $x['is_lead'] && !DB::val('SELECT 1 FROM pj_roles WHERE is_lead=1 AND active=1 AND id<>?', [$x['id']])) { flash('Il faut au moins un rôle de chef de projet actif.', 'danger'); redirect('pj/config'); }
        if ($x) DB::update('pj_roles', $d, 'id=?', [$x['id']]); else DB::insert('pj_roles', $d); Audit::log($x ? 'update' : 'create', 'pj_role', $id ?: null, $x, $d); flash('Rôle enregistré.'); redirect('pj/config');
    }
}
