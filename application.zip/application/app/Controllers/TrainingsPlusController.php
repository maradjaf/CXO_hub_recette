<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Notifier, Tr, Org, Cert};

/** Formation (lot 25) : sessions à créneaux, formateurs, inscriptions en masse, évaluations à chaud/à froid, rapports, certificats. */
class TrainingsPlusController extends Controller {
    private function emps(): array { return DB::all("SELECT id, first_name, last_name, matricule FROM employees WHERE status='active' ORDER BY last_name, first_name"); }
    private function uid(?int $emp): ?int { $u = $emp ? DB::val("SELECT id FROM users WHERE employee_id=? AND status='active'", [$emp]) : null; return $u ? (int)$u : null; }
    private function me(): int { return (int)(Auth::user()['employee_id'] ?? 0); }

    // ───────── Sessions ─────────
    function newSession(string $id): void {
        $t = DB::one('SELECT * FROM trainings WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return; }
        $this->view('training/session_new', ['title' => 'Planifier une session : ' . $t['title'], 't' => $t, 'emps' => $this->emps(), 'forms' => DB::all('SELECT id, kind, name FROM tr_eval_forms WHERE active=1 AND kind IN (\'hot\',\'cold\') ORDER BY kind, name')]);
    }
    function storeSession(string $id): void {
        $t = DB::one('SELECT * FROM trainings WHERE id=?', [(int)$id]); if (!$t) { $this->notFound(); return; }
        $dates = array_values(array_unique(array_filter(array_map('trim', (array)($_POST['dates'] ?? [])), fn($x) => preg_match('/^\d{4}-\d{2}-\d{2}$/', $x) && strtotime($x)))); sort($dates);
        $slots = []; $ok = fn($a, $b) => preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $a) && preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $b) && $a < $b;
        foreach ((array)($_POST['slots'] ?? []) as $x) { [$a, $b] = array_pad(explode('-', (string)$x, 2), 2, ''); if ($ok($a, $b)) $slots[$a . '-' . $b] = [$a, $b]; }
        foreach ((array)($_POST['cs_start'] ?? []) as $i => $a) { $b = (string)($_POST['cs_end'][$i] ?? ''); if ($a !== '' && $ok((string)$a, $b)) $slots[$a . '-' . $b] = [$a, $b]; }
        $err = []; if (!$dates) $err['dates'] = 'Choisissez au moins une date.'; if (!$slots) $err['slots'] = 'Cochez au moins un créneau horaire (ou saisissez un créneau personnalisé valide).';
        $p1 = (int)($_POST['trainer_emp_id'] ?? 0) ?: null; $p2 = (int)($_POST['backup_emp_id'] ?? 0) ?: null;
        if ($p1 && $p1 === $p2) $err['backup_emp_id'] = 'Le suppléant doit être différent du formateur principal.';
        foreach (['trainer_emp_id' => $p1, 'backup_emp_id' => $p2] as $f => $v) if ($v && !DB::val("SELECT 1 FROM employees WHERE id=? AND status='active'", [$v])) $err[$f] = 'Collaborateur inconnu.';
        if ($err) { $_SESSION['_old'] = $_POST; $_SESSION['_ferr'] = $err; flash(implode(' ', $err), 'danger'); redirect("trainings/$id/sessions/new"); }
        $sid = DB::insert('training_sessions', ['training_id' => (int)$id, 'session_date' => $dates[0], 'end_date' => end($dates), 'label' => mb_substr(trim((string)($_POST['label'] ?? '')), 0, 100) ?: null, 'mode' => in_array($_POST['mode'] ?? '', ['presentiel', 'distanciel', 'hybride'], true) ? $_POST['mode'] : 'presentiel',
            'location' => mb_substr(trim((string)($_POST['location'] ?? '')), 0, 150) ?: null, 'trainer' => '', 'trainer_emp_id' => $p1, 'backup_emp_id' => $p2, 'trainer_unavailable' => 0, 'capacity' => max(0, (int)($_POST['capacity'] ?? 0)) ?: null, 'status' => 'planned', 'created_by' => Auth::id(), 'created_at' => now()]);
        foreach ($dates as $d) foreach ($slots as [$a, $b]) DB::insert('training_slots', ['session_id' => $sid, 'slot_date' => $d, 'start_time' => $a, 'end_time' => $b]);
        foreach ([$p1 => 'principal', $p2 => 'suppléant'] as $e => $r) if ($e && ($u = $this->uid((int)$e))) Notifier::send($u, 'Vous êtes formateur ' . $r, $t['title'] . ' · ' . Tr::when(['id' => $sid, 'session_date' => $dates[0]]), '/trainings/sessions/' . $sid);
        $last = end($dates); $df = Tr::planDefaults($sid, $last);
        foreach (['hot', 'cold'] as $k) if (!empty($_POST['plan_' . $k]) && $df[$k]['form']) { $on = (string)($_POST[$k . '_on'] ?? ''); $on = preg_match('/^\d{4}-\d{2}-\d{2}$/', $on) ? $on : $df[$k]['send_on'];
            DB::insert('tr_eval_plans', ['session_id' => $sid, 'kind' => $k, 'form_id' => (int)($_POST[$k . '_form'] ?? 0) ?: $df[$k]['form'], 'send_on' => $on, 'due_on' => date('Y-m-d', strtotime($on . ($k === 'hot' ? ' +7 days' : ' +14 days'))), 'status' => 'planned', 'created_by' => Auth::id(), 'created_at' => now()]); }
        \App\Core\Sat::ensureSession((int)$sid);
        Audit::log('create', 'training_session', $sid, null, ['dates' => $dates, 'slots' => array_keys($slots)]); flash('Session planifiée : ' . count($dates) . ' jour(s) × ' . count($slots) . ' créneau(x).'); redirect("trainings/sessions/$sid");
    }
    /** Formateur principal / suppléant ; l'indisponibilité du principal fait intervenir le suppléant. */
    function trainers(string $sid): void {
        $s = DB::one('SELECT s.*, t.title FROM training_sessions s JOIN trainings t ON t.id=s.training_id WHERE s.id=?', [(int)$sid]); if (!$s) { $this->notFound(); return; }
        $p1 = (int)($_POST['trainer_emp_id'] ?? 0) ?: null; $p2 = (int)($_POST['backup_emp_id'] ?? 0) ?: null; $un = !empty($_POST['unavailable']) ? 1 : 0;
        if ($p1 && $p1 === $p2) { flash('Le suppléant doit être différent du formateur principal.', 'danger'); redirect("trainings/sessions/$sid"); }
        if ($un && !$p2) { flash('Désignez un suppléant avant de déclarer le principal indisponible.', 'danger'); redirect("trainings/sessions/$sid"); }
        DB::update('training_sessions', ['trainer_emp_id' => $p1, 'backup_emp_id' => $p2, 'trainer_unavailable' => $un, 'unavail_reason' => $un ? mb_substr(trim((string)($_POST['reason'] ?? '')), 0, 200) : null], 'id=?', [(int)$sid]);
        $new = $s['trainer_unavailable'] != $un && $un; if ($new && ($u = $this->uid($p2))) Notifier::send($u, 'Vous intervenez en remplacement', $s['title'] . ' · ' . Tr::when($s), '/trainings/sessions/' . $sid);
        Audit::log('trainers', 'training_session', $sid, $s, ['principal' => $p1, 'suppleant' => $p2, 'indisponible' => $un]); flash($un ? 'Le suppléant intervient à la place du formateur principal.' : 'Formateurs enregistrés.'); redirect("trainings/sessions/$sid");
    }

    // ───────── Inscriptions en masse ─────────
    /** Personnel des activités / canaux choisis (JSON) pour l'écran d'inscription. */
    function people(): void {
        if (!can('training.manage') && !can('elearn.assign')) { http_response_code(403); exit; }
        $rows = Tr::people(array_map('intval', (array)$this->in('units', [])), array_map('intval', (array)$this->in('channels', [])));
        header('Content-Type: application/json; charset=utf-8'); echo json_encode(array_map(fn($r) => ['id' => (int)$r['id'], 'name' => $r['last_name'] . ' ' . $r['first_name'], 'matricule' => $r['matricule'], 'unit' => (string)$r['unit_name'], 'channel' => (string)$r['channel_name']], $rows), JSON_UNESCAPED_UNICODE); exit;
    }
    function bulkEnroll(string $sid): void {
        $s = DB::one('SELECT s.*, t.title FROM training_sessions s JOIN trainings t ON t.id=s.training_id WHERE s.id=?', [(int)$sid]); if (!$s) { $this->notFound(); return; }
        if ($s['status'] !== 'planned') { flash('Cette session n\'accepte plus d\'inscriptions.', 'warning'); redirect("trainings/sessions/$sid"); }
        [$ids, $excl, $err] = Tr::parseBulk($_POST); if ($err) { flash(implode(' ', array_slice($err, 0, 4)) . (count($err) > 4 ? ' …' : ''), 'danger'); redirect("trainings/sessions/$sid"); }
        $n = 0; $dup = 0; $full = false;
        foreach ($ids as $e) {
            if (!DB::val("SELECT 1 FROM employees WHERE id=? AND status='active'", [$e])) continue; if (DB::val('SELECT 1 FROM training_enrollments WHERE session_id=? AND employee_id=?', [(int)$sid, $e])) { $dup++; continue; }
            if ($s['capacity'] && (int)DB::val('SELECT COUNT(*) FROM training_enrollments WHERE session_id=?', [(int)$sid]) >= (int)$s['capacity']) { $full = true; break; }
            DB::insert('training_enrollments', ['session_id' => (int)$sid, 'employee_id' => $e, 'status' => 'registered']); $n++;
            if ($u = $this->uid($e)) Notifier::send($u, 'Inscription à une formation', $s['title'] . ' · ' . Tr::when($s), '/trainings/sessions/' . $sid);
        }
        foreach ($excl as $e => $why) { DB::exec("DELETE FROM enroll_exclusions WHERE ref_type='session' AND ref_id=? AND employee_id=?", [(int)$sid, $e]); DB::insert('enroll_exclusions', ['ref_type' => 'session', 'ref_id' => (int)$sid, 'employee_id' => $e, 'reason' => $why, 'by_user' => Auth::id(), 'created_at' => now()]); }
        Audit::log('enroll', 'training_session', $sid, null, ['added' => $n, 'excluded' => count($excl)]);
        flash("$n inscription(s)" . ($dup ? ", $dup déjà inscrit(s)" : '') . (count($excl) ? ', ' . count($excl) . ' exclu(s) avec justification' : '') . '.' . ($full ? ' Capacité atteinte.' : ''), $full ? 'warning' : 'success'); redirect("trainings/sessions/$sid");
    }

    // ───────── Évaluations à chaud / à froid ─────────
    function planCreate(string $sid): void {
        $s = DB::one('SELECT * FROM training_sessions WHERE id=?', [(int)$sid]); if (!$s) { $this->notFound(); return; }
        $k = (string)$this->in('kind'); $f = (int)$this->in('form_id'); $on = (string)$this->in('send_on'); $due = (string)$this->in('due_on');
        if (!isset(Tr::KIND[$k]) || !DB::val('SELECT 1 FROM tr_eval_forms WHERE id=? AND kind=? AND active=1', [$f, $k]) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $on)) { flash('Type, questionnaire ou date d\'envoi invalide.', 'danger'); redirect("trainings/sessions/$sid"); }
        $due = preg_match('/^\d{4}-\d{2}-\d{2}$/', $due) ? $due : date('Y-m-d', strtotime("$on +14 days"));
        $pid = DB::insert('tr_eval_plans', ['session_id' => (int)$sid, 'kind' => $k, 'form_id' => $f, 'send_on' => $on, 'due_on' => $due, 'status' => 'planned', 'created_by' => Auth::id(), 'created_at' => now()]);
        if ($on <= date('Y-m-d')) Tr::openDue(); Audit::log('create', 'tr_eval_plan', $pid); flash('Évaluation ' . mb_strtolower(Tr::KIND[$k]) . ' planifiée.'); redirect("trainings/sessions/$sid");
    }
    function planAct(string $pid): void {
        $p = DB::one('SELECT * FROM tr_eval_plans WHERE id=?', [(int)$pid]); if (!$p) { $this->notFound(); return; }
        $a = (string)$this->in('action');
        if ($a === 'cancel' && $p['kind'] === 'hot') { flash('L\'enquête de satisfaction à chaud est obligatoire pour chaque formation : vous pouvez la clôturer, pas l\'annuler.', 'warning'); redirect('trainings/sessions/' . $p['session_id']); }
        if ($a === 'cancel') DB::update('tr_eval_plans', ['status' => 'cancelled'], 'id=?', [(int)$pid]);
        elseif ($a === 'close') DB::update('tr_eval_plans', ['status' => 'closed'], 'id=?', [(int)$pid]);
        elseif ($a === 'open') { DB::update('tr_eval_plans', ['send_on' => date('Y-m-d'), 'status' => 'planned'], 'id=?', [(int)$pid]); Tr::openDue(); }
        Audit::log($a, 'tr_eval_plan', $pid); flash('Évaluation mise à jour.'); redirect('trainings/sessions/' . $p['session_id']);
    }
    function evals(): void {
        $me = $this->me(); $k = (string)$this->in('kind', ''); $st = (string)$this->in('status', ''); $w = ['1=1']; $p = [];
        if (isset(Tr::KIND[$k])) { $w[] = 'pl.kind=?'; $p[] = $k; } if (isset(Tr::PLAN_ST[$st])) { $w[] = 'pl.status=?'; $p[] = $st; }
        $rows = can('training.manage') || can('trreport.view') ? DB::all("SELECT pl.*, t.title, s.session_date, (SELECT COUNT(*) FROM tr_eval_responses r WHERE r.plan_id=pl.id) n, (SELECT AVG(avg) FROM tr_eval_responses r WHERE r.plan_id=pl.id) av, (SELECT COUNT(*) FROM training_enrollments e WHERE e.session_id=s.id AND e.status<>'absent') part FROM tr_eval_plans pl JOIN training_sessions s ON s.id=pl.session_id JOIN trainings t ON t.id=s.training_id WHERE " . implode(' AND ', $w) . ' ORDER BY pl.send_on DESC LIMIT 200', $p) : [];
        $mine = $me ? DB::all("SELECT pl.*, t.title, s.session_date FROM tr_eval_plans pl JOIN training_sessions s ON s.id=pl.session_id JOIN trainings t ON t.id=s.training_id JOIN training_enrollments e ON e.session_id=s.id AND e.employee_id=? AND e.status<>'absent' WHERE pl.status='open' AND NOT EXISTS (SELECT 1 FROM tr_eval_responses r WHERE r.plan_id=pl.id AND r.employee_id=?) ORDER BY pl.due_on", [$me, $me]) : [];
        $this->view('training/evals', ['title' => 'Évaluations à chaud et à froid', 'rows' => $rows, 'mine' => $mine, 'kind' => $k, 'status' => $st]);
    }
    private function planCtx(string $pid): ?array {
        $p = DB::one('SELECT pl.*, t.title, s.session_date, s.id sid FROM tr_eval_plans pl JOIN training_sessions s ON s.id=pl.session_id JOIN trainings t ON t.id=s.training_id WHERE pl.id=?', [(int)$pid]);
        return $p ? ['p' => $p, 'form' => DB::one('SELECT * FROM tr_eval_forms WHERE id=?', [(int)$p['form_id']]), 'qs' => DB::all('SELECT * FROM tr_eval_questions WHERE form_id=? ORDER BY position', [(int)$p['form_id']])] : null;
    }
    function evalFill(string $pid): void {
        $c = $this->planCtx($pid); if (!$c) { $this->notFound(); return; } $me = $this->me();
        $enrolled = $me && DB::val("SELECT 1 FROM training_enrollments WHERE session_id=? AND employee_id=? AND status<>'absent'", [(int)$c['p']['sid'], $me]); $preview = can('training.manage');
        if (!$enrolled && !$preview) { $this->forbidden(); return; }
        $done = $me && DB::val('SELECT 1 FROM tr_eval_responses WHERE plan_id=? AND employee_id=?', [(int)$pid, $me]);
        $this->view('training/eval_form', $c + ['title' => 'Évaluation ' . mb_strtolower(Tr::KIND[$c['p']['kind']]) . ' : ' . $c['p']['title'], 'can' => $enrolled && $c['p']['status'] === 'open' && !$done, 'done' => (bool)$done, 'preview' => !$enrolled]);
    }
    function evalSubmit(string $pid): void {
        $c = $this->planCtx($pid); if (!$c) { $this->notFound(); return; } $me = $this->me();
        if (!$me || $c['p']['status'] !== 'open' || !DB::val("SELECT 1 FROM training_enrollments WHERE session_id=? AND employee_id=? AND status<>'absent'", [(int)$c['p']['sid'], $me])) { $this->forbidden(); return; }
        if (DB::val('SELECT 1 FROM tr_eval_responses WHERE plan_id=? AND employee_id=?', [(int)$pid, $me])) { flash('Vous avez déjà répondu.', 'warning'); redirect('trainings/evals'); }
        $ans = []; $err = []; $sum = 0; $n = 0;
        foreach ($c['qs'] as $q) { $v = trim((string)($_POST['q'][$q['id']] ?? ''));
            if ($v === '') { if ($q['required']) $err['q' . $q['id']] = 'Réponse obligatoire : ' . mb_substr($q['label'], 0, 60); continue; }
            if ($q['qtype'] === 'rating') { $i = (int)$v; if ($i < 1 || $i > 5) { $err['q' . $q['id']] = 'Note invalide.'; continue; } $ans[$q['id']] = $i; $sum += $i; $n++; }
            elseif ($q['qtype'] === 'yesno') $ans[$q['id']] = $v === 'yes' ? 'yes' : 'no'; else $ans[$q['id']] = mb_substr($v, 0, 1000); }
        if ($err) { $_SESSION['_old'] = $_POST; $_SESSION['_ferr'] = $err; flash(implode(' ', array_slice($err, 0, 3)), 'danger'); redirect('trainings/eval/' . $pid); }
        DB::insert('tr_eval_responses', ['plan_id' => (int)$pid, 'employee_id' => $me, 'avg' => $n ? round($sum / $n, 2) : null, 'answers' => json_encode($ans, JSON_UNESCAPED_UNICODE), 'comment' => mb_substr(trim((string)($_POST['comment'] ?? '')), 0, 1500) ?: null, 'submitted_at' => now()]);
        flash('Merci, votre évaluation est enregistrée.'); redirect('trainings/evals');
    }
    function evalResults(string $pid): void {
        $c = $this->planCtx($pid); if (!$c) { $this->notFound(); return; }
        $resp = DB::all('SELECT * FROM tr_eval_responses WHERE plan_id=?', [(int)$pid]); $stats = []; $verb = [];
        foreach ($c['qs'] as $q) { $vals = []; foreach ($resp as $r) { $a = json_decode((string)$r['answers'], true) ?: []; if (isset($a[$q['id']]) && $a[$q['id']] !== '') $vals[] = $a[$q['id']]; }
            if ($q['qtype'] === 'rating') { $dist = array_fill(1, 5, 0); foreach ($vals as $v) $dist[(int)$v]++; $stats[$q['id']] = ['n' => count($vals), 'avg' => $vals ? round(array_sum($vals) / count($vals), 2) : null, 'dist' => $dist]; }
            elseif ($q['qtype'] === 'yesno') $stats[$q['id']] = ['n' => count($vals), 'yes' => count(array_filter($vals, fn($v) => $v === 'yes'))]; else $stats[$q['id']] = ['n' => count($vals), 'texts' => $vals]; }
        foreach ($resp as $r) if ($r['comment']) $verb[] = $r['comment'];
        $part = (int)DB::val("SELECT COUNT(*) FROM training_enrollments WHERE session_id=? AND status<>'absent'", [(int)$c['p']['sid']]);
        $this->view('training/eval_results', $c + ['title' => 'Résultats : ' . $c['p']['title'], 'stats' => $stats, 'verb' => $verb, 'n' => count($resp), 'part' => $part, 'avg' => $resp ? round(array_sum(array_map(fn($r) => (float)$r['avg'], $resp)) / count($resp), 2) : null]);
    }
    // Questionnaires
    function forms(): void { $this->view('training/eval_forms', ['title' => 'Questionnaires d\'évaluation', 'rows' => DB::all('SELECT f.*, (SELECT COUNT(*) FROM tr_eval_questions q WHERE q.form_id=f.id) nq, (SELECT COUNT(*) FROM tr_eval_plans p WHERE p.form_id=f.id) np FROM tr_eval_forms f ORDER BY f.kind, f.name')]); }
    function formCreate(): void {
        $k = (string)$this->in('kind'); $n = trim((string)$this->in('name')); if (!isset(Tr::FKIND[$k]) || $n === '') { flash('Type et nom obligatoires.', 'danger'); redirect('trainings/eval-forms'); }
        $id = DB::insert('tr_eval_forms', ['kind' => $k, 'name' => mb_substr($n, 0, 150), 'active' => 1]); Audit::log('create', 'tr_eval_form', $id); redirect("trainings/eval-forms/$id");
    }
    function formShow(string $id): void {
        $f = DB::one('SELECT * FROM tr_eval_forms WHERE id=?', [(int)$id]); if (!$f) { $this->notFound(); return; }
        $this->view('training/eval_form_edit', ['title' => $f['name'], 'f' => $f, 'qs' => DB::all('SELECT * FROM tr_eval_questions WHERE form_id=? ORDER BY position', [(int)$id])]);
    }
    function formUpdate(string $id): void {
        $f = DB::one('SELECT * FROM tr_eval_forms WHERE id=?', [(int)$id]); if (!$f) { $this->notFound(); return; }
        $n = trim((string)$this->in('name')); if ($n === '') { flash('Le nom est obligatoire.', 'danger'); redirect("trainings/eval-forms/$id"); }
        DB::update('tr_eval_forms', ['name' => mb_substr($n, 0, 150), 'active' => $this->in('active') ? 1 : 0], 'id=?', [(int)$id]); flash('Questionnaire enregistré.'); redirect("trainings/eval-forms/$id");
    }
    function qAdd(string $id): void {
        if (!DB::val('SELECT 1 FROM tr_eval_forms WHERE id=?', [(int)$id])) { $this->notFound(); return; }
        $l = trim((string)$this->in('label')); $t = (string)$this->in('qtype', 'rating'); if ($l === '' || !isset(Tr::QT[$t])) { flash('Libellé et type obligatoires.', 'danger'); redirect("trainings/eval-forms/$id"); }
        DB::insert('tr_eval_questions', ['form_id' => (int)$id, 'position' => (int)DB::val('SELECT COALESCE(MAX(position),0)+1 FROM tr_eval_questions WHERE form_id=?', [(int)$id]), 'label' => mb_substr($l, 0, 300), 'qtype' => $t, 'required' => $this->in('required') ? 1 : 0]); flash('Question ajoutée.'); redirect("trainings/eval-forms/$id");
    }
    function qDelete(string $id, string $qid): void {
        if ((int)DB::val('SELECT COUNT(*) FROM tr_eval_responses r JOIN tr_eval_plans p ON p.id=r.plan_id WHERE p.form_id=?', [(int)$id])) { flash('Des réponses existent : désactivez le questionnaire plutôt que de supprimer une question.', 'warning'); redirect("trainings/eval-forms/$id"); }
        DB::exec('DELETE FROM tr_eval_questions WHERE id=? AND form_id=?', [(int)$qid, (int)$id]); flash('Question supprimée.'); redirect("trainings/eval-forms/$id");
    }

    // ───────── Rapports ─────────
    function note(): void {
        $sc = (string)$this->in('scope'); $per = mb_substr((string)$this->in('period'), 0, 10); $k = mb_substr((string)$this->in('k'), 0, 30); $back = (string)$this->in('back', '/');
        $perm = in_array($sc, ['tr_month', 'tr_session', 'tr_trainer'], true) ? 'training.manage' : (in_array($sc, ['qa_month', 'qa_coach', 'cal'], true) ? 'qa.manage' : ($sc === 'ep' ? 'ep.manage' : null));
        if (!$perm || !can($perm) || !preg_match('/^[a-z_0-9]+$/', $k)) { $this->forbidden(); return; }
        Tr::setNote($sc, $per, $k, mb_substr(trim((string)$this->in('body')), 0, 2000)); flash('Commentaire enregistré.'); $bp = base_path(); if ($bp !== '' && str_starts_with($back, $bp . '/')) $back = substr($back, strlen($bp)); $back = ltrim($back, '/');
        if ($back === '' || preg_match('#^[a-z][a-z0-9+.-]*:#i', $back) || str_starts_with($back, '/') || str_contains($back, '\\') || str_contains($back, "\n")) $back = (string)($_SERVER['HTTP_REFERER'] ?? '') !== '' && str_starts_with((string)$_SERVER['HTTP_REFERER'], (isset($_SERVER['HTTPS']) ? 'https://' : 'http://') . ($_SERVER['HTTP_HOST'] ?? '')) ? (string)$_SERVER['HTTP_REFERER'] : '/';
        redirect($back);
    }
    function dashboard(): void {
        $ym = (string)$this->in('month', date('Y-m')); if (!preg_match('/^\d{4}-\d{2}$/', $ym)) $ym = date('Y-m');
        [$f, $t] = Tr::monthRange($ym); $pm = Tr::prevMonth($ym); [$pf, $pt] = Tr::monthRange($pm); $cur = Tr::stats($f, $t); $prev = Tr::stats($pf, $pt);
        $labels = []; $series = ['Taux de réussite' => [], 'Assiduité' => []]; for ($i = 11; $i >= 0; $i--) { $m = date('Y-m', strtotime($ym . "-01 -$i month")); [$a, $b] = Tr::monthRange($m); $x = Tr::stats($a, $b); $labels[] = date('m/y', strtotime("$m-01")); $series['Taux de réussite'][] = $x['pass_rate'] ?? 0; $series['Assiduité'][] = $x['presence'] ?? 0; }
        $this->view('training/dashboard', ['title' => 'Rapport mensuel de formation', 'ym' => $ym, 'cur' => $cur, 'prev' => $prev, 'cov' => Tr::coverage(), 'labels' => $labels, 'series' => $series, 'edit' => can('training.manage')], 'layout/public');
    }
    function sessionReport(string $sid): void {
        $s = DB::one('SELECT s.*, t.title, t.category, t.duration_hours, t.mandatory FROM training_sessions s JOIN trainings t ON t.id=s.training_id WHERE s.id=?', [(int)$sid]); if (!$s) { $this->notFound(); return; }
        $en = DB::all('SELECT en.*, e.first_name, e.last_name, e.matricule, ' . Tr::entityOf() . ' entity FROM training_enrollments en JOIN employees e ON e.id=en.employee_id LEFT JOIN channels c ON c.id=e.channel_id WHERE en.session_id=? ORDER BY e.last_name', [(int)$sid]);
        $plans = DB::all('SELECT pl.*, (SELECT COUNT(*) FROM tr_eval_responses r WHERE r.plan_id=pl.id) n, (SELECT AVG(avg) FROM tr_eval_responses r WHERE r.plan_id=pl.id) av FROM tr_eval_plans pl WHERE pl.session_id=? ORDER BY pl.send_on', [(int)$sid]);
        $verb = []; foreach ($plans as $p) if ($p['kind'] === 'hot') foreach (DB::all('SELECT comment FROM tr_eval_responses WHERE plan_id=? AND comment IS NOT NULL', [(int)$p['id']]) as $r) $verb[] = $r['comment'];
        $this->view('training/session_report', ['title' => 'Rapport de fin de formation : ' . $s['title'], 's' => $s, 'en' => $en, 'plans' => $plans, 'verb' => $verb, 'hours' => Tr::sessionHours((int)$sid, (float)$s['duration_hours']), 'edit' => can('training.manage')], 'layout/public');
    }
    function trainerReport(): void {
        $ym = (string)$this->in('month', date('Y-m')); if (!preg_match('/^\d{4}-\d{2}$/', $ym)) $ym = date('Y-m'); [$f, $t] = Tr::monthRange($ym);
        $emp = (int)$this->in('trainer', 0) ?: $this->me();
        $trainers = DB::all("SELECT DISTINCT e.id, e.first_name, e.last_name FROM employees e JOIN training_sessions s ON e.id IN (s.trainer_emp_id, s.backup_emp_id) ORDER BY e.last_name");
        if (!$emp && $trainers) $emp = (int)$trainers[0]['id'];
        $ss = $emp ? array_values(array_filter(DB::all("SELECT s.*, t.title, t.category, t.duration_hours FROM training_sessions s JOIN trainings t ON t.id=s.training_id WHERE s.status<>'cancelled' AND s.session_date BETWEEN ? AND ? ORDER BY s.session_date", [$f, $t]), fn($s) => Tr::trainerId($s) === $emp)) : [];
        $rows = []; $h = 0.0; $part = 0; $pass = 0; $fail = 0; $ids = [];
        foreach ($ss as $s) { $e = DB::all("SELECT status FROM training_enrollments WHERE session_id=?", [(int)$s['id']]); $p = count(array_filter($e, fn($x) => in_array($x['status'], Tr::FORMED, true))); $ok = count(array_filter($e, fn($x) => $x['status'] === 'passed')); $ko = count(array_filter($e, fn($x) => $x['status'] === 'failed'));
            $hh = Tr::sessionHours((int)$s['id'], (float)$s['duration_hours']); if ($s['status'] === 'done') { $h += $hh; } $part += $p; $pass += $ok; $fail += $ko; $ids[] = (int)$s['id']; $rows[] = ['s' => $s, 'present' => $p, 'rate' => ($ok + $ko) ? round(100 * $ok / ($ok + $ko), 1) : null, 'h' => $hh]; }
        $prog = []; $weak = [];
        if ($ids) { $in = implode(',', $ids); foreach (DB::all("SELECT en.*, e.first_name, e.last_name FROM training_enrollments en JOIN employees e ON e.id=en.employee_id WHERE en.session_id IN ($in)") as $en) { if ($en['score'] !== null && $en['pre_score'] !== null) $prog[] = (float)$en['score'] - (float)$en['pre_score']; if ($en['status'] === 'failed') $weak[] = $en; } }
        $this->view('training/trainer_report', ['title' => 'Rapport mensuel du formateur', 'ym' => $ym, 'emp' => $emp, 'trainers' => $trainers, 'rows' => $rows, 'hours' => $h, 'part' => $part, 'rate' => ($pass + $fail) ? round(100 * $pass / ($pass + $fail), 1) : null,
            'prog' => $prog ? round(array_sum($prog) / count($prog), 1) : null, 'sat' => $ids ? Tr::evalAvg(["pl.kind='hot'", 's.id IN (' . implode(',', $ids) . ')']) : null, 'weak' => $weak, 'name' => Tr::name($emp), 'edit' => can('training.manage')], 'layout/public');
    }

    // ───────── Certificats d'une formation ─────────
    function certificate(string $eid): void {
        $en = DB::one('SELECT * FROM training_enrollments WHERE id=?', [(int)$eid]); if (!$en) { $this->notFound(); return; }
        if (!can('training.manage') && (int)$en['employee_id'] !== $this->me()) { $this->forbidden(); return; }
        $x = Cert::forTraining($en); if (!$x) { flash('Le certificat n\'est disponible que pour les participants dont la formation est validée.', 'warning'); redirect('trainings/sessions/' . $en['session_id']); }
        Audit::log('certificate', 'training_enrollment', $eid); Cert::deliver($x[0], $x[1], 'training_enrollment', (int)$eid, 'attestation-' . $x[1]['no'], (int)$en['employee_id']);
    }
    function setCertTemplate(string $id): void {
        if (!DB::val('SELECT 1 FROM trainings WHERE id=?', [(int)$id])) { $this->notFound(); return; }
        $t = (int)$this->in('cert_template_id', 0); DB::update('trainings', ['cert_template_id' => $t && DB::val('SELECT 1 FROM cert_templates WHERE id=?', [$t]) ? $t : null], 'id=?', [(int)$id]); flash('Modèle d\'attestation enregistré.'); redirect("trainings/$id");
    }
}
