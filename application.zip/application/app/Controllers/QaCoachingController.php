<?php
namespace App\Controllers;
use App\Core\{DB, Audit, Auth, Scope, Notifier, Ca, QaSessions as S};
/** Coachings qualité : programmation, compte rendu partagé avec le collaborateur et son N+1. */
class QaCoachingController extends QaSessionBase {
    protected string $kind = 'coaching'; protected string $path = 'coachings';
    private function myEmp(): int { return (int)(Auth::user()['employee_id'] ?? 0); }
    public function canSee(array $r): bool {
        if ((int)$r['coach_user_id'] === (int)Auth::id()) return true;
        if (can('qa.view') && Scope::allows((int)$r['employee_id'])) return true;
        return can('qa.own') && $this->myEmp() === (int)$r['employee_id'] && $r['status'] !== 'cancelled';
    }
    function index(): void {
        [$w, $p] = Scope::sql('c.employee_id'); $w = [$w];
        if (isset(S::ST[$this->in('status')])) { $w[] = 'c.status=?'; $p[] = $this->in('status'); }
        if ($this->in('coach_id')) { $w[] = 'c.coach_user_id=?'; $p[] = (int)$this->in('coach_id'); }
        if ($this->in('employee_id')) { $w[] = 'c.employee_id=?'; $p[] = (int)$this->in('employee_id'); }
        if ($this->in('from')) { $w[] = 'c.planned_at>=?'; $p[] = $this->in('from') . ' 00:00:00'; } if ($this->in('to')) { $w[] = 'c.planned_at<=?'; $p[] = $this->in('to') . ' 23:59:59'; }
        $from = 'qa_coachings c JOIN employees e ON e.id=c.employee_id JOIN users u ON u.id=c.coach_user_id WHERE ' . implode(' AND ', $w); $cols = 'c.*, e.first_name, e.last_name, e.matricule, u.name coach_name';
        if ($this->in('export') === 'csv') csv_download('coachings-qualite.csv', ['Date', 'Matricule', 'Collaborateur', 'Coach', 'Sujet', 'Statut', 'Compte rendu partagé le'], array_map(fn($r) => [dt($r['planned_at']), $r['matricule'], $r['last_name'] . ' ' . $r['first_name'], $r['coach_name'], $r['topic'], S::ST[$r['status']][0] ?? $r['status'], $r['shared_at'] ? dt($r['shared_at']) : ''], DB::all("SELECT $cols FROM $from ORDER BY c.planned_at DESC", $p)));
        $k = DB::all("SELECT c.status, COUNT(*) n FROM $from GROUP BY c.status", $p);
        $this->view('qa/coachings', ['title' => 'Coachings qualité', 'p' => paginate($from, $p, $this->page(), 25, $cols, 'c.planned_at DESC, c.id DESC'), 'kpi' => array_column($k, 'n', 'status'), 'coaches' => Ca::usersWith('qa.evaluate'), 'employees' => Scope::employees()]);
    }
    function mine(): void {
        $me = $this->myEmp();
        $rows = $me ? DB::all("SELECT c.*, u.name coach_name FROM qa_coachings c JOIN users u ON u.id=c.coach_user_id WHERE c.employee_id=? AND c.status<>'cancelled' ORDER BY c.planned_at DESC", [$me]) : [];
        $team = $me ? (int)DB::val('SELECT team_id FROM employees WHERE id=?', [$me]) : 0;
        $deb = $team ? DB::all("SELECT d.*, u.name coach_name FROM qa_debriefs d JOIN users u ON u.id=d.coach_user_id WHERE d.team_id=? AND d.audience='team' AND d.status<>'cancelled' ORDER BY d.planned_at DESC", [$team]) : [];
        $this->view('qa/coachings_mine', ['title' => 'Mes coachings', 'rows' => $rows, 'deb' => $deb]);
    }
    function create(): void {
        $this->view('qa/coaching_form', ['title' => 'Programmer un coaching', 'employees' => Scope::employees(), 'coaches' => Ca::usersWith('qa.evaluate'), 'pre' => ['employee_id' => (int)$this->in('employee_id', 0), 'evaluation_id' => (int)$this->in('evaluation_id', 0), 'topic' => (string)$this->in('topic', '')]]);
    }
    function store(): void {
        [$d, $err] = $this->validate(['topic' => ['label' => 'Le sujet', 'req' => true, 'max' => 190], 'objectives' => ['label' => 'Les objectifs', 'max' => 1000]], $_POST);
        $emp = (int)$this->in('employee_id'); $at = S::when($this->in('date'), $this->in('time')); $dur = max(5, min(480, (int)$this->in('duration_min', 30)));
        $coach = can('qa.manage') && $this->in('coach_id') ? (int)$this->in('coach_id') : (int)Auth::id();
        if (!$emp || !Scope::allows($emp) || !DB::val("SELECT 1 FROM employees WHERE id=? AND status<>'left'", [$emp])) $err['emp'] = 'Choisissez un collaborateur de votre périmètre.';
        if (!$at) $err['date'] = 'Indiquez la date du coaching.'; elseif (strtotime($at) < strtotime(date('Y-m-d'))) $err['date'] = 'La date ne peut pas être passée.';
        if (!in_array($coach, array_map('intval', array_column(Ca::usersWith('qa.evaluate'), 'id')), true)) $err['coach'] = 'Coach invalide.';
        $ev = (int)$this->in('evaluation_id', 0); if ($ev && !DB::val('SELECT 1 FROM qa_evaluations WHERE id=? AND employee_id=?', [$ev, $emp])) $ev = 0;
        if ($err) $this->back($err, $_POST, 'qa/coachings/new');
        $row = ['employee_id' => $emp, 'coach_user_id' => $coach, 'planned_at' => $at, 'duration_min' => $dur, 'topic' => $d['topic'], 'objectives' => $d['objectives'], 'evaluation_id' => $ev ?: null, 'status' => 'planned', 'created_by' => Auth::id(), 'created_at' => now()];
        $id = DB::insert('qa_coachings', $row); S::log('coaching', $id, 'planned', null, $at, null); $row['id'] = $id;
        $this->notify($row, 'Coaching programmé · ' . $d['topic'], 'Le ' . dt($at) . ' (' . $dur . ' min)', true, true);
        Audit::log('create', 'qa_coaching', $id, null, $row); flash('Coaching programmé ; le collaborateur et son N+1 sont prévenus. Rappels automatiques à J-3 et J-1.'); redirect("qa/coachings/$id");
    }
    function show(string $id): void {
        $r = $this->open($id); if (!$r) return;
        $e = DB::one('SELECT * FROM employees WHERE id=?', [(int)$r['employee_id']]); $m = $e['manager_id'] ? DB::one('SELECT first_name, last_name FROM employees WHERE id=?', [(int)$e['manager_id']]) : null; $e['n1'] = $m ? $m['last_name'] . ' ' . $m['first_name'] : '';
        $own = $this->myEmp() === (int)$r['employee_id'] && (int)$r['coach_user_id'] !== (int)Auth::id() && !can('qa.view');
        $this->view('qa/session', $this->detail($r) + ['title' => 'Coaching qualité', 'emp' => $e, 'hideReport' => $own && !$r['shared_at'], 'evaluation' => $r['evaluation_id'] ? DB::one('SELECT id, eval_date, score_pct FROM qa_evaluations WHERE id=?', [(int)$r['evaluation_id']]) : null]);
    }
}
