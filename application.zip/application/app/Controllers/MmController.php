<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, ESign, Esc, Notifier, Ns, View};

/** Mémos : rédaction, validation par le N+1, avis signés électroniquement. */
class MmController extends Controller {
    private function load(string $id): ?array { $m = DB::one('SELECT m.*, a.name author, v.name n1 FROM mm_memos m LEFT JOIN users a ON a.id=m.author_id LEFT JOIN users v ON v.id=m.n1_id WHERE m.id=?', [(int)$id]); if (!$m || !Ns::mmSees($m)) { $this->notFound(); return null; } return $m; }
    private function editable(array $m): bool { return (int)$m['author_id'] === (int)Auth::id() && in_array($m['status'], ['draft', 'rejected'], true); }
    function index(): void {
        $me = (int)Auth::id(); $view = (string)($_GET['view'] ?? 'mine'); $w = []; $p = [];
        if ($view === 'todo') { $w[] = "EXISTS (SELECT 1 FROM esign s WHERE s.doc_type='memo' AND s.doc_id=m.id AND s.user_id=? AND s.status='pending') AND m.status IN ('pending_n1','to_sign')"; $p[] = $me; }
        elseif ($view === 'all' && can('mm.all')) { $w[] = "m.status<>'draft'"; } else { $view = 'mine'; $w[] = 'm.author_id=?'; $p[] = $me; }
        $st = (string)($_GET['status'] ?? ''); if (isset(Ns::MM[$st])) { $w[] = 'm.status=?'; $p[] = $st; }
        if (($q = trim((string)($_GET['q'] ?? ''))) !== '') { $w[] = '(m.subject LIKE ? OR m.ref LIKE ? OR m.addressee LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $from = 'mm_memos m LEFT JOIN users a ON a.id=m.author_id LEFT JOIN users v ON v.id=m.n1_id WHERE ' . implode(' AND ', $w);
        if (($_GET['export'] ?? '') === 'csv') csv_download('memos_' . date('Ymd_His') . '.csv', ['Référence', 'Objet', 'Auteur', 'Entité', 'Destinataire', 'Date', 'Statut', 'Valideur N+1', 'Validé le'], array_map(fn($r) => [$r['ref'], $r['subject'], $r['author'], $r['author_entity'], $r['addressee'], $r['memo_date'], Ns::MM[$r['status']] ?? $r['status'], $r['n1'], $r['validated_at']], DB::all("SELECT m.*, a.name author, v.name n1 FROM $from ORDER BY m.id DESC", $p)));
        $this->view('mm/index', ['title' => 'Mémos', 'p' => paginate($from, $p, $this->page(), 25, 'm.*, a.name author, v.name n1', 'm.id DESC'), 'view' => $view, 'st' => $st,
            'todo' => (int)DB::val("SELECT COUNT(*) FROM esign s JOIN mm_memos m ON m.id=s.doc_id WHERE s.doc_type='memo' AND s.user_id=? AND s.status='pending' AND ((s.kind='n1' AND m.status='pending_n1') OR (s.kind='avis' AND m.status='to_sign'))", [$me])]);
    }
    private function formData(?array $m): array {
        $n1 = Esc::managerOf((int)Auth::id()); $cur = $m ? ESign::rows('memo', (int)$m['id']) : [];
        return ['m' => $m, 'defN1' => $m['n1_id'] ?? $n1, 'validators' => ESign::usersWith('mm.validate'), 'avis' => array_values(array_filter($cur, fn($s) => $s['kind'] === 'avis')), 'emp' => DB::one('SELECT t.name team FROM users u LEFT JOIN employees e ON e.id=u.employee_id LEFT JOIN teams t ON t.id=e.team_id WHERE u.id=?', [(int)Auth::id()])];
    }
    function create(): void { $this->view('mm/form', ['title' => 'Nouveau mémo'] + $this->formData(null)); }
    function edit(string $id): void { if (!($m = $this->load($id))) return; if (!$this->editable($m)) { $this->forbidden(); return; } $this->view('mm/form', ['title' => 'Modifier le mémo'] + $this->formData($m)); }
    /** Création / modification ; act=submit envoie au N+1. */
    function save(string $id = '0'): void {
        $m = null; if ((int)$id) { if (!($m = $this->load($id))) return; if (!$this->editable($m)) { $this->forbidden(); return; } }
        $me = (int)Auth::id(); $act = (string)$this->in('act', 'save'); $back = $m ? 'mm/' . $m['id'] . '/edit' : 'mm/new';
        $d = ['subject' => mb_substr(trim((string)$this->in('subject')), 0, 250), 'author_entity' => mb_substr(trim((string)$this->in('author_entity')), 0, 120) ?: null, 'addressee' => mb_substr(trim((string)$this->in('addressee')), 0, 200) ?: null, 'body' => mb_substr(trim((string)$this->in('body')), 0, 30000) ?: null, 'annex' => mb_substr(trim((string)$this->in('annex')), 0, 20000) ?: null,
            'entity' => mb_substr(trim((string)$this->in('entity')), 0, 100) ?: Ns::entity(), 'ref_suffix' => mb_substr(trim((string)$this->in('ref_suffix')), 0, 60) ?: Ns::suffix(), 'n1_id' => (int)$this->in('n1_id') ?: null, 'updated_at' => now()]; $err = [];
        $okV = array_map('intval', array_column(ESign::usersWith('mm.validate'), 'id')); $mgr = Esc::managerOf($me);
        if ($d['subject'] === '') $err[] = 'L\'objet est obligatoire.';
        if ($d['n1_id'] && ($d['n1_id'] === $me || !($d['n1_id'] === $mgr || in_array($d['n1_id'], $okV, true)))) { $err[] = 'Le valideur doit être votre responsable ou une personne habilitée, et ne peut pas être vous-même.'; $d['n1_id'] = null; }
        $avis = []; foreach ((array)($_POST['a_label'] ?? []) as $i => $l) { $l = mb_substr(trim((string)$l), 0, 80); $u = (int)($_POST['a_user'][$i] ?? 0); if ($l === '' && !$u) continue; if ($l === '' || !$u || !DB::val("SELECT 1 FROM users WHERE id=? AND status='active'", [$u])) { $err[] = 'Chaque avis doit avoir un intitulé et un signataire.'; continue; } $avis[] = [$l, $u]; }
        if ($act === 'submit') { if (!$d['body']) $err[] = 'Le texte du mémo est vide.'; if (!$d['n1_id']) $err[] = 'Désignez le valideur N+1.'; if (!$d['addressee']) $err[] = 'Indiquez le destinataire.'; }
        if ($err && !$m && $d['subject'] === '') { $_SESSION['_old'] = $_POST; flash(implode(' ', array_unique($err)), 'danger'); redirect($back); }
        if ($m) DB::update('mm_memos', $d, 'id=?', [(int)$m['id']]); else { $id = (string)DB::insert('mm_memos', $d + ['author_id' => $me, 'status' => 'draft', 'created_at' => now()]); Ns::log((int)$id, 'create', $d['subject'], 'mm'); Audit::log('create', 'mm_memo', $id); }
        $mid = (int)($m['id'] ?? $id); ESign::clear('memo', $mid); foreach ($avis as $i => [$l, $u]) ESign::ask('memo', $mid, 'avis', $l, $u, $i + 2);
        unset($_SESSION['_old']);
        if ($err) { flash(implode(' ', array_unique($err)), 'danger'); redirect("mm/$mid/edit"); }
        if ($act !== 'submit') { if ($m) Ns::log($mid, 'edit', 'Mémo modifié', 'mm'); flash('Mémo enregistré.'); redirect('mm/' . $mid); }
        ESign::ask('memo', $mid, 'n1', 'Validation N+1', (int)$d['n1_id'], 1);
        DB::update('mm_memos', ['status' => 'pending_n1', 'reject_reason' => null, 'submitted_at' => now(), 'memo_date' => date('Y-m-d')], 'id=?', [$mid]); Ns::log($mid, 'submit', 'Soumis à ' . DB::val('SELECT name FROM users WHERE id=?', [(int)$d['n1_id']]), 'mm');
        Notifier::send((int)$d['n1_id'], 'Mémo à valider', $d['subject'] . ' — ' . (Auth::user()['name'] ?? ''), '/mm/' . $mid); flash('Mémo soumis à votre N+1.'); redirect('mm/' . $mid);
    }
    function show(string $id): void {
        if (!($m = $this->load($id))) return; $sig = ESign::rows('memo', (int)$id); $mine = null;
        foreach ($sig as $s) if ((int)$s['user_id'] === (int)Auth::id() && $s['status'] === 'pending' && (($s['kind'] === 'n1' && $m['status'] === 'pending_n1') || ($s['kind'] === 'avis' && $m['status'] === 'to_sign'))) { $mine = $s; break; }
        $this->view('mm/show', ['title' => $m['ref'] ?: 'Mémo', 'm' => $m, 'sig' => $sig, 'mine' => $mine, 'pad' => ESign::pad((int)Auth::id()), 'editable' => $this->editable($m),
            'log' => DB::all('SELECT l.*, u.name uname FROM mm_log l LEFT JOIN users u ON u.id=l.user_id WHERE l.memo_id=? ORDER BY l.id DESC', [(int)$id])]);
    }
    function decide(string $id): void {
        if (!($m = $this->load($id))) return; $me = (int)Auth::id(); $kind = $m['status'] === 'pending_n1' ? 'n1' : ($m['status'] === 'to_sign' ? 'avis' : null);
        $s = $kind ? ESign::mine('memo', (int)$id, $kind) : null; if (!$s) { $this->forbidden(); return; }
        $ok = (string)$this->in('decision') === 'ok'; $c = trim((string)$this->in('comment'));
        if (!ESign::confirm((string)$this->in('password'))) { flash('Mot de passe incorrect : la décision n\'a pas été enregistrée.', 'danger'); redirect('mm/' . $id); }
        if (!$ok) { if ($c === '') { flash('Le motif du refus est obligatoire.', 'danger'); redirect('mm/' . $id); }
            ESign::reject((int)$s['id'], $c); DB::update('mm_memos', ['status' => 'rejected', 'reject_reason' => mb_substr($s['role'] . ' : ' . $c, 0, 500), 'updated_at' => now()], 'id=?', [(int)$id]); Ns::log((int)$id, 'reject', $s['role'] . ' : ' . $c, 'mm');
            Notifier::send((int)$m['author_id'], 'Mémo à corriger', $m['subject'] . ' — ' . $c, '/mm/' . $id); flash('Refus enregistré : le mémo retourne à son auteur.'); redirect('mm/' . $id); }
        $pad = (string)$this->in('pad'); if ($pad !== '') ESign::savePad($me, $pad);
        ESign::sign((int)$s['id'], Ns::mmHash($m), $c); $u = ['updated_at' => now()];
        if ($kind === 'n1') { [$no, $y] = Ns::number('mm_memos'); $u += ['ref_no' => $no, 'year' => $y, 'ref' => sprintf('%03d/%s', $no, $m['ref_suffix'] ?: Ns::suffix()), 'validated_at' => now(), 'verify_code' => ESign::code()]; Ns::log((int)$id, 'n1', 'N° ' . $u['ref'], 'mm'); } else Ns::log((int)$id, 'avis', $s['role'] . ($c !== '' ? ' : ' . $c : ''), 'mm');
        if (ESign::left('memo', (int)$id)) { $u['status'] = 'to_sign'; if ($kind === 'n1') foreach (ESign::rows('memo', (int)$id) as $r) if ($r['status'] === 'pending') Notifier::send((int)$r['user_id'], 'Mémo : votre avis est attendu (' . $r['role'] . ')', $m['subject'], '/mm/' . $id); }
        else { $u += ['status' => 'signed', 'signed_at' => now()]; Notifier::send((int)$m['author_id'], 'Mémo validé' . (isset($u['ref']) ? ' : N° ' . $u['ref'] : ''), $m['subject'], '/mm/' . $id); }
        DB::update('mm_memos', $u, 'id=?', [(int)$id]); if ($kind === 'n1' && ($u['status'] ?? '') === 'to_sign') Notifier::send((int)$m['author_id'], 'Mémo validé par votre N+1 : N° ' . $u['ref'], $m['subject'], '/mm/' . $id);
        Audit::log('sign', 'mm_memo', $id, null, ['kind' => $kind]); flash($kind === 'n1' ? 'Mémo validé : N° ' . $u['ref'] . '.' : 'Avis enregistré.'); redirect('mm/' . $id);
    }
    function remove(string $id): void {
        if (!($m = $this->load($id))) return; if ((int)$m['author_id'] !== (int)Auth::id() && !can('mm.all')) { $this->forbidden(); return; }
        if ($m['status'] === 'draft' && (int)$m['author_id'] === (int)Auth::id()) { ESign::clear('memo', (int)$id); DB::exec('DELETE FROM mm_log WHERE memo_id=?', [(int)$id]); DB::exec('DELETE FROM mm_memos WHERE id=?', [(int)$id]); Audit::log('delete', 'mm_memo', $id, ['subject' => $m['subject']]); flash('Brouillon supprimé.'); redirect('mm'); }
        $c = trim((string)$this->in('comment')); if (in_array($m['status'], ['signed', 'cancelled'], true) || $c === '') { flash('Annulation impossible (mémo validé) ou motif manquant.', 'danger'); redirect('mm/' . $id); }
        DB::update('mm_memos', ['status' => 'cancelled', 'reject_reason' => mb_substr($c, 0, 500), 'updated_at' => now()], 'id=?', [(int)$id]); Ns::log((int)$id, 'cancel', $c, 'mm'); flash('Mémo annulé.'); redirect('mm/' . $id);
    }
    function printView(string $id): void { if (!($m = $this->load($id))) return; echo View::partial('ns/print', ['n' => $m, 'sig' => ESign::rows('memo', (int)$id), 'kind' => 'memo']); }
}
