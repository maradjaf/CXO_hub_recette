<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Settings, Audit, Integ, Files, Meet, Xchg, Secret};

/** Administration > « Visio, WhatsApp et chat » : intégrations API et réglages des appels, du chat et des pièces jointes. */
class ExchangesController extends Controller {
    /** section => [titre, icône, aide, champs]. Champ : clé => [libellé, type, aide]. Types : bool, int:min:max, text, secret, url, select:a|b, platforms, groups. */
    const SECTIONS = [
        'teams' => ['Microsoft Teams', 'microsoft-teams', 'Crée automatiquement la réunion Teams (Microsoft Graph, permissions d\'application). Prérequis : application enregistrée dans Azure AD / Entra ID avec la permission OnlineMeetings.ReadWrite.All et une stratégie d\'accès d\'application (New-CsApplicationAccessPolicy) pour l\'organisateur.', [
            'integ.teams.enabled' => ['Activer l\'intégration Teams', 'bool', ''], 'integ.teams.tenant_id' => ['ID de l\'annuaire (tenant)', 'text', ''], 'integ.teams.client_id' => ['ID de l\'application (client)', 'text', ''], 'integ.teams.client_secret' => ['Secret client', 'secret', 'Chiffré en base ; laissez vide pour conserver la valeur actuelle.'],
            'integ.teams.organizer' => ['Organisateur des réunions (UPN ou ID d\'objet)', 'text', 'Compte Microsoft 365 au nom duquel les réunions sont créées, ex. support@entreprise.com.'], 'integ.teams.graph_base' => ['URL de l\'API Graph', 'url', 'Avancé — ne modifier que pour un cloud souverain.'], 'integ.teams.login_base' => ['URL d\'authentification', 'url', 'Avancé.']]],
        'zoom' => ['Zoom', 'camera-video', 'Crée automatiquement la réunion Zoom (application Server-to-Server OAuth du Marketplace Zoom, portées meeting:write:meeting:admin et meeting:update/delete).', [
            'integ.zoom.enabled' => ['Activer l\'intégration Zoom', 'bool', ''], 'integ.zoom.account_id' => ['Account ID', 'text', ''], 'integ.zoom.client_id' => ['Client ID', 'text', ''], 'integ.zoom.client_secret' => ['Client secret', 'secret', 'Chiffré en base ; laissez vide pour conserver la valeur actuelle.'],
            'integ.zoom.host' => ['Compte hôte (e-mail Zoom ou « me »)', 'text', 'Utilisateur Zoom qui organise les réunions.'], 'integ.zoom.api_base' => ['URL de l\'API', 'url', 'Avancé.'], 'integ.zoom.oauth_url' => ['URL du jeton OAuth', 'url', 'Avancé.']]],
        'wa' => ['WhatsApp Business (Cloud API)', 'whatsapp', 'Envoie les invitations, annulations et rappels d\'appel en message WhatsApp. WhatsApp n\'offre pas d\'API pour créer un appel : le message transporte le lien de la réunion (Teams / Zoom / autre). Hors fenêtre de 24 h, Meta impose un modèle de message approuvé.', [
            'integ.wa.enabled' => ['Activer WhatsApp', 'bool', ''], 'integ.wa.phone_id' => ['ID du numéro de téléphone (Phone number ID)', 'text', ''], 'integ.wa.token' => ['Jeton d\'accès permanent', 'secret', 'Chiffré en base ; laissez vide pour conserver la valeur actuelle.'],
            'integ.wa.mode' => ['Type de message', 'select:template|text', 'template = modèle approuvé (recommandé) ; text = texte libre (uniquement si le destinataire a écrit dans les 24 h).'],
            'integ.wa.template' => ['Nom du modèle approuvé', 'text', 'Corps à 4 variables : {{1}} nom du participant, {{2}} objet de l\'appel, {{3}} date et heure, {{4}} lien ou numéro.'], 'integ.wa.lang' => ['Langue du modèle', 'text', 'ex. fr'], 'integ.wa.api_base' => ['URL de l\'API', 'url', 'Avancé.']]],
        'meet' => ['Appels planifiés', 'calendar-event', 'Activation, outils proposés, canaux de notification et rappels.', [
            'meet.enabled_inc' => ['Appels sur les incidents', 'bool', ''], 'meet.enabled_at' => ['Appels sur les tickets', 'bool', ''], 'meet.platforms' => ['Outils proposés', 'platforms', ''], 'meet.default_duration' => ['Durée par défaut (minutes)', 'int:5:480', ''], 'meet.reminder_min' => ['Rappel avant le début (minutes)', 'int:1:1440', 'Pris en compte par le cron bin/inc-alerts.php (toutes les 5 minutes).'], 'meet.max_guests' => ['Participants maximum par appel', 'int:1:200', ''],
            'meet.ch_inapp' => ['Canal : notification dans l\'outil', 'bool', ''], 'meet.ch_email' => ['Canal : e-mail avec fichier agenda', 'bool', 'Nécessite SMTP_HOST dans .env.'], 'meet.ch_sms' => ['Canal : SMS', 'bool', 'Nécessite SMS_GATEWAY_URL dans .env.'], 'meet.ch_wa' => ['Canal : WhatsApp', 'bool', 'Nécessite l\'intégration WhatsApp ci-dessus.'], 'meet.auto_default' => ['Cocher « création automatique » par défaut', 'bool', 'Quand Teams ou Zoom est configuré.']]],
        'chat' => ['Chat des incidents et tickets', 'chat-dots', 'Discussion intégrée à chaque fiche.', [
            'chat.enabled_inc' => ['Chat sur les incidents', 'bool', ''], 'chat.enabled_at' => ['Chat sur les tickets', 'bool', ''], 'chat.requester' => ['Le demandeur / déclarant peut écrire', 'bool', 'Sinon il lit seulement ; les gestionnaires et le support écrivent toujours.'], 'chat.internal' => ['Autoriser les notes internes', 'bool', 'Visibles uniquement par l\'équipe de traitement.'], 'chat.notify' => ['Notifier les participants dans l\'outil', 'bool', ''],
            'chat.poll_sec' => ['Actualisation (secondes)', 'int:2:120', ''], 'chat.max_len' => ['Longueur maximale d\'un message', 'int:50:2000', ''], 'chat.edit_min' => ['Délai pour modifier / supprimer son message (minutes)', 'int:0:1440', '0 = jamais.'], 'chat.rate_per_min' => ['Messages maximum par minute et par personne', 'int:1:600', '']]],
        'elearn' => ['E-learning', 'mortarboard', 'Règles du parcours d\'apprentissage, des niveaux, des questions aux formateurs, des demandes et des imports.', [
            'elearn.sequential_default' => ['Parcours par étapes par défaut (nouveaux cours)', 'bool', 'Chaque étape se débloque après la précédente ; réglable cours par cours.'], 'elearn.level_gate' => ['Déblocage par niveau', 'bool', 'Débutant à valider pour ouvrir Intermédiaire, puis Intermédiaire pour ouvrir Avancé (par domaine).'],
            'elearn.qna' => ['Questions aux formateurs (chat sur une partie)', 'bool', ''], 'elearn.requests' => ['Demandes d\'accès / de création de cours par les apprenants', 'bool', ''], 'elearn.self_enroll_paths' => ['Auto-inscription aux parcours en libre accès', 'bool', ''],
            'elearn.remind_days' => ['Rappel avant l\'échéance (jours)', 'int:0:60', ''], 'elearn.inactive_days' => ['Relance après inactivité (jours)', 'int:1:365', 'Un cours commencé sans activité depuis ce délai déclenche un rappel.'],
            'elearn.import_max_mb' => ['Taille maximale d\'un document importé (Mo)', 'int:1:200', 'Cours et base de connaissances. Plafonné par upload_max_filesize / post_max_size de php.ini.'], 'elearn.pdftotext_path' => ['Chemin de pdftotext (import PDF)', 'text', 'Facultatif. Laissez vide pour détection automatique (PATH, Laragon, poppler). Ex. : C:\\laragon\\bin\\poppler\\Library\\bin\\pdftotext.exe'], 'elearn.media_max_mb' => ['Taille maximale d\'un média de cours (Mo)', 'int:1:500', 'Images, vidéos et sons insérés dans l\'éditeur.']]],
        'rn' => ['Réunions', 'people', 'Planification, invitations, comptes rendus, décisions et plans d\'actions.', [
            'rn.enabled' => ['Module Réunions actif', 'bool', ''], 'rn.lazy' => ['Rappels sans cron (filet de sécurité)', 'bool', 'Si le cron bin/rn-reminders.php ne tourne pas, les rappels sont déclenchés par la navigation, au plus toutes les 10 minutes. Sans effet quand le cron fonctionne.'], 'rn.kinds' => ['Types de réunion (séparés par des virgules)', 'text', 'Proposés à la création et utilisés dans le tableau de bord.'], 'rn.default_duration' => ['Durée par défaut (minutes)', 'int:5:480', ''], 'rn.max_attendees' => ['Participants maximum par réunion', 'int:2:500', ''],
            'rn.ch_inapp' => ['Invitations : notification dans l\'outil', 'bool', ''], 'rn.ch_email' => ['Invitations : e-mail (avec fichier agenda .ics)', 'bool', 'Nécessite SMTP_HOST dans .env.'], 'rn.ch_sms' => ['Invitations : SMS', 'bool', 'Nécessite SMS_GATEWAY_URL dans .env.'], 'rn.ch_wa' => ['Invitations : WhatsApp', 'bool', 'Nécessite l\'intégration WhatsApp ci-dessus.'],
            'rn.reminder_min' => ['Rappel avant la réunion (minutes)', 'int:5:2880', 'Envoyé par le cron bin/rn-reminders.php.'], 'rn.four_eyes' => ['Compte rendu : validation par une autre personne que le rédacteur', 'bool', 'Sinon l\'organisateur ou le secrétaire peut valider ce qu\'il a rédigé.'],
            'rn.action_default_days' => ['Échéance proposée pour une action (jours)', 'int:1:365', ''], 'rn.action_remind_days' => ['Rappel d\'action avant l\'échéance (jours)', 'int:0:60', ''], 'rn.action_email' => ['Actions : prévenir aussi par e-mail', 'bool', ''],
            'rn.action_owner_close' => ['Le responsable clôture lui-même son action', 'bool', 'Sinon il la soumet et l\'organisateur la clôture après vérification.'], 'rn.minutes_chase_days' => ['Relance de l\'organisateur si le compte rendu manque après (jours)', 'int:1:60', '']]],
        'tc' => ['Discussions (façon Teams)', 'chat-left-text', 'Conversations individuelles et de groupe entre utilisateurs.', [
            'tc.enabled' => ['Discussions actives', 'bool', ''], 'tc.allow_groups' => ['Les utilisateurs peuvent créer des groupes', 'bool', 'Sinon seules les conversations individuelles sont possibles.'], 'tc.group_max' => ['Membres maximum par groupe', 'int:3:500', ''],
            'tc.max_len' => ['Longueur maximale d\'un message', 'int:100:10000', ''], 'tc.edit_min' => ['Délai pour modifier / supprimer son message (minutes)', 'int:0:1440', '0 = jamais.'], 'tc.longpoll' => ['Attente longue (secondes, 0 = désactivée)', 'int:0:30', 'Le message arrive aussitôt, comme dans une messagerie instantanée : la requête reste ouverte jusqu\'à 20 s. Mettre 0 si le serveur web a très peu de processus.'], 'tc.poll_sec' => ['Actualisation de repli (secondes)', 'int:2:120', 'Utilisée quand l\'attente longue est désactivée ou que l\'onglet est masqué.'], 'tc.rate_per_min' => ['Messages maximum par minute et par personne', 'int:5:600', ''],
            'tc.files' => ['Pièces jointes autorisées', 'bool', ''], 'tc.file_max_mb' => ['Taille maximale d\'une pièce jointe (Mo)', 'int:1:100', 'Plafonnée par upload_max_filesize / post_max_size de php.ini.'], 'tc.reactions' => ['Réactions (emoji)', 'bool', ''], 'tc.notify' => ['Notifier les nouveaux messages dans l\'outil', 'bool', 'Regroupées : pas de nouvelle notification tant que la précédente n\'est pas lue ; les mentions @ notifient toujours.']]],
        'files' => ['Pièces jointes', 'paperclip', 'Limites et formats autorisés pour les incidents et les tickets. La taille effective reste plafonnée par upload_max_filesize / post_max_size de php.ini.', [
            'files.max_mb' => ['Taille maximale par fichier (Mo)', 'int:1:100', ''], 'files.max_count' => ['Nombre maximum de fichiers par envoi', 'int:1:30', ''], 'files.groups' => ['Types de fichiers autorisés', 'groups', '']]],
    ];
    private function val(string $k, string $t): string { return str_starts_with($k, 'integ.') ? Integ::get(substr($k, 6)) : (str_contains($k, 'platforms') || str_contains($k, 'groups') ? implode(',', Xchg::csv($k)) : Xchg::get($k)); }
    function index(): void {
        $vals = []; $has = [];
        foreach (self::SECTIONS as $sec) foreach ($sec[3] as $k => [$l, $t]) { if ($t === 'secret') $has[$k] = Integ::has(substr($k, 6)); else $vals[$k] = $this->val($k, $t); }
        $this->view('admin/exchanges', ['title' => 'Visio, WhatsApp et chat', 'sections' => self::SECTIONS, 'vals' => $vals, 'has' => $has, 'ready' => ['teams' => Integ::ready('teams'), 'zoom' => Integ::ready('zoom'), 'wa' => Integ::ready('wa')],
            'log' => DB::all('SELECT l.*, u.name AS uname FROM integ_log l LEFT JOIN users u ON u.id=l.user_id ORDER BY l.id DESC LIMIT 25'), 'queue' => ['wa' => (int)DB::val("SELECT COUNT(*) FROM wa_outbox WHERE status='pending'"), 'wa_failed' => (int)DB::val("SELECT COUNT(*) FROM wa_outbox WHERE status='failed'"), 'sms' => (int)DB::val("SELECT COUNT(*) FROM sms_outbox WHERE status='pending'")],
            'smtp' => (string)env('SMTP_HOST', '') !== '', 'smsgw' => \App\Core\Sms::enabled(), 'groups' => array_keys(Files::GROUPS), 'platforms' => Meet::PLATFORMS]);
    }
    function save(string $section): void {
        if (!isset(self::SECTIONS[$section])) { $this->notFound(); return; } $in = (array)$this->in('f', []); $err = []; $set = [];
        foreach (self::SECTIONS[$section][3] as $k => [$label, $t]) {
            $raw = $in[$k] ?? null;
            if ($t === 'bool') { $set[$k] = $raw === '1' ? '1' : '0'; continue; }
            if ($t === 'secret') { if ((string)($in['_clear'][$k] ?? '') === '1') $set[$k] = ''; elseif (trim((string)$raw) !== '') $set[$k] = trim((string)$raw); continue; }
            if ($t === 'platforms') { $set[$k] = implode(',', array_values(array_intersect(array_keys(Meet::PLATFORMS), (array)$raw))); if ($set[$k] === '') $err[] = 'Choisissez au moins un outil de réunion.'; continue; }
            if ($t === 'groups') { $set[$k] = implode(',', array_values(array_intersect(array_keys(Files::GROUPS), (array)$raw))); if ($set[$k] === '') $err[] = 'Choisissez au moins un type de fichier.'; continue; }
            $raw = trim((string)$raw);
            if (str_starts_with($t, 'int:')) { [, $a, $b] = explode(':', $t); if (!preg_match('/^\d+$/', $raw) || (int)$raw < (int)$a || (int)$raw > (int)$b) { $err[] = "$label : entier entre $a et $b."; continue; } $set[$k] = (string)(int)$raw; }
            elseif ($t === 'url') { if ($raw !== '' && !preg_match('#^https://[^\s]+$#', $raw) && !preg_match('#^http://(127\.0\.0\.1|localhost)(:\d+)?(/\S*)?$#', $raw)) { $err[] = "$label : URL en https:// requise."; continue; } $set[$k] = rtrim($raw, '/'); }
            elseif (str_starts_with($t, 'select:')) { $o = explode('|', substr($t, 7)); if (!in_array($raw, $o, true)) { $err[] = "$label : valeur invalide."; continue; } $set[$k] = $raw; }
            else { if (mb_strlen($raw) > 200 || preg_match('/[\x00-\x1f]/', $raw)) { $err[] = "$label : texte invalide."; continue; } $set[$k] = $raw; }
        }
        if ($err) { flash(implode(' ', $err), 'danger'); redirect('admin/exchanges#' . $section); }
        $changed = [];
        foreach ($set as $k => $v) {
            if (str_starts_with($k, 'integ.')) { $kk = substr($k, 6); if (in_array($kk, Integ::SECRETS, true)) { if ($v === '') Settings::set($k, ''); else Integ::set($kk, $v); } else Integ::set($kk, $v); if (str_ends_with($k, '.client_secret') || str_ends_with($k, '.client_id') || str_ends_with($k, '.tenant_id') || str_ends_with($k, '.account_id')) Settings::set(substr($k, 0, strrpos($k, '.')) . '.tok', ''); }
            else Settings::set($k, $v);
            $changed[] = $k;
        }
        Audit::log('update', 'exchanges', $section, null, ['keys' => $changed]);   // jamais les valeurs (secrets)
        flash('Réglages « ' . self::SECTIONS[$section][0] . ' » enregistrés.'); redirect('admin/exchanges#' . $section);
    }
    function test(string $provider): void {
        if (!in_array($provider, ['teams', 'zoom', 'wa'], true)) { $this->notFound(); return; } [$ok, $msg] = Integ::test($provider); Audit::log('test', 'exchanges', $provider, null, ['ok' => $ok]);
        flash(($ok ? '✔ ' : '✘ ') . $msg, $ok ? 'success' : 'danger'); redirect('admin/exchanges#' . $provider);
    }
    function flushQueues(): void {
        [$a, $b] = \App\Core\Wa::flush(); flash("WhatsApp : $a envoyé(s), $b en échec."); redirect('admin/exchanges#wa');
    }
}
