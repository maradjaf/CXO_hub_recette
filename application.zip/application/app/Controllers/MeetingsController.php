<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Inc, Integ, Meet, Sms, Tickets, Xchg};

/** Appels / visioconférences planifiés depuis un incident ou un ticket. */
class MeetingsController extends Controller {
    private function ent(string $module, int $id): ?array { return self::access($module, $id); }
    /** Vrai (données de l'entité) si l'utilisateur courant peut voir l'incident / le ticket. */
    static function access(string $module, int $id): ?array {
        $e = Meet::entity($module, $id); if (!$e) return null;
        if ($module === 'el') { $t = DB::one('SELECT user_id FROM el_threads WHERE id=?', [$id]); return $t && ((int)$t['user_id'] === (int)Auth::id() || can('elearn.manage')) ? $e : null; }
        if ($module === 'inc') { $i = DB::one('SELECT * FROM inc_incidents WHERE id=?', [$id]); return IncFilesController::sees($i) ? $e : null; }
        $t = DB::one('SELECT requester_id, assignee_id FROM at_tickets WHERE id=?', [$id]); $me = (int)Auth::id();
        return can('at.handle') || can('scope.all') || (int)$t['requester_id'] === $me || (int)$t['assignee_id'] === $me || DB::val("SELECT 1 FROM meetings m JOIN meeting_guests g ON g.meeting_id=m.id WHERE m.module='at' AND m.ref_id=? AND g.user_id=?", [$id, $me]) ? $e : null;
    }
    private function meeting(string $mid): ?array { return DB::one('SELECT * FROM meetings WHERE id=?', [(int)$mid]) ?: null; }
    private function isMine(array $m): bool { return (int)$m['organizer_id'] === (int)Auth::id() || (bool)DB::val('SELECT 1 FROM meeting_guests WHERE meeting_id=? AND user_id=?', [(int)$m['id'], (int)Auth::id()]); }
    private function log(array $m, string $txt): void {
        if ($m['module'] === 'inc') Inc::event((int)$m['ref_id'], 'appel', $txt, Auth::id()); else Tickets::event((int)$m['ref_id'], 'meeting', $txt, Auth::id());
    }
    private function backTo(string $module, int $id): never { redirect(($module === 'inc' ? (can('inc.declare') ? 'incidents/' : 'support/incidents/') : 'at/') . $id . '#appels'); }
    /** Lit et valide le formulaire. @return array{0:?array,1:array,2:array} données, invités, erreurs */
    private function read(string $module, int $id, ?array $cur = null): array {
        $err = []; $p = $cur && $cur['auto'] ? $cur['platform'] : trim((string)$this->in('platform')); $auto = !$cur && (string)$this->in('auto_link') === '1' && Meet::autoCapable($p);
        if (!isset(Meet::platforms()[$p]) && !($cur && $cur['platform'] === $p)) $err[] = 'Cet outil de réunion n\'est pas activé.'; $title = trim((string)$this->in('title')); $link = trim((string)$this->in('link')); $dial = trim((string)$this->in('dial_in'));
        $date = (string)$this->in('date'); $time = (string)$this->in('time'); $dur = (int)$this->in('duration_min', 30); $agenda = trim((string)$this->in('agenda'));
        if ($title === '') $err[] = 'Indiquez l\'objet de l\'appel.';
        if ($cur && $cur['auto']) { $link = $cur['link']; } elseif (!$auto && ($e = Meet::linkError($p, $link, $dial))) $err[] = $e;
        $ts = strtotime($date . ' ' . $time); if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !preg_match('/^\d{2}:\d{2}$/', $time) || !$ts) $err[] = 'Date ou heure invalide.'; elseif ($ts < time() - 60) $err[] = 'La date de l\'appel doit être dans le futur.';
        if ($dur < 5 || $dur > 480) $err[] = 'Durée : entre 5 et 480 minutes.';
        $cand = []; foreach (Meet::candidates($module, $id) as $c) $cand[$c['key']] = $c; $guests = [];
        foreach ((array)$this->in('guests', []) as $k) if (isset($cand[$k])) { $c = $cand[$k]; $guests[] = ['user_id' => $c['user_id'], 'member_id' => $c['member_id'], 'name' => $c['name'], 'email' => $c['email'], 'phone' => $c['phone'] ? (Sms::normalize($c['phone']) ?: null) : null]; }
        [$extra, $e2] = Meet::parseExtra((string)$this->in('extra')); $err = array_merge($err, $e2); $guests = array_merge($guests, $extra);
        if (!$guests && !$e2) $err[] = 'Sélectionnez au moins un participant.';
        if (count($guests) > Xchg::int('meet.max_guests', 1, 200)) $err[] = 'Maximum ' . Xchg::int('meet.max_guests', 1, 200) . ' participants.';
        return [$err ? null : ['auto_req' => $auto, 'platform' => $p, 'title' => mb_substr($title, 0, 190), 'link' => mb_substr($link, 0, 500), 'dial_in' => mb_substr($dial, 0, 120), 'start_at' => date('Y-m-d H:i:s', (int)$ts), 'duration_min' => $dur, 'agenda' => mb_substr($agenda, 0, 1000)], $guests, $err];
    }
    function store(string $module, string $id): void {
        $e = $this->ent($module, (int)$id); if (!$e) { $this->notFound(); return; } if (!Meet::canManage($module)) { $this->forbidden(); return; }
        [$d, $guests, $err] = $this->read($module, (int)$id);
        if ($err) { flash(implode(' ', $err), 'danger'); $this->backTo($module, (int)$id); }
        $auto = $d['auto_req']; unset($d['auto_req']); $pid = null;
        if ($auto) { try { [$lnk, $pid, $dial] = Integ::createMeeting($d['platform'], $d['title'], $d['start_at'], (int)$d['duration_min'], $d['agenda']); $d['link'] = mb_substr($lnk, 0, 500); if ($dial !== '') $d['dial_in'] = mb_substr(trim($d['dial_in'] . ' ' . $dial), 0, 200); }
            catch (\Throwable $x) { flash('Création automatique impossible — ' . $x->getMessage() . ' Vérifiez la configuration ou collez le lien manuellement.', 'danger'); $this->backTo($module, (int)$id); } }
        $mid = DB::insert('meetings', $d + ['provider_id' => $pid, 'auto' => $auto ? 1 : 0, 'module' => $module, 'ref_id' => (int)$id, 'status' => 'planned', 'organizer_id' => Auth::id(), 'seq' => 0, 'reminder_sent' => 0, 'created_at' => now(), 'updated_at' => now()]);
        foreach ($guests as $g) DB::insert('meeting_guests', $g + ['meeting_id' => $mid, 'n_inapp' => 'skipped', 'n_email' => 'skipped', 'n_sms' => 'skipped', 'created_at' => now()]);
        $n = Meet::notify((int)$mid, 'INVITATION'); $m = $this->meeting((string)$mid);
        $this->log($m, 'Appel planifié (' . Meet::label($d['platform']) . ') : ' . $d['title'] . ' — ' . Meet::when($m) . ' — ' . count($guests) . ' participant(s) invité(s).');
        Audit::log('create', 'meeting', (string)$mid, null, ['module' => $module, 'ref' => $e['ref'], 'guests' => count($guests)]);
        flash("Appel planifié. Invitation envoyée à $n participant(s) (outil, e-mail et SMS selon les coordonnées disponibles).");
        $this->backTo($module, (int)$id);
    }
    private function owned(string $mid): ?array {
        $m = $this->meeting($mid); if (!$m || !$this->ent($m['module'], (int)$m['ref_id'])) { $this->notFound(); return null; }
        if (!Meet::canManage($m['module'])) { $this->forbidden(); return null; } return $m;
    }
    function update(string $mid): void {
        $m = $this->owned($mid); if (!$m) return; if ($m['status'] !== 'planned') { flash('Cet appel n\'est plus modifiable.', 'warning'); $this->backTo($m['module'], (int)$m['ref_id']); }
        [$d, $guests, $err] = $this->read($m['module'], (int)$m['ref_id'], $m);
        if ($err) { flash(implode(' ', $err), 'danger'); $this->backTo($m['module'], (int)$m['ref_id']); }
        unset($d['auto_req']); $warn = '';
        if ($m['auto'] && $m['provider_id']) { try { Integ::updateMeeting($m['platform'], $m['provider_id'], $d['title'], $d['start_at'], (int)$d['duration_min'], $d['agenda']); } catch (\Throwable $x) { $warn = ' Attention : ' . $x->getMessage(); } }
        DB::update('meetings', $d + ['seq' => (int)$m['seq'] + 1, 'reminder_sent' => 0, 'updated_at' => now()], 'id=?', [(int)$mid]);
        // Les invités conservés gardent leur ligne ; les retirés reçoivent une annulation ; les nouveaux, une invitation.
        $old = DB::all('SELECT * FROM meeting_guests WHERE meeting_id=?', [(int)$mid]); $sig = fn($g) => ($g['user_id'] ? 'u' . $g['user_id'] : ($g['member_id'] ? 'm' . $g['member_id'] : strtolower((string)$g['email']) . '|' . $g['phone']));
        $newSig = array_map($sig, $guests); $removed = array_filter($old, fn($g) => !in_array($sig($g), $newSig, true));
        if ($removed) { $keep = array_diff_key($old, $removed); $tmp = DB::one('SELECT * FROM meetings WHERE id=?', [(int)$mid]);
            DB::update('meetings', ['status' => 'cancelled'], 'id=?', [(int)$mid]); // annulation envoyée aux seuls retirés
            foreach ($removed as $g) Meet::notify((int)$mid, 'ANNULATION', (int)$g['id']);
            DB::update('meetings', ['status' => 'planned'], 'id=?', [(int)$mid]); foreach ($removed as $g) DB::exec('DELETE FROM meeting_guests WHERE id=?', [(int)$g['id']]); }
        $have = array_map($sig, DB::all('SELECT * FROM meeting_guests WHERE meeting_id=?', [(int)$mid]));
        foreach ($guests as $g) if (!in_array($sig($g), $have, true)) DB::insert('meeting_guests', $g + ['meeting_id' => (int)$mid, 'n_inapp' => 'skipped', 'n_email' => 'skipped', 'n_sms' => 'skipped', 'created_at' => now()]);
        $n = Meet::notify((int)$mid, 'MODIFICATION'); $m = $this->meeting($mid);
        $this->log($m, 'Appel modifié / reprogrammé : ' . $m['title'] . ' — ' . Meet::when($m) . '.'); Audit::log('update', 'meeting', $mid, null, ['guests' => $n]);
        flash("Appel mis à jour ; $n participant(s) prévenu(s)." . $warn, $warn ? 'warning' : 'success'); $this->backTo($m['module'], (int)$m['ref_id']);
    }
    function cancel(string $mid): void {
        $m = $this->owned($mid); if (!$m) return; if ($m['status'] !== 'planned') { flash('Appel déjà clos.', 'warning'); $this->backTo($m['module'], (int)$m['ref_id']); }
        DB::update('meetings', ['status' => 'cancelled', 'cancelled_at' => now(), 'seq' => (int)$m['seq'] + 1, 'updated_at' => now()], 'id=?', [(int)$mid]);
        $warn = ''; if ($m['auto'] && $m['provider_id']) { try { Integ::deleteMeeting($m['platform'], $m['provider_id']); } catch (\Throwable $x) { $warn = ' Attention : ' . $x->getMessage(); } }
        $n = Meet::notify((int)$mid, 'ANNULATION'); $this->log($m, 'Appel annulé : ' . $m['title'] . '.'); Audit::log('cancel', 'meeting', $mid, null, ['guests' => $n]);
        flash("Appel annulé ; $n participant(s) prévenu(s)." . $warn, $warn ? 'warning' : 'success'); $this->backTo($m['module'], (int)$m['ref_id']);
    }
    function done(string $mid): void {
        $m = $this->owned($mid); if (!$m) return; DB::update('meetings', ['status' => 'done', 'updated_at' => now()], 'id=?', [(int)$mid]);
        $this->log($m, 'Appel tenu : ' . $m['title'] . '.'); flash('Appel marqué comme tenu.'); $this->backTo($m['module'], (int)$m['ref_id']);
    }
    function resend(string $mid): void {
        $m = $this->owned($mid); if (!$m) return; if ($m['status'] !== 'planned') { flash('Appel clos.', 'warning'); $this->backTo($m['module'], (int)$m['ref_id']); }
        $n = Meet::notify((int)$mid, 'INVITATION'); Audit::log('resend', 'meeting', $mid, null, ['guests' => $n]); flash("Invitation renvoyée à $n participant(s)."); $this->backTo($m['module'], (int)$m['ref_id']);
    }
    function ics(string $mid): void {
        $m = $this->meeting($mid); if (!$m || !$this->ent($m['module'], (int)$m['ref_id']) || !($this->isMine($m) || Meet::canManage($m['module']))) { $this->notFound(); return; }
        header('Content-Type: text/calendar; charset=utf-8'); header('Content-Disposition: attachment; filename="appel-' . (int)$m['id'] . '.ics"'); header('X-Content-Type-Options: nosniff');
        echo Meet::ics($m, DB::all('SELECT * FROM meeting_guests WHERE meeting_id=?', [(int)$mid]), $m['status'] === 'cancelled' ? 'CANCEL' : 'REQUEST'); exit;
    }
    /** « Mes appels » : réunions à venir où je suis organisateur ou invité. */
    function index(): void {
        $me = (int)Auth::id(); $rows = DB::all("SELECT DISTINCT m.* FROM meetings m LEFT JOIN meeting_guests g ON g.meeting_id=m.id WHERE m.status='planned' AND m.start_at>=? AND (m.organizer_id=? OR g.user_id=?) ORDER BY m.start_at", [date('Y-m-d H:i:s', time() - 3600), $me, $me]);
        foreach ($rows as &$r) { $r['ent'] = Meet::entity($r['module'], (int)$r['ref_id']); $r['organizer'] = DB::val('SELECT name FROM users WHERE id=?', [(int)$r['organizer_id']]); } unset($r);
        $past = DB::all("SELECT DISTINCT m.* FROM meetings m LEFT JOIN meeting_guests g ON g.meeting_id=m.id WHERE (m.status<>'planned' OR m.start_at<?) AND (m.organizer_id=? OR g.user_id=?) ORDER BY m.start_at DESC LIMIT 15", [date('Y-m-d H:i:s', time() - 3600), $me, $me]);
        foreach ($past as &$r) $r['ent'] = Meet::entity($r['module'], (int)$r['ref_id']); unset($r);
        $this->view('meetings/index', ['title' => 'Mes appels', 'rows' => $rows, 'past' => $past]);
    }
}
