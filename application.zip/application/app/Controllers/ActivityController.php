<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Activity};
/** Consultation de l'historique d'activité (rôles Administrateur de sécurité et Auditeur). Chaque consultation et export est journalisé. */
class ActivityController extends Controller {
    private function where(): array {
        $w = ['1=1']; $p = [];
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(user_name LIKE ? OR url LIKE ?)'; array_push($p, "%$q%", "%$q%"); }
        foreach (['event_type', 'module', 'result', 'network', 'device', 'menu_code'] as $f) if ($this->in($f)) { $w[] = "$f=?"; $p[] = $this->in($f); }
        if ($this->in('user_id')) { $w[] = 'user_id=?'; $p[] = (int)$this->in('user_id'); }
        if ($this->in('ip')) { $w[] = 'ip LIKE ?'; $p[] = $this->in('ip') . '%'; }
        if ($this->in('city')) { $w[] = 'city LIKE ?'; $p[] = '%' . $this->in('city') . '%'; }
        $days = (int)$this->in('last_days', 0);
        if ($days > 0) { $w[] = 'created_at>=?'; $p[] = date('Y-m-d 00:00:00', strtotime("-$days days")); }
        else {
            if ($this->in('from')) { $w[] = 'created_at>=?'; $p[] = $this->in('from') . ' 00:00:00'; }
            if ($this->in('to')) { $w[] = 'created_at<=?'; $p[] = $this->in('to') . ' 23:59:59'; }
        }
        return [implode(' AND ', $w), $p];
    }
    function index(): void {
        [$w, $p] = $this->where();
        $pg = paginate("user_activity_events WHERE $w", $p, $this->page(), 50, '*', 'id DESC');
        $since = date('Y-m-d H:i:s', strtotime('-30 days'));
        $stats = [
            'topPages' => DB::all("SELECT url, COUNT(*) n FROM user_activity_events WHERE event_type='page_view' AND created_at>=? GROUP BY url ORDER BY n DESC LIMIT 8", [$since]),
            'topMenus' => DB::all("SELECT menu_code, COUNT(*) n FROM user_activity_events WHERE menu_code IS NOT NULL AND created_at>=? GROUP BY menu_code ORDER BY n DESC LIMIT 8", [$since]),
            'unused' => DB::all("SELECT m.label FROM menu_items m WHERE m.active=1 AND m.url IS NOT NULL AND m.code NOT IN (SELECT DISTINCT menu_code FROM user_activity_events WHERE menu_code IS NOT NULL AND created_at>=?) ORDER BY m.label", [$since]),
            'perDay' => DB::all("SELECT SUBSTR(created_at,1,10) day, COUNT(*) n, COUNT(DISTINCT user_id) u FROM user_activity_events WHERE created_at>=? GROUP BY SUBSTR(created_at,1,10) ORDER BY day DESC LIMIT 14", [date('Y-m-d H:i:s', strtotime('-14 days'))]),
            'newPlaces' => DB::all("SELECT user_name, city, MIN(created_at) first_seen, COUNT(*) n FROM user_activity_events WHERE event_type='login' AND city IS NOT NULL AND created_at>=? GROUP BY user_id, user_name, city HAVING MIN(created_at)>=? ORDER BY first_seen DESC LIMIT 8", [$since, date('Y-m-d H:i:s', strtotime('-7 days'))]),
        ];
        Audit::log('view', 'activity_history', null, null, ['filters' => $_GET]);
        $this->view('admin/activity/index', ['title' => 'Historique d\'activité', 'p' => $pg, 'stats' => $stats,
            'types' => array_column(DB::all('SELECT DISTINCT event_type FROM user_activity_events ORDER BY event_type'), 'event_type'),
            'modules' => array_column(DB::all('SELECT DISTINCT module FROM user_activity_events WHERE module IS NOT NULL ORDER BY module'), 'module'),
            'users' => DB::all('SELECT id, name FROM users ORDER BY name')]);
    }
    function user(string $id): void {
        $u = DB::one('SELECT * FROM users WHERE id=?', [(int)$id]); if (!$u) { $this->notFound(); return; }
        $pg = paginate('user_activity_events WHERE user_id=?', [(int)$id], $this->page(), 50, '*', 'id DESC');
        $sessions = DB::all('SELECT session_hash, MIN(created_at) first, MAX(created_at) last, COUNT(*) n, MAX(ip) ip, MAX(city) city, MAX(device) device, MAX(browser) browser FROM user_activity_events WHERE user_id=? AND session_hash IS NOT NULL GROUP BY session_hash ORDER BY first DESC LIMIT 10', [(int)$id]);
        Audit::log('view', 'user_activity', $id);
        $this->view('admin/activity/user', ['title' => 'Activité de ' . $u['name'], 'u' => $u, 'p' => $pg, 'sessions' => $sessions]);
    }
    function export(): void {
        [$w, $p] = $this->where();
        $rows = DB::all("SELECT created_at, user_name, role_code, event_type, module, menu_code, url, method, status_code, result, duration_ms, ip, country, city, network, device, os, browser FROM user_activity_events WHERE $w ORDER BY id DESC LIMIT 50000", $p);
        Audit::log('export', 'activity_history', null, null, ['rows' => count($rows), 'filters' => $_GET]);
        Activity::event('export', ['module' => 'activity', 'route' => '/admin/activity/export', 'status_code' => 200]);
        Activity::skipRequest();
        csv_download('historique_activite_' . date('Ymd_His') . '.csv', ['Date', 'Utilisateur', 'Rôle', 'Événement', 'Module', 'Menu', 'URL', 'Méthode', 'Code HTTP', 'Résultat', 'Durée (ms)', 'IP', 'Pays', 'Ville', 'Réseau', 'Appareil', 'Système', 'Navigateur'], $rows);
    }

    // ---------- Sessions : connexions / déconnexions ----------
    private function sessFrom(): array {
        $w = ['1=1']; $p = [];
        if ($this->in('user_id')) { $w[] = 'user_id=?'; $p[] = (int)$this->in('user_id'); }
        if ($this->in('ip')) { $w[] = 'ip LIKE ?'; $p[] = $this->in('ip') . '%'; }
        if ($this->in('city')) { $w[] = '(city LIKE ? OR country LIKE ?)'; array_push($p, '%' . $this->in('city') . '%', '%' . $this->in('city') . '%'); }
        if ($this->in('from')) { $w[] = 'first_at>=?'; $p[] = $this->in('from') . ' 00:00:00'; }
        if ($this->in('to')) { $w[] = 'first_at<=?'; $p[] = $this->in('to') . ' 23:59:59'; }
        if ($this->in('state') === 'closed') $w[] = 'logout_at IS NOT NULL'; elseif ($this->in('state') === 'open') $w[] = 'logout_at IS NULL';
        $sub = "(SELECT session_hash, user_id, MAX(user_name) user_name, MIN(created_at) first_at, MAX(created_at) last_at, COUNT(*) n, MIN(CASE WHEN event_type='login' THEN created_at END) login_at, MIN(CASE WHEN event_type='logout' THEN created_at END) logout_at, MAX(ip) ip, MAX(city) city, MAX(country) country, MAX(device) device, MAX(os) os, MAX(browser) browser FROM user_activity_events WHERE session_hash IS NOT NULL AND user_id IS NOT NULL GROUP BY session_hash, user_id) s";
        return ["$sub WHERE " . implode(' AND ', $w), $p];
    }
    function sessions(): void {
        [$from, $p] = $this->sessFrom();
        $pg = paginate($from, $p, $this->page(), 50, '*', 'first_at DESC');
        Audit::log('view', 'sessions', null, null, ['filters' => $_GET]);
        $this->view('admin/activity/sessions', ['title' => 'Connexions et sessions', 'p' => $pg, 'users' => DB::all('SELECT id, name FROM users ORDER BY name')]);
    }
    function sessionsExport(): void {
        [$from, $p] = $this->sessFrom();
        $rows = DB::all("SELECT user_name, login_at, logout_at, first_at, last_at, n, ip, city, country, device, os, browser FROM $from ORDER BY first_at DESC LIMIT 50000", $p);
        foreach ($rows as &$r) { $r['duree_min'] = (string)round((strtotime($r['logout_at'] ?: $r['last_at']) - strtotime($r['first_at'])) / 60); } unset($r);
        Audit::log('export', 'sessions', null, null, ['rows' => count($rows)]); Activity::skipRequest();
        csv_download('sessions_' . date('Ymd_His') . '.csv', ['Utilisateur', 'Connexion', 'Déconnexion', 'Première action', 'Dernière action', 'Actions', 'IP', 'Ville', 'Pays', 'Appareil', 'Système', 'Navigateur', 'Durée (min)'], $rows);
    }

    // ---------- Sécurité : échecs, intrusions, accès refusés ----------
    const REASONS = ['unknown_account' => 'Compte inconnu', 'blocked_account' => 'Compte bloqué', 'inactive_account' => 'Compte désactivé', 'brute_force' => 'Force brute (échecs répétés)', 'csrf' => 'Jeton de formulaire invalide', 'reset_unknown' => 'Réinitialisation : compte inconnu', 'reset_flood' => 'Réinitialisation : demandes répétées', 'reset_bad_token' => 'Lien de réinitialisation invalide'];
    private function secWhere(): array {
        $kind = $this->in('kind');
        $w = [$kind === 'login_failed' ? "event_type='login_failed'" : ($kind === 'intrusion' ? "event_type='intrusion'" : ($kind === 'denied' ? "event_type='denied'" : "event_type IN ('login_failed','intrusion','denied')"))]; $p = [];
        if ($this->in('reason')) { $w[] = 'object_type=?'; $p[] = $this->in('reason'); }
        if ($this->in('ip')) { $w[] = 'ip LIKE ?'; $p[] = $this->in('ip') . '%'; }
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(user_name LIKE ? OR object_id LIKE ? OR url LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        if ($this->in('from')) { $w[] = 'created_at>=?'; $p[] = $this->in('from') . ' 00:00:00'; }
        if ($this->in('to')) { $w[] = 'created_at<=?'; $p[] = $this->in('to') . ' 23:59:59'; }
        return [implode(' AND ', $w), $p];
    }
    function security(): void {
        [$w, $p] = $this->secWhere();
        $pg = paginate("user_activity_events WHERE $w", $p, $this->page(), 50, '*', 'id DESC');
        $since = date('Y-m-d H:i:s', strtotime('-7 days'));
        $stats = [
            'failed' => (int)DB::val("SELECT COUNT(*) FROM user_activity_events WHERE event_type='login_failed' AND created_at>=?", [$since]),
            'intrusions' => (int)DB::val("SELECT COUNT(*) FROM user_activity_events WHERE event_type='intrusion' AND created_at>=?", [$since]),
            'denied' => (int)DB::val("SELECT COUNT(*) FROM user_activity_events WHERE event_type='denied' AND created_at>=?", [$since]),
            'topIps' => DB::all("SELECT ip, COUNT(*) n, MAX(city) city, MAX(created_at) last_at FROM user_activity_events WHERE event_type IN ('login_failed','intrusion') AND ip IS NOT NULL AND created_at>=? GROUP BY ip ORDER BY n DESC LIMIT 8", [$since]),
            'byReason' => DB::all("SELECT object_type reason, COUNT(*) n FROM user_activity_events WHERE event_type='intrusion' AND created_at>=? GROUP BY object_type ORDER BY n DESC", [$since]),
            'blocked' => DB::all("SELECT id, name, blocked_reason, blocked_at FROM users WHERE status='blocked' ORDER BY blocked_at DESC LIMIT 10"),
            'locked' => DB::all("SELECT id, name, locked_until FROM users WHERE locked_until>? ORDER BY locked_until DESC LIMIT 10", [now()]),
        ];
        Audit::log('view', 'security_journal', null, null, ['filters' => $_GET]);
        $this->view('admin/activity/security', ['title' => 'Sécurité : échecs et intrusions', 'p' => $pg, 'stats' => $stats, 'reasons' => self::REASONS]);
    }
    function securityExport(): void {
        [$w, $p] = $this->secWhere();
        $rows = DB::all("SELECT created_at, event_type, object_type, object_id, user_name, ip, country, city, network, device, os, browser, url, result FROM user_activity_events WHERE $w ORDER BY id DESC LIMIT 50000", $p);
        foreach ($rows as &$r) $r['object_type'] = self::REASONS[$r['object_type']] ?? $r['object_type']; unset($r);
        Audit::log('export', 'security_journal', null, null, ['rows' => count($rows)]); Activity::skipRequest();
        csv_download('securite_' . date('Ymd_His') . '.csv', ['Date', 'Type', 'Motif', 'Cible', 'Utilisateur', 'IP', 'Pays', 'Ville', 'Réseau', 'Appareil', 'Système', 'Navigateur', 'URL', 'Résultat'], $rows);
    }
}
