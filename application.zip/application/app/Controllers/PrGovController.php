<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Pr, Pm};

/** Lot 58 : gouvernance d'un processus (direction, criticité, amélioration), sous-fiches risques et KPI avec mesures. */
class PrGovController extends Controller {
    private function load(string $id, bool $edit = true): ?array {
        $p = DB::one('SELECT * FROM pr_processes WHERE id=?', [(int)$id]); if (!$p || !Pr::canSee($p)) { $this->notFound(); return null; }
        if ($edit && !Pr::canEdit($p) && !Pr::isOwner($p) && !can('pr.manage')) { $this->forbidden(); return null; } return $p;
    }
    static function gov(int $pid): array { return DB::one('SELECT * FROM pr_gov WHERE process_id=?', [$pid]) ?: ['direction' => null, 'activity' => null, 'criticality' => null, 'upstream' => null, 'downstream' => null, 'improve' => 0, 'improve_note' => null, 'last_review_at' => null]; }
    /** Enregistre les champs de gouvernance postés avec la fiche (appelé par PrController). Retourne une erreur éventuelle. */
    static function save(int $pid, array $in): ?string {
        $crit = (string)($in['criticality'] ?? ''); if ($crit !== '' && !isset(Pm::CRIT[$crit])) return 'Criticité invalide.';
        $d = ['direction' => mb_substr(trim((string)($in['direction'] ?? '')), 0, 100) ?: null, 'activity' => mb_substr(trim((string)($in['activity'] ?? '')), 0, 150) ?: null, 'criticality' => $crit ?: null, 'upstream' => mb_substr(trim((string)($in['upstream'] ?? '')), 0, 300) ?: null, 'downstream' => mb_substr(trim((string)($in['downstream'] ?? '')), 0, 300) ?: null,
              'improve' => !empty($in['improve']) ? 1 : 0, 'improve_note' => mb_substr(trim((string)($in['improve_note'] ?? '')), 0, 500) ?: null, 'updated_at' => now()];
        if ($d['improve'] && !$d['improve_note']) return 'Précisez le besoin de simplification.';
        if ($cur = DB::one('SELECT id FROM pr_gov WHERE process_id=?', [$pid])) DB::update('pr_gov', $d, 'id=?', [(int)$cur['id']]); else DB::insert('pr_gov', $d + ['process_id' => $pid]);
        return null;
    }
    // ---- risques ----
    private function riskData(): array {
        $t = trim((string)$this->in('title', '')); $err = []; if ($t === '' || mb_strlen($t) > 200) $err[] = 'L\'intitulé du risque est obligatoire (200 caractères au plus).';
        $sev = (int)$this->in('severity', 2); $prob = (int)$this->in('probability', 2); if ($sev < 1 || $sev > 4 || $prob < 1 || $prob > 4) $err[] = 'Gravité et probabilité vont de 1 à 4.';
        $res = (string)$this->in('residual', ''); $res = $res === '' ? null : (int)$res; if ($res !== null && ($res < 1 || $res > 16)) $err[] = 'Le niveau résiduel va de 1 à 16.';
        $due = (string)$this->in('due', ''); if ($due !== '' && !strtotime($due)) $err[] = 'Échéance invalide.'; $st = (string)$this->in('status', 'open'); if (!isset(Pm::RISK_ST[$st])) $st = 'open';
        $own = (int)$this->in('owner_id') ?: null; if ($own && !DB::val('SELECT 1 FROM users WHERE id=?', [$own])) $own = null;
        return [['title' => $t, 'step_label' => mb_substr(trim((string)$this->in('step_label', '')), 0, 150) ?: null, 'severity' => $sev, 'probability' => $prob, 'residual' => $res, 'control_txt' => mb_substr(trim((string)$this->in('control_txt', '')), 0, 500) ?: null, 'owner_id' => $own, 'due' => $due ?: null, 'status' => $st, 'updated_at' => now()], $err];
    }
    function storeRisk(string $id): void { if (!($p = $this->load($id))) return; [$d, $err] = $this->riskData(); if ($err) { flash(implode(' ', $err), 'danger'); redirect("pr/p/$id#risques"); }
        $rid = DB::insert('pr_risks', $d + ['process_id' => (int)$id, 'created_at' => now()]); Audit::log('create', 'pr_risk', $rid, null, ['process' => $p['code'], 'title' => $d['title']]); flash('Risque enregistré.'); redirect("pr/p/$id#risques"); }
    function updateRisk(string $id, string $rid): void { if (!($p = $this->load($id))) return; $r = DB::one('SELECT * FROM pr_risks WHERE id=? AND process_id=?', [(int)$rid, (int)$id]); if (!$r) { $this->notFound(); return; }
        if ($this->in('act') === 'delete') { DB::exec('DELETE FROM pr_risks WHERE id=?', [(int)$rid]); Audit::log('delete', 'pr_risk', (int)$rid, $r, null); flash('Risque supprimé.'); redirect("pr/p/$id#risques"); }
        [$d, $err] = $this->riskData(); if ($err) { flash(implode(' ', $err), 'danger'); redirect("pr/p/$id#risques"); } DB::update('pr_risks', $d, 'id=?', [(int)$rid]); Audit::log('update', 'pr_risk', (int)$rid, $r, $d); flash('Risque mis à jour.'); redirect("pr/p/$id#risques"); }
    // ---- KPI et mesures ----
    private function kpiData(): array {
        $n = trim((string)$this->in('name', '')); $err = []; if ($n === '' || mb_strlen($n) > 150) $err[] = 'Le nom du KPI est obligatoire (150 caractères au plus).';
        $tg = (string)$this->in('target', ''); if ($tg !== '' && !is_numeric(str_replace(',', '.', $tg))) $err[] = 'Cible numérique attendue.';
        $b = (string)$this->in('better', 'up'); if (!in_array($b, ['up', 'down'], true)) $b = 'up'; $per = (string)$this->in('period', 'month'); if (!in_array($per, ['week', 'month', 'quarter', 'year'], true)) $per = 'month';
        $own = (int)$this->in('owner_id') ?: null; if ($own && !DB::val('SELECT 1 FROM users WHERE id=?', [$own])) $own = null;
        return [['name' => $n, 'formula' => mb_substr(trim((string)$this->in('formula', '')), 0, 300) ?: null, 'unit' => mb_substr(trim((string)$this->in('unit', '')), 0, 20) ?: null, 'target' => $tg === '' ? null : (float)str_replace(',', '.', $tg), 'better' => $b, 'period' => $per, 'source' => mb_substr(trim((string)$this->in('source', '')), 0, 150) ?: null, 'owner_id' => $own], $err];
    }
    function storeKpi(string $id): void { if (!($p = $this->load($id))) return; [$d, $err] = $this->kpiData(); if ($err) { flash(implode(' ', $err), 'danger'); redirect("pr/p/$id#kpi"); }
        $k = DB::insert('pr_kpis', $d + ['process_id' => (int)$id, 'active' => 1, 'created_at' => now()]); Audit::log('create', 'pr_kpi', $k, null, ['process' => $p['code'], 'name' => $d['name']]); flash('KPI enregistré.'); redirect("pr/p/$id#kpi"); }
    function updateKpi(string $id, string $kid): void { if (!($p = $this->load($id))) return; $k = DB::one('SELECT * FROM pr_kpis WHERE id=? AND process_id=?', [(int)$kid, (int)$id]); if (!$k) { $this->notFound(); return; }
        if ($this->in('act') === 'toggle') { DB::update('pr_kpis', ['active' => $k['active'] ? 0 : 1], 'id=?', [(int)$kid]); flash($k['active'] ? 'KPI désactivé.' : 'KPI réactivé.'); redirect("pr/p/$id#kpi"); }
        [$d, $err] = $this->kpiData(); if ($err) { flash(implode(' ', $err), 'danger'); redirect("pr/p/$id#kpi"); } DB::update('pr_kpis', $d, 'id=?', [(int)$kid]); Audit::log('update', 'pr_kpi', (int)$kid, $k, $d); flash('KPI mis à jour.'); redirect("pr/p/$id#kpi"); }
    function storeMeasure(string $id, string $kid): void {
        if (!($p = $this->load($id))) return; $k = DB::one('SELECT * FROM pr_kpis WHERE id=? AND process_id=?', [(int)$kid, (int)$id]); if (!$k) { $this->notFound(); return; }
        $per = trim((string)$this->in('period', '')); $v = str_replace(',', '.', (string)$this->in('value', '')); $den = str_replace(',', '.', (string)$this->in('denominator', ''));
        if (!preg_match('/^\d{4}(-\d{2})?(-T[1-4])?(-S\d{2})?$/', $per)) { flash('Période attendue : AAAA, AAAA-MM, AAAA-T1 ou AAAA-S05.', 'danger'); redirect("pr/p/$id#kpi"); }
        if (!is_numeric($v)) { flash('Valeur numérique attendue.', 'danger'); redirect("pr/p/$id#kpi"); } if ($den !== '' && (!is_numeric($den) || (float)$den <= 0)) { flash('Dénominateur numérique positif attendu.', 'danger'); redirect("pr/p/$id#kpi"); }
        $data = ['value' => (float)$v, 'denominator' => $den === '' ? null : (float)$den, 'note' => mb_substr(trim((string)$this->in('note', '')), 0, 300) ?: null, 'user_id' => Auth::id(), 'created_at' => now()];
        if ($cur = DB::one('SELECT id FROM pr_kpi_measures WHERE kpi_id=? AND period=?', [(int)$kid, $per])) DB::update('pr_kpi_measures', $data, 'id=?', [(int)$cur['id']]); else DB::insert('pr_kpi_measures', $data + ['kpi_id' => (int)$kid, 'period' => $per]);
        Audit::log('update', 'pr_kpi', (int)$kid, null, ['period' => $per, 'value' => (float)$v]); flash('Mesure enregistrée.'); redirect("pr/p/$id#kpi");
    }
}
