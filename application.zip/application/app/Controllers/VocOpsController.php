<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Voc};

/** Lot 59 — Voix du client : sorties terrain, Loop Close Feedback, plans d'action, étapes et journal. */
class VocOpsController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    private function fail(string $back, string $msg): never { $_SESSION['_old'] = $_POST; $this->go($back, $msg, 'danger'); }
    private function s(string $k, int $max = 150): ?string { $v = mb_substr(trim((string)$this->in($k, '')), 0, $max); return $v === '' ? null : $v; }
    private function day(string $k): ?string { $v = trim((string)$this->in($k, '')); return Voc::isDay($v) ? $v : null; }
    private function int(string $k, int $lo, int $hi): ?int { $v = trim((string)$this->in($k, '')); return $v !== '' && ctype_digit($v) && (int)$v >= $lo && (int)$v <= $hi ? (int)$v : null; }
    private function backTo(string $default): string { $b = (string)$this->in('back', ''); return preg_match('#^voc/[A-Za-z0-9/_?=&%.\-]*$#', $b) ? $b : $default; }

    // ───────────────────────── sorties terrain ─────────────────────────
    function fieldIndex(): void {
        $stage = in_array($_GET['stage'] ?? '', Voc::FIELD_ST, true) ? $_GET['stage'] : ''; $all = DB::all('SELECT * FROM vn_field ORDER BY day DESC, id DESC');
        $this->view('voc/field_index', ['title' => 'Sorties terrain', 'all' => $all, 'rows' => array_values(array_filter($all, fn($r) => $stage === '' || $r['stage'] === $stage)), 'stage' => $stage]);
    }
    function fieldForm(string $id = ''): void {
        $r = $id !== '' ? DB::one('SELECT * FROM vn_field WHERE id=?', [(int)$id]) : null; if ($id !== '' && !$r) { $this->notFound(); return; }
        $this->view('voc/field_form', ['title' => $r ? 'Sortie terrain ' . $r['ref'] : 'Planifier une sortie terrain', 'r' => $r, 'actions' => $r ? DB::all("SELECT id, ref, title, status FROM vn_actions WHERE origin_type='field' AND origin_id=? ORDER BY id", [(int)$r['id']]) : []]);
    }
    function fieldSave(string $id = ''): void {
        $r = $id !== '' ? DB::one('SELECT * FROM vn_field WHERE id=?', [(int)$id]) : null; if ($id !== '' && !$r) { $this->notFound(); return; } $back = 'voc/field/' . ($r ? $r['id'] : 'new');
        $d = ['title' => $this->s('title'), 'day' => $this->day('day'), 'zone' => $this->s('zone'), 'owner' => $this->s('owner'), 'target' => $this->int('target', 0, 99999) ?? 0, 'completed' => $this->int('completed', 0, 99999) ?? 0,
            'stage' => in_array($this->in('stage'), Voc::FIELD_ST, true) ? $this->in('stage') : 'Planifié', 'goal' => $this->s('goal', 1500), 'report' => $this->s('report', 1500), 'updated_at' => now()];
        if (!$d['title'] || !$d['owner']) $this->fail($back, 'Renseignez l\'intitulé et le responsable.'); if (!$d['day'] || !$d['zone']) $this->fail($back, 'Renseignez la date et la zone.');
        if ($d['stage'] === 'CR validé' && !$d['report']) $this->fail($back, 'Renseignez le compte rendu avant de le valider.');
        if ($r) { DB::update('vn_field', $d, 'id=?', [(int)$r['id']]); Audit::log('update', 'vn_field', (int)$r['id'], ['stage' => $r['stage']], ['stage' => $d['stage']]); }
        else { $nid = DB::insert('vn_field', $d + ['ref' => Voc::ref('TER', 'vn_field'), 'is_demo' => 0, 'created_by' => Auth::id(), 'created_at' => now()]); Audit::log('create', 'vn_field', $nid, null, ['title' => $d['title']]); }
        $this->go('voc/field', 'Fiche enregistrée.');
    }

    // ───────────────────────── Loop Close Feedback ─────────────────────────
    function loopIndex(): void {
        $stage = in_array($_GET['stage'] ?? '', Voc::LOOP_ST, true) ? $_GET['stage'] : ''; $all = DB::all('SELECT * FROM vn_loop ORDER BY opened DESC, id DESC');
        $this->view('voc/loop_index', ['title' => 'Loop Close Feedback', 'all' => $all, 'rows' => array_values(array_filter($all, fn($r) => $stage === '' || $r['stage'] === $stage)), 'stage' => $stage, 'today' => date('Y-m-d')]);
    }
    function loopForm(string $id = ''): void {
        $r = $id !== '' ? DB::one('SELECT * FROM vn_loop WHERE id=?', [(int)$id]) : null; if ($id !== '' && !$r) { $this->notFound(); return; }
        $this->view('voc/loop_form', ['title' => $r ? 'Dossier ' . $r['ref'] : 'Créer un dossier', 'r' => $r, 'actions' => $r ? DB::all("SELECT id, ref, title, status FROM vn_actions WHERE origin_type='loop' AND origin_id=? ORDER BY id", [(int)$r['id']]) : []]);
    }
    function loopSave(string $id = ''): void {
        $r = $id !== '' ? DB::one('SELECT * FROM vn_loop WHERE id=?', [(int)$id]) : null; if ($id !== '' && !$r) { $this->notFound(); return; } $back = 'voc/loop/' . ($r ? $r['id'] : 'new');
        $d = ['source' => in_array($this->in('source'), Voc::LOOP_SRC, true) ? $this->in('source') : 'Autre', 'stage' => in_array($this->in('stage'), Voc::LOOP_ST, true) ? $this->in('stage') : 'Nouveau', 'theme' => $this->s('theme'), 'owner' => $this->s('owner'), 'ticket' => $this->s('ticket'),
            'opened' => $this->day('opened'), 'due' => $this->day('due'), 'first_contact' => $this->day('first_contact'), 'closed' => $this->day('closed'), 'score' => $this->int('score', 0, 10), 'recheck' => $this->int('recheck', 0, 10), 'attempts' => $this->int('attempts', 0, 99999) ?? 0, 'result' => $this->s('result', 1500), 'updated_at' => now()];
        if (!$d['owner']) $this->fail($back, 'Renseignez le responsable.'); if (!$d['theme']) $this->fail($back, 'Renseignez le thème du dossier.'); if (!$d['opened'] || !$d['due']) $this->fail($back, 'Renseignez la date d\'ouverture et l\'échéance de résolution.');
        if ($d['due'] < $d['opened'] || ($d['first_contact'] && $d['first_contact'] < $d['opened']) || ($d['closed'] && $d['closed'] < $d['opened'])) $this->fail($back, 'Vérifiez l\'ordre des dates du dossier.');
        if ($d['first_contact'] && $d['closed'] && $d['closed'] < $d['first_contact']) $this->fail($back, 'La clôture doit suivre le premier contact effectif.');
        if (trim((string)$this->in('score', '')) !== '' && $d['score'] === null) $this->fail($back, 'La note d\'origine doit être un entier de 0 à 10.');
        if ($d['source'] === 'CSAT Mixx' && $d['score'] !== null && ($d['score'] < 1 || $d['score'] > 5)) $this->fail($back, 'La note CSAT d\'origine doit être comprise entre 1 et 5.');
        if ($d['recheck'] !== null && $d['source'] !== 'NPS Yas') $this->fail($back, 'La réévaluation NPS est disponible pour les dossiers NPS Yas.');
        if ($d['stage'] === 'Clôturé' && (!$d['closed'] || !$d['result'])) $this->fail($back, 'Renseignez l\'issue et la date de clôture.');
        if ($r) { DB::update('vn_loop', $d, 'id=?', [(int)$r['id']]); Audit::log('update', 'vn_loop', (int)$r['id'], ['stage' => $r['stage']], ['stage' => $d['stage']]); }
        else { $nid = DB::insert('vn_loop', $d + ['ref' => Voc::ref('LCF', 'vn_loop'), 'is_demo' => 0, 'created_by' => Auth::id(), 'created_at' => now()]); Audit::log('create', 'vn_loop', $nid, null, ['theme' => $d['theme']]); }
        $this->go('voc/loop', 'Fiche enregistrée.');
    }

    // ───────────────────────── plans d'action ─────────────────────────
    static function origins(): array {
        $o = []; foreach (DB::all('SELECT id, ref, title FROM vn_field ORDER BY day DESC') as $x) $o['field:' . $x['id']] = $x['ref'] . ' · ' . $x['title']; foreach (DB::all('SELECT id, ref, theme FROM vn_loop ORDER BY opened DESC') as $x) $o['loop:' . $x['id']] = $x['ref'] . ' · ' . $x['theme']; return $o;
    }
    function actIndex(string $id = ''): void {
        $st = in_array($_GET['status'] ?? '', Voc::ACTION_ST, true) ? $_GET['status'] : ''; $ev = (int)($_GET['event'] ?? 0);
        $w = ['1=1']; $p = []; if ($st !== '') { $w[] = 'a.status=?'; $p[] = $st; } if ($ev) { $w[] = 'a.event_id=?'; $p[] = $ev; }
        $rows = DB::all('SELECT a.*, e.theme event FROM vn_actions a LEFT JOIN vn_events e ON e.id=a.event_id WHERE ' . implode(' AND ', $w) . ' ORDER BY (a.due IS NULL), a.due, a.id', $p);
        $steps = []; foreach (DB::all("SELECT * FROM vn_steps WHERE entity='action' ORDER BY position, id") as $s) $steps[(int)$s['entity_id']][] = $s;
        $a = $id !== '' ? DB::one('SELECT a.*, e.theme event, e.ref event_ref FROM vn_actions a LEFT JOIN vn_events e ON e.id=a.event_id WHERE a.id=?', [(int)$id]) : null; if ($id !== '' && !$a) { $this->notFound(); return; }
        if ($a && $a['origin_type']) { $t = $a['origin_type'] === 'field' ? 'vn_field' : 'vn_loop'; $a['origin'] = DB::one("SELECT id, ref FROM $t WHERE id=?", [(int)$a['origin_id']]); }
        if (($_GET['export'] ?? '') === 'csv') { Audit::log('export', 'vn_actions', null, null, ['rows' => count($rows)]);
            Voc::csvOut('CXO_plans_action.csv', array_merge([['Réf.', 'Axe', 'Action', 'Focus group', 'Responsable', 'Échéance', 'Horizon', 'Priorité', 'Statut', 'Indicateurs', 'Résultat et preuve', 'Clôturée le']], array_map(fn($r) => [$r['ref'], $r['axis'], $r['title'], $r['event'], $r['owner'], $r['due'], $r['horizon'], $r['priority'], $r['status'], $r['kpi'], $r['closure'], $r['closed_at']], $rows))); }
        $this->view('voc/act_index', ['title' => 'Plans d\'action', 'rows' => $rows, 'steps' => $steps, 'st' => $st, 'ev' => $ev, 'events' => DB::all('SELECT id, theme FROM vn_events ORDER BY day DESC'), 'a' => $a, 'journal' => $a ? Voc::journalOf('action', (int)$a['id']) : [], 'today' => date('Y-m-d')]);
    }
    function actForm(string $id = ''): void {
        $a = $id !== '' ? DB::one('SELECT * FROM vn_actions WHERE id=?', [(int)$id]) : null; if ($id !== '' && !$a) { $this->notFound(); return; }
        $this->view('voc/act_form', ['title' => $a ? 'Modifier l\'action' : 'Créer une action', 'a' => $a, 'events' => DB::all('SELECT id, theme FROM vn_events ORDER BY day DESC'), 'origins' => self::origins(), 'preEvent' => (int)($_GET['event'] ?? 0), 'preOrigin' => (string)($_GET['origin'] ?? ''), 'back' => $this->backTo('')]);
    }
    function actSave(string $id = ''): void {
        $a = $id !== '' ? DB::one('SELECT * FROM vn_actions WHERE id=?', [(int)$id]) : null; if ($id !== '' && !$a) { $this->notFound(); return; } $back = $a ? 'voc/actions/' . $a['id'] . '/edit' : 'voc/actions/new';
        $ev = (int)$this->in('event_id') ?: null; if ($ev && !DB::val('SELECT 1 FROM vn_events WHERE id=?', [$ev])) $ev = null;
        $or = (string)$this->in('origin', ''); $ot = null; $oi = null; if (preg_match('/^(field|loop):(\d+)$/', $or, $m) && DB::val('SELECT 1 FROM vn_' . $m[1] . ' WHERE id=?', [(int)$m[2]])) { $ot = $m[1]; $oi = (int)$m[2]; }
        $d = ['event_id' => $ev, 'origin_type' => $ot, 'origin_id' => $oi, 'axis' => $this->s('axis'), 'title' => $this->s('title', 300), 'owner' => $this->s('owner'), 'objective' => $this->s('objective', 1500), 'due' => $this->day('due'), 'horizon' => $this->s('horizon', 100), 'kpi' => $this->s('kpi', 1500),
            'priority' => in_array($this->in('priority'), Voc::PRIORITIES, true) ? $this->in('priority') : 'Normale', 'status' => in_array($this->in('status'), Voc::ACTION_ST, true) ? $this->in('status') : 'À lancer', 'closure' => $this->s('closure', 1500), 'updated_at' => now()];
        if (!$d['title'] || !$d['owner']) $this->fail($back, 'Renseignez l\'action et son responsable.');
        $from = $a['status'] ?? null;
        if ($d['status'] === 'Clôturée' && (!$d['closure'] || ($a && Voc::pendingMandatory(Voc::steps('action', (int)$a['id']))) || !$a)) $this->fail($back, 'Renseignez le résultat et la preuve, et terminez les étapes obligatoires.');
        $d['closed_at'] = $d['status'] === 'Clôturée' ? ($from === 'Clôturée' && $a['closed_at'] ? $a['closed_at'] : date('Y-m-d')) : null;
        if ($a) { DB::update('vn_actions', $d, 'id=?', [(int)$a['id']]); $aid = (int)$a['id']; Audit::log('update', 'vn_action', $aid, ['status' => $from], ['status' => $d['status']]); }
        else { $aid = DB::insert('vn_actions', $d + ['ref' => Voc::ref('ACT', 'vn_actions'), 'is_demo' => 0, 'created_by' => Auth::id(), 'created_at' => now()]);
            foreach (Voc::ACTION_STEPS as $i => [$n, $req]) DB::insert('vn_steps', ['entity' => 'action', 'entity_id' => $aid, 'position' => $i + 1, 'name' => $n, 'status' => 'À faire', 'required' => $req]); Audit::log('create', 'vn_action', $aid, null, ['title' => $d['title']]); }
        if ($from !== $d['status']) Voc::journal('action', $aid, 'Statut : ' . ($from ? $from . ' → ' : '') . $d['status']); Voc::journal('action', $aid, (string)$this->in('comment', ''));
        $this->go($this->backTo('voc/actions/' . $aid), 'Action enregistrée.');
    }

    // ───────────────────────── étapes et journal (focus groups et actions) ─────────────────────────
    function steps(): void {
        $entity = $this->in('entity') === 'action' ? 'action' : 'event'; $pid = (int)$this->in('entity_id'); $table = $entity === 'action' ? 'vn_actions' : 'vn_events';
        $parent = DB::one("SELECT * FROM $table WHERE id=?", [$pid]); if (!$parent) { $this->notFound(); return; }
        $back = $this->backTo($entity === 'action' ? 'voc/actions/' . $pid : 'voc/focus/' . $pid . '?tab=steps'); $act = (string)$this->in('act'); $sid = (int)$this->in('id');
        $step = $sid ? DB::one('SELECT * FROM vn_steps WHERE id=? AND entity=? AND entity_id=?', [$sid, $entity, $pid]) : null;
        if ($act === 'journal') { $c = trim((string)$this->in('comment', '')); if ($c === '') $this->go($back, 'Saisissez un commentaire.', 'danger'); Voc::journal($entity, $pid, $c); $this->go($back, 'Commentaire enregistré.'); }
        if ($act === 'move' && $step) { $all = Voc::steps($entity, $pid); $at = array_search($sid, array_map('intval', array_column($all, 'id')), true); $to = $at + ((int)$this->in('offset') < 0 ? -1 : 1);
            if ($at !== false && isset($all[$to])) { [$all[$at], $all[$to]] = [$all[$to], $all[$at]]; foreach ($all as $i => $s) DB::update('vn_steps', ['position' => $i + 1], 'id=?', [(int)$s['id']]); } $this->go($back); }
        if ($act === 'remove' && $step) { DB::exec('DELETE FROM vn_steps WHERE id=?', [$sid]); Voc::journal($entity, $pid, 'Étape retirée : ' . $step['name']); $this->go($back, 'Étape retirée.'); }
        if ($act !== 'save') $this->go($back, 'Action inconnue.', 'danger');
        $name = $this->s('name', 100); if (!$name) $this->go($back, 'Nommez l\'étape.', 'danger'); $status = in_array($this->in('status'), Voc::STEP_ST, true) ? $this->in('status') : 'À faire'; $req = $this->in('required') === 'oui' ? 1 : 0; $note = $this->s('note', 1500);
        if (in_array($parent['status'], ['Clôturé', 'Clôturée'], true) && $req && $status !== 'Terminé') $this->go($back, 'Rouvrez la fiche avant d\'ajouter une étape obligatoire en cours.', 'danger');
        $d = ['name' => $name, 'owner' => $this->s('owner', 100), 'due' => $this->day('due'), 'status' => $status, 'note' => $note, 'required' => $req];
        if ($step) DB::update('vn_steps', $d, 'id=?', [$sid]); else DB::insert('vn_steps', $d + ['entity' => $entity, 'entity_id' => $pid, 'position' => (int)DB::val('SELECT COALESCE(MAX(position),0) FROM vn_steps WHERE entity=? AND entity_id=?', [$entity, $pid]) + 1]);
        if (!$step || $status !== $step['status'] || $note !== $step['note']) Voc::journal($entity, $pid, 'Étape « ' . $name . ' » · ' . $status . ($note ? ' · ' . $note : ''));
        $this->go($back, 'Étape enregistrée.');
    }
}
