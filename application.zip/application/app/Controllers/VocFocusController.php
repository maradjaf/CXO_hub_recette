<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Voc, VocDemo, Files, Mailer, Qr};

/** Lot 59 — Focus groups : fiches, participants et invitations, plan d'action, évaluation à chaud (questionnaire public), médias, rétrospectives. */
class VocFocusController extends Controller {
    const TABS = ['overview' => 'Vue d\'ensemble', 'steps' => 'Étapes et journal', 'people' => 'Participants et invitations', 'issues' => 'Plan d\'action', 'survey' => 'Évaluation à chaud', 'media' => 'Photos et vidéos'];
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    private function s(string $k, int $max = 150): ?string { $v = mb_substr(trim((string)$this->in($k, '')), 0, $max); return $v === '' ? null : $v; }
    private function day(string $k): ?string { $v = trim((string)$this->in($k, '')); return Voc::isDay($v) ? $v : null; }
    private function cnt(string $k, bool $req = false): ?int { $v = trim((string)$this->in($k, '')); if ($v === '') { if ($req) throw new \InvalidArgumentException('Renseignez tous les effectifs requis.'); return null; } if (!ctype_digit($v) || (int)$v > 1000000) throw new \InvalidArgumentException('Saisissez un effectif entier positif ou nul.'); return (int)$v; }

    // ───────────────────────── liste et fiche ─────────────────────────
    function index(string $id = ''): void {
        $q = trim((string)($_GET['q'] ?? '')); $st = in_array($_GET['status'] ?? '', Voc::FOCUS_ST, true) ? $_GET['status'] : '';
        $list = array_values(array_filter(DB::all('SELECT * FROM vn_events ORDER BY day DESC, id DESC'), fn($e) => ($st === '' || $e['status'] === $st) && ($q === '' || mb_stripos(implode(' ', [$e['theme'], $e['target'], $e['location'], $e['owner']]), $q) !== false)));
        $e = $id !== '' ? DB::one('SELECT * FROM vn_events WHERE id=?', [(int)$id]) : ($list[0] ?? null); if ($id !== '' && !$e) { $this->notFound(); return; }
        $tab = isset(self::TABS[$_GET['tab'] ?? '']) ? $_GET['tab'] : 'overview'; $d = ['title' => 'Focus groups', 'list' => $list, 'q' => $q, 'st' => $st, 'e' => $e, 'tab' => $tab];
        if ($e) { $eid = (int)$e['id'];
            $d['actions'] = DB::all('SELECT * FROM vn_actions WHERE event_id=? ORDER BY id', [$eid]); $d['staffN'] = array_sum(array_column((array)json_decode((string)$e['staff'], true), 'count'));
            if ($tab === 'steps') { $d['steps'] = Voc::steps('event', $eid); $d['journal'] = Voc::journalOf('event', $eid); }
            if ($tab === 'people') { $d['people'] = DB::all('SELECT p.*, (SELECT c.channel FROM vn_contacts c WHERE c.participant_id=p.id ORDER BY c.id DESC LIMIT 1) last_channel, (SELECT c.day FROM vn_contacts c WHERE c.participant_id=p.id ORDER BY c.id DESC LIMIT 1) last_day FROM vn_participants p WHERE p.event_id=? ORDER BY p.id DESC', [$eid]);
                $pid = (int)($_GET['p'] ?? 0); $d['person'] = $pid ? DB::one('SELECT * FROM vn_participants WHERE id=? AND event_id=?', [$pid, $eid]) : null; $d['contacts'] = $d['person'] ? DB::all('SELECT * FROM vn_contacts WHERE participant_id=? ORDER BY id DESC', [$pid]) : []; $d['mode'] = ($_GET['mode'] ?? '') === 'invite' ? 'invite' : 'edit'; $d['mail'] = Mailer::enabled(); }
            if ($tab === 'issues') { $d['asteps'] = []; foreach (DB::all("SELECT s.* FROM vn_steps s JOIN vn_actions a ON a.id=s.entity_id WHERE s.entity='action' AND a.event_id=? ORDER BY s.position, s.id", [$eid]) as $s) $d['asteps'][(int)$s['entity_id']][] = $s; }
            if ($tab === 'survey') { $d['surveys'] = DB::all('SELECT * FROM vn_surveys WHERE event_id=? ORDER BY id', [$eid]); $sid = (int)($_GET['s'] ?? 0); $c = null; foreach ($d['surveys'] as $x) if ((int)$x['id'] === $sid) $c = $x; $c ??= $d['surveys'][0] ?? null; $d['c'] = $c;
                if ($c) { $d['questions'] = DB::all('SELECT * FROM vn_questions WHERE survey_id=? ORDER BY position, id', [(int)$c['id']]); $rf = $this->replyFilter(); $d['rf'] = $rf; $d['res'] = Voc::results((int)$c['id'], $d['questions'], $rf); $d['total'] = (int)DB::val('SELECT COUNT(*) FROM vn_replies WHERE survey_id=?', [(int)$c['id']]);
                    $d['emails'] = DB::all("SELECT name, email FROM vn_participants WHERE event_id=? AND email IS NOT NULL AND email<>'' ORDER BY name", [$eid]); $d['mail'] = Mailer::enabled(); $d['qid'] = (int)($_GET['qe'] ?? 0); } }
            if ($tab === 'media') $d['media'] = DB::all('SELECT * FROM vn_media WHERE event_id=? ORDER BY id', [$eid]);
        }
        $this->view('voc/focus', $d);
    }
    private function replyFilter(): array { return ['channel' => isset(Voc::REPLY_CH[$_GET['rc'] ?? '']) ? $_GET['rc'] : '', 'from' => Voc::isDay($_GET['rfrom'] ?? '') ? $_GET['rfrom'] : '', 'to' => Voc::isDay($_GET['rto'] ?? '') ? $_GET['rto'] : '']; }
    function form(string $id = ''): void {
        $e = $id !== '' ? DB::one('SELECT * FROM vn_events WHERE id=?', [(int)$id]) : null; if ($id !== '' && !$e) { $this->notFound(); return; }
        $this->view('voc/focus_form', ['title' => $e ? 'Modifier le focus group' : 'Planifier un focus group', 'e' => $e]);
    }
    /** Texte « Titre » puis lignes « Réponse : valeur » (valeur en nombre ou en %), blocs séparés par une ligne vide. */
    private static function parseStudy(string $t): array {
        $out = []; foreach (preg_split('/\R\s*\R/', trim($t)) as $block) { $lines = array_values(array_filter(array_map('trim', preg_split('/\R/', $block)), fn($x) => $x !== '')); if (count($lines) < 2) continue; $title = mb_substr(array_shift($lines), 0, 150); $entries = []; $pct = false;
            foreach ($lines as $l) { if (!preg_match('/^(.+?)\s*[:|]\s*([\d.,]+)\s*(%?)$/u', $l, $m)) throw new \InvalidArgumentException('Usages et attentes : écrivez « Réponse : valeur » sous chaque titre.'); $v = (float)str_replace(',', '.', $m[2]); if ($m[3] === '%') { $pct = true; $v /= 100; } $entries[] = ['label' => mb_substr(trim($m[1]), 0, 120), 'value' => $v]; }
            $out[] = ['title' => $title, 'unit' => $pct ? '%' : 'observations', 'entries' => $entries]; }
        return $out;
    }
    static function studyText(?string $json): string {
        return implode("\n\n", array_map(fn($s) => $s['title'] . "\n" . implode("\n", array_map(fn($x) => $x['label'] . ' : ' . ($s['unit'] === '%' ? rtrim(rtrim(number_format(100 * $x['value'], 1, ',', ''), '0'), ',') . ' %' : rtrim(rtrim(number_format($x['value'], 1, ',', ''), '0'), ',')), $s['entries'])), (array)json_decode((string)$json, true)));
    }
    function save(string $id = ''): void {
        $e = $id !== '' ? DB::one('SELECT * FROM vn_events WHERE id=?', [(int)$id]) : null; if ($id !== '' && !$e) { $this->notFound(); return; } $back = $e ? 'voc/focus/' . $e['id'] . '/edit' : 'voc/focus/new';
        $fail = function (string $m) use ($back): never { $_SESSION['_old'] = $_POST; $this->go($back, $m, 'danger'); };
        $d = ['theme' => $this->s('theme', 180), 'day' => $this->day('day'), 'location' => $this->s('location'), 'time_start' => preg_match('/^\d{2}:\d{2}$/', (string)$this->in('time_start')) ? $this->in('time_start') : null, 'time_end' => preg_match('/^\d{2}:\d{2}$/', (string)$this->in('time_end')) ? $this->in('time_end') : null,
            'owner' => $this->s('owner'), 'target' => $this->s('target', 300), 'status' => in_array($this->in('status'), Voc::FOCUS_ST, true) ? $this->in('status') : 'Brouillon', 'context' => $this->s('context', 1500), 'objective' => $this->s('objective', 1500), 'method' => $this->s('methodo', 1500),
            'agenda' => $this->s('agenda', 1500), 'findings' => $this->s('findings', 1500), 'report' => $this->s('report', 1500), 'hot_note' => $this->s('hot_note', 500), 'updated_at' => now()];
        if (!$d['theme'] || !$d['day'] || !$d['location'] || !$d['owner'] || !$d['target']) $fail('Renseignez le thème, la date, le lieu, la cible et le pilote.');
        if ($d['time_start'] && $d['time_end'] && $d['time_end'] <= $d['time_start']) $fail('L\'heure de fin doit suivre l\'heure de début.');
        try {
            $d += ['expected' => $this->cnt('expected', true), 'confirmed' => $this->cnt('confirmed'), 'present' => $this->cnt('present') ?? 0, 'staff' => json_encode(Voc::breakdown((string)$this->in('staff', '')), JSON_UNESCAPED_UNICODE), 'profiles' => json_encode(Voc::breakdown((string)$this->in('profiles', '')), JSON_UNESCAPED_UNICODE),
                'study' => json_encode(self::parseStudy((string)$this->in('study', '')), JSON_UNESCAPED_UNICODE), 'hot_invited' => $this->cnt('hot_invited'), 'hot_responded' => $this->cnt('hot_responded'), 'hot_very' => $this->cnt('hot_very'), 'hot_satisfied' => $this->cnt('hot_satisfied')];
        } catch (\InvalidArgumentException $x) { $fail($x->getMessage()); }
        $rd = str_replace(',', '.', trim((string)$this->in('hot_rate_deck', ''))); $d['hot_rate_deck'] = $rd !== '' && is_numeric($rd) && $rd >= 0 && $rd <= 100 ? (float)$rd : null;
        if ($d['hot_responded'] !== null && (!$d['hot_invited'] || $d['hot_responded'] > $d['hot_invited'] || (int)$d['hot_very'] + (int)$d['hot_satisfied'] > $d['hot_responded'])) $fail('Évaluation archivée : vérifiez les effectifs (répondants ≤ interrogés, satisfaits ≤ répondants).');
        $from = $e['status'] ?? null;
        if ($d['status'] === 'Clôturé' && $from !== 'Clôturé' && (!$d['report'] || !$e || Voc::pendingMandatory(Voc::steps('event', (int)$e['id'])))) $fail('Terminez les étapes obligatoires et renseignez le compte rendu avant la clôture.');
        if ($e) { DB::update('vn_events', $d, 'id=?', [(int)$e['id']]); $eid = (int)$e['id']; Audit::log('update', 'vn_event', $eid, ['status' => $from], ['status' => $d['status']]); }
        else { $eid = DB::insert('vn_events', $d + ['ref' => Voc::ref('FG', 'vn_events'), 'archive' => 0, 'is_demo' => 0, 'created_by' => Auth::id(), 'created_at' => now()]);
            foreach (Voc::EVENT_STEPS as $i => [$n, $req]) DB::insert('vn_steps', ['entity' => 'event', 'entity_id' => $eid, 'position' => $i + 1, 'name' => $n, 'status' => 'À faire', 'required' => $req]); Audit::log('create', 'vn_event', $eid, null, ['theme' => $d['theme']]); }
        if ($from !== $d['status']) Voc::journal('event', $eid, 'Statut : ' . ($from ? $from . ' → ' : '') . $d['status']); Voc::journal('event', $eid, (string)$this->in('comment', ''));
        $this->go('voc/focus/' . $eid, 'Fiche enregistrée.');
    }
    function printView(string $id): void {
        $e = DB::one('SELECT * FROM vn_events WHERE id=?', [(int)$id]); if (!$e) { $this->notFound(); return; }
        $this->view('voc/focus_print', ['title' => $e['theme'], 'e' => $e, 'actions' => DB::all('SELECT * FROM vn_actions WHERE event_id=? ORDER BY id', [(int)$id])], 'layout/public');
    }

    // ───────────────────────── opérations de la fiche ─────────────────────────
    function act(string $id): void {
        $e = DB::one('SELECT * FROM vn_events WHERE id=?', [(int)$id]); if (!$e) { $this->notFound(); return; } $eid = (int)$e['id']; $act = (string)$this->in('act');
        $to = fn(string $tab, string $extra = '') => "voc/focus/$eid?tab=$tab$extra";
        switch ($act) {
            case 'delete': if ($e['status'] === 'Clôturé') $this->go($to('overview'), 'Une rencontre clôturée ne se supprime pas.', 'danger'); VocDemo::dropEvent($eid); Audit::log('delete', 'vn_event', $eid, ['theme' => $e['theme']], null); $this->go('voc/focus', 'Rencontre supprimée.');
            // ── participants ──
            case 'participant_save': $pid = (int)$this->in('pid'); $p = $pid ? DB::one('SELECT * FROM vn_participants WHERE id=? AND event_id=?', [$pid, $eid]) : null; $back = $to('people', $p ? '&p=' . $pid : '');
                $name = $this->s('name', 130); if (!$name) $this->go($back, 'Renseignez un nom ou une référence.', 'danger'); $phone = preg_replace('/[()\s.\-]/', '', (string)$this->in('phone', '')); if ($phone !== '' && !preg_match('/^\+?\d{7,16}$/', $phone)) $this->go($back, 'Vérifiez le numéro de téléphone et l\'indicatif.', 'danger');
                $email = $this->s('email', 254); if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) $this->go($back, 'Vérifiez l\'adresse e-mail.', 'danger'); $status = in_array($this->in('status'), Voc::PART_ST, true) ? $this->in('status') : 'À inviter';
                $d = ['name' => $name, 'profile' => $this->s('profile'), 'email' => $email, 'phone' => $phone ?: null, 'status' => $status, 'note' => $this->s('note', 1500)];
                if ($p) DB::update('vn_participants', $d, 'id=?', [$pid]); else DB::insert('vn_participants', $d + ['event_id' => $eid, 'created_at' => now()]);
                if (!$p || $p['status'] !== $status) Voc::journal('event', $eid, 'Participation « ' . $name . ' » · ' . $status); $this->go($to('people'), 'Participant enregistré.');
            case 'participant_remove': $pid = (int)$this->in('pid'); if ($p = DB::one('SELECT * FROM vn_participants WHERE id=? AND event_id=?', [$pid, $eid])) { DB::exec('DELETE FROM vn_contacts WHERE participant_id=?', [$pid]); DB::exec('DELETE FROM vn_participants WHERE id=?', [$pid]); Voc::journal('event', $eid, 'Participant retiré : ' . $p['name']); } $this->go($to('people'), 'Participant retiré.');
            case 'contact': case 'contact_send': $pid = (int)$this->in('pid'); $p = DB::one('SELECT * FROM vn_participants WHERE id=? AND event_id=?', [$pid, $eid]); if (!$p) $this->go($to('people'), 'Participant introuvable.', 'danger'); $back = $to('people', '&p=' . $pid . '&mode=invite');
                $day = $this->day('day'); if (!$day) $this->go($back, 'Indiquez la date du contact.', 'danger'); $ch = in_array($this->in('channel'), Voc::CONTACT_CH, true) ? $this->in('channel') : 'Autre'; $status = in_array($this->in('status'), Voc::PART_ST, true) ? $this->in('status') : 'Contacté'; $note = $this->s('note', 1500);
                if ($act === 'contact_send' && Mailer::enabled() && $p['email'] && filter_var($p['email'], FILTER_VALIDATE_EMAIL)) { $body = trim((string)$this->in('body', '')); if ($body === '') $this->go($back, 'Le message est vide.', 'danger'); Mailer::queue($p['email'], 'Invitation · ' . $e['theme'], mb_substr($body, 0, 4000)); $ch = 'E-mail'; $note = trim('E-mail remis au service d\'envoi. ' . (string)$note); }
                DB::insert('vn_contacts', ['participant_id' => $pid, 'day' => $day, 'channel' => $ch, 'note' => $note ?: null, 'user_id' => Auth::id(), 'created_at' => now()]); DB::update('vn_participants', ['status' => $status], 'id=?', [$pid]);
                Voc::journal('event', $eid, 'Invitation · ' . $p['name'] . ' · ' . $ch . ' · ' . $status . ($note ? ' · ' . $note : '')); $this->go($to('people'), 'Contact enregistré.');
            case 'tally': DB::update('vn_events', ['present' => (int)DB::val("SELECT COUNT(*) FROM vn_participants WHERE event_id=? AND status='Présent'", [$eid]), 'confirmed' => (int)DB::val("SELECT COUNT(*) FROM vn_participants WHERE event_id=? AND status IN ('Confirmé','Présent','Absent')", [$eid]), 'updated_at' => now()], 'id=?', [$eid]);
                Voc::journal('event', $eid, 'Effectifs reportés depuis le registre de présence.'); $this->go($to('people'), 'Présents et confirmés reportés dans la fiche.');
            // ── médias ──
            case 'media_add': $this->mediaAdd($e);
            case 'media_save': case 'media_remove': $m = DB::one('SELECT * FROM vn_media WHERE id=? AND event_id=?', [(int)$this->in('mid'), $eid]); if (!$m) $this->go($to('media'), 'Média introuvable.', 'danger');
                if ($act === 'media_remove') { if ($m['stored_name']) @unlink(Files::dir('voc') . '/' . basename($m['stored_name'])); DB::exec('DELETE FROM vn_media WHERE id=?', [(int)$m['id']]); Voc::journal('event', $eid, 'Média retiré : ' . $m['name']); $this->go($to('media'), 'Média retiré.'); }
                $name = $this->s('name'); $url = $m['kind'] === 'link' ? self::https((string)$this->in('url', '')) : null; if (!$name || ($m['kind'] === 'link' && !$url)) $this->go($to('media'), 'Vérifiez le titre et le lien HTTPS.', 'danger');
                DB::update('vn_media', ['name' => $name] + ($m['kind'] === 'link' ? ['url' => $url] : []), 'id=?', [(int)$m['id']]); $this->go($to('media'), 'Média mis à jour.');
            case 'visibility': DB::update('vn_events', ['archive' => $e['archive'] ? 0 : 1, 'updated_at' => now()], 'id=?', [$eid]); Voc::journal('event', $eid, $e['archive'] ? 'Rétrospective retirée.' : 'Rétrospective mise à disposition du personnel.'); $this->go($to('media'), $e['archive'] ? 'Rétrospective retirée.' : 'Rétrospective mise à disposition du personnel.');
            // ── enquêtes à chaud ──
            case 'survey_save': $c = $this->survey($eid); $back = $to('survey', $c ? '&s=' . $c['id'] : ''); $title = $this->s('title', 180); $exp = $this->day('expires'); if (!$title || !$exp) $this->go($back, 'Renseignez le titre et la date de fin.', 'danger');
                $base = trim((string)$this->in('base', '')); if (!ctype_digit($base) || (int)$base > 10000) $this->go($back, 'Indiquez le nombre de personnes sollicitées (0 à 10 000).', 'danger'); $d = ['title' => $title, 'intro' => $this->s('intro', 1200), 'expires' => $exp, 'base' => (int)$base];
                if ($c) { DB::update('vn_surveys', $d, 'id=?', [(int)$c['id']]); $sid = (int)$c['id']; }
                else { $sid = DB::insert('vn_surveys', $d + ['event_id' => $eid, 'token' => bin2hex(random_bytes(16)), 'state' => 'draft', 'created_by' => Auth::id(), 'created_at' => now()]);
                    foreach ([['Quel est votre niveau de satisfaction globale concernant la rencontre ?', 'rating5', 1], ['Recommanderiez-vous les canaux digitaux de Yas et Mixx à un proche ?', 'yesno', 1], ['Quel point devrions-nous améliorer lors de la prochaine rencontre ?', 'text', 0]] as $i => [$l, $k, $r]) DB::insert('vn_questions', ['survey_id' => $sid, 'position' => $i + 1, 'label' => $l, 'kind' => $k, 'required' => $r]); }
                $this->go($to('survey', '&s=' . $sid), 'Configuration enregistrée.');
            case 'question_save': case 'question_remove': case 'question_move': $c = $this->survey($eid); if (!$c) $this->go($to('survey'), 'Enquête introuvable.', 'danger'); $back = $to('survey', '&s=' . $c['id']);
                if ($c['state'] !== 'draft') $this->go($back, 'Le questionnaire publié conserve ses questions et leur ordre.', 'warning'); $qid = (int)$this->in('qid'); $q = $qid ? DB::one('SELECT * FROM vn_questions WHERE id=? AND survey_id=?', [$qid, (int)$c['id']]) : null;
                if ($act === 'question_remove') { if ($q) DB::exec('DELETE FROM vn_questions WHERE id=?', [$qid]); $this->go($back, 'Question retirée.'); }
                if ($act === 'question_move') { $all = DB::all('SELECT id FROM vn_questions WHERE survey_id=? ORDER BY position, id', [(int)$c['id']]); $at = array_search($qid, array_map('intval', array_column($all, 'id')), true); $n = $at + ((int)$this->in('offset') < 0 ? -1 : 1);
                    if ($at !== false && isset($all[$n])) { [$all[$at], $all[$n]] = [$all[$n], $all[$at]]; foreach ($all as $i => $x) DB::update('vn_questions', ['position' => $i + 1], 'id=?', [(int)$x['id']]); } $this->go($back); }
                $label = $this->s('label', 220); if (!$label) $this->go($back, 'Renseignez le libellé de la question.', 'danger'); $kind = isset(Voc::Q_KINDS[$this->in('kind')]) ? $this->in('kind') : 'rating5';
                $opts = $kind === 'choice' ? array_values(array_unique(array_filter(array_map(fn($o) => mb_substr(trim($o), 0, 100), preg_split('/\R/', (string)$this->in('options', ''))), fn($o) => $o !== ''))) : [];
                if ($kind === 'choice' && (count($opts) < 2 || count($opts) > 10)) $this->go($back, 'Renseignez de deux à dix réponses distinctes.', 'danger'); $d = ['label' => $label, 'kind' => $kind, 'required' => $this->in('required') === 'non' ? 0 : 1, 'options' => $opts ? implode("\n", $opts) : null];
                if ($q) DB::update('vn_questions', $d, 'id=?', [$qid]); else { if ((int)DB::val('SELECT COUNT(*) FROM vn_questions WHERE survey_id=?', [(int)$c['id']]) >= 16) $this->go($back, 'Le questionnaire comprend au maximum 16 questions.', 'danger'); DB::insert('vn_questions', $d + ['survey_id' => (int)$c['id'], 'position' => (int)DB::val('SELECT COALESCE(MAX(position),0) FROM vn_questions WHERE survey_id=?', [(int)$c['id']]) + 1]); }
                $this->go($back, 'Question enregistrée.');
            case 'survey_state': $c = $this->survey($eid); if (!$c) $this->go($to('survey'), 'Enquête introuvable.', 'danger'); $back = $to('survey', '&s=' . $c['id']); $state = $this->in('state') === 'closed' ? 'closed' : 'open';
                if ($state === 'open' && (!DB::val('SELECT 1 FROM vn_questions WHERE survey_id=?', [(int)$c['id']]) || $c['expires'] < date('Y-m-d'))) $this->go($back, 'Ajoutez une question et choisissez une date de fin valide.', 'danger');
                DB::update('vn_surveys', ['state' => $state], 'id=?', [(int)$c['id']]); Audit::log('update', 'vn_survey', (int)$c['id'], ['state' => $c['state']], ['state' => $state]); Voc::journal('event', $eid, ($state === 'open' ? 'Enquête publiée : ' : 'Collecte clôturée : ') . $c['title']); $this->go($back, $state === 'open' ? 'Enquête publiée.' : 'Collecte clôturée.');
            case 'survey_mail': $c = $this->survey($eid); if (!$c || !Voc::surveyOpen($c)) $this->go($to('survey'), 'L\'enquête n\'est pas ouverte.', 'danger'); $back = $to('survey', '&s=' . $c['id']); if (!Mailer::enabled()) $this->go($back, 'L\'envoi d\'e-mails n\'est pas configuré : ouvrez le brouillon dans votre messagerie.', 'warning');
                $mail = trim((string)$this->in('email', '')); $subject = $this->s('subject', 200); $body = trim((string)$this->in('body', '')); if (!filter_var($mail, FILTER_VALIDATE_EMAIL) || !$subject) $this->go($back, 'Vérifiez l\'adresse et l\'objet.', 'danger');
                if (!str_contains($body, Voc::surveyUrl($c, 'email'))) $this->go($back, 'Conservez le lien du questionnaire dans le message.', 'danger'); Mailer::queue($mail, $subject, mb_substr($body, 0, 4000)); Voc::journal('event', $eid, 'Invitation à l\'enquête envoyée à ' . $mail); $this->go($back, 'Invitation remise au service d\'envoi.');
        }
        $this->go($to('overview'), 'Action inconnue.', 'danger');
    }
    private function survey(int $eid): ?array { $sid = (int)$this->in('sid'); return $sid ? (DB::one('SELECT * FROM vn_surveys WHERE id=? AND event_id=?', [$sid, $eid]) ?: null) : null; }
    private static function https(string $u): ?string { $u = trim($u); return preg_match('#^https://[^\s<>"\']{3,490}$#i', $u) && filter_var($u, FILTER_VALIDATE_URL) ? $u : null; }
    private function mediaAdd(array $e): never {
        $eid = (int)$e['id']; $back = "voc/focus/$eid?tab=media"; $f = $_FILES['files'] ?? null; $url = trim((string)$this->in('url', '')); $title = $this->s('title'); $n = 0; $picked = [];
        if ($f && is_array($f['name'])) foreach ($f['name'] as $i => $name) if ($f['error'][$i] !== UPLOAD_ERR_NO_FILE) $picked[] = $i;
        if (!$picked && $url === '') $this->go($back, 'Choisissez au moins un fichier ou saisissez un lien.', 'danger'); if ($url !== '' && !self::https($url)) $this->go($back, 'Utilisez un lien HTTPS.', 'danger'); if (count($picked) > 10) $this->go($back, 'Choisissez dix fichiers maximum par ajout.', 'danger');
        foreach ($picked as $i) { $ext = strtolower(pathinfo((string)$f['name'][$i], PATHINFO_EXTENSION));
            if ($f['error'][$i] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'][$i]) || !isset(Voc::MEDIA_TYPES[$ext]) || !$f['size'][$i] || $f['size'][$i] > 50000000) $this->go($back, 'Vérifiez le format et la taille des fichiers (images JPEG, PNG, WebP, GIF ou vidéos MP4, WebM, MOV de 50 Mo au plus ; limite du serveur : ' . ini_get('upload_max_filesize') . ').', 'danger');
            $mime = Voc::MEDIA_TYPES[$ext]; if (str_starts_with($mime, 'image/') && @getimagesize($f['tmp_name'][$i]) === false) $this->go($back, 'Le fichier « ' . Files::cleanName((string)$f['name'][$i]) . ' » n\'est pas une image valide.', 'danger'); }
        foreach ($picked as $i) { $ext = strtolower(pathinfo((string)$f['name'][$i], PATHINFO_EXTENSION)); $mime = Voc::MEDIA_TYPES[$ext]; $stored = bin2hex(random_bytes(16)) . '.' . $ext; if (!move_uploaded_file($f['tmp_name'][$i], Files::dir('voc') . '/' . $stored)) continue;
            DB::insert('vn_media', ['event_id' => $eid, 'name' => count($picked) === 1 && $title ? $title : mb_substr(Files::cleanName((string)$f['name'][$i]), 0, 150), 'kind' => str_starts_with($mime, 'video/') ? 'video' : 'image', 'stored_name' => $stored, 'mime' => $mime, 'size' => (int)$f['size'][$i], 'original' => 0, 'user_id' => Auth::id(), 'created_at' => now()]); $n++; }
        if ($url !== '') { DB::insert('vn_media', ['event_id' => $eid, 'name' => $title ?: 'Vidéo de l\'évènement', 'kind' => 'link', 'url' => self::https($url), 'original' => 0, 'user_id' => Auth::id(), 'created_at' => now()]); $n++; }
        Voc::journal('event', $eid, $n . ' média(s) ajouté(s).'); $this->go($back, 'Galerie mise à jour.');
    }
    /** Affichage en ligne d'une photo ou d'une vidéo (types contrôlés à l'ajout) ; réservé aux gestionnaires, ou à tous si la rencontre est en rétrospective. */
    function media(string $id): void {
        $m = DB::one('SELECT m.*, e.archive FROM vn_media m JOIN vn_events e ON e.id=m.event_id WHERE m.id=?', [(int)$id]);
        if (!$m || !$m['stored_name'] || !(can('voc.view') || ($m['archive'] && can('voc.replays')))) { $this->notFound(); return; }
        $path = Files::dir('voc') . '/' . basename($m['stored_name']); if (!is_file($path) || !in_array($m['mime'], Voc::MEDIA_TYPES, true)) { $this->notFound(); return; }
        $size = filesize($path); $start = 0; $end = $size - 1;
        header('Content-Type: ' . $m['mime']); header('X-Content-Type-Options: nosniff'); header('Accept-Ranges: bytes'); header('Cache-Control: private, max-age=3600'); header('Content-Disposition: inline; filename="media-' . (int)$m['id'] . '"');
        if (preg_match('/^bytes=(\d*)-(\d*)$/', $_SERVER['HTTP_RANGE'] ?? '', $r) && ($r[1] !== '' || $r[2] !== '')) { if ($r[1] === '') { $start = max(0, $size - (int)$r[2]); } else { $start = (int)$r[1]; if ($r[2] !== '') $end = min($end, (int)$r[2]); }
            if ($start > $end || $start >= $size) { http_response_code(416); header("Content-Range: bytes */$size"); exit; } http_response_code(206); header("Content-Range: bytes $start-$end/$size"); }
        header('Content-Length: ' . ($end - $start + 1)); $h = fopen($path, 'rb'); fseek($h, $start); $left = $end - $start + 1; while ($left > 0 && !feof($h)) { $chunk = fread($h, (int)min(262144, $left)); echo $chunk; $left -= strlen($chunk); } fclose($h); exit;
    }
    function replays(): void {
        $list = DB::all('SELECT * FROM vn_events WHERE archive=1 ORDER BY day DESC, id DESC'); $id = (int)($_GET['e'] ?? 0); $e = null; foreach ($list as $x) if ((int)$x['id'] === $id) $e = $x; $e ??= $list[0] ?? null;
        $this->view('voc/replays', ['title' => 'Rétrospectives', 'list' => $list, 'e' => $e, 'media' => $e ? DB::all('SELECT * FROM vn_media WHERE event_id=? ORDER BY id', [(int)$e['id']]) : []]);
    }

    // ───────────────────────── enquête : export, QR code, aperçu, formulaire public ─────────────────────────
    function surveyExport(string $id): void {
        $c = DB::one('SELECT * FROM vn_surveys WHERE id=?', [(int)$id]); if (!$c) { $this->notFound(); return; } $rf = $this->replyFilter(); $res = Voc::results((int)$c['id'], DB::all('SELECT * FROM vn_questions WHERE survey_id=? ORDER BY position, id', [(int)$c['id']]), $rf);
        $out = [['Enquête', $c['title']], ['Canal', Voc::REPLY_CH[$rf['channel']] ?? 'Tous'], ['Du', $rf['from']], ['Au', $rf['to']], ['Réponses', $res['replies']], ['Question', 'Réponse', 'Nombre', 'Réponses valides']];
        foreach ($res['rows'] as $r) { if ($r['counts']) foreach ($r['counts'] as [$v, $n]) $out[] = [$r['q']['label'], $v, $n, $r['base']]; else $out[] = [$r['q']['label'], 'Réponses ouvertes', $r['base'], $r['base']]; }
        Audit::log('export', 'vn_survey', (int)$c['id'], null, ['replies' => $res['replies']]); Voc::csvOut('CXO_Evaluation_a_chaud.csv', $out);
    }
    function surveyQr(string $id): void {
        $c = DB::one('SELECT * FROM vn_surveys WHERE id=?', [(int)$id]); if (!$c) { $this->notFound(); return; }
        header('Content-Type: image/svg+xml; charset=utf-8'); header('Content-Disposition: attachment; filename="QR_Enquete_' . (int)$c['id'] . '.svg"'); echo Qr::svg(Voc::surveyUrl($c, 'qr'), 300); exit;
    }
    function surveyPreview(string $id): void {
        $c = DB::one('SELECT * FROM vn_surveys WHERE id=?', [(int)$id]); if (!$c) { $this->notFound(); return; }
        $this->view('voc/survey_public', ['title' => $c['title'], 'c' => $c, 'questions' => DB::all('SELECT * FROM vn_questions WHERE survey_id=? ORDER BY position, id', [(int)$c['id']]), 'preview' => true, 'via' => 'lien', 'state' => 'open'], 'layout/public');
    }
    private function publicSurvey(string $token): ?array { return preg_match('/^[a-f0-9]{16,40}$/', $token) ? (DB::one("SELECT * FROM vn_surveys WHERE token=? AND state<>'draft'", [$token]) ?: null) : null; }
    function publicForm(string $token): void {
        $c = $this->publicSurvey($token); if (!$c) { $this->notFound(); return; } $via = isset(Voc::REPLY_CH[$_GET['via'] ?? '']) ? $_GET['via'] : 'lien';
        $state = !Voc::surveyOpen($c) ? 'closed' : (!empty($_SESSION['vn_done'][(int)$c['id']]) ? 'done' : 'open');
        $this->view('voc/survey_public', ['title' => $c['title'], 'c' => $c, 'questions' => DB::all('SELECT * FROM vn_questions WHERE survey_id=? ORDER BY position, id', [(int)$c['id']]), 'preview' => false, 'via' => $via, 'state' => $state], 'layout/public');
    }
    function publicSubmit(string $token): void {
        $c = $this->publicSurvey($token); if (!$c) { $this->notFound(); return; } $back = 'q/' . $c['token'] . '?via=' . (isset(Voc::REPLY_CH[$this->in('via')]) ? $this->in('via') : 'lien'); $sid = (int)$c['id'];
        if (!Voc::surveyOpen($c) || !empty($_SESSION['vn_done'][$sid])) $this->go($back);
        if (trim((string)$this->in('website', '')) !== '') $this->go($back);   // champ piège : rempli uniquement par un robot
        if ((int)DB::val('SELECT COUNT(*) FROM vn_replies WHERE survey_id=?', [$sid]) >= 5000) $this->go($back, 'La collecte a atteint son plafond de réponses.', 'warning');
        $ans = []; $given = (array)($_POST['a'] ?? []);
        foreach (DB::all('SELECT * FROM vn_questions WHERE survey_id=? ORDER BY position, id', [$sid]) as $q) { $v = trim((string)($given[$q['id']] ?? '')); $opts = Voc::qOptions($q);
            if ($v === '') { if ($q['required']) { $_SESSION['_old'] = $_POST; $this->go($back, 'Répondez aux questions obligatoires.', 'danger'); } continue; }
            if ($q['kind'] === 'text') $v = mb_substr($v, 0, 1000); elseif (!in_array($v, $opts, true)) { $_SESSION['_old'] = $_POST; $this->go($back, 'Une réponse n\'est pas reconnue.', 'danger'); }
            $ans[(int)$q['id']] = $v; }
        if (!$ans) $this->go($back, 'Répondez à au moins une question.', 'danger');
        $rid = DB::insert('vn_replies', ['survey_id' => $sid, 'channel' => isset(Voc::REPLY_CH[$this->in('via')]) ? $this->in('via') : 'lien', 'submitted_at' => now()]); foreach ($ans as $qid => $v) DB::insert('vn_answers', ['reply_id' => $rid, 'question_id' => $qid, 'value' => $v]);
        $_SESSION['vn_done'][$sid] = 1; $this->go($back);
    }
}
