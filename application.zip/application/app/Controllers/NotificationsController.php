<?php
namespace App\Controllers;
use App\Core\{Controller, Auth, DB};
class NotificationsController extends Controller {
    function index(): void {
        $p = paginate('notifications WHERE user_id=?', [Auth::id()], $this->page(), 20, '*', 'id DESC');
        $this->view('notifications/index', ['title' => 'Notifications', 'p' => $p]);
    }
    function update(): void {
        DB::exec('UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL', [now(), Auth::id()]);
        flash('Notifications marquées comme lues.');
        redirect('notifications');
    }
}
