<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Skill, Scope, Notifier};

/** Lot 57 : compétences (M16) — matrice, fiche d'écart, vue équipe, propositions après session, catalogue et niveaux requis par poste. */
class SkillsController extends Controller {
    private function go(string $p, string $msg = '', string $t = 'success'): never { if ($msg !== '') flash($msg, $t); redirect($p); }
    private function filters(): array {
        return ['teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'), 'stores' => DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name'), 'positions' => DB::all('SELECT id, name FROM positions WHERE active=1 ORDER BY name'),
            'families' => DB::all('SELECT * FROM sk_families WHERE active=1 ORDER BY sort_order, name')];
    }
    private function scopeWhere(): array {
        [$sw, $sp] = Scope::sql('e.id'); $w = ["e.status<>'left'", $sw]; $p = $sp;
        foreach (['team_id', 'store_id', 'position_id'] as $f) if ($this->in($f)) { $w[] = "e.$f=?"; $p[] = (int)$this->in($f); }
        if (($q = trim((string)$this->in('q', ''))) !== '') { $w[] = '(e.first_name LIKE ? OR e.last_name LIKE ? OR e.matricule LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        return [implode(' AND ', $w), $p];
    }

    // ------------------------------------------------------------------ matrice
    function index(): void {
        [$w, $p] = $this->scopeWhere(); $fam = (int)$this->in('family_id');
        $skills = DB::all('SELECT s.*, f.name family FROM sk_skills s JOIN sk_families f ON f.id=s.family_id WHERE s.active=1' . ($fam ? ' AND s.family_id=' . $fam : '') . ' ORDER BY f.sort_order, f.name, s.name');
        $pg = paginate("employees e LEFT JOIN teams t ON t.id=e.team_id LEFT JOIN positions po ON po.id=e.position_id WHERE $w", $p, (int)$this->in('page', 1), 25, 'e.id, e.first_name, e.last_name, e.matricule, e.position_id, t.name team_name, po.name position_name', 'e.last_name, e.first_name');
        $ids = array_map(fn($r) => (int)$r['id'], $pg['rows']); $lv = []; $req = [];
        if ($ids) { $in = implode(',', array_fill(0, count($ids), '?')); foreach (DB::all("SELECT employee_id, skill_id, level FROM sk_levels WHERE employee_id IN ($in)", $ids) as $l) $lv[(int)$l['employee_id']][(int)$l['skill_id']] = (int)$l['level']; }
        foreach ($pg['rows'] as $r) if ($r['position_id'] && !isset($req[(int)$r['position_id']])) $req[(int)$r['position_id']] = Skill::required((int)$r['position_id']);
        if ($this->in('export') === 'csv') {
            $all = DB::all("SELECT e.id, e.matricule, e.last_name, e.first_name, e.position_id, t.name team_name FROM employees e LEFT JOIN teams t ON t.id=e.team_id WHERE $w ORDER BY e.last_name, e.first_name LIMIT 5000", $p); $rows = [];
            foreach ($all as $r) { $cur = Skill::levels((int)$r['id']); $rq = $r['position_id'] ? Skill::required((int)$r['position_id']) : []; $line = [$r['matricule'], $r['last_name'], $r['first_name'], $r['team_name']];
                foreach ($skills as $s) { $sid = (int)$s['id']; $line[] = (isset($cur[$sid]) ? Skill::LEVELS[(int)$cur[$sid]['level']] : '') . (isset($rq[$sid]) ? ' (requis : ' . Skill::LEVELS[$rq[$sid]] . ')' : ''); } $rows[] = $line; }
            Audit::log('export', 'sk_matrix', null, null, ['rows' => count($rows)]);
            csv_download('matrice_competences_' . date('Ymd_His') . '.csv', array_merge(['Matricule', 'Nom', 'Prénom', 'Équipe'], array_map(fn($s) => $s['family'] . ' / ' . $s['name'], $skills)), $rows);
        }
        $pending = can('skills.assess') ? (int)DB::val("SELECT COUNT(*) FROM sk_proposals sp JOIN employees e ON e.id=sp.employee_id WHERE sp.status='pending' AND " . Scope::sql('e.id')[0], Scope::sql('e.id')[1]) : 0;
        $this->view('skills/index', ['title' => 'Matrice des compétences', 'p' => $pg, 'skills' => $skills, 'lv' => $lv, 'req' => $req, 'pending' => $pending] + $this->filters());
    }

    // ------------------------------------------------------------------ vue équipe
    function team(): void {
        [$w, $p] = $this->scopeWhere();
        $emps = DB::all("SELECT e.id, e.first_name, e.last_name, e.matricule FROM employees e WHERE $w ORDER BY e.last_name, e.first_name LIMIT 2000", $p); $ids = array_map(fn($r) => (int)$r['id'], $emps); $names = [];
        foreach ($emps as $e) $names[(int)$e['id']] = $e['last_name'] . ' ' . $e['first_name'];
        $cov = Skill::teamCoverage($ids); $fam = (int)$this->in('family_id'); if ($fam) $cov = array_filter($cov, fn($c) => (int)DB::val('SELECT family_id FROM sk_skills WHERE id=?', [(int)$c['skill']['id']]) === $fam);
        $tr = []; foreach (DB::all('SELECT ts.skill_id, t.id, t.title FROM sk_training_skills ts JOIN trainings t ON t.id=ts.training_id WHERE t.active=1') as $t) $tr[(int)$t['skill_id']][] = $t;
        $tot = ['required' => 0, 'covered' => 0, 'gaps' => 0]; foreach ($cov as $c) { $tot['required'] += $c['required']; $tot['covered'] += $c['covered']; $tot['gaps'] += count($c['missing']); }
        if ($this->in('export') === 'csv') {
            Audit::log('export', 'sk_team', null, null, ['rows' => count($cov)]);
            csv_download('couverture_competences_' . date('Ymd_His') . '.csv', ['Famille', 'Compétence', 'Collaborateurs concernés', 'Couverts', 'Couverture %', 'En écart', 'Écart moyen (niveaux)', 'Formations liées', 'Collaborateurs en écart'],
                array_map(fn($c) => [$c['skill']['family'], $c['skill']['name'], $c['required'], $c['covered'], $c['pct'] ?? '', count($c['missing']), $c['gap_avg'], implode(' ; ', array_map(fn($t) => $t['title'], $tr[(int)$c['skill']['id']] ?? [])), implode(' ; ', array_map(fn($i) => $names[$i] ?? $i, $c['missing']))], array_values($cov)));
        }
        $this->view('skills/team', ['title' => 'Couverture des compétences', 'cov' => $cov, 'names' => $names, 'tr' => $tr, 'tot' => $tot, 'n' => count($emps)] + $this->filters());
    }

    // ------------------------------------------------------------------ fiche d'écart
    function me(): void { $e = (int)(Auth::user()['employee_id'] ?? 0); if (!$e) { flash('Votre compte n\'est pas rattaché à un collaborateur.', 'warning'); redirect('skills'); } redirect('skills/employee/' . $e); }
    function employee(string $id): void {
        $e = DB::one('SELECT e.*, t.name team_name, po.name position_name FROM employees e LEFT JOIN teams t ON t.id=e.team_id LEFT JOIN positions po ON po.id=e.position_id WHERE e.id=?', [(int)$id]);
        if (!$e || (!Scope::allows((int)$id) && (int)(Auth::user()['employee_id'] ?? 0) !== (int)$id)) { $this->notFound(); return; }
        $gs = Skill::gapSheet((int)$id);
        $this->view('skills/employee', ['title' => 'Compétences · ' . $e['first_name'] . ' ' . $e['last_name'], 'e' => $e, 'gs' => $gs, 'canAssess' => can('skills.assess') && Scope::allows((int)$id),
            'skills' => DB::all('SELECT s.id, s.name, f.name family FROM sk_skills s JOIN sk_families f ON f.id=s.family_id WHERE s.active=1 ORDER BY f.sort_order, f.name, s.name'),
            'hist' => DB::all('SELECT h.*, s.name skill FROM sk_history h JOIN sk_skills s ON s.id=h.skill_id WHERE h.employee_id=? ORDER BY h.id DESC LIMIT 100', [(int)$id]),
            'props' => DB::all("SELECT sp.*, s.name skill, t.title training FROM sk_proposals sp JOIN sk_skills s ON s.id=sp.skill_id LEFT JOIN training_sessions ss ON ss.id=sp.session_id LEFT JOIN trainings t ON t.id=ss.training_id WHERE sp.employee_id=? ORDER BY sp.id DESC LIMIT 50", [(int)$id]),
            'tr' => DB::all('SELECT ts.skill_id, ts.level, t.id, t.title FROM sk_training_skills ts JOIN trainings t ON t.id=ts.training_id WHERE t.active=1')]);
    }
    function assess(string $id): void {
        if (!Scope::allows((int)$id) || !DB::val('SELECT 1 FROM employees WHERE id=?', [(int)$id])) { $this->notFound(); return; }
        $sid = (int)$this->in('skill_id'); $lv = (string)$this->in('level', ''); $src = (string)$this->in('source', 'manager'); $date = (string)$this->in('assessed_at', date('Y-m-d')); $note = trim((string)$this->in('note', ''));
        if (!DB::val('SELECT 1 FROM sk_skills WHERE id=? AND active=1', [$sid])) $this->go("skills/employee/$id", 'Choisissez la compétence.', 'danger');
        if (!ctype_digit($lv) || (int)$lv > 5) $this->go("skills/employee/$id", 'Choisissez le niveau (Non acquis à Polyvalent).', 'danger');
        if (!isset(Skill::SOURCES[$src]) || $src === 'session') $src = 'manager';
        if (!strtotime($date) || $date > date('Y-m-d')) $this->go("skills/employee/$id", 'La date d\'évaluation doit être passée ou aujourd\'hui.', 'danger');
        if ((int)$lv === 5) { $fam = (int)DB::val('SELECT family_id FROM sk_skills WHERE id=?', [$sid]); $adv = (int)DB::val('SELECT COUNT(*) FROM sk_levels l JOIN sk_skills s ON s.id=l.skill_id WHERE l.employee_id=? AND s.family_id=? AND l.level>=3 AND l.skill_id<>?', [(int)$id, $fam, $sid]);
            if ($adv + 1 < Skill::polyMin()) $this->go("skills/employee/$id", 'Le niveau « Polyvalent » suppose au moins ' . Skill::polyMin() . ' compétences de la même famille au niveau Avancé ou plus.', 'danger'); }
        $ch = Skill::setLevel((int)$id, $sid, (int)$lv, $src, Auth::id(), $note ?: null, null, $date);
        if ($ch) { Audit::log('update', 'sk_level', (int)$id, null, ['skill_id' => $sid, 'level' => (int)$lv, 'source' => $src]); DB::exec("UPDATE sk_proposals SET status='superseded', decided_by=?, decided_at=? WHERE employee_id=? AND skill_id=? AND status='pending' AND level<=?", [Auth::id(), now(), (int)$id, $sid, (int)$lv]); }
        $this->go("skills/employee/$id", $ch ? 'Niveau enregistré.' : 'Niveau inchangé.', $ch ? 'success' : 'info');
    }

    // ------------------------------------------------------------------ propositions issues des sessions
    function proposals(): void {
        [$sw, $sp] = Scope::sql('e.id'); $st = (string)$this->in('status', 'pending'); $w = [$sw]; $p = $sp; if (in_array($st, ['pending', 'accepted', 'rejected', 'superseded'], true)) { $w[] = 'sp.status=?'; $p[] = $st; }
        if ($this->in('team_id')) { $w[] = 'e.team_id=?'; $p[] = (int)$this->in('team_id'); }
        $pg = paginate('sk_proposals sp JOIN employees e ON e.id=sp.employee_id JOIN sk_skills s ON s.id=sp.skill_id LEFT JOIN training_sessions ss ON ss.id=sp.session_id LEFT JOIN trainings t ON t.id=ss.training_id WHERE ' . implode(' AND ', $w), $p, (int)$this->in('page', 1), 30, 'sp.*, e.first_name, e.last_name, e.matricule, s.name skill, t.title training, ss.session_date', 'sp.id DESC');
        $this->view('skills/proposals', ['title' => 'Propositions de niveau', 'p' => $pg, 'st' => $st] + $this->filters());
    }
    function decide(string $id): void {
        $sp = DB::one('SELECT * FROM sk_proposals WHERE id=?', [(int)$id]); if (!$sp) { $this->notFound(); return; }
        if (!Scope::allows((int)$sp['employee_id'])) { $this->forbidden(); return; }
        $back = (string)$this->in('back', 'skills/proposals'); if (!preg_match('#^skills/#', $back)) $back = 'skills/proposals';
        if ($sp['status'] !== 'pending') $this->go($back, 'Cette proposition est déjà traitée.', 'warning');
        $act = (string)$this->in('act'); $note = trim((string)$this->in('note', ''));
        if ($act === 'accept') { Skill::setLevel((int)$sp['employee_id'], (int)$sp['skill_id'], (int)$sp['level'], 'session', Auth::id(), $note ?: null, $sp['session_id'] ? 'session #' . $sp['session_id'] : null); }
        elseif ($act !== 'reject') $this->go($back, 'Action inconnue.', 'danger');
        DB::update('sk_proposals', ['status' => $act === 'accept' ? 'accepted' : 'rejected', 'decided_by' => Auth::id(), 'decided_at' => now(), 'note' => $note ? mb_substr($note, 0, 300) : null], 'id=?', [(int)$id]);
        Audit::log('update', 'sk_proposal', (int)$id, ['status' => 'pending'], ['status' => $act === 'accept' ? 'accepted' : 'rejected']);
        $this->go($back, $act === 'accept' ? 'Niveau validé et enregistré.' : 'Proposition écartée : le niveau actuel est conservé.');
    }

    // ------------------------------------------------------------------ catalogue
    function catalog(): void {
        $this->view('skills/catalog', ['title' => 'Catalogue des compétences', 'families' => DB::all('SELECT f.*, (SELECT COUNT(*) FROM sk_skills s WHERE s.family_id=f.id) n FROM sk_families f ORDER BY f.sort_order, f.name'),
            'skills' => DB::all('SELECT s.*, f.name family, (SELECT COUNT(*) FROM sk_levels l WHERE l.skill_id=s.id) n_emp, (SELECT COUNT(*) FROM sk_position_reqs r WHERE r.skill_id=s.id) n_pos FROM sk_skills s JOIN sk_families f ON f.id=s.family_id ORDER BY f.sort_order, f.name, s.name'),
            'links' => DB::all('SELECT ts.*, t.title FROM sk_training_skills ts JOIN trainings t ON t.id=ts.training_id ORDER BY t.title'), 'trainings' => DB::all('SELECT id, title FROM trainings WHERE active=1 ORDER BY title'), 'poly' => Skill::polyMin()]);
    }
    function familyStore(): void {
        $n = trim((string)$this->in('name', '')); if ($n === '' || mb_strlen($n) > 100) $this->go('skills/catalog', 'Le nom de la famille est obligatoire (100 caractères au plus).', 'danger');
        if (DB::val('SELECT 1 FROM sk_families WHERE name=?', [$n])) $this->go('skills/catalog', 'Cette famille existe déjà.', 'danger');
        $id = DB::insert('sk_families', ['name' => $n, 'sort_order' => (int)$this->in('sort_order'), 'active' => 1]); Audit::log('create', 'sk_family', $id, null, ['name' => $n]); $this->go('skills/catalog', 'Famille créée.');
    }
    function familyUpdate(string $id): void {
        $f = DB::one('SELECT * FROM sk_families WHERE id=?', [(int)$id]); if (!$f) { $this->notFound(); return; }
        if ($this->in('act') === 'toggle') { DB::update('sk_families', ['active' => $f['active'] ? 0 : 1], 'id=?', [(int)$id]); $this->go('skills/catalog', $f['active'] ? 'Famille désactivée.' : 'Famille réactivée.'); }
        $n = trim((string)$this->in('name', '')); if ($n === '' || mb_strlen($n) > 100) $this->go('skills/catalog', 'Nom invalide.', 'danger');
        if (DB::val('SELECT 1 FROM sk_families WHERE name=? AND id<>?', [$n, (int)$id])) $this->go('skills/catalog', 'Cette famille existe déjà.', 'danger');
        DB::update('sk_families', ['name' => $n, 'sort_order' => (int)$this->in('sort_order')], 'id=?', [(int)$id]); Audit::log('update', 'sk_family', (int)$id, $f, ['name' => $n]); $this->go('skills/catalog', 'Famille modifiée.');
    }
    private function skillData(): array {
        $code = strtoupper(trim((string)$this->in('code', ''))); $name = trim((string)$this->in('name', '')); $fam = (int)$this->in('family_id'); $err = [];
        if (!preg_match('/^[A-Z0-9][A-Z0-9_-]{1,29}$/', $code)) $err[] = 'Code invalide (2 à 30 caractères : lettres, chiffres, tiret).'; if ($name === '' || mb_strlen($name) > 150) $err[] = 'Le libellé est obligatoire (150 caractères au plus).';
        if (!DB::val('SELECT 1 FROM sk_families WHERE id=?', [$fam])) $err[] = 'Choisissez la famille.';
        return [['code' => $code, 'name' => $name, 'family_id' => $fam, 'description' => mb_substr(trim((string)$this->in('description', '')), 0, 500) ?: null], $err];
    }
    function skillStore(): void {
        [$d, $err] = $this->skillData(); if (!$err && DB::val('SELECT 1 FROM sk_skills WHERE code=?', [$d['code']])) $err[] = 'Ce code existe déjà.';
        if ($err) { $_SESSION['_old'] = $_POST; $this->go('skills/catalog', implode(' ', $err), 'danger'); }
        $id = DB::insert('sk_skills', $d + ['active' => 1]); Audit::log('create', 'sk_skill', $id, null, $d); $this->go('skills/catalog', 'Compétence « ' . $d['name'] . ' » créée.');
    }
    function skillUpdate(string $id): void {
        $s = DB::one('SELECT * FROM sk_skills WHERE id=?', [(int)$id]); if (!$s) { $this->notFound(); return; } $act = (string)$this->in('act');
        if ($act === 'toggle') { DB::update('sk_skills', ['active' => $s['active'] ? 0 : 1], 'id=?', [(int)$id]); Audit::log('update', 'sk_skill', (int)$id, ['active' => $s['active']], ['active' => $s['active'] ? 0 : 1]); $this->go('skills/catalog', $s['active'] ? 'Compétence désactivée : elle n\'apparaît plus dans la matrice.' : 'Compétence réactivée.'); }
        if ($act === 'link') { $tid = (int)$this->in('training_id'); $lv = (int)$this->in('level', 2); if (!DB::val('SELECT 1 FROM trainings WHERE id=?', [$tid])) $this->go('skills/catalog', 'Choisissez la formation.', 'danger');
            if (DB::val('SELECT 1 FROM sk_training_skills WHERE training_id=? AND skill_id=?', [$tid, (int)$id])) DB::update('sk_training_skills', ['level' => max(1, min(4, $lv))], 'training_id=? AND skill_id=?', [$tid, (int)$id]); else DB::insert('sk_training_skills', ['training_id' => $tid, 'skill_id' => (int)$id, 'level' => max(1, min(4, $lv))]);
            Audit::log('update', 'sk_skill', (int)$id, null, ['training_id' => $tid, 'level' => $lv]); $this->go('skills/catalog', 'Formation liée : un résultat « Acquis » proposera ce niveau.'); }
        if ($act === 'unlink') { DB::exec('DELETE FROM sk_training_skills WHERE training_id=? AND skill_id=?', [(int)$this->in('training_id'), (int)$id]); $this->go('skills/catalog', 'Lien supprimé.'); }
        [$d, $err] = $this->skillData(); if (!$err && DB::val('SELECT 1 FROM sk_skills WHERE code=? AND id<>?', [$d['code'], (int)$id])) $err[] = 'Ce code existe déjà.';
        if ($err) $this->go('skills/catalog', implode(' ', $err), 'danger');
        DB::update('sk_skills', $d, 'id=?', [(int)$id]); Audit::log('update', 'sk_skill', (int)$id, $s, $d); $this->go('skills/catalog', 'Compétence modifiée.');
    }
    function settingsSave(): void {
        $v = (string)$this->in('poly_min', ''); if (!ctype_digit($v) || (int)$v < 2 || (int)$v > 10) $this->go('skills/catalog', 'Le seuil de polyvalence est un nombre entre 2 et 10.', 'danger');
        \App\Core\Settings::set('sk.poly_min', $v); Audit::log('update', 'sk_settings', null, null, ['poly_min' => (int)$v]); $this->go('skills/catalog', 'Seuil de polyvalence enregistré.');
    }

    // ------------------------------------------------------------------ niveaux requis par poste
    function positions(): void {
        $this->view('skills/positions', ['title' => 'Niveaux requis par poste', 'rows' => DB::all('SELECT po.*, (SELECT COUNT(*) FROM sk_position_reqs r WHERE r.position_id=po.id) n, (SELECT COUNT(*) FROM employees e WHERE e.position_id=po.id AND e.status<>\'left\') emp FROM positions po WHERE po.active=1 ORDER BY po.name')]);
    }
    function position(string $id): void {
        $po = DB::one('SELECT * FROM positions WHERE id=?', [(int)$id]); if (!$po) { $this->notFound(); return; }
        $this->view('skills/position', ['title' => 'Niveaux requis · ' . $po['name'], 'po' => $po, 'req' => Skill::required((int)$id), 'skills' => DB::all('SELECT s.*, f.name family FROM sk_skills s JOIN sk_families f ON f.id=s.family_id WHERE s.active=1 ORDER BY f.sort_order, f.name, s.name'),
            'copyFrom' => DB::all('SELECT po.id, po.name FROM positions po WHERE po.id<>? AND EXISTS (SELECT 1 FROM sk_position_reqs r WHERE r.position_id=po.id) ORDER BY po.name', [(int)$id])]);
    }
    function positionSave(string $id): void {
        $po = DB::one('SELECT * FROM positions WHERE id=?', [(int)$id]); if (!$po) { $this->notFound(); return; }
        if ($this->in('act') === 'copy') { $src = (int)$this->in('from'); if (!DB::val('SELECT 1 FROM positions WHERE id=?', [$src])) $this->go("skills/positions/$id", 'Poste source inconnu.', 'danger');
            DB::exec('DELETE FROM sk_position_reqs WHERE position_id=?', [(int)$id]); foreach (DB::all('SELECT skill_id, level FROM sk_position_reqs WHERE position_id=?', [$src]) as $r) DB::insert('sk_position_reqs', ['position_id' => (int)$id, 'skill_id' => (int)$r['skill_id'], 'level' => (int)$r['level']]);
            Audit::log('update', 'sk_position', (int)$id, null, ['copied_from' => $src]); $this->go("skills/positions/$id", 'Niveaux requis copiés.'); }
        $n = 0; $old = Skill::required((int)$id);
        foreach ((array)($_POST['level'] ?? []) as $sid => $lv) { $sid = (int)$sid; if (!DB::val('SELECT 1 FROM sk_skills WHERE id=?', [$sid])) continue; $lv = (string)$lv;
            if ($lv === '' || !ctype_digit($lv) || (int)$lv < 1) { DB::exec('DELETE FROM sk_position_reqs WHERE position_id=? AND skill_id=?', [(int)$id, $sid]); continue; }
            $lv = min(4, (int)$lv); $n++; if (isset($old[$sid])) DB::update('sk_position_reqs', ['level' => $lv], 'position_id=? AND skill_id=?', [(int)$id, $sid]); else DB::insert('sk_position_reqs', ['position_id' => (int)$id, 'skill_id' => $sid, 'level' => $lv]); }
        Audit::log('update', 'sk_position', (int)$id, $old, Skill::required((int)$id)); $this->go("skills/positions/$id", "$n niveau(x) requis enregistré(s).");
    }
}
