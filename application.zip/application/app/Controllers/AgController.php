<?php
namespace App\Controllers;
use App\Core\{Controller, DB, Audit, Auth, Ag, Notifier, Org};

/** Évaluation des agents : objectifs (unitaires, en masse, reconduits), validation N+1, campagnes d'auto-évaluation avec preuves. */
class AgController extends Controller {
    private function emp(int $id): ?array { return DB::one('SELECT * FROM employees WHERE id=?', [$id]); }
    private function obj(string $id): ?array { return DB::one('SELECT * FROM ag_objectives WHERE id=?', [(int)$id]); }
    private function weight($v): int { return max(1, min(10, (int)$v ?: 1)); }
    private function periodOf(): array { $t = (string)$this->in('period_type', 'month'); if (!isset(Ag::PT[$t])) $t = 'month'; $r = (string)$this->in('ref_date', date('Y-m-d')); if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $r)) $r = date('Y-m-d'); return [$t, ...Ag::period($t, $r)]; }
    private function lookups(): array {
        return ['teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name'), 'stores' => DB::all('SELECT id, name FROM stores WHERE active=1 ORDER BY name'), 'channels' => DB::all('SELECT id, name FROM channels ORDER BY name'), 'units' => Org::flat()];
    }

    // ---------- Objectifs : liste, export ----------
    private function objQuery(): array {
        $p = []; $w = [Ag::scope('o.employee_id', $p)]; $q = trim((string)$this->in('q', ''));
        if ($q !== '') { $w[] = '(o.title LIKE ? OR e.last_name LIKE ? OR e.first_name LIKE ? OR e.matricule LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%", "%$q%"); }
        $t = (string)$this->in('period_type', ''); if (isset(Ag::PT[$t])) { $w[] = 'o.period_type=?'; $p[] = $t; }
        $s = (string)$this->in('status', ''); if (isset(Ag::OS[$s])) { $w[] = 'o.status=?'; $p[] = $s; }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$this->in('from', ''))) { $w[] = 'o.period_end>=?'; $p[] = $this->in('from'); }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$this->in('to', ''))) { $w[] = 'o.period_start<=?'; $p[] = $this->in('to'); }
        if ((int)$this->in('team_id', 0)) { $w[] = 'e.team_id=?'; $p[] = (int)$this->in('team_id'); }
        if ((int)$this->in('batch', 0)) { $w[] = 'o.batch_id=?'; $p[] = (int)$this->in('batch'); }
        if ($this->in('mine', '') === '1' && ($me = Ag::myEmployee())) { $w[] = 'o.employee_id=?'; $p[] = $me; }
        return ['ag_objectives o JOIN employees e ON e.id=o.employee_id WHERE ' . implode(' AND ', $w), $p];
    }
    function objectives(): void {
        [$from, $p] = $this->objQuery();
        $pg = paginate($from, $p, $this->page(), 25, 'o.*, e.first_name, e.last_name, e.matricule', 'o.period_start DESC, e.last_name, o.id');
        foreach ($pg['rows'] as &$r) $r['can'] = Ag::canValidate($r); unset($r);
        $this->view('ag/objectives', ['title' => 'Objectifs', 'p' => $pg] + $this->lookups());
    }
    function objectivesExport(): void {
        [$from, $p] = $this->objQuery(); $rows = [];
        foreach (DB::all("SELECT o.*, e.first_name, e.last_name, e.matricule FROM $from ORDER BY o.period_start DESC, e.last_name LIMIT 20000", $p) as $r)
            $rows[] = [$r['matricule'], $r['last_name'] . ' ' . $r['first_name'], Ag::PT[$r['period_type']], Ag::label($r['period_type'], $r['period_start'], $r['period_end']), $r['title'], $r['target'], $r['weight'], Ag::OS[$r['status']][0], $r['adapted'] ? 'Oui' : 'Non'];
        Audit::log('export', 'ag_objectives'); csv_download('objectifs-agents.csv', ['Matricule', 'Collaborateur', 'Périodicité', 'Période', 'Objectif', 'Cible', 'Poids', 'Statut', 'Adapté'], $rows);
    }

    // ---------- Objectifs : création unitaire ----------
    function create(): void { $this->view('ag/obj_form', ['title' => 'Nouvel objectif', 'emps' => Ag::pickable(), 'o' => null]); }
    function store(): void {
        [$d, $err] = $this->validate(['title' => ['label' => 'L\'objectif', 'req' => true, 'max' => 190], 'target' => ['label' => 'La cible', 'max' => 150], 'description' => ['label' => 'La description', 'max' => 1000]], $_POST);
        $emp = (int)$this->in('employee_id', 0); if (!$emp || !$this->emp($emp)) $err['employee_id'] = 'Choisissez un collaborateur.'; elseif (!Ag::canSet($emp)) { $this->forbidden(); return; }
        if ($err) $this->back($err, $_POST, 'ag/objectives/new');
        [$t, $s, $e] = $this->periodOf(); $now = isset($_POST['validate_now']) && Ag::canSet($emp) && $emp !== Ag::myEmployee();
        $id = DB::insert('ag_objectives', $d + ['employee_id' => $emp, 'period_type' => $t, 'period_start' => $s, 'period_end' => $e, 'weight' => $this->weight($this->in('weight', 1)), 'status' => $now ? 'validated' : 'submitted',
            'validated_by' => $now ? Auth::id() : null, 'validated_at' => $now ? now() : null, 'created_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()]);
        Audit::log('create', 'ag_objectives', $id, null, $d); if (!$now) Ag::notifyN1([$emp], 'à valider', '/ag/objectives?status=submitted'); flash($now ? 'Objectif créé et validé.' : 'Objectif créé : il doit être validé par le N+1.'); redirect('ag/objectives');
    }
    function edit(string $id): void {
        $o = $this->obj($id); if (!$o) { $this->notFound(); return; } if (!Ag::canSet((int)$o['employee_id'])) { $this->forbidden(); return; }
        $this->view('ag/obj_form', ['title' => 'Modifier l\'objectif', 'emps' => Ag::pickable(), 'o' => $o]);
    }
    function update(string $id): void {
        $o = $this->obj($id); if (!$o) { $this->notFound(); return; } if (!Ag::canSet((int)$o['employee_id'])) { $this->forbidden(); return; }
        [$d, $err] = $this->validate(['title' => ['label' => 'L\'objectif', 'req' => true, 'max' => 190], 'target' => ['label' => 'La cible', 'max' => 150], 'description' => ['label' => 'La description', 'max' => 1000]], $_POST);
        if ($err) $this->back($err, $_POST, "ag/objectives/$id/edit");
        [$t, $s, $e] = $this->periodOf(); $new = $d + ['period_type' => $t, 'period_start' => $s, 'period_end' => $e, 'weight' => $this->weight($this->in('weight', 1)), 'status' => 'submitted', 'validated_by' => null, 'validated_at' => null, 'reject_reason' => null, 'updated_at' => now()];
        if ($o['batch_id'] && ($d['target'] !== $o['target'] || $new['weight'] !== (int)$o['weight'] || $d['title'] !== $o['title'])) $new['adapted'] = 1;
        DB::update('ag_objectives', $new, 'id=?', [(int)$id]); Audit::log('update', 'ag_objectives', $id, $o, $new); Ag::notifyN1([(int)$o['employee_id']], 'à valider (modifié)', '/ag/objectives?status=submitted');
        flash('Objectif modifié : il repasse en validation.'); redirect('ag/objectives');
    }
    function delete(string $id): void {
        $o = $this->obj($id); if (!$o) { $this->notFound(); return; } if (!Ag::canSet((int)$o['employee_id'])) { $this->forbidden(); return; }
        if (DB::val('SELECT 1 FROM ag_eval_items WHERE objective_id=?', [(int)$id])) { flash('Cet objectif figure déjà dans une évaluation : suppression impossible.', 'danger'); redirect('ag/objectives'); }
        DB::exec('DELETE FROM ag_objectives WHERE id=?', [(int)$id]); Audit::log('delete', 'ag_objectives', $id, $o); flash('Objectif supprimé.'); redirect('ag/objectives');
    }

    // ---------- Validation N+1 ----------
    function validateOne(string $id): void {
        $o = $this->obj($id); if (!$o) { $this->notFound(); return; } if (!Ag::canValidate($o)) { $this->forbidden(); return; }
        $this->setStatus($o, 'validated', null); flash('Objectif validé.'); redirect($_POST['back'] ?? 'ag/objectives');
    }
    function reject(string $id): void {
        $o = $this->obj($id); if (!$o) { $this->notFound(); return; } if (!Ag::canValidate($o)) { $this->forbidden(); return; }
        $why = trim((string)$this->in('reason', '')); if ($why === '') { flash('Indiquez le motif du refus.', 'danger'); redirect('ag/objectives'); }
        $this->setStatus($o, 'rejected', mb_substr($why, 0, 500)); flash('Objectif refusé : le motif est transmis.'); redirect('ag/objectives');
    }
    function validateBulk(): void {
        $n = 0; foreach ((array)($_POST['ids'] ?? []) as $id) { $o = $this->obj((string)(int)$id); if ($o && $o['status'] === 'submitted' && Ag::canValidate($o)) { $this->setStatus($o, 'validated', null, false); $n++; } }
        flash($n ? "$n objectif(s) validé(s)." : 'Aucun objectif sélectionné.', $n ? 'success' : 'warning'); redirect('ag/objectives?status=submitted');
    }
    private function setStatus(array $o, string $st, ?string $why, bool $notify = true): void {
        DB::update('ag_objectives', ['status' => $st, 'validated_by' => Auth::id(), 'validated_at' => now(), 'reject_reason' => $why, 'updated_at' => now()], 'id=?', [(int)$o['id']]);
        Audit::log($st === 'validated' ? 'validate' : 'reject', 'ag_objectives', $o['id']);
        if ($notify && ($u = Ag::userOfEmployee((int)$o['employee_id'])) && $u !== Auth::id()) Notifier::send($u, $st === 'validated' ? 'Objectif validé' : 'Objectif refusé', $o['title'] . ($why ? " — $why" : ''), '/ag/my');
    }

    // ---------- Attribution en masse, adaptation, reconduction ----------
    function mass(): void { $this->view('ag/mass', ['title' => 'Attribuer des objectifs en masse', 'emps' => Ag::pickable()] + $this->lookups()); }
    function massStore(): void {
        [$d, $err] = $this->validate(['title' => ['label' => 'L\'objectif', 'req' => true, 'max' => 190], 'target' => ['label' => 'La cible', 'max' => 150], 'description' => ['label' => 'La description', 'max' => 1000]], $_POST);
        $scope = (string)$this->in('scope', 'all'); if (!in_array($scope, ['all', 'unit', 'team', 'store', 'channel', 'emps'], true)) $scope = 'all';
        $ref = $scope === 'emps' ? implode(',', array_map('intval', (array)($_POST['emps'] ?? []))) : (string)(int)$this->in('ref_' . $scope, 0);
        if ($scope !== 'all' && ($ref === '' || $ref === '0')) $err['scope'] = 'Précisez le périmètre (activité, équipe, store, canal ou collaborateurs).';
        $emps = $err ? [] : Ag::inScope($scope, $ref); $skip = array_map('intval', (array)($_POST['skip'] ?? [])); $emps = array_values(array_filter($emps, fn($e) => !in_array((int)$e['id'], $skip, true)));
        if (!$err && !$emps) $err['scope'] = 'Aucun collaborateur actif dans ce périmètre.';
        if ($err) $this->back($err, $_POST, 'ag/objectives/mass');
        [$t, $s, $e] = $this->periodOf(); $w = $this->weight($this->in('weight', 1)); $now = isset($_POST['validate_now']);
        $b = DB::insert('ag_batches', ['label' => $d['title'], 'scope' => $scope, 'scope_ref' => $ref, 'created_by' => Auth::id(), 'created_at' => now()]); $n = 0; $dup = 0; $ids = [];
        foreach ($emps as $x) {
            if (DB::val('SELECT 1 FROM ag_objectives WHERE employee_id=? AND period_start=? AND period_type=? AND title=?', [(int)$x['id'], $s, $t, $d['title']])) { $dup++; continue; }
            $v = $now && Ag::canSet((int)$x['id']) && (int)$x['id'] !== Ag::myEmployee();
            DB::insert('ag_objectives', $d + ['employee_id' => (int)$x['id'], 'period_type' => $t, 'period_start' => $s, 'period_end' => $e, 'weight' => $w, 'status' => $v ? 'validated' : 'submitted', 'validated_by' => $v ? Auth::id() : null, 'validated_at' => $v ? now() : null,
                'batch_id' => $b, 'created_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()]); $n++; if (!$v) $ids[] = (int)$x['id'];
        }
        Audit::log('create', 'ag_batches', $b, null, ['scope' => $scope, 'ref' => $ref, 'n' => $n]); Ag::notifyN1($ids, 'à valider (attribution en masse)', '/ag/objectives?status=submitted');
        flash("$n objectif(s) attribué(s)" . ($dup ? ", $dup déjà existant(s) ignoré(s)" : '') . '. Vous pouvez adapter la cible de certains collaborateurs ci-dessous.'); redirect("ag/batches/$b");
    }
    function batch(string $id): void {
        $b = DB::one('SELECT * FROM ag_batches WHERE id=?', [(int)$id]); if (!$b) { $this->notFound(); return; }
        $p = []; $rows = DB::all('SELECT o.*, e.first_name, e.last_name, e.matricule FROM ag_objectives o JOIN employees e ON e.id=o.employee_id WHERE o.batch_id=? AND ' . Ag::scope('o.employee_id', $p) . ' ORDER BY e.last_name, e.first_name', [(int)$id]);
        $this->view('ag/batch', ['title' => 'Lot d\'objectifs', 'b' => $b, 'rows' => $rows, 'scopeName' => Ag::scopeName($b['scope'], (string)$b['scope_ref'])]);
    }
    function batchSave(string $id): void {
        $b = DB::one('SELECT * FROM ag_batches WHERE id=?', [(int)$id]); if (!$b) { $this->notFound(); return; } $n = 0; $del = 0; $ids = [];
        foreach (DB::all('SELECT * FROM ag_objectives WHERE batch_id=?', [(int)$id]) as $o) {
            if (!Ag::canSet((int)$o['employee_id'])) continue; $k = (int)$o['id'];
            if (isset($_POST['rm'][$k]) && !DB::val('SELECT 1 FROM ag_eval_items WHERE objective_id=?', [$k])) { DB::exec('DELETE FROM ag_objectives WHERE id=?', [$k]); $del++; continue; }
            $tg = mb_substr(trim((string)($_POST['target'][$k] ?? $o['target'])), 0, 150); $w = $this->weight($_POST['weight'][$k] ?? $o['weight']);
            if ($tg !== (string)$o['target'] || $w !== (int)$o['weight']) { DB::update('ag_objectives', ['target' => $tg ?: null, 'weight' => $w, 'adapted' => 1, 'status' => 'submitted', 'validated_by' => null, 'validated_at' => null, 'updated_at' => now()], 'id=?', [$k]); $n++; $ids[] = (int)$o['employee_id']; }
        }
        Audit::log('update', 'ag_batches', $id, null, ['adapted' => $n, 'removed' => $del]); Ag::notifyN1($ids, 'à valider (adaptés)', '/ag/objectives?status=submitted'); flash("$n objectif(s) adapté(s), $del retiré(s).", 'success'); redirect("ag/batches/$id");
    }
    function renew(): void { $this->view('ag/renew', ['title' => 'Reconduire des objectifs'] + $this->lookups()); }
    function renewStore(): void {
        $t = (string)$this->in('period_type', 'month'); if (!isset(Ag::PT[$t])) $t = 'month'; $ref = (string)$this->in('src_date', date('Y-m-d')); $ref2 = (string)$this->in('dst_date', '');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $ref)) { flash('Date de la période source invalide.', 'danger'); redirect('ag/objectives/renew'); }
        [$ss, $se] = Ag::period($t, $ref); [$ds, $de] = preg_match('/^\d{4}-\d{2}-\d{2}$/', $ref2) ? Ag::period($t, $ref2) : Ag::next($t, $ss);
        if ($ds <= $ss) { flash('La période cible doit suivre la période source.', 'danger'); redirect('ag/objectives/renew'); }
        $scope = (string)$this->in('scope', 'all'); if (!in_array($scope, ['all', 'unit', 'team', 'store', 'channel'], true)) $scope = 'all'; $ref3 = $scope === 'all' ? '' : (string)(int)$this->in('ref_' . $scope, 0);
        $ok = array_map(fn($e) => (int)$e['id'], Ag::inScope($scope, $ref3)); $n = $this->copyObjectives($t, $ss, $ds, $de, $ok, $this->in('only', 'validated') === 'all' ? null : 'validated');
        flash("$n objectif(s) reconduit(s) sur " . Ag::label($t, $ds, $de) . ' ; ils repassent en validation N+1.'); redirect('ag/objectives?from=' . $ds . '&to=' . $de . '&period_type=' . $t);
    }
    /** @param int[] $emps */
    private function copyObjectives(string $t, string $srcStart, string $ds, string $de, array $emps, ?string $status, ?int $onlyId = null): int {
        if (!$emps) return 0; $w = 'period_type=? AND period_start=? AND employee_id IN (' . implode(',', $emps) . ')'; $p = [$t, $srcStart]; if ($status) { $w .= ' AND status=?'; $p[] = $status; } if ($onlyId) { $w .= ' AND id=?'; $p[] = $onlyId; }
        $n = 0; $ids = [];
        foreach (DB::all("SELECT * FROM ag_objectives WHERE $w", $p) as $o) {
            if (DB::val('SELECT 1 FROM ag_objectives WHERE employee_id=? AND period_type=? AND period_start=? AND title=?', [(int)$o['employee_id'], $t, $ds, $o['title']])) continue;
            DB::insert('ag_objectives', ['employee_id' => $o['employee_id'], 'period_type' => $t, 'period_start' => $ds, 'period_end' => $de, 'title' => $o['title'], 'description' => $o['description'], 'target' => $o['target'], 'weight' => $o['weight'], 'status' => 'submitted',
                'batch_id' => $o['batch_id'], 'source_id' => $o['id'], 'adapted' => $o['adapted'], 'created_by' => Auth::id(), 'created_at' => now(), 'updated_at' => now()]); $n++; $ids[] = (int)$o['employee_id'];
        }
        Audit::log('renew', 'ag_objectives', null, null, ['n' => $n, 'from' => $srcStart, 'to' => $ds]); Ag::notifyN1($ids, 'reconduit(s) à valider', '/ag/objectives?status=submitted'); return $n;
    }
    function renewOne(string $id): void {
        $o = $this->obj($id); if (!$o) { $this->notFound(); return; } if (!Ag::canSet((int)$o['employee_id'])) { $this->forbidden(); return; }
        [$ds, $de] = Ag::next($o['period_type'], $o['period_start']); $n = $this->copyObjectives($o['period_type'], $o['period_start'], $ds, $de, [(int)$o['employee_id']], null, (int)$id);
        flash($n ? 'Objectif reconduit sur ' . Ag::label($o['period_type'], $ds, $de) . ' (à valider par le N+1).' : 'Cet objectif existe déjà sur la période suivante.', $n ? 'success' : 'warning'); redirect('ag/objectives');
    }

    // ---------- Mon espace ----------
    function my(): void {
        Ag::sync(); $me = Ag::myEmployee(); $objs = []; $evals = [];
        if ($me) {
            $objs = DB::all('SELECT * FROM ag_objectives WHERE employee_id=? AND period_end>=? ORDER BY period_start, id', [$me, date('Y-m-d', strtotime('-31 day'))]);
            $evals = DB::all('SELECT v.*, c.name cname, c.closes_on, c.status cstatus, c.period_type, c.period_start, c.period_end FROM ag_evals v JOIN ag_campaigns c ON c.id=v.campaign_id WHERE v.employee_id=? AND c.status<>\'planned\' ORDER BY c.closes_on DESC, v.id DESC', [$me]);
        }
        $this->view('ag/my', ['title' => 'Mes objectifs et évaluations', 'me' => $me, 'objs' => $objs, 'evals' => $evals]);
    }

    // ---------- Campagnes ----------
    function campaigns(): void {
        Ag::sync(); $pg = paginate('ag_campaigns', [], $this->page(), 25, '*', 'closes_on DESC, id DESC');
        foreach ($pg['rows'] as &$c) { $c['n'] = (int)DB::val('SELECT COUNT(*) FROM ag_evals WHERE campaign_id=?', [(int)$c['id']]); $c['done'] = (int)DB::val("SELECT COUNT(*) FROM ag_evals WHERE campaign_id=? AND status<>'todo'", [(int)$c['id']]); $c['rev'] = (int)DB::val("SELECT COUNT(*) FROM ag_evals WHERE campaign_id=? AND status='reviewed'", [(int)$c['id']]); } unset($c);
        $this->view('ag/campaigns', ['title' => 'Campagnes d\'évaluation', 'p' => $pg]);
    }
    function campaignNew(): void { $this->view('ag/campaign_form', ['title' => 'Nouvelle campagne d\'évaluation'] + $this->lookups()); }
    function campaignStore(): void {
        [$d, $err] = $this->validate(['name' => ['label' => 'Le nom', 'req' => true, 'max' => 190], 'opens_on' => ['label' => 'Le début', 'req' => true, 'date' => true], 'closes_on' => ['label' => 'La clôture', 'req' => true, 'date' => true]], $_POST);
        $r1 = (int)$this->in('remind1_days', 7); $r2 = (int)$this->in('remind2_days', 3);
        if ($r1 < 1 || $r1 > 60 || $r2 < 1 || $r2 > 60) $err['remind1_days'] = 'Les relances se règlent entre 1 et 60 jours avant la clôture.'; elseif ($r1 <= $r2) $err['remind1_days'] = 'La 1re relance doit précéder la 2e (plus de jours avant la clôture).';
        if (empty($err['closes_on']) && empty($err['opens_on']) && $d['closes_on'] < $d['opens_on']) $err['closes_on'] = 'La clôture doit être postérieure au début.';
        $scope = (string)$this->in('scope', 'all'); if (!in_array($scope, ['all', 'unit', 'team', 'store', 'channel'], true)) $scope = 'all'; $ref = $scope === 'all' ? '' : (string)(int)$this->in('ref_' . $scope, 0);
        if ($scope !== 'all' && $ref === '0') $err['scope'] = 'Précisez le périmètre.';
        $emps = $err ? [] : Ag::inScope($scope, $ref); if (!$err && !$emps) $err['scope'] = 'Aucun collaborateur actif dans ce périmètre.';
        if ($err) $this->back($err, $_POST, 'ag/campaigns/new');
        [$t, $s, $e] = $this->periodOf();
        $id = DB::insert('ag_campaigns', $d + ['period_type' => $t, 'period_start' => $s, 'period_end' => $e, 'status' => 'planned', 'remind1_days' => $r1, 'remind2_days' => $r2, 'remind_email' => isset($_POST['remind_email']) ? 1 : 0, 'created_by' => Auth::id(), 'created_at' => now()]);
        foreach ($emps as $x) DB::insert('ag_evals', ['campaign_id' => $id, 'employee_id' => (int)$x['id'], 'status' => 'todo']);
        Ag::sync(); Audit::log('create', 'ag_campaigns', $id, null, $d + ['n' => count($emps)]); flash('Campagne créée pour ' . count($emps) . ' collaborateur(s).'); redirect("ag/campaigns/$id");
    }
    private function camp(string $id): ?array { Ag::sync(); return DB::one('SELECT * FROM ag_campaigns WHERE id=?', [(int)$id]); }
    private function evalQuery(array $c): array {
        $w = ['v.campaign_id=?']; $p = [(int)$c['id']]; $q = trim((string)$this->in('q', ''));
        if ($q !== '') { $w[] = '(e.last_name LIKE ? OR e.first_name LIKE ? OR e.matricule LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $s = (string)$this->in('status', ''); if (isset(Ag::ES[$s])) { $w[] = 'v.status=?'; $p[] = $s; } if ((int)$this->in('team_id', 0)) { $w[] = 'e.team_id=?'; $p[] = (int)$this->in('team_id'); }
        return ['ag_evals v JOIN employees e ON e.id=v.employee_id WHERE ' . implode(' AND ', $w), $p];
    }
    function campaignShow(string $id): void {
        $c = $this->camp($id); if (!$c) { $this->notFound(); return; } [$from, $p] = $this->evalQuery($c);
        $pg = paginate($from, $p, $this->page(), 25, 'v.*, e.first_name, e.last_name, e.matricule, e.team_id', 'e.last_name, e.first_name');
        $st = DB::one("SELECT COUNT(*) n, SUM(status<>'todo') done, SUM(status='reviewed') rev, AVG(final_score) avg FROM ag_evals WHERE campaign_id=?", [(int)$id]);
        $this->view('ag/campaign', ['title' => $c['name'], 'c' => $c, 'p' => $pg, 'st' => $st, 'teams' => DB::all('SELECT id, name FROM teams WHERE active=1 ORDER BY name')]);
    }
    function campaignExport(string $id): void {
        $c = $this->camp($id); if (!$c) { $this->notFound(); return; } [$from, $p] = $this->evalQuery($c); $rows = [];
        foreach (DB::all("SELECT v.*, e.first_name, e.last_name, e.matricule FROM $from ORDER BY e.last_name LIMIT 20000", $p) as $r)
            $rows[] = [$r['matricule'], $r['last_name'] . ' ' . $r['first_name'], Ag::ES[$r['status']][0], $r['self_score'], $r['final_score'], Ag::rating($r['final_score'] === null ? null : (int)$r['final_score'])[0], $r['self_submitted_at'], $r['reviewed_at']];
        Audit::log('export', 'ag_campaigns', $id); csv_download('campagne-' . (int)$id . '.csv', ['Matricule', 'Collaborateur', 'Statut', 'Auto-évaluation %', 'Note finale %', 'Appréciation', 'Remise le', 'Évalué le'], $rows);
    }
    function campaignDates(string $id): void {
        $c = $this->camp($id); if (!$c) { $this->notFound(); return; } $o = (string)$this->in('opens_on', ''); $e = (string)$this->in('closes_on', '');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $o) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $e) || $e < $o) { flash('Dates invalides : la clôture doit suivre le début.', 'danger'); redirect("ag/campaigns/$id"); }
        $f = ['opens_on' => $o, 'closes_on' => $e]; if ($e !== $c['closes_on']) { $f['reminded1_at'] = null; $f['reminded2_at'] = null; }
        if ($c['status'] === 'closed') $f['status'] = 'planned'; DB::update('ag_campaigns', $f, 'id=?', [(int)$id]); Ag::sync(); Audit::log('update', 'ag_campaigns', $id, $c, $f); flash('Dates mises à jour.'); redirect("ag/campaigns/$id");
    }
    function campaignClose(string $id): void {
        $c = $this->camp($id); if (!$c) { $this->notFound(); return; } DB::update('ag_campaigns', ['status' => 'closed'], 'id=?', [(int)$id]); Audit::log('close', 'ag_campaigns', $id); flash('Campagne clôturée.'); redirect("ag/campaigns/$id");
    }

    // ---------- Évaluation : auto-évaluation, preuves, revue N+1 ----------
    function review(): void {
        Ag::sync(); $p = []; $w = [Ag::scope('v.employee_id', $p), "c.status<>'planned'"]; $s = (string)$this->in('status', 'self_done'); if (isset(Ag::ES[$s])) { $w[] = 'v.status=?'; $p[] = $s; }
        if ((int)$this->in('campaign', 0)) { $w[] = 'v.campaign_id=?'; $p[] = (int)$this->in('campaign'); } $q = trim((string)$this->in('q', ''));
        if ($q !== '') { $w[] = '(e.last_name LIKE ? OR e.first_name LIKE ? OR e.matricule LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%"); }
        $me = Ag::myEmployee(); if ($me) { $w[] = 'v.employee_id<>?'; $p[] = $me; }
        $pg = paginate('ag_evals v JOIN employees e ON e.id=v.employee_id JOIN ag_campaigns c ON c.id=v.campaign_id WHERE ' . implode(' AND ', $w), $p, $this->page(), 25, 'v.*, e.first_name, e.last_name, e.matricule, c.name cname, c.closes_on, c.status cstatus', 'c.closes_on, e.last_name');
        $this->view('ag/review', ['title' => 'Évaluations à examiner', 'p' => $pg, 'camps' => DB::all("SELECT id, name FROM ag_campaigns WHERE status<>'planned' ORDER BY closes_on DESC LIMIT 50")]);
    }
    private function loadEval(string $id): ?array {
        Ag::sync(); $ev = DB::one('SELECT * FROM ag_evals WHERE id=?', [(int)$id]); if (!$ev) { $this->notFound(); return null; }
        if (!Ag::canSeeEval($ev)) { $this->forbidden(); return null; } return $ev;
    }
    function evalShow(string $id): void {
        if (!($ev = $this->loadEval($id))) return; $c = DB::one('SELECT * FROM ag_campaigns WHERE id=?', [(int)$ev['campaign_id']]);
        if ($c['status'] === 'planned') { flash('Cette campagne n\'est pas encore ouverte.', 'warning'); redirect('ag/my'); }
        if ($c['status'] === 'open' && $ev['status'] === 'todo') Ag::syncItems($ev, $c);
        $items = DB::all('SELECT * FROM ag_eval_items WHERE eval_id=? ORDER BY id', [(int)$id]); $evd = []; foreach (DB::all('SELECT * FROM ag_evidence WHERE eval_id=? ORDER BY id', [(int)$id]) as $f) $evd[(int)$f['item_id']][] = $f;
        $self = (int)$ev['employee_id'] === Ag::myEmployee();
        $this->view('ag/eval', ['title' => 'Évaluation · ' . $c['name'], 'ev' => $ev, 'c' => $c, 'items' => $items, 'evd' => $evd, 'emp' => $this->emp((int)$ev['employee_id']), 'self' => $self,
            'canSelf' => $self && $c['status'] === 'open' && $ev['status'] === 'todo', 'canReview' => !$self && Ag::canSet((int)$ev['employee_id']) && $c['status'] !== 'planned']);
    }
    function evalSelf(string $id): void {
        if (!($ev = $this->loadEval($id))) return; $c = DB::one('SELECT * FROM ag_campaigns WHERE id=?', [(int)$ev['campaign_id']]);
        if ((int)$ev['employee_id'] !== Ag::myEmployee()) { $this->forbidden(); return; }
        if ($c['status'] !== 'open' || $ev['status'] !== 'todo') { flash('Cette auto-évaluation n\'est plus modifiable.', 'warning'); redirect("ag/eval/$id"); }
        Ag::syncItems($ev, $c); $items = DB::all('SELECT * FROM ag_eval_items WHERE eval_id=? ORDER BY id', [(int)$id]); $submit = $this->in('act', 'save') === 'submit'; $err = []; $up = [];
        foreach ($items as $i) {
            $k = (int)$i['id']; $res = mb_substr(trim((string)($_POST['res'][$k] ?? '')), 0, 1000); $sc = $_POST['sc'][$k] ?? ''; $sc = $sc === '' ? null : max(0, min(100, (int)$sc));
            DB::update('ag_eval_items', ['self_result' => $res ?: null, 'self_score' => $sc], 'id=?', [$k]); $i['self_result'] = $res; $i['self_score'] = $sc; $up[] = $i;
            $err = array_merge($err, $this->takeEvidence($id, $k));
            if ($submit && ($res === '' || $sc === null)) $err[] = '« ' . $i['label'] . ' » : indiquez le résultat obtenu et votre note.';
        }
        $com = mb_substr(trim((string)$this->in('self_comment', '')), 0, 2000); $f = ['self_comment' => $com ?: null, 'self_score' => Ag::avg($up, 'self_score')];
        if ($submit && !$items) $err[] = 'Aucun objectif validé sur cette période : rien à évaluer.';
        if ($submit && !$err) { $f += ['status' => 'self_done', 'self_submitted_at' => now()]; }
        DB::update('ag_evals', $f, 'id=?', [(int)$id]);
        if ($submit && !$err) { Audit::log('submit', 'ag_evals', $id); if (($u = Ag::n1User((int)$ev['employee_id'])) && $u !== Auth::id()) Notifier::send($u, 'Auto-évaluation remise', Ag::name((int)$ev['employee_id']) . ' a remis son auto-évaluation « ' . $c['name'] . ' ».', '/ag/eval/' . $id); flash('Auto-évaluation remise à votre N+1.'); redirect('ag/my'); }
        foreach ($err as $m) flash($m, 'danger'); if (!$err) flash('Brouillon enregistré.'); redirect("ag/eval/$id");
    }
    /** Enregistre les preuves (fichier png/jpg/pdf/docx/xlsx 5 Mo, ou lien) d'un objectif. @return string[] erreurs */
    private function takeEvidence(string $eid, int $iid): array {
        $err = []; $have = (int)DB::val('SELECT COUNT(*) FROM ag_evidence WHERE item_id=?', [$iid]); $f = $_FILES["ev_$iid"] ?? null;
        if ($f && is_array($f['name'])) foreach ($f['name'] as $k => $name) {
            if (($f['error'][$k] ?? 4) === UPLOAD_ERR_NO_FILE) continue; if ($f['error'][$k] !== UPLOAD_ERR_OK) { $err[] = "« $name » non reçu."; continue; }
            if ($have >= 5) { $err[] = '5 preuves maximum par objectif.'; break; }
            $n = trim(preg_replace('#[\x00-\x1f\\\\/]+#', '_', (string)$name)); $ext = strtolower(pathinfo($n, PATHINFO_EXTENSION));
            if (!isset(Ag::EV_TYPES[$ext]) || $f['size'][$k] > 5 * 1024 * 1024) { $err[] = "« $n » refusé (png, jpg, pdf, docx ou xlsx ; 5 Mo maximum)."; continue; }
            $stored = bin2hex(random_bytes(16)) . '.' . $ext; if (!@move_uploaded_file($f['tmp_name'][$k], Ag::dir() . '/' . $stored)) { $err[] = "« $n » non enregistré."; continue; }
            DB::insert('ag_evidence', ['eval_id' => (int)$eid, 'item_id' => $iid, 'user_id' => Auth::id(), 'kind' => 'file', 'label' => pathinfo($n, PATHINFO_FILENAME), 'original_name' => mb_substr($n, 0, 190), 'stored_name' => $stored, 'mime' => Ag::EV_TYPES[$ext], 'size' => (int)$f['size'][$k], 'created_at' => now()]); $have++;
        }
        $url = trim((string)($_POST['lk'][$iid] ?? ''));
        if ($url !== '') { if (!preg_match('#^https?://#i', $url) || !filter_var($url, FILTER_VALIDATE_URL)) $err[] = 'Lien de preuve invalide (adresse http ou https).'; elseif ($have >= 5) $err[] = '5 preuves maximum par objectif.';
            else DB::insert('ag_evidence', ['eval_id' => (int)$eid, 'item_id' => $iid, 'user_id' => Auth::id(), 'kind' => 'link', 'label' => mb_substr(trim((string)($_POST['ll'][$iid] ?? '')) ?: $url, 0, 190), 'url' => mb_substr($url, 0, 500), 'created_at' => now()]); }
        return $err;
    }
    function evidenceFile(string $fid): void {
        $f = DB::one("SELECT * FROM ag_evidence WHERE id=? AND kind='file'", [(int)$fid]); if (!$f) { $this->notFound(); return; }
        $ev = DB::one('SELECT * FROM ag_evals WHERE id=?', [(int)$f['eval_id']]); if (!$ev || !Ag::canSeeEval($ev)) { $this->forbidden(); return; }
        $path = Ag::dir() . '/' . $f['stored_name']; if (!is_file($path)) { $this->notFound(); return; } Audit::log('download', 'ag_evidence', $fid);
        header('Content-Type: ' . $f['mime']); header('X-Content-Type-Options: nosniff'); header("Content-Security-Policy: sandbox; default-src 'none'; img-src 'self'; style-src 'unsafe-inline'"); header('Content-Length: ' . filesize($path));
        header('Content-Disposition: ' . (str_starts_with($f['mime'], 'image/') || $f['mime'] === 'application/pdf' ? 'inline' : 'attachment') . '; filename="' . rawurlencode($f['original_name']) . '"; filename*=UTF-8\'\'' . rawurlencode($f['original_name'])); readfile($path); exit;
    }
    function evidenceDelete(string $fid): void {
        $f = DB::one('SELECT * FROM ag_evidence WHERE id=?', [(int)$fid]); if (!$f) { $this->notFound(); return; } $ev = DB::one('SELECT * FROM ag_evals WHERE id=?', [(int)$f['eval_id']]);
        $c = DB::one('SELECT status FROM ag_campaigns WHERE id=?', [(int)$ev['campaign_id']]); if ((int)$ev['employee_id'] !== Ag::myEmployee() || $ev['status'] !== 'todo' || $c['status'] !== 'open') { $this->forbidden(); return; }
        if ($f['stored_name']) @unlink(Ag::dir() . '/' . $f['stored_name']); DB::exec('DELETE FROM ag_evidence WHERE id=?', [(int)$fid]); Audit::log('delete', 'ag_evidence', $fid); flash('Preuve retirée.'); redirect('ag/eval/' . $ev['id']);
    }
    function evalReview(string $id): void {
        if (!($ev = $this->loadEval($id))) return; if ((int)$ev['employee_id'] === Ag::myEmployee() || !Ag::canSet((int)$ev['employee_id'])) { $this->forbidden(); return; }
        $c = DB::one('SELECT * FROM ag_campaigns WHERE id=?', [(int)$ev['campaign_id']]); if ($c['status'] === 'planned') { $this->forbidden(); return; }
        $items = DB::all('SELECT * FROM ag_eval_items WHERE eval_id=? ORDER BY id', [(int)$id]); $up = [];
        foreach ($items as $i) { $k = (int)$i['id']; $ms = $_POST['ms'][$k] ?? ''; $ms = $ms === '' ? null : max(0, min(100, (int)$ms)); $mc = mb_substr(trim((string)($_POST['mc'][$k] ?? '')), 0, 500);
            DB::update('ag_eval_items', ['manager_score' => $ms, 'manager_comment' => $mc ?: null], 'id=?', [$k]); $i['manager_score'] = $ms; $up[] = $i; }
        $final = Ag::avg($up, 'manager_score'); $done = $this->in('act', 'save') === 'finish';
        if ($done && $final === null) { flash('Attribuez au moins une note avant de finaliser.', 'danger'); redirect("ag/eval/$id"); }
        $f = ['manager_comment' => mb_substr(trim((string)$this->in('manager_comment', '')), 0, 2000) ?: null, 'manager_user_id' => Auth::id(), 'final_score' => $final]; if ($done) $f += ['status' => 'reviewed', 'reviewed_at' => now()];
        DB::update('ag_evals', $f, 'id=?', [(int)$id]); Audit::log($done ? 'review' : 'save', 'ag_evals', $id);
        if ($done && ($u = Ag::userOfEmployee((int)$ev['employee_id']))) Notifier::send($u, 'Votre évaluation est disponible', '« ' . $c['name'] . ' » : note finale ' . $final . ' %.', '/ag/eval/' . $id);
        flash($done ? 'Évaluation finalisée : le résultat est visible par l\'agent.' : 'Notes enregistrées.'); redirect($done ? 'ag/review' : "ag/eval/$id");
    }
    function evalReopen(string $id): void {
        if (!($ev = $this->loadEval($id))) return; if (!Ag::canSet((int)$ev['employee_id']) || (int)$ev['employee_id'] === Ag::myEmployee()) { $this->forbidden(); return; }
        $c = DB::one('SELECT * FROM ag_campaigns WHERE id=?', [(int)$ev['campaign_id']]); if ($c['status'] !== 'open') { flash('La campagne est clôturée : rouvrez-la d\'abord en prolongeant la date de clôture.', 'danger'); redirect("ag/eval/$id"); }
        DB::update('ag_evals', ['status' => 'todo', 'self_submitted_at' => null, 'reviewed_at' => null, 'final_score' => null], 'id=?', [(int)$id]); Audit::log('reopen', 'ag_evals', $id);
        if ($u = Ag::userOfEmployee((int)$ev['employee_id'])) Notifier::send($u, 'Auto-évaluation à compléter', 'Votre N+1 vous renvoie l\'auto-évaluation « ' . $c['name'] . ' ».', '/ag/eval/' . $id); flash('Renvoyée à l\'agent.'); redirect('ag/review');
    }
}
